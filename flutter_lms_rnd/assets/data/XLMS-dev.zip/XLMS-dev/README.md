# Getting Started

## Install dependencies

npm - v8.3.0

node - v16.13.1


next - v12.1.8

amplify - v7.6.5

tailwindcss - v3.0.8

chartsjs - v3.7.0

## Install Commands

### On Linux (Ubuntu)

#### Node JS

Step 1: Use the following link to download the nodejs file: <https://nodejs.org/dist/v16.13.1/node-v16.13.1-linux-x64.tar.xz>.

Step 2: Open a terminal window (Ubuntu: ctrl+alt+t) and Go to the directory in which (.tar.xz file) is downloaded.
In my case --> ~/Downloads directory

```bash
#!/bin/bash
cd ~/Downloads/
```

Step 3: Update System Repositories

```bash
#!/bin/bash
sudo apt update
```

Step 4: Install the package xz-utils

```bash
#!/bin/bash
sudo apt install xz-utils
```

Step 5: To Extract the .tar.xz file

```bash
#!!/bin/bash
sudo tar -xvf node-v16.13.1-linux-x64.tar.xz
```

Step 6: Copy the contents from the extracted folder to /usr folder

```bash
#!/bin/bash
sudo cp -r node-v16.13.1-linux-x64/{bin,include,lib,share} /usr/
```

Step 7: Check the node version

```bash
#!/bin/bash
node --version
```

#### Install Amplify

```bash
#!/bin/bash
npm install aws-amplify @aws-amplify/ui-react
```

#### Install Tailwindcss

```bash
#!/bin/bash
npm install -D tailwindcss postcss autoprefixer
```

#### To initialize tailwindcss for the project

```bash
#!/bin/bash
npx tailwindcss init
```

After installing Add the paths to all of your template files in your tailwind.config.js file.

```json
module.exports = {
content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
theme: {
extend: {},
},
plugins: [],
};
```

## To create a Project

```bash
#!/bin/bash
npx create-next-app <ProjectName>
```

or

## clone this project

If you want to use this project. Follow these steps:

```bash
#!/bin/bash
git clone <GitCloneURl>
```

## Following steps

## Install the Node modules in your Projects

## Step 1

```bash
#!/bin/bash
npm install
```

## Step 2 Build the project

```bash
#!/bin/bash
npm run build
```

## Step 3 Run the project

```bash
#!/bin/bash
npm run dev
```

## Add this line to global.css file

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

## Init Amplify Steps

```bash
Run Headless Bash file based on Amplify ID

```
