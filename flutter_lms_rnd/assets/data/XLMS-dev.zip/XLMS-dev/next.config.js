module.exports = {
  reactStrictMode: true,
  images: {
    unoptimized: true,
  },
  compress: false,
  env: {
    Encryption_Key: "dev",
    PAGEGRIDSIZE: 10,
    /*Custom Login Policy Password Length*/
    APIGATEWAY_GetLoginPolicyForForgetPassword: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/getloginpolicyforforgetpassword",

    /* Create Company */
    APIGATEWAY_URL_COMPANYCREATION: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_COMPANYCREATION: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CompanyCreation_dev",
    COMPANYLOGO_PRESIGNED_URL_S3_BUCKET: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/presignedurlforcreatecompany_dev",

    /* Edit Company */
    STEP_FUNCTION_ARN_COMPANYEDIT: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CompanyUpdation_dev",
    APIGATEWAY_URL_COMPANYEDIT: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    COMPANYLOGOEDIT_PRESIGNED_URL_S3_BUCKET: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/presignedurlforeditcompany_dev",

    /* Suspend Company */
    APIGATEWAY_URL_SUSPENDTENANT: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_SUSPENDTENANT: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CompanySuspend_dev",

    /* UnSuspend Company */
    APIGATEWAY_URL_UNSUSPENDTENANT: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_UNSUSPENDTENANT: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CompanyUnSuspend_dev",

    /*Company Overview */
    COMPANYOVERVIEW: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/companyoverview_dev",

    /* Company Info  */
    COMPANYLOGO_SIZE: 50 * 1024,
    COMPANYLOGO_EXTENTION: ["png", "jpg", "jpeg"],

    /* Create Plan Processor */
    APIGATEWAY_URL_CREATEPLANPROCESSOR: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_CREATEPLANPROCESSOR: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CreatePlanProcessor_dev",

    /* Change Plan Processor */
    APIGATEWAY_URL_CHANGE_PLAN_PROCESSOR: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/updateplanprocessor",

    /* Email & User Checking */
    APIGATEWAY_URL_USEREXISTSORNOT: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/userexistornot_dev",
    APIGATEWAY_URL_EMAILEXISTSORNOT: "https://p9p4cdhx39.execute-api.ap-south-1.amazonaws.com/dev/emailexistornot_dev",

    /* User Creation */
    APIGATEWAY_URL_USERCREATION: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_USERCREATION: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CreateUser_dev",

    /* User Info  */
    USERPROFILE_SIZE: 50 * 1024,
    USERPROFILE_EXTENTION: ["png", "jpg", "jpeg"],

    /* User Update */
    APIGATEWAY_URL_UPDATEUSER: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_UPDATEUSER: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-EditUser_dev",

    /* Suspend User */
    APIGATEWAY_URL_SUSPENDUSER: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_SUSPENDUSER: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-UserSuspend_dev",

    /* Unsuspend User */
    APIGATEWAY_URL_UNSUSPENDUSER: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_UNSUSPENDUSER: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-UserUnSuspend_dev",

    /* User Bulk Upload */
    APIGATEWAY_URL_CSVPRESIGNEDURL: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/getpresignedurlforbulkuploaduser_dev",
    APIGATEWAY_URL_BULKUPLOADUSER: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_UPLOADUSER: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-UserBulkUpload_dev",

    /* Change Password */
    APIGATEWAY_URL_CHANGEPASSWORD: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/userpasswordchange_dev",

    /*User group delete*/
    APIGATEWAY_URL_DELETEUSERGROUP: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/deletelistitems_dev",

    /* User manualgroup Notification */
    APIGATEWAY_URL_USERGROUPNOTIFICATION: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/usertogroupmanualnotification_dev",

    /* User Group Bulk*/
    APIGATEWAY_URL_CREATEGROUP: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_UPLOADUSERGROUP: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-BulkUserGroupUpload_dev",

    /* Get Batch Item Using PK, SK, Table Name */
    GET_BATCH_ITEM: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/getdetailsusingpksk_dev",

    /* Get Records Using Filter */
    GET_FILTER_ITEM: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/gettingrecordsusingfilter_dev",

    /* Get Records Using Single Filter */
    GET_SINGLE_FILTER_LIST_ITEM: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/filterrecords_dev",

    /* Logging */
    APIGATEWAY_URL_GETQUERYIDFORMATETRACEID: "https://8geat6llh4.execute-api.ap-south-1.amazonaws.com/dev/getqueryidfromtraceid_dev",
    APIGATEWAY_URL_FETCHLOGSUSEQUERY: "https://8geat6llh4.execute-api.ap-south-1.amazonaws.com/dev/fetchlogsusingqueryid_dev",

    /* Create Roles And Permission */
    APIGATEWAY_URL_ROLE_PERMISSION_CREATION: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_ROLE_PERMISSION_CREATION: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CreateRolesandPermissions_dev",

    /* Edit Roles And Permission */
    APIGATEWAY_URL_ROLE_PERMISSION_EDIT: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_ROLE_PERMISSION_EDIT: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-UpdateRolesandPermissions_dev",

    /* Delete Roles And Permission */
    APIGATEWAY_URL_ROLE_PERMISSION_DELETE: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_ROLE_PERMISSION_DELETE: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-DeleteRolesandPermissions_dev",

    /*Activity Thumbname Size And Extentions */
    ACTIVITY_THUMBNAIL_SIZE: 50 * 1024,
    ACTIVITY_THUMBNAIL_EXTENTION: ["png", "jpg", "jpeg"],
    NOTIFICATION_FILE_EXTENTION: ["png", "jpg", "jpeg", "csv", "txt", "doc", "docx", "pdf"],
    NOTIFICATION_UPLOAD_FILE_SIZE: 2 * 1024 * 1024,

    /* Activity Upload File */
    APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/amuploadfileforactivity_dev",

    /*Activity Unsaved To Saved */
    ACTIVITY_UNSAVED_TO_SAVED: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/amuploadfileunsavedtosaved_dev",

    /*Activity Multi-Language  Unsaved To Saved */
    ACTIVITY_LANG_UNSAVED_TO_SAVED: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/ambulkmovefile_dev",

    /*Activity Video Streaming */
    ACTIVITY_VIDEO_STREAMING: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/transcodingvideo_dev",

    /*Activity MoveFolder With UserSub*/
    UNSAVED_TO_SAVED_SUBMITED_ASSIGNMENT_ACTIVITY: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/movefolderwithusersub_dev",

    /* Activity Enroll User */
    APIGATEWAY_URL_ENROLL_UPLOADUSER: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/amuserenroll_dev",

    /* Activity Enroll Bulk Upload */
    APIGATEWAY_URL_ENROLL_BULKUPLOAD: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_ENROLL_BULKUPLOAD: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StateMachine-AMBulkUser_dev",

    /* Activity Enroll Group */
    APIGATEWAY_URL_ENROLL_UPLOADGROUP: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/amgroupenrolluser_dev",

    /*Scrom Activity*/
    APIGATEWAY_URL_SCORMFILEUPlOAD: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_SCORM: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-SCORM_dev",

    /* Forget Password */
    FORGET_PASSWORD: "",

    /* */
    APIGATEWAY_SAVEPAGECONTENT: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/savefileforpageactivity_dev",

    /* Custom Certificate Upload */
    APIGATEWAY_URL_CUSTOM_CERTIFICATE_UPLOAD_URL: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/uploadcustomcertificate_dev",

    /* Login */
    APIGATEWAY_URL_CUSTOM_LOGIN: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/customlogin_dev",

    /* Custom Certificate Read */
    APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/readingcustomcertificate_dev",

    /* Download Generated Certificate*/
    APIGATEWAY_URL_TO_DOWNLOAD_GENERATED_CERTIFICATE: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/getpresignedurlforpageactivity_dev",

    /* Delete File Based Object Url */
    APIGATEWAY_URL_DELETE_OBJECT_URL: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/deletecustomcertificate_dev",

    /* Video Transcoding Url*/
    VIDEO_TRANSCODING_URL: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/transcodingvideo_dev",

    /* Activity Send Notification Event Bridge */
    ACTIVITY_SENDNOTIFICATION_EVENT_BRIDGE: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/notificationtriggerlambda_dev",
    ACTIVITY_ENROLLUSER_FILE_SIZE: 5 * 1024 * 1024,

    /* Course Management Thumbnail Info */
    COURSE_THUMBNAIL_SIZE: 128 * 1024 * 1024,
    COURSE_THUMBNAIL_EXTENTION: ["png", "jpg", "jpeg"],
    COURSE_VIDEO_EXTENTION: ["mp4", "mkv", "webm", "avi", "mov", "wmv"],
    COURSE_VIDEO_SIZE: 1 * 1024 * 1024 * 1024,
    ACTIVITY_ALLFILE_SIZE: 1 * 1024 * 1024 * 1024,

    /* User Send Notification */
    USER_SENDNOTIFICATION_EVENT_BRIDGE: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/notificationtriggerlambda_dev",

    /* CourseManagement Enroll User */
    APIGATEWAY_URL_COURSE_ENROLLUSER: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_COURSE_ENROLLUSER: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CMEnrollUser_dev",

    APIGATEWAY_URL_COURSE_ENROLLGROUP: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_COURSE_ENROLLGROUP: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CMEnrollGroup_dev",

    APIGATEWAY_URL_COURSE_ENROLL_BULKUPLOAD: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_COURSE_ENROLL_BULKUPLOAD: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StateMachine-CMBulkUser_dev",

    APIGATEWAY_URL_COURSE_SELF_ENROLLUSER: "https://f0azepbrvf.execute-api.ap-south-1.amazonaws.com/CourseManagemnet/cmselfenrolluser",

    /* Course Video STREAMING*/
    ACTIVITY_VIDEO_COURSE_STREAMING: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/coursetranscodingvideo_dev",

    /* QUIZ ACTIVITY TEMPLATE UPLOAD */
    STEP_FUNCTION_ARN_QUIZ_TEMPLATE_UPLOAD: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-QuizQuestionBankInfo_dev",
    APIGATEWAY_URL_QUIZ_TEMPLATE_UPLOAD: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_OFFLINE_QUIZ: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-OfflineQuizUpdateMark_dev",
    /*INVOKE URL */
    APIGATEWAY_INVOKEURL: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/downloads3url_dev",

    /* Get Live Users  */
    APIGATEWAY_URL_LIVE_USER_COUNT: "https://j857mbq74b.execute-api.ap-south-1.amazonaws.com/dev/reportsprocess_dev",

    /* Change Password Notification */
    APIGATEWAY_CHANGEPASSWORD_NOTIFICATION: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/notificationforchangepassword_dev",
    APIGATEWAY_REPORT_URL: "https://j857mbq74b.execute-api.ap-south-1.amazonaws.com/dev/reportsprocess_dev",

    APIGATEWAY_REPORT_URL_DOWNLOAD: "https://j857mbq74b.execute-api.ap-south-1.amazonaws.com/dev/downloadcourseactivityreport",

    /* Feedback Activity Report Download */
    APIGATEWAY_FEEDBACK_REPORT_DOWNLOAD_URL: "https://j857mbq74b.execute-api.ap-south-1.amazonaws.com/dev/feedbackreport_dev",

    /* Certificate  Generation*/
    STEP_FUNCTION_ARN_CERTIFICATE_GENERATION: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CertificateGeneration_dev",

    /* User Wise Course Report Notification */
    APIGATEWAY_USERWISE_COURSE_NOTIFICATION_URL: "https://j857mbq74b.execute-api.ap-south-1.amazonaws.com/dev/sentsinglemailcontent",

    /*SiteConfigNotification*/
    CUSTOM_SEND_NOTIFICATION_URL: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/notificationtriggerlambda_dev",
    SENDNOTIFICATIONGROUP: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/groupwisenotification",

    /* Report*/
    REPORT_BUCKET_NAME: "nvl-lms-userreports-dev",
    REPORT_SCORE_WISE_ASSESSMENT: "https://j857mbq74b.execute-api.ap-south-1.amazonaws.com/dev/scorewiseassessment_dev",
    REPORT_QUESTION_WISE_ASSESSMENT: " https://j857mbq74b.execute-api.ap-south-1.amazonaws.com/dev/questionwiseassessment_dev",
    // Update user profile info
    APIGATEWAY_URL_UPDATE_USER_PROFILE: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/updateuserprofile_dev",

    /*Course Approval Notification */
    APIGATEWAY_COURSE_APPROVAL_NOTIFICATION: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/courseapprovalnotification_dev",
    /*QUILL EDITOR FONT */
    QUILLEDITORFONT: ["Serif", "Monospace", "Arial", "Times New Roman", "Calibri", "Verdana", "Georgia", "Helvetica", "Tahoma", "Open Sans", "Roboto", "Lato", "Montserrat", "Proxima Nova", "Raleway", "Source Sans Pro", "Ubuntu"],

    // Zoom
    APIGATEWAY_ZOOM_TOKEN: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/getzoomtoken_dev",

    APIGATEWAY_ZOOM_CREATION: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/zoomcreation_dev",

    /*Knowledge Repository File info */
    KNOWLEDGEREPO_THUMBNAIL_SIZE: 50 * 1024,
    KNOWLEDGEREPO_THUMBNAIL_EXTENTION: ["png", "jpg", "jpeg"],
    KNOWLEDGEREPO_FILE_EXTENTION: ["jpg", "jpeg", "png", "mp4", "avi", "mov", "doc", "docx", "zip", "pdf", "csv", "xls", "xlsx", "mp3"],
    KNOWLEDGEREPO_FILE_SIZE: 1 * 1024 * 1024 * 1024,
    KNOWLEDGEREPO_VIDEO_COURSE_STREAMING: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/krtranscodingvideo_dev",

    /*PopFileUploadSize */
    POPUP_FILE_SIZE: 128 * 1024 * 1024,
    POPUP_FILE_EXTENTION: ["jpg", "jpeg", "png", "mp4", "mp3"],
    POPUP_UPLOAD_UNSAVE_PRESIGN: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/getpresignedurlformodalpopup_dev",
    POPUP_UPLOAD_UNSAVED_TO_SAVE: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/movefilefromunsavedtosaved_dev",
    POPUP_VIDEO_TRANSCODING_URL: "https://sk2qhkbfzc.execute-api.ap-south-1.amazonaws.com/dev/transcodingvideofile_dev",

    /*Batch Restriction*/
    BATCH_RESTRICTION_SET: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-CreateDefaultRestrictions_dev",
    BATCH_RESTRICTION_API: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",

    // Add evnent
    ADD_EVENT_BASED_ON_GROUP_COURSE_API: "https://abtyc4hch1.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_ADD_EVENT: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-EventCreation_dev",

    //Training Management
    /*Upload File Presigned Url*/
    APIGATEWAY_URL_UPLOAD_FILE_TRAINING: "https://5qot9vgcw5.execute-api.ap-south-1.amazonaws.com/dev/getpresignedurlfortrainingmanagement_dev",

    /*Upload File Unsaved To Saved*/
    TRAINING_UNSAVED_TO_SAVED: "https://5qot9vgcw5.execute-api.ap-south-1.amazonaws.com/dev/movefilefromunsavedtosavedpath_dev",

    /* Training Enroll Bulk Upload */
    APIGATEWAY_URL_TRAINING_ENROLL_BULKUPLOAD: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_TRAINING_ENROLL_BULKUPLOAD: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StateMachine-AMBulkUser_dev",
    APIGATEWAY_URL_TRAINING_ENROLL_UPLOADUSER: "https://5qot9vgcw5.execute-api.ap-south-1.amazonaws.com/dev/stepfunctiontrigger_dev",
    STEP_FUNCTION_ARN_TRAINING_ENROLL_UPLOADUSER: "arn:aws:states:ap-south-1:078418245182:stateMachine:NVL-LMS-StepFunction-TrainingEnrollUser_dev",
    //End Training Management

    //Ramdom Quiz Question
    QuizRandom: "https://mylng7gfih.execute-api.ap-south-1.amazonaws.com/dev/quizrandomquestion_dev",
  },

  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "X-Frame-Options",
            value: "SAMEORIGIN",
          },
          {
            key: "X-XSS-Protection",
            value: "1; mode=block",
          },
          {
            key: "Strict-Transport-Security",
            value: "max-age=65540 ; includeSubDomains",
          },
          {
            key: "Cache-Control",
            value: "public, s-maxage=10, max-age=300, s-max-age=300, stale-while-revalidate=59",
          },
        ],
      },
    ];
  },
};
