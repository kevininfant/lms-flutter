const plugin = require("tailwindcss/plugin");
const colors = require("tailwindcss/colors");
delete colors["lightBlue"];
delete colors["warmGray"];
delete colors["trueGray"];
delete colors["coolGray"];
delete colors["blueGray"];

module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  important: false,
  theme: {
    extend: {},
  },
  plugins: [require("@tailwindcss/forms")],
  theme: {
    colors: {
      transparent: "transparent",
      current: "currentColor",
      white: "#ffffff",
      primary: "#007afa",
      bermuda: "#047D95",
      emerald: colors.emerald,
      fuchsia: colors.fuchsia,
      "th-background": "var(--background)",
      "th-background-secondary": "var(--background-secondary)",
      "th-foreground": "var(--foreground)",
      "th-primary-dark": "var(--primary-dark)",
      "th-primary-medium": "var(--primary-medium)",
      "th-primary-light": "var(--primary-light)",
      "th-accent-dark": "var(--accent-dark)",
      "th-accent-medium": "var(--accent-medium)",
      "th-accent-light": "var(--accent-light)",

      "th-navbar-header-bg-color": "var(--nvl-header-bg-color)",
      "th-navbar-header-txt-color": "var(--nvl-header-txt-color)",
      "th-navbar-header-icon-color": "var(--nvl-header-icon-color)",
      "th-navbar-header-button-bg-color": "var(--nvl-header-button-bg-color)",
      "th-navbar-header-button-txt-color": "var(--nvl-header-button-txt-color)",
      "th-navbar-header-link-color": "var(--nvl-header-link-color)",
      "th-navbar-header-link-hover-color": "var(--nvl-header-link-hover-color)",
      "th-navbar-header-button-hover-bg-color": "var(--nvl-header-button-hover-bg-color)",
      "th-navbar-header-button-txt-hover-color": "var(--nvl-header-button-txt-hover-color)",
      "th-navbar-header-icon-hover-color": "var(--nvl-header-icon-hover-color)",

      "th-sidebar-bg-color": "var(--nvl-sidebar-bg-color)",
      "th-sidebar-nested-bg-color": "var(--nvl-sidebar-nested-bg-color)",
      "th-sidebar-hover-bg-color": "var(--nvl-sidebar-hover-bg-color)",
      "th-sidebar-txt-color": "var(--nvl-sidebar-txt-color)",
      "th-sidebar-icon-color": "var(--nvl-sidebar-icon-color)",
      "th-sidebar-button-bg-color": "var(--nvl-sidebar-button-bg-color)",
      "th-sidebar-button-txt-color": "var(--nvl-sidebar-button-txt-color)",
      "th-sidebar-link-color": "var(--nvl-sidebar-link-color)",
      "th-sidebar-link-hover-color": "var(--nvl-sidebar-link-hover-color)",
      "th-sidebar-button-hover-bg-color": "var(--nvl-sidebar-button-hover-bg-color)",
      "th-sidebar-menu-active-state": "var(--nvl-sidebar-menu-active-state-color)",
      "th-sidebar-menu-active-txt-color": "var(--nvl-sidebar-menu-active-txt-color)",

// body

      "th-body-bg-color": "var(--nvl-body-bg-color)",
      "th-body-txt-color": "var(--nvl-body-txt-color)",
      "th-body-icon-color": "var(--nvl-body-icon-color)",
      "th-body-icon-hover-color": "var(--nvl-body-icon-hover-color)",
      "th-body-button-bg-color": "var(--nvl-body-button-bg-color)",
      "th-body-button-txt-color": "var(--nvl-body-button-txt-color)",
      "th-body-link-color": "var(--nvl-body-link-color)",
      "th-body-link-hover-color": "var(--nvl-body-link-hover-color)",
      "th-body-button-hover-bg-color": "var(--nvl-body-button-hover-bg-color)",
      "th-body-icon-hover-bg-color": "var(--nvl-body-icon-hover-color)",
      "th-loader-bg-color": "var(--nvl-loading-spinner-bg-clr)",

      /*grid*/
      "th-grid-header-bg-color": "var(--nvl-grid-header-bg-color)",
      "th-grid-th-bg-start-color": "var(--nvl-grid-row-start-bg-color)",
      "th-grid-td-bg-end-color": "var(--nvl-grid-row-end-bg-color)",
      "th-grid-txt-color": "var(--nvl-grid-txt-color)",

      ...colors,
    },
    extend: {
      fontFamily: { Montserrat: ["Montserrat", "Helvetica,Arial,sans-serif"] },
    },
    fontSize: {
      xs: ".75rem",
      sm: ".85rem",
      tiny: ".85rem",
      base: "1rem",
      lg: "1.125rem",
      xl: "1.25rem",
      "2xl": "1.5rem",
      "3xl": "1.875rem",
      "4xl": "2.25rem",
      "5xl": "3rem",
      "6xl": "4rem",
      "7xl": "5rem",
    },
    animation: {
      "spin-slow": "spin 3s linear infinite",
    },
    // screens: {
    //   sm: { min: "0px", max: "767px" },
    //   md: { min: "768px", max: "1023px" },
    //   lg: { min: "1024px", max: "1279px" },
    //   xl: { min: "1280px", max: "2560px" },
    // },
  },
};
