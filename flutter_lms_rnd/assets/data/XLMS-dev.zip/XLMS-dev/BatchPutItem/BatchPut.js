import { AppsyncDBconnection } from "DBConnection/ErrorResponse";

export const BatchPut = (props) => {
    const RemoveNull = (obj) => {
        let tempjson = {};
        Object.keys(obj).forEach((k) => {
            if (obj?.[k] != undefined) {
                tempjson = { ...tempjson, [k]: obj?.[k] }
            }
        });
        return tempjson;
    };
    async function updateItem(temp) {
        await AppsyncDBconnection(props?.query, { input: temp }, props.user);
    }
    const values = RemoveNull(props?.Values), BatchPut = [];
    for (let i = 1; i <= props?.Shard; i++) {
        BatchPut = [...BatchPut, { ...values, ...props?.UpdateData, PK: values?.PK + "#" + i }];
        if (i % 25 === 0 || i === props?.Shard) {
            updateItem(BatchPut);
            BatchPut = [];
        }
    }
};
