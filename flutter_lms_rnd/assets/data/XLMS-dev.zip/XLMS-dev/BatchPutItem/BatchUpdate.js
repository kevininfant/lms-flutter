import { AppsyncDBconnection } from "DBConnection/ErrorResponse";

export const UpdateBatch = (value) => {
  let UpdateData = value?.UpdateData; let SK = value?.UpdateData?.SK; let props = value?.props; let VariableRecord = value?.inn; let ReplaceData = []; let PK = value?.pk; let GsiPK = SK; let GsiSK = PK; let Query = value.query;
  let tempData = { ...UpdateData, ...VariableRecord };
   ReplaceData = [...ReplaceData, { ...tempData, PK, GsiPK, GsiSK }];
   ReplaceData = ReplaceData[0];
  async function updateItem() {
    let query = Query; let variables = { input: { ...ReplaceData } };
    await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
  }
  updateItem();
};
