export const Regex = (type) => {
  let regex;
  switch (type) {
    case "SpecialCharValidation":
      regex = /[<>/*#`'[\]"%~-]/;
      break;
    case "AllowAlphaNumWithSpace":
      regex = /^(?!\s)(?!.*\s$)[\w\s()-]+$/;
      break;
    case "AllowAlphaNumWithoutSpace":
      regex = /^[\w]+$/;
      break;
    case "AllowOnlyNumbers":
      regex = /^[0-9]+$/;
      break;
    case "AllowAlphaNumeric":
      regex = /^[a-zA-Z0-9]*$/;
      break;
    case "PhoneNumber":
      regex = /^[6-9][\d]{9}$/;
      break;
    case "AllowOnlyNumbersWithSpace":
      regex = /^(?!\s)(?!.*\s$)[\d\s()-]+$/;
      break;
    case "AllowOnlyNumbersExceptZero":
      regex = /^[1-9]+$/;
      break;
    case "AllowZeroasSecondary":
      regex = /^[1-9][0-9]+$/;
      break;
    case "AllowNumbersWithDot":
      regex = /^[\d.]+$/;
      break;
    case "AllowAlphabetsAndDot":
      regex = /^[a-zA-Z.]+$/;
      break;
    case "Date":
      regex = /^\d{4}-(0[1-9]|1[012])-(0[1-9]|[12][0-9]|3[01])$/;
      break;
    case "AlphabetsOnly":
      regex = /^[a-zA-Z]+$/;
      break;
    case "AlphabetsAndSpaceOnly":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z\s()-]+$/;
      break;
    case "DeniedChars":
      regex = /[<>/*#`'[\]"%~-]/;
      break;
    case "Email":
      regex = /^[a-zA-Z0-9.+_-]{2}[a-z.A-Z0-9+_-]+@[a-zA-Z0-9]{1}[a-zA-Z0-9-]+[.][a-zA-Z0-9]{1}[a-zA-Z0-9]+$/;
      break;
    case "AllowAlphaNumericwithQuestionMark":
      regex = /^[\w*? -]+$/;
      break;
    case "AllowAlphaNumericWithFewSpecial":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z0-9-_"':,*&-+()\s]+$/;
      break;
    case "AllowAlphaNumWithSpecial":
      regex = /^[\w\{\}\(\)\s]+$/;
      break;
    case "Url":
      regex = /^(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9_+%-]+(\.[a-zA-Z0-9+\_%-]+)*(:[0-9]{1,5})?(\/[a-zA-Z0-9+()?#~=&\._%-]*)*)?$/g;
      break;
    case "VideoUrl":
      regex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/g;
      break;
    case "AllowAlphaNumericandHyphen":
      regex = /^[a-zA-Z0-9-]+$/;
      break;
    case "AlphaNumericandHyphenLimit30":
      regex = /^(?=.{1,30}$).*[a-zA-Z0-9-]+$/;
      break;
    case "AlphaNumericWithSpecialLimit30":
      regex = /^(?=.{1,30}$).*[\w\{\}\(\)\s]+$/;
      break;
    case "AlphaNumWithAllowedSpecialChar":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z][a-zA-Z0-9-&,_.+/"():\s`]+$/;
      break;
    case "AlphaNumForTopicName":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z][a-zA-Z0-9-&,_.+/"():\s]+$/;
      break;
    case "AllowAlphaNumericAndDot":
      regex = /^[a-zA-Z0-9.]+$/;
      break;
    case "OnlyAlphabets":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z\s]+$/;
      break;
    case "AlphaNumWithAllowedSomeSpecialChar":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z][a-zA-Z0-9-&'.\s]+$/;
      break;
    case "OnlyUpperCaseAndNumWithoutSpace":
      regex = /^[A-Z0-9]+$/;
      break;
    case "AcceptAllRestrictSpaceAtBeginning":
      regex = /^[^\d\s\W].*?[^\s]$/;
      break;
    case "AlphabetsAndSpaceWithDot":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z\s()-.]+$/;
      break;
    case "AlphanumSpecialCharModified":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z0-9][a-zA-Z0-9\-&,_.? `'-()'+/=!;"":\s]+$/;
      break;
    case "AlphanumWithAllSpecialChar":
      regex = /^(?!\s)(?!.*\s$)[a-zA-Z0-9][a-zA-Z0-9\-&,_.? @#$%^*|<>~`/{}'-()'+=!;"":\s]+$/;
      break;
    case "AlphanumWithAllSpecialCharAtStart":
      regex = /^(?!\s)(?!.*\s$)[\-&,_.? @#$%^*|<>~`/{}'-()'+=!;"":\sa-zA-Z0-9][a-zA-Z0-9\-&,_.? @#$%^*|<>~`/{}'-()'+=!;"":\s]+$/;
      break;
    default:
      regex = "No regex found";
  }
  return regex;
};