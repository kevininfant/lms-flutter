import { API } from "aws-amplify";

export const AppSyncStatusCode = (ResponseCode, res) => {
  let ErrorMessage;
  switch (ResponseCode) {
    case 200:
      ErrorMessage = "Success";
      break;
    case 400:
      ErrorMessage = "Some error occured while save your data";
      break;
    case 403:
      ErrorMessage = "Forbidden";
      break;
    case 404:
      ErrorMessage = "Requested url not found";
      break;
    case 500:
      ErrorMessage = "Internal server error occured";
      break;
    case 503:
      ErrorMessage = "Poor network connection";
      break;
    default:
      ErrorMessage = "Something went wrong while processing your data";
  }
  return { "Status": ErrorMessage, res: res };
};

export const APIGatewayStatsusCode = (ResponseCode, res) => {
  let ErrorMessage;
  switch (ResponseCode) {
    case 200:
      ErrorMessage = "Success";
      break;
    case 400:
      ErrorMessage = "Some error occured while save your data";
      break;
    case 401:
      ErrorMessage = "The custom or Amazon Cognito authorizer failed to authenticate";
      break;
    case 403:
      ErrorMessage = "Missing authentication token error or attempts to invoke an unsupported API method";
      break;
    case 404:
      ErrorMessage = "API Gateway cannot find the specified resource after an API request passes authentication and authorization";
      break;
    case 413:
      ErrorMessage = "The request too large error";
      break;
    case 415:
      ErrorMessage = "A payload is of an unsupported media type";
      break;
    case 429:
      ErrorMessage = "The gateway response for the usage plan quota exceeded error";
      break;
    case 500:
      ErrorMessage = "Amazon Cognito authorizer failed to authenticate";
      break;
    case 503:
      ErrorMessage = "Poor network connection";
      break;
    default:
      ErrorMessage = "Something went wrong while processing your data";
  }
  return ErrorMessage;
};

/*Appsync*/
export const AppsyncDBconnection = async (query, variable, token) => {
  let FinalToken = token;
  if (localStorage?.["AccessTokenKey"] != undefined) {
    if (localStorage?.[localStorage?.["AccessTokenKey"]] != token) {
      FinalToken = localStorage?.[localStorage?.["AccessTokenKey"]];
    }
  }

  let Status, response = {};
  await API.graphql({
    query: query,
    variables: {
      ...variable,
    },
    authMode: "AWS_LAMBDA",
    authToken: FinalToken
  }, { "Authorization": FinalToken })
    .then((res) => {
      Status = "Success";
      response = res.data;
    })
    .catch((e) => {
      let ResponseCode = e?.errors?.[0]?.message;
      ResponseCode = ResponseCode && ResponseCode.split(",")[1]?.match(/(\d+)/)?.[1];
      Status = ResponseCode;
    });
  return Status == "Success" ? AppSyncStatusCode(200, response) : AppSyncStatusCode(parseInt(Status), response);
};

export const APIGatewayGetRequest = async (fetchURL, headers) => {
  let Status, response;
  if (headers?.["headers"]?.["authorizationtoken"] != undefined && headers?.["headers"]?.["authorizationtoken"] != localStorage?.[localStorage?.["AccessTokenKey"]] && localStorage?.[localStorage?.["AccessTokenKey"]] != undefined) {
    headers = { ...headers, ["headers"]: { ...headers?.["headers"], authorizationtoken: localStorage?.[localStorage?.["AccessTokenKey"]] } };
  }
  await fetch(fetchURL, headers)
    .then(async (res) => {
      {
        response = res;
        Status = res.status == 200 ? "Success" : APIGatewayStatsusCode(res.status);
      }
    })
    .catch((error) => {
      Status == 400;
    });
  return { Status: (Status == "Success" || Status == undefined) ? APIGatewayStatsusCode(200) : APIGatewayStatsusCode(400), res: response }
};

export const APIGatewayPostRequest = async (fetchURL, headers) => {
  let Status, res;
  if (headers?.["headers"]?.["authorizationtoken"] != undefined && headers?.["headers"]?.["authorizationtoken"] != localStorage?.[localStorage?.["AccessTokenKey"]] && localStorage?.[localStorage?.["AccessTokenKey"]] != undefined) {
    headers = { ...headers, ["headers"]: { ...headers?.["headers"], authorizationtoken: localStorage?.[localStorage?.["AccessTokenKey"]] } };
  }
  await fetch(fetchURL, headers)
    .then((response) => {
      {
        Status = response.status == 200 ? "Success" : APIGatewayStatsusCode(response.status);
        res = response;
      }
    })
    .catch((e) => {
      Status == 400;
    });
  return { Status: (Status == "Success" || Status == undefined) ? APIGatewayStatsusCode(200) : APIGatewayStatsusCode(400), res: res }
};

export const APIGatewayPutRequest = async (fetchURL, headers, presignedHeader) => {
  let Status, UploadURL;
  await fetch(fetchURL, headers)
    .then(async (response) => response.text())
    .then(async (presignedUrl) => {
      await fetch(presignedUrl, presignedHeader).then((uploadResponse) => {
        UploadURL = uploadResponse.status == 200 ? uploadResponse.url.split("?")[0] : APIGatewayStatsusCode(uploadResponse.status);
        Status = uploadResponse.status == 200 ? "Success" : "Error";
      });
    })
    .catch((e) => {
      Status == 400;
    });
  return [Status == "Error" ? Status : "Success", UploadURL];
};

export const APIGatewayDeleteRequest = async (method, fetchURL, headers, response, presignedHeader) => { };





