#!/bin/bash
set -e
IFS='|'

REACTCONFIG="{\
\"SourceDir\":\"src\",\
\"DistributionDir\":\"build\",\
\"BuildCommand\":\"npm run-script build\",\
\"StartCommand\":\"npm run-script start\"\
}"
AWSCLOUDFORMATIONCONFIG="{\
\"configLevel\":\"project\",\
\"useProfile\":false,\
\"profileName\":\"default\",\
\"accessKeyId\":\"AKIAREQQXOY7EKWMI5F3\",\
\"secretAccessKey\":\"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\",\
\"region\":\"ap-south-1\"\
}"
AMPLIFY="{\
\"projectName\":\"XLMS\",\
\"appId\":\"d4k1nmucaqmqn\",\
\"envName\":\"dev\",\
\"defaultEditor\":\"code\"\
}"
FRONTEND="{\
\"frontend\":\"javascript\",\
\"framework\":\"react\",\
\"config\":$REACTCONFIG\
}"
PROVIDERS="{\
\"awscloudformation\":$AWSCLOUDFORMATIONCONFIG\
}"
AUTHCONFIG="{\
\"userPoolId\": \"ap-south-1_g2M2jphVK\",\
\"webClientId\": \"2qhbd1obmka30480oqvfa5j9qq\",\
\"nativeClientId\": \"2qhbd1obmka30480oqvfa5j9qq\",\
}"

CATEGORIES="{\
\"auth\":$AUTHCONFIG\
}"

amplify pull --amplify $AMPLIFY --frontend $FRONTEND --providers $PROVIDERS --categories $CATEGORIES --yes

amplify pull --apiId z5uswrukqfg4blfpgeyrxvujsq --amplify $AMPLIFY --frontend $FRONTEND --providers $PROVIDERS --categories $CATEGORIES --yes

amplify codegen



