import CheckboxList from "@components/MultiTreeCheckBox/CheckboxList/CheckboxList";
import { updateItemStates } from "@components/MultiTreeCheckBox/Tree/updateItemStates";
import { useCallback, useEffect, useState } from "react";


function Tree({ items, setPageData }) {
    useEffect(() => {
        const defaultItemStates = items.map((i) => ({
            id: i.id,
            state: i.state,
            SK: i.SK
        }))
        setItemStates(defaultItemStates)
    }, [items])
    const [itemStates, setItemStates] = useState(() => {
        const defaultItemStates = items.map((i) => ({
            id: i.id,
            state: i.state,
            SK: i.SK
        }))
        return defaultItemStates;
    });

    const getStateForId = useCallback((id) => {
        return itemStates?.find((i) => i.id === id)?.state;
    }, [itemStates]);

    const clickHandler = useCallback((id) => {
        let updatestates = updateItemStates(itemStates, items, id);
        setItemStates(updatestates);
        setPageData((data) => {
            return { ...data, CustomFeatureList: updatestates }
        });
    }, [itemStates, items, setPageData]);

    return <CheckboxList items={items} onClick={clickHandler} getStateForId={getStateForId} />;
}

export default Tree;