import NVLButton from "@components/Controls/NVLButton";
import NVLLink from "@components/Controls/NVLLink";
import { data } from "autoprefixer";
import React, { useState } from "react";
import Checkbox from "../Checkbox/Checkbox";

function CheckboxList({ items, getStateForId, idsToRender = [], indentLevel = 0, onClick, mode }) {

    const [Hidden, setHidden] = useState({});
    const CheckboxState = { "UNCHECKED": false, "CHECKED": true };

    if (!idsToRender.length) {
        idsToRender = items.filter((i) => !i.parentId).map((i) => i.id);
    }

    const getChildNodes = (parentId) => {
        const nodeItems = items.filter((i) => i.parentId === parentId);
        if (!nodeItems.length) return null;
        return (
            <div className={`${mode == "Delete" ? "pointer-events-none" : ""}`}>
                <CheckboxList
                    items={items}
                    idsToRender={nodeItems.map((i) => i.id)}
                    indentLevel={indentLevel + 1}
                    onClick={onClick}
                    getStateForId={getStateForId}
                /></div>
        );
    };

    return (
        <ul className={"list-none p-0 m-0"} style={{ paddingLeft: indentLevel * 30 }}>
            {idsToRender.map((id) => {
                const item = items.find((i) => i.id === id);
                const checkboxState = getStateForId(id);
                const Child = getChildNodes(item.id);
                if (Child != null && Hidden?.[item.id] == undefined) {
                    setHidden((data) => {
                        return { ...data, [item.id]: true }
                    })
                }
                return (
                    <React.Fragment key={item.id}>
                        <li className="text-gray-600 text-sm">
                            <div className="flex">
                                <NVLLink classNameLink={`pr-1 ${Child != null ? "" : "invisible"}`} text={""} className={`h-full arrow ${Hidden?.[item.id] ? "arrowright" : "arrowdown"}`}
                                    onClick={() => {
                                        setHidden((data) => {
                                            return { ...data, [item.id]: !(data?.[item.id] != undefined ? data?.[item.id] : false) }
                                        })
                                    }}

                                />
                                <div className={`${mode == "Delete" ? "pointer-events-none" : ""}`}>
                                    <Checkbox
                                        onClick={() => onClick(item.id)}
                                        isChecked={checkboxState === CheckboxState.CHECKED}
                                        isIndeterminate={checkboxState === CheckboxState.INDETERMINATE}
                                    />
                                    <span> {item.name}</span>
                                </div>
                            </div>
                        </li>

                        <div className={`${Hidden?.[item.id] ? "hidden" : ""}`}>
                            {Child != null && Child}
                        </div>
                    </React.Fragment>
                );
            })}
        </ul>
    );

}
export default CheckboxList;
