export const GetDateFormat = (date, Format) => {
  let DateString;
  switch (Format) {
    case "dd/mm/yyyy":
      DateString = new Date(date).toLocaleString().slice(0, 10);
      break;
    case "dd-mm-yyyy":
      date = new Date(date);
      var year = date.toLocaleString("default", { year: "numeric" });
      var month = date.toLocaleString("default", { month: "2-digit" });
      var day = date.toLocaleString("default", { day: "2-digit" });
      var formattedDate = day + "-" + month + "-" + year;
      DateString = formattedDate;

      break;
    case "yyyy/mm/dd":
      DateString = new Date(date).toISOString().slice(0, 10);
      break;
    case "yyyy-mm-dd":
      var dataFormat = new Date(date);
      let dateTimeString = dataFormat.getFullYear() + "-" + (dataFormat.getMonth() < 9 ? "0" : "") + (dataFormat.getMonth() + 1) + "-" + (dataFormat.getDate() < 10 ? ("0" + dataFormat.getDate()) : dataFormat.getDate());
      DateString = dateTimeString;
      break;
     
      case "±YYYYYY-MM-DDTHH:mm:ss":
      DateString = new Date(date);
      break;
      case "day mm dd yyy":
        DateString = new Date(date).toDateString();
        break;
    default:
      DateString = "No Date found";
  }
  return DateString;
};
