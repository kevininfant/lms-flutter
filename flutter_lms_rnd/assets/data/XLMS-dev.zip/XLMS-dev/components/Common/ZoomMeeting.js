import { APIGatewayPostRequest } from "DBConnection/ErrorResponse";

//JWT Token
export const generateToken = ({ api_key: api_key, api_secret: api_secret, expiry: expiry }) => {
    let CryptoJS = require("crypto-js");

    let header = CryptoJS.enc.Base64url.stringify(CryptoJS.enc.Utf8.parse('{"alg":"HS256","typ":"JWT"}'));
    let payload = CryptoJS.enc.Base64url.stringify(CryptoJS.enc.Utf8.parse('{"exp":' + expiry + ',"iss":"' + api_key + '"}'));
    let signature = CryptoJS.enc.Base64url.stringify(CryptoJS?.HmacSHA256(header + "." + payload, api_secret));

    header = header.replace(/\+/g, '-').replace(/\//g, '_').replace(/\=+$/, '')
    payload = payload.replace(/\+/g, '-').replace(/\//g, '_').replace(/\=+$/, '')
    signature = signature.replace(/\+/g, '-').replace(/\//g, '_').replace(/\=+$/, '')

    return header + "." + payload + "." + signature;
};

//Create Zoom Meeting
export const createMeeting = async ({ token: token, meetingDetails: meetingDetails, meetingID: meetingID, mode: mode }) => {

    let FinalResponse;

    const headers = {
        meetingid: meetingID ? meetingID : "",
        zoomtoken: `Bearer ${token}`,
        'content-type': 'application/json',
        mode: mode
    };

    let response;
    try {
        response = await APIGatewayPostRequest(process.env.APIGATEWAY_ZOOM_CREATION,
            {
                method: 'POST',
                headers: headers,
                body: JSON.stringify(meetingDetails),
            }
        );

        FinalResponse = await response?.res?.json();

    } catch (error) {
        console.log("Err", error);
    }
    return FinalResponse
}

//Join Meeting

export const joinMeeting = ({ meetingInfo: meetingInfo }) => {
    let ZoomMtg = require("@zoomus/websdk");


    ZoomMtg.init({
        leaveUrl: meetingInfo?.leaveURL,
        isSupportAV: true,
        success: function (e) {
            ZoomMtg.join({
                meetingNumber: meetingInfo?.meetingNumber,
                userName: meetingInfo?.userName,
                password: meetingInfo?.password,
                error: function (res) {
                    console.log("er", res);
                },
            });
        },
    });
};