import Head from "next/head";
import { useState } from "react";
import NVLLoadingIndicator from "@components/Controls/NVLLoadingIndicator";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";


export default function Container(props) {
  return (
    <>
      <Head>
        <title>{props.title}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>
      </Head>
      {(!props.loader) &&
        <>
          {props.PageRoutes != undefined && <NVLBreadCrumbs Routes={props.PageRoutes != undefined ? props.PageRoutes : []}></NVLBreadCrumbs>}
          {props.children}
        </>}
      {props.loader && <>
        <NVLLoadingIndicator IsLoad={true} AlignLoader={"center"} />
      </>}
    </>
  );
}
