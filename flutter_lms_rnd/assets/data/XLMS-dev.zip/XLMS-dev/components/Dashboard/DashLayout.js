import DashContext from "@Dashboard/DashContext";
import DashFooter from "@Dashboard/DashFooter";
import DashHeader from "@Dashboard/DashHeader";
import DashSideBar from "@Dashboard/DashSideBar";
import { createContext, useCallback, useContext, useState } from "react";

function DashLayout(props) {
  const value = useContext(DashContext);
  const [isOpened, setOpened] = useState(value.isOpen);
  const [isCollapse, setCollapse] = useState(value.isCollapsed);
  const toggleDrawer = useCallback(() => {
    setCollapse((data) => {
      let temp = data;
      let z = Object.keys(temp);
      for (let i = 0; i < z.length; i++) {
        temp = { ...temp, [z[i]]: false }
      }
      setOpened((isOpened) => {
        DashContext = createContext({ isOpen: !isOpened, isCollapsed: temp, oldCollapsed: data });
        return !isOpened;
      })
      return temp;
    })
  }, []);
 
  return (
    <div className="Container h-screen overflow-y-hidden font-Montserrat">
      <DashHeader ReduceNewDataFunction={props.ReduceNewDataFunction} TenantInfo={props.TenantInfo} NotificationPK={props.NotificationPK} LogoPath={props.TenantLogo} UserProfilePath={props.UserProfile} isOpened={isOpened} toggleDrawer={toggleDrawer} isCollapsed={isCollapse} signOut={props.signOut } userName={props.user.username} user={props.user} />
      <div className="Content overflow-y-auto">
        <DashSideBar TenantInfo={props.TenantInfo} Menu={props.Menu} value={value} isOpened={isOpened} isCollapse={isCollapse} setCollapse={setCollapse} user={props.user} />
        <div className="overflow-y-auto w-full px-2 xl:px-2 h-full sticky bg-th-body-bg-color">{props.children} </div>
      </div>
      <DashFooter />
    </div>
  );
}
export default DashLayout;
