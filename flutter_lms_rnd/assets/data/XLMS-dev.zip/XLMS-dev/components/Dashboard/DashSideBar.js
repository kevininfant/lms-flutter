import MenuItemsList from "@Dashboard/DashMenuItemlist";
import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";

function DashSidebar(props) {
  const [OptionData, setOptionData] = useState([]);
  const router = useRouter();
  const ProcessMenu = useCallback((MenuArray) => {
    let str = router.asPath.toString();
    let RouterArr = str.split("/");
    let isCollapse = {};
    MenuArray.sort(GetSortOrder("SerialNo"));
    function GetSortOrder(prop) {
      return function (a, b) {
        if (a[prop] > b[prop]) {
          return 1;
        } else if (a[prop] < b[prop]) {
          return -1;
        }
        return 0;
      };
    }
    let parentArr = [];
    let menuNameTemp = [];
    let inc = 0;
    const MenuOption = [{ id: inc, name: "Dashboard", icon: "fa fa-brands fa-windows", type: "Parent", url: props.TenantInfo.UserGroup == "SiteAdmin" ? "/Home/SiteAdminDashboard" : props.TenantInfo.UserGroup == "CompanyAdmin" ? "/Home/CompanyAdminDashboard" : "/Home/UserDashboard", },];
    let i = 0, j = 0;
    for (i = 0; i <= MenuArray.length - 1; i++) {
      let ParentName = MenuArray[i].ParentMenuName;
      isCollapse = { ...isCollapse, [ParentName]: false }
      if (!parentArr.includes(ParentName)) {
        let subItems = [];
        for (j = 0; j <= MenuArray.length - 1; j++) {
          inc = inc + 1;
          if (ParentName == MenuArray[j].ParentMenuName && ParentName != MenuArray[j].GroupMenuName) {
            subItems.push({ id: inc, name: MenuArray[j].GroupMenuName, icon: MenuArray[j].GroupMenuLogo, type: "Child", url: MenuArray[j].ActionURL });
            menuNameTemp.push(MenuArray[j].GroupMenuName.replace(/\s/g, ""));
          }
        }
        parentArr.push(ParentName);
        if (MenuArray[i].ParentMenuName != undefined)
          menuNameTemp.push(MenuArray[i].ParentMenuName.replace(/\s/g, ""));
        MenuOption.push({ id: inc, name: MenuArray[i].ParentMenuName, icon: MenuArray[i].ParentMenuLogo, type: "Parent", url: MenuArray[i].ActionURL, subItems, });
      }
    }
    menuNameTemp.push("PlanProcessor");
    isCollapse = { ...isCollapse, Home: false }
    menuNameTemp.push("Home");
    if (menuNameTemp.length > 2 && !menuNameTemp.includes(RouterArr[1]) && RouterArr[1] != "" && !(props.TenantInfo.UserGroup == "CompanyAdmin" && router.asPath.toString().includes("/CompanyManagement/CompanyDetails?TenantID=" + props.TenantInfo.TenantID))) {
      router.push(MenuOption[0].url);
    }
    setOptionData(MenuOption);
    if (props.isCollapse?.Home == undefined)
      props.setCollapse(isCollapse)
  }, [router, props]);
  useEffect(() => {
    ProcessMenu(props.Menu);
  }, [props.user, ProcessMenu, props.Menu]);

  function makeMenuLevel(options, depth = 0) {
    return options.map((option, idx) => ({
      ...option,
      id: depth === 0 ? idx.toString() : `${depth}.${idx}`,
      depth,
      subItems: option.subItems && option.subItems.length > 0 ? makeMenuLevel(option.subItems, depth + 1) : undefined,
    }));
  }
  return (
    <div className={props.isOpened ? "nvl-sidebarcontainer nowrap md:w-80  border-r pt-4" : "nvl-sidebarcontainer w-12 md:80 nowrap border-r pt-4"}>
      <MenuItemsList options={makeMenuLevel(OptionData)} setCollapse={props.setCollapse} isOpened={props.isOpened} isCollapse={props.isCollapse} value={props.value} user={props.user} TenantInfo={props.TenantInfo} />
    </div>
  );
}

export default DashSidebar;
