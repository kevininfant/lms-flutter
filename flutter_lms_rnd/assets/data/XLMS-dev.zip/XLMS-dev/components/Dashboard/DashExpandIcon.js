import { MdExpandLess, MdExpandMore } from "react-icons/md";

export default function ExpandIcon({ isExpanded, handleClick, IconId }) {
  return isExpanded ? <MdExpandLess id={IconId+"ExpandIcon"} onClick={handleClick} /> : <MdExpandMore id={IconId+"ExpandIcon"}  onClick={handleClick} />;
}
