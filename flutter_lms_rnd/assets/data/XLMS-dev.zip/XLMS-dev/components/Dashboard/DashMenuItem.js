import DashContext from "@Dashboard/DashContext";
import DashExpandIcon from "@Dashboard/DashExpandIcon";
import DashMenuItemlist from "@Dashboard/DashMenuItemlist";
import { Menu, Transition } from "@headlessui/react";
import { useRouter } from "next/router";
import { createContext, Fragment, useContext } from "react";
import { useTranslation } from "react-i18next";

export default function DashMenuItem({ menuItem: { name, type, icon, url, depth, subItems, id }, parent, TenantInfo, isCollapse, isOpened, value, index, setCollapse }) {
  const { t } = useTranslation();
  let RouterArr = [];
  let UrlArr = [];
  const router = useRouter();
  const DashContent = useContext(DashContext);
  let str = router.asPath.toString();
  RouterArr = str.split("/");
  str = url != undefined ? url.toString() : "";
  UrlArr = str.split("/");
  let selected = RouterArr[1] === UrlArr[1];
  if (RouterArr[1] == "" && UrlArr[1] == "Home") {
    selected = true;
  }
  const isNested = subItems && subItems?.length > 0;
  const onClick = (name) => {
    let isExpand = isCollapse;
    isExpand = { ...isExpand, [name]: !isExpand?.[name] }
    setCollapse(isExpand)
    DashContext = createContext({ isOpen: isOpened, isCollapsed: isExpand, oldCollapsed: DashContent.oldCollapsed });
  };

  const HandlePopup = (url, name, isNested) => {
    isNested != true && router.push(url);
    return isNested ? onClick(name) : " ";
  };
  return (
    <>
      <section className={`hidden md:block ${isNested ? "nvl-dash-Side-bar" : ""} ${TenantInfo?.UserGroup && TenantInfo.UserGroup == "CompanyAdmin" && TenantInfo.FirstTimeLogin ? `${name == "Plan Processor" ? "nvl-selected" : "text-red-600 cursor-not-allowed pointer-events-none"}` : ""}`}>
        <Menu as="div" id="Menus" className={selected ? "nvl-dash-Side-bar-Selected !bg-blue-50" : " nvl-dash-Side-Menu"} depth={depth}>
          <Menu.Button>
            <div className="flex has-tooltip">
              <div className={"flex gap-x-4 w-52 px-4"} onClick={() => isOpened == true ? (HandlePopup(url, name, isNested)) : (HandlePopup(url))}>
                <div className={`h-2 w-2 pr-4 pt-0.5  ${selected ? "text-primary" : "hover:text-blue-600 text-th-sidebar-icon-color "}`}>
                  <i className={`fa ${icon} fa-thin fa-book-open text-sm `}></i>
                </div>
                <span className={`text-xs font-medium h-full relative top-1.5  ${type == "Parent" ? "p-0" : "pl-4"} ${selected ? "hover:text-[#F47A22] text-[#F47A22]" : "hover:text-blue-600 text-th-sidebar-txt-color"}`}>{t(name)}</span>
                {!isOpened && <span className='translate-x-8 tooltip rounded text-sm px-2 py-1 bg-black text-white pointer-events-none cursor-not-allowed'>{name}</span>}
              </div>
              <div className="lg:px-4 pt-2 text-[#374151]">{isNested ? <DashExpandIcon IconId={id} isExpanded={isCollapse?.[name]} handleClick={() => onClick(name)} /> : null}</div>
            </div>
          </Menu.Button>
          {isNested && (isCollapse?.[parent] || isCollapse?.[name]) ? (
            <Transition show={!value.isOpen && isCollapse?.[parent]} as={Fragment} id="SubMenus" enter="transition ease-out duration-100" enterFrom="transform opacity-0 scale-95" enterTo="transform opacity-100 scale-100" leave="transition ease-in duration-75" leaveFrom="transform opacity-100 scale-100" leaveTo="transform opacity-0 scale-95">
              <Menu.Items className="origin-top-right left-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 divide-y divide-gray-100 focus:outline-none">
                <Menu.Item>
                  <div className="bg-gray-100 text-gray-900 px-1 text-sm" onClick={() => HandlePopup(url)}>
                    {isNested && (isCollapse?.[parent] || isCollapse?.[name]) ? <DashMenuItemlist options={subItems} parent={name} isOpened={[]} isCollapse={isCollapse} value={value} /> : null}
                  </div>
                </Menu.Item>
              </Menu.Items>
            </Transition>
          ) : null}
        </Menu>
        <div className="pl-6">{(isCollapse?.[parent] || isCollapse?.[name]) && isNested ? <DashMenuItemlist options={subItems} parent={name} isOpened={[]} isCollapse={isCollapse} value={value} /> : null}</div>
      </section>

      {/* MobileMenu */}
      <section>
        <Menu as="div" className={`p-3 md:hidden ${TenantInfo?.UserGroup && TenantInfo.UserGroup == "CompanyAdmin" && TenantInfo.FirstTimeLogin ? `${name == "Plan Processor" ? "" : "text-red-600 cursor-not-allowed pointer-events-none"}` : ""}`} depth={depth}>
          <div>
            <Menu.Button className="block md:hidden">
              <div className="flex gap-x-2" onClick={() => router.push(url)}>
                <i className={`fa ${icon} text-lg`}></i>
                <span>{type == "Child" && name}</span>
              </div>
            </Menu.Button>
          </div>

          {isNested && isCollapse?.[parent] ? (
            <Transition as={Fragment} id="SubMenus" enter="transition ease-out duration-100" enterFrom="transform opacity-0 scale-95" enterTo="transform opacity-100 scale-100" leave="transition ease-in duration-75" leaveFrom="transform opacity-100 scale-100" leaveTo="transform opacity-0 scale-95">
              <Menu.Items className="origin-top-right absolute left-2 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 divide-y divide-gray-100 focus:outline-none">
                <div className="py-1">
                  <Menu.Item>
                    <div className="bg-gray-100 text-gray-900 px-1 py-2 text-sm flex gap-x-1" title={name} onClick={() => router.push(url)}>
                      {isNested ? <DashMenuItemlist options={subItems} /> : null}
                    </div>
                  </Menu.Item>
                </div>
              </Menu.Items>
            </Transition>
          ) : null}
        </Menu>
      </section>
    </>
  );
}
