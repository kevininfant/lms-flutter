export default function Footer() {
  return <div className="nvl-footercontainer text-white font-sans text-sm">Novac Technology Solutions &copy; All Rights Reserved</div>;
}
