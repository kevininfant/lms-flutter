import { createContext } from "react";

const DashContext = createContext({ isOpen: !false,isCollapsed: {},oldCollapsed:{}  });

export default DashContext;
