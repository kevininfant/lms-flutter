import DashMenuItem from "@Dashboard/DashMenuItem";

export default function DashMenuItemsList(props) {

  return <div className="nvl-listcontainer">{
    props.options && props.options.map((option) => 
      <DashMenuItem
        menuItem={option} key={option.id} user={props.user}
        parent={props.parent}
        TenantInfo={props.TenantInfo}
        setCollapse={props.setCollapse}
        isCollapse={props.isCollapse}
        isOpened={props.isOpened} value={props.value} />
    )

  }</div>;
}
