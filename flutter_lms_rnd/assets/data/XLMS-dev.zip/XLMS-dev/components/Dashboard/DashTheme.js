import { useEffect, useState } from "react";
import { useTheme } from "next-themes";

const Themes = [{ name: "Light" }];

const DashTheme = () => {
  const [mounted, setMounted] = useState(false);
  const { theme, setTheme } = useTheme();
  useEffect(() => setMounted(true), []);

  if (!mounted) return null;

  return (
    <>
      {Themes.length > 0 &&
        Themes.map((getItem, index) => (
          <div className="px-3 py-1" key={index}>
            <input name="theme" id="theme-select" type="radio" radioGroup="theme" className="pl-2" onClick={(e) => setTheme(e.currentTarget.value)} key={getItem.name.toLowerCase()} value={getItem.name.toLowerCase()} >{getItem.name}</input>
            <label className="px-3">{getItem.name}</label>
          </div>
        ))}
    </>
  );
};

export default DashTheme;
