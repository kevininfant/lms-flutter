import NVLButton from '@components/Controls/NVLButton';
import NVLImage from '@components/Controls/NVLImage';
import NVLNotificationAlert from '@components/Controls/NVLNotificationAlert';
import NVLPassword from "@components/Controls/NVLPassword";
import NVLProfileSelect from '@components/Controls/NVLProfileSelect';
import NVLSelectField from '@components/Controls/NVLSelectField';
import DashContext from "@Dashboard/DashContext";
import { yupResolver } from "@hookform/resolvers/yup";
import image from "@Public/Axle.png";
import { API, Auth } from 'aws-amplify';
import { APIGatewayGetRequest, AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import router from 'next/router';
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useForm } from "react-hook-form";
import { FaChevronLeft, FaListUl } from 'react-icons/fa';
import { deleteXlmsLoginLiveUserInfo, updateXlmsInAppNotification } from "src/graphql/mutations";
import { listXlmsInAppNotification } from 'src/graphql/queries';
import { onCreateXlmsInAppNotification, onUpdateXlmsInAppNotification } from 'src/graphql/subscriptions';
import * as Yup from "yup";

export default function DashHeader({ toggleDrawer, subscription, setsubscription, signOut, user, isOpen, NotificationPK, LogoPath, TenantInfo, UserProfilePath, ReduceNewDataFunction, isOpened }) {

  const [lblMessage, setlblMessage] = useState({ Message: "", MessageType: "" })
  const [profile, setprofile] = useState(false)
  const [newData, setnewData] = useState({ data: [], count: 0 })
  const DashContent = useContext(DashContext);

  const validationSchema = Yup.object().shape({
    ddlApproval: Yup.string().test("", "", (e) => {
      if (e == "CourseApproval") {
        router.push("/Home/CourseApproval")
      } else if (e == "TrainingApproval") {
        router.push("/Home/TrainingApproval")
      } else if (e == "Select") {
        router.push("/Home/UserDashboard")
      }
    }),
    txtpassword: Yup.string()
      .required("Current password is required")
      .max(100, "Maximum length exceeded")
      .test("Password", "", (e, ctx) => {
        if (watch("txtpassword") == watch("txtnewpassword")) {
          return ctx.createError({
            message: "Current and New Password Should be Different",
          });
        } else { return true; }
      }),
    txtnewpassword: Yup.string()
      .required("New password is required")
      .max(100, "Maximum length exceeded")
      .test("Password", "", (e, ctx) => validatePassword(e, ctx)),
    txtCnfrmpassword: Yup.string()
      .required("Confirm password is required")
      .max(100, "Maximum length exceeded")
      .test("Password", "", (e, ctx) => {
        if (watch("txtnewpassword") == watch("txtCnfrmpassword")) {
          return true;
        } else {
          return ctx.createError({ message: "Both Password Should be Same" });
        }
      }),
  });
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true };
  const { register, handleSubmit, reset, setValue, watch, formState } = useForm(formOptions);
  const { errors } = formState;

  const SignoutHandler = useCallback(() => {
    async function GetLiveUserData(e, index) {
      const DeleteUserResponse = await AppsyncDBconnection(deleteXlmsLoginLiveUserInfo, { input: [{ PK: "XLMS#LIVEUSER", SK: "TENANT#" + user?.attributes["custom:tenantid"] + "#USERSUB#" + user?.attributes["sub"], },] }, user?.signInUserSession?.accessToken?.jwtToken);
    }
    GetLiveUserData()
    router.push("/");
    DashContext = createContext({ isOpen: true, isCollapsed: true, oldCollapsed: DashContent.oldCollapsed });

    signOut();
  }, [DashContent.oldCollapsed, signOut, user?.attributes, user?.signInUserSession?.accessToken?.jwtToken]);

  const validatePassword = (password, ctx) => {
    let i = 0,
      message = "Password Should Have ";
    if (!password.match(/\d+/g)) {
      i++;
      message = message + "A Number";
    }
    if (!password.match(/[A-Z]+/g)) {
      i++;
      if (i > 1) {
        message = message + ", ";
      }
      message = message + "A Captial Letter";
    }
    if (!password.match(/[a-z]+/g)) {
      i++;
      if (i > 1) {
        message = message + ", ";
      }
      message = message + "A Small Letter";
    }
    if (!password.match(/[\W_]+/g)) {
      i++;
      if (i > 1) {
        message = message + ", ";
      }
      message = message + "A Special Character";
    }

    if (password.length < 6) {
      i++;
      if (i > 1) {
        message = message + ", ";
      }
      message = message + "Minimun Of Length 6";
    }
    if (i > 0) {
      return ctx.createError({ message: message });
    }
    return true;
  };

  const refreshData = useCallback(async () => {
    let newArray = [];
    if (NotificationPK != undefined) {
      const Response = await AppsyncDBconnection(listXlmsInAppNotification, { PK: NotificationPK, SK: 'PUSHEVENT#', }, user.signInUserSession.accessToken.jwtToken)
      const element = Response?.res?.listXlmsInAppNotification?.items
      let uniqueValues = 0;
      if (element?.length != undefined && element?.length > 0) {
        uniqueValues = element.filter(function (value) { return value.IsViewState === true }).length
      }
      let count = element?.length;
      if (count > 5) {
        count = 5;
      }
      if (element?.length >= 0) {
        let append = 5;
        for (let i = element?.length - 1; i >= 0; i--) {
          newArray.push({ PK: element[i]?.PK, SK: element[i]?.SK, Message: element[i]?.Message, Subject: element[i]?.Subject, CreatedDate: element[i]?.CreatedDate, IsViewState: element[i]?.IsViewState, });
          append--;
          if (append == 0) {
            break;
          }
        }
      }
      let a = { data: newArray, count: uniqueValues };
      if (newArray.length >= 0) {
        setnewData(a);
      }
    }
    return () => {
      setnewData((data) => data);
    };
  }, [NotificationPK, user]);

  useEffect(() => {
    const ReduceNewData = () => {
      setnewData((data) => {
        return { ...data, count: data.count - 1 }
      })
    }
    ReduceNewDataFunction(ReduceNewData);
  }, [ReduceNewDataFunction])


  useEffect(() => {
    refreshData();
  }, [refreshData]);

  useEffect(() => {
    if (subscription) {
      const subscription = API.graphql({
        query: onUpdateXlmsInAppNotification,
        variables: {
          PK: NotificationPK,
        },
        authMode: "AWS_LAMBDA",
        authToken: user.signInUserSession.accessToken.jwtToken
      }, { "Authorization": user.signInUserSession.accessToken.jwtToken }).subscribe({
        next: (result) => {
          let isUpdate = false;
          let UpdateData = result.value.data.onUpdateXlmsInAppNotification
          if (UpdateData != null || UpdateData != '') {
            refreshData();
          }
        }
      })
      setsubscription(() => {

      })
    }
  }, [NotificationPK, refreshData, setsubscription, subscription, user.signInUserSession.accessToken.jwtToken])

  useEffect(() => {
    const subscription = API.graphql({
      query: onCreateXlmsInAppNotification,
      variables: {
        PK: NotificationPK,
      },
      authMode: "AWS_LAMBDA",
      authToken: user.signInUserSession.accessToken.jwtToken
    }, { "Authorization": user.signInUserSession.accessToken.jwtToken }).subscribe({
      next: (result) => {
        let CreateData = result.value.data.onCreateXlmsInAppNotification
        if (CreateData != null || CreateData != '') {
          refreshData()
        }
      }
    })
  }, [NotificationPK, refreshData, user.signInUserSession.accessToken.jwtToken])

  async function updateReadValues(PKid, SKid) {
    await AppsyncDBconnection(updateXlmsInAppNotification, {
      input: { PK: PKid, SK: SKid, IsViewState: false },
    }, user.signInUserSession.accessToken.jwtToken).then((res) => {
      router.push(`/Home/NotiFication?${("modetype=get&PKid=" + encodeURIComponent(PKid) + "&SKid=" + encodeURIComponent(SKid))}`)
    })
      .catch((e) => {
        return
      })
  }
  const submitHandler = async (data) => {
    Auth.changePassword(user, data.txtpassword, data.txtnewpassword)
      .then(async () => {
        reset({ txtpassword: "", txtnewpassword: "", txtCnfrmpassword: "" });
        setlblMessage({
          Message: "Password has been changed successfully",
          MessageType: "Success",
        });
        setTimeout(() => {
          signOut();
        }, 3000);
        let groupmenuname = TenantInfo.UserGroup == "CompanyAdmin" ? "CompanyManagement" : "UserManagement";
        let menuid = TenantInfo.UserGroup == "CompanyAdmin" ? "100504" : "200004";
        const headers = {
          method: "GET",
          headers: {
            authorizationtoken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
            menuid: menuid,
            groupmenuname: groupmenuname,
            defaultrole: TenantInfo.UserGroup,
          },
        };
        let FinalStatus = await APIGatewayGetRequest(`${process.env.APIGATEWAY_CHANGEPASSWORD_NOTIFICATION}?UserSub=${user.attributes.sub}&TenantID=${TenantInfo.TenantID}&IsUser=${TenantInfo.UserGroup != "CompanyAdmin" ? "true" : "false"}`, headers);
        setTimeout(() => {
          resetpassword();
        }, 3000);
      })
      .catch(({ message }) => {
        reset({ txtpassword: "", txtnewpassword: "", txtCnfrmpassword: "" });
        setlblMessage({
          Message: message != "Incorrect username or password." ? message : "Incorrect password",
          MessageType: "Error",
        });
      });
  };
  const resetpassword = () => {
    reset({ txtpassword: "", txtnewpassword: "", txtCnfrmpassword: "" });
    setprofile((profile) => {
      return !profile;
    });
    setlblMessage({ Message: "", MessageType: "" });
  };
  const approvalList = useMemo(() => {
    return (
      [{ value: "Select", text: "Select Approval" },
      { value: "CourseApproval", text: "Course Approval" },
      { value: "TrainingApproval", text: "Training Approval" }])
  }, []);
  return (
    <>
      <section>
        <div className="nvl-Dash-header  !border-b">
          <div className="nvl-Dash-menu-icon" onClick={toggleDrawer}>
            {isOpen ? (<FaChevronLeft className="outline-none " tabIndex={1} />) : (<FaListUl className="outline-none text-gray-600" tabIndex={1} />)}
          </div>
          <div className="nvl-Dash-headeritems ">
            <NVLImage alt="novac" tabIndex={2} onClick={() => router.push("/")} src={LogoPath != undefined ? LogoPath : image.src} height={30} className="nvl-Dash-logo pointer-events-none" title="Novac Logo" />
            {/* <div className="nvl-Dash-header-ser-items hidden"  visibility="hidden">
              <input  className="nvl-Dash-input" type="search" name="search" placeholder="Search" />
              <button type="submit" className="absolute right-2 top-2">
                <i className="fa-solid fa-magnifying-glass h-4 w-4 relative bottom-0.5"></i>
              </button>
            </div> */}
          </div>
          <div className="nvl-Dash-lang border-none">
            <div className={`${user.attributes["custom:groupname"] != "Manager" ? "hidden" : ""}`}>
              <NVLButton text="MyTeam" className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-100" onClick={() => router.push(`/Home/UserTeam?EmailId=${user.attributes["email"]}&UserName=${user.attributes["name"]}&TenantId=${TenantInfo?.TenantID}`)} />
            </div>
            <div className={`${user.attributes["custom:groupname"] != "Manager" ? "hidden" : "pb-3"}`}>
              <NVLSelectField id="ddlApproval" errors={errors} register={register} options={approvalList} className={`w-48 md:w-44 `} />
            </div>
            <div className={`${user.attributes["custom:groupname"] != "CompanyAdmin" ? "hidden" : "pt-2 "}`}>
              <NVLButton text="Calendar" className="inline-flex justify-center rounded-md border border-gray-300 bg-white px-4 h-8 pt-1 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-100" onClick={() => router.push("/Home/AdminViewEventCalendar")} />
            </div>
            {/* <NVLLanaguageSelect /> */}
            <span title={user.attributes["custom:groupname"] == "CompanyAdmin" ? TenantInfo.TenantName : UserProfilePath?.Name} className="text-xs font-semibold grid content-center my-2 uppercase rounded text-blue-700 last:mr-0">
              {UserProfilePath?.Name == undefined ?
                TenantInfo.TenantName?.length > 30 ?
                  TenantInfo.TenantName?.substring(0, 30) + "..." : TenantInfo.TenantName :
                (UserProfilePath?.Name)?.length > 30 ?
                  (UserProfilePath?.Name)?.substring(0, 30) + "..." :
                  UserProfilePath?.Name
              }
            </span>
            <div className="nvl-DashHeader-Item py-3">
              <NVLNotificationAlert newData={newData} NotificationPK={NotificationPK} updateReadValues={updateReadValues} />
            </div>
            <NVLProfileSelect FirstName={UserProfilePath?.FirstName} LogOut={async () => SignoutHandler()} UserProfilePath={UserProfilePath?.PofileURL} ChangePassword={() => setprofile(!profile)} TenantInfo={TenantInfo} />
          </div>
          <div className={`relative z-10 ${profile == true ? "" : "hidden"}`} aria-labelledby="modal-title" role="dialog" aria-modal="true">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
            <div className="fixed inset-0 z-10 overflow-y-auto">
              <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
                  <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <div className="sm:flex sm:items-start">
                      <div className="nvl-FormContent">
                        <NVLPassword changeType={profile} title="Current Password" id="txtpassword" type="password" labelText="Current Password" FieldType="password" labelClassName="nvl-Def-Label" className=" nvl-mandatory nvl-Def-Input !pr-8" register={register} errors={errors}></NVLPassword>
                        <NVLPassword changeType={profile} title="New Password" id="txtnewpassword" type="password" labelText="New Password" FieldType="password" labelClassName="nvl-Def-Label" className=" nvl-mandatory nvl-Def-Input !pr-8" register={register} errors={errors}></NVLPassword>
                        <NVLPassword changeType={profile} title="Confirm Password" id="txtCnfrmpassword" type="password" labelText="Confirm Password" FieldType="password" labelClassName="nvl-Def-Label" className=" nvl-mandatory nvl-Def-Input !pr-8" register={register} errors={errors}></NVLPassword>
                      </div>
                    </div>
                  </div>
                  <div onClick={() => resetpassword()} className="absolute right-0 top-2 px-3" >
                    <i className="fa-solid fa-xmark"></i>
                  </div>
                  <div className={`${lblMessage.MessageType == "Success" ? "w-full text-center font-bold text-green-400 justify-center text-sm" : "w-full text-center font-bold text-red-400 justify-center text-sm"}`} id="lblCustomError">
                    <span>{lblMessage.Message}</span>
                  </div>
                  <div className=" justify-center py-4 flex gap-4 pt-4">
                    <NVLButton id="btnSubmit" text={"Submit"} type="submit" onClick={handleSubmit((data) => submitHandler(data))} className={"w-32 nvl-button bg-primary text-white "}></NVLButton>
                    <NVLButton id="btnCancel" text={"Cancel"} type="button" className="nvl-button w-28" onClick={() => resetpassword()}></NVLButton>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}