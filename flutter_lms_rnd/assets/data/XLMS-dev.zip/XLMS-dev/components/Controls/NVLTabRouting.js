import NVLButton from "./NVLButton";
import { Link } from "@aws-amplify/ui-react";


function NVLTabRouting(props) {
    let rendertab = {
        Link: <Link id={props.id} title={props.text} className={"  nvl-button-success inline-flex items-center justify-center !text-white focus:!text-white hover:text-white " + props.className} type={props.type} href={props.href} isExternal={props.isExternal} color={props.color} as={props.as} to={props.to} onClick={props.onClick}>{props.text?.length > 35 && props.showFull == undefined ? (props?.text?.substring(0, 30) + "...") : props.text}</Link>,
        Button: <NVLButton id={props.id} type={props.type} text={props.text} onClick={props.onClick} disabled={props.disabled} className={props.className} />,
    };
    let currentTab = props.TabRouting ? "Link" : "Button";
    return rendertab[currentTab];
}
export default NVLTabRouting;


