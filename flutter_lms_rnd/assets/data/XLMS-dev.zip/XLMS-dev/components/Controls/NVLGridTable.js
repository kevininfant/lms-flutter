import Container from "@components/Container/Container";
import NVLGridTableHeader from "@components/Controls/NVLGridTableHeader";
import NVLGridTableRows from "@components/Controls/NVLGridTableRows";
import NVLNoImage from "@components/Controls/NVLNoImage";
import Pagination from "@components/Controls/NVLPagination";
import NVLlabel from "@components/Controls/NVLlabel";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { API } from 'aws-amplify';
import { useCallback, useEffect, useRef, useState } from "react";
import NVLModalPopup from "./NVLModalPopup";


function NVLGridTable({ viewMoreAction, setPagezero, UpdateSubscription, UpdateSubscriptionName, SubscriptionVariable, CreateSubscription, CreateSubscriptionName, DonotLoad, Header, LoadInSinglePage, user, RowGridDataPass, color, pageChangeCall, GridDataBind, query, pageSize, querryName, variable, HeaderColumn, id, Search, className, refershPage, PaginationReq, SearchType, TotalCount, glossary, ShowContentAndReducePage, currentPageFront }) {
  const [RowGridData, setRowGridData] = useState({ RowGrid: [], nextToken: "", Data: [] });
  const [currentPage, setCurrentPage] = useState(currentPageFront != undefined ? currentPageFront : 0);
  const [currentTableData, setPageWiseData] = useState([]);
  const refershPageGrid = useRef({ RefershNo: refershPage, Refershing: false });
  const [Loading, setLoading] = useState(false);
  const setSubscription = useRef(null);
  const [PageSize, setPageSize] = useState(pageSize == undefined ? process.env.PAGEGRIDSIZE : pageSize);
  const [Content, setContent] = useState("");
  const prevSearch = useRef("");
  const getSearchData = useCallback((array, searchValue) => {
    // SearchType: WildcardLoop, Exact (Will search with only PK and SK. It won't loop.)
    let temp = [];
    array?.map((getItem) => {
      let keys = Object.keys(getItem);
      for (var i = 0; i < keys.length; i++) {
        try {
          if (getItem?.[keys[i]] != undefined && getItem?.[keys[i]]?.toLowerCase().indexOf(searchValue.toLowerCase()) != -1) {
            temp.push(getItem);
            return;
          }
        } catch (e) { }
      }
    });
    return temp;
  }, []);

  useEffect(() => {
    if (setSubscription.current == undefined) {
      if (CreateSubscription != undefined) {
        setSubscription.current = true;
        const subscription = API.graphql({ query: CreateSubscription, variables: SubscriptionVariable, authMode: "AWS_LAMBDA", authToken: user.signInUserSession.accessToken.jwtToken }, { Authorization: user.signInUserSession.accessToken.jwtToken }).subscribe({
          next: (result) => {
            let UpdateData = result.value.data?.[CreateSubscriptionName];
            if (UpdateData != null) {
              UpdateData = [UpdateData];
              setRowGridData((data) => {
                return { ...data, Data: [...UpdateData, ...data?.Data], RowGrid: [...GridDataBind(UpdateData), ...data?.RowGrid] };
              });
            }
          },
        });
      }
      if (UpdateSubscription != undefined) {
        setSubscription.current = true;
        const subscription = API.graphql({ query: UpdateSubscription, variables: SubscriptionVariable, authMode: "AWS_LAMBDA", authToken: user.signInUserSession.accessToken.jwtToken }, { Authorization: user.signInUserSession.accessToken.jwtToken }).subscribe({
          next: (result) => {
            let UpdateData = result.value.data?.[UpdateSubscriptionName];
            if (UpdateData != null) {
              UpdateData = [UpdateData];
              setRowGridData((data) => {
                let temp = data;
                for (let i = 0; i < temp.Data.length; i++) {
                  if (temp.Data[i].PK == UpdateData[0].PK && temp.Data[i].SK == UpdateData[0].SK) {
                    temp.Data.splice(i, 1);
                    temp.RowGrid.splice(i, 1);
                    break;
                  }
                }
                return { ...data, Data: [...UpdateData, ...temp?.Data], RowGrid: [...GridDataBind(UpdateData), ...temp?.RowGrid] };
              });
            }
          },
        });
      }
    }
  }, [CreateSubscription, GridDataBind, user?.signInUserSession?.accessToken?.jwtToken, CreateSubscriptionName, UpdateSubscription, UpdateSubscriptionName, SubscriptionVariable]);

  const getData = useCallback(
    async (array, nextToken, page, data, rowGrid) => {
      let arraytemp = [],
        response;
      setLoading(false);
      if (array.length < PageSize * (page + 1) && nextToken != null && nextToken != "") {
        response = await AppsyncDBconnection(query, { ...variable, limit: PageSize, nextToken: nextToken }, user.signInUserSession.accessToken.jwtToken);
        if (response.Status == "Success") {
          arraytemp = Search != undefined && Search != "" ? getSearchData(response.res?.[querryName].items, Search) : response.res?.[querryName].items;
          let z = [...data, ...arraytemp];
          z = z.filter((elem, ix) => z.findIndex((elem1) => elem1.PK == elem.PK && elem1.SK == elem.SK) === ix);

          let temp = {
            RowGrid: [...rowGrid, ...(await GridDataBind(arraytemp))],
            nextToken: response.res?.[querryName].nextToken,
            Data: [...z],
          };
          if (temp.RowGrid.length < PageSize * (page + 1) && temp.nextToken != null && nextToken != "") {
            getData(temp.RowGrid, temp.nextToken, page, temp.Data, temp.RowGrid);
          } else {
            setLoading(true);
            setRowGridData(temp);
          }
        }
      } else if (array.length == 0 && nextToken == "" && refershPage != 0) {
        response = await AppsyncDBconnection(query, { ...variable, limit: PageSize }, user?.signInUserSession.accessToken.jwtToken);
        if (response.Status == "Success") {
          let temparry = Search != undefined && Search != "" ? getSearchData(response.res?.[querryName]?.items, Search) : response.res?.[querryName]?.items;
          arraytemp = await GridDataBind(temparry);
          if (arraytemp?.length < PageSize * (page + 1) && response.res?.[querryName]?.nextToken != null) {
            getData(arraytemp, response.res?.[querryName]?.nextToken, page, temparry, arraytemp);
          } else {
            setLoading(true);
            setRowGridData((data) => {
              return {
                RowGrid: [...array, ...arraytemp],
                nextToken: response.res?.[querryName]?.nextToken,
                Data: [...temparry],
              };
            });
          }
        }
      } else if (array.length == 0 && nextToken == "") {
        response = await AppsyncDBconnection(query, { ...variable, limit: PageSize }, user.signInUserSession.accessToken.jwtToken);
        if (response.Status == "Success") {
          let temparry = Search != undefined && Search != "" ? getSearchData(response.res?.[querryName]?.items, Search) : response.res?.[querryName]?.items;
          arraytemp = await GridDataBind(temparry);
          if (arraytemp?.length < PageSize * (page + 1) && response.res?.[querryName]?.nextToken != null) {
            getData(arraytemp, response.res?.[querryName]?.nextToken, 0, temparry, arraytemp);
          } else {
            setLoading(true);
            setRowGridData((data) => {
              return {
                RowGrid: [...array, ...arraytemp],
                nextToken: response.res?.[querryName]?.nextToken,
                Data: [...temparry],
              };
            });
          }
        }
      }
      if (arraytemp.length == 0 && array.length > 0 && array.length == PageSize * page && response?.res?.[querryName]?.nextToken == null) {
        setCurrentPage((data) => {
          return data - 1;
        });
        setContent("There is no more record");
      } else if (nextToken == null && array?.length == 0) {
        setLoading(true);
      }
    },
    [GridDataBind, PageSize, Search, getSearchData, querryName, query, refershPage, variable, user]
  );

  const getDataWithoutNextToken = useCallback(async () => {
    setRowGridData({ RowGrid: RowGridDataPass.RowGrid, nextToken: null });
    setLoading(true);
  }, [RowGridDataPass]);

  useEffect(() => {
    if (variable != null && DonotLoad == undefined && !refershPageGrid.current.Refershing && refershPageGrid.current.RefershNo > 0) {
      setCurrentPage(0);
      getData([], "", 0, [], []);
    } else if (refershPageGrid.current.Refershing) {
      refershPageGrid.current = { ...refershPageGrid.current, Refershing: false };
    }
    prevSearch.current = Search;
  }, [variable, getData, DonotLoad, Search]);

  useEffect(() => {
    if (currentPage >= 0 && pageChangeCall != undefined) {
      pageChangeCall(currentPage);
    }
  }, [currentPage, pageChangeCall]);

  useEffect(() => {
    if (ShowContentAndReducePage != undefined && ShowContentAndReducePage != 0) {
      setCurrentPage((data) => {
        if (data > 0) {
          setContent("There is no more record");
          return data - 1;
        }
        else {
          return data;
        }
      });
    }
  }, [ShowContentAndReducePage]);

  useEffect(() => {
    if (setPagezero != undefined) {
      setCurrentPage(0);
    }
  }, [setPagezero]);

  useEffect(() => {
    if (RowGridData.RowGrid.length == 0 && RowGridDataPass == undefined) {
      getData(RowGridData.RowGrid, RowGridData.nextToken, 0, RowGridData.Data, RowGridData?.RowGrid);
    } else if (RowGridDataPass?.RowGrid?.length > 0) {
      getDataWithoutNextToken();
    } else if (RowGridDataPass?.RowGrid?.length == 0) {
      setLoading(true);
    }
  }, [getData, PageSize, RowGridData.RowGrid, RowGridData.nextToken, getDataWithoutNextToken, RowGridDataPass, RowGridData.Data]);

  useEffect(() => {
    if (refershPage != 0 && refershPage != undefined && refershPageGrid.current.RefershNo + 1 == refershPage) {
      setCurrentPage(0);
      getData([], "", 0, [], []);
      refershPageGrid.current = { RefershNo: refershPage, Refershing: true };
    }
  }, [refershPage, getData]);

  useEffect(() => {
    const firstPageIndex = currentPage * PageSize;
    const lastPageIndex = firstPageIndex + PageSize;
    if (LoadInSinglePage == undefined) setPageWiseData(RowGridData.RowGrid.slice(firstPageIndex, lastPageIndex));
    else {
      setPageWiseData(RowGridData.RowGrid);
    }
    return () => {
      setPageWiseData([]);
    };
  }, [currentPage, PageSize, RowGridData.RowGrid, LoadInSinglePage]);

  function nextValue(page) {
    if (RowGridData.RowGrid.length < (page + 1) * PageSize && RowGridData.nextToken != null) getData(RowGridData.RowGrid, RowGridData.nextToken, page, RowGridData.Data, RowGridData?.RowGrid);
    if (LoadInSinglePage == undefined) setPageWiseData(RowGridData.RowGrid.slice(page * PageSize, page * PageSize + PageSize));
    else {
      setPageWiseData(RowGridData.RowGrid);
    }
  }
  return (
    <>
      <Container loader={!Loading}>
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => setContent("")} CloseIconEvent={() => setContent("")} Content={Content} IsConfirmAlert={true} />
        {RowGridData?.RowGrid?.length != 0 && RowGridData.nextToken != "" ? (
          <section className="nvl-GridSec">
            <div className={"nvl-GridTable-Outer  " + (color === "light" ? "bg-white" : "bg-blueGray-700 text-gray-700")}>
              <table className={"nvl-GridTable-Inner  " + className} id={id} key={HeaderColumn}>
                {Header != "NoHeader" && <NVLGridTableHeader HeaderColumn={HeaderColumn} />}
                <NVLGridTableRows HeaderColumn={HeaderColumn} RowsData={currentTableData} glossary={glossary} />
              </table>
            </div>
            {(RowGridData?.RowGrid?.length > PageSize - 1 || RowGridData.nextToken != null) && LoadInSinglePage == undefined && (
              <div id="idPagenation" className={`pt-4 ${PaginationReq == "" ? "hidden" : ""}`}>
                <Pagination
                  className="nvl-pagination-bar"
                  currentPage={currentPage}
                  totalCount={RowGridData.RowGrid.length}
                  nextToken={RowGridData.nextToken}
                  TotalRecord={TotalCount}
                  pageSize={PageSize}
                  onPageChange={(page) => {
                    setCurrentPage(page);
                    nextValue(page);
                  }}
                />
              </div>
            )}
            {LoadInSinglePage &&
              <div className="flex justify-end gap-2">
                <NVLlabel text={`Fetched ${RowGridData.RowGrid.length}${RowGridData.nextToken != null ? "+" : ""} records`} />
                {RowGridData.nextToken != null &&
                  <div >
                    <div className=" flex gap-2 bg-gray-300 hover:bg-gray-400 text-gray-800 font-medium py-1 px-2 rounded text-xs cursor-pointer"
                      onClick={() => { setCurrentPage(currentPage + 1); nextValue(currentPage + 1); }}>
                      Load More<i className="fa-solid fa-plus my-auto"></i>
                    </div>
                  </div>}
              </div>
            }
            {/* {LoadInSinglePage && RowGridData.nextToken != null && (
              <div className="flex justify-end">
                <div
                  className=" flex gap-2 bg-gray-300 hover:bg-gray-400 text-gray-800 font-medium py-1 px-2 rounded text-xs cursor-pointer"
                  onClick={() => {
                    setCurrentPage(currentPage + 1);
                    nextValue(currentPage + 1);
                  }}
                >
                  Load More<i className="fa-solid fa-plus my-auto"></i>
                </div>
              </div>
            )} */}
            {(viewMoreAction?.IsNavigation&&viewMoreAction?.ListOfCount<=currentTableData?.length)&&viewMoreAction?.Link}
            </section>

        ) : (
          <div>
            <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />
          </div>
        )}
      </Container>
    </>
  );
}

export default NVLGridTable;
