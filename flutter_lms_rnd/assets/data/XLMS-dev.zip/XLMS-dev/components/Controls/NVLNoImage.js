import NVLImage from "@components/Controls/NVLImage";

function NVLNoImage(props) {
  return (
    <div className={`w-full justify-${props.alignItem} flex xl:px-4`+ props.className}>
      <NVLImage src="/NoRecords.jpg" 
      alt="NoRecord" 
      title="No Record" 
      className={props.className} />
    </div>
  );
}

export default NVLNoImage;