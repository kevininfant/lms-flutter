import React, { useState } from "react";

const Modal = (props) => {
  const [showModal, setShowModal] = useState(false);
  function onClickState() {
    props.onDelete()
    setShowModal(false)
  }

  return (
    <>
      <button type="button" onClick={() => setShowModal(true)}>
        {props.Icon}
      </button>
      {showModal ? (
        <div className="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>
          <div className="fixed inset-0 z-10 overflow-y-auto">
            <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
              <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
                <div className="p-6 text-center bg-th-body-bg-color text-th-body-txt-color px-4 py-3">
                  <i className="fa fa-solid fa-circle-exclamation text-5xl mx-auto mb-4 w-14 h-14 text-th-body-icon-color"></i>
                  <h3 className="mb-5 text-lg font-normal  ">Are you sure you want to delete?</h3>
                  <button onClick={onClickState} type="button" className="text-white bg-red-600 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-red-300 dark:focus:ring-red-800 font-medium rounded-lg text-sm inline-flex items-center px-5 py-2.5 text-center mr-2">
                    Yes, I&apos;m sure
                  </button>
                  <button onClick={() => setShowModal(false)} data-modal-toggle="popup-modal"
                    type="button"
                    className="text-gray-500 bg-white hover:bg-gray-100 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-gray-900 focus:z-10 dark:bg-gray-700 dark:text-gray-300 dark:border-gray-500 dark:hover:text-white dark:hover:bg-gray-600 dark:focus:ring-gray-600">No, cancel</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
};

export default Modal;