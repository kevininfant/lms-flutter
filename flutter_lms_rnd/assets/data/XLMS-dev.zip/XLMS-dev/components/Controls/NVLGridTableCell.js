function NVLGridTableCell(props) {
  return (
    <td
      className={"nvl-GridTable-Cell " + props.HeaderColumnCss}>
      {props.ControlItem}
    </td>
  );
}

export default NVLGridTableCell;
