import NVLActivityIcon from "@components/Controls/NVLActivityIcon";
import NVLlabel from "@components/Controls/NVLlabel";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useState } from "react";
import { listXlmsUserCertificateInfos } from "src/graphql/queries";
function NVLCourseNavbar({ FetchActData, fetchCourseIntoduction, fetchdata, FunctionUpdate, EnrollCourseData, activeState }) {

    const [open, setOpen] = useState(false);
    const [isDownload, setIsDownload] = useState(false);
    const [getMyCertificate, setgetMyCertificate] = useState();
    const [status, setStatus] = useState(() => {
        return JSON.parse(EnrollCourseData?.CompletionStatus != undefined ? EnrollCourseData?.CompletionStatus : '{}');
    });
    useEffect(() => {
        FunctionUpdate(setStatus);
        async function fetchData(params) {
            const CertificateForCompleted = await AppsyncDBconnection(listXlmsUserCertificateInfos, { PK: "TENANT#" + fetchdata?.TenantInfo?.TenantID + "#USERSUB#" + fetchdata?.user?.attributes?.["sub"], SK: "CERTIFICATE#" }, fetchdata?.user?.signInUserSession?.accessToken?.jwtToken)
            let myCertficate = CertificateForCompleted?.res?.listXlmsUserCertificateInfos?.items && CertificateForCompleted?.res?.listXlmsUserCertificateInfos?.items.filter((item) => { return item?.SK.split("#")[3] == EnrollCourseData?.CourseID; })
            setgetMyCertificate(myCertficate?.[0]?.CertificateImagePath)
        } fetchData()
    }, [EnrollCourseData?.CourseID, FunctionUpdate, fetchdata?.TenantInfo?.TenantID, fetchdata?.user?.attributes, fetchdata?.user?.signInUserSession?.accessToken?.jwtToken])

    const downloadCertificate = useCallback(async (input) => {
        setIsDownload(true)
        let fetchURL = process.env.APIGATEWAY_INVOKEURL;
        let headers = {
            method: "POST",
            headers: {
                authorizationtoken: fetchdata?.user?.signInUserSession?.accessToken?.jwtToken,
                bucketName: fetchdata?.TenantInfo?.BucketName,
            },
            body: input.substring(1),
        };
        let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
        var win = window.open(await FinalStatus.res?.text(), '_blank');
        setIsDownload(false)
    }, [fetchdata?.user?.signInUserSession?.accessToken?.jwtToken, fetchdata?.TenantInfo?.BucketName])

    const groupBy = function (xs, key) {
        return xs.reduce(function (rv, x) {
            (rv[x[key]] = rv[x[key]] || []).push(x);
            return rv;
        }, {});
    };

    const restriction = useMemo(() => { return Object.values(JSON.parse(fetchdata?.EnrollCourseData?.Restriction != undefined ? fetchdata?.EnrollCourseData?.Restriction : "{}"))?.[0]?.flow }, [fetchdata?.EnrollCourseData?.Restriction]);
    const ModuleInfo = useMemo(() => {
        let restriction = Object.values(JSON.parse(fetchdata?.EnrollCourseData?.Restriction != undefined ? fetchdata?.EnrollCourseData?.Restriction : "{}"))?.[0]?.flow;
        if (restriction?.ActivityList != undefined) {
            let ModuleInfoID = Object.keys(groupBy(restriction.ActivityList, "ModuleID"))
            let ModuleInfo = [], ModuleName = {};
            fetchdata?.responseModuleData?.map((element, index) => {
                ModuleName = { ...ModuleName, [element.ModuleID]: element.ModuleName }
            });

            ModuleInfoID.map((data) => {
                ModuleInfo = [...ModuleInfo, { ModuleID: data, ModuleName: ModuleName?.[data] }]
            })
            return ModuleInfo;
        }
        else {
            return [];
        }
    }, [fetchdata?.EnrollCourseData?.Restriction, fetchdata?.responseModuleData])

    const ActivityInfo = useMemo(() => {
        let restriction = Object.values(JSON.parse(fetchdata?.EnrollCourseData?.Restriction != undefined ? fetchdata?.EnrollCourseData?.Restriction : "{}"))?.[0]?.flow;
        if (restriction?.ActivityList != undefined) {
            let tempActivityInfo = {}, ActivityInfo = [];
            fetchdata?.ActList?.map((data, index) => {
                tempActivityInfo = { ...tempActivityInfo, [data.ActivityID]: data }
            })
            restriction?.ActivityList.map((data) => {
                if (tempActivityInfo?.[data?.actId] != undefined) {
                    ActivityInfo = [...ActivityInfo, tempActivityInfo?.[data?.actId]]
                }
            })
            return groupBy(ActivityInfo, "ModuleID")
        }
        else {
            return {};
        }
    }, [fetchdata?.ActList, fetchdata?.EnrollCourseData?.Restriction])
    function toHoursAndMinutes(totalMinutes) {
        if (totalMinutes) {
            if (totalMinutes != "null") {
                const minutes = totalMinutes % 60;
                const hours = Math.floor(totalMinutes / 60);
                return `${padTo2Digits(hours)}:${padTo2Digits(minutes)}`;
            } else return `00:00`

        } else return "00:00"
    }

    function padTo2Digits(num) {
        return num.toString().padStart(2, '0');
    }
    const updatedCourseProgressBG = { width: Math.round(status?.progress) + "%" };
    return (
        <>
            <div className={`${!open && "hidden"} `}>
                <div className="absolute right-0 top-3 border w-44 rounded-l-lg flex">
                <button onClick={() => setOpen(!open)} type="button" className={` bg-primary text-white shadow-md duration-300 py-3 h-10 w-5 rounded-l-lg  border-gray-200  px-2  text-xs`}>
                    {open ? <i className="fa-solid fa-chevron-left"></i> : <i className="fa-solid fa-chevron-right"></i>}
                </button>
                <NVLlabel className="!text-sm  text-gray-600 font-bold my-auto px-2 py-1">Course content</NVLlabel>
                </div>
            </div>
            <div className={` ${open ? "hidden " : "block relative bottom-10 "} w-full md:w-[450px] h-screen float-right flex flex-col text-xs border duration-700 `}>
                <div className={`${!open && "absolute -left-5"} `}>
                    <button onClick={() => setOpen(!open)} type="button" className={`  bg-primary text-white shadow-md duration-300 float-right left-4 py-2 h-10 w-5 rounded-l-lg  border-gray-200  px-2  text-xs`}>
                        {open ? <i className="fa-solid fa-chevron-left"></i> : <i className="fa-solid fa-chevron-right"></i>}
                    </button>
                </div>
                <li className={`flex gap-2 p-2 border-b `}>
                <NVLlabel className="!text-sm  text-gray-600 font-bold my-auto px-2 py-1">Course content</NVLlabel> </li>
           
                    <div className="flex gap-2 justify-evenly border-b py-4">
                        <NVLlabel className="!text-xs  text-gray-600 font-medium my-auto">My Progress</NVLlabel>
                        <div className="flex my-auto gap-2 items-center">
                            <div className="w-32 h-[6px] relative bg-slate-200 rounded">
                                <div style={updatedCourseProgressBG} className={`absolute top-0 left-0 bg-[#F47A22] cursor-pointer group rounded h-full `}>
                                    <span className=" bg-white border text-[#374151] hidden group-hover:block rounded-3xl font-semibold !text-[10px] -py-2 px-1 absolute -right-4 bottom-full mb-2">
                                        <span className=" w-2 h-2 rotate-45 border bg-white absolute bottom-[-4px] left-1/2 -z-50 -translate-x-1/2 rounded-sm"></span>
                                        {"("}{status?.progress > 0 ? Math.round(status?.progress) : "0"}{"%)"}
                                    </span>
                                </div>
                            </div>
                        </div>
                          {isDownload ? <div ><i className="fa fa-circle-notch fa-spin text-[#1d74ff]"></i> </div>
                            : <svg className={`${getMyCertificate ? "cursor-pointer" : "pointer-events-none cursor-none"}`} onClick={() => downloadCertificate(getMyCertificate)} id="View_And_download_certificate" data-name="View And download certificate" width="32" height="28.22" viewBox="0 0 32 28.22">
                                <g id="Group_1018" data-name="Group 1018">
                                    <path id="Path_402" data-name="Path 402" d="M9.436,100.543a4.718,4.718,0,1,1-4.721-4.715,4.721,4.721,0,0,1,4.721,4.715" transform="translate(0 -89.536)" fill={getMyCertificate?"#1d74ff":"#D1D3D4"} />
                                    <path id="Path_403" data-name="Path 403" d="M30.219,250.757V251q0,2.2,0,4.4a.805.805,0,0,1-1.441.591c-.558-.565-1.125-1.121-1.705-1.7-.054.05-.115.1-.17.156q-.781.782-1.561,1.565a.784.784,0,0,1-.933.229.8.8,0,0,1-.482-.81c0-1.547,0-3.095,0-4.675a6.34,6.34,0,0,0,6.291,0" transform="translate(-22.356 -234.293)" fill={getMyCertificate?"#1d74ff":"#D1D3D4"} />
                                    <path id="Path_404" data-name="Path 404" d="M263.476,8.348l4.158,4.155a1.094,1.094,0,0,1-.143.015q-1.584,0-3.169,0a.785.785,0,0,1-.852-.811c0-1.089,0-2.178,0-3.267,0-.038.005-.075.007-.092" transform="translate(-246.169 -7.8)" fill={getMyCertificate?"#1d74ff":"#D1D3D4"} />
                                    <path id="Path_405" data-name="Path 405" d="M86.765,21.21A4.7,4.7,0,0,1,89.4,16.99q0-5.231,0-10.463V6.292h-.29q-1.769,0-3.538,0a2.359,2.359,0,0,1-2.463-2.454q0-1.781,0-3.562V.024A.475.475,0,0,0,83.032,0c-2.9,0-5.8-.012-8.7.007a2.224,2.224,0,0,0-2.171,1.917c-.09.913-.019,1.843-.019,2.763.386.049.781.071,1.163.151a6.291,6.291,0,0,1,3.638,10.168.605.605,0,0,0-.122.35c-.008,1.515,0,3.03-.007,4.545,0,.7-.029,1.4-.045,2.109a.736.736,0,0,0,.085,0q4.989,0,9.977,0a4.719,4.719,0,0,1-.07-.805M77.607,5.5a.787.787,0,0,1,.831-.782q1.13-.005,2.26,0a.788.788,0,1,1,0,1.571q-.282,0-.565,0H79c-.188,0-.377,0-.565,0a.79.79,0,0,1-.826-.789m7.846,12.583c-1.04.005-2.08,0-3.12,0h-3.12a.775.775,0,0,1-.725-.421.731.731,0,0,1,.021-.771.769.769,0,0,1,.7-.381q3.12,0,6.24,0a.785.785,0,1,1,0,1.569m-.058-3.93q-2.285,0-4.57,0a.79.79,0,1,1,.013-1.572q1.142,0,2.285,0t2.26,0a.79.79,0,1,1,.012,1.572m.012-3.932q-2.3,0-4.594,0a.788.788,0,1,1,.012-1.571c.762,0,1.523,0,2.285,0s1.523,0,2.285,0a.788.788,0,1,1,.012,1.571" transform="translate(-67.383 0)" fill={getMyCertificate?"#1d74ff":"#D1D3D4"} />
                                    <path id="Path_406" data-name="Path 406" d="M319.38,256.1a5.7,5.7,0,1,0,5.7,5.7,5.7,5.7,0,0,0-5.7-5.7m-1.941,5.162a.457.457,0,0,1,.661.011c.038.036.074.073.11.11l.676.679.032-.012V261.9q0-1.549,0-3.1a.461.461,0,0,1,.44-.507.445.445,0,0,1,.468.379,1.072,1.072,0,0,1,.011.18q0,1.523,0,3.046v.18c.055-.049.089-.078.121-.11.227-.226.451-.453.679-.678a.464.464,0,1,1,.65.658q-.773.776-1.549,1.549a.461.461,0,0,1-.717,0q-.79-.787-1.577-1.576a.452.452,0,0,1-.005-.66m5.513,3.319a.775.775,0,0,1-.731.727c-.039,0-.078,0-.117,0h-5.456a.791.791,0,0,1-.839-.685,3.138,3.138,0,0,1-.009-.414c0-.289,0-.579,0-.868a.455.455,0,0,1,.451-.481.449.449,0,0,1,.461.483c0,.345,0,.689,0,1.046h5.332c0-.216,0-.427,0-.637,0-.151,0-.3,0-.453a.454.454,0,0,1,.907-.016c.009.432.014.864,0,1.3" transform="translate(-293.083 -239.289)" fill={getMyCertificate?"#1d74ff":"#D1D3D4"} />
                                </g>
                            </svg>}
                    </div>
             
                <div className="overflow-auto ">
                    <div className={` `}>
                        <li onClick={() => { fetchCourseIntoduction() }} className={`flex gap-2 px-2 p-1.5 cursor-pointer  ${(activeState == undefined) ? "bg-blue-100 " : ""}`}>
                            <div className="my-auto">
                                <NVLActivityIcon bgColor={(activeState == undefined) ? "bg-primary " : " bg-gray-200 "} color={(activeState == undefined) ? "#fff" : " #374151"} type="Video" className={`p-1 h-6 w-6 grid place-content-center rounded-md cursor-pointer ${(activeState == undefined) ? "bg-primary text-white" : " bg-gray-200 !text-[#374151]"}  `} />
                            </div>
                            <div className={` w-full space-y-2 px-2  p-1 `}>
                                <NVLlabel className={`!text-[#374151] text-sm text-th-primary-dark cursor-pointer ${activeState == undefined ? "underline !text-[#0E4681]" : ""}`} tooltip={"Course Introduction"} text={"Course Introduction"} ></NVLlabel>
                                <div className="text-[10px] flex gap-1 my-auto text-gray-500"><i className="fa-solid fa-clock text-xs text-slate-600 mt-0.5"></i> <p> {toHoursAndMinutes(EnrollCourseData?.TotalHours)}</p></div>
                            </div>
                            <input type="checkbox" checked={true} className="my-auto w-4 h-4 text-green-600 border focus:border-transparent focus:ring-0 rounded-full" />
                        </li>
                    </div>
                    {ModuleInfo?.map((element, index) => {
                        let tempModule = [];
                        let ActivityList = ActivityInfo?.[element.ModuleID]
                        if (ActivityList != undefined) {
                            ActivityList?.map((data, index) => {
                                restriction?.Visible.map((temp) => {
                                    if (temp.actId == data.ActivityID) {
                                        tempModule = [...tempModule, data]
                                    }
                                })
                                let trackProgress = []
                                restriction?.must.map((data) => {
                                    trackProgress = [...trackProgress, data.actId]
                                })
                            });
                        }
                        if (tempModule.length > 0)
                            return (
                                // Module Section
                                <div key={index} className="Course-Trastion mb-2">
                                    <div className="relative flex flex-col rounded-md ">
                                        <input className="peer hidden" type="checkbox" id={`accordion-${index}`} defaultChecked={(fetchdata?.ActivityData?.ModuleID == element?.ModuleID || fetchdata?.ActivityData?.ActivityID == undefined && index == 0)} />

                                        <label htmlFor={`accordion-${index}`} className="text-sm text-[#374151] lg:text-base">
                                            <div className="text-sm flex-end font-semibold shadow-none cursor-pointer px-2.5 bg-[#D6D6D6] py-2 ">
                                                {`Section ${(index + 1)}: ${element.ModuleName?.length > 25 ? (element.ModuleName?.substring(0, 25) + "...") : element.ModuleName}`}
                                            </div>
                                        </label>
                                        <label htmlFor={`accordion-${index}`} className="text-sm text-[#374151] cursor-pointer hidden peer-checked:block absolute right-3 top-2">
                                            <i className="fa-solid fa-angle-up"></i>
                                        </label>
                                        <label htmlFor={`accordion-${index}`} className="text-sm text-[#374151] cursor-pointer peer-checked:hidden absolute right-3 top-2">
                                            <i className="fa-solid fa-angle-down"></i>
                                        </label>
                                        <div className="max-h-0 cursor-none overflow-hidden  peer-checked:max-h-full ">
                                            {tempModule.map((data, index) => {
                                                let temp = status, tempres = restriction.Order, disabled = false;
                                                if (tempres?.[data.ActivityID]?.before?.length > 0) {
                                                    tempres?.[data.ActivityID].before.map(tempdata => {
                                                        if (temp?.[tempdata.actId]?.CompletionStatus != "100") {
                                                            disabled = true;
                                                        }
                                                    })
                                                }
                                                let tempActiveState = activeState != undefined && fetchdata?.ActivityData?.ActivityID == data.ActivityID;
                                                return (<>
                                                    <li onClick={() => { FetchActData(data.ActivityID) }} className={`flex gap-2 px-2 py-1.5 cursor-pointer border-b ${(tempActiveState) ? "bg-blue-100 " : ""}`}>
                                                        <div className="my-auto">
                                                            <NVLActivityIcon bgColor={(tempActiveState) ? "bg-primary " : " bg-gray-200 "} color={(tempActiveState) ? "#fff" : " #374151"} type={data.ActivityType} className={`p-1 h-6 w-6 grid place-content-center rounded-md cursor-pointer ${(tempActiveState) ? "bg-primary text-white" : " bg-gray-200 !text-[#374151]"}  `} />
                                                        </div>
                                                        <div className={` w-full space-y-2 px-2  p-1 `}>
                                                            <NVLlabel className={`!text-[#374151] text-sm text-th-primary-dark cursor-pointer ${tempActiveState ? "underline !text-[#0E4681]" : ""}`} tooltip={data.ActivityName} text={data.ActivityName} ></NVLlabel>
                                                            <div className="text-[10px] flex gap-2 my-auto text-gray-500"><i className="fa-solid fa-clock text-xs text-[#374151] mt-0.5"></i> <p> {toHoursAndMinutes(data?.ActivityDuration)}</p></div>
                                                        </div>
                                                        {status?.[data.ActivityID]?.CompletionStatus == "100" ?
                                                            <input disabled={true} type="checkbox" checked={true} className={`my-auto w-4 h-4 text-green-600 border focus:border-transparent focus:ring-0 rounded-full`} />
                                                            : <input disabled={!data?.IsMarkTheActivity} type="checkbox" className={`my-auto w-4 h-4 text-green-600 border focus:border-transparent focus:ring-0 rounded-full`} />}

                                                    </li>
                                                </>
                                                );
                                            })}
                                        </div>
                                    </div>
                                </div>
                            );
                    })}
                </div>
            </div>
        </>)
}
export default NVLCourseNavbar;