import { createXlmsLoginLiveUserInfo } from '@graphql/graphql/mutations';
import { Auth } from 'aws-amplify';
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useCallback, useEffect, useMemo, useRef } from 'react';

export default function NVLWebWorkerLogin(props) {
    const user = useRef();
    useMemo(() => {
        const temp = async () => {
            let currentuser = await Auth?.currentAuthenticatedUser();
            user.current = currentuser;
        }
        temp();
    }, [])
    const getting = useCallback(async () => {
        const getUA = () => {
            let device;
            const ua = {
                "Android": /Android/i,
                "BlackBerry": /BlackBerry/i,
                "Bluebird": /EF500/i,
                "Chrome OS": /CrOS/i,
                "Datalogic": /DL-AXIS/i,
                "Honeywell": /CT50/i,
                "iPad": /iPad/i,
                "iPhone": /iPhone/i,
                "iPod": /iPod/i,
                "macOS": /Macintosh/i,
            }
            Object.keys(ua).map(v => navigator.userAgent.match(ua[v]) && (device = v));
            return device;
        }
        var today = Math.round(((new Date()).getTime()) / 1000) + (60);
        let Variables = {
            input: {
                PK: "XLMS#LIVEUSER",
                SK: "TENANT#" + user?.current?.attributes["custom:tenantid"] + "#USERSUB#" + user?.current?.attributes["sub"],
                DeviceName: getUA() == undefined ? "Web User" : "Mobile User",
                UserSub: user?.current?.attributes["sub"],
                CreatedDate: new Date(),
                AutoDelete: today
            }
        }
        AppsyncDBconnection(createXlmsLoginLiveUserInfo, Variables, user?.current?.signInUserSession?.accessToken?.jwtToken)
    }, [])

    useEffect(() => {
        function GetTimer() {
            if (user.current != undefined) {
                getting()
            }
        }
        GetTimer();
        if (user.current != undefined) {
            getting()
        }
        const interval = setInterval(GetTimer, 30000); //300000
        return () => clearInterval(interval);
    }, [getting])

    useEffect(() => {
        async function RefershAuth() {
            if (user.current != undefined) {
                try {
                    const currentSession = await Auth.currentSession();
                    user.current.refreshSession(currentSession.refreshToken, (err, session) => {
                        if (err == undefined) {
                            const { refreshToken, accessToken } = session;
                            let keys = Object.keys(localStorage);
                            keys.map((data) => {
                                if (data.includes("refreshToken")) {
                                    localStorage.setItem(data, refreshToken?.token);
                                }
                                else if (data.includes("accessToken")) {
                                    localStorage.setItem(data, accessToken?.jwtToken)
                                    localStorage.setItem("AccessTokenKey", data)
                                }
                            })
                            Auth?.currentAuthenticatedUser().then((res) => {
                                console.log(res)
                                props.changeUserValues(res);

                            }).catch((e) => {
                                console.log(e)
                                props.signOut();
                            })
                        }
                        else {
                            console.log(err)
                            props.signOut();
                        }
                    });
                } catch (e) {
                    console.log(e)
                    props.signOut();
                }
            }
        }
        const interval = setInterval(RefershAuth, 240000); //300000
        return () => clearInterval(interval);
    }, [getting, props])


    return (
        <div>
        </div>
    )
}