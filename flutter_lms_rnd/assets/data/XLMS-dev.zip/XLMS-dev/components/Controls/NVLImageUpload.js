import { MdClose } from "react-icons/md";
import { ImUpload } from "react-icons/im";
import NVLlabel from '@components/Controls/NVLlabel';
import NVLImage from "@Controls/NVLImage";
import NVLLoader from "@Controls/NVLLoader";
import { useEffect, useRef } from "react";

function NVLImageUpload(props) {
    const imgageControl = useRef(null);
    useEffect(() => {
        if (props?.Logofile == null) {
            imgageControl.current.value=null;
        }
    }, [props?.Logofile])
    return (
        <>
            <div className="mt-1 flex ">
                <span className={`overflow-hidden`} id="defLogo">
                    {props.Logofile != null ? <NVLImage src={props.uploadImage == "" ? props.Logofile : URL.createObjectURL(props.uploadImage)} alt={props.Logofile ? props.Logofile.name : "Logo"} className={`${props.ImgHeight != "" ? props.ImgHeight : "w-44 h-20"} `} title="Novac Logo" /> : <ImUpload className="fa-solid fa-upload text-4xl text-primary" htmlFor="fulogo" />}
                </span>
                <NVLlabel htmlFor="fulogo" className="relative lg:bottom-1 xl:bottom-1 cursor-pointer bg-white xl:pt-4 text-gray-600 font-semibold text-indigo-6 text-sm">
                    <span className={`sm:px-0 select-none uppercase underline ${props.Logofile != null ? "hidden" : ""}`} id="lblupload">
                        {props.text}
                    </span>
                    <input id="fulogo" ref={imgageControl} name="file-upload" accept={props.accept} type="file" onChange={props.UploadLogo} className="sr-only " />
                </NVLlabel>
                <NVLLoader className={`text-sm ${props?.watch(props?.control) == "Upload" ? "" : "hidden"}`} id="loader" />
                <MdClose className={`cursor-pointer border border-red-700 rounded-xl hover:scale-105  text-red-700 text-xl -translate-x-5 ${props.watch(props.control) == "Image" ? "" : "hidden"}`} id="delimg" onClick={(e) => props.removeImg(e)} />
            </div>
            <div className={`sm:flex flex ${props.watch(props.control) == "Error" ? "" : "hidden"}`}>
                <NVLlabel className="text-red-600 text-sm " showFull={"Full"} id="lblFile" text={props.lblFile} />
            </div>
        </>
    );
}
export default NVLImageUpload;