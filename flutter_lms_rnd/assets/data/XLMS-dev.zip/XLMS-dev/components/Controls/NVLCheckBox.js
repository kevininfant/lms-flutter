import NVLlabel from "@components/Controls/NVLlabel";

function NVLCheckbox(props) {
  return (
    <>
      <div className="w-full flex">
        <input id={props.id} type="checkbox"
          {...props.register(props.id, { shouldValidate: true })}
          readOnly={props.readOnly}
          className={"nvl-Checkbox  " + props.className + "  " + (props.errors?.[props.id] ? "border-red " : "  border-gray-300")}
          label={props.label}
          defaultChecked={props.defaultChecked}
          disabled={props.disabled}
          onClick={props.onClick} />
        <NVLlabel text={props.text} showFull={props.showFull}
          className={"text-gray-600 px-2 " + props.className} />
      </div>
      <div className='{invalid-feedback} text-red-500 text-sm'>{props?.errors?.[props.id]?.message}</div>
    </>
  );
}

export default NVLCheckbox;