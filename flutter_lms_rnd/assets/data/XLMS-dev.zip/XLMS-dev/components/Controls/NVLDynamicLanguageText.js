import NVLTextbox from "@components/Controls/NVLTextBox";
import React, { useCallback, useEffect } from "react";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLlabel from "@components/Controls/NVLlabel";
import { Regex } from "RegularExpression/Regex";

export default function NVLDynamicLanguageText({  title,LangValues, setLangValue, setValue, SelectFieldOptions, id, 
  ValidateError, LoaderId, watch, errors, ddlLangId, ddlTextId, ErrorMsg, register,FileError }) {

  useEffect(() => {
    LangValues?.map((e, index) => {
      setValue("ddlVideoUrl" + index, e?.Language)
      setValue("textVideoUrl" + index, e?.TextURL)
    });
  }, [LangValues, setValue])

  const deleteField = useCallback((e, index) => {
    if (!(index == 0 && LangValues.length == 1)) {
      for (let i = index; i < LangValues.length - 1; i++) {
        setValue("ddlVideoUrl" + i, watch(ddlLangId + (i + 1)))
        setValue("textVideoUrl" + i, watch(ddlTextId + (i + 1)))
      }
      setValue(ddlTextId + "0", watch(ddlTextId + "0"))
      setValue(ddlLangId + "0", watch(ddlLangId + "0"))

      setValue(ddlTextId + LangValues.length, "")
      setValue(ddlLangId + LangValues.length, "")
      LangValues.splice(index, 1);
      setLangValue(LangValues);
    }
    setValue("FileLang", "success", { shouldValidate: true })
  },


    [LangValues, ddlLangId, ddlTextId, setLangValue, setValue, watch]
  );

  const AddCustomFields = useCallback((index) => {
    let tempData = [];
    let isEmpt = false;

    LangValues.map((e, count) => {
      tempData = [...tempData, { Language: watch(ddlLangId + count), TextURL: document.getElementById(ddlTextId + count).value }]
      if ((watch(ddlTextId + count) == "" || watch(ddlTextId + count) == undefined) && (watch(ddlLangId + count) == "" || watch(ddlLangId + count) == undefined)) {
        isEmpt = true;
        setValue("FileLang", "LANGTEXT", { shouldValidate: true })
      }
      else if (watch(ddlTextId + count) == "" || watch(ddlTextId + count) == undefined) {
        isEmpt = true;
        setValue("FileLang", "TEXT", { shouldValidate: true })
        return;
      } else if (watch(ddlLangId + count) == "" || watch(ddlLangId + count) == undefined) {
        isEmpt = true;
        setValue("FileLang", "LANG", { shouldValidate: true })
        return;
      } else if (!Regex("Url").test(watch(ddlTextId + count))) {
        isEmpt = true;
        setValue("FileLang", "INVALIDURL", { shouldValidate: true })
        return;
      }
    });

    if (hasDuplicate(tempData, "Language")) {
      setValue("FileLang", "LANGEXISTS", { shouldValidate: true })
      return;
    }

    if (!isEmpt) {
      tempData = [...tempData, { Language: "", TextURL: "" }]
      setLangValue(tempData);
      setValue(ddlTextId + index, "")
      setValue(ddlLangId + index, "")
      setValue("FileLang", "Sucess", { shouldValidate: true })
    }
  }, [LangValues, ddlLangId, ddlTextId, setLangValue, setValue, watch]);

  const hasDuplicate = (arrayObj, colName) => {
    var hash = Object.create(null);
    return arrayObj.some((arr) => {
      return arr[colName] && (hash[arr[colName]] || !(hash[arr[colName]] = true));
    });
  };

  const NVLDynamicTextLanguage = useCallback(() => {
    return (<div className={"text-red-500 text-sm"} id={"fileErrorMessage"}>{FileError}</div>)

  }, [FileError]);

  return (
    <>
      <div className="w-64 md:w-96 relative">
        <div className="">
          {LangValues.map((message, index) => {
            return (
              <div key={"divId" + index} className={`${index == 0 ? "mb-8" : ""}`}>
               <div className="flex justify-between">
                <div>
                 {index == 0 && <NVLlabel text="Choose Language" className={`nvl-Def-Label`} />}
                  <NVLSelectField
                    id={ddlLangId + index}
                    className="w-48 nvl-mandatory"
                    options={SelectFieldOptions}
                    errors={errors}
                    register={register} />
                     </div>
                  <div>
                  {index == 0 && <NVLlabel text="URL" className={`nvl-Def-Label`} />}
                  <NVLTextbox id={ddlTextId + index} errors={errors} register={register} title={title} className="nvl-mandatory" />
                  </div>
                  
                    
                </div>
                <div className={`${index == 0 ? "hidden" : ""}`}>
                  <NVLlabel key={index} className={`relative left-[400px] bottom-8 cursor-pointer h-8 w-8 shadow-lg bg-red-100   inline-block text-red-600  rounded-full `} id="todo__delete" onClick={(e) => deleteField(e, index)} >
                    <i className="fa-solid fa-trash absolute top-2.5 left-2.5 text-sm"></i>
                  </NVLlabel>
                </div>
              </div>
            );
          })}
        </div>
        <div id="app" className={`grid gap-4 absolute ${LangValues.length > 1 ? "-right-24 bottom-8" : "-right-12 bottom-1"} `}>
          <NVLlabel onClick={() => AddCustomFields(LangValues.length)} className="cursor-pointer text-xs  bg-blue-100  shadow-lg text-blue-600 font-bold rounded-full h-8 w-8">
            <i className="fa-solid fa-plus relative left-2.5 top-2 text-sm"></i>
          </NVLlabel>
        </div>


        <div className="hidden" id="divURLLangCount">{LangValues.length}
        </div>

      </div>
      <NVLDynamicTextLanguage />
    </>
  );
}
