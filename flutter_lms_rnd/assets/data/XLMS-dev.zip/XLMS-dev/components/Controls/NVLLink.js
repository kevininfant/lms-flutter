import { Link } from "@aws-amplify/ui-react";
import React from "react";

const NVLLink = React.forwardRef((props, rel) => {
  return (
    <>
      <div className={`${props.classNameLink != undefined ? props.classNameLink : " nvl-Link "}`}>
        {props.Icon &&
          <div className="my-auto">
            <Link href={props.href}>
              <i className={`${props.Icon} rounded p-1 px-1.5 text-sm pr-5 `}></i>
            </Link>
          </div>
        }
        <div className={`my-auto ${props.classNameDiv!=undefined?props.classNameDiv:""}`}>
          <Link id={props.id} title={props.text?.toString()?.replace(/\s{2,}(?!\s)/g, ' ').trim()} className={props.className != undefined ? props.className : " text-xs font-medium m-auto  p-2 pt-2"} type={props.type} href={props.href} isExternal={props.isExternal} color={props.color} as={props.as} to={props.to} onClick={props.onClick}>
            {props.text?.length > 35 && props.showFull == undefined ? (props?.text?.substring(0, 30) + "...") : props.text}
          </Link>
        </div>
      </div>
    </>
  );
});
NVLLink.displayName = "NVLLink";

export default NVLLink;
