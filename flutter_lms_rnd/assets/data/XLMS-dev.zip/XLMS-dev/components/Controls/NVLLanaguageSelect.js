import React, { Fragment, useState, useEffect } from "react";
import { Menu, Transition } from "@headlessui/react";
import { useTranslation } from "react-i18next";
import i18next from "i18next";


const languageMap = {
  English: { label: "English", dir: "ltr", active: true },
  Tamil: { label: "தமிழ்", dir: "ltr", active: false },
  Telugu: { label: "తెలుగు", dir: "ltr", active: false },
  Malayalam: { label: "മലയാളം", dir: "ltr", active: false },
  Kannada: { label: "ಕನ್ನಡ", dir: "ltr", active: false },
  Hindi: { label: "हिन्दी", dir: "ltr", active: false },
};

const NVLLanaguageSelect = () => {
  function classNames(...classes) {
    return classes.filter(Boolean).join(" ");
  }
  const selected = localStorage.getItem("i18nextLng") || "English";
  const [menuAnchor, setMenuAnchor] = useState(null);
  // useEffect(() => {
  //   document.body.dir = languageMap[selected]?.dir;
  // }, [menuAnchor, selected]);

  return (
    <>
      <Menu as="div" className="relative inline-block text-left">
        <div>
          <Menu.Button className="inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 focus:ring-offset-gray-100"
          onClick={({ currentTarget }) => setMenuAnchor(currentTarget)}>
            {languageMap[selected]?.label==undefined?"English":languageMap[selected]?.label}
          </Menu.Button>
        </div>

        <Transition
          as={Fragment}
          enter="transition ease-out duration-100"
          enterFrom="transform opacity-0 scale-95"
          enterTo="transform opacity-100 scale-100"
          leave="transition ease-in duration-75"
          leaveFrom="transform opacity-100 scale-100"
          leaveTo="transform opacity-0 scale-95"
        >
          <Menu.Items className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
            <div className="py-1">
              {Object.keys(languageMap)?.map((item) => (
                <Menu.Item key={item}>
                  {({ active }) => (
                    <a key={item}
                      href="#"
                      title={item}
                      className={classNames(
                        active ? "bg-gray-100 text-gray-900" : "text-gray-700",
                        "block px-4 py-2 text-sm"
                      )}  
                      onClick={() => {
                        i18next.changeLanguage(item);
                        setMenuAnchor(null);
                      }}
                    >
                      <span>{languageMap[item].label}</span>
                    </a>
                  )}
                </Menu.Item>
              ))}
            </div>
          </Menu.Items>
        </Transition>
      </Menu>
    </>
  );
};

export default NVLLanaguageSelect;
