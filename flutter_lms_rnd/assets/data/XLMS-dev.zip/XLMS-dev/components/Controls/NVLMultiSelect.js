import { MultiSelect } from "react-multi-select-component";

function NVLMultiSelect(props) {
  return <MultiSelect width={props.width}
    name={props.name}
    options={props.options}
    disabled={props.disbaled}
    singleSelect={props.singleSelect}
    downArrowIcon={props.downArrowIcon}
    closeIcon={props.closeIcon}
    clearable={props.clearable}
    downArrow={props.downArrow}
    className={"nvl-MultiSelect !text-xs " + props.className}
    placeholder={props.placeholder}
    overrideStrings={props.overrideStrings != undefined ? props.overrideStrings : {}}
    labelledBy={props.placeholder}
    closeOnSelect={props.closeOnSelect}
    value={props.value ? props.value : []}
    onChange={props.onChange}
    handleOnchange={props.handleonChange}
    shouldToggleOnHover={props.shouldToggleOnHover}
  />;
}

export default NVLMultiSelect;
