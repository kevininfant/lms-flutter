import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import moment from 'moment'
import { Auth } from "aws-amplify";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { deleteXlmsLoginLiveUserInfo } from "src/graphql/mutations";

const IdleTimeOutHandler = React.forwardRef((props, ref) => {
    const [open, setOpen] = useState("");
    const events = useMemo(() => ['click', 'scroll', 'load', 'keydown', 'keypress', 'mousedown', 'mousemove'], [])
    const eventHandler = useCallback((eventType) => {
        localStorage.setItem('lastInteractionTime', moment())
        if (ref.current) {
            clearTimeout(ref.current)
            startTimer();
        }
    }, [, ref, startTimer]);
    useEffect(() => {
        addEvents();
        return (() => {
            clearTimeout(ref.current)
            removeEvents();
        })
    }, [addEvents, ref, removeEvents])
    const startTimer = useCallback(() => {
        if (open == "")
            ref.current = setTimeout(() => {
                let lastInteractionTime = localStorage.getItem('lastInteractionTime')
                const diff = moment.duration(moment().diff(moment(lastInteractionTime)));
                let timeOutInterval = props.timeOutInterval ? props.timeOutInterval : 60000;
                setOpen("Session Has Been Expired")
                localStorage.setItem('sessionstartTime', moment());
                if (diff._milliseconds < timeOutInterval) {
                    clearTimeout(ref.current)
                    startTimer();
                }
            }, props.timeOutInterval ? props.timeOutInterval : 900000)


    }, [props.timeOutInterval, ref, open])
    const addEvents = useCallback(() => {
        events.forEach(eventName => {
            window.addEventListener(eventName, eventHandler)
        })
        clearTimeout(ref.current)
        startTimer();

    }, [eventHandler, events, ref, startTimer])
    const reset = () => {
        clearTimeout(ref.current)
    }
    const removeEvents = useCallback(() => {
        events.forEach(eventName => {
            window.removeEventListener(eventName, eventHandler)
        })
    }, [eventHandler, events]);

    const UpdateField = (e) => {
        e.preventDefault();
        reset();
        localStorage.setItem('lastInteractionTime', moment())
        setOpen("");
        Auth.currentSession()
            .then(data => console.log(data))
            .catch(err => console.log(err));
    }

    const CancelEvent = (e) => {
        async function GetLiveUserData() {
            const DeleteUserResponse = await AppsyncDBconnection(
              deleteXlmsLoginLiveUserInfo,
              {input:[{
                PK: "XLMS#LIVEUSER",
                SK: "TENANT#" +props?.user?.attributes["custom:tenantid"] + "#USERSUB#"+props?.user?.attributes["sub"],
              },]},
              props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            const ListOfLiveUSers = DeleteUserResponse?.res?.deleteXlmsLoginLiveUserInfo?.items && DeleteUserResponse?.res?.listXlmsLoginLiveUserCountInfos?.items;
          }
          GetLiveUserData()
        e.preventDefault();
        props.signOut();
    }

    return (
        <div>
            <div> < NVLModalPopup ButtonYestext="Continue" SubmitClick={(e) => UpdateField(e)} CancelClick={(e) => CancelEvent(e)} ButtonNotext="Log In" CloseIconEvent={(e) => UpdateField(e)} Content={open} />
            </div>
        </div>
    )

}
)
IdleTimeOutHandler.displayName = "IdleTimeOutHandler";
export default IdleTimeOutHandler
