import React, { useCallback, useEffect, useRef, useState } from "react";
import EditorJS from "@editorjs/editorjs";
import Header from "@editorjs/header";
import RawTool from "@editorjs/raw";
import ImageTool from "@editorjs/image";
import Checklist from "@editorjs/checklist";
import List from "@editorjs/list";
import Quote from "@editorjs/quote";
import CodeTool from "@editorjs/code";
import { StyleInlineTool } from "editorjs-style";
import Tooltip from "editorjs-tooltip";
import _ from "lodash/debounce";

const NVLDynamicLanguagePage = (props) => {
  const DEFAULT_INITIAL_DATA = useCallback(() => {
    return {
      time: new Date().getTime(),
      blocks: [],
    };
  }, []);
  const getBase64 = (file) => {
    return new Promise((resolve) => {
      let baseURL = "";
      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        baseURL = reader.result;
        resolve(baseURL);
      };
    });
  };
  const isInstance = useRef(EditorJS | (null > null));
  useEffect(() => {
    if (!isInstance.current && !(isInstance.current?.isReady)) {
      initEditor();
    }
    return () => {
      if (isInstance.current) {
        isInstance.current.destroy();
        isInstance.current = null;
      }
    };
  }, [isInstance, initEditor]);
  const onFileChange = useCallback(async (file) => {
    return await getBase64(file);
  }, []);
  const initEditor = useCallback(() => {
    const editor = new EditorJS({
      holder: props.id,
      data:
        props.forwardedRef.current?.[props.id] === undefined
          ? DEFAULT_INITIAL_DATA()
          : JSON.parse(props.forwardedRef.current?.[props.id]),

      onReady: () => {
        isInstance.current = editor;
      },

      onChange: _(async function () {
        try {
          const output = await editor.save();
          const contentsdt = JSON.stringify(output);
          //props.setValue(props.id,contentsdt);
          props.forwardedRef.current = {
            ...props.forwardedRef?.current,
            [props.id]: contentsdt,
          };
        } catch (err) {
          console.log(err);
        }
      }),
      autofocus: true,
      tools: {
        style: StyleInlineTool,
        tooltip: {
          class: Tooltip,
          config: {
            location: "left",
            highlightColor: "#FFEFD5",
            underline: true,
            backgroundColor: "#154360",
            textColor: "#FDFEFE",
            holder: "editorId",
          },
        },
        header: {
          class: Header,
          inlineToolbar: true,
          config: {
            defaultLevel: 1,
          },
        },
        raw: RawTool,
        image: {
          class: ImageTool,
          config: {
            uploader: {
              async uploadByFile(file) {
                return onFileChange(file).then((imageUrl) => {
                  return {
                    success: 1,
                    file: {
                      url: imageUrl,
                    },
                  };
                });
              },
            },
          },
        },
        checklist: {
          class: Checklist,
          inlineToolbar: true,
        },
        list: {
          class: List,
          inlineToolbar: true,
          config: {
            defaultStyle: "unordered",
          },
        },
        quote: {
          class: Quote,
          inlineToolbar: true,
          shortcut: "CMD+SHIFT+O",
          config: {
            quotePlaceholder: "Enter a quote",
            captionPlaceholder: "Quote's author",
          },
        },
        code: {
          class: CodeTool,
          inlineToolbar: true,
        },
      },
    });
  }, [DEFAULT_INITIAL_DATA, onFileChange, props.forwardedRef, props.id]);

  return (
    <>
      <div id={props.id} className="bg-white border rounded">
        {" "}
      </div>
    </>
  );
};

export default NVLDynamicLanguagePage;
