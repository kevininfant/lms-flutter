import NVLlabel from '@components/Controls/NVLlabel';
import { useEffect, useRef } from "react";
import NVLLoader from './NVLLoader';
import NVLRapidModal from './NVLRapidModal';

function NVLFileUpload(props) {
  const imgageControl = useRef(null);
  useEffect(() => {
    if (props?.text == "Select File") {
      imgageControl.current.value = null;
    }
  }, [props?.text])
  return (
    <>
      <div className={`nvl-FileUpload ${props.className != undefined && props.className}`}>
        <div className="my-auto text-left">
          <NVLlabel htmlFor={`${props.id ? props.id : "getFile"}`} text={props.text} tooltip={props.tooltip} className={props.text?.toLowerCase() == "select file" ? "text-xs cursor-pointer bg-primary p-1.5 ml-2 text-white font-medium rounded-md " : "cursor-pointer bg-green-600 p-1.5 text-white  rounded"}> </NVLlabel>
        </div>
        {props?.isLoader && <div id={props?.loaderID} className={"h-4 my-auto hidden"}>
          <NVLLoader className={`text-sm`} />
        </div>}
        <div className=" flex gap-1 mr-2 items-center">
          <NVLlabel htmlFor={`${props.id ? props.id : "getFile"}`} text="Upload Files" className=" hidden border border-primary p-1 my-auto rounded cursor-pointer text-xs text-primary"></NVLlabel>
          {props.FilOnclick && (
            <NVLRapidModal
              id={"RapidModal"}
              ActionList={[
                {
                  id: 1,
                  Color: "text-green-700",
                  Icon: "fa fa-solid fa-cloud-arrow-down text-green-700  bg-green-100 w-6 ",
                  name: "Download",
                  action: props.FilOnclick,
                },
              ]}
            ></NVLRapidModal>
          )}
          <input ref={imgageControl} className="pr-4 text-xs hidden" id={`${props.id ? props.id : "getFile"}`} accept={props.format} type="file" onChange={props.onChange} />
        </div>
      </div>
    </>
  );
}
export default NVLFileUpload;