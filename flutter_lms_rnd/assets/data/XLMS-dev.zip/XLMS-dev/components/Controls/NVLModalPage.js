import NVLRichTextBox, { getContents, setContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLPannelResiziable from "@Controls/NVLPannelResiziable";
import { useState } from "react";
import NVLButton from "./NVLButton";
import NVLlabel from "./NVLlabel";
export default function NVLModalPage(props) {
  const [Message, setMessage] = useState("");
  function InsertText() {
   const RichText = getContents(Message);
    const Tage = (
      <NVLPannelResiziable key={props.text.length + 1} HeaderContent={RichText}></NVLPannelResiziable>
    );
    props.setText([...props.text, Tage]);
      props.setOpen();
    setHTMLContents("", Message);
    
    
  }
  return (
    <div className={props.open ? "relative z-10" : "hidden"} >
      <div >
        <div className={props.open ? "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" : "hidden"} />
      </div>
      <div className="fixed z-10 inset-0 overflow-y-auto">
        <div className="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0">
          <div className="relative bg-white  rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 w-full md:w-[500px]">
            <div className="flex justify-between m-3">
              <h6 className="font-semibold text-gray-700">
                {props.name}
              </h6>
              <i onClick={() => props.setOpen(!props.open)} className="fa-solid fa-xmark text-red-600 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-red-100"></i>
            </div>
            <div className="bg-white">
              <NVLRichTextBox id="txtInsertText" value="" Link={true} className={"isResizable !nvl-Def-Input mx-2 border-8 rounded-xl"} setState={setMessage} />
            </div>
            <div className="pt-2 flex gap-6 font-semibold p-2">
                <div className="gap-4 flex flex-wrap text-2xl">
                {props?.NotificationData && Array.from(props?.NotificationData)?.map((fieldsData,index) => {
                    return (
                      <>
                      <div key={index}>
                        <NVLlabel
                          id="lblUserName"
                          className="NotifyItems text-lg"
                          text={fieldsData?.[1]}
                          onClick={() => {
                            setContents("{" + fieldsData?.[0] > 0 ? fieldsData?.[0] : "{" + fieldsData?.[1]  + "}", Message);
                          }}
                        />
                        </div>
                      </>
                    )
                  })}
                </div>
              </div>
            {/* <div className="pt-2 flex gap-6 font-extrabold px-4">
              <div>
                <NVLlabel id="lblUserID" className="NotifyItems" text="UserID" onClick={() => { setContents("${UserID}", Message); }} />
              </div>
              <div>
                <NVLlabel id="lblUserName" className="NotifyItems" text="UserName" onClick={() => { setContents("${UserName}", Message); }} />
              </div>
              <div>
                <NVLlabel id="lblEmailID" className="NotifyItems" text="EmailID" onClick={() => { setContents("${EmailID}", Message); }} />
              </div>
              <div>
                <NVLlabel id="lblEmailID" className="NotifyItems" text="Profile Field" onClick={() => { setContents("${ProfileField}", Message); }} />
              </div>
              <div>
                <NVLlabel id="lblEmailID" className="NotifyItems" text="Course Field" onClick={() => { setContents("${CourseField}", Message); }} />
              </div>
            </div> */}

            <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
              <NVLButton type="button" className="w-full inline-flex justify-center rounded-full border border-transparent shadow-sm px-3 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm" onClick={InsertText}>
                Insert
                <i className="fa fa-solid fa-feather-pointed fa-lg p-2"></i>
              </NVLButton>
            </div>
          </div>
        </div>
      </div>

      {/* modal close */}
    </div>
  );
}