import React, { useEffect, useRef } from "react";

export default function NVLToolTip(props) {
  const text = useRef(null);
  useEffect(() => {
    text.current.innerHTML = props.PopDetail;
  })
  return (
    <div className={"relative flex flex-col  group"}>
      <i className={props.PopIcon}></i>
      <div className={`absolute ${props.top != undefined ? "top-0" : "bottom-0 "} ${props.CustomCss} flex-col hidden mb-6 group-hover:flex w-72 `}>
        <div className={`break-words flex shadow-md gap-6 rounded overflow-hidden divide-x max-w-2xl   bg-gray-400 `}>
          <div className="flex flex-1 flex-col p-4 dark:border-violet-400">
            <span className="text-xs dark:text-white" ref={text}></span>
          </div>
        </div>
        {props.top == undefined &&
          <div>
            <div className={`w-3 h-3 -mt-2 rotate-45 ${props.CustomCss != "" ? "" : "bg-gray-400"} relative left-1`}>
            </div>
          </div>
        }
      </div>
    </div>
  );
}
