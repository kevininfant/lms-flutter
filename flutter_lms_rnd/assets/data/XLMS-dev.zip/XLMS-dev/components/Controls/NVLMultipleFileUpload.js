import NVLlabel from "@components/Controls/NVLlabel";
import { APIGatewayPutRequest } from "DBConnection/ErrorResponse";
import { Auth } from "aws-amplify";
import { useCallback, useState } from "react";
import NVLFileUpload from "./NVLFileUpload";
import NVLLoader from "./NVLLoader";

export default function NVLMultipleFileUpload({ TenantInfo, finalFileValidtion, id, fileError, FileValues, setFileValues, setValue, register, FileError, errors, watch, LoaderId, ValidateError }, props) {
  const [isUpload, setisUpload] = useState(false);
  const [getIndex, setIndex] = useState()

  const getContentType = (Extension) => {
    switch (Extension) {
      case "mkv":
        return "video/x-matroska";
      case "avi":
        return "video/x-ms-video";
      case "mov":
        return "video/quicktime";
      case "wmv":
        return "video/x-ms-wmv";
      case "mp4":
        return "video/mp4";
      case "mpeg4":
        return "video/mpeg4";
      case "txt":
        return "text/plain";
      case "xls":
        return "application/vnd.ms-excel";
      case "ppt":
        return "application/vnd.ms-powerpoint";
      case "pptx":
        return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
      case "xlsx":
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      case "docx":
        return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
        case "doc":
          return "application/msword";
      default:
        return "application/" + Extension;
    }
  };

  //fileREname
  const fileRename = useCallback((files) => {
    let fileName = files?.name.split(".")[0];
    let guid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (c) {
        var r = (Math.random() * 16) | 0,
          v = c == "x" ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }
    );
    let ext = files?.name.split(".").pop();
    let ContentType =
      ext == "csv"
        ? "text/" + ext
        : ext == "jpeg" || ext == "jpg" || ext == "png"
          ? "image/" + ext
          : getContentType(ext);

    let filechanges = new File([files], fileName + "-" + guid + "." + ext, {
      type: ContentType,
      lastModified: Date.now(),
    });
    return filechanges;
  }, []);



  //fileValidation
  const fileValidation = useCallback((e, index) => {

    if (e.target.files.length == 0) {
      return;
    }
    let fileInput = document.getElementById(e.target.id);

    let filePath = fileInput.value;

    let getFile = fileRename(e.target.files[0]);
    let allowedExtensions = /(\.csv|\.txt|\.doc|\.docx|\.pdf|\.jpeg|\.jpg|\.png|\.xlsx|\.xls|\.pptx|\.ppt)$/i;
    if (!allowedExtensions.exec(filePath) || fileInput == null) {
setValue("dynamicError","invalid file type")
      fileInput.value = "";
      setFileValues((FileValues) => {
        FileValues[index] = {
          ...FileValues[index],
          FileName: "Select File",
          FileSize: 0,
          PathChanged: false,
          id: id + index,
    FilePath:""

        };

        return FileValues;
      });

      return false;
    }

    else {
      setValue("load",true)
    
      UploadFile(getFile, index)

    }

  }, [UploadFile, fileRename, id, setFileValues, setValue])


  //uploading files
  const UploadFile = useCallback((getFile, index) => {

    setIndex("load" + index)

    setisUpload(true);
    const file = getFile;
    const fileReader = new FileReader()
    fileReader.onload = async function (getFile) {
      let isFileDataCheck = false;
      if (!isFileDataCheck) {
        let fetchUrl = process.env.APIGATEWAY_URL_UPLOAD_FILE_TRAINING +
          `?TenantId=${TenantInfo?.TenantID}&FileName=${file.name}&BucketName=${TenantInfo?.BucketName}&RootFolder=${TenantInfo?.RootFolder}&Page=Glossary&S3BucketName=${TenantInfo?.BucketName}&S3KeyName=${TenantInfo?.RootFolder}/${TenantInfo?.TenantID}`

        let GroupMenuName = "GlossaryManagement";
        let MenuID = "110303"
        let headers = {
          method: "GET",
          headers: {
            authorizationtoken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
            defaultrole: TenantInfo.UserGroup,
            groupmenuname: GroupMenuName,
            menuid: MenuID,
          }
        }
        let Extension = file.name?.substring(file.name.lastIndexOf(".") + 1).toLowerCase();
        let ContentType =
          Extension == "csv"
            ? "text/" + Extension
            : Extension == "jpeg" || Extension == "jpg" || Extension == "png"
              ? "image/" + Extension
              : getContentType(Extension);

        let presignedHeader = {
          method: "PUT",
          headers: {
            "content-type": ContentType,
            defaultrole: TenantInfo.UserGroup,
            groupmenuname: GroupMenuName,
            menuid: MenuID,
          },
          body: file,
        };

        let FinalStatus = await APIGatewayPutRequest(fetchUrl, headers, presignedHeader);
        if (FinalStatus[0] != "Success") {
          setFileValues((FileValues) => {
            FileValues[index] = {
              ...FileValues[index],
              FileName: "Select File",
              FileSize: 0,
              PathChanged: false,
              id: "",
              FilePath:""
            };
            return FileValues;
          });
          setisUpload(false);
          setValue("load",false)

       
          return;
        } else {
          setValue("File", "exist", { shouldValidate: true });
          setFileValues((FileValues) => {
            FileValues[index] = {
              ...FileValues[index],
              FileName: file.name,
              FileSize: file.size,
              PathChanged: false,
              FilePath:"",
              id: id + index

            };
            return FileValues;
          });
        
        }
      }
      setisUpload(false);
      setValue("load",false)

    }
    setisUpload(false);
    fileReader.readAsText(file);


  }, [TenantInfo?.BucketName, TenantInfo?.RootFolder, TenantInfo?.TenantID, TenantInfo.UserGroup, id, setFileValues, setValue])


  //add files 

  const AddCustomFields =() => {
    if (isUpload) {
      return;
    }
    let isAdd = true;
    let tempFiles = [];
    FileValues.map((e, index) => {
      tempFiles = [
        ...tempFiles,
        {
          FileName: e.FileName,
          FileSize: e.FileSize,
          PathChanged: e.PathChanged,
          FilePath:e.FilePath,
          id: e.id
        },
      ];
    });


    tempFiles.map((e, index) => {
      if (
        (e.FileName == "Select File") || (e.FileName == "") ||
        (e.FileName == null)
      ) {
        isAdd = false;
        return;
      }

    });

    if (isAdd) {
      tempFiles = [
        ...tempFiles,
        {
          FileName: "Select File",
          FileSize: 0,
          PathChanged: false,
          FilePath:"",
          id: ""
        },
      ];
      setFileValues(tempFiles);
           setValue("dynamicError", "")
    }else{
    
       setValue("dynamicError","File cannot be added unless file is uploaded")
       return
    }

  }

  //reset data
  const ResetData = useCallback(
    (ResetValue) => {
      let tempFiles = [];
      ResetValue?.map((e, index) => {
        tempFiles = [
          ...tempFiles,
          {
            FileName: e.FileName,
            FileSize: e.FileSize,
            PathChanged: e.PathChanged,
            FilePath:"",
            id: id + index
          },
        ];
      });
      return tempFiles;
    },
    [id]
  );
  const deleteField = useCallback(
    (e, index) => {
      if (!(index == 0 && FileValues.length == 1)) {
        let tempData = ResetData(FileValues);
        tempData.splice(index, 1);
        setFileValues(tempData);
        setValue(id + index, "");
          
      }
      setValue("dynamicError", "")
      setValue("add",true)
    },
   
    [FileValues, ResetData, id, setFileValues, setValue]
  );

  return (
    <>
      {FileValues && FileValues.map((message, index) => {
        return (
        
            <div className="flex" key={index}>
              <div className=" py-2 flex relative" >

                <NVLFileUpload

                  id={message.id}
                  className="nvl-non-mandatory"
                  isLoader={true}
                  loaderID={"loader" + index}
                  tooltip={
                    message?.FileName != null
                      ? message?.FileName
                      : "Select File"
                  }
                  text={
                    message?.FileName == null || message.FileName == ""
                      ? message.FileName
                        ? message?.FileName
                        : "Select File"
                      : message.FileName?.length > 12
                        ? message.FileName?.substring(0, 12) + "..."
                        : message.FileName
                  }
                  errors={errors}
                  register={register}
                  onChange={(e) => fileValidation(e, index)}
                />
{(watch("load")&& getIndex=="load"+index)?
<NVLLoader className="absolute  top-4 right-6" id={`load${index}`} />:""}
              </div>
              
              <div className={`p-2 ${index == 0 ? "hidden" : ""}`}>
                <NVLlabel
                  key={index}
                  className={`relative  cursor-pointer h-8 w-8 shadow-lg bg-red-100   inline-block text-red-600  rounded-full `}
                  id="todo__delete"
                  onClick={(e) => deleteField(e, index)}
                >
                  <i className="fa-solid fa-trash absolute top-2.5 left-2.5 text-sm"></i>
                </NVLlabel>
              </div>
              {FileValues?.length == index + 1 && <div
                id="app"
                className={`p-2 ${FileValues.length > 1 ? "-right-28" : "-right-16"
                  } `}

              >
               {watch("add")? <NVLlabel
                  onClick={() => AddCustomFields()}
                  className="cursor-pointer text-xs  bg-blue-100  shadow-lg text-blue-600 font-bold rounded-full h-8 w-8"
                >
                  <i className="fa-solid fa-plus relative left-2.5 top-2 text-sm pointer-events-none"></i>
                </NVLlabel>:""}
              </div>}
            </div>
        
        )
      })}
      <div className={"text-red-500 text-sm"} id={fileError}>
        {FileError}
      </div>
    </>
  )
}

