import { Link } from "@aws-amplify/ui-react";
import { Menu, Transition } from "@headlessui/react";
import router from 'next/router';
import { Fragment, useMemo } from "react";
import NVLImage from "./NVLImage";

const NVLProfileSelect = ({ UserProfilePath, ChangePassword, TenantInfo, LogOut, FirstName }) => {
  const UserCostomFields = useMemo(() => {
    let TempLogo;
    if (UserProfilePath && UserProfilePath != "") {
      TempLogo = <NVLImage className="rounded-full overflow-hidden shadow-lg hover:scale-125 ease-in duration-500 cursor-pointer" src={UserProfilePath ? UserProfilePath : "/defaultphoto.jpg"} alt="profile" title="Profile" height={35} width={35} tabIndex={8} />;
    } else if (TenantInfo?.UserGroup == "SiteAdmin") {
      TempLogo = <NVLImage className="rounded-full overflow-hidden shadow-lg hover:scale-125 ease-in duration-500 cursor-pointer" src={"/defaultphoto.jpg"} alt="profile" title="Profile" height={35} width={35} tabIndex={8} />
    } else {
      TempLogo = <div className="m-1 mr-2 w-9 h-9 relative flex justify-center items-center rounded-full bg-blue-600 text-xl text-white uppercase">{TenantInfo.UserGroup == "CompanyAdmin" ? TenantInfo?.TenantName?.split('')[0] : FirstName?.split('')[0]}</div>
    }
    return TempLogo;
  }, [FirstName, TenantInfo?.TenantName, TenantInfo.UserGroup, UserProfilePath])

  return (
    <>
      <Menu as="div" className="relative inline-block text-left">
        <div>
          <Menu.Button className="">{UserCostomFields}</Menu.Button>
        </div>
        <Transition
          as={Fragment}
          enter="transition ease-out duration-100"
          enterFrom="transform opacity-0 scale-95"
          enterTo="transform opacity-100 scale-100"
          leave="transition ease-in duration-75"
          leaveFrom="transform opacity-100 scale-100"
          leaveTo="transform opacity-0 scale-95"
        >
          <Menu.Items className="absolute right-0 z-10 mt-2 w-56 origin-top-right rounded-md bg-white shadow-lg  focus:outline-none">
            <div className="absolute right-0 z-10 mt-2 w-56 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none" role="menu" aria-orientation="vertical" aria-labelledby="menu-button" tabIndex="-1">
              <div className="py-1 " role="none">
                {TenantInfo?.UserGroup != "SiteAdmin" && (<Link className="text-gray-700 px-4 py-2 text-sm flex gap-4 hover:bg-gray-100" onClick={() => router.push(`/Home/ViewProfile?Type=${TenantInfo?.UserGroup}`)} >
                  <i className="fa-solid fa-user my-auto text-gray-600"></i>View Profile
                </Link>)}
                <Link className="text-gray-700 px-4 py-2 text-sm  flex gap-4 hover:bg-gray-200" onClick={ChangePassword} >
                  <i className="fa-solid fa-key my-auto text-gray-600"></i> Change Password
                </Link>
              </div>
              <div className="py-1" role="none">
                <Link className="text-gray-700 px-4 py-2 text-sm  flex gap-4 hover:bg-gray-200" onClick={LogOut} >
                  <i className="fa-solid fa-right-from-bracket my-auto text-gray-600"></i> SignOut
                </Link>
              </div>
            </div>
          </Menu.Items>
        </Transition>
      </Menu>
    </>
  );
};

export default NVLProfileSelect;
