import NVLButton from './NVLButton';
import NVLImage from './NVLImage';
import NVLlabel from './NVLlabel';

export default function NVLCertificateCard(props) {
  // const refHide = useRef(false);
  return (<div className={`group relative bg-white rounded overflow-hidden shadow-lg hover:-translate-y-1 hover:shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] ease-in duration-150 cursor-pointer border-b-4 ${props?.IsAvailable ? "border-[#28a745]" : "border-[#dc3545] opacity-70"} `}>
    <div className={`w-[150px] h-[150px] absolute top-[-5px] left-[-5px] overflow-hidden z-50 `}>
      <span className={`text-xs absolute top-[30px] right-0 w-[225px] ${props?.IsAvailable ? "bg-[#28a745]" : "bg-[#dc3545] text-black"} text-white text-center shadow-md -rotate-45`}>{props?.IsAvailable ? "Completed" : "Incomplete"}</span>
    </div>
    <div className='!h-32 relative overflow-hidden group'>
      <NVLImage className="hover:bg-blend-saturation h-full w-full duration-500" src={`${(props?.imagePath && props?.IsAvailable) ? props?.imagePath : "/preview-certificate.jpg"}`} alt="Course" />
      {props?.IsAvailable && <div className="bg-[rgba(0,0,0,0.34)] z-50 flex items-end justify-center  text-white absolute -top-[100%] h-[100%] w-[100%] ease-in duration-300 group-hover:top-0 text-center text-[10px] p-2">
        <div className=" justify-center flex gap-2 ">
          <NVLButton onClick={props?.ViewCertificate} id="btnSend" text={"View"} type="submit" className={`nvl-button nvl-button-success text-white w-28`}>
            <i className="fa-solid fa-expand ml-2 "></i>
          </NVLButton>
          <NVLButton onClick={props?.DownloadCertificate} id="btnDownload" text={"Download"} type="submit" className={`nvl-button w-28 bg-primary text-white !text-[10px]`}>
            <i className="fa-solid fa-circle-down ml-2 "></i>
          </NVLButton>
        </div>
      </div>}
    </div>
    <div className="bg-slate-200 w-full flex justify-center">
      <NVLlabel text={props?.CertificateData?.[props?.indexNo]?.CertificateName} className="nvl-Def-Label py-2" />
    </div>
  </div>
  )
}
