import NVLlabel from "@components/Controls/NVLlabel";
import { APIGatewayPostRequest } from "DBConnection/ErrorResponse";
import { useCallback, useState } from "react";

export default function NVLCard({ data, editGlossaryData, deleteData, role, bucketName, token }) {

  const [IsShowFileMore, setIsShowFileMore] = useState(true);
  const [fileLength, setFileLength] = useState(2)
  const onButtonClick = useCallback(async (path) => {
      let fetchURL = process.env.APIGATEWAY_INVOKEURL;

      let headers = {
        method: "POST",
        headers: {
          authorizationtoken: token,
          bucketName: bucketName,
        },
        body: path.substring(1),
      };

      let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
      const handleDownload = (url) => {
        fetch(url).then(response => {
          response.blob().then(blob => {
            const fileURL = window.URL.createObjectURL(blob);
            let link = document.createElement('a');
            let temp = path.split("/")
            link.href = fileURL;
            link.download = temp.at(-1);
            link.click();
            link.remove();
          })
        })
      };
      handleDownload(await FinalStatus.res?.text())

  }, [bucketName, token])
  const handleFile = () => {
    setIsShowFileMore((prev) => !prev)
    setFileLength(JSON.parse(data?.AttachFile).length)
    if (IsShowFileMore == false) {
      setFileLength(2)
    }
  }
  return (
    <div className='border-2 border-gray-300 p-2'>
                <NVLlabel text={data?.ConceptName} className="!text-2xl" />
      
      <div className="pt-2 text-justify px-8">
        <NVLlabel text={data?.Definition.replaceAll(/(<([^>]+)>)/gi, "").replaceAll(/&amp;/g, "&").replaceAll(/&nbsp;/g, ' ')}/>
        </div>
      <hr></hr>
      {role == "User" ?
        <div className="flex justify-between">
          <div className="flex p-2">
            <div className="text-tiny py-5" >Keyword(s):</div>
            {JSON.parse(data?.Keywords).length != 0 ?
              <div className="my-1 border-2 border-slate-300 h-14 w-52 relative overflow-y-scroll">
                {data?.Keywords != undefined && JSON.parse(data?.Keywords).map((txt, index) => {
                  return (
                    <div key={index}>
                      <div className="p-1"> 
                           <NVLlabel text={txt.text}/>
                      </div>
                    </div>
                  )
                })
                }
              </div> : <div className="pt-[21px] pl-2">Keywords are not provided</div>}
          </div>
          <div>
            <div className="text-tiny pt-5">
              File(s):
            </div>
            {JSON.parse(data?.AttachFile)[0].FileName != "" ?
              <>
                {JSON.parse(data?.AttachFile).map((file, index) => {
                  return (
                    <div key={index}>
                      {index < fileLength && <div className="text-primary  hover:cursor-pointer " onClick={() => onButtonClick(file.FilePath)} >{file.FileName.split("-")[0] + "." + file.FileName.split(".").pop()}</div>}
                    </div>
                  )
                })}
                <div className='pt-2'>
                  {JSON.parse(data?.AttachFile).length > 2 && <span className="text-amber-900 pl-2" onClick={handleFile}>
                    {`${IsShowFileMore ? "More Files" : "Less Files"}`}
                  </span>}
                </div>
              </>
              : <div className="pt-1 ">Files are not provided</div>}
          </div>
        </div>
        :
        <div className="flex justify-between">
          <div className="flex p-2">
            <div className="text-tiny py-5" >Keyword(s):</div>
            {JSON.parse(data?.Keywords).length != 0 ?
              <div className="my-1 border-2 border-slate-300 h-14 w-52 relative overflow-y-scroll">
                {data?.Keywords != undefined && JSON.parse(data?.Keywords).map((txt, index) => {
                  return (
                    <div key={index}>
                      <div className="p-1"><NVLlabel text={txt.text}/></div>
                    </div>
                  )
                })
                }
              </div> : <div className="pt-[21px] pl-2">Keywords are not provided</div>}
          </div>
        <div className="flex justify-end pt-6">

          <div className="cursor-pointer" onClick={deleteData}>
            <i className="fa-solid fa-trash fa-lg relative left-2 top-1 pr-4 text-red-600 "></i>
          </div>
          <div className="cursor-pointer" onClick={editGlossaryData} >
            <i className="fa-solid fa-pencil  fa-lg relative left-2 top-1 pr-4 text-blue-600 "></i>
          </div>
        </div>
        </div>
      }

    </div >
  )
}

