import React from "react";

function NVLToggle(props) {
  return (
    <>
      <div className="nvl-Toggle">
        <label className="toggler-wrapper style-1">
          <input type="checkbox" 
          // {...props.register(props.id, { shouldValidate: true })}
          defaultChecked={props.defaultChecked} 
          id={props.id} 
          checked={props.checked} 
          name={props.name} 
          onClick={props.onClick} 
          onChange={props.onChange} />
          <div className="toggler-slider">
            <div className="toggler-knob"></div>
          </div>
        </label>
      <div className='{invalid-feedback} text-red-500 text-sm w-4/5 pt-1'>{props?.errors?.[props.id]?.message}</div>
      </div>
    </>
  );
}

export default NVLToggle;
