import React from "react";
import NVLImage from "@components/Controls/NVLImage";

function NVLLoadingImage(props) {
  return (
    <>
      <div className={props.IsLoad ? "" : "hidden"}>
        <NVLImage src={"/nvl-loader.gif"} />
      </div>
    </>
  );
}

export default NVLLoadingImage;
