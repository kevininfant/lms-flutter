import React, { useEffect } from "react";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLRadio from "./NVLRadio";
import { DateTime } from "@Pages/ActivityManagement/CommonActivitySettings/ActivityComponents";

function NVLMultiOptionField({setValue,id,value,className,disabled,Datecontrol,ControlType,ControlOptions,labelText,title,errors,register}) {

    
    let today = new Date();
    let DateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T" + today.getHours() + ":" + (today.getMinutes() > 9 ? today.getMinutes() : "0" + today.getMinutes()); 
  
    useEffect(() => {
        if (setValue != undefined && value!=undefined)
            setValue(id, value)
    }, [setValue,value,id])
    return (
        <>
            {ControlType == "Checkbox" ? (
                ControlOptions.map((Options, index) => {
                    if (Options.value)
                        return (
                            <div className="gap-3" key={index}>
                                <NVLCheckbox id={id + "" + index} name={id + "" + index} text={Options.text} value={Options.value} errors={errors} register={register}  ></NVLCheckbox>
                            </div>
                        );
                })
            ) : ControlType == "DateOrTime" ? (
                <>
                    <div className="gap-3" >
                        <NVLTextbox min={Datecontrol != "Past" ? DateTime :""}  max ={Datecontrol == "Past" ? DateTime :""}labelText={labelText} disabled={disabled!=undefined?disabled:false} labelClassName="nvl-Def-Label" title={title} id={id} errors={errors} register={register} type="datetime-local" className={`nvl-Def-Input ${className != undefined ? className : ""} ${disabled!=undefined && disabled?"Disabled":""}`} />
             
                    </div>
                </>
            ) : ControlType == "DropdownMenu" ? (
                <>
                    <NVLSelectField labelText={labelText} disabled={disabled!=undefined?disabled:false} labelClassName="nvl-Def-Label" title={title} id={id} options={ControlOptions} errors={errors} register={register} className={`nvl-Def-Input ${className != undefined ? className : ""} ${disabled!=undefined && disabled?"Disabled":""}`} />

                </>
            ) : ControlType == "TextInput" ? (
                <>
                    <NVLTextbox labelText={labelText} disabled={disabled!=undefined?disabled:false} labelClassName="nvl-Def-Label" title={title} id={id} errors={errors} register={register} className={`nvl-Def-Input ${className != undefined ? className : ""} ${disabled!=undefined && disabled?"Disabled":""}`} />
                </>
            ) : ControlType == "TextArea" ? (
                <>
                    <NVLMultilineTxtbox labelText={labelText} disabled={disabled!=undefined?disabled:false} labelClassName="nvl-Def-Label" title={title} id={id} errors={errors} register={register} className={`nvl-Def-Input ${className != undefined ? className : ""} ${disabled!=undefined && disabled?"Disabled":""}`} />
                </>
            ) : ControlType == "RadioButton" ? (
                <>
                    {ControlOptions.map((Options, index) => {
                        return (
                            <div key={index} className="gap-3">
                                <NVLRadio id={id + "" + index} text={Options.text} value={Options.value} errors={errors} register={register} />
                            </div>
                        );
                    })}
                </>
            ) : (
                <></>
            )}
        </>
    );

}

export default NVLMultiOptionField;