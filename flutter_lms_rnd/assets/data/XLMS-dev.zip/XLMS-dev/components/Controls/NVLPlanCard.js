import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";

const PlanCard = (props) => {
  const { Symbol, PlanAmount, PlanDetail, displayStep } = props;
  function redirect(PlanHeadertxt) {
    displayStep(PlanHeadertxt);
  }

  return (
    <>
      <div className={`${props.activePlan}  nvl-PlanCard `}>
        <div className={`${props.headerStyle} nvl-PlanHeader`}>
          <div className={`${props.priceStyle} nvl-PlanPrice`}>
            <div className="font-normal text-xs dark:text-gray-200 rounded text relative top-2 flex justify-center">
              {Symbol && <NVLlabel className={Symbol && "mb-4 text-xs align-sub"} text={Symbol == "USD" ? "$" : "₹"} />}
              <NVLlabel className={PlanAmount && "mb-4 text-xs font-medium align-sub"} text={PlanAmount} />
            </div>
          </div>
          <NVLlabel text={props.PlanHeadertxt} className="leading-loose text-sm font-bold text-center w-full "></NVLlabel>
        </div>
        <div className="nvl-PlanText">
          <span className={`${props.contentStyle} px-3 py-1 mt-2 rounded`}>{props.PlanText}</span>
          <div className="font-bold">{props.PlanUser}</div>
        </div>

        <div className="nvl-Planfeatures">
          <div className="flex justify-center">
            <svg className={` ${props.contentStyle} h-5 w-5 rounded-full`} stroke="currentColor" fill="none" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
            </svg>
            &nbsp; All features
          </div>

          <div className="flex justify-center">
            <svg className={` ${props.contentStyle} h-5 w-5 rounded-full`} stroke="currentColor" fill="none" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
            </svg>
            &nbsp; Free support
          </div>
        </div>

        <div className="nvl-PlanCard-Footer">
          <NVLButton
            disabled={props.disabled}
            type="button"
            onClick={() => {
              redirect(props.PlanAlt);
            }}
            className={`${props.btnStyle} border  border-blue-400 py-1  hover:${props?.IsDisabled ? "bg-blue-200 !text-blue-400" : "bg-blue-500"} focus:ring-blue-400 focus:ring-offset-indigo-200 w-full transition ease-in duration-200 text-center text-xs font-medium shadow-md focus:outline-none focus:ring-2 focus:ring-offset-2 hover:${props?.IsDisabled ? "!text-blue-400" : "text-white"} rounded-full `}
            text="GET A PLAN"
          ></NVLButton>
        </div>
        <div className="max-w-lg mx-auto">
          <details className="open:bg-white dark:open:bg-slate-900  open:ring-black/5 dark:open:ring-white/10 open:shadow-lg p-6 rounded-lg">
            <summary className="text-xs leading-6 text-slate-900 dark:text-white font-semibold select-none">Show Further</summary>
            <div className="mt-3 text-xs leading-6 text-slate-600 dark:text-slate-400">
              <p>The mug is round. The jar is round. They should call it Roundtine.The mug is round. The jar is round. They should call it Roundtine.</p>
            </div>
          </details>
        </div>
      </div>
    </>
  );
};

export default PlanCard;
