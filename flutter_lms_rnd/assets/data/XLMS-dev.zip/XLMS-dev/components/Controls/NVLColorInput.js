import NVLlabel from "@Controls/NVLlabel";

function NVLColorInput(props) {
  return (
    <div className="w-full">
      {props.icon == undefined && props.labelText ? <NVLlabel text={props.labelText} className={props.labelClassName} /> : ""}
      <input
        value={props.value == undefined ? "" : props.value}
        type={props.type ? props.type : "color"}
        id={props.id}
        placeholder={props.title}
        disabled={props.disabled}
        tabIndex={props.tabIndex}
        min={props.min}
        max={props.max}
        className={`cursor-pointer px-2 pt-1 w-full ${props.className} `}
        onChange={props.onChange}
      />
    </div>
  );
}

export default NVLColorInput;