import NVLlabel from "@Controls/NVLlabel";

function NVLMultilineTxtbox(props) {
  return (
    <div className="grid">
      {props.icon == undefined && props.labelText ? (
        <NVLlabel text={props.labelText} className={props.labelClassName} >{props.className.indexOf("nvl-mandatory")!=-1&& <span className="text-red-500 text-lg">*</span>}</NVLlabel>
      ) : (
        ""
      )}
      <div className=" relative">
        <textarea
          id={props.id}
          {...props.register(props.id, { shouldValidate: true })}
          placeholder={props.title}
          autoComplete="off"
          disabled={props.disabled}
          className={
            "nvl-Multi-TextBox " +
            props.className +
            "  " +
            (props.errors?.[props.id] ? "border-red " : "  border-gray-300")
          }
        />
      </div>
      <div className="{invalid-feedback} text-red-500 text-sm">
        {props?.errors?.[props.id]?.message}
      </div>
    </div>
  );
}

export default NVLMultilineTxtbox;