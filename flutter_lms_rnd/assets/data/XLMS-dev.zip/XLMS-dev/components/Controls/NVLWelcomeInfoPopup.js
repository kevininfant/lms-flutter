import { Image } from "@aws-amplify/ui-react";
import { useCallback, useState } from 'react';
import ReactPlayer from 'react-player';
import NVLlabel from "./NVLlabel";

export default function NVLWelcomeInfoPopup({ setPopupData, popupData }) {
    const [currentScreen, setcurrentScreen] = useState(0);
    const fileReader = useCallback((id, data) => {
        switch (data?.[id]?.FileType) {
            case "Youtube": return (<>
                <ReactPlayer onContextMenu={e => e.preventDefault()} width="100%" height="500px" url={data?.[id]?.URL} playing={false} controls={true} />
            </>)
            case "URL": return (<>
                <iframe src={data?.[id]?.URL + "#toolbar=0"} width="100%" height="500px"></iframe>
            </>)
            case "Image": return (<>
                <Image download alt="testimonial" className="w-full h-[500px] shadow-xl p-1 my-auto rounded-lg bg-gray-200 inline-block border-gray-200" src={data?.[id]?.FilePath} />
            </>)
            case "Audio": return (<>
                <ReactPlayer onContextMenu={e => e.preventDefault()} width="100%" height="100px" url={data?.[id]?.FilePath} playing={false} controls={true} />
            </>)
            case "Video": return (<>
                <ReactPlayer onContextMenu={e => e.preventDefault()} width="100%" height="500px" url={data?.[id]?.MpdUrlPath} playing={false} controls={true} />
            </>)
            default:
                return null
        }
    }, [],)

    return (
        <div >
            <div className="relative z-10" >
                <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
                <div className="fixed inset-0 z-10 overflow-y-auto">
                    <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                        <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 w-full md:w-[700px]">
                            <div className="px-6 ">
                                <div className="flex justify-between py-4">
                                    <div className="my-auto">
                                        <NVLlabel text={popupData?.[currentScreen]?.PopUpName} className="!text-lg font-semibold" />
                                    </div>
                                    <i onClick={() => { setPopupData([]) }} className="fa fa-solid fa-square-xmark text-blue-600 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-blue-100"></i>
                                </div>
                                {fileReader(currentScreen, popupData)}
                            </div>
                            <div className="bg-gray-50 px-4 py-3 sm:px-6 flex justify-center gap-4">
                                {currentScreen != 0 &&
                                    <i id={"WelcomePrev"} onClick={() => setcurrentScreen((prev) => prev - 1)} className="fa-solid fa-chevron-left text-blue-600 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-blue-100 hover:bg-blue-600 hover:text-white"></i>}
                                {(currentScreen + 1) != popupData?.length && <i id={"WelcomeNext"} onClick={(currentScreen + 1) == popupData?.length ? () => { setPopupData([]) } : () => setcurrentScreen((prev) => prev + 1)} className="hover:bg-blue-600 hover:text-white fa-solid fa-chevron-right text-blue-600 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-blue-100"></i>}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}