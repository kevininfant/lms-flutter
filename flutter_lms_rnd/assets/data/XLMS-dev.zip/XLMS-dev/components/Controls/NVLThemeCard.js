import { useEffect, useState } from "react";
import NVLButton from "./NVLButton";
import Modal from "./NVLDeletePopup";
import NVLlabel from "./NVLlabel";

function NVLThemeCard(props) {
 

  const [BodyBackground, setBackgroud] = useState("#d3d3d3");

  useEffect(() => {
   if(props?.ThemeInfo?.Body!=undefined )
   JSON.parse(props?.ThemeInfo?.Body)?.["--nvl-body-bg-color"] != undefined && JSON.parse(props?.ThemeInfo?.Body)?.["--nvl-body-bg-color"] && setBackgroud(JSON.parse(props.ThemeInfo.Body))
  }, [props.ThemeInfo.Body])
  return (
    <>
      <div className="relative block shadow-lg overflow-hidden border border-gray-100 rounded-lg" href="">
        <span className="absolute inset-x-0 bottom-0 h-1   bg-gradient-to-r from-green-300 via-blue-500 to-purple-600"></span>
        <div className={`${props.ThemeInfo.ThemeMode != "Dark-Theme" && props.ThemeInfo.ThemeMode != "Default-Theme" ? "" : "py-4"}`} id="divBackgroud" style={{ backgroundColor: BodyBackground?.["--nvl-body-bg-color"] == "rgb(255, 255, 255)" ? "rgb(229 231 235)" : BodyBackground?.["--nvl-body-bg-color"] }}>

          <div className="flex justify-end p-4 pt-4">
            { props.ThemeInfo.ThemeMode != "Dark-Theme" && props.ThemeInfo.ThemeMode != "Default-Theme" ?
              <Modal onDelete={props.deleteOnClick} autoChange={props.applyOnClick} Icon={<i style={{ color: BodyBackground?.["--nvl-body-icon-color"] }}
              className="fa-solid fa-trash grid place-content-center h-8 w-8  cursor-pointer rounded-full bg-gray-100"
            ></i>}></Modal> : ""}

          </div>
          <div className="flex flex-col items-center pb-10 ">
            <span style={{ color: BodyBackground?.["--nvl-body-txt-color"] }} className="text-xs">
              <NVLlabel HelpInfo={props.ThemeInfo.ThemeMode} HelpInfoIcon={""} text={props.ThemeInfo.ThemeMode} />
              {/* {props.ThemeInfo.ThemeMode} */}
              
              </span>
          </div>
        </div>
        <div className=" px-6 py-4">
          <div className="grid grid-flow-col gap-4 pt-3 text-xs  text-white font-medium">
            <NVLButton id="btnApply" text={"Apply"} 
            disabled={props.RoleData.apply ? false : true}
              onClick={props.applyOnClick}
              type="submit" className={`${props.RoleData.apply ?  "nvl-button bg-primary text-white " : "nvl-button bg-primary Disabled text-black" }`}/>
            <NVLButton id="btnPreview" onClick={props.preViewOnClick} 
            disabled={props.RoleData.preview ? false : true}
            text={"Preview"} type="submit"
            className={`${props.RoleData.preview ?  "nvl-button bg-primary text-white " : "nvl-button bg-primary Disabled text-black" }`}/>
          </div>
        </div>
      </div>
    </>
  );
}

export default NVLThemeCard;
