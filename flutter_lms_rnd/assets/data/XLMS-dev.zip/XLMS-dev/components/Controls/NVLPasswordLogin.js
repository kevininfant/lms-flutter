import { useEffect, useState } from "react";

export default function NVLPasswordLogin(props) {
  const [type, setType] = useState("password");
  const togglePassword = () => {
    setType((type) => {
      if (type == "text") {
        return "password";
      } else {
        return "text";
      }
    });
  };
  useEffect(() => {
    if (props.changeType)
      setType(() => {
        return "password";
      });
  }, [props.changeType]);
  return (
    <>
      <div className="space-y-2">
        <div className="relative">
          {props?.Captcha ? props?.Captcha : <i className={`fa ${type == "text" ? "fa-eye-slash" : "fa-eye"} text-gray-400 cursor-pointer pr-2 absolute top-3 right-2`} onClick={togglePassword}></i>}
          <input {...props.register(props.id, { shouldValidate: true })} type={type} id={props.id} className="block px-4 pl-10 pb-2.5 pt-2 !pr-10 rounded-full h-9 w-full text-sm text-gray-900 bg-transparent  border-gray-300  appearance-none focus:outline-none focus:ring-0 focus:border-blue-600 focus:font-medium " placeholder={props?.labelText} autoComplete="off" /> 
          {props?.labelClassIcon?props?.labelClassIcon:<svg id="password" width="14" height="18" viewBox="0 0 14 18" className="absolute top-2 left-4">
            <defs>
              <clipPath id="clip-path">
                <rect id="Rectangle_12" data-name="Rectangle 12" width="14" height="18" fill="#1d74ff" />
              </clipPath>
            </defs>
            <g id="Group_4" data-name="Group 4" >
              <path id="Path_32" data-name="Path 32" d="M49.033,6.29a11.185,11.185,0,0,1,.255-3.26,4.553,4.553,0,0,1,4.6-3.013,4.469,4.469,0,0,1,4.123,3.81c.1.807.066,1.63.094,2.462H56.067c0-.062,0-.128,0-.194,0-.574.015-1.15-.008-1.723a2.5,2.5,0,0,0-5-.041c-.027.573-.009,1.149-.011,1.723,0,.074,0,.148,0,.236Z" transform="translate(-46.559 0)" fill="#1d74ff" />
              <path id="Path_33" data-name="Path 33" d="M14,146.276a1.56,1.56,0,0,0-1.666-1.653H1.683A1.563,1.563,0,0,0,0,146.279Q0,150,0,153.717a1.565,1.565,0,0,0,1.676,1.664H12.325A1.563,1.563,0,0,0,14,153.733q0-3.728,0-7.457M7.9,149.749a.418.418,0,0,0-.154.351c.009.531,0,1.062,0,1.593a.756.756,0,1,1-1.509,0c0-.269,0-.537,0-.806,0-.122,0-.244,0-.366,0-.041,0-.081,0-.121a.96.96,0,0,0-.268-.8,1.253,1.253,0,0,1,.176-1.805,1.328,1.328,0,0,1,1.822.126,1.287,1.287,0,0,1-.072,1.821" transform="translate(0 -137.381)" fill="#1d74ff" />
            </g>
          </svg>}
        </div>
        {props.showErros && <div className="{invalid-feedback} text-red-500 text-sm">{props?.errors?.[props.id]?.message}</div>}
      </div>
    </>
  );
}
