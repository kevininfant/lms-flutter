import NVLLink from "@components/Controls/NVLLink";
import { Menu, Transition } from "@headlessui/react";
import { Fragment, useEffect, useRef, useState } from "react";
import { GoTriangleDown } from "react-icons/go";

export default function NVLRapidModal(props) {
  const MenuRef = useRef();
  const [open, setOpen] = useState(false);
  const ClassName = useRef()

  useEffect(() => {
    if (open) {
      var height = window.innerHeight;
      var top = MenuRef.current.getBoundingClientRect()?.top;
      ClassName.current.className = "block";
      var tooltiph = MenuRef?.current?.childNodes[0]?.clientHeight;
      if (tooltiph - top > 0) {
        ClassName.current.className = `block absolute z-50 max-w-sm -translate-y-7 -translate-x-full transform sm:px-0 lg:max-w-3xl`;
      }
      else if (top + tooltiph > height) {
        ClassName.current.className = `block absolute z-50 max-w-sm -translate-y-full -translate-x-full transform sm:px-0 lg:max-w-3xl`;
      }
      else{
        ClassName.current.className = `block absolute z-50 max-w-sm -translate-y-7 -translate-x-full transform sm:px-0 lg:max-w-3xl`;
      }
    }
    else {
      ClassName.current.className = "hidden";
    }
  }, [open])

  return (
    <>
      <Menu as="div" className="MenuHead" onMouseLeave={() => setOpen(false)} >
        <div className="MenuButton">
          <Menu.Button className="MenuButtonCss">
            {props.CustomIcon ?
              <i className="fa fa-plus h-5 w-8" onClick={() => { setOpen(data => !data) }} /> :
              <GoTriangleDown id={"Action" + props.id} className="text-lg ml-2" onClick={() => { setOpen(data => !data); }} />
            }
          </Menu.Button>
        </div>
        <div id={props.id} className={`h-full !bg-primary`} ref={MenuRef} >
          <Transition as={Fragment} show={true} enter="TransitionEnter" enterFrom="TransitionFrom" enterTo="TransitionTo" leave="TransitionLeave" leaveFrom="TransitionLeaveFrom" leaveTo="TransitionLeaveTo">
            <div ref={ClassName} >
              {props.ActionList != undefined &&
                props?.ActionList?.map((getItem, index) => (
                  <div className="overflow-hidden rounded shadow-lg w-48 ring-1 ring-black ring-opacity-5 cursor-pointer" key={index} onClick={getItem.action}>
                    <div className="relative grid bg-white">
                      <Menu.Item key={index} className={`text-gray-900 w-screen px-1 ${getItem?.MenuCss}`}>
                        <NVLLink Icon={getItem.Icon} textColor={getItem.Color} onClick={getItem.action} text={getItem.name == "ScormPackage" ? "SCORM Package" : getItem.name
                        }></NVLLink>
                      </Menu.Item>
                    </div>
                  </div>
                ))}
            </div>
          </Transition>
        </div >
      </Menu >
    </>
  );
}