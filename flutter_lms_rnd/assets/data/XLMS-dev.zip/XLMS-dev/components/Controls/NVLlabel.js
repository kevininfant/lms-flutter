import NVLToolTip from "./NVLToolTip";

function NVLlabel(props) {
  return (
    <div className="flex gap-2">
      <label
        id={props.id}
        htmlFor={props.htmlFor}
        className={"text-xs " + props.className}
        placeholder={props.placeholder}
        maxLength={props.maxLength}
        textDecoration={props.textDecoration}
        onClick={props.onClick}
        color={props.color}
        fontWeight={props.fontWeight}
        fontStyle={props.fontStyle}
        fontSize={props.fontSize}
        title={
        props?.tooltip != undefined ? props?.tooltip?.toString()?.replace(/\s{2,}(?!\s)/g, ' ')?.trim() : 
        props.text?.length > 35 && props.showFull == undefined  ? props.text?.toString()?.replace(/\s{2,}(?!\s)/g, ' ')?.trim() :""}
        >
        {props.text?.length > 35 && props.showFull == undefined ? (props?.text?.substring(0, 30) + "...") : props.text}
        {props.children}
      </label>
      {props.HelpInfo &&
        <NVLToolTip PopDetail={props.HelpInfo} PopIcon={props.HelpInfoIcon} CustomCss={props.CustomCss} ></NVLToolTip>}
    </div>
  );
}

export default NVLlabel;
