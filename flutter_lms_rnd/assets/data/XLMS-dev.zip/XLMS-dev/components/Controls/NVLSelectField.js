import NVLlabel from "@Controls/NVLlabel";
function NVLSelectField(props) {
  return (
    <>
      {props.icon == undefined && props.labelText ? <NVLlabel text={props.labelText} showFull className={props.labelClassName} >{props.className.indexOf("nvl-mandatory") != -1 && <span className="text-red-500 text-lg">*</span>}</NVLlabel> : ""}
      <div className="relative">
        <select
          id={props.id}
          className={"nvl-SelectField " + props.className + "  " + (props.errors?.[props.id] ? "border-red " : "  border-gray-300")}
          autoComplete="off"
          disabled={props.disabled}
          tabIndex={props?.className?.includes("Disabled") ? "-1" : props?.tabIndex}
          ref={props?.ref}
          {...props.register(props.id, { shouldValidate: true })}>
          {createOptions(props.options, props.showFull)}
        </select>
      </div>
      {props?.errors?.[props.id]?.message && <div className='{invalid-feedback} text-red-500 text-sm'>{props?.errors?.[props.id]?.message}</div>}
    </>
  );
}


function createOptions(options, FullText) {
  let opts = [];
  options &&
    options?.map((opt) => {
      opts.push(
        <option key={opt.value} value={opt.value} title={opt?.text?.toString().replace(/\s{2,}(?!\s)/g, ' ').trim()} className={"w-full"}>
          {(opt.text?.toString().length > 35 && !FullText) ? opt.text?.toString().replace(/\s{2,}(?!\s)/g, ' ').trim().substring(0, 25) + "..." : opt.text?.toString().replace(/\s{2,}(?!\s)/g, ' ').trim()}
        </option>
      );
    });
  return opts;
}
export default NVLSelectField;