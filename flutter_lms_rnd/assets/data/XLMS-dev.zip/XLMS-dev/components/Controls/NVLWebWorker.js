import { GetDateFormat } from '@components/Common/DateFormat';
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useCallback, useEffect, useRef, useState } from 'react';
import { createXlmsActivityLiveCountInfo } from 'src/graphql/mutations';

export default function NVLWebWorker({props}) {
    const [count, setCount] = useState(0)
    const currentDate = new Date();
    const startOfDay = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
    const timeSpanMs = useRef()
    timeSpanMs.current = currentDate.getTime() - startOfDay.getTime();
    const DateFormat = GetDateFormat(currentDate, "dd-mm-yyyy")
    const getting = useCallback(async (i) => {
        let Variables = {
            input: {
                PK: "XLMS#LIVEACTIVITYUSER",
                SK: "TIMESPAN#" + DateFormat + "#TENANT#" + props?.TenantInfo?.TenantID + "#ACTIVITYID#" + props?.ActivityData?.ActivityID + "#" + props?.user?.attributes.sub,
                Count: timeSpanMs.current,
                ActivityType: props?.ActivityData?.ActivityType,
                AutoDelete: timeSpanMs.current + 5,
                TenantName: props?.TenantInfo?.TenantName,
            }
        }
        let FinalStatus = (await AppsyncDBconnection(createXlmsActivityLiveCountInfo, Variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        return FinalStatus
    }, [DateFormat, props, timeSpanMs])
    
    useEffect(() => {
        let i = 0;
        function GetTimer() {
            setCount(i);
            i++;
            let w;
            if (typeof (Worker) != undefined) {
                if (typeof (w) == "undefined") {
                    w = new Worker(getting(i));
                }
            } else {
                console.log("Sorry! No Web Worker support.")
            }
        }
        const interval = setInterval(GetTimer, 300000); //300000
        return () => clearInterval(interval);
    }, [getting])


    return (
        <div>
            {/* {console.log("Its me"+count)} */}
        </div>
    )
}
