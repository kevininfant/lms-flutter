import NVLTextbox from "@components/Controls/NVLTextBox";
import React, { useCallback } from "react";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLButton from "@components/Controls/NVLButton";

export default function NVLCustomTxtBoxField({ NoOfField, errors, Optionslength, setOptionlength, setValue, id, watch, title, register }) {
  const AddCustomFields = () => {
    setOptionlength((data) => {
      return data + 1;
    })
  };

  const deleteField = useCallback((id, setValue, watch,NoOfField,textId) => {
    for (let i = id; i < Optionslength - 1; i++) {
      setValue(textId + i, watch(textId + (i + 1)));
      if (NoOfField == 2) {
        setValue(textId + "-" + i, watch(textId + "-" + (i + 1)));
      }
    }
    setOptionlength((data) => {
      setValue(textId + (data - 1), "");
      if (NoOfField == 2) {
        setValue(textId + "-" + (data - 1), "");
      }
      return data - 1;
    })
  }, [Optionslength, setOptionlength]);

  const Todo = useCallback(({ id, deleteField, setValue, watch ,NoOfField,textId}) => {
    return (
      <NVLButton
        className="relative left-[390px] bottom-9 shadow-lg  cursor-pointer h-8 w-8  hover:bg-red-100   inline-block text-red-600 rounded-full    "
        id={id} onClick={(e) => {
          e.preventDefault(); deleteField(id, setValue, watch,NoOfField,textId)
        }} >
        <i className="fa-solid fa-eraser absolute top-1.5 left-2 text-lg"></i>
      </NVLButton>
    );
  }, []);

  const Html = useCallback((props) => {
    return (
      <div key={props.index}>
        <div  className="flex mb-2 gap-8">
          <NVLTextbox id={props.id + props.index} type="text" title={props.title} pattern="^\S[ a-zA-Z\d@#$_.\-\s]*" errors={props.errors} register={props.register} className={`nvl-mandatory ${props.NoOfField == 2 ? "w-44" : "nvl-Def-Input"}`} />
          {props.NoOfField == 2 &&
            <NVLTextbox id={props.id + "-" + props.index} type="text" title={props.title} pattern="^\S[ a-zA-Z\d@#$_.\-\s]*" errors={props.errors} register={props.register} className="nvl-mandatory w-44" />
          }
        </div>
        {props.index != 0 && <Todo textId={props.id} id={props.index} deleteField={deleteField} NoOfField={props.NoOfField} setValue={props.setValue} watch={props.watch} />}
      </div>
    )
  }, [deleteField])

  const DynamicTextBinding = useCallback((props) => {
    const RowGrid = [];
    for (let i = 0; i < Optionslength; i++) {
      RowGrid.push(<Html key={i} index={i} setValue={props.setValue} watch={props.watch} NoOfField={props.NoOfField} id={props.id} title={props.title} errors={props.errors} register={props.register} />)
    }
    return (
      <div className="grid ">
        {RowGrid}
      </div>)
  }, [Optionslength])



  return (
    <div className="">
      <DynamicTextBinding NoOfField={NoOfField} errors={errors} Optionslength={Optionslength} setOptionlength={setOptionlength} setValue={setValue} id={id} watch={watch} title={title} register={register} />
      <div id="app" className="grid gap-4">
        <NVLlabel ButtonType="primary" id="form__submit" onClick={() => AddCustomFields()} className="text-xs bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded"> + Add Text Fields
        </NVLlabel>
      </div>
    </div>
  );
}




