import NVLModalPopup from "@components/Controls/NVLModalPopup";
import { yupResolver } from "@hookform/resolvers/yup";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import NVLButton from "./NVLButton";
import NVLCheckbox from "./NVLCheckBox";
import NVLlabel from "./NVLlabel";
function NVLDragAndDropRestriction({ BatchDatas, items, getList, json, id, data, setSubmitDrag, updateModuleData }) {
    const [popUpValues, setPopUpValues] = useState({});
    const [moduleColappse, SetModuleColappse] = useState(() => {
        const moduleGroup = function (xs, key) {
            return xs.reduce(function (rv, x) {
                if (rv?.[x[key]] == undefined) {
                    rv = { ...rv, [x[key]]: false }
                }
                return rv;
            }, {});
        };
        let temp = moduleGroup(items, "ModuleID");
        return temp;
    });
    const dragItem = useRef();
    const dragOverItem = useRef();

    const [force, setforce] = useState()
    let DynamicYupfields = {
        find: Yup.string().test("e", "noValid", e => {
            let check = 0;
            for (let z = 0; z < items?.length - 1; z++) {
                if (watch(id + "order" + z)) {
                    check++;
                }
                else {
                    check = 0;
                    break;
                }
            }
            if (check == items?.length - 1 && force != true) {
                setforce(true);
            }
            else if (force && check == 0) {
                setforce(false);
            }
            return true;
        })
    };
    for (let i = 0; i < items.length; i++) {
        DynamicYupfields = {
            ...DynamicYupfields,
            [id + "must" + i]: Yup.bool().test("e", "novalid", (e) => {
                if (e && !watch(id + "visible" + i)) {
                    setValue(id + "visible" + i, true)
                }
                return true;
            }),
            [id + "order" + i]: Yup.bool().test("e", "novalid", (e) => {
                if (e && !watch(id + "must" + i)) {
                    setValue(id + "must" + i, true, { shouldValidate: true });
                }
                return true;
            })
        }
    }
    const groupBy = function (xs, key) {
        return xs.reduce(function (rv, x) {
            (rv[x[key]] = rv[x[key]] || []).push(x);
            return rv;
        }, {});
    };
    const validationSchema = Yup.object().shape(DynamicYupfields);
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, formState, setValue, watch } = useForm(formOptions);
    const { errors } = formState;
    const getZoom = useCallback((items) => {
        let temp = [];
        if (items != undefined) {
            items.map((data) => {
                if (data?.ZoomActivityID == undefined || (data?.ZoomActivityID == data?.actId)) {
                    temp = [...temp, data]
                }

            })
        }
        return temp;

    }, [])
    const ModuleList = useRef(groupBy(getZoom(items), "ModuleID"));
    const [list, setList] = useState(() => { return getZoom(items); });
    const ModuleNameJson = useRef();
    useEffect(() => {
        let temp = getZoom(items);
        ModuleList.current = groupBy(temp, "ModuleID");
        let tempModuleName = {};
        items.map((data) => {
            tempModuleName = { ...tempModuleName, [data?.ModuleID]: data.ModuleName }
        })
        ModuleNameJson.current = tempModuleName;
        setList(temp)
    }, [id, items, setValue, watch, getZoom])

    useEffect(() => {
        return (() => {
            getList(list, watch, id, items);
        })
    }, [list, id, items, watch, getList])

    useEffect(() => {
        if (data > 0) {
            getList(list, watch, id, items);
            setSubmitDrag((tempdata) => {
                if (tempdata + 1 == data) {
                    return data + 1;
                }
                else {
                    return data;
                }
            });
        }
    }, [list, id, items, watch, getList, data, setSubmitDrag])

    const dragStart = (e, position) => {
        dragItem.current = position;
    };

    useEffect(() => {
        if (json?.ActivityList.length > 0) {
            let must = [], list = [], visible = [];
            try {
                (json.ActivityList).map((data, index) => {
                    list = [...list, data.actId]
                })
            }
            catch (e) { }
            try {
                (json.must).map((data, index) => {
                    must = [...must, data.actId]
                })
            }
            catch (e) { }
            (json.Visible).map((data, index) => {
                visible = [...visible, data.actId]
            })
            let tempActlist = [], tempIndex = 0;
            (json.ActivityList).map((data, index) => {
                if (data?.ZoomActivityID == undefined) {
                    tempActlist = [...tempActlist, data.actId]
                }
            });
            (json.ActivityList).map((data, index) => {
                if (data?.ZoomActivityID == undefined) {
                    if (must.includes(data.actId)) {
                        setValue(id + "must" + tempIndex, true, { shouldValidate: true });
                    }
                    if (visible.includes(data.actId)) {
                        setValue(id + "visible" + tempIndex, true, { shouldValidate: true });
                    }
                    if (json?.Order?.[data.actId]?.before?.length > 0) {
                        if (json.Order?.[data.actId].before[0]?.ZoomActivityID == undefined) {
                            setValue(id + "order" + tempActlist.indexOf(json.Order?.[data.actId].before[0].actId), true, { shouldValidate: true });
                        }
                        else if (!(data.name + "-PreAssessment" == json.Order?.[data.actId].before[0].name)) {
                            setValue(id + "order" + tempActlist.indexOf(json.Order?.[data.actId].before[0].ZoomActivityID), true, { shouldValidate: true });
                        }
                    }
                    if (json?.Order?.[data.actId]?.after?.length > 0) {
                        if (json.Order?.[data.actId].after[0]?.ActList != undefined) {
                            setValue(id + "order" + tempIndex, true, { shouldValidate: true });

                        }
                    }
                    tempIndex++;
                }
            })
        }
    }, [id, json, setValue, watch])

    const dragEnter = (e, position) => {
        dragOverItem.current = position;
    };

    const drop = (e) => {
        const currentstatus = (id) => {
            const temp = [];
            list.map((a, index) => {
                temp = [...temp, watch(id + index)];
            })
            const dragitemValue = temp[dragItem.current];
            temp.splice(dragItem.current, 1)
            temp.splice(dragOverItem.current, 0, dragitemValue)
            temp.map((data, index) => {
                setValue(id + index, data)
            })
        }
        let temp = [...list];
        const dragItemContent = temp[dragItem.current];
        const postion = temp[dragOverItem.current];
        if (dragItemContent?.ModuleID != undefined && postion?.ModuleID != undefined) {
            if (postion?.ModuleID == dragItemContent?.ModuleID) {
                currentstatus(id + "must", list);
                currentstatus(id + "visible", list);
                currentstatus(id + "order", list);
                setValue(id + "order" + (list.length - 1), false, { shouldValidate: true });
                const copyListItems = [...list];
                copyListItems.splice(dragItem.current, 1);
                copyListItems.splice(dragOverItem.current, 0, dragItemContent);
                dragItem.current = null;
                dragOverItem.current = null;
                ModuleList.current = groupBy(copyListItems, "ModuleID");
                setList(copyListItems);
            }
            else {
                setPopUpValues({
                    Content: "Do you wish to interchange the module?"
                })
            }
        }
    };

    const updateModule = useCallback(() => {
        let temp = [...list];
        let start = temp.length, end = temp.length;
        const dragitemModuleId = temp[dragItem.current]?.ModuleID;
        for (let i = 0; i < temp.length; i++) {
            if (dragitemModuleId == temp[i]?.ModuleID) {
                start = i;
                break;
            }
        }
        for (let i = start; i < temp.length; i++) {
            if (dragitemModuleId != temp[i]?.ModuleID) {
                end = i;
                break;
            }
        }
        const copyListItems = [...list];
        let startDrageoverItem = temp[dragOverItem.current], startItem;
        for (let i = 0; i < temp.length; i++) {
            if (startDrageoverItem.ModuleID == temp[i]?.ModuleID) {
                startItem = i;
                break;
            }
        }
        const currentstatus = (id) => {
            const temparray = [];
            list.map((a, index) => {
                temparray = [...temparray, watch(id + index)];
            })
            let latestArray = temparray.splice(start, end - start);
            temparray.splice(startItem, 0, ...latestArray);
            temparray.map((data, index) => {
                setValue(id + index, data)
            })
        }
        currentstatus(id + "must", copyListItems);
        currentstatus(id + "visible", copyListItems);
        currentstatus(id + "order", copyListItems);
        setValue(id + "order" + (list.length - 1), false, { shouldValidate: true });
        let latestArray = copyListItems.splice(start, end - start);
        copyListItems.splice(startItem, 0, ...latestArray);
        dragOverItem.current = null;
        dragItem.current = null;
        ModuleList.current = groupBy(copyListItems, "ModuleID");
        setList(copyListItems);
        setPopUpValues({ Content: "" })
    }, [id, list, setValue, watch])

    const ResetPopUp = useCallback(() => {
        setPopUpValues({ Content: "" })
    }, [])

    const forceSequence = useCallback((e) => {
        e.preventDefault();
        if (force) {
            for (let i = 0; i < items?.length - 1; i++) {
                if (watch(id + "order" + i)) {
                    setValue(id + "order" + i, false, { shouldValidate: true });
                }
                setValue(id + "must" + (items?.length - 1), watch(id + "must" + (items?.length - 1)), { shouldValidate: true });
            }
        }
        else {
            for (let i = 0; i < items?.length - 1; i++) {
                if (!watch(id + "order" + i)) {
                    setValue(id + "order" + i, true);
                }
            }
            setValue(id + "must" + (items?.length - 1), true, { shouldValidate: true });
        }
    }, [force, id, items?.length, setValue, watch])



    const moduleName = useCallback((moduleID, idx) => {
        const moduleName = "";
        let moduleNameList = updateModuleData;
        moduleNameList = moduleNameList.filter((item) => {
            item.ModuleID == moduleID
            return item.ModuleName
        })
        return moduleNameList?.[idx]?.ModuleName

    }, [updateModuleData])
    return (
        <>
            <div className="grid gap-2 rounded my-4">
                {items?.length > 1 &&
                    <div className="flex ml-auto justify-items-end">
                        <NVLButton id={id + "chkall"} name={id + "chkall"} text={force ? "Disable Force Sequence" : "Enable Force Sequence"} onClick={(e) => { forceSequence(e) }} className={BatchDatas?.IsDefaultBatch == true ? "nvl-button bg-primary Disabled " : "nvl-button bg-primary text-white "} errors={errors} register={register} />
                    </div>
                }
                <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateModule(e)} CancelClick={(e) => ResetPopUp(e)} ButtonNotext="No" CloseIconEvent={() => ResetPopUp()} Content={popUpValues.Content} />
                {
                    Object.keys(ModuleList.current).map((data, idx) => {
                        let listActivity = ModuleList.current?.[data], index = 0, ModuleName = "";
                        let moduleID = "";
                        let temp = Object.keys(ModuleList.current);
                        for (let i = 0; i < temp.length; i++) {
                            moduleID = temp[i]
                            if (data != temp[i]) {
                                index = index + ModuleList.current?.[temp[i]].length;
                            }
                            else {
                                    ModuleName = ModuleList.current?.[temp[i]][0]?.ModuleName
                                    break;
                            }
                        }
                        return (
                            <div key={data} className="p-2 bg-gray-100">
                                <div className="flex" onClick={() => { SetModuleColappse((temp) => { return { ...temp, [data]: !temp?.[data] } }) }}>
                                    <div className="flex-none px-2">
                                        <span className={`arrow ${moduleColappse?.[data] ? "arrowdown" : "arrowright"}`} />
                                    </div>
                                    <NVLlabel text={ModuleNameJson.current?.[moduleID]} className="nvl-Def-Label m-auto"></NVLlabel>
                                </div>
                                <div className={`${moduleColappse?.[data] ? "" : "hidden"}`}>                             {
                                    listActivity.map((item, indextemp) => {
                                        let tempIndex = indextemp + index;
                                        return (
                                            <div className={` bg-gray-100  grid grid-flow-col grid-cols-4 justify-items-center gap-2 shadow-lg
                                             ${BatchDatas?.IsDefaultBatch == true ? "select-none" : ""}`} onDragStart={(e) => dragStart(e, tempIndex)} onDragEnter={(e) => dragEnter(e, tempIndex)} onDragEnd={drop} key={tempIndex} draggable={BatchDatas?.IsDefaultBatch == true ? false : true}>
                                                <div className="p-4 grid gap-1 col-span-3	">
                                                    <NVLlabel text={item.name} className="nvl-Def-Label"></NVLlabel>
                                                    <div className="grid grid-flow-col grid-cols-3 bg-white border border-gray-400 !text-gray-900   p-2 rounded-xl">
                                                        <NVLCheckbox className={BatchDatas?.IsDefaultBatch == true ? "checked:text-gray-400 pointer-events-none " : ""} id={id + "must" + tempIndex} name={"must" + tempIndex} text={"Mandatory"} value={true} errors={errors} register={register}  ></NVLCheckbox>
                                                        <NVLCheckbox className={BatchDatas?.IsDefaultBatch == true ? "checked:text-gray-400 pointer-events-none " : ""} disabled={watch(id + "must" + tempIndex)} id={id + "visible" + tempIndex} name={"visible" + tempIndex} text={"Visible"} value={true} errors={errors} register={register}  ></NVLCheckbox>
                                                        {tempIndex != (list.length - 1) && <NVLCheckbox className={BatchDatas?.IsDefaultBatch == true ? "checked:text-gray-400 pointer-events-none " : ""} id={id + "order" + tempIndex} name={"order" + tempIndex} text={"Must Complete For Next Activity"} value={true} errors={errors} register={register}  ></NVLCheckbox>}

                                                    </div>
                                                </div>
                                                <div className="bg-white text-gray-600 h-full w-full text-center grid place-content-center cursor-move "><i className="fa-solid fa-grip-lines"></i></div>
                                            </div>
                                        )
                                    })}
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </>
    );
}

export default NVLDragAndDropRestriction;