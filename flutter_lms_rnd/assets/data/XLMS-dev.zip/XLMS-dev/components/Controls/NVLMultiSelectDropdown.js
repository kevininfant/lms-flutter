import { listXlmsSearchUserInfos, listXlmsUserGroupInfos } from '@graphql/graphql/queries';
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import Multiselect from 'multiselect-react-dropdown';
import { useCallback, useEffect, useRef } from 'react';
import NVLToolTip from './NVLToolTip';


function NVLMultiSelectDropdown(props) {

  const UserList = useRef([]);
  const TotalUserList = useRef([])
  const refUserFound = useRef("No suggestion")

  const GetUsersList = useCallback(async (SearchUserName, props) => {

    if (SearchUserName?.trim() == "") return true;

    const ManualList = [];

    const userData = await AppsyncDBconnection(listXlmsSearchUserInfos, {
      PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "#USERINFO#"
      , FullName: SearchUserName?.replace(/\s+/g, '')?.toLowerCase(), UserName: SearchUserName?.replace(/\s+/g, '')?.toLowerCase()
    }, props.user.signInUserSession.accessToken.jwtToken);

    if (userData.res.listXlmsSearchUserInfos?.items && userData.res.listXlmsSearchUserInfos?.items?.length > 0) {
      userData.res.listXlmsSearchUserInfos?.items.map((getItem) => {
        if (getItem?.SK != null && getItem?.EmailID != null && getItem?.IsSuspend != "true") {
          let UserName = `${getItem?.FirstName} ${getItem?.LastName} - ${getItem?.UserName}`
          ManualList.push({
            value: getItem.SK,
            label: (UserName?.length > 40) ? UserName?.substring(0, 40) + "..." : UserName,
            FirstName: getItem?.FirstName,
            LastName: getItem?.LastName,
            UserName: getItem?.UserName,
            EmailID: getItem?.EmailID,
            SK: getItem.SK,
            tooltip: UserName
          });
        }
      });
    }


    let GroupUsersList = [];

    const groupUserResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#GROUPID#" + props?.GroupID, SK: "#USERINFO#" }, props.user.signInUserSession.accessToken.jwtToken);

    if (ManualList != undefined) {

      if (props?.ScreenName == "AssignCourse") {
        groupUserResponse?.res?.listXlmsUserGroupInfos?.items.map(() => {
          const userData = ManualList?.filter(({ EmailID: EmailId }) => groupUserResponse?.res?.listXlmsUserGroupInfos?.items?.some(({ EmailID: EmailId1 }) => EmailId === EmailId1));
          userData.map((getItem) => {
            GroupUsersList.push({
              value: getItem.SK,
              label: getItem?.label,
              FirstName: getItem?.FirstName,
              LastName: getItem?.LastName,
              UserName: getItem?.UserName,
              EmailID: getItem?.EmailID,
              tooltip: getItem.tooltip
            });

          });
        });

      } else if (props?.ScreenName == "AddUser") {
        const userData = ManualList?.filter(({ EmailID: EmailId }) => !groupUserResponse?.res?.listXlmsUserGroupInfos?.items?.some(({ EmailID: EmailId1 }) => EmailId === EmailId1));
        userData.map((getItem) => { GroupUsersList.push({ value: getItem.SK, label: getItem?.label }); });
      }

      TotalUserList.current = (props?.ScreenName == "AddUser" || props?.ScreenName == "AssignCourse") ? GroupUsersList : ManualList;
      UserList.current = (props?.ScreenName == "AddUser" || props?.ScreenName == "AssignCourse") ? GroupUsersList : ManualList;;
      props?.temp();
    }
    else {
      TotalUserList.current = [];
      props?.temp();
    }
  }, [])

  const SearchHandler = useCallback(async (SearchUserName, props, mode) => {
    if (SearchUserName.length < 3 || SearchUserName == "") {
      refUserFound.current = "No suggestion";
      UserList.current = ([]);
      TotalUserList.current = ([]);
      props?.temp();
      return true;
    }
    else if ((SearchUserName.length == 3 && props?.type == "User")) {
      GetUsersList(SearchUserName, props, mode)
    }
    refUserFound.current = UserList.current?.length == 0 ? "No user found" : "No user found";
    props?.temp();
  }, [GetUsersList]);

  useEffect(() => {
    const myElement = document.getElementById(props?.id);
    const handleClick = (event) => {
      const isClickedOutside = !myElement?.contains(event.target);
      if (isClickedOutside) {
        refUserFound.current = "No suggestion";
        UserList.current = ([]);
        props?.temp();
      }
    };
    document.addEventListener("click", handleClick);

    return () => {
      document.removeEventListener("click", handleClick);
    };
  }, [SearchHandler, props, props?.id, UserList]);

  useEffect(() => {
    const input = document.getElementById(props?.reference?.current?.props?.id);
    input && input.addEventListener('paste', handlePaste);

    return () => {
      input && input.removeEventListener('paste', handlePaste);
    };

  }, [handlePaste, props?.reference]);

  const handlePaste = useCallback(async (event) => {
    GetUsersList(event.clipboardData.getData('Text'), props)
  }, [GetUsersList, props]);

  function showTooltip() {
    const element = document.querySelectorAll('.option');
    if (element) {
      for (let i = 0; i <= element?.length; i++) {
        element[i] && element[i].setAttribute("title", UserList?.current[i]?.tooltip);
      };
    }

  }
  return (
    <div className='pt-4 gap-4  relative'>
      <div onMouseOver={() => props?.showToolTip ? "" : showTooltip()} >
        <Multiselect
          id={props?.id}
          ref={props?.reference}
          className={"nvl-MultiSelect " + props.className}
          options={props?.type != "User" ? [...new Map(props?.options?.map(item => [item["value"], item])).values()] : [...new Map(UserList.current?.map(item => [item["value"], item])).values()]}
          selectedValues={props?.selectedValue}
          onSelect={props?.onSelect}
          onRemove={(props?.onRemove)}
          displayValue={props?.displayValue ? props?.displayValue : "label"}
          onSearch={(e) => SearchHandler(e, props)}
          keepSearchTerm={true}
          emptyRecordMsg={refUserFound.current}
          showCheckbox={true}
          placeholder={props?.placeholder}
          setSelectedValues={props?.setSelectedValues}
          avoidHighlightFirstOption={true}
          disable={props?.disable}
        />
        <div className='absolute top-4 -right-6'>
          <NVLToolTip PopDetail={props.HelpInfo ? props.HelpInfo : "Search with minimum three characters using Name/UserID"} PopIcon={props.HelpInfoIcon ? props.HelpInfoIcon : "fa fa-solid fa-circle-question pt-2"} CustomCss={props.CustomCss} ></NVLToolTip>
        </div>
      </div>
      <div>
      </div>
    </div>
  )
}

export default NVLMultiSelectDropdown