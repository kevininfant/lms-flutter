import NVLlabel from "@Controls/NVLlabel";
import NVLToolTip from "./NVLToolTip";

function NVLToolTipTextBox(props) {
    return (
        <div className={`grid ${props?.wfull != undefined ? props?.wfull : ""}`}>
            {props.icon == undefined && props.labelText ? <NVLlabel text={props.labelText} className={props.labelClassName}  >{props.className.indexOf("nvl-mandatory") != -1 && <span className="text-red-500 text-lg">*</span>}</NVLlabel> : ""}
            <div className="flex">
                <input
                    type={props.type ? props.type : "text"}
                    id={props.id}
                    {...props.register(props.id, { shouldValidate: true })}
                    placeholder={props.title} autoComplete="off"
                    disabled={props.disabled}
                    tabIndex={props.tabIndex}
                    min={props.min}
                    max={props.max}
                    className={"nvl-TextBox " + props.className + "  " + (props.errors?.[props.id] ? "border-red " : "  border-gray-300") + (props.icon ? "" : " ")}
                />
                {props.HelpInfo&&<NVLToolTip PopDetail={props.HelpInfo} PopIcon={"pl-3 pt-2 " + props.HelpInfoIcon} />}
            </div>
            {props.icon == undefined ? <div className={"{invalid-feedback}   text-red-500 text-sm " + (props.icon ? " top-9 absolute" : "")}>{props?.errors?.[props.id]?.message}</div> : <></>}
        </div>
    );
}

export default NVLToolTipTextBox;