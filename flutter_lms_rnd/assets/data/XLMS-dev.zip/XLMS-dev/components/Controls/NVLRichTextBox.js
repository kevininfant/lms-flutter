import ResizeModule from "@Controls/NVLRichTextImageResize";
import 'quill/dist/quill.bubble.css';
import 'quill/dist/quill.snow.css';
import { useCallback, useEffect, useMemo, useRef } from "react";
import { useQuill } from "react-quilljs";

function NVLRichTextBox({ Image, className, setState, Link, isDisabled }) {

  const messagesEnd = useRef();

  let fonts = useMemo(() => { return process.env.QUILLEDITORFONT }, []);

  // generate code friendly names
  const getFontName = useCallback((font) => {
    let cssFont = font.toLowerCase().replace(/\s/g, "-");
    if (cssFont == "times-new-roman")
      return cssFont.replace("times-new-roman", "Times");
    else
      return cssFont;
  }, []);


  let fontNames = useMemo(() => { let lfontValue = fonts?.map(font => getFontName(font)); lfontValue.push(false); return lfontValue }, [fonts, getFontName]);

  // add fonts to style
  let fontStyles = "";
  fonts?.forEach(function (font) {
    let fontName = getFontName(font);
    fontStyles += ".ql-snow .ql-picker.ql-font .ql-picker-label[data-value=" + fontName + "]::before, .ql-snow .ql-picker.ql-font .ql-picker-item[data-value=" + fontName + "]::before {" +
      "content: '" + font + "';" +
      "font-family: '" + font + "', sans-serif;" +
      "}" +
      ".ql-font-" + fontName + "{" +
      " font-family: '" + font + "', sans-serif;" +
      "}.ql-snow .ql-picker{height:auto !important}";
  });

  let node = document?.createElement('style');
  node.innerHTML = fontStyles;
  document?.body?.appendChild(node);

  const modules = {
    toolbar: {
      scrollingContainer: 'body',
      container: [["bold", "italic", "underline"],
      [{ indent: "-1" }, { indent: "+1" }],
      [{ size: ["small", false, "large", "huge"] }], ["undo", "redo"],
      [{ color: [] }], [{ font: fontNames }], [{ align: [] }],
      [!Link || Link == undefined ? "link" : undefined, Image ? "image" : undefined]],
      handlers: {
        undo: undoChange,
        redo: redoChange
      },
    },
    resize: {},
    history: {
      delay: 1000,
      maxStack: 500,
    },
    clipboard: {
      matchVisual: false
    },
  };
  const theme = "snow";
  const formats = ["header", "font", "size", "bold", "italic", "underline", "align", "strike", "script", "blockquote", "background", "list", "bullet", "indent", "link", "image", "color", "code-block"];
  const { quill, quillRef, Quill } = useQuill({ modules, formats, theme });
  if (Quill && !quill) {
    Quill.register("modules/resize", ResizeModule);
    let icons = Quill.import("ui/icons");
    icons["undo"] = `<i class="fa-solid fa-rotate-left"></i>`;
    icons["redo"] = `<i class="fa-solid fa-rotate-right"></i>`;


    let Font = Quill.import('formats/font');
    Font.whitelist = fontNames;
    Quill.register(Font, true);
  }
  useEffect(() => {
    setState(quill)
    if (quill == null) return;
    quill?.clipboard?.addMatcher('span', preserveSizeFormat);
    quill?.on("editor-change", () => {
      messagesEnd.current?.scrollIntoView({ behavior: "instant", block: "center" });
    });
  }, [quill, setState])

  function undoChange() {
    this.quill.history.undo();
  }
  function redoChange() {
    this.quill.history.redo();
  }

  function preserveSizeFormat(node, delta) {
    const match = node.className.match(/ql-size-(.*)/)
    const fmatch = node.className.match(/ql-font-(.*)/)
    const fontSize = node.style['font-size']
    const fontFamily = node.style['font-family']
    const styleMatch = fontSize && fontSize !== '16px'

    delta.map(function (op) {
      if (!op.attributes) {
        op.attributes = {}
      }
      if (match) {
        op.attributes.size = match[1]
      }
      else if (styleMatch) {
        const large = fontSize === '19.5px' || fontSize === '1.5rem'
        op.attributes.size = (large ? 'large' : ((large ? 'huge' : (fontSize == '0.75rem' || fontSize == "9.75px") ? "small" : "")))
      }
      if (fmatch) {
        op.attributes.font = fmatch[1]
      } else {
        op.attributes.font = fontFamily
      }
      return op
    })
    return delta
  }

  useEffect(() => {
    function disableTab(event) {
      if (event.key === 'Tab') {
        event.preventDefault();
      }
    }
   isDisabled &&  document.addEventListener('keydown', disableTab);
    return (() => {
      document.removeEventListener('keydown', disableTab);
    })
  }, [isDisabled, quillRef])

  return (
    <>
      <div className={`${className}`}>
        <div ref={quillRef}>
        </div>
        <div ref={messagesEnd}></div>

      </div>
    </>
  );
}

export default NVLRichTextBox;

export function getContents(quill) {
  if (quill?.getContents()?.length() > 1) return quill?.root?.innerHTML;
  else return "";
}

export function setContents(contents, quill) {
  let range = quill?.getSelection(!quill?.hasFocus());
  quill?.insertText(range?.index, contents);
}

export function setHTMLContents(Content, quill) {
  if (quill != undefined && quill) {
    const delta = Content && quill?.clipboard?.convert(Content);
    quill.setContents(delta, "silent");
  }
}

export function ClearContents(quill) {
  quill.deleteText(0, quill.getLength());
}
