
export default function NVLWarning(props)
{
return(<div className={`bg-orange-100 border-l-4 border-orange-500 text-orange-700 p-4 ${props?.className}`} role="alert">
  <p className="font-bold">{props.Header}</p>
  <p>{props.Content}</p>
</div>);
}