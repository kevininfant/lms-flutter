function NVLButton(props) {
  return (
    <button 
          id={props.id} 
          type={props.type}
          onClick={props.onClick}
          disabled={props.disabled} 
          className={props.ButtonType == "success" ? " nvl-button-success "+props.className : 
                    props.ButtonType == "danger" ? " nvl-button-danger "+props.className :
                    props.ButtonType == "warning" ? " nvl-button-warning "+props.className : 
                    props.ButtonType == "dark" ? " nvl-button-dark "+props.className :
                    props.ButtonType == "light" ? " nvl-button-light "+props.className : 
                    props.ButtonType == "link" ? " nvl-button-link  "+props.className :
                    props.ButtonType == "primary" ? "nvl-button-primary "+props.className: 
                    props.ButtonType == "default" ? "nvl-button-default "+props.className:
                    props.ButtonType == "start" ? "nvl-button-start "+props.className:
                    props.ButtonType == "completed" ? "nvl-button-completed "+props.className:
                    props.ButtonType == "continue" ? "nvl-button-continue "+props.className:
                    props.ButtonType == "learnagain" ? "nvl-button-learnagain "+props.className
                    : props.className}>
          {props.text}{props.children}
    </button>
  );
}

export default NVLButton;
