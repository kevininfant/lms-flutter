function NVLGridTableHeader(props) {
  return (
    <thead className="nvl-GridTable-Header">
      <tr>
        {props?.HeaderColumn?.length > 0 &&
          props.HeaderColumn.map((Headerlink, Headerindex) => (
            Headerlink?.HeaderName? <th key={Headerindex} className={Headerlink.HeaderName==""? "bg-white":"" +"px-6 w-full align-middle border-b py-3 text-xs border-l-0 border-r-0 whitespace-nowrap font-semibold text-left " + Headerlink.HeaderCss + " " + (props.color === "light" ? "bg-blueGray-50 text-blueGray-500 border-blueGray-100" : "bg-blueGray-600 text-blueGray-200 border-blueGray-500")}>
              {Headerlink.HeaderName}
            </th>:""
          ))}
      </tr>
    </thead>
  );
}
export default NVLGridTableHeader;
