import { useRouter } from "next/router";
import { useCallback } from "react";
import NVLLink from "./NVLLink";


function NVLDiscussionBox(props) {
   const router = useRouter();
   const editCondition = useCallback(() => {
      let CourseID = props?.props?.ActivityData?.CourseID == undefined ? "" : props?.props?.ActivityData?.CourseID;
      let ModuleID = props?.props?.ActivityData?.ModuleID == undefined ? "" : props?.props?.ActivityData?.ModuleID;
      let BatchId = props?.props?.EnrollCourseData?.BatchID == undefined ? "" : props?.props?.EnrollCourseData?.BatchID;
      router.push(`/MyLearning/CreateTopic?ActivityID=${props?.props?.ActivityData?.ActivityID}&CourseID=${CourseID}&ModuleID=${ModuleID}&BatchID=${BatchId}&TopicSub=${props.DiscussionMessage?.SK.split("#").pop()}&CourseName=${encodeURIComponent(props?.props?.CourseEnrollData?.CourseName)}`)
   }, [props.DiscussionMessage?.SK, props?.props?.ActivityData?.ActivityID, props?.props?.ActivityData?.CourseID, props?.props?.ActivityData?.ModuleID, props?.props?.EnrollCourseData?.BatchID, props?.props?.CourseEnrollData?.CourseName, router])
   return (
      <div className="relative">
         {
            props.DiscussionMessage?.TopicName &&
            <>
               <div className="flex justify-between">
                  <NVLLink text={(props.DiscussionMessage?.TopicName)} onClick={() =>
                     router.push(`/MyLearning/DiscussionChat?ActivityID=${props?.props?.ActivityData?.ActivityID}&TopicID=${props.DiscussionMessage?.SK.split("#").pop()}&TopicName=${props?.DiscussionMessage?.TopicName}&Description=${props?.DiscussionMessage?.Description}&CourseID=${props?.props?.CourseEnrollData?.CourseID == undefined ? "" : props?.props?.CourseEnrollData?.CourseID}&BatchID=${props?.props?.EnrollCourseData?.BatchID == undefined ? "" : props?.props?.EnrollCourseData?.BatchID}&ModuleID=${props?.props?.ActivityData?.ModuleID == undefined ? "" : props?.props?.ActivityData?.ModuleID}&CourseName=${encodeURIComponent(props?.props?.CourseEnrollData?.CourseName)}`)} className="font-Montserrat text-sm font-bold ">
                  </NVLLink>
                  <div className="flex gap-2">
                     <div className="border rounded-xl h-6 w-12  my-auto flex justify-center items-center shadow-lg gap-2 ">
                        <i className="fa fa-eye text-md"></i><span className="text-sm font-semibold ">{props.DiscussionMessage.TotalCount}</span>
                     </div>
                     <div className={!props.props.ActivityData.IsCompleteTheActivity ? "border rounded-xl h-6 w-12  my-auto flex justify-center items-center shadow-lg gap-2 " : ""} onClick={!props.props.ActivityData.IsCompleteTheActivity ? editCondition : ""}>
                        {!props.props.ActivityData.IsCompleteTheActivity ? <i className="fa fa-pencil text-md"></i> : ""}
                     </div>
                  </div>
               </div>
            </>
         }
      </div>
   )
}
export default NVLDiscussionBox;