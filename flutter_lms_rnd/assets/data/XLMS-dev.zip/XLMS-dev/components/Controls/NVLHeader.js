import NVLSelectField from "@components/Controls/NVLSelectField";
import router from "next/router";
import { useEffect, useRef } from "react";
import NVLTabRouting from "./NVLTabRouting";

export default function NVLHeader(props) {
  const Search = useRef(null);
  const OldSearch = useRef("");

  function handleKeyUp(event) {
    if (event.keyCode === 13) {
      if (Search.current?.value != "") {
        event.preventDefault();
        performSearch();
      }
    }
    else {
      if (Search?.current?.value == "" && OldSearch.current != "") {
        OldSearch.current = "";
        performSearch();
      }
    }
  }
  function performSearch() {
    OldSearch.current = Search.current.value?.trim();
    props.SearchonChange(Search.current.value?.trim());
  }

  useEffect(() => {
    if (props.Search == "" && Search.current != undefined) {
      Search.current.value = "";
    }
  }, [props.Search])

  return (
    <>
      <section className={`${props.Header == "Site Admin Dashboard" ? "px-3 pt-3" : "px-3 sm:pb-4"}`}>
        <div className="HeaderBody flex">
          {props.isBackAction && <i className="fa fa-light fa-hand-point-left my-1 cursor-pointer px-1 text-th-body-icon-color" onClick={() => router.push(props.RedirectHome)}></i>}
          <div className="flow-root HeaderTitle">
            <span className="float-left">
              <h6 className={`select-none ${props.isBackAction ? "cursor-pointer px-2 text-th-body-txt-color break-all" : ""}`} onClick={() => props.isBackAction && router.push(props.RedirectHome)}>
                {props.Header}
              </h6>
            </span>
            <div className="right-0	float-right">{props.HeaderOption && props.HeaderOption}</div>
          </div>
        </div>
        {props.IsNestedHeader && (
          <div className="nvl-CpntHeader">
            {
              <div className={`nvl-CpntHeader-Item  !flex`}>
                {<div className={`nvl-CpntHeader-button ${props.className != undefined ? props.className : "!w-4/5 "}`}>
                  {props.LinkName5 != undefined && <NVLTabRouting TabRouting={props.TabRouting} href={props.href5} id={props.ButtonID5} type4={props.type5} text={props.LinkName5} disabled={props.DisableButton5} onClick={props.RedirectAction5} classNameLink={props.classNameLink5} className={props.className5 != undefined ? props.className5 : "h-8 w-full bg-th-body-button-bg-color text-th-body-button-txt-color rounded hover:bg-th-body-button-hover-bg-color"} />}
                  {props?.refreshIcon &&
                    <div className="py-1">
                      <button type="button" className="fa-solid fa-rotate-right text-xl w-9" id="refresh" onClick={() => props?.refreshEvent()} />
                    </div>
                  }
                  {props?.ButtonToolTip && props?.ButtonToolTip}
                  {props.LinkName4 != undefined && <NVLTabRouting TabRouting={props.TabRouting} href={props.href4} id={props.ButtonID4} type4={props.type4} text={props.LinkName4} disabled={props.DisableButton4} onClick={props.RedirectAction4} classNameLink={props.classNameLink4} className={props.className4 != undefined ? props.className4 : "h-8 w-full bg-th-body-button-bg-color text-th-body-button-txt-color rounded hover:bg-th-body-button-hover-bg-color"} />}
                  {props.LinkName3 != undefined && <NVLTabRouting TabRouting={props.TabRouting} href={props.href3} id={props.ButtonID3} type3={props.type3} text={props.LinkName3} disabled={props.DisableButton3} onClick={props.RedirectAction3} classNameLink={props.classNameLink3} className={props.className3 != undefined ? props.className3 : "h-8 w-full bg-th-body-button-bg-color text-th-body-button-txt-color rounded hover:bg-th-body-button-hover-bg-color"} />}
                  {props.LinkName2 != undefined && <NVLTabRouting TabRouting={props.TabRouting} href={props.href2} id={props.ButtonID2} type2={props.type2} text={props.LinkName2} disabled={props.DisableButton2} onClick={props.RedirectAction2} classNameLink={props.classNameLink2} className={props.className2 != undefined ? props.className2 : "h-8 w-full bg-th-body-button-bg-color text-th-body-button-txt-color rounded hover:bg-th-body-button-hover-bg-color"} />}
                  {props.LinkName1 != undefined && <NVLTabRouting TabRouting={props.TabRouting} href={props.href1} id={props.ButtonID1} type1={props.type1} text={props.LinkName1} disabled={props.DisableButton1} onClick={props.RedirectAction1} classNameLink={props.classNameLink1} className={props.className1 != undefined ? props.className1 : "h-8 w-full bg-th-body-button-bg-color text-th-body-button-txt-color rounded hover:bg-th-body-button-hover-bg-color"} />}
                </div>
                }
                <div className="nvl-CpntHeader-Search !w-4/5  !gap-x-1 !  " >
                  {props.isDropdownRequired1 != undefined && <NVLSelectField id="dropdown1" options={props.DropdownData1 != undefined ? props.DropdownData1 : []} className={`${props.dropdownclass1 != undefined ? props.dropdownclass1 : " "} !w-fit !pr-7 !px-2`} disabled={props.IsDropdownDisable1 ? true : false} errors={props.errors} register={props.register}></NVLSelectField>}
                  {props.isDropdownRequired2 != undefined && <NVLSelectField id="dropdown2" options={props.DropdownData2 != undefined ? props.DropdownData2 : []} className={`${props.dropdownclass2 != undefined ? props.dropdownclass2 : " "} !w-fit !pr-7 !px-2`} disabled={props.IsDropdownDisable2 ? true : false} errors={props.errors} register={props.register}></NVLSelectField>}
                  {props.isDropdownRequired3 != undefined && <NVLSelectField id="dropdown3" options={props.DropdownData3 != undefined ? props.DropdownData3 : []} className={`${props.dropdownclass3 != undefined ? props.dropdownclass3 : " "} !w-fit !pr-7 !px-2`} disabled={props.IsDropdownDisable3 ? true : false} errors={props.errors} register={props.register}></NVLSelectField>}

                  {props.IsSearch && (
                    <div className="relative flex " >
                      <button type="button" className="fa-solid fa-rotate-right text-xl w-9" id="refresh" onClick={() => { props.onClick1(); Search.current.value = ""; }} />
                      <input ref={Search} onKeyUp={handleKeyUp} className="pr-10 w-60 lg:w-72 placeholder-gray-300 border-1 focus:font-medium focus:text-black border-gray-300 rounded text-gray-900 h-8 text-xs focus:ring-0" type="text" disabled={props.SearchDisabled} id="tableSearch" value={props.TextboxValue} placeholder={props.placeholder} />
                      <button type="button" className="absolute right-2" onClick={() => props.SearchonChange(Search.current.value)}>
                        <i className="fa fa-light fa-magnifying-glass text-xl relative top-2 text-gray-200 hover:text-blue-500"></i>
                      </button>
                    </div>
                  )}
                  {props.IsDropdown &&
                    <div className="relative flex">
                      {props?.IsDropdownRefresh && <div className="pt-2">
                        <button type="button" className="fa-solid fa-rotate-right text-xl w-9" id="GridRefresh"
                          onClick={() => { props.onClick1() }} />
                      </div>}
                      <div>
                        <NVLSelectField id="ddlSearch" required={props.DropdownRequired} options={props.DropdownData} onChange={props.DropdownonChange} className={`w-72 ${props.IsDropdownDisable ? "Disabled" : ""}`} disabled={props.IsDropdownDisable ? true : false} errors={props.errors} register={props.register}></NVLSelectField>
                      </div>
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        )}
      </section>
    </>
  );
}