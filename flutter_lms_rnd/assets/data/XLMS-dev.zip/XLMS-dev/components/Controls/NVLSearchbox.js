function NVLSearchbox(props) {
  return (
    <>
      <div className={"nvl-SearchField  " + props.SearchFieldCss}>
        <label 
          htmlFor="default-search" 
          className="nvl-SearchField-Label ">
          Search
        </label>
        <div className="relative">
          <input 
          id={props.id} 
          className={"mt-0 focus:ring-0 block w-full h-9 shadow-sm sm:text-sm border border-gray-300 rounded-md placeholder:text-gray-400 text-sm placeholder:text-sm " + props.className} 
          title={props.title} 
          placeholder={props.placeholder} 
          minLength={props.minLength} 
          maxLength={props.maxLength ? props.maxLength : "100"} 
          onPaste={props.onPaste} 
          label={props.label} 
          type="text" 
          size={props.size}
          onChange={props.onChange} 
          onFocus={props.onFocus} 
          pattern={props.pattern} 
          onKeyPress={props.onKeyPress} 
          disabled={props.disabled}
          fontSize={props.fontSize}
          color={props.color} 
          width={props.width} 
          value={props.value} 
          wrap={props.wrap} 
          direction={props.direction} 
          required={props.required} 
          autoComplete="off" />
          <button type="button" 
                  className="text-gray-600 absolute right-2.5 bottom-2.5 focus:ring-4 focus:outline-none font-medium rounded-lg text-lg" 
                  onClick={props.onClick}>
                  <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em" preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24">
                      <path fill="none" stroke="currentColor" strokeLinecap="round" strokeWidth="2" d="m21 21l-4.486-4.494M19 10.5a8.5 8.5 0 1 1-17 0a8.5 8.5 0 0 1 17 0Z" />
                  </svg>
          </button>
        </div>
      </div>
    </>
  );
}

export default NVLSearchbox