import NVLButton from "@Controls/NVLButton";

function NVLModalPopup(props) {
  return (
    <div id="divNVLModal" className={`${props.Content != "" && props.Content != undefined ? "" : "hidden"} modalBackgroud flex !m-0`}>
      <div className={"nvl-Modal w-full m-10  pointer-events-none align-middle"} id="staticBackdrop" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div className="modal-header m-auto border-none shadow-lg xl:flex xl:flex-col xl:w-full pointer-events-auto bg-white bg-clip-padding rounded-2xl outline-none text-current">
          <div className="modal-header flex xl:flex-shrink-0 xl:items-center justify-end px-2">
            <span id="lblClose" className={`xl:pr-2 xl:pt-2 text-gray-500 cursor-pointer hover:text-red-60 ${props?.IsCloseIcon ? "" : "invisible"}`} onClick={props.CloseIconEvent}>
              <i className="fa-regular fa-circle-xmark text-2xl"></i>
            </span>
          </div>
          <div className={`modal-header px-4 ${props.TextClassName != undefined ? props.TextClassName : "text-center"} overflow-y-auto max-h-[80vh]`}>
            <p className="modal-header text-sm py-2 text-gray-500 pointer-events-none 	">{props.Content}</p>
          </div>
          <div className={`modal-header flex justify-center gap-1 p-5 ${props.loader ? "pointer-events-none" : ""}`}>
            {props.ButtonYestext && <NVLButton type={"button"} id={props.ButtonYestext} disabled={props.loader} text={!props.loader ? props.ButtonYestext : ""} className="text-white border h-8 font-medium border-gray-300 bg-primary pl-3 pr-3 rounded-md text-sm w-25 " onClick={props.SubmitClick}>
              {props.loader && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
            </NVLButton>}
            {props?.IsConfirmAlert == undefined && <NVLButton type={"button"} id={props.ButtonNotext} text={props.ButtonNotext} disabled={props.loader} className="text-gray-700 border h-8 font-medium border-gray-300 pl-3 pr-3 rounded-md text-sm w-25 " onClick={props.CancelClick}></NVLButton>}
          </div>
        </div>
      </div>
    </div>
  );
}

export default NVLModalPopup;