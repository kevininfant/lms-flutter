import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { Auth } from "aws-amplify";
import { APIGatewayPutRequest } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useState } from "react";
export default function NVLDynamicLanguageFile({
  ActivityType,
  ActivityID,
  FileError,
  errors,
  SelectFieldOptions,
  register,
  HelpInfo,
  id,
  FileValues,
  setFileValues,
  setValue,
  TenantInfo,
  mode,
  ddlId,
  watch,
  dynamicFileRef,
}) {


  const [isUpload, setisUpload] = useState(false);

  useEffect(() => {
    FileValues?.map((e, index) => {
      setValue(ddlId + index, e?.Language);
    });
  }, [FileValues, ddlId, setValue]);

  const getContentType = (Extension) => {
    switch (Extension) {
      case "mkv":
        return "video/x-matroska";
      case "avi":
        return "video/x-ms-video";
      case "mov":
        return "video/quicktime";
      case "wmv":
        return "video/x-ms-wmv";
      case "mp4":
        return "video/mp4";
      case "mpeg4":
        return "video/mpeg4";
      case "txt":
        return "text/html";
      case "xls":
        return "application/vnd.ms-excel";
      case "ppt":
        return "application/vnd.ms-powerpoint";
      case "pptx":
        return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
      case "xlsx":
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      case "docx":
        return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      default:
        return "application/" + Extension;
    }
  };

  const fileRename = useCallback((files) => {
    let fileName = files?.name.split(".")[0];
    let guid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(
      /[xy]/g,
      function (c) {
        var r = (Math.random() * 16) | 0,
          v = c == "x" ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }
    );
    let ext = files?.name.split(".").pop();
    let ContentType =
      ext == "csv"
        ? "text/" + ext
        : ext == "jpeg" || ext == "jpg" || ext == "png"
          ? "image/" + ext
          : getContentType(ext);

    let filechanges = new File([files], fileName + "-" + guid + "." + ext, {
      type: ContentType,
      lastModified: Date.now(),
    });
    return filechanges;
  }, []);

  const fileValidation = useCallback(
    async (e, index) => {
      document.getElementById("loader" + index).classList.remove("hidden");
      let fileInput = document.getElementById(e.target.id);
      let filePath = fileInput.value;
      let getFile = fileRename(e.target.files[0]);
      let allowedExtensions =
        ActivityType == "File"
          ? /(\.docx|\.doc|\.zip|\.pdf|\.csv|\.jpg|\.jpeg|\.png|\.avi|\.mov|\.xls|\.xlsx|\.mp4|\.mpeg4)$/i
          : ActivityType == "Assignment"
            ? /(\.docx|\.doc|\.ppt|\.pptx|\.pdf|\.csv|\.jpg|\.jpeg|\.png|\.avi|\.mov|\.xls|\.xlsx|\.mp4|\.mpeg4)$/i
            : ActivityType == "Video"
              ? /(\.mp4|\.mpeg4|\.mkv|\.avi|\.mov|\.mov|\.wmv)$/i
              : ActivityType == "ScormPackage"
                ? /(\.zip|\.raz)$/i
                : ActivityType == "LearningBytes"
                  ? /(\.h5p)$/i
                  : /(\.csv|\.txt|\.doc|\.docx|\.pdf|\.jpeg|\.jpg|\.png)$/i;
      if (!allowedExtensions.exec(filePath) || fileInput == null) {
        fileInput.value = "";
        setFileValues((FileValues) => {
          FileValues[index] = {
            ...FileValues[index],
            FileName: "Select File",
            FilePath: "",
            Language: "",
            PathChanged: false,
          };
          return FileValues;
        });
        setValue("FileLang", "INVALIDFILE", { shouldValidate: true });
        document.getElementById("loader" + index) &&
          !document.getElementById("loader" + index).classList.contains("hidden")
          ? document.getElementById("loader" + index).classList.add("hidden")
          : "";
        return false;
      } else if (getFile <= process.env.ACTIVITY_ALLFILE_SIZE) {
        fileInput.value = "";
        setFileValues((FileValues) => {
          FileValues[index] = {
            ...FileValues[index],
            Language: "",
            FileName: "Select File",
            FilePath: "",
            path: null,
            PathChanged: false,
          };
          return FileValues;
        });
        setValue("FileLang", "FILESIZE", { shouldValidate: true });
        document.getElementById("loader" + index) &&
          !document.getElementById("loader" + index).classList.contains("hidden")
          ? document.getElementById("loader" + index).classList.add("hidden")
          : "";
      } else {
        await UploadFile(getFile, index);
      }
    },
    [ActivityType, UploadFile, fileRename, setFileValues, setValue]
  );

  const UploadFile = useCallback(
    async (getFile, index) => {
      setisUpload(true);
      document
        .getElementById("divEditActivitySettings")
        ?.classList?.add("pointer-events-none");
      const file = getFile;
      const CSVReader = new FileReader();
      CSVReader.onload = async function (getFile) {
        let isCSVDatacheck = false;
        if (!isCSVDatacheck) {
          let fetchURL =
            process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
            `?FileName=${file.name}&TenantID=${TenantInfo?.TenantID}&BucketName=${TenantInfo?.BucketName}&RootFolder=${TenantInfo?.RootFolder}&ActivityType=${ActivityType}&Type=Activity&ActivityID=${ActivityID}`;
          if (mode == "ModuleDirect" || mode == "ModuleEdit") {
            fetchURL =
              process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
              `?FileName=${file.name}&ActivityID=${ActivityID}&TenantID=${TenantInfo.TenantID}&CourseType=Module&RootFolder=${TenantInfo.RootFolder}&BucketName=${TenantInfo.BucketName}&Type=Course&ManagementType=CourseManagement`;
          }
          if (ActivityType == "ScormPackage") {
            if (mode == "ModuleDirect") {
              fetchURL =
                process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
                `?FileName=${getFile.name}&&TenantID=${TenantInfo.TenantID}& &&RootFolder=${TenantInfo.RootFolder}&&BucketName=${TenantInfo.BucketName}&&Type=Course&&ManagementType=CourseManagement`;
            } else if (mode == "Edit") {
              fetchURL =
                process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
                `?FileName=${file?.name}&TenantID=${TenantInfo.TenantID}&BucketName=${TenantInfo.BucketName}&RootFolder=${TenantInfo.RootFolder}&Type=Activity&ActivityType=${ActivityType}`;
            }
          }

          let GroupMenuName = (mode == "ModuleDirect" || mode == "ModuleEdit") ? "CourseManagement" : "ActivityManagement";
          let MenuID = (mode == "ModuleDirect" || mode == "ModuleEdit") ? "300406" : "500002"
          let headers = {
            method: "GET",
            headers: {
              authorizationtoken: await Auth.currentSession().then((s) =>
                s.getAccessToken().getJwtToken()
              ),
              defaultrole: TenantInfo.UserGroup,
              groupmenuname: GroupMenuName,
              menuid: MenuID,
            },
          };
          let Extension = file.name
            .substring(file.name.lastIndexOf(".") + 1)
            .toLowerCase();
          let ContentType =
            Extension == "csv"
              ? "text/" + Extension
              : Extension == "jpeg" || Extension == "jpg" || Extension == "png"
                ? "image/" + Extension
                : getContentType(Extension);

          let presignedHeader = {
            method: "PUT",
            headers: {
              // "x-amz-acl": "public-read",
              "content-type": ContentType,
              defaultrole: TenantInfo.UserGroup,
              groupmenuname: GroupMenuName,
              menuid: MenuID,
            },
            body: file,
          };

          let FinalStatus = await APIGatewayPutRequest(
            fetchURL,
            headers,
            presignedHeader
          );
          if (FinalStatus[0] != "Success") {
            setFileValues((FileValues) => {
              FileValues[index] = {
                ...FileValues[index],
                Language: document.getElementById(ddlId + index)?.options[
                  document.getElementById(ddlId + index).selectedIndex
                ].value,
                FileName: "Select File",
                FilePath: "",
                path: null,
                PathChanged: false,
              };
              return FileValues;
            });
            setValue("File", "Error", { shouldValidate: true });
            setValue("FileLang", "ERROR");
            document
              .getElementById("divEditActivitySettings")
              .classList.remove("pointer-events-none");
            setisUpload(false);
            document.getElementById("loader" + index) &&
              !document
                .getElementById("loader" + index)
                .classList.contains("hidden")
              ? document
                .getElementById("loader" + index)
                .classList.add("hidden")
              : "";
            return;
          } else {
            setValue("File", "exist", { shouldValidate: true });
            setFileValues((FileValues) => {
              FileValues[index] = {
                ...FileValues[index],
                Language: document.getElementById(ddlId + index)?.options[
                  document.getElementById(ddlId + index).selectedIndex
                ].value,
                FileName: file.name,
                FilePath: FinalStatus[1],
                path: null,
                PathChanged: true,
              };
              return FileValues;
            });

            setValue("FileLang", "sucess", { shouldValidate: true });
            document
              .getElementById("fileErrorMessage")
              ?.classList?.add("hidden");
            document.getElementById("divEditActivitySettings")?.classList.remove("pointer-events-none");
            document.getElementById("loader" + index) &&
              !document
                .getElementById("loader" + index)
                .classList.contains("hidden")
              ? document
                .getElementById("loader" + index)
                .classList.add("hidden")
              : "";
          }
        }
        setisUpload(false);
      };
      setisUpload(false);
      CSVReader.readAsText(file);
    },
    [ActivityID, ActivityType, TenantInfo.BucketName, TenantInfo.RootFolder, TenantInfo.TenantID, TenantInfo.UserGroup, ddlId, mode, setFileValues, setValue]
  );

  const ResetData = useCallback(
    (ResetValue) => {
      let tempFiles = [];
      ResetValue?.map((e, index) => {
        tempFiles = [
          ...tempFiles,
          {
            FileName: e.FileName,
            FilePath: e.FilePath,
            path: e.path,
            Language: document.getElementById(ddlId + index)?.options[
              document.getElementById(ddlId + index).selectedIndex
            ].value,
            PathChanged: e.PathChanged,
          },
        ];
      });
      return tempFiles;
    },
    [ddlId]
  );

  const deleteField = useCallback(
    (e, index) => {
      if (!(index == 0 && FileValues.length == 1)) {
        let tempData = ResetData(FileValues);
        tempData.splice(index, 1);
        setFileValues(tempData);
        setValue(id + index, "");
      }
      setValue("FileLang", "sucess", { shouldValidate: true });
      if (
        !document
          .getElementById("fileErrorMessage")
          ?.classList?.contains("hidden")
      ) {
        document.getElementById("fileErrorMessage")?.classList?.add("hidden");
      }
    },

    [FileValues, ResetData, id, setFileValues, setValue]
  );

  const AddCustomFields = useCallback(() => {
    if (isUpload) {
      return;
    }
    let isAdd = true;
    let tempFiles = [];
    FileValues.map((e, index) => {
      let language = document.getElementById(ddlId + index)?.options[
        document.getElementById(ddlId + index).selectedIndex
      ].value;
      tempFiles = [
        ...tempFiles,
        {
          Language: language,
          FileName: e.FileName,
          FilePath: e.FilePath,
          path: e.path,
          PathChanged: e.PathChanged,
        },
      ];
    });

    if (hasDuplicate(tempFiles, "Language")) {
      setValue("FileLang", "LANGEXISTS", { shouldValidate: true });
      isAdd = false;
      return;
    }
    tempFiles.map((e, index) => {
      let la = document.getElementById(ddlId + index)?.options[
        document.getElementById(ddlId + index).selectedIndex
      ].value;
      if (
        (e.FileName == "Select File" && la == "") ||
        (e.FileName == null && e.FilePath == null)
      ) {
        setValue("FileLang", "FILELANG", { shouldValidate: true });
        isAdd = false;
        return;
      } else if (
        e.FileName == "Select File" ||
        (e.FileName == null && e.FilePath == null)
      ) {
        setValue("FileLang", "FILE", { shouldValidate: true });
        isAdd = false;
        return;
      } else if (la == "") {
        setValue("FileLang", "LANG", { shouldValidate: true });
        isAdd = false;
        return;
      }
    });
    if (isAdd) {
      tempFiles = [
        ...tempFiles,
        {
          FileName: "Select File",
          FilePath: "",
          path: "",
          PathChanged: true,
          Language: "",
        },
      ];
      setFileValues(tempFiles);
    }
  }, [FileValues, ddlId, isUpload, setFileValues, setValue]);

  const hasDuplicate = (arrayObj, colName) => {
    var hash = Object.create(null);
    return arrayObj.some((arr) => {
      return (
        arr[colName] && (hash[arr[colName]] || !(hash[arr[colName]] = true))
      );
    });
  };

  const DynamicLanguageFile = useCallback(() => {
    return (
      <div className="grid">
        <div className="w-64 md:w-96 relative">
          <div className="">
            {FileValues.map((message, index) => {
              return (
                <div
                  key={"divId" + index}
                  className={`${index == 0 ? "mb-8" : ""}`}
                >
                  <div className="flex justify-between gap-2">
                    <div className="grid gap-2">
                      {index == 0 && (
                        <NVLlabel
                          text="Choose Language"
                          className={`nvl-Def-Label`}
                        />
                      )}
                      <NVLSelectField
                        id={ddlId + index}
                        className="nvl-mandatory w-44"
                        options={SelectFieldOptions}
                        errors={errors}
                        register={register}
                      />
                    </div>
                    <div>
                      <div className="grid gap-2">
                        {index == 0 && (
                          <NVLlabel
                            text="Upload File"
                            className={`nvl-Def-Label`}
                            HelpInfo={HelpInfo}
                            HelpInfoIcon="fa fa-solid fa-circle-question"
                          />
                        )}
                        <NVLFileUpload
                          id={id + index}
                          className="nvl-mandatory !w-56"
                          isLoader={true}
                          loaderID={"loader" + index}
                          tooltip={
                            message?.FileName != null
                              ? message?.FileName
                              : "Select File"
                          }
                          text={
                            message?.FileName == null || message.FileName == ""
                              ? message.FileName
                                ? message?.FileName
                                : "Select File"
                              : message.FileName?.length > 12
                                ? message.FileName?.substring(0, 12) + "..."
                                : message.FileName
                          }
                          errors={errors}
                          register={register}
                          onChange={(e) => fileValidation(e, index)}
                        />
                      </div>
                    </div>
                  </div>
                  <div className={`${index == 0 ? "hidden" : ""}`}>
                    <NVLlabel
                      key={index}
                      className={`relative left-[420px] bottom-11 cursor-pointer h-8 w-8 shadow-lg bg-red-100   inline-block text-red-600  rounded-full `}
                      id="todo__delete"
                      onClick={(e) => deleteField(e, index)}
                    >
                      <i className="fa-solid fa-trash absolute top-2.5 left-2.5 text-sm"></i>
                    </NVLlabel>
                  </div>
                </div>
              );
            })}
          </div>
          <div
            id="app"
            className={`grid gap-4 absolute ${FileValues.length > 1 ? "-right-28" : "-right-16"
              } bottom-11`}

          >
            <div className={(SelectFieldOptions&&(FileValues.length>=(SelectFieldOptions?.length-1))) ? "hidden" : ""}>
              <NVLlabel
                onClick={() => AddCustomFields(FileValues.length)}
                className="cursor-pointer text-xs  bg-blue-100  shadow-lg text-blue-600 font-bold rounded-full h-8 w-8"
              >
                <i className="fa-solid fa-plus relative left-2.5 top-2 text-sm"></i>
              </NVLlabel>
            </div>
          </div>
        </div>
        <div className={"text-red-500 text-sm"} id={"fileErrorMessage"}>
          {FileError}
        </div>
        <div className="hidden" id="divFileLangCount">
          {FileValues.length}
        </div>
      </div>
    );
  }, [
    FileError,
    FileValues,
    ddlId,
    SelectFieldOptions,
    errors,
    register,
    HelpInfo,
    id,
    fileValidation,
    deleteField,
    AddCustomFields,
  ]);

  return (
    <>
      <DynamicLanguageFile />
    </>
  );
}
