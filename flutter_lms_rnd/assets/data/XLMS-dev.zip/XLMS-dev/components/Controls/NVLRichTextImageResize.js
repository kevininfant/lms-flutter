! function(t, e) {
    "object" == typeof exports && "undefined" != typeof module ? module.exports = e() : "function" == typeof define && define.amd ? define(e) : (t = t || self).QuillResizeModule = e()
}(this, function() {
    "use strict";
    let i = function(t, e) {
        return (i = Object.setPrototypeOf || {
                __proto__: []
            }
            instanceof Array && function(t, e) {
                t.__proto__ = e
            } || function(t, e) {
                for (let i in e) e.hasOwnProperty(i) && (t[i] = e[i])
            })(t, e)
    };
    let e = function() {
        return (e = Object.assign || function(t) {
            for (let e, i = 1, n = arguments.length; i < n; i++)
                for (let r in e = arguments[i]) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t
        }).apply(this, arguments)
    };
    ! function(t) {
        if (t && "undefined" != typeof window) {
            let e = document.createElement("style");
            e.setAttribute("media", "screen"), e.innerHTML = t, document.head.appendChild(e)
        }
    }("#editor-resizer {\n  position: absolute;\n  border: 1px dashed #fff;\n  background-color: rgba(0, 0, 0, 0.5);\n}\n#editor-resizer .handler {\n  position: absolute;\n  right: -5px;\n  bottom: -5px;\n  width: 10px;\n  height: 10px;\n  border: 1px solid #333;\n  background-color: rgba(255, 255, 255, 0.8);\n  cursor: nwse-resize;\n  user-select: none;\n}\n#editor-resizer .toolbar {\n  position: absolute;\n  top: -3em;\n  left: 50%;\n  padding: 0.5em;\n  border: 1px solid #fff;\n  border-radius: 3px;\n  background-color: #fff;\n  box-shadow: 0 0 3px rgba(0, 0, 0, 0.5);\n  transform: translateX(-50%);\n}\n#editor-resizer .toolbar .group {\n  display: flex;\n  border: 1px solid #aaa;\n  border-radius: 6px;\n  overflow: hidden;\n  white-space: nowrap;\n  text-align: center;\n}\n#editor-resizer .toolbar .group:not(:first-child) {\n  margin-top: 0.5em;\n}\n#editor-resizer .toolbar .group .btn {\n  flex: 1 0 0;\n  text-align: center;\n  width: 25%;\n  padding: 0 0.5rem;\n  display: inline-block;\n  color: rgba(0, 0, 0, 0.65);\n  vertical-align: top;\n  line-height: 2;\n  user-select: none;\n}\n#editor-resizer .toolbar .group .btn.btn-group {\n  padding: 0;\n  display: inline-flex;\n  line-height: 2em;\n}\n#editor-resizer .toolbar .group .btn.btn-group .inner-btn {\n  flex: 1 0 0;\n  font-size: 2em;\n  width: 50%;\n  cursor: pointer;\n}\n#editor-resizer .toolbar .group .btn.btn-group .inner-btn:first-child {\n  border-right: 1px solid #ddd;\n}\n#editor-resizer .toolbar .group .btn.btn-group .inner-btn:active {\n  transform: scale(0.8);\n}\n#editor-resizer .toolbar .group .btn:not(:last-child) {\n  border-right: 1px solid #bbb;\n}\n#editor-resizer .toolbar .group .btn:not(.btn-group):active {\n  background-color: rgba(0, 0, 0, 0.1);\n}\n#editor-resizer .last-item {\n  margin-right: 5px;\n}\n#editor-resizer .showSize {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  padding: 0.1em;\n  border: 1px solid rgba(255, 255, 255, 0.8);\n  border-radius: 2px;\n  background-color: rgba(255, 255, 255, 0.8);\n  box-shadow: 0 0 3px rgba(0, 0, 0, 0.5);\n  transform: translateX(-50%);\n}\n");
    let n = (t.prototype.findLabel = function(t) {
        return this.config ? Reflect.get(this.config, t) : null
    }, t);

    function t(t) {
        this.config = e(e({}, r), t)
    }
    let r = {
        altTip: "Hold down the alt key to zoom",
        floatLeft: "Left",
        floatRight: "Right",
        center: "Center",
        restore: "Restore"
    };
    let o, s, a, l, d;
    try{
    o = HTMLElement, i(s = c, a = o), s.prototype = null === a ? Object.create(a) : (h.prototype = a.prototype, new h);
    }
    catch(e){
        
    }
    function h() {
        this.constructor = s
    }

    function c() {
        let t = null !== o && o.apply(this, arguments) || this;
        return t.originSize = null, t
    }
    let u = (p.prototype.initResizer = function() {
        let t = this.container.querySelector("#editor-resizer");
        t || ((t = document.createElement("div")).setAttribute("id", "editor-resizer"), t.innerHTML = function(t) {
            for (let i = [], e = 1; e < arguments.length; e++) i[e - 1] = arguments[e];
            return t.replace(/\{(\d+)\}/g, function(t, e) {
                return i.length > e ? i[e] : ""
            })
        }(l, this.i18n.findLabel("altTip"), this.i18n.findLabel("floatLeft"), this.i18n.findLabel("center"), this.i18n.findLabel("floatRight"), this.i18n.findLabel("restore")), this.container.appendChild(t)), this.resizer = t
    }, p.prototype.createToobar = function(t) {
        let e = '<div class="toolbar">\n    ' + (!1 !== (null === (e = null == t ? void 0 : t.toolbar) || void 0 === e ? void 0 : e.sizeTools) ? '<div class="group">\n      <a class="btn" data-width="100%">100%</a>\n      <a class="btn" data-width="50%">50%</a>\n      <a  class="btn btn-group">\n      <span data-width="-5" class="inner-btn">﹣</span>\n      <span data-width="5" class="inner-btn">﹢</span>\n      </a>\n      <a data-width="auto" class="btn last-item">{4}</a>\n      </div>' : "") + "\n    " + (!1 !== (null === (e = null == t ? void 0 : t.toolbar) || void 0 === e ? void 0 : e.alingTools) ? '<div class="group">\n      <a class="btn" data-float="left">{1}</a>\n      <a class="btn" data-float="center">{2}</a>\n      <a class="btn" data-float="right">{3}</a>\n      <a data-float="none" class="btn last-item">{4}</a>\n      </div>' : "") + "\n  </div>";
        return '<div class="handler" title="{0}"></div>' + (!0 === (null == t ? void 0 : t.showSize) ? '<div class="showSize" name="ql-size" title="{0}">{size}</div>' : "") + (!1 !== (null == t ? void 0 : t.showToolbar) ? e : "")
    }, p.prototype.positionResizerToTarget = function(t) {
        null !== this.resizer && (this.resizer.style.setProperty("left", t.offsetLeft + "px"), this.resizer.style.setProperty("top", t.offsetTop + "px"), this.resizer.style.setProperty("width", t.clientWidth + "px"), this.resizer.style.setProperty("height", t.clientHeight + "px"), null != d && d.showSize && (document.getElementsByName("ql-size").item(0).innerHTML = (t.getAttribute("width") ? t.getAttribute("width") : t.clientWidth) + ", " + (t.getAttribute("height") ? t.getAttribute("height") : t.clientHeight)))
    }, p.prototype.bindEvents = function() {
        null !== this.resizer && (this.resizer.addEventListener("mousedown", this.startResize), this.resizer.addEventListener("click", this.toolbarClick)), window.addEventListener("mouseup", this.endResize), window.addEventListener("mousemove", this.resizing)
    }, p.prototype.toolbarClick = function(t) {
        let e, i, n = t.target;
        (n.classList.contains("btn") || n.classList.contains("inner-btn")) && (i = n.dataset.width, e = n.dataset.float, t = this.resizeTarget.style, i ? ("iframe" !== this.resizeTarget.tagName.toLowerCase() && this.resizeTarget.removeAttribute("height"), "auto" === i ? this.resizeTarget.removeAttribute("width") : i.includes("%") ? this.resizeTarget.setAttribute("width", i) : (n = this.resizeTarget.getAttribute("width") || "", i = parseInt(i), n = n.includes("%") ? Math.min(Math.max(parseInt(n) + i, 5), 100) + "%" : Math.max(this.resizeTarget.clientWidth + i, 10) + "px", this.resizeTarget.setAttribute("width", n))) : "center" === e ? (t.setProperty("display", "block"), t.setProperty("margin", "auto"), t.removeProperty("float")) : (t.removeProperty("display"), t.removeProperty("margin"), t.setProperty("float", e)), this.positionResizerToTarget(this.resizeTarget))
    }, p.prototype.startResize = function(t) {
        t.target.classList.contains("handler") && 1 === t.which && (this.startResizePosition = {
            left: t.clientX,
            top: t.clientY,
            width: this.resizeTarget.clientWidth,
            height: this.resizeTarget.clientHeight
        })
    }, p.prototype.endResize = function() {
        this.startResizePosition = null
    }, p.prototype.resizing = function(t) {
        let e, i, n, r;
        this.startResizePosition && (e = t.clientX - this.startResizePosition.left, i = t.clientY - this.startResizePosition.top, n = this.startResizePosition.width, r = this.startResizePosition.height, n += e, r += i, t.altKey && (r = (t = this.resizeTarget.originSize).height / t.width * n), this.resizeTarget.setAttribute("width", Math.max(n, 30) + ""), this.resizeTarget.setAttribute("height", Math.max(r, 30) + ""), this.positionResizerToTarget(this.resizeTarget))
    }, p.prototype.destory = function() {
        this.container.removeChild(this.resizer), window.removeEventListener("mouseup", this.endResize), window.removeEventListener("mousemove", this.resizing), this.resizer = null
    }, p);

    function p(t, e, i) {
        this.resizer = null, this.startResizePosition = null, this.i18n = new n((null == i ? void 0 : i.locale) || r), l = this.createToobar(i), (this.resizeTarget = t).originSize || (t.originSize = {
            width: t.clientWidth,
            height: t.clientHeight
        }), d = i, this.container = e, this.initResizer(), this.positionResizerToTarget(t), this.resizing = this.resizing.bind(this), this.endResize = this.endResize.bind(this), this.startResize = this.startResize.bind(this), this.toolbarClick = this.toolbarClick.bind(this), this.bindEvents()
    }
    let f = function(t, e) {
            this.element = t, this.cb = e, this.hasTracked = !1
        },
        g = (b.track = function(t, e) {
            this.iframes.push(new f(t, e)), this.interval || (this.interval = setInterval(function() {
                b.checkClick()
            }, this.resolution))
        }, b.checkClick = function() {
            if (document.activeElement) {
                let t, e = document.activeElement;
                for (t in this.iframes) e === this.iframes[t].element ? 0 == this.iframes[t].hasTracked && (this.iframes[t].cb.apply(window, []), this.iframes[t].hasTracked = !0) : this.iframes[t].hasTracked = !1
            }
        }, b.resolution = 200, b.iframes = [], b.interval = null, b);

    function b() {}
    return function(t, i) {
        let n, r, o = t.root;
        o.addEventListener("click", function(t) {
            let e = t.target;
            t.target && ["img", "video"].includes(e.tagName.toLowerCase()) && (r = new u(n = e, o.parentElement, i))
        }), t.on("text-change", function(t, e) {
            o.querySelectorAll("iframe").forEach(function(t) {
                g.track(t, function() {
                    r = new u(n = t, o.parentElement, i)
                })
            })
        }), document.addEventListener("mousedown", function(t) {
            let e, i = t.target;
            i === n || null !== (t = null === (e = null == r ? void 0 : r.resizer) || void 0 === e ? void 0 : e.contains) && void 0 !== t && t.call(e, i) || (null !== (i = null == r ? void 0 : r.destory) && void 0 !== i && i.call(r), n = r = null)
        }, {
            capture: !0
        })
    }
});