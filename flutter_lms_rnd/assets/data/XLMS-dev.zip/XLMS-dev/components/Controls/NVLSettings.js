function NVLSettings(props) {
  return (
    <button 
          id={props.id} 
          className={"inline-flex rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white  " + props.className} 
          name={props.name} 
          type="button">
      {props.icon}
    </button>
  );
}

export default NVLSettings;
