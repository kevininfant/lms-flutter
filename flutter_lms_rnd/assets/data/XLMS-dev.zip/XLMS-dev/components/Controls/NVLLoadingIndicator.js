import React from 'react'

export default function NVLLoadingIndicator(props) {
  return (
    <div className={(props?.IsLoad || props?.IsLoad == undefined) ? "grid h-screen content-center" : "hidden"}>
      <div className="sk-folding-cube">
        <div className="sk-cube1 sk-cube before:bg-th-loader-bg-color"></div>
        <div className="sk-cube2 sk-cube before:bg-th-loader-bg-color"></div>
        <div className="sk-cube4 sk-cube before:bg-th-loader-bg-color"></div>
        <div className="sk-cube3 sk-cube before:bg-th-loader-bg-color"></div>
      </div>
    </div>

  )
}

