import { useState } from "react";

function Card(props) {
  const [IsHover, setIsHover] = useState(false);
  return (
    <>
      <div className={`${props.outerclass}`}>
        <div className={IsHover ? `rounded-lg overflow-hidden ${props.borderclass} ${props.className} cursor-pointer` : `rounded-lg overflow-hidden ${props.className}`} onMouseLeave={() => setIsHover(false)} onMouseOver={() => setIsHover(true)} onClick={props.onClick}>
        {props.children ? (
            props.children
          ) : (
          <div className="Center-Aligned-Items pt-7">
            <div className="flex justify-center">
              <span className={IsHover ? "th-body-icon-hover-bg-color cursor-pointer" : "text-th-body-icon-color cursor-pointer"} onMouseLeave={() => setIsHover(false)} onMouseOver={() => setIsHover(true)}>
                {props.CardIcon}
              </span>
            </div>
            {props.CardName?
            <div className="pt-4 text-center">
              <p className="text-gray-800 px-5 text-xs truncate font-semibold" title={props.CardName}>
                {props.CardName}
              </p>
            </div>
            :
            <div className="pt-4 text-center text-xs text-gray-600">
            {props.CardText}
            </div>
            }
          </div>
          )}
        </div>
      </div>
    </>
  );
}

export default Card;