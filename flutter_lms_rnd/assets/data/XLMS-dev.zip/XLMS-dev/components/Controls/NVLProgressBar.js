
const NVLProgressBar = (props) => {
  const Childdiv = {
    width: props.progress + "%",
    backgroundColor: props.bgcolor,
  };
  return (
  <div className="!w-32 h-[7px] lg:w-52  relative bg-[#AEB9DE] rounded">
      <div style={Childdiv} className={` absolute top-0 left-0 rounded h-full group`}>
      </div>
    </div>
  );
};

export default NVLProgressBar;
