import NVLSettingsCard from "@components/Controls/NVLSettingsCard";

export default function NVLPageModalPopup(props) {

  const CardsList = [
    { id: "1", CardIcon: "Team", CardName: "Allow only students who below to a specified cohort", ActionUrl: props.CohortAction },
    { id: "2", CardIcon: "Activity  Completion", CardName: "Require student to complete (or not complete) another activity", ActionUrl: props.ActivityCompletionAction },
    { id: "3", CardIcon: "Date", CardName: "Prevent access untill (or from) a specified date and time", ActionUrl: props.DateAction },
    // { id: "4", CardIcon: "Grade", CardName:"Find the best answer to your technical question, help others answer theirs", ActionUrl:props.GradeAction},
    { id: "5", CardIcon: "User Profile", CardName: "Control access based on fields within the student's profile", ActionUrl: props.UserProfileAction },
    { id: "6", CardIcon: "Restriction Set", CardName: "Add a set of nested restrictios to apply complex logic", ActionUrl: props.RestrictAction },
  ];
  if (props.open) {
    return (
      <div id="divPageModal" className={props.open ? "relative z-10" : "hidden"} >
        <div >
          <div className={props.open ? "fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" : "hidden"} />
        </div>
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0">
            <div className={`relative bg-white  rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 w-full ${props?.CustomWidth ? props?.CustomWidth : "md:w-[700px]"}`}>
              <div className="flex justify-between m-3">
                {props?.CustomHeader && <div title={props?.CustomHeader} className="pl-1 font-semibold break-all">
                  {props.CustomHeader?.length > 40 ? (props?.CustomHeader?.substring(0, 40) + "...") : props.CustomHeader}</div>}
                <span>{props.name}</span>
                <h6 className="font-semibold text-gray-700">
                  {props.ModalType == "Card" ? <span className="justify-center flex text-xl text-gray-700 font-semibold">Add Restriction</span> :
                    <span className="justify-center flex text-xl text-gray-700 font-semibold">{props.ScreenName}</span>}
                </h6>
                <i onClick={() => props.setOpen(!props.open)} className="fa-solid fa-xmark text-red-600 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-red-100"></i>
              </div>
              <div className="p-4">
                {(CardsList && props.ModalType == "Card") ?
                  CardsList.map((getItem, index) => {
                    return (
                      <div key={index}>
                        <NVLSettingsCard CardIcon={getItem.CardIcon} CardText={getItem.CardName} onClick={getItem.ActionUrl} borderclass="border-b-4 border-th-body-icon-hover-color" className="h-36 nvl-card-shadow" outerclass="p-3" />
                      </div>
                    );
                  }) :
                  props.PageComponent}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  else {
    return <></>
  }
}