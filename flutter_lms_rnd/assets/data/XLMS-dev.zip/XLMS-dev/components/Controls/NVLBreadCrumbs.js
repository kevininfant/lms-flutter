import { useRouter } from "next/router";
import NVLlabel from './NVLlabel';

export default function NVLBreadCrumbs({ Routes }) {
  const router = useRouter();
  return (
    <>
      <div className="flex gap-2 items-start py-2 px-3 my-2 font-semibold !text-sm">
        <svg width="14" height="11.695" viewBox="0 0 14 11.695" className="cursor-pointer my-auto" onClick={() => router.push("/")}>
          <defs>
            <clipPath id="clip-path">
              <rect id="Rectangle_599" data-name="Rectangle 599" width="14" height="11.695" fill="#1d74ff" />
            </clipPath>
          </defs>
          <g id="Home" transform="translate(0 -9)">
            <g id="Group_883" data-name="Group 883" transform="translate(0 9)" clipPath="url(#clip-path)">
              <path id="Path_198" data-name="Path 198" d="M14,5.415a1.165,1.165,0,0,0-.1.1c-.287.371-.572.742-.865,1.123L7,2,.966,6.641,0,5.385,7,0,9.983,2.294V1.331h2.033v.162c0,.747,0,1.494,0,2.242a.228.228,0,0,0,.1.2Q13.06,4.659,14,5.387Z" fill="#1d74ff" />
              <path id="Path_199" data-name="Path 199" d="M60.368,77.234l3.011,2.316c.57.439,1.142.877,1.709,1.32a.242.242,0,0,1,.089.162q.007,2.393,0,4.785c0,.022,0,.044,0,.076h-3.7V82.274H59.424v3.617H55.552v-.134q0-2.345,0-4.689a.238.238,0,0,1,.107-.214q2.288-1.755,4.572-3.516l.139-.1" transform="translate(-53.366 -74.198)" fill="#1d74ff" />
            </g>
          </g>
        </svg>
        <i className="fa-solid fa-chevron-right text-[10px] my-auto "></i>
        {Routes.map((crumb, i) => {
          const isLastItem = i === Routes.length - 1;
          if (!isLastItem) {
            return (
              <div key={i} className={"mr-1 space-x-2"}>
                <div className="hover-underline-animation cursor-pointer !text-xs">
                  <div onClick={() => router.push(crumb.path)} >{(crumb.breadcrumb?.length > 35) ? (crumb.breadcrumb?.substring(0, 30) + "...") : crumb.breadcrumb}</div>
                </div>
                <i className="fa-solid fa-chevron-right my-auto text-[10px]"></i>
              </div>
            );
          } else { return <NVLlabel className="!text-xs text-gray-600 mt-0.5" key={i} text={crumb.breadcrumb} ></NVLlabel> }
        })}
      </div>
    </>
  )
}