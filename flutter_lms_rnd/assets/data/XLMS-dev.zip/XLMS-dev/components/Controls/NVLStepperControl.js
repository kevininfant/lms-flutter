import NVLButton from "@Controls/NVLButton";

export default function StepperControl({ handleClick, currentStep, steps , Flag}) {
   return (
    <div className="nvl-FormContent flex justify-center">
         <NVLButton text=" Previous"   onClick={() => handleClick()} type={"button"} className={`cursor-pointer rounded-none border-2 bg-primary py-1 px-10 text-sm  text-white transition duration-200 ease-in-out hover:bg-slate-700 hover:text-white ${currentStep === 1 ? "hidden cursor-not-allowed opacity-50 border-2 " : ""}`}></NVLButton>
        <NVLButton  id ="btnStepperFinalsave" text={!Flag?(currentStep === steps.length ?  "Submit" : "Next"):""}  disabled={Flag? true : false}  type={"submit"} 
        className={Flag?"cursor-pointer rounded-none border-2 bg-primary py-1 px-10 text-sm  text-white transition duration-200 ease-in-out hover:bg-slate-700 hover:text-white":"w-28 nvl-button  bg-primary text-white"}>
         {Flag && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
        </NVLButton>
    </div>
  );
}
