export default function NVLFetchDataLoading(props) {
    return (
        <div className={`h-20 grid place-content-center py-3 relative ${props?.height}`}>
            <div className=" rounded-md w-full relative  ">
                <div className="Dash-loaders-shadow"></div>
                <div className="Dash-loader-box"></div>
            </div>
        </div>
             
    )
}
