import React, { useCallback, useEffect, useRef, useState } from "react";
import _ from "lodash/debounce";
import NVLlabel from "./NVLlabel";
import NVLButton from "./NVLButton";
import dynamic from "next/dynamic";
import NVLDynamicLanguagePage from "@Controls/NVLDynamicLanguagePage";
import NVLSelectField from "./NVLSelectField";
import { DynamicPageLanguageValidation } from "@Pages/ActivityManagement/CommonActivitySettings/CommonFunction"

const PageContentEditor = React.forwardRef((props, ref) => (<NVLDynamicLanguagePage {...props} forwardedRef={ref} />));
PageContentEditor.displayName = "PageContentEditor";

const NVLLangPage = (props) => {
  const [getData, setData] = useState(1);
  const [messageList, setMessageList] = useState([...props.EditContent]);
  const [RowCount, setRowCount] = useState(1);
  const getBase64 = (file) => {
    return new Promise((resolve) => {
      let baseURL = "";
      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        baseURL = reader.result;
        resolve(baseURL);
      };
    });
  };



  const deleteField = useCallback(
    (id, total, message) => {
      let messageListTemp = [];
      let refCurrent = {};
      let length = Object.keys(props.forwardedRef.current).length;
      for (let i = 0; i < length; i++) {
        if (id == "NVLCustomEditor" + i) {
          continue;
        }
        if (id > "NVLCustomEditor" + i) {
          messageListTemp = [
            ...messageListTemp,
            {
              Id: "NVLCustomEditor" + i,
              Language: props.watch("ddlLanguagePage" + i),
              Content: props.forwardedRef.current?.["NVLCustomEditor" + i],
            },
          ];
          props.setValue(
            "NVLCustomEditor" + i,
            props.forwardedRef.current?.["NVLCustomEditor" + i]
          );
          refCurrent = {
            ...refCurrent,
            ["NVLCustomEditor" + i]:
              props.forwardedRef.current?.["NVLCustomEditor" + i],
          };
        } else {
          messageListTemp = [
            ...messageListTemp,
            {
              Id: "NVLCustomEditor" + (i - 1),
              Language: props.watch("ddlLanguagePage" + i),
              Content: props.forwardedRef.current?.["NVLCustomEditor" + i],
            },
          ];
          props.setValue(
            "NVLCustomEditor" + (i - 1),
            props.forwardedRef.current?.["NVLCustomEditor" + i]
          );
          props.setValue(
            "ddlLanguagePage" + (i - 1),
            props.watch("ddlLanguagePage" + i)
          );
          refCurrent = {
            ...refCurrent,
            ["NVLCustomEditor" + (i - 1)]:
              props.forwardedRef.current?.["NVLCustomEditor" + i],
          };
        }
      }
      props.forwardedRef.current = refCurrent;
      props.setValue("ddlLanguagePage" + (length - 1), "");
      setMessageList(messageListTemp);
    },
    [props]
  );

  function resetData(event) {
    props.setValue(props.id + event, "");
    if (props.NoOfField == 2) {
      props.setValue(props.id + "-" + event, "");
    }
  }
  // Add Editor
  const AddCustomFields = () => {
    let validation = DynamicPageLanguageValidation(props.forwardedRef, "ddlLanguagePage");
    let length = Object.keys(props.forwardedRef.current).length;
    if (validation == "sucess") {
      length++;
    }
    let messageListTemp = [];
    let refCurrent = {};

    for (let i = 0; i < length; i++) {
      messageListTemp = [
        ...messageListTemp,
        {
          Id: "NVLCustomEditor" + i,
          Language: props.watch("ddlLanguagePage" + i),
          Content: props.forwardedRef.current?.["NVLCustomEditor" + i],
        },
      ];
      refCurrent = { ...refCurrent, ["NVLCustomEditor" + i]: props.forwardedRef.current?.["NVLCustomEditor" + i], };
      props.setValue("NVLCustomEditor" + i, props.forwardedRef.current?.["NVLCustomEditor" + i]);
    }
    props.forwardedRef.current = refCurrent;
    setMessageList(messageListTemp);
  };

  const DynamicTextBinding = useCallback(() => {
    return messageList && messageList.length > 0 && messageList.map((message, index) => {
      return (
        <>
          <div key={"id" + index}>
            <div className="grid gap-2">
              <div className="my-auto">
                <NVLSelectField
                  id={"ddlLanguagePage" + index}
                  className="w-32 "
                  options={props.LanguageType}
                  errors={props.errors}
                  register={props.register} />
              </div>
              <div className="">
                <PageContentEditor
                  ref={props.forwardedRef}
                  setMessageList={setMessageList}
                  messageList={messageList}
                  setData={setData}
                  watch={props.watch}
                  setValue={props.setValue}
                  EditContent={props.watch(message.Id)}
                  setContents={props.setContents}
                  contents={props.contents}
                  id={message.Id} />
                {index != 0 && (
                  <Todo
                    id={message.Id}
                    message={message}
                    deleteField={deleteField}
                  />
                )}
              </div>
            </div>

          </div>
        </>
      );
    });
  }, [messageList, props, deleteField]);

  const Todo = ({ id, message, deleteField }) => {
    const handleSubmitForDelete = (event) => {
      deleteField(id, event, message);
    };
    return (
      <NVLButton
        className="m-auto  shadow-lg  cursor-pointer h-8 w-8 hover:text-white  hover:bg-red-700 bg-red-100  inline-block text-red-700 rounded-full    "
        id={id}
        onClick={() => handleSubmitForDelete(RowCount - 1)}>
        <i className="fa-solid fa-trash"></i>
      </NVLButton>
    );
  };

  // testing cend

  return (
    <>
      {/* <div className="Editor_class">
        <div id={EDITTOR_HOLDER_ID}> </div>
      </div> */}
      <div className="grid gap-4 rounded">
        <DynamicTextBinding></DynamicTextBinding>

        <div id="app" className="grid gap-4">
          <nav className="relative w-full flex flex-wrap items-center justify-between py-2 bg-gray-100 text-gray-500 hover:text-gray-700 focus:text-gray-700 shadow-lg">
            <div className="container-fluid w-full flex flex-wrap items-center justify-between px-6">
              <div className="container-fluid">
                <NVLlabel ButtonType="primary" id="form__submit" onClick={() => AddCustomFields(messageList.length)}
                  className="text-xs bg-blue-500 hover:bg-blue-700 text-white font-bold py-1 px-2 rounded">

                  + Add Another Content
                </NVLlabel>

              </div>
            </div>
          </nav>
        </div>
      </div>
    </>
  );
};

export default NVLLangPage;
