import { useRef } from "react";
import NVLPanelHeader from "./NVLPannel";
import NVLResizer from "./NVLResize";

export const Direction = {
  Top: "top",
  TopLeft: "topLeft",
  TopRight: "topRight",
  Right: "right",
  Bottom: "bottom",
  BottomLeft: "bottomLeft",
  BottomRight: "bottomRight",
  Left: "left",
};

const NVLPannelResiziable = (props) => {
  const panelRef = useRef(null);
  const Fileref = useRef(null);
  const handleDrag = (movementX, movementY) => {
    const panel = panelRef.current;
    if (!panel) return;
    if (panel.offsetLeft + movementX < document.getElementById("parent").offsetWidth - panel.offsetWidth && document.getElementById("parent").offsetLeft <= panel.offsetLeft + movementX) {
      let b = panel.offsetLeft + movementX;
      let c = (b / document.getElementById("parent").offsetWidth) * 100
      panel.style.left = `${c}%`;
    }
    if (panel.offsetTop + movementY < document.getElementById("parent").offsetHeight - panel.offsetHeight && document.getElementById("parent").offsetTop <= panel.offsetTop + movementY) {
      let b = panel.offsetTop + movementY;
      let c = (b / document.getElementById("parent").offsetHeight) * 100;
      panel.style.top = `${c}%`;
    }
  };
  const handleResize = (direction, movementX, movementY) => {
    const panel = panelRef.current;
    if (!panel) return;
    const { width, height } = panel.getBoundingClientRect();

    const resizeTop = () => {
      if (panel.offsetTop + movementY > document.getElementById("parent").offsetTop) {
        panel.style.height = `${height - movementY}px`;
        panel.style.top = `${panel.offsetTop + movementY}px`;
      }
      else {
        return
      }
    };

    const resizeRight = () => {
      if (panel.offsetLeft + width + movementX < document.getElementById("parent").offsetLeft + document.getElementById("parent").offsetWidth) {
        panel.style.width = `${width + movementX}px`;
      }
      else {
        return
      }
    };

    const resizeBottom = () => {
            if (panel.offsetTop + height + movementY < document.getElementById("parent").offsetTop + document.getElementById("parent").offsetHeight) {
        panel.style.height = `${height + movementY}px`;
      }
      else {
        return
      }
    };

    const resizeLeft = () => {
      if (panel.offsetLeft + movementX > document.getElementById("parent").offsetLeft) {
        panel.style.width = `${width - movementX}px`;
        panel.style.left = `${panel.offsetLeft + movementX}px`;
      }
      else {
        return;
      }
    };

    switch (direction) {
      case Direction.TopLeft:
        resizeTop();
        resizeLeft();
        break;

      case Direction.Top:
        resizeTop();
        break;

      case Direction.TopRight:
        resizeTop();
        resizeRight();
        break;

      case Direction.Right:
        resizeRight();
        break;

      case Direction.BottomRight:
        resizeBottom();
        resizeRight();
        break;

      case Direction.Bottom:
        resizeBottom();
        break;

      case Direction.BottomLeft:
        resizeBottom();
        resizeLeft();
        break;

      case Direction.Left:
        resizeLeft();
        break;

      default:
        break;
    }
  };

  return (
    <>
      <div className="panel rounded-md max-w-full max-h-full	" style={props.width != undefined ? { "width": `${props.width}px` } : {}} ref={panelRef}>
        <div className="absolute -top-2 -right-8 z-3 flex justify-between">
          <i className="fa fa-solid close-icon-pattern fa-minus text-red-600 h-6 w-6 grid place-content-center cursor-pointer rounded-full bg-red-100" onClick={() => { panelRef.current.remove(); }}></i>
        </div>
        <div className="panel__container !max-h-full	!max-w-full">
          <NVLResizer onResize={handleResize} />
          <NVLPanelHeader onDrag={handleDrag} HeaderContent={props.HeaderContent} />
          <div className="panel__content absolute top-0 right-0 !max-h-full	!max-w-full overflow-hidden ">
          </div>
        </div>
      </div>
    </>
  );
};

export default NVLPannelResiziable;
