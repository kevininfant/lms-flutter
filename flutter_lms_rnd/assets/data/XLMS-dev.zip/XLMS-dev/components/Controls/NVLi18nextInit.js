import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import Backend from "i18next-http-backend";
import LanguageDetector from "i18next-browser-languagedetector";
// import translationEN from "@Public/assets/locales/en/translation.json";
import Tamil from "@Public/assets/locales/Tamil/Tamil.json";
import Telugu from "@Public/assets/locales/Telugu/Telugu.json";
import Hindi from "@Public/assets/locales/Hindi/Hindi.json";
import Malayalam from "@Public/assets/locales/Malayalam/Malayalam.json";
import Kannada from "@Public/assets/locales/Kannada/Kannada.json";

// const fallbackLng = ["english"];
const availableLanguages = ["Tamil", "Telugu", "Hindi", "Malayalam", "Kannada"];

const resources = {
  // en: {
  //   translation: translationEN
  // },
  Tamil: {
    translation: Tamil
  },
  Telugu: {
    translation: Telugu
  },
  Hindi: {
    translation: Hindi
  },
  Malayalam: {
    translation: Malayalam
  },
  Kannada: {
    translation: Kannada
  }
};

i18n
  .use(Backend)
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({ resources, detection: { checkWhitelist: true }, debug: false,
   whitelist: availableLanguages,   
   interpolation: {
       escapeValue: false
    }
  });

export default i18n;
