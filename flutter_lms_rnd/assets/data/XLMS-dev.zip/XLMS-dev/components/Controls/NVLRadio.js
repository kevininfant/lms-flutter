import NVLlabel from "@components/Controls/NVLlabel";

function NVLRadio(props) {
  return (
    <>
      <div className="flex items-center gap-2">
        <input
          id={props.id}
          type="radio"
          {...props.register(props.id, { shouldValidate: true })}
          className={"nvl-Radio " + props.className + "  " + (props.errors?.[props.id] ? "border-red " : "  border-gray-300")}
          label={props.label}
          name={props.name}
          size={props.size}
          value={props.value}
          disabled={props.disabled}
          checked={props.checked}
          defaultChecked={props.defaultChecked}
          onClick={props.onClick}
        />
        <NVLlabel
          for={props.id}
          text={props.text}
          showFull={props?.showFull}
          className={"text-gray-600 " + props.className}
          value={props.value} />
      </div>
    </>
  );
}

export default NVLRadio;
