import "@toast-ui/calendar/dist/toastui-calendar.min.css";
import TUICalendar from "@toast-ui/react-calendar";


export default function NVLCalander(props) {

  return (
    <TUICalendar
      {...props}
      ref={props.forwardedRef}
    />
  );
}