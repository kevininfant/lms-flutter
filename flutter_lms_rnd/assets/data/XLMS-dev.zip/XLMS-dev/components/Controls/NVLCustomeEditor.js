import React, { useCallback, useEffect, useRef, useState } from "react";
import EditorJS from "@editorjs/editorjs";
import Header from "@editorjs/header";
import LinkTool from "@editorjs/link";
import RawTool from "@editorjs/raw";
import ImageTool from "@editorjs/image";
import Checklist from "@editorjs/checklist";
import List from "@editorjs/list";
import Quote from "@editorjs/quote";
import CodeTool from "@editorjs/code";
import { StyleInlineTool } from "editorjs-style";
import Tooltip from "editorjs-tooltip";
import _ from "lodash/debounce";

const EDITTOR_HOLDER_ID = "editorjs";
const NVLCustomeEditor = (props) => {
  const DEFAULT_INITIAL_DATA =useCallback( () => {
    if(props.EditContent==null){
      return {
        time: new Date().getTime(),
        blocks: [
          {
            type: "paragraph",
            data: {
              text: "",
              level: 1,
            },
          },
        ],
      };
    }else{
      return JSON.parse(props.EditContent)
    }
  },[props.EditContent]);
  const getBase64 = (file) => {
    return new Promise((resolve) => {
      let baseURL = "";     
      let reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        baseURL = reader.result;
        resolve(baseURL);
      };
    });
  };

  const isInstance = useRef(EditorJS | null>(null));

  useEffect(() => {
    if (!isInstance.current) {
      initEditor();
    }
    return () => {    
      if (isInstance.current) {
        isInstance.current.destroy();
        isInstance.current = null;
      }
    };
  }, [isInstance,initEditor]);

  const onFileChange = useCallback(async (file) => {
    return await getBase64(file)
  },[]);

   const initEditor = useCallback(() => 
  {
    const editor = new EditorJS({
      holder: EDITTOR_HOLDER_ID,
      data: props.contents===undefined? DEFAULT_INITIAL_DATA() : JSON.parse(props.contents),
      onReady: () => {
        isInstance.current = editor;
      },
      onChange: _(async function () {
        try {
          const output = await editor.save();
      const contentsdt = JSON.stringify(output);
      props.setValue(props.id,contentsdt)
        } catch (err) {
        }
      }, 3000),
      autofocus: true,
      tools: {
        style: StyleInlineTool,
        tooltip: {
          class: Tooltip,
          config: {
            location: "left",
            highlightColor: "#FFEFD5",
            underline: true,
            backgroundColor: "#154360",
            textColor: "#FDFEFE",
            holder: "editorId",
          },
        },

        header: {
          class: Header,
          inlineToolbar: true,
          config: {
            defaultLevel: 1,
          },
        },

        raw: RawTool,
        linkTool: LinkTool,
        image: {
          class: ImageTool,
          config: {
            uploader: {
              async uploadByFile(file) 
              {
                return onFileChange(file).then((imageUrl) => {
                  return {
                    success: 1,
                    file: {
                      url: imageUrl,
                    },
                  };
                });
              },
            },
          },
        },
        checklist: {
          class: Checklist,
          inlineToolbar: true,
        },
        list: {
          class: List,
          inlineToolbar: true,
          config: {
            defaultStyle: "unordered",
          },
        },
        quote: {
          class: Quote,
          inlineToolbar: true,
          shortcut: "CMD+SHIFT+O",
          config: {
            quotePlaceholder: "Enter a quote",
            captionPlaceholder: "Quote's author",
          },
        },
        code: {
          class: CodeTool,
          inlineToolbar: true,
        },
      },
    });  
  },[DEFAULT_INITIAL_DATA, onFileChange, props]);


  return (
    <>
      <div className="Editor_class">
        <div id={EDITTOR_HOLDER_ID}> </div>
      </div>
    </>
  );
};

export default NVLCustomeEditor;
