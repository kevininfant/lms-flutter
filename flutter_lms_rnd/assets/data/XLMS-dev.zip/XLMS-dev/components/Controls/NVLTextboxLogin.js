export default function NVLTextboxLogin(props) {
  return (
    <div className="space-y-2">
      <div className="relative">
        <input {...props.register(props.id, { shouldValidate: true })} disabled={props.disabled} type={props.type ? props.type : "text"}
          id={props.id} className={`${props?.disabled ? "Disabled" : ""} block px-4 pl-10 pb-2.5 pt-2  rounded-full h-9 w-full text-sm text-gray-900 bg-transparent  border-gray-300  appearance-none focus:outline-none focus:ring-0 focus:border-blue-600 focus:font-medium `} placeholder={props?.labelText} autoComplete="off" />
        {props?.labelClassIcon ? props?.labelClassIcon : <svg id="user" width="14" height="16" viewBox="0 0 14 16" className="absolute top-2.5 left-4">
          <defs>
            <clipPath id="clip-path">
              <rect id="Rectangle_10" data-name="Rectangle 10" width="14" height="16" fill="#1d74ff" />
            </clipPath>
          </defs>
          <g id="Group_2" data-name="Group 2" >
            <path id="Path_30" data-name="Path 30" d="M2.589,205.936c-.191-.038-.384-.065-.571-.116a2.532,2.532,0,0,1-2.006-2.4,8.171,8.171,0,0,1,.581-3.613,3.36,3.36,0,0,1,1.556-1.789,3.188,3.188,0,0,1,1.527-.349,1.216,1.216,0,0,1,.5.165c.249.129.48.289.721.431a3.887,3.887,0,0,0,4.213,0c.195-.115.394-.226.577-.357a1.453,1.453,0,0,1,1.1-.214,3.106,3.106,0,0,1,2.377,1.627,6.446,6.446,0,0,1,.764,2.594,12.271,12.271,0,0,1,.064,1.4,2.61,2.61,0,0,1-2.48,2.587.663.663,0,0,0-.107.029Z" transform="translate(0 -189.936)" fill="#1d74ff" />
            <path id="Path_31" data-name="Path 31" d="M73.468,7.709a3.945,3.945,0,0,1-4.038-3.871,4.05,4.05,0,0,1,8.091.028,3.952,3.952,0,0,1-4.053,3.844" transform="translate(-66.577 0)" fill="#1d74ff" />
          </g>
        </svg>}
      </div>
      {props.showErros && <div className="{invalid-feedback} text-red-500 text-sm">{props?.errors?.[props.id]?.message}</div>}
    </div>
  );
}
