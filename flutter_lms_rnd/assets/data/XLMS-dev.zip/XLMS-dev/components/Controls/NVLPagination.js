
// import React, { useEffect } from "react";
// import NVLlabel from "@components/Controls/NVLlabel";
// import { NVLusePagination, DOTS } from "./NVLusePagination";

// const NVLPagination = (props) => {
//   const { onPageChange, totalCount, siblingCount = 1, currentPage, pageSize } = props;

//   const paginationRange = NVLusePagination({
//     currentPage,
//     totalCount,
//     siblingCount,
//     pageSize,
//   });

//   const onNext = () => {
//     onPageChange(currentPage + 1);
//   };

//   const onPrevious = () => {
//     onPageChange(currentPage - 1);
//   };

//   //Set currenct page details in local storage
//   useEffect(() => {
//     localStorage.setItem("currentPage", currentPage + 1);
//     return () => {
//       localStorage.removeItem("currentPage");
//     };
//   }, [currentPage]);

//   let lastPage = paginationRange[paginationRange.length - 1];

//   return (
//     <>
//       <ul id="paginationBar" className={"nvl-pagination-container nvl-pagination-bar"}>
//         {currentPage + 1 != 1 ? (
//           <li className={"nvl-pagination-item arrow-item"} onClick={onPrevious}>
//             <i className="fa-solid fa-angles-left text-base text-primary"></i>
//           </li>
//         ) : (
//           <li className={"nvl-pagination-item arrow-item disabled"}>
//             <i className="fa-solid fa-angles-left text-base text-gray-400"></i>
//           </li>
//         )}

//         {paginationRange.map((pageNumber, index) => {
//           if (pageNumber === DOTS) {
//             return (
//               <li key={index} className="nvl-pagination-item dots">
//                 &#8230;
//               </li>
//             );
//           }
//           return (
//             <li key={index} className={currentPage == pageNumber - 1 ? "nvl-pagination-item bg-gray-300" : "nvl-pagination-item"} onClick={() => onPageChange(pageNumber - 1)}>
//               {pageNumber}
//             </li>
//           );
//         })}
//         {currentPage + 1 != lastPage || (currentPage + 1 == lastPage && props.nextToken != null) || (currentPage + 1 == lastPage && currentPage * pageSize < props.TotalRecord) ? (
//           <li className={"nvl-pagination-item arrow-item"} onClick={onNext}>
//             <i className="fa-solid fa-angles-right text-base  text-primary"></i>
//           </li>
//         ) : (
//           <li className={"nvl-pagination-item arrow-item disabled"}>
//             <i className="fa-solid fa-angles-right text-base text-gray-400 "></i>
//           </li>
//         )}
//       </ul>
//       <div className="flex w-full justify-end m-auto px-5">
//         <NVLlabel className={"justify-end"} text={`Fetched ${props.totalCount}${props.nextToken != null ? "+" : ""} records`} />
//       </div>
//     </>
//   );
// };

// export default NVLPagination;

import NVLlabel from "@components/Controls/NVLlabel";
import { useEffect } from "react";
// import React, { useEffect } from "react";
// import NVLlabel from "@components/Controls/NVLlabel";
// import { NVLusePagination, DOTS } from "./NVLusePagination";

// const NVLPagination = (props) => {
//   const { onPageChange, totalCount, siblingCount = 1, currentPage, pageSize } = props;

//   const paginationRange = NVLusePagination({
//     currentPage,
//     totalCount,
//     siblingCount,
//     pageSize,
//   });

//   const onNext = () => {
//     onPageChange(currentPage + 1);
//   };

//   const onPrevious = () => {
//     onPageChange(currentPage - 1);
//   };

//   //Set currenct page details in local storage
//   useEffect(() => {
//     localStorage.setItem("currentPage", currentPage + 1);
//     return () => {
//       localStorage.removeItem("currentPage");
//     };
//   }, [currentPage]);

//   let lastPage = paginationRange[paginationRange.length - 1];

//   return (
//     <>
//       <ul id="paginationBar" className={"nvl-pagination-container nvl-pagination-bar"}>
//         {currentPage + 1 != 1 ? (
//           <li className={"nvl-pagination-item arrow-item"} onClick={onPrevious}>
//             <i className="fa-solid fa-angles-left text-base text-primary"></i>
//           </li>
//         ) : (
//           <li className={"nvl-pagination-item arrow-item disabled"}>
//             <i className="fa-solid fa-angles-left text-base text-gray-400"></i>
//           </li>
//         )}

//         {paginationRange.map((pageNumber, index) => {
//           if (pageNumber === DOTS) {
//             return (
//               <li key={index} className="nvl-pagination-item dots">
//                 &#8230;
//               </li>
//             );
//           }
//           return (
//             <li key={index} className={currentPage == pageNumber - 1 ? "nvl-pagination-item bg-gray-300" : "nvl-pagination-item"} onClick={() => onPageChange(pageNumber - 1)}>
//               {pageNumber}
//             </li>
//           );
//         })}
//         {currentPage + 1 != lastPage || (currentPage + 1 == lastPage && props.nextToken != null) || (currentPage + 1 == lastPage && currentPage * pageSize < props.TotalRecord) ? (
//           <li className={"nvl-pagination-item arrow-item"} onClick={onNext}>
//             <i className="fa-solid fa-angles-right text-base  text-primary"></i>
//           </li>
//         ) : (
//           <li className={"nvl-pagination-item arrow-item disabled"}>
//             <i className="fa-solid fa-angles-right text-base text-gray-400 "></i>
//           </li>
//         )}
//       </ul>
//       <div className="flex w-full justify-end m-auto px-5">
//         <NVLlabel className={"justify-end"} text={`Fetched ${props.totalCount}${props.nextToken != null ? "+" : ""} records`} />
//       </div>
//     </>
//   );
// };

// export default NVLPagination;

import { DOTS, NVLusePagination } from "./NVLusePagination";

const NVLPagination = (props) => {
  const { onPageChange, totalCount, siblingCount = 1, currentPage, pageSize } = props;

  const paginationRange = NVLusePagination({
    currentPage,
    totalCount,
    siblingCount,
    pageSize,
  });

  const onNext = () => {
    onPageChange(currentPage + 1);
  };

  const onPrevious = () => {
    onPageChange(currentPage - 1);
  };

  //Set currenct page details in local storage
  useEffect(() => {
    localStorage.setItem("currentPage", currentPage + 1);
    return () => {
      localStorage.removeItem("currentPage");
    };
  }, [currentPage]);

  let lastPage = paginationRange[paginationRange.length - 1];
  return (
    <>
      <ul id="paginationBar" className={"nvl-pagination-container nvl-pagination-bar"}>
        {currentPage + 1 != 1 ? (
          <li className={"nvl-pagination-item arrow-item"} onClick={onPrevious}>
            <i className="fa-solid fa-angles-left text-base text-primary"></i>
          </li>
        ) : (
          <li className={"nvl-pagination-item arrow-item disabled"}>
            <i className="fa-solid fa-angles-left text-base text-gray-400"></i>
          </li>
        )}

        {paginationRange.map((pageNumber, index) => {
          if (pageNumber === DOTS) {
            return (
              <li key={index} className="nvl-pagination-item dots">
                &#8230;
              </li>
            );
          }
          return (
            <li key={index} className={currentPage == pageNumber - 1 ? "nvl-pagination-item bg-gray-300" : "nvl-pagination-item"} onClick={() => onPageChange(pageNumber - 1)}>
              {pageNumber}
            </li>
          );
        })}
        {currentPage + 1 != lastPage || (currentPage + 1 == lastPage && props.nextToken != null) || (currentPage + 1 == lastPage && (currentPage+1) * pageSize < props.TotalRecord* pageSize) ? (
          <li className={"nvl-pagination-item arrow-item"} onClick={onNext}>
            <i className="fa-solid fa-angles-right text-base  text-primary"></i>
          </li>
        ) : (
          <li className={"nvl-pagination-item arrow-item disabled"}>
            <i className="fa-solid fa-angles-right text-base text-gray-400 "></i>
          </li>
        )}
      </ul>
      <div className="float-right -my-6 w-fit px-5">
        <NVLlabel className={"justify-end"} text={`Fetched ${props.totalCount} ${props.nextToken != null ? "+" : ""} records`} />
      </div >
    </>
  );
};

export default NVLPagination;
