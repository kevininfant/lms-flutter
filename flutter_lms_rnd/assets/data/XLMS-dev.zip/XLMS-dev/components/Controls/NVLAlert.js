let TimeOutModal, TimeOutAnimation, TimeOutCustomClose, Flag = false, ModalOnClick, Animate, AnimateBack, Postion, Alignment;
export default function NVLAlert(props) {
  let BgColor ,Icon ,IconColor ,TextColor, TextColorSmallText, MessageTop,MessageBottom;
  ModalOnClick = () => { ModalClose() };
  if (props.ModalInfo) {
    Animate = "-translate-x-7";
    AnimateBack = "translate-x-7";
    Postion = "top-0";
    Alignment = "justify-end";
    if (props.ModalInfo == "Success") {
      BgColor = "bg-green-100";
      Icon = "fa fa-check-circle";
      IconColor = "text-green-500";
      TextColor = "text-green-500";
      TextColorSmallText = "text-gray-500";
      MessageTop = "Success";
      MessageBottom = "Details have been saved successfully."
    }
    else if (props.ModalInfo == "Warning") {
      BgColor = "bg-orange-100";
      Icon = "fa fa-exclamation-triangle";
      IconColor = "text-orange-500";
      TextColor = "text-orange-500";
      TextColorSmallText = "text-gray-500";
      MessageTop = "Warning";
      MessageBottom = "Please Check and Fill the Form."
    } else if (props.ModalInfo == "Info") {
      BgColor = "bg-blue-100";
      Icon = "fa fa-info-circle";
      IconColor = "text-blue-500";
      TextColor = "text-blue-500";
      TextColorSmallText = "text-gray-500";
      MessageTop = "In Progress";
      MessageBottom = "Creation is in progress. Will contact you once the creation is over"
    }
    else if (props.ModalInfo == "Danger") {
      BgColor = "bg-red-100";
      Icon = "fa fa-times";
      IconColor = "text-red-500";
      TextColor = "text-red-500";
      TextColorSmallText = "text-gray-500";
      MessageTop = "Error";
      MessageBottom = "Server Error. Please try again after some time."
    }
    if (props.ModalOnClick) {
      Flag = true;
      ModalOnClick = () => { props.ModalOnClick(); };
    }
    else {
      Flag = false;
    }
  }
  return (
    <>
      <div id="modepopup" className="invisible top-0 fixed z-50	  bottom-0 right-0 w-full h-full left-0   p-12">
        <div id="modepopup_inside" className={`sticky top flex ${Alignment} transform duration-500`}>
          <div id="divNVLModal" className={`shadow-sm absolute ${Postion}  mx-auto pl-4   rounded-lg lg:w-1/4 ${props.BgColor ? props.BgColor : BgColor}`} >
            <div id="alert-3 " className={`flex p-4 pl-0`} role="alert">
              <div className="modal-header flex w-full justify-start px-2 my-auto">
                {!props.ModalType && <i className={`${props.Icon ? props.Icon : Icon} ${props.IconColor ? props.IconColor : IconColor} my-auto  text-2xl px-1`}></i>}
                <div className="break-words">
                  <div className={`ml-3 text-sm font-semibold ${props.TextColor ? props.TextColor : TextColor} m-1`}>{props.MessageTop ? props.MessageTop : MessageTop}</div>
                  <div className={`ml-3 text-sm font-medium break-words ${props.TextColorSmallText ? props.TextColorSmallText : TextColorSmallText}`}>{props.MessageBottom ? props.MessageBottom : MessageBottom}</div>
                </div>
              </div>
              <div className="modal-header flex justify-end my-auto">
                <div>
                  <span id="lblClose" className="xl:pr-2 xl:pt-2 text-gray-500 cursor-pointer hover:text-red-600" onClick={props.ModalOnClick ? () => { clearTimeout(TimeOutCustomClose); props.ModalOnClick(); } : ModalOnClick}>
                    <i className={`fa-regular fa-circle-xmark text-2xl`}></i>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
export function ModalCustomClose() {
  clearTimeout(TimeOutModal);
  TimeOutCustomClose = setTimeout(function () {
    clearTimeout(TimeOutModal);
    ModalOnClick();
  }, 3000);
}
export function ModalTimeout() {
  clearTimeout(TimeOutModal);
  TimeOutModal = setTimeout(function () {
    if (document.getElementById("modepopup") &&!document.getElementById("modepopup").classList.contains("invisible") && document.getElementById("modepopup_inside").classList.contains(Animate)) {
      document.getElementById("modepopup_inside") != null ? document.getElementById("modepopup_inside").classList.remove(Animate) : "";
      document.getElementById("modepopup_inside") != null ? document.getElementById("modepopup_inside").classList.add(AnimateBack) : "";
      TimeOutAnimation = setTimeout(function () {
        if (document.getElementById("modepopup") && !document.getElementById("modepopup").classList.contains("invisible")) {
          document.getElementById("modepopup") != null ? document.getElementById("modepopup").classList.add("invisible") : "";
        }
      }, 500);
    }
  }, 3000);
}
export function ModalOpen() {
  document.getElementById("modepopup_inside") != null ? document.getElementById("modepopup_inside").classList.remove(AnimateBack) : "";
  document.getElementById("modepopup") != null ? document.getElementById("modepopup").classList.remove("invisible") : "";
  document.getElementById("modepopup_inside") != null ? document.getElementById("modepopup_inside").classList.add(Animate) : "";
  if (Flag) {
    ModalCustomClose();
  }
  else {
    ModalTimeout();
  }
}
export function ModalClose() {
  clearTimeout(TimeOutCustomClose);
  clearTimeout(TimeOutModal);
  document.getElementById("modepopup_inside") != null ? document.getElementById("modepopup_inside").classList.remove(Animate) : "";
  document.getElementById("modepopup_inside") != null ? document.getElementById("modepopup_inside").classList.add(AnimateBack) : "";
  TimeOutAnimation = setTimeout(function () {
    document.getElementById("modepopup") != null ? document.getElementById("modepopup").classList.add("invisible") : "";
  }, 500);
}
