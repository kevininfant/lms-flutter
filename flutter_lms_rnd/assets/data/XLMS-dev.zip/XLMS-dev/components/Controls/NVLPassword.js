import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLToolTip from "@components/Controls/NVLToolTip";
import NVLlabel from "@components/Controls/NVLlabel";
import { useEffect, useState } from "react";
function NVLPassword(props) {
    const [type, setType] = useState("password")
    const togglePassword = () => {
        setType((type) => {
            if (type == "text") {
                return "password";
            }
            else {
                return "text";
            }
        })
    }
    useEffect(() => {
        if (props.changeType)
            setType(() => {
                return "password";
            })
    }, [props.changeType])
    return (
        <>
            <div>
               
            {props.labelText&& <NVLlabel className={props.labelClassName} text={props.labelText}>{props.className.indexOf("nvl-mandatory")!=-1 && <span className="text-red-500 text-lg">*</span>}</NVLlabel>}
                <div className="relative flex">
                    <NVLTextbox icon={true} FieldType="password" title={props.title} id={props.id} type={type} className={props.className} register={props.register} errors={props.errors}></NVLTextbox>
                    <div className={`absolute top-2 ${props?.eyeIconStyle?props?.eyeIconStyle:"left-[355px]"}`}>
                        <i className={`fa ${type == "text" ? "fa-eye-slash" : "fa-eye"} text-primary pr-2`} onClick={togglePassword}></i>
                    </div>
                    {props.HelpInfo != undefined && <NVLToolTip PopDetail={props.HelpInfo} PopIcon={"pl-3 mb-3" + props.HelpInfoIcon} />}
                </div>

            </div>
            <div className={"{invalid-feedback}   text-red-500 text-sm "}>
                {props.errors?.[props.id]?.message}
            </div>

        </>

    )
}
export default NVLPassword;