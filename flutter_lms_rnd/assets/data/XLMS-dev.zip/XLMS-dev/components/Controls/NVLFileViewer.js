import { Image } from "@aws-amplify/ui-react";
import { APIGatewayPostRequest } from "DBConnection/ErrorResponse";
import { useCallback, useMemo, useState } from "react";
import ReactPlayer from "react-player";
import NVLButton from "./NVLButton";


export default function NVLFileViewer(props) {
  const [eventHandler, setEventHandler] = useState(false)
  const Type = useMemo(() => {
    let Type
    try {
      Type = props?.src?.substring(props?.src.lastIndexOf(".") + 1).toLowerCase();
    }
    catch (e) {
      Type = "";
    }
    return Type;
  }, [props?.src]);
  const onButtonClick = useCallback(async () => {
    setEventHandler(true)
    let fetchURL = process.env.APIGATEWAY_INVOKEURL;

    let headers = {
      method: "POST",
      headers: {
        authorizationtoken: props.token,
        bucketName: props.BucketName,
      },
      body: props.src.substring(1),
    };
    let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
    const handleDownload = (url) => {

      fetch(url).then(response => {
        response.blob().then(blob => {
          // Creating new object of PDF file
          const fileURL = window.URL.createObjectURL(blob);
          // Setting various property values
          let link = document.createElement('a');
          let temp = props.src.split("/")
          link.href = fileURL;
          link.download = temp.at(-1);
          link.click();
          link.remove();
        })
      })
      setEventHandler(false)
    };
    handleDownload(await FinalStatus.res?.text())


  }, [props.token, props.BucketName, props.src])

  // eslint-disable-next-line react-hooks/exhaustive-deps
  const IsDownloadTrue = () => {
    return (
      (props?.IsDownload == true) ?
        <div className="flex space-x-2 justify-center">
          <div>
            <NVLButton id="btnSubmit" onClick={onButtonClick} text={!eventHandler ? "Download Your File" : ""} disabled={eventHandler ? true : false} type="submit" className={`${eventHandler ? "w-40 nvl-button bg-primary text-white pointer-events-none" : "w-40 nvl-button bg-primary text-white"}`}>
              {eventHandler && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
            </NVLButton>
          </div>
        </div>
        : (props?.IsDownload == false) ?<div className="p-2 bg-slate-50 items-center text-slate-50 leading-none lg:rounded-full flex lg:inline-flex my-4" role="alert">
            <span className="flex rounded-full bg-slate-600 uppercase px-2 py-1 text-xs font-bold mr-3"><i className="fa-solid fa-circle-exclamation"></i></span>
            <p className="font-bold text-xs text-slate-600">Download Is Not Accessible</p>
          </div>

          : ""
    )
  }
  const OtherTypesOfFiles = useCallback(() => {
    const onError = (e) => { };
    // let Type = props?.src && props?.src.substring(props?.src.lastIndexOf(".") + 1).toLowerCase();
    if (Type == "jpg" || Type == "png" || Type == "jpeg") {
      return (<div className={`rounded-lg min-h-[500px] max-h-[500px] mx-auto bg-white`}
      ><Image download alt="testimonial" className="w-full h-[500px] p-1 my-auto bg-gray-200 inline-block border-gray-200"
        src={props?.src} />
        <div className="flex justify-end py-4">
          {IsDownloadTrue()}
        </div>
      </div>)

    } else if (Type == "mp4" || Type == "mp3") {
      return (
        <>
          {Type == "mp4" ? <div className={` ${props?.className ? props?.className : " min-h-[500px] max-h-[500px]"}  mx-auto  bg-white`}>
            <ReactPlayer
              config={{ file: { attributes: { controlsList: props?.IsDownload ? "" : 'nodownload' } } }}
              onContextMenu={e => e.preventDefault()}
              width="100%"
              height="500px"
              url={props?.MpdUrlPath != undefined && props?.MpdUrlPath != "" ? props?.MpdUrlPath : props?.src}
              playing={false}
              controls={true} />
          </div>
            :
            <div className="flex justify-center">
              <ReactPlayer
                config={{ file: { attributes: { controlsList: props?.IsDownload ? "" : 'nodownload' } } }}
                onContextMenu={e => e.preventDefault()}
                width="50%"
                height="100px"
                url={props?.src}
                playing={false}
                controls={true} />
            </div>
          }
          <div className="flex justify-end">
            {IsDownloadTrue()}
          </div>
        </>);
    } else if (Type == "pdf") {
      return (
        <>
          <div className={`overflow-x-auto border-gray-200 min-h-[500px] max-h-[500px] mx-auto  bg-white`}>
            <iframe src={props?.src + "#toolbar=0"} width="100%" height="500px">
            </iframe>
          </div>
          <div className="flex justify-end">
            {IsDownloadTrue()}
          </div>
        </>
      )
    } else if (Type == "avi" || Type == "mov") {
      return (<>
        {(props?.MpdUrlPath != undefined && props?.MpdUrlPath != "") ? <div className={` ${props?.className ? props?.className : " m-4 min-h-[500px] max-h-[500px]"}  mx-auto  bg-white`}>
          <ReactPlayer
            config={{ file: { attributes: { controlsList: props?.IsDownload ? "" : 'nodownload' } } }}
            onContextMenu={e => e.preventDefault()}
            width="100%"
            height="500px"
            url={props?.MpdUrlPath != undefined && props?.MpdUrlPath != "" ? props?.MpdUrlPath : props?.src}
            playing={false}
            controls={true} />
        </div>
          :
          <div className="bg-yellow-100 border-t-4 border-yellow-500 rounded-b text-yellow-900 px-4 py-3 shadow-md" role="alert">
            <div className="flex">
              <div className="py-1"><svg className="fill-current h-6 w-6 text-yellow-500 mr-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z" /></svg></div>
              <div className="flex justify-center">
                <p className="font-semibold text-xs mt-1">Cannot play back the file. The format is not supported</p>
              </div>
            </div>
          </div>
        }
        <div className="flex justify-end">
          {IsDownloadTrue()}
        </div>
      </>)
    }
    else {
      return (
        <section className="py-6 dark:bg-violet-400 dark:text-gray-900">
          <div className="bg-yellow-100 border-t-4 border-yellow-500 rounded-b text-yellow-900 px-4 py-3 shadow-md" role="alert">
            <div className="flex">
              <div className="py-1"><svg className="fill-current h-6 w-6 text-yellow-500 mr-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M2.93 17.07A10 10 0 1 1 17.07 2.93 10 10 0 0 1 2.93 17.07zm12.73-1.41A8 8 0 1 0 4.34 4.34a8 8 0 0 0 11.32 11.32zM9 11V9h2v6H9v-4zm0-6h2v2H9V5z" /></svg></div>
              <div className="flex justify-center">
                <p className="font-semibold text-xs mt-1 ">Cannot view the file. The format is not supported. Download to view the file.</p>
              </div>
            </div>
          </div>
          <div className="container mx-auto flex flex-col items-center justify-center p-4 space-y-8 md:p-10 md:px-24 xl:px-48">
            {IsDownloadTrue()}</div>
        </section>
      )
    }
    return <></>;
  }, [Type, props?.src, props?.className, props?.IsDownload, props.MpdUrlPath, IsDownloadTrue]);

  return (
    <>
      {props?.src && Type && <OtherTypesOfFiles />}
    </>
  );
}
