import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { Auth } from "aws-amplify";
import {
  APIGatewayPutRequest
} from "DBConnection/ErrorResponse";
import { useCallback } from "react";
import NVLLoader from "./NVLLoader";


export default function NVLAddCustomField(props) {

  // file Upload Function
  // eslint-disable-next-line react-hooks/exhaustive-deps
  async function fileValidation(e, index) 
  {
    props.setValue("File", "Uploading");
    let fileInput = document.getElementById(e.target.id);
    let filePath = fileInput.value;
    let allowedExtensions =
      props.ActivityType == "File"
        ? /(\.docx|\.zip|\.pdf|\.csv|\.jpg|\.jpeg|\.txt|\.xlsx)$/i
        : props.ActivityType == "Assignment"
        ? /(\.doc|\.docx)$/i
        : props.ActivityType == "Video"
        ? /(\.mp4|\.mpeg4)$/i
        : props.ActivityType == "ScormPackage"
        ? /(\.zip|\.raz)$/i
        : /(\.csv|\.txt|\.doc|\.docx|\.pdf|\.jpeg|\.jpg|\.png)$/i;
    allowedExtensions =
      props.CurrentDiv == "LearningBytes"
        ? /(\.zip|\.h5p|\.rar|\.tar)$/
        : allowedExtensions;

    if (!allowedExtensions.exec(filePath) || fileInput == null) {
      fileInput.value = "";
      props.setFileValues((FileValues) => {
        FileValues[index] = {
          ...FileValues[index],
          TextName: "Select File",
          FilePath: "",
        };
        return FileValues;
      });
      props.setValue("File", "fileType", { shouldValidate: true });
      return false;
    } else {
      await UploadFile(e, index);
    }
  }

  async function UploadFile(e, index) {
    const file = e.target.files[0];
    const CSVReader = new FileReader();
    CSVReader.onload = async function (e) {
      const text = e.target.result;
      let lines = text.split("\n");
      let values = lines[0].split(",");
      let isCSVDatacheck = false;
      if (!isCSVDatacheck) {
        let fetchURL =
          process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
          `?FileName=${file.name}&TenantID=${props?.TenantInfo?.TenantID}&BucketName=${props?.TenantInfo?.BucketName}&RootFolder=${props?.TenantInfo?.RootFolder}&ActivityType=${props?.ActivityType}&Type=Activity&ActivityID=${props.ActivityID}`;
          // process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
          // `?FileName=${file.name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props?.TenantInfo?.BucketName}&RootFolder=${props?.TenantInfo?.RootFolder}&Type=Activity&ActivityType=${props?.ActivityType}&Type=Activity&ActivityID=${props.ActivityID}`;

          if (props.ActivityType == "ScormPackage") {

            if (props.mode == "ModuleDirect") {
              fetchURL =process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
                `?FileName=${e.target.files[0].name}&&TenantID=${props.TenantInfo.TenantID}&&CourseType=Module&&RootFolder=${props.TenantInfo.RootFolder}&&BucketName=${props.TenantInfo.BucketName}&&Type=Course&&ManagementType=CourseManagement`;
            } else if (props.mode == "Edit") {
              fetchURL =process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +`?FileName=${file?.name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&Type=Activity&ActivityType=${props.ActivityType}`;
            }
          }
        
          let headers = {
          method: "GET",
          headers: {
            authorizationToken: await Auth.currentSession().then((s) =>
              s.getAccessToken().getJwtToken()
            ),
          },
        };
        let Extension = file.name
          .substring(file.name.lastIndexOf(".") + 1)
          .toLowerCase();
        let ContentType =
          Extension == "csv"
            ? "text/" + Extension
            : "application/" + Extension;
        let presignedHeader = {
          method: "PUT",
          headers: {
            //"x-amz-acl": "public-read",
            "content-type": ContentType,
          },
          body: file,
        };
        let FinalStatus = await APIGatewayPutRequest(
          fetchURL,
          headers,
          presignedHeader
        );

        if (FinalStatus[0] != "Success") {
          props.setFileValues((FileValues) => {
            FileValues[index] = {
              ...FileValues[index],
              TextName: "Select File",
              FilePath: "",
              pathchanged: false,
            };
            return FileValues;
          });
          props.setValue("File", "Error", { shouldValidate: true });
          return;
        } else {
          props.setValue("File", "exist", { shouldValidate: true });

          props.setFileValues(
            (FileValues) => {           
            FileValues[index] = {
              ...FileValues[index],
              TextName: file.name,
              FilePath: FinalStatus[1],
              pathchanged: true,
            };
            return FileValues;
          });
        }
      }
    };
    CSVReader.readAsText(file);
  }
  const deleteField = useCallback(
    (e, index) => {
      if (!(index == 0 && props.FileValues.length==1))
        props.setFileValues((FileValues) => {
          FileValues.splice(index, 1);
          return [...FileValues];
        });
    },
    [props]
  );
  const AddCustomFields = useCallback(() => 
  {
    let isAdd=true;
    props.FileValues.map((e,index)=>
    { 
     let la=document.getElementById("ddlLanguageView"+index)?.options[document.getElementById("ddlLanguageView"+index).selectedIndex].value;

    if(e.TextName=="Select File" ||la=="")
    {
      document.getElementById("divError"+index)?.classList?.remove("hidden")
      isAdd=false; 
      return;     
    }else if( document.getElementById("divError"+index)?.classList?.contains("hidden")){
      document.getElementById("divError"+index)?.classList?.add("hidden")
    }
    else if( document.getElementById("divFileError")?.classList?.contains("hidden")){
      document.getElementById("divFileError")?.classList?.add("hidden")
    }})
    if(isAdd){
    props.setFileValues((FileValues) => {     
      FileValues = [
        ...FileValues,
        {
          TextName: "Select File",
          FilePath: "Select File",
          path: "",
          Language:"",
          pathchanged: true,
        },
      ];
      return FileValues;
    });
  } 
    
  }, [props]);
  const Temp = useCallback(() => {
    return (
      <div className="w-64 md:w-96 relative">
        <div className="">

          {props.FileValues.map((message, index) => {
            return (           
              <div key={"divId"+index} className={`${index==0?"mb-8":""}`}>
                <div className="flex justify-between">
                  <NVLSelectField
                    id={"ddlLanguageView"+index}       
                    className="w-32"
                    options={props.SelectFieldOptions}
                    errors={props.errors}
                    register={props.register}/>
                  <div>
                    <NVLFileUpload
                      id={props.id + index}
                      className="!w-56"
                      text={
                        message?.TextName == null
                          ? message.FileName?message?.FileName:"Select File" 
                          : message.TextName?.length > 20
                          ? message.TextName?.substring(0, 10) + "..."
                          : message.TextName
                      }
                      errors={props.errors}
                      register={props.register}
                      onChange={(e) => fileValidation(e, index)}/>
                    <NVLLoader className={`text-sm ${props.Watch + 1 == "Uploading" ? "" : "hidden"}`} id={props.LoaderId + index}/>                    
                  </div>
                </div>
                <div className={`${index==0?"hidden":""}`}>
                <NVLlabel key={index} className={`relative left-[390px] bottom-9 cursor-pointer h-8 w-8 shadow-lg hover:bg-red-100   inline-block text-red-600  rounded-full `} id="todo__delete" onClick={(e) => deleteField(e, index)} >
                  <i className=" fa-solid fa-eraser absolute top-1.5 left-2 text-lg"></i>
                </NVLlabel>
                </div>
                <div id={"divError"+index} className="text-sm hidden">Please choose correct Language and File</div>
              </div>          
            );
          })}
          
        </div>
        <div id="app" className={`grid gap-4 absolute ${props.FileValues.length > 1 ? "-right-20" : "-right-10 top-1"   } bottom-10`}>   
          <NVLlabel onClick={() => AddCustomFields()} className="text-xs  hover:bg-blue-700 shadow-lg text-blue-600 font-bold py-1 px-2 rounded-full">
            <i className="fa-solid fa-plus-minus"></i>
          </NVLlabel>
        </div>
      </div>
    );
  }, [props.FileValues, props.SelectFieldOptions, props.id, props.errors, props.register, props.Watch, props.LoaderId, fileValidation, deleteField, AddCustomFields]);

  return (
    <>
      <Temp />
    </>
  );
}
