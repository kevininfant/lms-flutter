import NVLGridTableCell from "@components/Controls/NVLGridTableCell";

function NVLGridTableRows(props) {
    return (
        <tbody className="text-th-grid-txt-color">
            {props.RowsData &&
                props.RowsData.map((getItem, index) => (
                    <tr key={index} className={(index % 2 == 0  && !(props?.glossary && index % 2 == 0 )) ? "bg-th-grid-th-bg-start-color" : "bg-th-grid-td-bg-end-color"}>
                        {props?.HeaderColumn?.length > 0 &&
                            props.HeaderColumn.map((Columnlink, ColumnCount) => (
                                <NVLGridTableCell ColumnCount={ColumnCount} key={ColumnCount} ControlItem={getItem[props.HeaderColumn[ColumnCount].Columnvalue]} HeaderColumnCss={Columnlink.HeaderCss} ></NVLGridTableCell>
                            ))}
                    </tr>
                ))}
        </tbody>
    );
}
export default NVLGridTableRows;