import { Loader } from "@aws-amplify/ui-react";

function NVLLoader(props) {
  return (
    <>
      <Loader 
             id={props.id} 
             className={props.className} 
             variation={props.variation} 
             emptyColor={props.emptyColor} 
             filledColor={props.filledColor} 
             width={props.width} 
             height={props.height}>
      </Loader>
    </>
  );
}

export default NVLLoader;
