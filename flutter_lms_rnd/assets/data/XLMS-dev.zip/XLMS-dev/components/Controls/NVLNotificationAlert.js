import { Menu, Transition } from "@headlessui/react";
import router from 'next/router';
import { Fragment } from "react";
import NVLButton from "./NVLButton";
import NVLlabel from "./NVLlabel";
export default function NVLNotificationAlert({ newData, NotificationPK, updateReadValues }) {
  const date1 = new Date(Date.now() + new Date().getTimezoneOffset() * 60000);
  function getDifferenceInDays(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / (1000 * 60 * 60 * 24);
  }
  function getDifferenceInHours(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / (1000 * 60 * 60);
  }
  function getDifferenceInMinutes(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / (1000 * 60);
  }
  function getDifferenceInSeconds(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / 1000;
  }
  return (
    <>

      <Menu as="div" className="relative inline-block text-left">
        <div>
          <Menu.Button className="">
            <div className="mx-4">
              <span className="relative inline-block">
                <i className="fa-solid fa-bell "></i>
                {newData?.count >= 0 && newData?.count == 0 ? "" : (
                  <span className="absolute bottom-4 px-2 py-1 left-0.5 text-xs font-bold leading-none text-red-100 transform bg-red-600 rounded-full">
                    {newData?.count}
                  </span>
                )}
              </span>
            </div>
          </Menu.Button>
        </div>
        <Transition as={Fragment} enter="transition ease-out duration-100" enterFrom="transform opacity-0 scale-95" enterTo="transform opacity-100 scale-100" leave="transition ease-in duration-75" leaveFrom="transform opacity-100 scale-100" leaveTo="transform opacity-0 scale-95">
          <Menu.Items className="absolute right-0 z-10 mt-0.5 w-56 origin-top-right rounded bg-white shadow-lg ring-opacity-5 focus:outline-none">{(props) => {

            return (
              <div className="w-full h-full sm:h-[600px] z-10 origin-top-right absolute right-0 mt-2 sm:w-[350px] rounded shadow-2xl bg-white ring-1 ring-black ring-opacity-5 focus:outline-none" role="menu" aria-orientation="vertical" aria-labelledby="menu-button">
                <div className=" text-sm font-medium  text-gray-900 bg-white rounded-lg border-gray-200 dark:bg-gray-700 dark:border-gray-600 dark:text-white">
                  <div className="py-2 px-4 flex justify-between gap-8">
                    <div className="text-md font-semibold">
                      Notifications
                    </div>
                  </div>
                  {newData?.data?.length > 0 &&
                    newData?.data?.map((getItem) => {
                      return (
                        <div key={getItem.SK} onClick={() => updateReadValues(getItem.PK, getItem.SK)} className={!getItem.IsViewState ? 'text-xs flex px-4 py-2 w-full border-t border-gray-100 cursor-pointer focus:outline-none focus:ring-2 focus:ring-gray-700 focus:text-gray-700 ' : 'text-xs flex px-4 py-2 w-full border-t bg-green-50 border-green-100 cursor-pointer hover:bg-gray-100 hover:text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-700 focus:text-blue-700 '} >
                          <div className="flex w-full">
                            <div className=" text-gray-600 break-all  w-full" role="alert">
                              <div className="flex w-full gap-3">
                                <div className={!getItem.IsViewState ? 'absolute left-0 h-12 rounded-full w-[1.5px] bg-gray-400 ' : 'absolute left-0 h-12 rounded-full w-[1.5px] bg-green-400'}></div>
                                <div className="my-auto shadow-xl border-2 relative  flex-shrink-0 flex items-center justify-center h-10 w-10 rounded-full  hover:text-gray-600  hover:bg-gray-100 sm:mx-0">
                                  <p className="m-auto text-xl rounded-full ">
                                    {getItem?.Subject.substring(0, 1).toUpperCase()}
                                  </p>
                                </div>
                                <div className="grid gap-2 ">
                                  <div onClick={() => router.push(`/Home/NotiFication?modetype=get&PKid=${getItem.SK}&SKid=${getItem.SK}`,)} className="relative">
                                    <div className="text-[10px] float-right font-normal">
                                      {getDifferenceInDays(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) < 33
                                        ? getDifferenceInHours(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) < 24
                                          ? getDifferenceInMinutes(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) < 60
                                            ? Math.floor(getDifferenceInSeconds(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) / 60,) + ' minutes ago'
                                            : Math.floor(getDifferenceInMinutes(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) / 60,) + ' hours ago'
                                          : Math.floor(getDifferenceInHours(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) / 24,) + ' days ago'
                                        : getDifferenceInDays(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) / 30 < 12
                                          ? Math.floor(getDifferenceInDays(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) / 30,) + ' months ago'
                                          : Math.floor(getDifferenceInDays(date1, new Date(getItem.CreatedDate?.replace("T", " ")),) / 30 / 12,) + ' years ago'}
                                    </div>
                                  </div>
                                  <NVLlabel className="font-bold " text={getItem.Subject} />
                                  <div className="text-[11px]">
                                    <>
                                      {getItem.Message > getItem.Message.substring(0, 75) ? getItem.Message.substring(0, 75) + '...' : getItem.Message}
                                    </>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>)
                    })}
                  { }
                  <NVLButton className="absolute left-2 bottom-2 flex  hover:text-gray-600 text-blue-600 hover:bg-gray-100 bg-blue-100 font-bold py-2 px-4 rounded gap-2 ml-2" onClick={() => router.push(`/Home/NotiFication?${("modetype=get&PKid=" + encodeURIComponent(NotificationPK) + "&SKid=")}`)}>
                    See All<i className="fa-solid fa-comments"></i>
                  </NVLButton>
                </div>
              </div>)
          }}
          </Menu.Items>
        </Transition>
      </Menu>
    </>
  )
}
