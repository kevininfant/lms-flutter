import React, { useState } from 'react'
import NVLAddRestrictControl from '@components/Controls/NVLAddRestrictControl'
import NVLPageModalPopup from '@components/Controls/NVLPageModalPopup'
import NVLButton from '@components/Controls/NVLButton'

function NVLAddRestriction(props) {

const [open, setOpen] = useState(false);
const [PageLoad, setPageLoad] = useState(false);

  const [RestrictStateValues, setRestrictStateValues] = 
  useState({ CohortControlCount: 0, UserProfileControlCount: 0, DateControlCount: 0, ActivityCompletionRestrictCount: 0, RestrictActionCount:0 })

  const AddRestrictAction = (RestrictName) => {
    setOpen(false);
    setPageLoad(true);
    RestrictName == "Cohort" ? setRestrictStateValues(RestrictData=> ({...RestrictData, CohortControlCount: RestrictData.CohortControlCount+1 })) :
    RestrictName == "UserProfile" ? setRestrictStateValues(RestrictData=> ({...RestrictData, UserProfileControlCount: RestrictData.UserProfileControlCount+1 })) :
    RestrictName == "Date" ? setRestrictStateValues(RestrictData=> ({...RestrictData, DateControlCount: RestrictData.DateControlCount+1 })) :
    RestrictName == "ActivityCompletion" ? setRestrictStateValues(RestrictData=> ({...RestrictData, ActivityCompletionRestrictCount: RestrictData.ActivityCompletionRestrictCount+1 })) :
    setRestrictStateValues(RestrictData=> ({...RestrictData, RestrictActionCount: RestrictData.RestrictActionCount+1 }));   
}


function GetJsonDynamicdata() {
  setOpen(!open)
  let DynamicData = {};
  DynamicData = ({ ...DynamicData, "RestrictSet": props.DynamicControlCount },{"NestedData":RestrictStateValues})
  return DynamicData;
}


  return (
    <div className="">
       <div className="px-4">
        <NVLButton id={"btnAddRestrict"+crypto.randomUUID()} text={"Add Restrict"} type={"button"} onClick={() => GetJsonDynamicdata()} className={`w-32 nvl-button bg-blue-400 text-white `}></NVLButton>
        </div>

       <NVLPageModalPopup ModalType="Card" open={open} setOpen={setOpen} CohortAction={() => AddRestrictAction("Cohort")} UserProfileAction={() => AddRestrictAction("UserProfile")} DateAction={() => AddRestrictAction("Date")} ActivityCompletionAction={() => AddRestrictAction("ActivityCompletion")} RestrictAction={()=>AddRestrictAction("Restrict")} />
        <NVLAddRestrictControl DynamicControlCount={RestrictStateValues} NestedRestriction={true} setRestrictStateValues={setRestrictStateValues} />     
    </div>
  )
}

export default NVLAddRestriction