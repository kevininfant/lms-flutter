import React, { useState, useEffect, useRef } from "react";
import 'quill/dist/quill.snow.css';
import 'quill/dist/quill.bubble.css';

const NVLPanelHeader = ({ HeaderContent, onDrag }) => {
  const [mouseDown, setMouseDown] = useState(false);
  const HeaderRef = useRef(null);
  useEffect(() => {
    const handleMouseUp = () => setMouseDown(false);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.addEventListener("mouseup", handleMouseUp);
    };
  }, []);
  useEffect(() => {
    HeaderRef.current.innerHTML = HeaderContent;
  }, [HeaderContent]);
  useEffect(() => {
    const ratio = window.devicePixelRatio;
    const handleMouseMove = (e) => onDrag(e.movementX / ratio, e.movementY / ratio);
    if (mouseDown) {
      window.addEventListener("mousemove", handleMouseMove);
    }
    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
    };
  }, [mouseDown, onDrag]);
  const handleMouseDown = () => setMouseDown(true);
  return (
    <div className="focus:outline-none rounded overflow-hidden border-yellow-600 cursor-pointer !max-h-full	!max-w-full ql-editor !m-0 !p-0" onMouseDown={handleMouseDown} ref={HeaderRef} />
  );
};

export default NVLPanelHeader;
