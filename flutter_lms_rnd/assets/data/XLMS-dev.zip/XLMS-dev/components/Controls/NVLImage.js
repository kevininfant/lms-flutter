import { Image } from "@aws-amplify/ui-react";

function NVLImage(props) {
  return (
    <>
      <Image 
            id={props.id} 
            className={"select-none "+props.className} 
            src={props.src} 
            srcSet={props.srcSet} 
            alt={props.alt} 
            height={props.height} 
            alignself={props.alignSelf} 
            width={props.width}
            onClick={props.onClick}/>
    </>
  );
}

export default NVLImage;