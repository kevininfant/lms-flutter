import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLProgressBar from "@components/Controls/NVLProgressBar";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { listXlmsCourseEnrollUser, listXlmsCourseManagementInfo } from "src/graphql/queries";
import * as Yup from "yup";

export default function ProgressModuleWiseReport(props) {
  const courseStatus = useRef("Filter by Status")
  const modulewiseData = useRef()
  const [courseProgressData, setCourseProgressData] = useState({})
  const router = useRouter();
  const [search, setSearch] = useState("")
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [filterStatus, setFilterstatus] = useState("Filterbystatus");

  const courseProgressList = useMemo(() => {
    return {variable:{ PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSE#ENROLLUSER#" + props?.user?.attributes?.sub, 
    SK: "COURSE#", IsSuspend: false,limit: 1000
  }}
  }, [props?.TenantInfo?.TenantID, props?.user?.attributes]);
  const validationSchema = Yup.object().shape({
    ddlStatus: Yup.string()
      .test("", "status", (e) => {
        if (courseStatus.current != e && e != undefined) {
          courseStatus.current = e
          setValue("fetch", true);
          setFilterstatus(e);
          setValue("fetch", false);
        }
        return true;
      }),
  });
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
  const { errors } = formState;
  
  useEffect(() => {
    async function fetchData() {
      setValue("fetch", true);
      const courseData = await AppsyncDBconnection(listXlmsCourseEnrollUser, courseProgressList.variable, props?.user?.signInUserSession?.accessToken?.jwtToken)
      const courseManagement = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      setCourseProgressData({ CourseData: courseData?.res?.listXlmsCourseEnrollUser?.items, CourseManagement: courseManagement?.res?.listXlmsCourseManagementInfo?.items })
      setValue("fetch", false);
    }
    fetchData()
    return (() => {
     setCourseProgressData((data)=> {return {...data}}) 
    })
  }, [setValue,courseProgressList?.variable, props.TenantInfo.TenantID, props.sub, props?.user?.signInUserSession?.accessToken?.jwtToken])
  
  const headerColumn = useMemo(() => {
    return [{ HeaderName: "Module Name", Columnvalue: "ModuleName", HeaderCss: "!w-6/12" },
    { HeaderName: "Completion Date", Columnvalue: "CompletionDate", HeaderCss: "!w-1/12", },
    { HeaderName: "Completion(%)", Columnvalue: "Completion", HeaderCss: "!w-1/12", },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-1/12" }];
  }, []);
  const GetCompletedStatus = useMemo(() => {
    return [
      { value: "Filterbystatus", text: "Filter by status" },
      { value: "Completed", text: "Completed" },
      { value: "InProgress", text: "In Progress" },
      { value: "Yettostart", text: "Yet to start" },
    ]
  }, [])
  const PageRoutes = useMemo(() => {
    return [
      { path: "/Report/ReportList", breadcrumb: "Reports" },
      { path: "/Report/ProgressReport", breadcrumb: "Course Progress" },
      { path: "", breadcrumb: "Course Module Wise Report" }

    ];
  }, [])
  function getDateFormat(date) {
    return (new Date(date).toLocaleDateString())

  }
  const gridDataBind = useCallback(() => {
    let viewData=courseProgressData?.CourseData
    const rowGrid = [];
    const moduleValue = [];
    let status = [], completion
    let dataCombined = [], dataModule, filteredData
    let moduleData
    viewData && viewData.map((getItem, index) => {
      if (viewData[index].CompletionStatus != undefined) {
        status.push(JSON.parse(viewData[index].CompletionStatus))

      } else {
        status.push('-')
      }

      if (router.query["CourseID"] == getItem.CourseID) {

        if (getItem?.Restriction != undefined) {
          if(JSON.parse(getItem?.Restriction).RS0!=undefined){
          moduleData = JSON.parse(getItem?.Restriction).RS0.flow.ActivityList
          }
          else{
          moduleData = JSON.parse(getItem?.Restriction).RSDefault.flow.ActivityList
          }
          const uniqueIds = [];
          moduleValue = moduleData.filter(element => {
            const isDuplicate = uniqueIds.includes(element.ModuleID);
            if (!isDuplicate) {
              uniqueIds.push(element.ModuleID);
              return true;
            }
            return false;
          });
        }
      }
    })
    moduleValue && moduleValue.map((val, index) => {
      if (Object.keys(status[index]).includes(val.ModuleID)) {
        dataModule = { ModuleID: val.ModuleID, ModuleName: val.ModuleName }
        completion = status[index][val.ModuleID]
      } else {
        dataModule = { ModuleID: val.ModuleID, ModuleName: val.ModuleName }
        completion = { CompletedActivity: "-", CompletionDate: "-", progress: 0 }
      }
      dataCombined.push({ data: dataModule, completion: completion })
      modulewiseData.current = dataCombined
    })
    
    if (filterStatus == "Filterbystatus") {
      filteredData = dataCombined
    } else if (filterStatus == "Completed") {
      filteredData = dataCombined.filter((item) => {return item.completion.progress == 100 })
    } else if (filterStatus == "InProgress") {

      filteredData = dataCombined.filter((item) => {return  item.completion.progress < 0 && item.completion.progress > 100 })
    } else if (filterStatus == "Yettostart") {

      filteredData = dataCombined.filter((item) => {return item.completion.progress == 0 })
    }
    filteredData  && filteredData .map((item, index) => {
    
     
      rowGrid.push({

        ModuleID: (
          <NVLlabel id={"lblModuleID" + (index + 1)} name="ModuleID" text={item.data.ModuleID} />
        ),
        ModuleName: (
          <>
            <NVLlabel id={"txtModuleName" + (index + 1)} text={item.data.ModuleName} className={`${item.data.ModuleName && "p-2"}`} />
          </>
        ),
        CompletionDate: (
          <>
            <NVLlabel id={"txtEndDate" + (index + 1)} text={item.completion.CompletionDate == "-" ? "-" : getDateFormat(item.completion.CompletionDate)} />
          </>
        ),
        Completion: (
          <>
              <div className="flex items-center gap-2 " >

            <NVLProgressBar text="Progress" ProgressCss={"w-44"}
              bgcolor={(item.completion.progress) > 0 && (item.completion.progress) < 100 ? "#ffa500" : (item.completion.progress) == 0 ? "#ff0000" : "#008000"}
              progress={item.completion.progress}
            />
            <NVLlabel text={item.completion.progress == "-" ? "-" : `${item.completion.progress}%`} />
          </div>
          </>
        ),
        Status: (
          <>
            <NVLlabel id={"txtStatus" + (index + 1)} text={(item.completion.progress) > 0 && (item.completion.progress) < 100 ? "In Progress" : (item.completion.progress) == 0 ? "Yet to Start" : (item.completion.progress) == "-" ? "" : "Completed"}></NVLlabel>
          </>
        )

      });
    })
  
    return rowGrid;
  }, [filterStatus, router.query,courseProgressData?.CourseData])
 
   
  return (
    <Container title="Course Progress" PageRoutes={PageRoutes}>
      <div className="flex gap-4 pt-6">
        <div className="col-span-6 sm:col-span-3 w-48 pl-3">
          <NVLlabel htmlFor="Department" className="block text-sm font-medium text-gray-600 py-1">
            Status
          </NVLlabel>
          <NVLSelectField id="ddlStatus"  register={register} errors={errors} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" options={GetCompletedStatus} />
        </div>
        {/* <div className="flex items-center">
          <NVLButton id="btnSubmit"
          type={"button"}
          className={ "nvl-button  bg-indigo-500 !h-9" }
          >
            <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>

          </NVLButton>
          <div className="pb-2 pl-2 ">
            <NVLlabel
              className="nvl-Def-Label pb-1"
              HelpInfo={"Additional report details can be downloaded here"}
              HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
            />
          </div>
        </div> */}
      </div>
      {/* {!watch("fetch") &&<NVLGridTable
        refershPage={isRefreshing}
        user={props?.user}
        id="tblCourseList"
        HeaderColumn={headerColumn}
        GridDataBind={gridDataBind}
        query={listXlmsCourseEnrollUser}
        querryName={"listXlmsCourseEnrollUser"}
        variable={courseProgressList?.variable}
        Search={search}
      />} */}

          {!watch("fetch") && <div className="pb-8">
            <NVLGridTable id="tblEnrollList" className="max-w-full"
              HeaderColumn={headerColumn}
              RowGridDataPass={{ RowGrid:gridDataBind() }} />
          </div>}
      {watch("fetch") && <NVLLoadingSpinner />}
    </Container>
  )
}
