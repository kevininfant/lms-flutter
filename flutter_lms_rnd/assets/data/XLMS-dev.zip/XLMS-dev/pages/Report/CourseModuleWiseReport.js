import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLProgressBar from "@components/Controls/NVLProgressBar";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCourseManagementInfo, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

function CourseProgressModuleWise(props) {
    const [Data, setData] = useState(props);
    const courseStatus = useRef()
    const router = useRouter();
    const CourseName = useRef(router.query["CourseName"])
    const FilterDropdownData = useRef();
    const refRecordStatus = useRef()
    useEffect(() => {
        async function fetchData() {
            const lctTenantinfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);

            let lGetModuleeReportData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    menuid: "115402",
                    tenantid: props.user.attributes["custom:tenantid"],
                    usersub: props.user?.attributes["sub"],
                },
                body: `WHERE coursename='${router.query["CourseName"]}'`,
            });

            let lGetModuleReportDatas = await lGetModuleeReportData?.res?.text();
            lGetModuleReportDatas != undefined && Object.keys(JSON.parse(JSON.parse(lGetModuleReportDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";

            const ltdrpCourse = [{ value: "", text: "Filter by Course" }];
            const lGetCourseData = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + props.user.attributes["custom:tenantid"], SK: "COURSEINFO#" , IsDeleted: false }, AuthorizedToken);
            let courseData = lGetCourseData.res?.listXlmsCourseManagementInfo?.items
            let enrolledCourse = courseData.filter((data)=> data.CourseName == CourseName.current)
            enrolledCourse && enrolledCourse?.map((getItem) => {
                if (getItem?.text?.toLowerCase() != "select") {
                    ltdrpCourse.push({ value: getItem.CourseName, text: getItem.CourseName });
                }
            });
            FilterDropdownData.current = ltdrpCourse
            setData((data) => {
                let a = {
                    plistXlmsTenantInfo: lctTenantinfo.res?.listXlmsTenantInfos?.items != undefined ? lctTenantinfo.res?.listXlmsTenantInfos?.items : [],
                    pGetModuleReportData: lGetModuleReportDatas,
                }
                return { ...data, ...a }
            })
        }
        fetchData();
    }, [AuthorizedToken, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query, setValue])

    const PageRoutes = useMemo(() => {
        let Routes;
        if (!router.query["Navigation"]) {
            Routes = [
                { path: "/Report/ReportList", breadcrumb: "Reports" },
                { path: "/Report/CourseProgressReport", breadcrumb: "Course Progress" },
                { path: "", breadcrumb: "Course Module Wise Report" }
            ];
        } else {
            Routes = [
                { path: "/Report/ReportList", breadcrumb: "Reports" },
                { path: "/Report/LearningHours", breadcrumb: "Learning Hours" },
                { path: "", breadcrumb: "Course Module Wise Report" }
            ];
        }
        return Routes
    }, [router.query])


    let AuthorizedToken = Data?.user?.signInUserSession?.accessToken?.jwtToken;


    const GetFilterDropdownData = useCallback(() => {
        return FilterDropdownData.current && FilterDropdownData.current
    }, [FilterDropdownData])

    useEffect(() => {
        setValue("ddlCourse", CourseName.current)
    }, [router.query, setValue, GetFilterDropdownData])


    const validationSchema = Yup.object().shape({
        ddlStatus: Yup.string()
            .test("", "status", (e) => {
                if (courseStatus.current != e && e != undefined) {
                    courseStatus.current = e
                    dropdownChange(e);
                }
                return true;
            }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
    const { errors } = formState;

    const HeaderColumn = useMemo(() => {
        return [
            { HeaderName: "Module Name", Columnvalue: "ModuleName", HeaderCss: "w-1/6" },
            { HeaderName: "Enrolled Date", Columnvalue: "EnrolledDate", HeaderCss: "w-1/6" },
            { HeaderName: "Completion Date", Columnvalue: "CompletionDate", HeaderCss: "w-1/6" },
            { HeaderName: "Completion", Columnvalue: "Completion", HeaderCss: "w-1/6" },
            { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-1/6" },
        ]
    }, [])

    const execID = useRef();

    const GridDataBind = useCallback(
        (lGetUserloginInfoDatas = null) => {
            try {
                const RowGrid = [];
                let viewData = Data?.pGetModuleReportData != undefined && Object.values(JSON?.parse(Data?.pGetModuleReportData));
                viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);
                execID.current = Data?.pGetModuleReportData != undefined && JSON?.parse(Data?.pGetModuleReportData);
                if (viewData && viewData?.length == 1 && Object.keys(viewData?.[0]).length == 0) {
                    return [];
                } else {
                    viewData &&
                        viewData.map((getItem, index) => {
                            RowGrid.push({
                                ModuleName: <>{<NVLlabel id={index + 1} text={getItem.modulename} className={`${getItem.modulename && "p-2"}`} />}</>,
                                EnrolledDate: <NVLlabel id={index + 1} text={getItem["EnrolledDate"]} />,
                                CompletionDate: <NVLlabel id={index + 1} text={getItem?.CompletionDate} />,
                                Status: <NVLlabel id={index + 1} text={getItem?.Status} />,
                                Completion: <> {getItem?.modulename &&
                                    <div className="flex items-center gap-2 " title={`${getItem?.Status} : ${getItem?.CompletedStatus ?? "0"}`}>
                                        
                                        <NVLProgressBar text="Progress" ProgressCss={"w-44"}
                                             bgcolor={
                                                getItem?.CompletedStatus > "0" ? ((getItem?.CompletedStatus < "100" || getItem?.Status != "Completed") ? "#ffa500" : 
                                                getItem?.IsActivityCompletion ? "#94a3b8" : "#008000") 
                                                : "#FF0000"}
                                            progress={(getItem?.CompletedStatus == null) ? "0%" : getItem?.CompletedStatus > "0" ? getItem?.CompletedStatus+"%" : "0%"} />
                                        <NVLlabel text={`${(getItem?.CompletedStatus == null) ? "0%" : getItem?.CompletedStatus ? getItem?.CompletedStatus+"%" : "0%"} `} />
                                    </div>
                                }</>,
                            });

                        });
                }
                return RowGrid;
            } catch (error) {
                console.log("Failed to retreive the records", error);
            }
        }, [Data?.pGetModuleReportData]);

    let lstrTenantID = Data.TenantInfo.UserGroup != "SiteAdmin" ? Data.TenantInfo.TenantID : watch("ddlCompany");
    const dropdownChange = useCallback(async () => {
        setValue("fetch", true);

        let lqrywhere;

        let lstrCourse = watch("ddlCourse");
        let lstrStatus = watch("ddlStatus")

        lqrywhere = `WHERE coursename='${lstrCourse}'`;

        if (lstrStatus != "") {
            lqrywhere += ` AND Status='${lstrStatus}'`
        }
        try {
            let lGetUserloginInfoData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    menuid: "115402",
                    tenantid: Auth?.user?.attributes["custom:tenantid"],
                    usersub: Auth?.user?.attributes["sub"],
                },
                body: `${lqrywhere}`,
            });
            let lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
            lGetUserloginInfoDatas != undefined && Object.keys(JSON.parse(JSON.parse(lGetUserloginInfoDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
            setData((data) => {
                return { ...data, pGetModuleReportData: lGetUserloginInfoDatas }
            });
        } catch (error) {
            setValue("fetch", false)
        }
        setValue("fetch", false)
    }, [setValue, watch])

    const FileDownload = useCallback(
        async (e) => {
            setValue("download", true);

            try {
                if (e?.type == "click") {
                    let lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
                    let headers = {
                        method: "POST",
                        headers: {
                            "Content-Type": "text/csv",
                            authorizationtoken: AuthorizedToken,
                            bucketname: process.env.REPORT_BUCKET_NAME,
                        },
                        body: `processed-data/${lstrTenantID}/${execID.current.QueryExecutionID}.csv`,
                    };
                    let lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
                    var win = window.open(await lstrFileDownload.res?.text(), "_self");
                }
            } catch (error) {
                console.log("Failed to generate report", error);
            }
            setValue("download", false);

        },
        [AuthorizedToken, lstrTenantID, setValue]
    );

    const GetCompletedStatus = useMemo(() => {
        return [
            { value: "", text: "Filter by status" },
            { value: "Completed", text: "Completed" },
            { value: "InProgress", text: "In Progress" },
            { value: "Yet to start", text: "Yet to start" },
        ]
    }, [])
    return (
        <>
            <Container loader={FilterDropdownData.current == undefined} title="Course Progress" PageRoutes={PageRoutes}>
                <form className={watch("fetch") || watch("download") ? "pointer-events-none px-2" : "px-2"}>
                    <div className="px-3" id="divFilter">
                        <div className="block rounded-lg ">
                            <div className="py-3 pb-4">
                                <div className="grid grid-cols-12 grid-flow-col gap-4 pt-4">
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1">
                                            Course Name
                                        </NVLlabel>
                                        <NVLSelectField disabled={router.query["CourseName"] != undefined ? true : false} id="ddlCourse" errors={errors} options={GetFilterDropdownData()} className={router.query["CourseName"] != undefined ? "mt-1 block w-full Disabled rounded-md border-gray-300 shadow-sm" : "mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"} register={register}></NVLSelectField>
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Department" className="block text-sm font-medium text-gray-600 py-1">
                                            Status
                                        </NVLlabel>
                                        <NVLSelectField id="ddlStatus" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={GetCompletedStatus} errors={errors} />
                                    </div>
                                    <div className="flex gap-4 pt-6">
                                        <div className="flex items-center">
                                            <NVLButton id="btnSubmit" disabled={(watch("download") || watch("fetch")) || refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? true : false} type={"button"}
                                                className={refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? "nvl-button Disabled bg-indigo-500 !h-9" : "nvl-button !bg-indigo-500 text-white !h-9"}
                                                onClick={(e) => FileDownload(e)}
                                            >
                                                <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                            </NVLButton>
                                            <div className="pb-2 pl-2 ">
                                                <NVLlabel
                                                    CustomCss="-translate-x-72 pt-4"
                                                    className="nvl-Def-Label pb-1"
                                                    HelpInfo={"Additional report details can be downloaded here"}
                                                    HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {!watch("fetch") && <div className="pb-8">
                        <NVLGridTable id="tblEnrollList" className="max-w-full"
                            HeaderColumn={HeaderColumn}
                            RowGridDataPass={{ RowGrid: GridDataBind() }} />
                    </div>}
                    <div>
                        {watch("fetch") &&
                            <div className="p-14"> <NVLLoadingSpinner /> </div>}
                    </div>
                </form>
            </Container>
        </>
    )
}

export default CourseProgressModuleWise