import NVLProgressBar from "@components/Controls/NVLProgressBar";
import Container from "@Container/Container";
import NVLButton from "@Controls/NVLButton";
import NVLGridTable from "@Controls/NVLGridTable";
import NVLlabel from "@Controls/NVLlabel";
import NVLLoadingSpinner from "@Controls/NVLLoadingSpinner";
import NVLSelectField from "@Controls/NVLSelectField";
import NVLTextbox from "@Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsCourseActivityConfig } from "src/graphql/queries";
import * as Yup from "yup";

export default function ActivityReport(props) {
  const [Data, setData] = useState({ ...props })
  useEffect(() => {
    async function fetchData() {
      let ltuser =props.user;

      let lGetActivityyReportData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/text",
          authorizationtoken: ltuser.signInUserSession.accessToken.jwtToken,
          menuid: "115103",
          usersub: ltuser.attributes["sub"],
          tenantid: ltuser.attributes["custom:tenantid"],
        },
        body: `WHERE usersub!=''`,
      });

      let activityData = await AppsyncDBconnection(
        getXlmsCourseActivityConfig,
        {
          PK: "XLMS#ACTIVITY",
          SK: "ACTIVITY#ACTIVITYTYPE",
        },
        ltuser.signInUserSession.accessToken.jwtToken
      );

      let lGetActivityReportDatas = await lGetActivityyReportData?.res?.text();
      lGetActivityReportDatas != undefined && Object.keys(JSON?.parse(JSON?.parse(lGetActivityReportDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";

      setData((temp) => {
        let z = {
          pGetActivityReportData: lGetActivityReportDatas,
          ActivityData: activityData.res?.getXlmsCourseActivityConfig,
        }
        return { ...temp, ...z }

      })
    }
    fetchData();
  },[props.user])
  const router = useRouter();
  let AuthorizedToken = Data?.user?.signInUserSession?.accessToken?.jwtToken;

  const refWhereQuery = useRef();
  const dropDownFilter = useRef({})
  const refRecordStatus = useRef()

  const [FilterDropdownData, setFilterDropdownData] = useState({ Activity: [{ value: "", text: "Filter by Activity" }] });

  const GetFilterDropdownData = useCallback(async () => {
    let ltdrpActivity = [{ value: "", text: "Filter by Activity" }];
    let Activity = Data.ActivityData?.ActivityType && JSON.parse(Data.ActivityData?.ActivityType);

    if (Activity != undefined) {
      Activity.map((getItem) => {
        ltdrpActivity.push({ value: getItem, text: getItem });
      });
    }
    setFilterDropdownData({ Activity: ltdrpActivity })
  }, [Data.ActivityData?.ActivityType])

  useEffect(() => {
    GetFilterDropdownData("")
  }, [GetFilterDropdownData])


  const validationSchema = Yup.object().shape({
    ddlActivity:  Yup.string() .test("", "", (e) => {
      if (e != dropDownFilter?.current.Activity && ((e != "") || (e == "" && dropDownFilter?.current.Activity != undefined))) {
        dropDownFilter.current.Activity = e
         getActivityData();
          }
          return true;
        }),

     ddlStatus:Yup.string() .test("", "", (e) => {
      if (e != dropDownFilter?.current.Status && ((e != "") || (e == "" && dropDownFilter?.current.Status != undefined))) {
        dropDownFilter.current.Status = e
         getActivityData();
          }
      return true;
    }) ,  
 })

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
  const { errors } = formState;


  const HeaderColumn = useMemo(() => {
    return [ 
      { HeaderName: "Activity Name", Columnvalue: "ActivityName", HeaderCss: "w-1/6" },
      { HeaderName: "Activity Type", Columnvalue: "ActivityType", HeaderCss: "w-1/6" },
      { HeaderName: "Start Date", Columnvalue: "Assigned Date", HeaderCss: "w-1/6" },
      { HeaderName: "End Date", Columnvalue: "Completion Date", HeaderCss: "w-1/6" },
      { HeaderName: "SeatTime", Columnvalue: "SeatTime", HeaderCss: "!w-3/12" },
      { HeaderName: "Completion(%)", Columnvalue: "Completion (%)", HeaderCss: "w-1/6" },
      { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-1/6 whitespace-nowrap" },
    ]
  }, [])

  const execID = useRef();

  const GridDataBind = useCallback((lGetUserloginInfoDatas = null) => {
      try {
        const RowGrid = [];
        let viewData = Data?.pGetActivityReportData != undefined && Object.values(JSON?.parse(Data?.pGetActivityReportData));
        viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);

        execID.current = Data?.pGetActivityReportData != undefined && JSON?.parse(Data?.pGetActivityReportData);
        viewData &&
          viewData.map((getItem, index) => {
            RowGrid.push({
              ActivityName: <NVLlabel id={index + 1} text={getItem.ActivityName} />,
              ActivityType: <NVLlabel id={index + 1} text={getItem.ActivityType} />,
              ["Assigned Date"]: <NVLlabel id={index + 1} text={getItem["StartDate"]} />,
              ["Completion Date"]: <NVLlabel id={index + 1} text={getItem["CompletionDate"]} />,
              SeatTime: <NVLlabel id={index + 1} text={getItem?.SeatTime ? getItem?.SeatTime : "00:00"} />,
              ["Status"]: <NVLlabel id={index + 1} text={getItem.Status} />,
              ["Completion (%)"]: <> {getItem?.ActivityName &&
                <div className="flex items-center gap-2 p-2">
                 <NVLProgressBar text="Progress" ProgressCss={"w-44"}
                  bgcolor={getItem["Completion(%)"] > "0%" ? ((getItem["Completion(%)"] < "100%" || getItem?.Status != "Completed") ? "#ffa500" : (getItem.IsActivityCompletion) ? "#94a3b8" : "#008000") : "#FF0000"}
                  progress={getItem["Completion(%)"] > "0%" ? getItem["Completion(%)"] : "0%"} />
                  <NVLlabel text={`${!getItem["Completion(%)"]? "0%":getItem["Completion(%)"]}`} />
                </div>
              }</>,
            });
          });
        return RowGrid;
      } catch (error) {
        console.log("Failed to retreive the records", error);
      }
    }, [Data?.pGetActivityReportData]);

  let lstrTenantID = Data.TenantInfo.UserGroup != "SiteAdmin" ? Data.TenantInfo.TenantID : watch("ddlActivity");

  const getActivityData = useCallback(async()=>{

    setValue("fetch", true);

    let lqrywhere;
    let lstrActivityType = watch("ddlActivity");
    let lstrCompletionStatus = watch("ddlStatus");
    let lstrActivityName = watch("txtActivityName");

    lqrywhere = `WHERE usersub!='' `;

    if (lstrActivityType != "") {
      lqrywhere += ` AND ActivityType='${lstrActivityType}'`;
    }
    if (lstrCompletionStatus != "") {
      lqrywhere += ` AND Status='${lstrCompletionStatus}'`;
    }

    if (lstrActivityName != "") {
      lqrywhere += `AND UPPER("ActivityName") LIKE '%${lstrActivityName?.toUpperCase()}%'`;
    }
    refWhereQuery.current = lqrywhere;

    try {

      let lGetUserloginInfoData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/text",
          menuid: "115103",
          usersub: Auth?.user?.attributes["sub"],
          tenantid: lstrTenantID,
        },
        body: `${lqrywhere}`,
      });
      let lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
      lGetUserloginInfoDatas != undefined && Object.keys(JSON?.parse(JSON?.parse(lGetUserloginInfoDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
      setData((data) => {
        return { ...data, pGetActivityReportData: lGetUserloginInfoDatas }
      })
    } catch(error){
      setValue("submit", false);
      setValue("fetch", false);
    }
    setValue("submit", false);
    setValue("fetch", false);

  },[lstrTenantID, setValue, watch])

  const submitHandler = async (data) => {
    setValue("submit", true);
    getActivityData()
  };

  const FileDownload = useCallback(
    async (e) => {
      setValue("download", true);
      try {
        if (e?.type == "click") {
          let lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
          let headers = {
            method: "POST",
            headers: {
              "Content-Type": "text/csv",
              authorizationtoken: AuthorizedToken,
              bucketname: process.env.REPORT_BUCKET_NAME,
            },
            body: `processed-data/${lstrTenantID}/${execID.current.QueryExecutionID}.csv`,

          };
          let lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
          var win = window.open(await lstrFileDownload.res?.text(), "_self");
        }
      } catch (error) {
        console.log("Failed to generate report", error);
      }
      setValue("download", false);

    },
    [AuthorizedToken, lstrTenantID, setValue]
  );


  const PageRoutes = useMemo(() => {
    return [
      { path: "/Report/ReportList", breadcrumb: "Report" },
      { path: "", breadcrumb: "Activity Report" }

    ];
  }, [])

  
  const CompletedStatus = useMemo(() => {
    return [
      { value: "", text: "Filter by Status" },
      { value: "Completed", text: "Completed" },
      { value: "Inprogress", text: "InProgress" },
      { value: "Yet to start", text: "Yet to start" }]

  }, [])

  return (
    <>
      <Container title="Activity Report" loader={Data?.pGetActivityReportData == undefined ? true : false} PageRoutes={PageRoutes}>
        <form onSubmit={handleSubmit(submitHandler)} className={`${watch("submit") || watch("fetch") || watch("download") ? "px-2 pointer-events-none" : "px-2" }`}>
          <div className="px-3" id="divFilter">
            <div className="block rounded-lg ">
              <div className="py-3 pb-4">
                <div className="grid grid-cols-12 grid-flow-col gap-4 pt-4">
                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="Activity-Type" className="block text-sm font-medium text-gray-600 py-1">
                      Activity Type
                    </NVLlabel>
                    <NVLSelectField id="ddlActivity" errors={errors} options={FilterDropdownData.Activity} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
                  </div>
                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="Status" className="block text-sm font-medium text-gray-600 py-1">
                      Status
                    </NVLlabel>
                    <NVLSelectField id="ddlStatus" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={CompletedStatus} errors={errors} />
                  </div>
                  <div className="col-span-6 sm:col-span-3 invisible"></div>

                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="Activity-Name" className="block text-sm font-medium text-gray-600 py-1">
                      Search by Activity Name
                    </NVLlabel>
                    <NVLTextbox id="txtActivityName" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by Activity name" />
                  </div>
                  <div className="col-span-6 sm:col-span-3 pt-6">
                    <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""}
                      disabled={watch("submit") || watch("fetch") || watch("download") ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-primary  text-white !h-10" : "w-28 nvl-button !bg-primary  text-white !h-10"}>
                      {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                    </NVLButton>
                  </div>
                  <div className="col-span-6 sm:col-span-3 pt-6">
                    <div className="flex items-center">
                      <NVLButton id="btnDownload" disabled={(watch("submit") || watch("download") || watch("fetch") || refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined) ? true : false} type={"button"}
                        className={refRecordStatus.current == undefined || refRecordStatus.current == "NoRecord" ? "nvl-button Disabled bg-primary !h-10" : watch("download") ? "nvl-button !bg-primary  text-white !h-10" :  "nvl-button !bg-primary  text-white !h-10"}
                        onClick={(e) => FileDownload(e)} >
                        <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                      </NVLButton>
                      <div className="pb-2 pl-2 ">
                        <NVLlabel
                          CustomCss="-translate-x-72 pt-4"
                          className="nvl-Def-Label pb-1"
                          HelpInfo={"Additional report details can be downloaded here"}
                          HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {!watch("fetch") && <div className="pb-8">
            <NVLGridTable id="tblEnrollList" className="max-w-full"
              HeaderColumn={HeaderColumn}
              RowGridDataPass={{ RowGrid: refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? [] : GridDataBind() }} />
          </div>}
          <div>
            {watch("fetch") && <NVLLoadingSpinner />}
          </div>
        </form>
      </Container>
    </>
  );
}