import Container from '@components/Container/Container';
import NVLFetchDataLoading from '@components/Controls/NVLFetchDataLoading';
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from '@components/Controls/NVLlabel';
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import { listXlmsUserCertificateInfos } from '@graphql/graphql/queries';
import { yupResolver } from "@hookform/resolvers/yup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { useForm } from "react-hook-form";
import * as Yup from "yup";
Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

export default function UserPerformanceReport({ props }) {

    const router = useRouter();
    const execID = useRef();
    const IsReportLoader = useRef(true);
    const [refgriddata, setrefgriddata] = useState()
    const [CoursCompletion, setCoursCompletion] = useState()
    const [eventHours, seteventHours] = useState();
    const totalUser = useRef();
    const [openTab, setOpenTab] = useState("1");
    const headerColumn = useMemo(() => {
        const bindeddata = [];
        switch (openTab) {
            case "1":
                bindeddata.push(
                    { HeaderName: "Course Name", Columnvalue: "coursename", HeaderCss: "!w-3/12" },
                    { HeaderName: "Category", Columnvalue: "Category", HeaderCss: "!w-2/12" },
                    { HeaderName: "Seat Time", Columnvalue: "SeatTime", HeaderCss: "!w-3/12" },
                    { HeaderName: "Completion(%)", Columnvalue: "Completion", HeaderCss: "!w-3/12" },
                    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-0/12" },
                );
                return bindeddata;
            case "2":
                bindeddata.push(
                    { HeaderName: "Activity Name", Columnvalue: "ActivityName", HeaderCss: "!w-3/12" },
                    { HeaderName: "Activity Type", Columnvalue: "ActivityType", HeaderCss: "!w-2/12" },
                    { HeaderName: "Seat Time", Columnvalue: "SeatTime", HeaderCss: "!w-3/12" },
                    { HeaderName: "Completion(%)", Columnvalue: "Completion (%)", HeaderCss: "!w-3/12" },
                    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-0/12 whitespace-nowrap" },
                );
                return bindeddata;
        }
    }, [openTab]);

    const CourseCompletion = useMemo(() => {
        let YetToStart = 0, ToatalOfInprogress = 0, ToatalOfCompleted = 0;
        CoursCompletion?.length > 0 && CoursCompletion.map((Item) => {
            if (Item?.Status == "Completed") ToatalOfCompleted += 1;
            else if (Item?.Status == "InProgress") ToatalOfInprogress += 1;
            else if (Item?.Status == "Yet to Start") YetToStart += 1;
        })
        const Completion = {
            labels: [Math.round(CoursCompletion?.length > 0 ? (ToatalOfCompleted / CoursCompletion?.length) * 100 : 0)
                + "% Completed", Math.round(CoursCompletion?.length > 0 ? (ToatalOfInprogress / CoursCompletion?.length) * 100 : 0)
            + "% In Progress", Math.round(CoursCompletion?.length > 0 ? (YetToStart / CoursCompletion?.length) * 100 : 0) + "% Yet to Start"],
            datasets: [
                {
                    data: [ToatalOfCompleted, ToatalOfInprogress, YetToStart],
                    backgroundColor: ["green", "orange", "red"],
                    hoverOffset: 4,
                },
            ],
        };
        return Completion;
    }, [CoursCompletion])

    const [achivementData, setAchivementData] = useState()
    const fetchUserPerfomanceReport = useCallback(async (menuId) => {
        setValue("Isfetch", true);
        let lGetUserloginInfoData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/text",
                menuid: openTab == "1" ? "115401" : "115103",
                usersub: router.query["UserSub"],
                tenantid: props?.TenantInfo?.TenantID,
            },
            body: openTab == "1" ? `` : `Where usersub!=''`
        });
        let lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
        let viewData = lGetUserloginInfoDatas != undefined && Object.values(JSON?.parse(lGetUserloginInfoDatas));
        viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);
        execID.current = lGetUserloginInfoDatas != undefined && JSON?.parse(lGetUserloginInfoDatas);
        // Completed Badges
        const BadgesForCompleted = await AppsyncDBconnection(
            listXlmsUserCertificateInfos,
            {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + router.query["UserSub"],
                SK: "BADGE#"
            },
            props?.user?.signInUserSession?.accessToken?.jwtToken
        )
        //    Completed Cert
        const CertForCompleted = await AppsyncDBconnection(
            listXlmsUserCertificateInfos,
            {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + router.query["UserSub"],
                SK: "CERTIFICATE#"
            },
            props?.user?.signInUserSession?.accessToken?.jwtToken
        )
        let Badge = BadgesForCompleted?.res?.listXlmsUserCertificateInfos?.items ? BadgesForCompleted?.res?.listXlmsUserCertificateInfos?.items : undefined;
        let Cert = CertForCompleted?.res?.listXlmsUserCertificateInfos?.items ? CertForCompleted?.res?.listXlmsUserCertificateInfos?.items : undefined;

        setAchivementData({ BadgeCount: Badge?.length, CertificateCount: Cert?.length, })
        gridDataBind(viewData, openTab == "1" ? "Course" : "Activity");
        if (openTab == "1") {
            viewData && setCoursCompletion(viewData && viewData);
        }
        setValue("Isfetch", false);
    }, [gridDataBind, openTab, props?.TenantInfo?.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue])

    useEffect(() => {
        const fetchAchivements = (async () => {
            setValue("isFetchinghours", true)
            // Total
            let getTotalLearningHours = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    menuid: "115100",
                    usersub: router.query["UserSub"],
                    tenantid: props?.TenantInfo?.TenantID,
                },
            });
            let UserTotalLearningHours = await getTotalLearningHours?.res?.text();
            let totalLearningHours = UserTotalLearningHours != undefined && Object.values(JSON?.parse(UserTotalLearningHours));
            totalLearningHours = (totalLearningHours && totalLearningHours != undefined) && JSON.parse(totalLearningHours?.[1]);
            // Activity
            let getActivityHours = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    menuid: "115300",
                    usersub: router.query["UserSub"],
                    tenantid: props?.TenantInfo?.TenantID,
                },
            });
            let UsergetActivityHours = await getActivityHours?.res?.text();
            let activityHours = UsergetActivityHours != undefined && Object.values(JSON?.parse(UsergetActivityHours));
            activityHours = (activityHours && activityHours != undefined) && JSON.parse(activityHours?.[1]);

            // Course
            let getCourseHours = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    menuid: "115200",
                    usersub: router.query["UserSub"],
                    tenantid: props?.TenantInfo?.TenantID,
                },
            });
            let UsergetCourseHours = await getCourseHours?.res?.text();
            let CourseHours = UsergetCourseHours != undefined && Object.values(JSON?.parse(UsergetCourseHours));
            CourseHours = (CourseHours && CourseHours != undefined) && JSON.parse(CourseHours?.[1]);

            seteventHours({
                totalLearningHours: totalLearningHours && totalLearningHours?.[0],
                activityHours: activityHours && activityHours?.[0],
                CourseHours: CourseHours && CourseHours?.[0]
            })

            setValue("isFetchinghours", false)

        })
        fetchAchivements()
        return () => {
            seteventHours({})
        }
    }, [props?.TenantInfo?.TenantID, router.query, setValue])

    useEffect(() => {
        fetchUserPerfomanceReport()
    }, [fetchUserPerfomanceReport])

    const gridDataBind = useCallback((FetchData, State) => {
        totalUser.current = "00:00";
        const RowGrid = [];
        let courseEnrolledCount = []
        FetchData &&
            FetchData.map((getItem, index) => {
                if (getItem.Status == "Completed" && getItem?.Completion != undefined && getItem?.Completion != null) {
                    if (getItem?.Completion != "") {
                        if (State == "Course") {
                            courseEnrolledCount.push(getItem?.Completion + ":00");
                        } else {
                            courseEnrolledCount.push(getItem?.Completion)
                        }
                    }

                    const totalSeconds = courseEnrolledCount.reduce((acc, val) => {
                        const [hours, minutes, seconds] = val.split(':').map(Number);
                        return parseInt(acc) + hours * 3600 + minutes * 60 + seconds;
                    }, 0);
                    const hours = Math.floor(totalSeconds / 3600);
                    const minutes = Math.floor((totalSeconds - hours * 3600) / 60);
                    const seconds = totalSeconds % 60;
                    const totalTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

                    totalUser.current = totalTime.split(":").slice(0, 2).join(":");
                }
                if (State == "Course") {
                    if (Object.entries(getItem).length != 0) {
                        RowGrid.push({
                            coursename: <> {getItem.coursename && <NVLlabel id={index + 1} text={getItem.coursename}
                                className={`${getItem.coursename && "p-2 pt-2"}`} />}</>,
                            ["Category"]: <NVLlabel id={index + 1} text={getItem?.categoryname} />,
                            SeatTime: <NVLlabel id={index + 1} text={getItem.SeatTime ? getItem.SeatTime : "00:00"} />,
                            Completion: <NVLlabel id={index + 1} text={getItem["Completion(%)"]} />,
                            Status: <NVLlabel id={index + 1} text={getItem.Status} />,
                        });
                    }
                } else {
                    if (Object.entries(getItem).length != 0) {
                        RowGrid.push({
                            ActivityName: <NVLlabel id={index + 1} text={getItem.ActivityName} />,
                            ActivityType: <NVLlabel id={index + 1} text={getItem.ActivityType} className="p-2 pt-2" />,
                            SeatTime: <NVLlabel id={index + 1} text={getItem?.SeatTime ? getItem?.SeatTime : "00:00"} />,
                            ["Completion (%)"]: <NVLlabel id={index + 1} text={getItem["Completion(%)"]} />,
                            Status: <NVLlabel id={index + 1} text={getItem.Status} />,
                        });
                    }
                }
            });
        setrefgriddata(RowGrid)
    }, []
    );
    const validationSchema = Yup.object().shape({})
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true };
    const { watch, formState, setValue } = useForm(formOptions);
    const { errors } = formState;
    const PageRoutes = useMemo(() => {
        return [{ path: "/UserManagement/UserList", breadcrumb: "User Management" }, { path: "", breadcrumb: "User Perfomance" }];
    }, [])
    const learningHoursData = useMemo(() => {
        let Learn = {
            labels: [
                eventHours?.activityHours ? Object.keys(eventHours?.activityHours)?.length == '0' ? "00:00" : eventHours?.activityHours?.activitytime : "00:00",
                eventHours?.CourseHours ? Object.keys(eventHours?.CourseHours)?.length == '0' ? "00:00" : eventHours?.CourseHours?.coursetime : "00:00"
            ],
            datasets: [
                {
                    data: [eventHours?.activityHours ? Object.keys(eventHours?.activityHours)?.length == '0' ? 0 : eventHours?.activityHours?.activity : 0,
                    eventHours?.CourseHours ? Object.keys(eventHours?.CourseHours)?.length == '0' ? 0 : eventHours?.CourseHours?.course : 0],
                    backgroundColor: [
                        '#36A2EB',
                        '#FFCE56',
                    ],
                },
            ],
        };
        return Learn;
    }, [eventHours]);
    const chartOptions = {
        hover: { mode: null },
        responsive: false,
        elements: {
            arc: {
                borderWidth: 0,
            },
        },
        cutout: "80%",
        maintainAspectRatio: false,
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false,
            },
            tooltip: {
                callbacks: {
                    label: (context) => {
                        const dataIndex = context.dataIndex;
                        const label = context.chart.data.labels[dataIndex];
                        // const value = context.chart.data.datasets[0].data[dataIndex];
                        return `${label}`;
                    },
                },
            },
        },
    };
    function toHoursAndMinutes(totalMinutes) {
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;

        return `${padToTwoDigits(hours)}:${padToTwoDigits(minutes)}`;
    }

    function padToTwoDigits(num) {
        return num.toString().padStart(2, '0');
    }

    return (
        <>
            <Container loader={CoursCompletion ? false : true} PageRoutes={PageRoutes}>
                <div className="flex flex-wrap gap-8 ">
                    <div className="bg-blue-100 w-full flex justify-end h-10 px-3">
                        <NVLlabel text={`Name : ${router.query["UserName"]?.toUpperCase()}`} className="font-semibold text-gray-600 text-sm my-auto" />
                    </div>
                    <div className="flex justify-between w-full gap-8">
                        <div className="bg-[#F9FAFC] w-full shadow h-52 relative">
                            <NVLlabel text="Course Progress" className="nvl-Def-Label px-4 py-2" />
                            <div className="grid place-content-center py-3">
                                <div className=" rounded-md w-full relative p-2 md:p-0 ">
                                    <Doughnut data={CourseCompletion} options={{
                                        hover: { mode: null },
                                        responsive: false,
                                        elements: {
                                            arc: {
                                                borderWidth: 0,
                                            },
                                        },
                                        plugins: {
                                            legend: {
                                                position: "right",
                                                display: true,
                                                labels: {
                                                    padding: 25,
                                                    boxWidth: 50,
                                                    usePointStyle: true,
                                                    font: {
                                                        family: "Montserrat, sans-serif",
                                                        size: 12,
                                                    },
                                                },
                                            },
                                        },
                                        cutout: "80%",
                                        maintainAspectRatio: false,
                                    }} id="DoughnutClass" />
                                    <div className="absolute top-6 left-4 md:top-8 md:left-7 text-center text-xs font-semibold p-6 rounded-full">
                                        <div>{CoursCompletion?.[0] && Object.keys(CoursCompletion?.[0])?.length == "0" ? 0 : CoursCompletion?.length}</div>
                                        <div>{CoursCompletion?.length <= 1 ? "Course" : "Courses"}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="bg-[#F9FAFC] w-full shadow h-52 relative">
                            {watch("isFetchinghours") ? <NVLFetchDataLoading /> : <>
                                <NVLlabel text="Learning Hours" className="nvl-Def-Label px-4 py-2" />
                                <div className="grid place-content-between grid-flow-col py-3">
                                    <div className=" rounded-md w-full relative p-2 md:p-0 ">
                                        <Doughnut data={learningHoursData} options={chartOptions} id="DoughnutClass" />
                                        <div className='font text-md px-16 absolute top-14 left-14  text-center font-semibold'>
                                            <div className="text-blue-600">HH:MM</div>
                                            {eventHours?.totalLearningHours && Object.keys(eventHours?.totalLearningHours)?.length == "0" ||
                                                eventHours?.totalLearningHours?.totaltime == ":00" || toHoursAndMinutes(eventHours?.totalLearningHours?.time) == "NaN:NaN" ? "00:00" :
                                                toHoursAndMinutes(eventHours?.totalLearningHours?.time)}
                                        </div>
                                    </div>
                                    <div className="space-y-4 my-auto -translate-x-10">
                                        <div className="flex gap-2"><i className="fa-solid fa-circle text-[#36A2EB]"></i>
                                            <p className="text-sm font-normal">Activity</p></div>
                                        <div className="flex gap-2"><i className="fa-solid fa-circle text-[#FFCE56]"></i>
                                            <p className="text-sm font-normal">Course</p></div>
                                    </div>
                                </div></>}
                        </div>
                        <div className="bg-[#F9FAFC] w-full shadow h-52 relative">
                            <NVLlabel text="Achivements" className="nvl-Def-Label px-4 py-2" />
                            <div className="grid place-content-center py-3">
                                <div className="flex flex-col items-center pb-10">
                                    <NVLlabel text="Certificates " className="nvl-Def-Label px-4 py-2" />
                                    <NVLlabel text={achivementData?.CertificateCount && achivementData?.CertificateCount} className="nvl-Def-Label px-4 py-2" />
                                    <NVLlabel text="Badges" className="nvl-Def-Label px-4 py-2" />
                                    <NVLlabel text={achivementData?.BadgeCount && achivementData?.BadgeCount} className="nvl-Def-Label px-4 py-2" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className={`w-full ${watch("Isfetch") ? "pointer-events-none" : ""}`}>
                        <ul className="grid sm:flex gap-4 sm:gap-0 justify-items-center justify-between" role="tablist">
                            <div className="flex  sm:gap-4 p-2">
                                <li className=" text-center">
                                    <a
                                        className={"text-xs  sm:px-2 py-1 block leading-normal " + (openTab === "1" ? "text-primary font-semibold border-b-2 border-primary " : " bg-white ")}
                                        onClick={(e) => {
                                            IsReportLoader.current = true;
                                            e.preventDefault();
                                            setOpenTab("1");
                                        }}
                                        data-toggle="tab" href="#link1" role="tablist">
                                        Course Summary
                                    </a>
                                </li>
                                <li className=" text-center">
                                    <a className={"text-xs  px-2 py-1 block leading-normal " + (openTab === "2" ? "text-primary font-semibold border-b-2 border-primary " : " bg-white ")}
                                        onClick={(e) => {
                                            IsReportLoader.current = true;
                                            e.preventDefault();
                                            setOpenTab("2");

                                        }} data-toggle="tab" href="#link1" role="tablist">
                                        Activity Summary
                                    </a>
                                </li>
                            </div>

                        </ul>
                        <div className="py-2 flex-auto text-xs ">
                            <div className="tab-content tab-space ">
                                <div className={""} id="link1">
                                    {watch("Isfetch") ? <div className="p-14"> <NVLLoadingSpinner /></div> :
                                        <NVLGridTable
                                            id="tblEnrollList"
                                            className="max-w-full"
                                            HeaderColumn={headerColumn}
                                            RowGridDataPass={{ RowGrid: refgriddata }} />}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Container>
        </>
    )
}
