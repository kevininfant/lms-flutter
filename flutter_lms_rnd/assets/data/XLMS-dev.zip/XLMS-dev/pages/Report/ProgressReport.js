import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLProgressBar from "@components/Controls/NVLProgressBar";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Doughnut } from "react-chartjs-2";
import { useForm } from "react-hook-form";

import { listXlmsCourseEnrollUser, listXlmsReportCourseConsumeInfo } from "src/graphql/queries";
import * as Yup from "yup";
Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

export default function ProgressReport(props) {
  const router = useRouter();
  const dropDownFilter = useRef({ Status: 'All' })
  const [courseProgressData, setCourseProgressData] = useState({})
  const courseOptions = useRef([{ value: "All", text: "Filter by course" }]);
  const [filterVariable, setFilterVariable] = useState("All")  
  const PageRoutes = useMemo(() => {
    return [
      { path: "/Report/ReportList", breadcrumb: "Reports" },
      { path: "", breadcrumb: "Course Progress" }
    ];
  }, [])

  const validationSchema = Yup.object().shape({
    ddlCourse: Yup.string().test("", "", (e) => {
      if (e != dropDownFilter?.current.Course && ((e != "") || (e == "" && dropDownFilter?.current.Course != undefined))) {
        dropDownFilter.current.Course = e
      }
      return true
    }).nullable(),
    ddlStatus: Yup.string().test("", "", (e) => {
      if (e != dropDownFilter?.current.Status && ((e != "") || (e == "" && dropDownFilter?.current.Status != undefined))) {
        dropDownFilter.current.Status = e
        setValue("fetch", true);
        getStatusData(e)
        setValue("fetch", false);
      }
      return true
    }).nullable(),
    txtsearch: Yup.string().nullable()

  });
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
  const { errors } = formState;


  const getStatusData = useCallback((e) => {
    setValue("fetch", true);
    setFilterVariable(e)
    setValue("fetch", false);

  }, [setValue])
  const courseProgressList = useMemo(() => {
    return {
      Name: "listXlmsReportCourseConsumeInfo",
      query: listXlmsReportCourseConsumeInfo,
      variable: { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSE#ENROLLUSER#" + props?.user?.attributes?.sub, SK: "COURSE#", limit: 1000 },
    };
  }, [props?.TenantInfo?.TenantID, props?.user?.attributes?.sub]);
  const headerColumn = useMemo(() => {
    return [{ HeaderName: "Course Name", Columnvalue: "CourseName", HeaderCss: "!w-6/12" },
    { HeaderName: "Start Date", Columnvalue: "StartDate", HeaderCss: "!w-1/12", },
    { HeaderName: "End Date", Columnvalue: "EndDate", HeaderCss: "!w-1/12", },
    { HeaderName: "Seat Time", Columnvalue: "SeatTime", HeaderCss: "!w-1/12", },
    { HeaderName: "Completion(%)", Columnvalue: "Completion", HeaderCss: "!w-1/12", },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-1/12" }];
  }, []);
  function getDateFormat(date) {
    if (date == undefined) {
      return "-"
    } else {
      return (new Date(date).toLocaleDateString())
    }
  }
  const GetModuleWise = useCallback((CourseID) => {
    router.push(`/Report/ProgressModuleWiseReport?CourseID=${CourseID}`)
  }, [router])

  useEffect(() => {
    async function fetchData() {
      setValue("fetch", true);
      const courseData = await AppsyncDBconnection(listXlmsReportCourseConsumeInfo, courseProgressList.variable, props?.user?.signInUserSession?.accessToken?.jwtToken)
      const courses = await AppsyncDBconnection(listXlmsCourseEnrollUser, { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#1", SK: "COURSEINFO#", limit: 1000 }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      setCourseProgressData({ CourseData: courseData?.res?.listXlmsReportCourseConsumeInfo, Courses: courses?.res?.listXlmsCourseEnrollUser?.items })
      setValue("fetch", false);
    }
    fetchData()
  }, [setValue, courseProgressList.variable, props?.TenantInfo?.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken])

  const gridDataBind = useCallback(
    () => {

      let rowGrid = []
      let viewData = courseProgressData
      let status, seatTime, courseOption = watch("ddlCourse"), search = watch("txtsearch")?.toLowerCase(), name
      let filteredData = []
      function getCourseDetails(courseID, key) {

        const courseName =
          viewData.Courses &&
          viewData.Courses.filter((item) => {
            return item.CourseID == courseID;
          });
        return courseName?.[0]?.[key];

      }
      if (filterVariable == "All") {
        courseOption != "All" || search != "" ? viewData?.CourseData?.items.map((item, index) => {
          name = getCourseDetails(item.CourseID, "CourseName")?.toLowerCase()
          if (courseOption == item.CourseID) {
            filteredData.push(item);
          } else if (name?.includes(search) && search != "") {
            filteredData.push(item);
          }
        }) : filteredData = viewData?.CourseData?.items

      } else if (filterVariable == "Completed") {
        courseOption != "All" || search != "" ? viewData?.CourseData?.CompletedItems.map((item, index) => {
          name = getCourseDetails(item.CourseID, "CourseName")?.toLowerCase()

          if (courseOption == item.CourseID) {
            filteredData.push(item);
          } else if (name?.includes(search) && search != "") {
            filteredData.push(item);
          }
        }) : filteredData = viewData?.CourseData?.CompletedItems


      } else if (filterVariable == "Yettostart") {
        courseOption != "All" || search != "" ? viewData?.CourseData?.Yettostarttems.map((item, index) => {
          name = getCourseDetails(item.CourseID, "CourseName")?.toLowerCase()

          if (courseOption == item.CourseID) {
            filteredData.push(item);
          } else if (name?.includes(search) && search != "") {
            filteredData.push(item);
          }
        }) : filteredData = viewData?.CourseData?.Yettostarttems
      } else if (filterVariable == "Inprogress") {
        courseOption != "All" || search != "" ? viewData?.CourseData?.InprogressItems.map((item, index) => {
          name = getCourseDetails(item.CourseID, "CourseName")?.toLowerCase()

          if (courseOption == item.CourseID) {
            filteredData.push(item);
          } else if (name?.includes(search) && search != "") {
            filteredData.push(item);
          }
        }) : filteredData = viewData?.CourseData?.InprogressItems
      }

      filteredData && filteredData.map((getItem, index) => {
        if (getItem.CompletionStatus != undefined) {
          status = JSON.parse(getItem.CompletionStatus)
        }
        else {
          status = { CompletionDate: "-", progress: 0 }
        }
        if (status?.progress == undefined) {
          status = { CompletionDate: "-", progress: 0 }

        }
        if (getItem.TotalHours == 0 || getItem.TotalHours == undefined) {
          seatTime = "00:00"
        } else {
          function toHoursAndMinutes() {
            const hours = Math.floor(getItem.TotalHours / 60);
            const minutes = getItem.TotalHours % 60;

            return `${padToTwoDigits(hours)}:${padToTwoDigits(minutes)}`;
          }

          function padToTwoDigits(num) {
            return num.toString().padStart(2, '0');
          }
          seatTime = toHoursAndMinutes()
        }
        rowGrid.push({
          PK: (
            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
          ),
          SK: (
            <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
          ),
          CourseID: (
            <NVLlabel id={"lblCourseID" + (index + 1)} name="CourseID" text={getItem.CourseID} />
          ),
          CourseName: (
            <>
              <NVLLink id={"txtCourseName" + (index + 1)} text={getCourseDetails(getItem.CourseID, "CourseName")} className={`${getCourseDetails(getItem.CourseID, "CourseName") && "p-2"}`} onClick={() => GetModuleWise(getItem.CourseID)} />
            </>
          ),
          StartDate: (
            <>
              <NVLlabel id={"txtStartDate" + (index + 1)} text={getDateFormat(getItem.CreatedDate)} />
            </>
          ),
          EndDate: (
            <>
              <NVLlabel id={"txtEndDate" + (index + 1)} text={status.CompletionDate == "-" ? "-" : getDateFormat(status.CompletionDate)} />
            </>
          ),
          SeatTime: (
            <>
              <NVLlabel id={"txtSeatTime" + (index + 1)} text={seatTime} />
            </>
          ),
          Completion: (
            <>
              <div className="flex items-center gap-2 " >

                <NVLProgressBar text="Progress" ProgressCss={"w-44"}
                  bgcolor={(status.progress) > 0 && (status.progress) < 100 ? "#ffa500" : (status.progress) == 100 ? "#008000" : "#ff0000"}
                  progress={status.progress}
                />
                <NVLlabel text={status.progress == "-" ? "-" : `${status.progress}%`} />
              </div>

            </>
          ),
          Status: (
            <>
              <NVLlabel id={"txtStatus" + (index + 1)} text={(status.progress) > 0 && (status.progress) < 100 ? "In Progress" : (status.progress) == 0 ? "Yet to Start" : (status.progress) == "-" ? "" : "Completed"}></NVLlabel>

            </>
          )

        })
      })

      return rowGrid;
    }, [GetModuleWise, courseProgressData, filterVariable, watch]
  );
  
  const GetCompletedStatus = useMemo(() => {
    return [
      { value: "All", text: "Filter by Status" },
      { value: "Completed", text: "Completed" },
      { value: "Inprogress", text: "InProgress" },
      { value: "Yettostart", text: "Yet to start" },
    ]
  }, [])

  const GetCourseOptions = () => {
    function getCourseDetails(courseID, key) {
      const courseName =
        courseProgressData?.Courses &&
        courseProgressData?.Courses.filter((item) => {
          return item.CourseID == courseID;
        });
      return courseName?.[0]?.[key];
    }

    let options = [{ value: "All", text: "Filter by Course" }]
    courseProgressData?.CourseData?.items && courseProgressData?.CourseData?.items.map((data, index) => {
      options.push({ value: data.CourseID, text: getCourseDetails(data.CourseID, "CourseName") })
    })
    courseOptions.current = options
    return courseOptions.current
  }
  const CourseCompletion = useMemo(() => {
    const Completion = {
      labels: [Math.round(courseProgressData?.CourseData?.FinalCount > 0 ? (courseProgressData?.CourseData?.CompletedCount / courseProgressData?.CourseData?.FinalCount) * 100 : 0)
        + "% Completed", Math.round(courseProgressData?.CourseData?.FinalCount > 0 ? (courseProgressData?.CourseData?.InprogressCount / courseProgressData?.CourseData?.FinalCount) * 100 : 0)
      + "% In Progress", Math.round(courseProgressData?.CourseData?.FinalCount > 0 ? (courseProgressData?.CourseData?.YettostartCount / courseProgressData?.CourseData?.FinalCount) * 100 : 0) + "% Yet to Start"],
      datasets: [
        {
          data: [courseProgressData?.CourseData?.CompletedCount, courseProgressData?.CourseData?.InprogressCount, courseProgressData?.CourseData?.YettostartCount],
          backgroundColor: ["green", "orange", "red"],
          hoverOffset: 4,
        },
      ],
    };
    return Completion;
  }, [courseProgressData?.CourseData])
  const DoughnutOptions2 = {
    responsive: false,
    elements: {
      arc: {
        borderWidth: 0,
      },
    },
    plugins: {
      legend: {
        position: "right",
        display: true,
        labels: {
          padding: 25,
          boxWidth: 10,
          usePointStyle: true,
          font: {
            family: "Montserrat, sans-serif",
            size: 12,
          },
        },
      },
    },
    cutout: "80%",
    maintainAspectRatio: false,
  };

  return (
    <>
      <Container title="Course Progress" PageRoutes={PageRoutes}>
        <div className="bg-[#F9FAFC] w-full shadow flex justify-start p-4">
          {/* Doughnut chart */}
          <div className="grid-cols-12 grid-flow-col gap-4 pt-4">
            <NVLSettingsCard outerclass="rounded-md px-4 w-full relative p-2 md:p-0">
              <Doughnut data={CourseCompletion} options={DoughnutOptions2} className="DoughnutClass" />
              <div className="absolute top-6 left-4 md:top-8 md:left-7 text-center text-xs font-semibold p-6 rounded-full">
                <div>{courseProgressData?.CourseData?.FinalCount}</div>
                <div>{courseProgressData?.CourseData?.FinalCount == undefined || courseProgressData?.CourseData?.FinalCount == "NoRecord" || (courseProgressData?.CourseData?.FinalCount == "Exists" && Object.values(courseProgressData?.CourseData?.FinalCount)?.length == 1) ? "Course" : "Courses"}</div>
              </div>
            </NVLSettingsCard>
          </div>
        </div>
        <div className="grid grid-cols-12 grid-flow-col gap-4 pt-4 px-3">
          <div className="col-span-6 sm:col-span-3">
            <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1">
              Course Name
            </NVLlabel>
            <NVLSelectField id="ddlCourse" errors={errors} options={GetCourseOptions()} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
          </div>
          <div className="col-span-6 sm:col-span-3">
            <NVLlabel htmlFor="Department" className="block text-sm font-medium text-gray-600 py-1">
              Status
            </NVLlabel>
            <NVLSelectField id="ddlStatus" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={GetCompletedStatus} errors={errors} />
          </div>
          <div className="col-span-6 sm:col-span-3 invisible"></div>
          <div className="col-span-6 sm:col-span-3">
            <NVLlabel htmlFor="User-Name" className="block text-sm font-medium text-gray-600 py-1">
              Search by Course Name
            </NVLlabel>
            <NVLTextbox id="txtsearch" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by course name" />
          </div>
          <div className="col-span-6 sm:col-span-3 pt-6">
            <div className="flex items-center">
              <NVLButton id="btnDownload"
                className={"nvl-button !bg-primary  text-white !h-10 hidden"}>
                <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
              </NVLButton>
              {/* <div className="pb-2 pl-2 ">
                <NVLlabel
                  CustomCss="-translate-x-72 pt-4"
                  className="nvl-Def-Label pb-1"
                  HelpInfo={"Additional report details can be downloaded here"}
                  HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                />
              </div> */}
            </div>
          </div>
        </div>
        {!watch("fetch") && (gridDataBind()?.length ? <NVLGridTable
          id="tblEnrollList" className="max-w-full"
          HeaderColumn={headerColumn}
          RowGridDataPass={{ RowGrid: gridDataBind() }} />
          : <div >
            <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />
          </div>)}
        {watch("fetch") && <NVLLoadingSpinner />}
      </Container>
    </>
  )
}
