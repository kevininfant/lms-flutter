
import Container from "@components/Container/Container";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import { useRouter } from "next/router";

function ReportList(props) {
  const router = useRouter();
  const CardsList = [
    {
      id: "1", CardName: `Course Progress`, CardIcon: <i className="fas fa-book-open text-5xl" />,
      ActionUrl: () => router.push("/Report/ProgressReport"),
    },
    {
      id: "2", CardName: "Training Report", CardIcon: <i className="fa fa-solid fa-bell text-5xl"></i>,
      // ActionUrl: () => router.push("/Report/CourseProgressReport") 
    },

    {
      id: "3", CardName: "Activity Report", CardIcon: <i className="fas fa-tasks text-5xl" />,
      ActionUrl: () => router.push("/Report/ActivityProgressReport")
    },

    {
      id: "4", CardName: "Learning Hours", CardIcon: <i className="fa fa-solid fa-bell text-5xl"></i>,
      ActionUrl: () => router.push("/Report/LearningHours") 
    },
    // {
    //   id: "5", CardName: "Progress Report AppSync", CardIcon: <i className="fa fa-solid fa-book-open text-5xl"></i>,
    //   ActionUrl: () => router.push("/Report/ProgressReport") 
    // },
    // {
    //   id: "6", CardName: "Activity Progress Report AppSync", CardIcon: <i className="fa fa-solid fa-book-open text-5xl"></i>,
    //   ActionUrl: () => router.push("/Report/ActivityProgressReport") 
    // },
  ];

  const PageRoutes = [
    { path: "", breadcrumb: "Report" }
  ];
  return (
    <>
      <Container title="Reports">
        <NVLBreadCrumbs Routes={PageRoutes}></NVLBreadCrumbs>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4 pt-4">
          {CardsList &&
            CardsList.map((getItem, index) => {
              return (
                <div key={index}>
                  <NVLSettingsCard CardIcon={getItem.CardIcon} CardName={getItem.CardName} onClick={getItem.ActionUrl} borderclass="border-b-4 border-th-body-icon-hover-color" className="h-56 nvl-card-shadow" outerclass="p-3" />
                </div>
              );
            })}
        </div>
      </Container>
    </>
  );
}

export default ReportList;




















