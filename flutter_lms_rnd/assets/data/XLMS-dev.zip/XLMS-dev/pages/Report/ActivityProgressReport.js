import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLProgressBar from "@components/Controls/NVLProgressBar";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { getXlmsCourseActivityConfig, listXlmsEnrollUser, listXlmsReportActivityConsumeInfo } from "src/graphql/queries";
import * as Yup from "yup";
export default function ActivityProgressReport(props) {
  const [activityProgressData, setActivityProgressData] = useState({})
  const [filterVariable, setFilterVariable] = useState("All")
  const dropDownFilter = useRef({ Status: 'All' })
  const GetCompletedStatus = useMemo(() => {
    return [
      { value: "All", text: "Filter by Status" },
      { value: "Completed", text: "Completed" },
      { value: "Yettostart", text: "Yet to start" },
    ]
  }, [])
  const validationSchema = Yup.object().shape({
    ddlActivityType: Yup.string().test("", "", (e) => {
      if (e != dropDownFilter?.current.Course && ((e != "") || (e == "" && dropDownFilter?.current.Course != undefined))) {
        dropDownFilter.current.Course = e
      }
      return true
    }).nullable(),
    ddlStatus: Yup.string().test("", "", (e) => {
      if (e != dropDownFilter?.current.Status && ((e != "") || (e == "" && dropDownFilter?.current.Status != undefined))) {
        dropDownFilter.current.Status = e
        setValue("fetch", true);
        getStatusData(e)
        setValue("fetch", false);
      }
      return true
    }).nullable(),
  });
  const getStatusData = useCallback((e) => {
    setValue("fetch", true);
    setFilterVariable(e)
    setValue("fetch", false);
  }, [setValue])

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
  const { errors } = formState;
  const PageRoutes = useMemo(() => {
    return [
      { path: "/Report/ReportList", breadcrumb: "Reports" },
      { path: "", breadcrumb: "Activity Progress" }

    ];
  }, [])
  function getDateFormat(date) {
    return (new Date(date).toLocaleDateString())
  }
  const headerColumn = useMemo(() => {
    return [{ HeaderName: "Activity Name", Columnvalue: "ActivityName", HeaderCss: "!w-6/12" },
    { HeaderName: "Activity Type", Columnvalue: "ActivityType", HeaderCss: "!w-1/12", },
    { HeaderName: "Start Date", Columnvalue: "StartDate", HeaderCss: "!w-1/12", },
    { HeaderName: "End Date", Columnvalue: "EndDate", HeaderCss: "!w-1/12", },
    { HeaderName: "Seat Time", Columnvalue: "SeatTime", HeaderCss: "!w-1/12", },
    { HeaderName: "Completion(%)", Columnvalue: "Completion", HeaderCss: "!w-1/12", },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-1/12" }];
  }, []);
  const activityProgressList = useMemo(() => {
    return {
      Name: "listXlmsReportActivityConsumeInfo",
      query: listXlmsReportActivityConsumeInfo,
      variable: { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#ACTIVITY#ENROLLUSER#" + props?.user?.attributes?.sub, SK: "ACTIVITYID#" },

    };
  }, [props?.TenantInfo?.TenantID, props?.user?.attributes?.sub]);
  useEffect(() => {
    async function fetchData() {
      setValue("fetch", true);
      const Activitydata = await AppsyncDBconnection(listXlmsReportActivityConsumeInfo, activityProgressList.variable, props?.user?.signInUserSession?.accessToken?.jwtToken)
      const activity = await AppsyncDBconnection(listXlmsEnrollUser, { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#1", SK: "ACTIVITYTYPE#" }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      const activityType = await AppsyncDBconnection(getXlmsCourseActivityConfig, { PK: "XLMS#ACTIVITY", SK: "ACTIVITY#ACTIVITYTYPE", }, props.user.signInUserSession.accessToken.jwtToken);

      setActivityProgressData({ ActivityData: Activitydata?.res?.listXlmsReportActivityConsumeInfo, Activity: activity?.res?.listXlmsEnrollUser?.items, ActivityType: activityType?.res?.getXlmsCourseActivityConfig?.ActivityType })
      setValue("fetch", false);
    }
    fetchData()
  }, [setValue, activityProgressList.variable, props.TenantInfo.TenantID, props.sub, props?.user?.signInUserSession?.accessToken?.jwtToken])

  const gridDataBind = useCallback(() => {
    let rowGrid = []
    let viewData = activityProgressData
    let search = watch("txtsearch")?.toLowerCase(), type = watch("ddlActivityType"), name
    let filteredData = []
    function getActivityDetails(activityID, key) {
      const activityName =
        viewData.Activity &&
        viewData.Activity.filter((item) => {
          return item.ActivityID == activityID;
        });
      return activityName?.[0]?.[key];
    }
    if (filterVariable == "All") {
      type != "All" || search != "" ? viewData?.ActivityData?.items.map((item, index) => {
        name = getActivityDetails(item.ActivityID, "ActivityName")?.toLowerCase()

        if (type == item.ActivityType) {
          filteredData.push(item);

        } else if (name?.includes(search) && search != "") {
          filteredData.push(item);
        }
      }) : filteredData = viewData?.ActivityData?.items

    } else if (filterVariable == "Completed") {
      type != "All" || search != "" ? viewData?.ActivityData?.CompletedItems.map((item, index) => {
        name = getActivityDetails(item.ActivityID, "ActivityName")?.toLowerCase()

        if (type == item.ActivityType) {
          filteredData.push(item);

        } else if (name?.includes(search) && search != "") {
          filteredData.push(item);
        }
      }) : filteredData = viewData?.ActivityData?.CompletedItems
    } else if (filterVariable == "Yettostart") {
      type != "All" || search != "" ? viewData?.ActivityData?.Yettostarttems.map((item, index) => {
        name = getActivityDetails(item.ActivityID, "ActivityName")?.toLowerCase()

        if (type == item.ActivityType) {
          filteredData.push(item);

        } else if (name?.includes(search) && search != "") {
          filteredData.push(item);
        }
      }) : filteredData = viewData?.ActivityData?.Yettostarttems
    }
    filteredData && filteredData.map((getItem, index) => {
      let seatTime, duration = getItem.ActivityDuration
      if (duration == 0 || duration == undefined) {
        seatTime = "00:00"
      } else {
        function toHoursAndMinutes() {
          const hours = Math.floor(duration / 60);
          const minutes = duration % 60;

          return `${padToTwoDigits(hours)}:${padToTwoDigits(minutes)}`;
        }

        function padToTwoDigits(num) {
          return num.toString().padStart(2, '0');
        }
        seatTime = toHoursAndMinutes()
      }

      rowGrid.push({
        PK: (
          <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
        ),
        SK: (
          <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
        ),
        ActivityID: (
          <NVLlabel id={"lblActivityID" + (index + 1)} name="ActivityID" text={getItem.ActivityID} />
        ),
        ActivityName: (
          <>
            <NVLlabel id={"txtActivityName" + (index + 1)} text={getActivityDetails(getItem.ActivityID, "ActivityName")} className={`${getActivityDetails(getItem.ActivityID, "ActivityName") && "p-2"}`} />
          </>
        ),
        ActivityType: (
          <>
            <NVLlabel id={"txtActivityType" + (index + 1)} text={getItem.ActivityType} className={`${getItem.ActivityType && "p-2"}`} />
          </>
        ),
        StartDate: (
          <>
            <NVLlabel id={"txtStartDate" + (index + 1)} text={getDateFormat(getItem.CreatedDate)} />
          </>
        ),
        EndDate: (
          <>
            <NVLlabel id={"txtEndDate" + (index + 1)} text={getItem.CompletionDate == undefined ? "-" : getDateFormat(getItem.CompletionDate)} />
          </>
        ),

        SeatTime: (
          <>
            <NVLlabel id={"txtSeatTime" + (index + 1)} text={seatTime} />
          </>
        ),
        Completion: (
          <>
            <div className="flex items-center gap-2 " >

              <NVLProgressBar text="Progress" ProgressCss={"w-44"}
                bgcolor={(getItem.CompletedStatus) > 0 && (getItem.CompletedStatus) < 100 ? "#ffa500" : (getItem.CompletedStatus) == 100 ? "#008000" : "#ff0000"}
                CompletedStatus={getItem.CompletedStatus}
              />
              <NVLlabel text={getItem.CompletedStatus == undefined ? "0%" : `${getItem.CompletedStatus}%`} />
            </div>

          </>
        ),
        Status: (
          <>
            <NVLlabel id={"txtStatus" + (index + 1)} text={(getItem.CompletedStatus) > 0 && (getItem.CompletedStatus) < 100 ? "In Progress" : (getItem.CompletedStatus) == 0 || (getItem.CompletedStatus) == undefined ? "Yet to Start" : "Completed"}></NVLlabel>

          </>
        )

      });

    })
    return rowGrid
  }, [activityProgressData, filterVariable, watch])

  const GetActivityTypeOptions = () => {
    let options = [{ value: "All", text: "Filter by Activity Type" }]
    if (activityProgressData?.ActivityType != undefined) {
      JSON.parse(activityProgressData?.ActivityType) && JSON.parse(activityProgressData?.ActivityType).map((data, index) => {
        options.push({ value: data, text: data })
      })
    }
    return options
  }
  return (
    <>
      <Container title="Course Progress" PageRoutes={PageRoutes}>
        <div className="grid grid-cols-12 grid-flow-col gap-4 pt-4 px-3">
          <div className="col-span-6 sm:col-span-3">
            <NVLlabel htmlFor="Activity-type" className="block text-sm font-medium text-gray-600 py-1">
              Activity Type
            </NVLlabel>
            <NVLSelectField id="ddlActivityType" errors={errors} options={GetActivityTypeOptions()} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
          </div>
          <div className="col-span-6 sm:col-span-3">
            <NVLlabel htmlFor="Department" className="block text-sm font-medium text-gray-600 py-1">
              Status
            </NVLlabel>
            <NVLSelectField id="ddlStatus" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={GetCompletedStatus} errors={errors} />
          </div>
          <div className="col-span-6 sm:col-span-3 invisible"></div>
          <div className="col-span-6 sm:col-span-3">
            <NVLlabel htmlFor="User-Name" className="block text-sm font-medium text-gray-600 py-1">
              Search by Activity Name
            </NVLlabel>
            <NVLTextbox id="txtsearch" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by course name" />
          </div>
          <div className="col-span-6 sm:col-span-3 pt-6">
            {/* <div className="flex items-center">
              <NVLButton id="btnDownload"
                className={"nvl-button !bg-primary  text-white !h-10"}
              >
                <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
              </NVLButton>

              <div className="pb-2 pl-2 ">
                <NVLlabel
                  CustomCss="-translate-x-72 pt-4"
                  className="nvl-Def-Label pb-1"
                  HelpInfo={"Additional report details can be downloaded here"}
                  HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                />
              </div>
            </div> */}
          </div>

        </div>
        {!watch("fetch") && (gridDataBind()?.length ? <NVLGridTable
          id="tblEnrollList" className="max-w-full"
          HeaderColumn={headerColumn}
          RowGridDataPass={{ RowGrid: gridDataBind() }} />
          : <div >
            <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />
          </div>)}
        {watch("fetch") && <NVLLoadingSpinner />}
      </Container>
    </>
  )
}
