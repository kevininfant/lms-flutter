import Container from '@components/Container/Container';
import NVLButton from '@components/Controls/NVLButton';
import NVLGridTable from '@components/Controls/NVLGridTable';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLLoadingSpinner from '@components/Controls/NVLLoadingSpinner';
import NVLSelectField from '@components/Controls/NVLSelectField';
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import NVLTextbox from '@components/Controls/NVLTextBox';
import { getXlmsCourseActivityConfig, listXlmsCourseManagementInfo } from '@graphql/graphql/queries';
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from 'next/router';
import { useCallback, useMemo, useRef } from 'react';
import { Doughnut } from "react-chartjs-2";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

function LearningHours(props) {
    const refRecordStatus = useRef();
    const refCourseCount = useRef();
    const refWhereQuery = useRef();
    const refgriddata = useRef();
    const refDropddownData = useRef([{ value: "", text: "Select" }]);
    const execID = useRef();
    const refHeaders = useRef();
    const totalUser = useRef();
    const GridDataLength = useRef()
    const router = useRouter()

    let AuthorizedToken = props?.user?.signInUserSession?.accessToken?.jwtToken;

    const validationSchema = Yup.object().shape({
        ddlReportType: Yup.string().test("", "Report Type is required", (e) => {
            if (refRecordStatus.current?.ddlReportType != e) {
                refRecordStatus.current = { ...refRecordStatus.current, ddlReportType: e };
                setValue("fetch", true);
                setValue("txtSearch", "")
                setValue("ddlCommonField","")
                setValue("ddlStatus","")
                GetDropdDownData(e);
            }
            return true;
        }).nullable(),
        ddlYear: Yup.string()
            .test("", "Select The Year", (e) => {
                if (refRecordStatus.current?.ddlYear != e && e != undefined) {
                    refRecordStatus.current = { ...refRecordStatus.current, ddlYear: e };
                    setValue("fetch", true);
                    setValue("txtSearch", "")
                    setValue("ddlCommonField","")
                    setValue("ddlStatus","")
                    GetDropdDownData(e);
                }
                return true;
            }).nullable(),
        ddlCommonField: Yup.string()
            .test("", "Select The Year", (e) => {
                if (refRecordStatus.current?.CourseOrActivity != e && e != undefined) {
                    refRecordStatus.current = { ...refRecordStatus.current, CourseOrActivity: e };
                    setValue("fetch", true);
                    fetchData();
                }
                return true;
            }).nullable(),
        ddlStatus: Yup.string()
            .test("", "Select The Year", (e) => {
                if (refRecordStatus.current?.Status != e && e != undefined) {
                    refRecordStatus.current = { ...refRecordStatus.current, Status: e };
                    setValue("fetch", true);
                    fetchData();
                }
                return true;
            }).nullable(),
    },
    );

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
    const { errors } = formState;

    const FileDownload = useCallback(
        async (e) => {
            setValue("download", true);
            const getTenantId = props.TenantInfo.TenantID;
            if (e?.type == "click") {
                const lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
                const headers = {
                    method: "POST",
                    headers: {
                        "Content-Type": "text/csv",
                        authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                        bucketname: process.env.REPORT_BUCKET_NAME,
                    },
                    body: `processed-data/${getTenantId}/${execID.current.QueryExecutionID}.csv`,
                };
                const reportDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
                var win = window.open(await reportDownload.res?.text(), "_self");
            }
            setValue("download", false);

        },
        [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue]
    );

    const GetCompletedStatus = useMemo(() => {
        return [
            { value: "", text: "Filter by Status" },
            { value: "Completed", text: "Completed" },
            { value: "Inprogress", text: "InProgress" },
            { value: "Yet to start", text: "Yet to start" },
        ]
    }, [])

    // Doughnut Chart
    const DoughnutProgress2 = {
        datasets: [
            {
                data: [totalUser.current && (("0" + (Math.floor(totalUser.current / 60))).slice(-2) + "." + ("0" + (totalUser.current % 60)).slice(-2)), "100.00"],
                backgroundColor: ["yellow", "gray"],
                hoverOffset: 4,
            },
        ],
    };

    const DoughnutOptions2 = {

        responsive: false,
        elements: {
            arc: {
                borderWidth: 0,
            },
        },
        plugins: {
            legend: {
                position: "right",
                display: true,
                labels: {
                    padding: 25,
                    boxWidth: 50,
                    usePointStyle: true,
                    font: {
                        family: "Montserrat, sans-serif",
                        size: 12,
                    },
                },
            },
        },
        cutout: "80%",
        maintainAspectRatio: false,
    };
    //

    const ReportType = useMemo(() => {
        return [
            { value: "", text: "Select Report Type" },
            { value: "Course", text: "My Course" },
            { value: "Activity", text: "My Activity" },
        ];
    }, []);

    const YearData = useMemo(() => {
        let selectedyear = new Date().getFullYear();
        let YearData = [];
        for (let i = selectedyear; i >= 2000; i--) {
            YearData.push({ value: i, text: i })
        }
        return YearData

    }, [])

    const GridDataBind = useCallback(() => {
        try {
            const RowGrid = [];

            let viewData = refgriddata.current != undefined && Object.values(JSON?.parse(refgriddata.current));
            viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);

            execID.current = refgriddata.current != undefined && JSON?.parse(refgriddata.current);

            viewData &&
                viewData.map((getItem, index) => {

                    if (watch("ddlReportType") == "Course") {
                        if (Object.entries(getItem).length != 0) {
                            RowGrid.push({
                                coursename:<NVLlabel id={index + 1} text={getItem.coursename}/>,
                                ["Category"]: <NVLlabel id={index + 1} text={getItem?.categoryname} />,
                                SeatTime: <NVLlabel id={index + 1} text={getItem.SeatTime ? getItem.SeatTime : "00:00"} />,
                                Completion: <NVLlabel id={index + 1} text={getItem["Completion(%)"]} />,
                                Status: <NVLlabel id={index + 1} text={getItem.Status} />,
                            });
                        }
                    } else {
                        if (Object.entries(getItem).length != 0) {
                            RowGrid.push({
                                ActivityName: <NVLlabel id={index + 1} text={getItem.ActivityName} />,
                                ActivityType: <NVLlabel id={index + 1} text={getItem.ActivityType} className="p-2 pt-2" />,
                                SeatTime: <NVLlabel id={index + 1} text={getItem?.SeatTime ? getItem?.SeatTime : "00:00"} />,
                                ["Completion (%)"]: <NVLlabel id={index + 1} text={getItem["Completion(%)"]} />,
                                Status: <NVLlabel id={index + 1} text={getItem.Status} />,
                            });
                        }
                    }
                });
            return RowGrid;
        } catch (error) {
            console.log("Failed to retreive the records", error);
        }
    }, [watch]);

    const getLearningHours = useCallback((getFilterLoginData) => {
        totalUser.current = "00:00";
        let tempViewData = getFilterLoginData != undefined && Object.values(JSON.parse(getFilterLoginData));
        let viewData = (tempViewData && tempViewData != undefined) && JSON.parse(tempViewData?.[1]);
        const courseEnrolledCount = [];

        viewData && viewData.map((getItem)=>{
            if (getItem.Status == "Completed" && getItem?.SeatTime!= undefined && getItem?.SeatTime!= null) {
                if (getItem?.SeatTime!= "") {
                    if (watch("ddlReportType") == "Course") {
                        courseEnrolledCount.push(getItem?.SeatTime+ ":00");
                    } else {
                        courseEnrolledCount.push(getItem?.SeatTime)
                    }
                }
                const totalSeconds = courseEnrolledCount.reduce((acc, val) => {
                    const [hours, minutes, seconds] = val.split(':').map(Number);
                    return acc + hours * 3600 + minutes * 60 + seconds;
                }, 0);
                const hours = Math.floor(totalSeconds / 3600);
                const minutes = Math.floor((totalSeconds - hours * 3600) / 60);
                const seconds = totalSeconds % 60;
    
                const totalTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                const [Hour,Min] = totalTime.split(":").slice(0,2)

                totalUser.current = Hour + ":" + Min;
            }
        })
      
    }, [watch]);


    const fetchData = useCallback(async () => {
        
        setValue("fetch", true);
        
        let activityOrCourse =document.getElementById("ddlCommonField").options[document.getElementById("ddlCommonField").selectedIndex].text == "Select" ? "" : document.getElementById("ddlCommonField").options[document.getElementById("ddlCommonField").selectedIndex].title
        let lstrCompletionStatus = watch("ddlStatus")
        let activityOrCourseName = watch("txtSearch")
        
        
        let lqrywhere = `WHERE StartDate like '%${watch("ddlYear")}%' `;

        if (activityOrCourse != "") {
            lqrywhere += ` AND ${watch("ddlReportType") == "Activity" ? "ActivityType" : "coursename"}='${activityOrCourse}'`;
        }
        if (lstrCompletionStatus != "") {
            lqrywhere += ` AND Status='${lstrCompletionStatus}'`;
        }

        if (activityOrCourseName != "") {
            lqrywhere += ` AND UPPER("${watch("ddlReportType") == "Activity" ? "ActivityName" : "CourseName"}") LIKE '%${activityOrCourseName?.toUpperCase()}%'`;
        }
        refWhereQuery.current = lqrywhere;

        try {
            let lGetUserloginInfoData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    menuid: watch("ddlReportType") == "Activity" ? "115103" : "115401",
                    usersub: Auth?.user?.attributes["sub"],
                    tenantid: props?.TenantInfo?.TenantID,
                },
                body: `${refWhereQuery.current}`,
            });
            let lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
            lGetUserloginInfoDatas!=undefined && Object.keys(JSON.parse(JSON.parse(lGetUserloginInfoDatas)?.State)?.[0]).length == 0 ?GridDataLength.current = "NoRecord":GridDataLength.current = "Exists";
            refgriddata.current = lGetUserloginInfoDatas;
            getLearningHours(lGetUserloginInfoDatas)
        } catch (error) {
            setValue("fetch", false);
        }
        setValue("fetch", false);
        setValue("submit",false)
    }, [getLearningHours, props?.TenantInfo?.TenantID, setValue, watch])

    const submitHandler = async (data) => {
        setValue("submit", true);
        fetchData()
    };

    const PageRoutes = useMemo(() => {
        return [
            { path: "/Report/ReportList", breadcrumb: "Reports" },
            { path: "", breadcrumb: "Learning Hours" }

        ];
    }, [])


    const GetDropdDownData = useCallback(async (e) => {

        if (e == "Select") return true;

        let ApiResponse, Headers, FinalData;
        if (refRecordStatus.current?.ddlReportType != "" && refRecordStatus.current?.ddlReportType != undefined) {
            let query = (refRecordStatus.current?.ddlReportType == "Activity" || e == "Activity") ? getXlmsCourseActivityConfig : listXlmsCourseManagementInfo;
            let pK = (refRecordStatus.current?.ddlReportType == "Activity" || e == "Activity") ? "XLMS#ACTIVITY" : "TENANT#" + props?.TenantInfo?.TenantID;
            let sK = (refRecordStatus.current?.ddlReportType == "Activity" || e == "Activity") ? "ACTIVITY#ACTIVITYTYPE" : "COURSEINFO#";

            let ResponseData = await AppsyncDBconnection(query, { PK: pK, SK: sK }, AuthorizedToken);
            FinalData = (refRecordStatus.current?.ddlReportType == "Activity" || e == "Activity") ? ResponseData.res?.getXlmsCourseActivityConfig : ResponseData.res?.listXlmsCourseManagementInfo?.items;
        }
        let Activity = FinalData?.ActivityType && JSON.parse(FinalData?.ActivityType);
        let DropdDownFinalData = [{ value: "", text: "Select" }];

        let lqrywhere;
        if (e == null || e == undefined || e == "") {
            let selectedyear = new Date().getFullYear();
            lqrywhere = `WHERE StartDate like '%${selectedyear}%' `;
        } else {
            let selectedyear = refRecordStatus.current?.ddlYear;
            lqrywhere = `WHERE StartDate like '%${selectedyear}%' `;
        }

        if (refRecordStatus.current?.ddlReportType == "Activity" || e == "Activity") {

            Headers = [
                { HeaderName: "Activity Name", Columnvalue: "ActivityName", HeaderCss: "!w-3/12" },
                { HeaderName: "Activity Type", Columnvalue: "ActivityType", HeaderCss: "!w-2/12" },
                // { HeaderName: "Start Date", Columnvalue: "Assigned Date", HeaderCss: "!w-3/12" },
                { HeaderName: "Seat Time", Columnvalue: "SeatTime", HeaderCss: "!w-3/12" },
                { HeaderName: "Completion(%)", Columnvalue: "Completion (%)", HeaderCss: "!w-3/12" },
                { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-0/12 whitespace-nowrap" },
            ]

            if (Activity != undefined) {
                Activity.map((getItem) => {
                    DropdDownFinalData.push({ value: getItem, text: getItem });
                });

                let lGetActivityyReportData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: AuthorizedToken,
                        menuid: "115103",
                        usersub: Auth?.user?.attributes["sub"],
                        tenantid: props.TenantInfo.TenantID,
                    },
                    body: `${lqrywhere}`,
                });
                ApiResponse = await lGetActivityyReportData?.res?.text();
                ApiResponse!=undefined && Object.keys(JSON.parse(JSON.parse(ApiResponse)?.State)?.[0]).length == 0 ?GridDataLength.current = "NoRecord":GridDataLength.current = "Exists";
            }
        } else if (refRecordStatus.current?.ddlReportType == "Course" || e == "Course") {

            Headers = [
                { HeaderName: "Course Name", Columnvalue: "coursename", HeaderCss: "!w-3/12" },
                { HeaderName: "Category", Columnvalue: "Category", HeaderCss: "!w-2/12" },
                { HeaderName: "Seat Time", Columnvalue: "SeatTime", HeaderCss: "!w-3/12" },
                { HeaderName: "Completion(%)", Columnvalue: "Completion", HeaderCss: "!w-3/12" },
                { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-0/12" },
            ]

            let lGetCourseProgressReportData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    authorizationtoken: AuthorizedToken,
                    menuid: "115401",
                    tenantid: props.TenantInfo.TenantID,
                    usersub: Auth?.user?.attributes["sub"],
                },
                body: `${lqrywhere}`,
            });

            ApiResponse = await lGetCourseProgressReportData?.res?.text();
            ApiResponse!=undefined && Object.keys(JSON.parse(JSON.parse(ApiResponse)?.State)?.[0]).length == 0 ?GridDataLength.current = "NoRecord":GridDataLength.current = "Exists";
            let viewData = ApiResponse != undefined && Object.values(JSON?.parse(ApiResponse));
            viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);
            viewData?.map((getItem) => {
                if (Object.entries(getItem).length != 0) {
                    if (getItem?.text?.toLowerCase() != "select") {
                        DropdDownFinalData.push({ value: getItem.courseid, text: getItem.coursename });
                    }
                }
            });
        }
        refDropddownData.current = DropdDownFinalData;
        refgriddata.current = ApiResponse;
        getLearningHours(ApiResponse)
        refHeaders.current = Headers;
        setValue("fetch", false);
    }, [AuthorizedToken, getLearningHours, props.TenantInfo.TenantID, setValue])

    return (
        <>
            <Container title="User Course Summary Report" PageRoutes={PageRoutes}>
                <form onSubmit={handleSubmit(submitHandler)} className={`${(watch("fetch") || watch("download")) ? "pointer-events-none" : "px-2"}`} >
                    <div className="px-3" id="divFilter">
                        <div className="block rounded-lg ">
                            <div className="py-1 pb-4">
                                <div className="grid grid-cols-12 grid-flow-col gap-4 pt-4 pb-3">
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Year" className="block text-sm font-medium text-gray-600 py-1">
                                            Year
                                        </NVLlabel>
                                        <NVLSelectField id="ddlYear" errors={errors} options={YearData} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="ReportType" className="block text-sm font-medium text-gray-600 py-1">
                                            Report Type
                                        </NVLlabel>
                                        <NVLSelectField id="ddlReportType" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={ReportType} errors={errors} />
                                    </div>
                                </div>
                                <div className="bg-[#F9FAFC] w-full shadow flex justify-center p-4">

                                    {/* Doughnut chart */}
                                    <div className="grid place-content-center ">
                                        <NVLSettingsCard outerclass=" rounded-md px-4 w-full relative p-2 md:p-0">
                                            <Doughnut data={DoughnutProgress2} options={DoughnutOptions2} class="DoughnutClass" />
                                            <div className="absolute top-6 left-4 md:top-8 md:left-7 text-center text-xs font-semibold p-6 float-left rounded-full">
                                                <div>{(refCourseCount.current && Object.values(refCourseCount.current)?.length != 1) ? Object.values(refCourseCount.current)?.length : ""}</div>
                                                <div className='text align-center px-16 absolute top-2'>HH:MM</div>
                                                <div className='font text-lg -translate-x-1 align-center px-16 absolute top-6'>
                                                    {totalUser.current == undefined || totalUser.current == "aN:aN"||totalUser.current == "NaN:NaN" || (watch("ddlReportType") == "Select" || watch("ddlReportType") == "undefined" || watch("ddlReportType")) == undefined ? "00:00"
                                                        : totalUser.current}
                                                </div>
                                                <div className='text-blue-500 text align-center px-14 absolute top-12 '>Learning</div>
                                                <div className='text-blue-500 text align-center px-16 absolute top-16'>Hours</div>
                                            </div>
                                        </NVLSettingsCard>
                                    </div>
                                </div>

                                <div className={`grid grid-cols-12 grid-flow-col gap-4 pt-4 ${watch("ddlReportType") == "" || watch("ddlReportType") == undefined ? "hidden" : ""}`}>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1">
                                            {`${watch("ddlReportType") == "Course" ? "Course Name" : "Activity Type"}`}
                                        </NVLlabel>
                                        <NVLSelectField id="ddlCommonField" errors={errors} options={refDropddownData.current} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Status" className="block text-sm font-medium text-gray-600 py-1">
                                            Status
                                        </NVLlabel>
                                        <NVLSelectField id="ddlStatus" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={GetCompletedStatus} errors={errors} />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3 invisible"></div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="User-Name" className="block text-sm font-medium text-gray-600 py-1">
                                            {`${watch("ddlReportType") == "Course" ? "Search By Course Name" : "Search By Activity Name"}`}
                                        </NVLlabel>
                                        <NVLTextbox id="txtSearch" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors}
                                            title={`Filter by ${watch("ddlReportType") == "Course" ? "course name" : "activity name"}`} />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3 pt-6">
                                        <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""}
                                            disabled={watch("submit") || watch("fetch") || watch("download") ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-primary  text-white !h-10" : "w-28 nvl-button !bg-primary  text-white !h-10"}>
                                            {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2 "></i>}
                                        </NVLButton>
                                    </div>
                                    <div className="col-span-6 sm:col-span-3 pt-6">
                                        <div className="flex items-center">

                                            <NVLButton id="btnDownload" disabled={GridDataLength.current == "NoRecord" || GridDataLength.current == undefined ? true : false} type={"button"}
                                                className={GridDataLength.current == "NoRecord" || GridDataLength.current == undefined? "nvl-button bg-primary Disabled !h-10" : "nvl-button !bg-primary  text-white !h-10"}
                                                onClick={(e) => FileDownload(e)} >
                                                <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                            </NVLButton>
                                            <div className="pb-2 pl-2 ">
                                                <NVLlabel
                                                    CustomCss="-translate-x-72 pt-4"
                                                    className="nvl-Def-Label pb-1"
                                                    HelpInfo={"Additional report details can be downloaded here"}
                                                    HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {!watch("fetch") && <div className="">
                            <NVLGridTable id="tblEnrollList" className="max-w-full"
                                HeaderColumn={refHeaders.current}
                                RowGridDataPass={{ RowGrid: (watch("ddlReportType") == "Select" || watch("ddlReportType") == "undefined" || watch("ddlReportType") == undefined) ? [] : GridDataBind() }} />
                        </div>}
                    </div>

                    <div>
                        {watch("fetch") &&
                            <div className="p-14"> <NVLLoadingSpinner /> </div>}
                    </div>
                </form>
            </Container>

        </>
    )
}

export default LearningHours