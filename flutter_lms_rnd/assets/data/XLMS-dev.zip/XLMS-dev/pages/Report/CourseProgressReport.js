import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLProgressBar from "@components/Controls/NVLProgressBar";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

function CourseProgressReport(props) {
  const [Data, setData] = useState({ ...props });
  const [FilterDropdownData, setFilterDropdownData] = useState({ Department: [{ value: "", text: "Filter by Department" }], Designation: [{ value: "", text: "Filter by Designation" }], Course: [{ value: "", text: "Filter by Course" }] });
  useEffect(() => {
    async function fetchData() {
      let ltuser = props.user;

      let lGetCourseProgressReportData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/text",
          authorizationtoken: ltuser.signInUserSession.accessToken.jwtToken,
          menuid: "115401",
          tenantid: ltuser.attributes["custom:tenantid"],
          usersub: ltuser?.attributes["sub"],
        },
      });

      let lGetCourseProgressData = await lGetCourseProgressReportData?.res?.text();
      lGetCourseProgressData != undefined && Object.keys(JSON?.parse(JSON?.parse(lGetCourseProgressData)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
      const DropdDownFinalData = [{ value: "", text: "Filter by Course" }]
      let viewData = lGetCourseProgressData != undefined && Object.values(JSON?.parse(lGetCourseProgressData));
      viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);
      viewData?.map((getItem) => {
          if (Object.entries(getItem).length != 0) {
              if (getItem?.text?.toLowerCase() != "select") {
                  DropdDownFinalData.push({ value: getItem.coursename, text: getItem.coursename });
              }
          }
      });
      setFilterDropdownData({Course:DropdDownFinalData})
      const z = {
        pGetCourseProgressReportData: lGetCourseProgressData,

      }
      setData((temp) => {
        return { ...temp, ...z }
      })
    }
    fetchData();

  }, [props.user])

  const PageRoutes = useMemo(() => {
    return [
      { path: "/Report/ReportList", breadcrumb: "Reports" },
      { path: "", breadcrumb: "Course Progress" }

    ];
  }, [])

  const router = useRouter();
  let AuthorizedToken = props?.user?.signInUserSession?.accessToken?.jwtToken;

  const refReportData = useRef();
  const refCourseCount = useRef();
  const refRecordStatus = useRef();
  const dropDownFilter = useRef({})

  const validationSchema = Yup.object().shape({
    ddlCourse: Yup.string().test("", "", (e) => {
      if (e != dropDownFilter?.current.Course && ((e != "") || (e == "" && dropDownFilter?.current.Course != undefined))) {
        dropDownFilter.current.Course = e
        getCourseData()
      }
      return true
    }).nullable(),
    ddlStatus: Yup.string().test("", "", (e) => {
      if (e != dropDownFilter?.current.Status && ((e != "") || (e == "" && dropDownFilter?.current.Status != undefined))) {
        dropDownFilter.current.Status = e
        getCourseData()
      }
      return true
    }).nullable(),
    txtsearch: Yup.string().nullable()
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
  const { errors } = formState;

  const HeaderColumn = useMemo(() => {
    return [
      { HeaderName: "Course Name", Columnvalue: "coursename", HeaderCss: "w-1/6" },
      { HeaderName: "Start Date", Columnvalue: "Start Date", HeaderCss: "w-1/6" },
      { HeaderName: "End Date", Columnvalue: "End Date", HeaderCss: "w-1/6" },
      { HeaderName: "SeatTime", Columnvalue: "SeatTime", HeaderCss: "w-1/6" },
      { HeaderName: "Completion(%)", Columnvalue: "Completion", HeaderCss: "w-1/6" },
      { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-1/6" },
    ]
  }, [])

  const execID = useRef();

  const GridDataBind = useCallback(() => {

    function GetModuleWise(CourseName) {

      // const CourseData = FilterDropdownData.Course?.filter(item => {
      //   return item.text == CourseName
      // })
      router.push(`/Report/CourseModuleWiseReport?CourseName=${CourseName}`)
    }

    try {
      const RowGrid = [];
      let viewData = Data?.pGetCourseProgressReportData != undefined && Object.values(JSON?.parse(Data?.pGetCourseProgressReportData));
      viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);
      refReportData.current = viewData;
      execID.current = Data?.pGetCourseProgressReportData != undefined && JSON?.parse(Data?.pGetCourseProgressReportData);

      viewData &&
        viewData.map((getItem, index) => {

          RowGrid.push({
            coursename: <>{<NVLLink id={index + 1} text={getItem.coursename}
              className={`${getItem.CourseName && "p-2"}`} onClick={() => GetModuleWise(getItem?.coursename)} />}</>,
            ["Start Date"]: <NVLlabel id={index + 1} text={getItem["StartDate"]} />,
            ["End Date"]: <NVLlabel id={index + 1} text={getItem["EndDate"]} />,
            SeatTime: <NVLlabel id={index + 1} text={getItem.SeatTime} />,
            Status: <NVLlabel id={index + 1} text={getItem?.Status} />,
            Completion: <> {getItem?.coursename &&
              <div className="flex items-center gap-2 " title={`${getItem?.Status} : ${getItem["Completion(%)"] ?? "0"}`}>
                <NVLProgressBar text="Progress" ProgressCss={"w-44"}
                  bgcolor={getItem["Completion(%)"] > "0%" ? ((getItem["Completion(%)"] < "100%" || getItem?.Status != "Completed") ? "#ffa500" : (getItem.IsActivityCompletion) ? "#94a3b8" : "#008000") : "#FF0000"}
                  progress={getItem["Completion(%)"] > "0%" ? getItem["Completion(%)"] : "0%"} />
                <NVLlabel text={`${getItem["Completion(%)"] ? getItem["Completion(%)"] : "0%"}`} />
              </div>
            }</>,
          });
        });
      return RowGrid;
    } catch (error) {
      console.log("Failed to retreive the records", error);
    }
  }, [Data?.pGetCourseProgressReportData, router]);


  const getCourseData = useCallback(async () => {

    setValue("fetch", true);

    let lqrywhere;

    let lstrCompletionStatus = watch("ddlStatus");
    // let lstrCourse = document.getElementById("ddlCourse").options[document.getElementById("ddlCourse").selectedIndex].text == "Filter by Course" ? "" : document.getElementById("ddlCourse").options[document.getElementById("ddlCourse").selectedIndex].title;
    let lstrCourse = watch("ddlCourse")
    let lstrUserName = watch("txtsearch");
    
    lqrywhere = `WHERE coursename !=''`;

    if (lstrCourse != "") {
      lqrywhere += ` AND coursename='${lstrCourse}'`;
    }

    if (lstrCompletionStatus != "") {
      lqrywhere += ` AND Status='${lstrCompletionStatus}'`;
    }

    if (lstrUserName != "") {
      lqrywhere += ` AND UPPER("coursename") LIKE '%${lstrUserName?.toUpperCase()}%'`;
    }
    try {
      let lGetUserloginInfoData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/text",
          menuid: "115401",
          tenantid: Auth?.user?.attributes["custom:tenantid"],
          usersub: Auth?.user?.attributes["sub"],
        },
        body: `${lqrywhere}`,
      });

      let lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
      lGetUserloginInfoDatas != undefined && Object.keys(JSON.parse(JSON.parse(lGetUserloginInfoDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";

      setData((temp) => {
        let a = { pGetCourseProgressReportData: lGetUserloginInfoDatas }
        return { ...temp, ...a }
      })
    } catch (error) {
      setValue("submit", false);
      setValue("fetch", false);
    }
    setValue("submit", false);
    setValue("fetch", false);
  }, [setValue, watch])

  const submitHandler = (data) => {
    setValue("submit", true);
    getCourseData()
  };

  const FileDownload = useCallback(async (e) => {
    setValue("download", true);

    try {
      if (e?.type == "click") {
        let lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
        let headers = {
          method: "POST",
          headers: {
            "Content-Type": "text/csv",
            authorizationtoken: AuthorizedToken,
            bucketname: process.env.REPORT_BUCKET_NAME,
          },
          body: `processed-data/${props?.TenantInfo?.TenantID}/${execID.current.QueryExecutionID}.csv`,
        };
        let lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
        var win = window.open(await lstrFileDownload.res?.text(), "_self");

      }
    } catch (error) {
      console.log("Failed to generate report", error);
    }
    setValue("download", false);

  },
    [AuthorizedToken, props?.TenantInfo?.TenantID, setValue]
  );

  //Doughnut Chart 

  const CourseCompletion = useMemo(() => {
    let ReportData = Data?.pGetCourseProgressReportData != undefined && Object.values(JSON?.parse(Data?.pGetCourseProgressReportData));
    ReportData = (ReportData && ReportData != undefined) && JSON.parse(ReportData?.[1]);
    refCourseCount.current = ReportData;
    let YetToStart = 0, ToatalOfInprogress = 0, ToatalOfCompleted = 0;
    ReportData?.length > 0 && ReportData.map((Item) => {
      if (Item?.Status == "Completed") ToatalOfCompleted += 1;
      else if (Item?.Status == "Inprogress") ToatalOfInprogress += 1;
      else if (Item?.Status == "Yet to start") YetToStart += 1;
    })
    const Completion = {
      labels: [Math.round(ReportData?.length > 0 ? (ToatalOfCompleted / ReportData?.length) * 100 : 0)
        + "% Completed", Math.round(ReportData?.length > 0 ? (ToatalOfInprogress / ReportData?.length) * 100 : 0)
      + "% In Progress", Math.round(ReportData?.length > 0 ? (YetToStart / ReportData?.length) * 100 : 0) + "% Yet to Start"],
      datasets: [
        {
          data: [ToatalOfCompleted, ToatalOfInprogress, YetToStart],
          backgroundColor: ["green", "orange", "red"],
          hoverOffset: 4,
        },
      ],
    };
    return Completion;
  }, [Data?.pGetCourseProgressReportData])

  const DoughnutOptions2 = {
    responsive: false,
    elements: {
      arc: {
        borderWidth: 0,
      },
    },
    plugins: {
      legend: {
        position: "right",
        display: true,
        labels: {
          padding: 25,
          boxWidth: 50,
          usePointStyle: true,
          font: {
            family: "Montserrat, sans-serif",
            size: 12,
          },
        },
      },
    },
    cutout: "80%",
    maintainAspectRatio: false,
  };
  //

  const GetCompletedStatus = useMemo(() => {
    return [
      { value: "", text: "Filter by Status" },
      { value: "Completed", text: "Completed" },
      { value: "Inprogress", text: "InProgress" },
      { value: "Yet to start", text: "Yet to start" },
    ]
  }, [])

  return (
    <>
      <Container title="Course Progress" loader={Data?.pGetCourseProgressReportData == undefined ? true : false} PageRoutes={PageRoutes}>
        <form onSubmit={handleSubmit(submitHandler)} className={`${watch("submit") || watch("download") || watch("fetch") ? "px-2 pointer-events-none" : "px-2"}`}>
          <div className="px-3" id="divFilter">
            <div className="block rounded-lg ">
              <div className="py-3 pb-4">
                <div className="bg-[#F9FAFC] w-full shadow flex justify-start p-4">
                  {/* Doughnut chart */}
                  <div className="grid-cols-12 grid-flow-col gap-4 pt-4">
                    <NVLSettingsCard outerclass=" rounded-md px-4 w-full relative p-2 md:p-0">
                      <Doughnut data={CourseCompletion} options={DoughnutOptions2} class="DoughnutClass" />
                      <div className="absolute top-6 left-4 md:top-8 md:left-7 text-center text-xs font-semibold p-6 rounded-full">
                        <div>{refRecordStatus.current == undefined || refRecordStatus.current == "NoRecord" ? "0" : Object.values(refCourseCount.current)?.length}</div>
                        <div>{refRecordStatus.current == undefined || refRecordStatus.current == "NoRecord" || (refRecordStatus.current == "Exists" && Object.values(refCourseCount.current)?.length == 1) ? "Course" : "Courses"}</div>
                      </div>
                    </NVLSettingsCard>
                  </div>
                </div>
                <div className="grid grid-cols-12 grid-flow-col gap-4 pt-4">
                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1">
                      Course Name
                    </NVLlabel>
                    <NVLSelectField id="ddlCourse" errors={errors} options={FilterDropdownData.Course} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
                  </div>
                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="Department" className="block text-sm font-medium text-gray-600 py-1">
                      Status
                    </NVLlabel>
                    <NVLSelectField id="ddlStatus" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={GetCompletedStatus} errors={errors} />
                  </div>
                  <div className="col-span-6 sm:col-span-3 invisible"></div>
                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="User-Name" className="block text-sm font-medium text-gray-600 py-1">
                      Search by Course Name
                    </NVLlabel>
                    <NVLTextbox id="txtsearch" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by course name" />
                  </div>
                  <div className="col-span-6 sm:col-span-3 pt-6">
                    <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""}
                      disabled={watch("submit") || watch("fetch") || watch("download") ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-primary  text-white !h-10" : "w-28 nvl-button !bg-primary  text-white !h-10"}>
                      {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                    </NVLButton>
                  </div>
                  <div className="col-span-6 sm:col-span-3 pt-6">
                    <div className="flex items-center">
                      <NVLButton id="btnDownload" disabled={(watch("submit") || watch("download") || watch("fetch")) || refRecordStatus.current == undefined || refRecordStatus.current == "NoRecord" ? true : false} type={"button"}
                        className={refRecordStatus.current == undefined || refRecordStatus.current == "NoRecord" ? "nvl-button Disabled bg-primary !h-10" : watch("download") ? "nvl-button !bg-primary  text-white !h-10" : "nvl-button !bg-primary  text-white !h-10"}
                        onClick={(e) => FileDownload(e)}>
                        <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                      </NVLButton>

                      <div className="pb-2 pl-2 ">
                        <NVLlabel
                          CustomCss="-translate-x-72 pt-4"
                          className="nvl-Def-Label pb-1"
                          HelpInfo={"Additional report details can be downloaded here"}
                          HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {!watch("fetch") && <div className="pb-8">
            <NVLGridTable id="tblEnrollList" className="max-w-full"
              HeaderColumn={HeaderColumn}
              RowGridDataPass={{ RowGrid: refRecordStatus.current == undefined || refRecordStatus.current == "NoRecord" ? [] : GridDataBind() }} />
          </div>}
          <div>
            {watch("fetch") && <NVLLoadingSpinner />}
          </div>
        </form>
      </Container>
    </>
  )
}

export default CourseProgressReport
