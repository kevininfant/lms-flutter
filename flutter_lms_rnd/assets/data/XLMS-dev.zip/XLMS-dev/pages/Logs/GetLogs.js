import { useState, useMemo } from "react";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import Container from "@components/Container/Container";
import NVLLoadingIndicator from "@components/Controls/NVLLoadingIndicator";
import NVLGridTable from "@components/Controls/NVLGridTable";

export default function GetLogs() {
  const Logs = [];
  const [IsLoad, setIsLoad] = useState(false);
  const [IsDisabled, setIsDisabled] = useState(true);
  const [RowGridData, setRowGridData] = useState([]);

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  async function getQueryValues(res) {
    await sleep(3000);
    await fetch(`${process.env.APIGATEWAY_URL_FETCHLOGSUSEQUERY}?QueryId=${res}`, Headers)
      .then((queryResponse) => {
        sleep(5000);
        return queryResponse.json();
      })
      .then((res) => {
        Logs.push(res);
        let RowGrid = [];
        if (Logs.length > 0 && Logs != null) {
          Logs.forEach((element) => {
            element.forEach((element2) => {
              element2.forEach((element3, index) => {
                RowGrid.push({
                  ID: index,
                  Field: element3.Field,
                  Value: element3.Value,
                });
              });
            });
          });
          setRowGridData({ RowGrid });
        }
        setIsLoad(false);
      })
      .catch((error) => {
        setIsLoad(false);
        /* Errorlog */
      });
  }
  const GetLogsInfo = async (e) => {
    e.preventDefault();
    setIsDisabled(false);
    let TraceID = document.getElementById("txtGetLogs").value;

    const Headers = {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    };

    await fetch(`${process.env.APIGATEWAY_URL_GETQUERYIDFORMATETRACEID}?traceid=${TraceID}`, Headers)
      .then((response) => {
        setIsLoad(true);
        return response.text();
      })
      .then((res) => {
        getQueryValues(res);
      })
      .catch((error) => {} /* Errorlog */);
  };
  const HeaderColumn = [
    { HeaderName: "Field", Columnvalue: "Field" },
    { HeaderName: "Value", Columnvalue: "Value" },
  ];

  useMemo(() => {
    RowGridData.RowGrid;
  }, [RowGridData.RowGrid]);

  return (
    <>
      <Container>
        <form onSubmit={(e) => SubmitHandler(e)}>
          <div className="xl:grid grid-cols-6 gap-4 md:px-36 lg:px-64 overflow-hidden">
            <div className="Center-Aligned-Items">
              <NVLTextbox onChange={() => {}} id="txtGetLogs" placeholder="Enter the Trace id" required={true}></NVLTextbox>
              <br></br>
              <div>
                <NVLButton ButtonType={"success"} onClick={(e) => GetLogsInfo(e)} text={"Get Query Values"} type={"submit"}></NVLButton>
              </div>
              <br></br>
              <NVLLoadingIndicator IsLoad={IsLoad} AlignLoader={"center"} />
              <br></br>
            </div>
            <br />
          </div>
          <div className="wpx-2 overflow-hidden flex-wrap hidden">
            <NVLlabel text={`Logs:`} className="text-red-600" />
            <small>{Logs}</small>
          </div>

          <section>{RowGridData.RowGrid != null ? <NVLGridTable HeaderColumn={HeaderColumn} RowGridData={RowGridData} /> : ""}</section>
        </form>
      </Container>
    </>
  );
}
