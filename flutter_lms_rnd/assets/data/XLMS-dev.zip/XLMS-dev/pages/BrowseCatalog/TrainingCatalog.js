import Container from '@components/Container/Container';
import NVLAlert, { ModalOpen } from '@components/Controls/NVLAlert';
import NVLBreadCrumbs from '@components/Controls/NVLBreadCrumbs';
import NVLButton from '@components/Controls/NVLButton';
import NVLImage from '@components/Controls/NVLImage';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLPageModalPopup from '@components/Controls/NVLPageModalPopup';
import NVLRadio from '@components/Controls/NVLRadio';
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from 'aws-amplify';
import { APIGatewayPostRequest, AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { createXlmsBatchTrainingManagement, createXlmsTrainingSelfEnrollUserBatch } from 'src/graphql/mutations';
import { getXlmsUserInfo, listXlmsTrainingManagement, listXlmsTrainingSelfEnrollUserInfos } from 'src/graphql/queries';
import * as Yup from "yup";

function TrainingCatalog(props) {

  const router = useRouter();
  const TenantId = useMemo(() => { return props.TenantInfo.TenantID }, [props.TenantInfo.TenantID])
  const PageUserSub = useMemo(() => { return props.user.attributes["sub"] }, [props.user.attributes])
  const [getIndex, setIndex] = useState()
  const GetAscendingOrder = useCallback((SortingTrainingData) => {
    SortingTrainingData?.sort(function (a, b) {
      if (new Date(a.LastModifiedDate) > new Date(b.LastModifiedDate)) {
        return -1;
      }
      if (new Date(a.LastModifiedDate) < new Date(b.LastModifiedDate)) {
        return 1;
      }
      return 0;
    });
    return SortingTrainingData;
  }, [])

  const [trainingDetails, setTrainingDetails] = useState()
  const [TrainingData, setTrainingData] = useState(trainingDetails?.TrainingData)

  useEffect(() => {
    async function TrainingFetch() {
      setValue("rbType", "All");
      setValue("submit", false)
      let enrollData = await AppsyncDBconnection(listXlmsTrainingSelfEnrollUserInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "SELFENROLLUSER#TRAINING#" }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      let trainingDataList = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + TenantId, SK: "TRAININGINFO#LASTMODIFIEDDATE#", TrainingType: "Suspend", IsSuspend: false, IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let userDetails = await AppsyncDBconnection(getXlmsUserInfo, { PK: "TENANT#" + TenantId, SK: "#USERINFO#" + Auth?.user?.attributes["sub"], IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)

      setTrainingDetails({
        TrainingData: trainingDataList?.res?.listXlmsTrainingManagement?.items,
        UserDetails: userDetails?.res?.getXlmsUserInfo != undefined ? userDetails?.res?.getXlmsUserInfo : [],
        EnrollData: enrollData?.res?.listXlmsTrainingSelfEnrollUserInfos?.items != undefined ? enrollData?.res?.listXlmsTrainingSelfEnrollUserInfos?.items : []
      })
      setTrainingData(GetAscendingOrder(trainingDataList?.res?.listXlmsTrainingManagement?.items))
    }
    TrainingFetch()
    return (() => {
      setTrainingDetails((temp) => { return { ...temp } })
    })
  }, [GetAscendingOrder, PageUserSub, TenantId, props.TenantInfo.TenantID, props?.user.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue])

  const validationSchema = Yup.object().shape(
    {
      ddlFilter: Yup.string().test("", "", (e) => {
        if (e != "") {
          TrainingData && TrainingData.sort(function (a, b) {
            return new Date(b.CreatedDate) - new Date(a.CreatedDate);
          });
        } else {
          return TrainingData
        }
      })
    })
  const [popupValues, setPopupValues] = useState({});
  const refSearchTraining = useRef("");
  const refSearchResult = useRef("");
  const [open, setOpen] = useState(false);
  const [trainingPopUpDetails, setTrainingPopUpDetails] = useState();
  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Your Training Nomination accepted  once approved you may accessing the Training content.",
  };
  const [modalValues, setModalValues] = useState(initialModalState);

  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: true,
  };

  const { register, watch, formState, reset, setValue } = useForm(formOptions);
  const { errors } = formState;

  const ResetPopUp = useCallback((mode) => {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    if (mode == "Submit") { router.push("/BrowseCatalog/TrainingCatalog") };

  }, [router])

  const FinalResponse = useCallback((FinalStatus) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
        ModalOnClickEvent: () => ResetPopUp("Submit")
      });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Success",
        ModalTopMessage: FinalStatus,
        ModalBottomMessage: "Your Training Nomination accepted  once approved you may accessing the Training",
        ModalOnClickEvent: () => ResetPopUp("Submit")
      });
      ModalOpen();
    }
  }, [ResetPopUp])

  const SearchTrainingHandler = useCallback(() => {
    reset();
    setValue("rbType", "All");
    if (refSearchTraining?.current?.value == "") {
      refSearchResult.current.value = "";
      setTrainingData(trainingDetails?.TrainingData)
    } else {
      let trainingFilterData = trainingDetails?.TrainingData?.filter((Training) => {
        return Training.TrainingName.toLowerCase().includes(refSearchTraining?.current.value?.toLowerCase());
      })
      let trainingFilterDataLength = Object.values(trainingFilterData)?.length;
      refSearchResult.current.value = trainingFilterDataLength == 0 ? "We were not able to find the Training you're looking for." : "Search Results Found (" + trainingFilterDataLength + ")";
      setTrainingData(trainingFilterData)
    }
  }, [reset, setValue, trainingDetails?.TrainingData])

  const filterByDate = useCallback(() => {
    async function fetchDate() {
      if (watch("txtFromDate") != "" || watch("txtToDate") != "") {
        let trainingType = (watch("txtFromDate") == "" && watch("txtToDate") == "") ? "" : (watch("txtFromDate") != "" && watch("txtToDate") != "") ? "Custom" : watch("txtFromDate") != "" ? "FromDate" : (watch("txtToDate") != "") ? "ToDate" : "";
        let filterDate, trainingData = [];
        if (trainingType == "Custom") {
          filterDate = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + TenantId, SK: "TRAININGINFO#LASTMODIFIEDDATE#", IsSuspend: false, IsDeleted: false, FromDate: watch("txtFromDate"), ToDate: watch("txtToDate"), TrainingType: trainingType }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        } else if (trainingType == "ToDate") {
          filterDate = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + TenantId, SK: "TRAININGINFO#LASTMODIFIEDDATE#", IsSuspend: false, IsDeleted: false, ToDate: watch("txtToDate"), TrainingType: trainingType }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        } else if (trainingType == "FromDate") {
          filterDate = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + TenantId, SK: "TRAININGINFO#LASTMODIFIEDDATE#", IsSuspend: false, IsDeleted: false, FromDate: watch("txtFromDate"), TrainingType: trainingType }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        }

        if (watch("rbType") && watch("rbType") != "All") {
          filterDate?.res?.listXlmsTrainingManagement?.items?.map((item) => {
            if ((item?.TrainingType?.includes(watch("rbType")))) {
              trainingData.push(item)
            }
          })
          refSearchResult.current.value = trainingData?.length == 0 || trainingData?.length == undefined ? "We were not able to find the Training you're looking for." : "Search Results Found (" + trainingData?.length + ")";
          setTrainingData(trainingData)
        }

        if (!watch("rbType") || watch("rbType") == "All") {
          refSearchResult.current.value = filterDate?.res?.listXlmsTrainingManagement?.items?.length == 0 || filterDate?.res?.listXlmsTrainingManagement?.items?.length == undefined ? "We were not able to find the Training you're looking for." : "Search Results Found (" + filterDate?.res?.listXlmsTrainingManagement?.items?.length + ")";
          setTrainingData(filterDate?.res?.listXlmsTrainingManagement?.items)
        }
      }
    } fetchDate()
  }, [TenantId, props?.user?.signInUserSession?.accessToken?.jwtToken, watch])

  const FilterTrainingHandler = useCallback((ProgramType) => {
    async function TrainingData() {
      setValue("txtFromDate", "")
      setValue("txtToDate", "")
      setTrainingData([]);
      let trainingData
      if (ProgramType == "All") {
        trainingData = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + TenantId, SK: "TRAININGINFO#LASTMODIFIEDDATE#", TrainingType: "Suspend", IsSuspend: false, IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      } else {
        trainingData = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + TenantId, SK: "TRAININGINFO#LASTMODIFIEDDATE#", TrainingType: "ProgramType", ProgramType: ProgramType, IsSuspend: false, IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      }
      refSearchResult.current.value = trainingData?.res?.listXlmsTrainingManagement?.items?.length == 0 || trainingData?.res?.listXlmsTrainingManagement?.items?.length == undefined ? "We were not able to find the Training you're looking for." : "Search Results Found (" + trainingData?.res?.listXlmsTrainingManagement?.items?.length + ")";
      setTrainingData(trainingData?.res?.listXlmsTrainingManagement?.items)
    } TrainingData()
  }, [TenantId, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue], [trainingDetails?.TrainingData])

  const getTrainingCount = useCallback(() => {
    if (TrainingData != undefined) {
      let trainingCount = TrainingData?.filter((Training) => {
        return !Training?.IsSuspend
      })
      let trainingFinalCount = Object.values(trainingCount)?.length;
      return trainingFinalCount
    }
    else {
      return 0;
    }
  }, [TrainingData])

  const setTime = useCallback((Time) => {
    let date = new Date(Time)?.getHours() >= 10 ? new Date(Time)?.getHours() : "0" + new Date(Time)?.getHours()
    let minute = new Date(Time).getMinutes() >= 10 ? new Date(Time).getMinutes() : "0" + new Date(Time).getMinutes()
    return date + ":" + minute
  }, [])

  const selfEnroll = useCallback(async (Training) => {
    setValue("submit", true)
    if (!Training?.IsManagerApproval) {
      let fetchURL = process.env.APIGATEWAY_URL_TRAINING_ENROLL_UPLOADUSER;
      const finalData = [];
      finalData.push(
        Auth?.user?.attributes["sub"],
      );

      let JsonInputData = '{ "NotificationSub":"","TrainingID":"' + Training?.TrainingID + '","CreatedBy":"","CreatedDate":"","LastModifiedBy":"","LastModifiedDate":"","Type":"User","TenantID":"' + props?.TenantInfo.TenantID + '","UserDetails":' + JSON.stringify(finalData) + "}"

      let Headers = {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
          defaultrole: props?.TenantInfo.UserGroup,
          groupmenuname: "TrainingManagement",
          menuid: "400102",
          stateMachineArn: process.env.STEP_FUNCTION_ARN_TRAINING_ENROLL_UPLOADUSER,
        },
        body: JsonInputData,
      };
      let FinalStatus = await APIGatewayPostRequest(fetchURL, Headers);
      let Variables = {
        input: [{
          PK: "TENANT#" + props?.TenantInfo.TenantID,
          SK: "SELFENROLLUSER#TRAINING#" + Training?.TrainingID + "#USER#" + Auth?.user?.attributes["sub"],
          // ReportManagerEmail: trainingDetails?.UserDetails?.ReportManagerEmail.toLowerCase(),
          UserSub: Auth?.user?.attributes["sub"],
          UserName: Auth?.user?.username,
          EmailID: Auth?.user?.attributes["email"],
          UserName: props.user?.username,
          FirstName: trainingDetails?.UserDetails?.FirstName,
          LastName: trainingDetails?.UserDetails?.LastName,
          TrainingID: Training?.TrainingID,
          TrainingName: Training?.TrainingName,
          StatusFlag: "Approved",
          LastModifiedBy: Auth?.user?.username,
          LastModifiedDate: new Date()
        }]
      }
      await AppsyncDBconnection(createXlmsTrainingSelfEnrollUserBatch, Variables, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let trainingVariables = {
        input: [{
          ...Training,
          SK: "TRAININGINFO#" + Training?.TrainingID,
          IsSelfEnrolled: true
        }, {
          ...Training,
          IsSelfEnrolled: true
        }
        ]
      }
      FinalStatus = await AppsyncDBconnection(createXlmsBatchTrainingManagement, trainingVariables, props?.user?.signInUserSession?.accessToken?.jwtToken);
      FinalResponse(FinalStatus?.Status)
      setValue("submit", false)
    }
    else {
      let Variables = {
        input: [{
          PK: "TENANT#" + props?.TenantInfo.TenantID,
          SK: "SELFENROLLUSER#TRAINING#" + Training?.TrainingID + "#USER#" + Auth?.user?.attributes["sub"],
          ReportManagerEmail: trainingDetails?.UserDetails?.ReportManagerEmail.toLowerCase(),
          UserSub: Auth?.user?.attributes["sub"],
          UserName: Auth?.user?.username,
          EmailID: Auth?.user?.attributes["email"],
          UserName: props.user?.username,
          FirstName: trainingDetails?.UserDetails?.FirstName,
          LastName: trainingDetails?.UserDetails?.LastName,
          TrainingID: Training?.TrainingID,
          TrainingName: Training?.TrainingName,
          StatusFlag: "Pending",
          LastModifiedBy: Auth?.user?.username,
          LastModifiedDate: new Date()
        }]
      }
      let FinalStatus = await AppsyncDBconnection(createXlmsTrainingSelfEnrollUserBatch, Variables, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const enrollCount = Training?.EnrollCount != undefined || Training?.EnrollCount != null || Training?.EnrollCount != 0 ? Training?.EnrollCount + 1 : 1
      let trainingVariables = {
        input: [{
          ...Training,
          SK: "TRAININGINFO#" + Training?.TrainingID,
          EnrollCount: enrollCount,
          IsSelfEnrolled: true
        }, {
          ...Training,
          EnrollCount: enrollCount,
          IsSelfEnrolled: true
        }
        ]
      }
      FinalStatus = await AppsyncDBconnection(createXlmsBatchTrainingManagement, trainingVariables, props?.user?.signInUserSession?.accessToken?.jwtToken);
      FinalResponse(FinalStatus.Status);
      setValue("submit", false)
    }
  }, [FinalResponse, props?.TenantInfo.TenantID, props?.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, props.user?.username, setValue, trainingDetails?.UserDetails?.FirstName, trainingDetails?.UserDetails?.LastName, trainingDetails?.UserDetails?.ReportManagerEmail])

  const getTrainingDetails = useCallback((Training) => {
    return (
      <>
        <form >
          <div className="flex justify-between ">
            <div className="flex">
              <div className={`modal-header px-8 text-center overflow-y-auto max-h-[80vh]`}>
                <div className="gap-4 ">
                  <NVLlabel className="nvl-Def-Label w-30" text={`Program Name : ${trainingPopUpDetails?.TrainingName}`}></NVLlabel>
                  <NVLlabel className="nvl-Def-Label w-30" text={`Trainer Name : ${trainingPopUpDetails?.TrainerName}`}></NVLlabel>
                  <NVLlabel className="nvl-Def-Label w-76" showFull text={`StartDate : ${new Date(trainingPopUpDetails?.StartDate)?.getDate() + "-" + (new Date(trainingPopUpDetails?.StartDate)?.getMonth() + 1) + "-" + new Date(trainingPopUpDetails?.StartDate)?.getFullYear()} StartTime : ${setTime(trainingPopUpDetails?.StartDate)}`}></NVLlabel>
                  <NVLlabel className="nvl-Def-Label w-76" showFull text={`EndDate : ${new Date(trainingPopUpDetails?.EndDate)?.getDate() + "-" + (new Date(trainingPopUpDetails?.EndDate)?.getMonth() + 1) + "-" + new Date(trainingPopUpDetails?.EndDate)?.getFullYear()} EndTime : ${setTime(trainingPopUpDetails?.EndDate)}`}></NVLlabel>
                </div>
              </div>
            </div>
          </div>
        </form>
      </>
    )
  }, [setTime, trainingPopUpDetails?.EndDate, trainingPopUpDetails?.StartDate, trainingPopUpDetails?.TrainerName, trainingPopUpDetails?.TrainingName])
  // function resetPopUp() {
  //   setPopupValues({ ProgramName: "", SK: "", Content: "", Type: "" });
  //   document.getElementById("tableSearch") && document.getElementById("tableSearch").value == "";
  // }

  const Popup = useCallback(async (Training) => {
    setValue("rbType", watch("rbType"));
    setValue("txtFromDate", "");
    setValue("txtToDate", "");
    setTrainingPopUpDetails(Training)
    setOpen((open) => {
      return !open;
    });
  }, [setValue, watch])

  // Bread Crumbs
  let PageRoutes = [
    {
      path: "",
      breadcrumb: "Training Catalog"
    },
  ];
  const [openTrainingBar, setOpenTrainingBar] = useState(false)
  const [trainingCount, setTrainingCount] = useState(9);
  const setCount = useCallback(() => {
    if (!(TrainingData?.length < trainingCount)) {
      setTrainingCount((prevCount) => prevCount + 8)
    }
    else {
      setTrainingCount(9)
    }
  }, [TrainingData?.length, trainingCount])
  const GetEnrollComp = useCallback(({ Training, index }) => {
    let statusFlag;
    function getApprovaldata() {
      if (Training?.TrainingType == "Open" && Training?.StartDate >= new Date().toISOString().substring(0, 16)) {
        trainingDetails?.EnrollData && trainingDetails?.EnrollData.some(
          (data) => {
            (data?.TrainingID == Training.TrainingID && data.UserSub == props?.user.attributes["sub"]) ? statusFlag = data?.StatusFlag : "";
          }
        );
      }
    }
    // fa-circle-notch fa-spin
    getApprovaldata()
    return (
      <>
        <div className="flex justify-between ">
          <div className="flex">
            {(statusFlag == undefined) ?
              <NVLButton id={"btnEnroll" + index} text={(watch("submit") && getIndex == "btnEnroll" + index) ? "" : "Enroll"} disabled={((Training?.TrainingType == "Open" && Training?.StartDate >= new Date().toISOString().substring(0, 16)) && ((Training?.WaitingList + Training?.BatchSize) != Training?.EnrollCount)) && watch("submit") == false ? false : true}
                className={` !rounded-full px-2 !text-[10px] py-1 !h-8 w-20 ${(Training?.TrainingType == "Open" && Training?.StartDate >= new Date().toISOString().substring(0, 16)) && (((Training?.WaitingList + Training?.BatchSize) != Training?.EnrollCount)) ? "nvl-button bg-primary text-white" : "invisible cursor-not-allowed nvl-button text-gray-500"}`}
                onClick={() => { selfEnroll(Training); setIndex("btnEnroll" + index) }}
              >{(watch("submit") && getIndex == "btnEnroll" + index) && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
              : (Training?.TrainingType == "Open" && Training?.StartDate >= new Date().toISOString().substring(0, 16)) ? statusFlag == "Approved" ?
                <div className="{invalid-feedback} text-green-500 text-sm pt-2"> {statusFlag} </div> : statusFlag == "Waiting" ? <div className="{invalid-feedback} text-yellow-500 text-sm pt-2"> {statusFlag} </div> : <div className="{invalid-feedback} text-red-500 text-sm pt-2"> {statusFlag} </div> : ""
            }
          </div>
        </div>
      </>
    );
  }, [getIndex, props?.user.attributes, selfEnroll, trainingDetails?.EnrollData, watch]);


  return (
    <>
      <Container title={"TrainingCatalog"} loader={TrainingData == undefined}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <NVLBreadCrumbs Routes={PageRoutes}></NVLBreadCrumbs>
        <NVLPageModalPopup ModalType="Page" CustomWidth="md:w-[500px]" ScreenName={`Training Details`} PageComponent={getTrainingDetails()} open={open} setOpen={setOpen} />
        <div className='lg:flex gap-4'>
          <main className=" w-full space-y-4">
            <div className='h-10 bg-slate-50 '>
              <div className="p-2 bg-[#f9fafc] flex justify-between">
                <div className='w-56 relative'>
                  <input id="txtSearchTraining" ref={refSearchTraining} className="nvl-Dash-input !w-full !text-xs " type="search" name="search" placeholder="Search By TrainingName" onChange={(e) => SearchTrainingHandler(e)} />
                  <button type="submit" className="absolute -right-4 bottom-2 ">
                    <i className="fa-solid fa-magnifying-glass h-4 w-4 absolute -bottom-0.5 right-6 text-gray-400" onClick={(e) => SearchTrainingHandler(e)}></i>
                  </button>
                </div>
                <div>
                  <span className='text-xs px-2 font-semibold text-slate-600 ' id="lblResults" ref={refSearchResult}>{refSearchResult?.current?.value}</span>
                  {!refSearchResult?.current?.value && <span className='text-xs px-2 text-gray-700 font-semibold my-auto'>Total Number Of Program : {getTrainingCount()}
                  </span>
                  }</div>
              </div>
            </div>
            <span className="flex items-center space-x-2">
              {TrainingData && <div className={`grid grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 ${!openTrainingBar ? " xl:grid-cols-3" : " xl:grid-cols-4"} gap-6 w-full  p-2`}>
                {TrainingData.map((Training, index) => {
                  return (
                    <div key={crypto.randomUUID()} className={`bg-white rounded overflow-hidden shadow-lg hover:-translate-y-1 hover:shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] ease-in duration-150 cursor-pointer ${(index > trainingCount) ? "hidden" : ""}`}>
                      <div className='!h-28 relative overflow-hidden group'>
                        <NVLImage className="hover:bg-blend-saturation h-full w-full hover:scale-110 duration-500" src={"/CourseDefaultImage.jpg"} alt="Training" />
                        <div className="bg-[rgba(0,0,0,0.34)] text-white absolute -top-[100%] h-[100%] w-[100%] ease-in duration-300 group-hover:top-0 text-center text-xs p-2">
                          <NVLButton text="View" className={`nvl-button bg-primary text-white !rounded-full mt-8`} onClick={() => Popup(Training)} />
                        </div>
                      </div>
                      <div className="p-2">
                        <NVLlabel showFull={true} className="text-slate-700 font-bold text-tiny cursor-pointer !break-all" text={Training.TrainingName}>
                        </NVLlabel>
                        <div>
                          <div className='w-full bg-slate-100 flex justify-center my-2'><div className='w-8 h-1 bg-primary rounded-full'></div></div>
                          <div className="flex justify-between text-gray-600">
                            <div className='gap-4 text-xl flex justify-between my-auto'>
                              <i className="fa fa-id-card text-slate-700 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-slate-100" aria-hidden="true" title='Certificate'></i>
                              <i className="fa-sharp fa-solid fa-ribbon  text-slate-700 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-slate-100" aria-hidden="true" title='Badge'></i>
                            </div>
                            <GetEnrollComp Training={Training} index={index} />
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })
                }
              </div>
              }
            </span>
            <div className='absolute cursor-pointer '>
              {TrainingData && Object.values(TrainingData)?.length > 9 && <span className="text-amber-900" onClick={(e) => setCount(e)}>
                {`${TrainingData?.length < trainingCount ? "Less Training" : "More Training"}`}
              </span>}
            </div>
          </main>

          <div className={` ${!openTrainingBar && "absolute right-2 "}`}>
            <button onClick={() => setOpenTrainingBar(!openTrainingBar)} type="button" className={`${openTrainingBar ? "  bg-primary text-white shadow-md duration-300 " :
              " bg-transparent to-blue-50 duration-300"} float-right left-4 py-2 h-10 w-10 rounded-full  border-gray-200  px-3  text-lg`}>
              {openTrainingBar ? <i className="fa-solid fa-angles-left  content-center"></i> : <i className="fa fa-solid fa-angles-right relative p-1 text-gray-800"></i>}
            </button>
          </div>
          <div className={` ${openTrainingBar ? "hidden " : "block"} lg:w-[25%] flex flex-col bg-red-20 text-xs duration-700 shadow-[rgba(17,_17,_26,_0.1)_0px_0px_16px]`}>
            <nav className="  w-full ">
              <div className=" w-full">
                {/* TrainingFilter */}
                <div className="space-y-3 min-h-screen max-h-min">
                  <div className="bg-[#f9fafc]  p-3">
                    <NVLlabel text="Search by Training Details"
                      className="font-semibold !text-sm text-gray-700" />
                  </div>
                  <ul className="space-y-2 p-2 bg-[#f9fafc] ">
                    <li>
                      <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                        <span className="items-center space-x-2">
                          <details className='pl-2'>
                            <summary className={"text-blue-600"}><span className='text-gray-700'>Filter By Program Type</span></summary>
                            <div className="px-10">
                              <NVLRadio
                                id="rbType"
                                type="radio"
                                errors={errors}
                                register={register}
                                text="All"
                                name="rbType"
                                value={"All"}
                                onClick={() => FilterTrainingHandler("All")}
                              />
                              <NVLRadio
                                id="rbType"
                                type="radio"
                                errors={errors}
                                register={register}
                                text="Open"
                                name="rbType"
                                value={"Open"}
                                onClick={() => FilterTrainingHandler("Open")}
                              />
                              <NVLRadio
                                id="rbType"
                                type="radio"
                                errors={errors}
                                register={register}
                                text="Mandatory"
                                name="rbType"
                                value={"Mandatory"}
                                onClick={() => FilterTrainingHandler("Mandatory")}
                              />
                            </div>
                          </details>
                        </span>
                      </a>
                    </li>
                    <li>
                      <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                        <span className="flex items-center space-x-2">
                          <details className='pl-2'>
                            <summary className="text-blue-600"><span className='text-gray-700'>Filter By Date</span></summary>
                            <div key={crypto.randomUUID()}>
                              <ul className='pt-2 pb-2 pl-3'>
                                <li>
                                  <div className="flex pb-2">
                                    <div className="pt-1">
                                      <div className="pb-1">
                                        <NVLlabel text="From" className="font-semibold text-gray-500"></NVLlabel>
                                      </div>
                                      <NVLTextbox
                                        id="txtFromDate"
                                        title="From Date"
                                        type="datetime-local"
                                        className="w-48 nvl-button pl-4"
                                        errors={errors}
                                        register={register}
                                      />
                                    </div>
                                  </div>
                                  <div className="flex ">
                                    <div className="pt-1">
                                      <div className="pb-1">
                                        <NVLlabel text="To" className="font-semibold text-gray-500"></NVLlabel>
                                      </div>
                                      <NVLTextbox
                                        id="txtToDate"
                                        title="To Date"
                                        type="datetime-local"
                                        className="w-48 nvl-button pl-4"
                                        errors={errors}
                                        register={register}
                                      />
                                    </div>
                                  </div>
                                  <div className="flex ">
                                    <div className="pt-1">
                                      <NVLButton
                                        id="btnFilter"
                                        text="Filter"
                                        className="w-24 nvl-button  bg-primary text-white !rounded-full mt-2"
                                        errors={errors}
                                        register={register}
                                        onClick={() => filterByDate()}
                                      />
                                    </div>
                                  </div>
                                </li>
                              </ul>
                            </div>
                          </details>
                        </span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </nav>
          </div>
        </div>
      </Container>
    </>
  )
}

export default TrainingCatalog
