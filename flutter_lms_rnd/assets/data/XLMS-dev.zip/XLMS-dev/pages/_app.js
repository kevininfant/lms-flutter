import "@aws-amplify/ui-react/styles.css";
import Container from "@components/Container/Container";
import "@components/Controls/NVLi18nextInit";
import IdleTimeOutHandler from "@components/Controls/NVLIdleTimeout";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingIndicator";
import NVLWebWorkerLogin from "@components/Controls/NVLWebWorkerLogin";
import NVLWelcomeInfoPopup from "@components/Controls/NVLWelcomeInfoPopup";
import DashLayout from "@Dashboard/DashLayout";
import awsconfig from "@graphql/aws-exports";
import Login from "@Home/Login";
import "@styles/globals.css";
import "@styles/theme.css";
import { Amplify, Auth, Hub } from "aws-amplify";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { ThemeProvider } from "next-themes";
import { useRouter } from "next/router";
import { createContext, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { getXlmsTenantBranding, getXlmsTenantInfo, getXlmsUserInfo, listXlmsGrpMenuBinding, listXlmsPopUpInfo, listXLMSRoleFeatureConfigs, listXlmsRolesAndPermissions, listXlmsTenantGrpMenuBinding } from "src/graphql/queries";
import SignInFooter from "./Home/SignInFooter";
import WebView from "./WebView/WebView";

Amplify.configure({ ...awsconfig, ssr: false });


const components = {
  SignIn: {
    Footer: SignInFooter,
  },
};

const App = function ({ Component, pageProps }) {
  const page = useRef();
  const [amplify, setAmplify] = useState();
  let timer = useRef();
  let userprofileName = useRef();
  const user = useRef();
  const router = useRouter();
  const [menu, setMenu] = useState([]);
  const RoleData = useRef([])
  const RoleDataJson = useRef({})
  const currentUser = useRef(undefined);
  const TenantInfo = useRef({});
  const Refersh = useRef(true)
  const isLogo = useRef(true)
  const logoPath = useRef();
  const changeRef = useRef(false);
  const check = useRef(1);
  const [isLoder, setLoder] = useState(false)
  const notificationPK = useRef();
  const ReduceNewData = useRef();
  const loginMechanisms = useRef({ signIn: { username: { labelHidden: true, isRequired: true, autocomplete: "off", }, password: { labelHidden: true, isRequired: true, autocomplete: "new-password", }, }, forceNewPassword: { password: { placeholder: 'New Password', }, }, });
  const ReduceNewDataFunction = useCallback((data) => {
    ReduceNewData.current = data;
  }, [])
  useEffect(() => {
    const handleRouteChange = (url) => {
      changeRef.current = true;
      setLoder(true);
    }
    const handleRouteComplete = (url) => {
      changeRef.current = false;
      setLoder(false);
    }
    router.events.on('routeChangeStart', handleRouteChange)
    router.events.on('routeChangeComplete', handleRouteComplete)
  }, [setLoder, router])

  useEffect(() => {
    RoleData.current.map((temp) => {
      if (temp.ActionURL == router.pathname && !temp.ActionAllow) {
        router.push("/")
      }
    })
  }, [router])

  const existingDataHandler = useCallback(async (UserGroup, PlanCode, StartDate, TenantID, ShardKey, user) => {
    let PK = 'ROLE#' + UserGroup, SK = "GrpMenu#";
    if (TenantID != "" && (ShardKey != null || undefined)) {
      PK = "TENANT#" + TenantID + "#PLAN#" + PlanCode + "#STARTDATE#" + StartDate + "#" + ShardKey;
      SK = "ROLE#" + UserGroup;
    }
    else if (TenantID != "" && ShardKey == undefined) {
      PK = "TENANT#" + TenantID + "#PLAN#" + PlanCode + "#STARTDATE#" + StartDate;
      SK = "ROLE#" + UserGroup;
    }
    let ExistingData = await AppsyncDBconnection(TenantID != "" ? listXlmsRolesAndPermissions : listXLMSRoleFeatureConfigs, { PK: PK, SK: SK }, user?.signInUserSession?.accessToken?.jwtToken);
    if (ExistingData.res?.[TenantID != "" ? "listXlmsRolesAndPermissions" : "listXLMSRoleFeatureConfigs"]?.items != undefined && ExistingData.res?.[TenantID != "" ? "listXlmsRolesAndPermissions" : "listXLMSRoleFeatureConfigs"]?.items.length != 0) {
      RoleData.current = ExistingData.res?.[TenantID != "" ? "listXlmsRolesAndPermissions" : "listXLMSRoleFeatureConfigs"]?.items
      let temparray = ExistingData.res?.[TenantID != "" ? "listXlmsRolesAndPermissions" : "listXLMSRoleFeatureConfigs"]?.items;
      let tempJSON = {};
      temparray.forEach(element => {
        tempJSON = { ...tempJSON, [element?.GroupMenuName]: { ...tempJSON?.[element?.GroupMenuName], [element?.Action.replace(/ /g, '')]: element?.ActionAllow } }
      });
      RoleDataJson.current = tempJSON;
    }
  }, [])

  useMemo(() => {
    async function getLogo() {
      let Url = "https:localhost:3000";
      // const IsThemeData = await AppsyncDBconnection(
      //   getXLMSCustomLoginTemplate,
      //   { PK: "XLMS#CUSTOMLOGINTEMPLATE", SK: "CUSTOMLOGIN#" + Url }, "d171ogig38p31a");
      // if (IsThemeData.res.getXLMSCustomLoginTemplate != null) {
      //   let awsconfig = {};
      //   awsconfig = JSON.parse(IsThemeData.res.getXLMSCustomLoginTemplate.Status);
      //   // const a = {
      //   //   signIn: {
      //   //     username: {
      //   //       labelHidden: !IsThemeData.data.getXLMSCustomLoginTemplate.IsUserNameLableVisible,
      //   //       isRequired: true,
      //   //       autocomplete: "off",
      //   //     },
      //   //     password: {
      //   //       labelHidden: !IsThemeData.data.getXLMSCustomLoginTemplate.IsPassWordLableVisible,
      //   //       isRequired: true,
      //   //       autocomplete: "off",
      //   //     },
      //   //   },
      //   // };
      //   Amplify.configure({ ...awsconfig, ssr: false });
      //   // page.current.style.backgroundColor = IsThemeData.data.getXLMSCustomLoginTemplate.LoginBackground;
      // }
      // else {
      //   Amplify.configure({ ...awsconfig, ssr: false });
      // }
      setAmplify("Done")

    }
    getLogo();
  }, []);

  const getUA = () => {
    let device;
    const ua = {
      "Android": /Android/i,
      "BlackBerry": /BlackBerry/i,
      "Bluebird": /EF500/i,
      "Chrome OS": /CrOS/i,
      "Datalogic": /DL-AXIS/i,
      "Honeywell": /CT50/i,
      "iPad": /iPad/i,
      "iPhone": /iPhone/i,
      "iPod": /iPod/i,
      "macOS": /Macintosh/i,
    }
    Object.keys(ua).map(v => navigator.userAgent.match(ua[v]) && (device = v));
    return device;
  }

  const clearOnSignout = useCallback(() => {
    TenantInfo.current = {};
    logoPath.current = (null);
    user.current = {};
    check.current = 1;
    notificationPK.current = "";
    let body = {
      "--nvl-body-bg-color": "rgb(255, 255, 255)",
      "--nvl-body-button-bg-color": "#099127",
      "--nvl-body-button-hover-bg-color": "#0c6e0c",
      "--nvl-body-icon-color": "#0d6aff",
      "--nvl-body-txt-color": "rgb(75 85 99)",
      "--nvl-loading-spinner-bg-clr": "hsl(0, 72%, 48%)"
    }

    let sidder = {
      "--nvl-sidebar-bg-color": "#f9fafc 0% 0% no-repeat padding-box",
      "--nvl-sidebar-hover-bg-color": "rgb(219 234 254)",
      "--nvl-sidebar-icon-color": "rgb(55 65 81)",
      "--nvl-sidebar-nested-bg-color": "rgb(239 246 255)",
      "--nvl-sidebar-txt-color": "rgb(55 65 81)"
    }

    let grid = {
      "--nvl-grid-header-bg-color": "rgb(219 234 254)",
      "--nvl-grid-row-end-bg-color": "rgb(255, 255, 255)",
      "--nvl-grid-row-start-bg-color": "rgb(243 244 246)",
      "--nvl-grid-txt-color": "rgb(66, 66, 66)"
    }

    let header = {
      "--nvl-header-bg-color": "#f9fafc",
      "--nvl-header-icon-color": "#757575",
      "--nvl-header-txt-color": "rgb(55 65 81)"
    }
    if (typeof window !== "undefined") {
      let r = document.querySelector(':root')
      Object.keys(body).map((item) => {
        r.style.setProperty(item, body[item])
      })

      Object.keys(sidder).map((item) => {
        r.style.setProperty(item, sidder[item])
      })

      Object.keys(grid).map((item) => {
        r.style.setProperty(item, grid[item])
      })

      Object.keys(header).map((item) => {
        r.style.setProperty(item, header[item])
      })

      try {
        DashContext = createContext({ isOpen: false, isCollapsed: [], oldCollapsed: [] });
      }
      catch (e) { }
      setMenu([]);
    }
  }, []);

  const BindContext = useCallback(async (user) => {
    let TenantContext;
    let userGroup = user?.signInUserSession?.accessToken?.payload?.["cognito:groups"][0];
    let tenantResponse = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + user?.attributes["custom:tenantid"] }, user?.signInUserSession?.accessToken?.jwtToken);
    const tenantBranding = await AppsyncDBconnection(getXlmsTenantBranding, { PK: "XLMS#BRANDING#TENANT#" + user?.attributes["custom:tenantid"], SK: "BRANDING#" + tenantResponse?.res?.getXlmsTenantInfo?.ThemeMode }, user?.signInUserSession?.accessToken?.jwtToken);
    if (userGroup != "SiteAdmin") {
      let UserDetail = await AppsyncDBconnection(getXlmsUserInfo, { PK: "TENANT#" + user?.attributes["custom:tenantid"], SK: "#USERINFO#" + user?.attributes["sub"] }, user?.signInUserSession?.accessToken?.jwtToken)
      if (UserDetail?.res?.getXlmsUserInfo != undefined && user != null) {
        let name = (UserDetail?.res?.getXlmsUserInfo.FirstName != undefined ? UserDetail?.res?.getXlmsUserInfo.FirstName : "") + " " + (UserDetail?.res?.getXlmsUserInfo.LastName != undefined ? UserDetail?.res?.getXlmsUserInfo.LastName : "")
        userprofileName.current = { PofileURL: (UserDetail?.res?.getXlmsUserInfo.ProfileURLPath != "" ? UserDetail?.res?.getXlmsUserInfo.ProfileURLPath : undefined), Name: name, FirstName: (UserDetail?.res?.getXlmsUserInfo.FirstName != undefined ? UserDetail?.res?.getXlmsUserInfo.FirstName : "") };
      } else {
        userprofileName.current = null;
      }
      if (localStorage.getItem("IsloginUser") == null) {
        localStorage.setItem('IsloginUser', true);
        const PopupInfo = await AppsyncDBconnection(listXlmsPopUpInfo,
          {
            PK: "TENANT#" + user?.attributes["custom:tenantid"],
            SK: "POPUP#LASTMODIFIEDDATE#", IsDeleted: false
          },
          user?.signInUserSession?.accessToken?.jwtToken);
        const now = new Date().getTime();
        const currentEvent = PopupInfo?.res?.listXlmsPopUpInfo?.items?.filter(
          p => new Date(p.StartDate) < now && new Date(p.EndDate) > now
        );
        setPopupData(currentEvent)
      }
    }
    if (tenantBranding?.res?.getXlmsTenantBranding != undefined && user != null) {
      ThemeColorApply(tenantBranding?.res?.getXlmsTenantBranding)
    }
    if (tenantResponse?.Status == "Success") {
      if (tenantResponse?.res?.getXlmsTenantInfo != undefined && user != null) {
        logoPath.current = (tenantResponse?.res?.getXlmsTenantInfo.LogoUrlPath != "" ? tenantResponse?.res?.getXlmsTenantInfo.LogoUrlPath : undefined);
        TenantContext = { TenantName: tenantResponse?.res?.getXlmsTenantInfo.TenantName, TenantID: tenantResponse?.res?.getXlmsTenantInfo.TenantID, PlanCode: tenantResponse?.res?.getXlmsTenantInfo.PlanCode, FirstTimeLogin: tenantResponse?.res?.getXlmsTenantInfo.FirstTimeLogin, UserGroup: user?.signInUserSession?.accessToken?.payload["cognito:groups"][0], BucketName: tenantResponse?.res?.getXlmsTenantInfo.BucketName, RootFolder: tenantResponse?.res?.getXlmsTenantInfo.RootFolder, StartDate: tenantResponse?.res?.getXlmsTenantInfo.StartDate, CustomLogo: tenantResponse?.res?.getXlmsTenantInfo.LogoUrlPath, ThemeMode: tenantResponse?.res?.getXlmsTenantInfo.ThemeMode };
        page?.current?.style != undefined ? (page.current.style.backgroundColor = "#fff") : "";
        await existingDataHandler(user?.signInUserSession?.accessToken?.payload["cognito:groups"][0], tenantResponse?.res?.getXlmsTenantInfo.PlanCode, tenantResponse?.res?.getXlmsTenantInfo.StartDate, tenantResponse?.res?.getXlmsTenantInfo.TenantID, user?.attributes["custom:Menu-Shard-Key"], user)
        if (tenantResponse?.res?.getXlmsTenantInfo !== null && tenantResponse?.res?.getXlmsTenantInfo.FirstTimeLogin && router.pathname != "/PlanProcessor/PlanInfo" && Refersh.current) {
          let sub = user?.attributes["sub"];
          let TentID = user?.attributes["custom:tenantid"];
          notificationPK.current = "TENANT#" + TentID + "#USERSUB#" + sub;
          TenantContext = { TenantName: tenantResponse?.res?.getXlmsTenantInfo.TenantName, TenantID: tenantResponse?.res?.getXlmsTenantInfo.TenantID, PlanCode: tenantResponse?.res?.getXlmsTenantInfo.PlanCode, FirstTimeLogin: tenantResponse?.res?.getXlmsTenantInfo.FirstTimeLogin, UserGroup: user?.signInUserSession?.accessToken?.payload["cognito:groups"][0], BucketName: tenantResponse?.res?.getXlmsTenantInfo.BucketName, RootFolder: tenantResponse?.res?.getXlmsTenantInfo.RootFolder, StartDate: tenantResponse?.res?.getXlmsTenantInfo.StartDate, CustomLogo: tenantResponse?.res?.getXlmsTenantInfo.LogoUrlPath, ThemeMode: tenantResponse?.res?.getXlmsTenantInfo.ThemeMode };
        }
      } else if (user != null) {
        if (user?.signInUserSession?.accessToken?.payload["cognito:groups"][0] != "SiteAdmin") {
          window.location.reload();
        }
        TenantContext = { TenantName: "", TenantID: "", PlanCode: "", FirstTimeLogin: false, UserGroup: user?.signInUserSession?.accessToken?.payload["cognito:groups"][0], BucketName: "", RootFolder: "", StartDate: "" };
        await existingDataHandler(user?.signInUserSession?.accessToken?.payload["cognito:groups"][0], "", "", "", user?.attributes["custom:Menu-Shard-Key"], user)
      }
      return TenantContext;
    }
    else {
      localStorage.clear();
      Auth.signOut();
    }
  }, [router, existingDataHandler]);

  function ThemeColorApply(BardingInfo) {

    let r = document.querySelector(':root')
    if (BardingInfo?.Body != undefined) {
      let bodyColor = JSON.parse(BardingInfo.Body)
      Object.keys(bodyColor).map((item) => {
        r.style.setProperty(item, bodyColor[item])
      })
    }
    if (BardingInfo?.SideBar != undefined) {
      let SideBarColor = JSON.parse(BardingInfo.SideBar)
      Object.keys(SideBarColor).map((item) => {
        r.style.setProperty(item, SideBarColor[item])
      })
    }
    if (BardingInfo?.Grid != undefined) {
      let GridColor = JSON.parse(BardingInfo?.Grid)
      Object.keys(GridColor).map((item) => {
        r.style.setProperty(item, GridColor[item])
      })
    }
    if (BardingInfo?.Header != undefined) {
      let HeaderColor = JSON.parse(BardingInfo?.Header)
      Object.keys(HeaderColor).map((item) => {
        r.style.setProperty(item, HeaderColor[item])
      })
    }
  }

  const getUserLoggedIn = useCallback(async () => {
    if (amplify != undefined) {
      let isUserLoggedIn;
      try {
        let isUserLoggedIncS = await Auth.currentSession();
        isUserLoggedIn = isUserLoggedIncS.isValid();
        if (TenantInfo.current?.UserGroup === undefined) {
          let currentuser = await Auth?.currentAuthenticatedUser();
          currentUser.current = isUserLoggedIn;
          user.current = currentuser;
          BindContext(currentuser).then(async (TenantContext) => {
            if (menu.length <= 1 && TenantContext?.FirstTimeLogin == false && check.current < 7) {
              check.current = check.current + 1;
              let userGroup = currentuser?.signInUserSession?.accessToken?.payload["cognito:groups"][0];
              let TentID = currentuser?.attributes["custom:tenantid"];
              let ShardKey = currentuser?.attributes["custom:Menu-Shard-Key"];
              let sub = currentuser?.attributes["sub"];
              if (userGroup == "SiteAdmin") {
                notificationPK.current = ("TENANT#" + "GROUP#" + userGroup)
                async function CallMenuSAdminMenuList() {
                  AppsyncDBconnection(listXlmsGrpMenuBinding, { PK: "XLMS#ROLE#" + userGroup, SK: "GrpMenu#" }, currentuser?.signInUserSession?.accessToken?.jwtToken).then((data) => {
                    TenantInfo.current = TenantContext;
                    if (data.res.listXlmsGrpMenuBinding?.items != undefined)
                      setMenu(data.res.listXlmsGrpMenuBinding?.items);
                  })
                }
                CallMenuSAdminMenuList();
              } else {
                notificationPK.current = ("TENANT#" + TentID + "#USERSUB#" + sub)
                var pk;
                if (ShardKey != undefined) {
                  pk = "TENANT#" + TentID + "#" + ShardKey;
                }
                else if (ShardKey == undefined) {
                  pk = "TENANT#" + TentID
                }
                async function CallMenuMenuList() {
                  AppsyncDBconnection(listXlmsTenantGrpMenuBinding, { PK: pk, SK: "ROLE#" + userGroup + "#GrpMenu" }, currentuser?.signInUserSession?.accessToken?.jwtToken).then((data) => {
                    TenantInfo.current = TenantContext;
                    if (data?.res?.listXlmsTenantGrpMenuBinding?.items != undefined)
                      setMenu(data?.res?.listXlmsTenantGrpMenuBinding?.items);
                  });
                }
                CallMenuMenuList().then((r) => {
                  // setMenu(r.data.listXlmsTenantGrpMenuBinding.items);
                });
              }
            }
            else if (TenantContext?.FirstTimeLogin) {
              TenantInfo.current = TenantContext;
              setMenu([])
              router.push("/PlanProcessor/PlanInfo", undefined, { shallow: true });
            }
          });
          if (typeof (Worker) != undefined) {
            // new Worker(NVLWebWorkerLogin);
          }
        }

      } catch (error) {
        if (typeof localStorage !== 'undefined') {
          localStorage.clear();
        }
        isUserLoggedIn = false;
        currentUser.current = isUserLoggedIn;
        clearOnSignout();
      }
    }
  }, [BindContext, amplify, menu.length, router, clearOnSignout])

  useMemo(() => {
    if (amplify != undefined) {
      getUserLoggedIn();
      Hub.listen("auth", (event) => {
        if (event.payload.event == "signIn") {
          currentUser.current = true;
          setMenu([]);
          getUserLoggedIn();
        } else if (event.payload.event == "signOut") {
          localStorage.clear();
          currentUser.current = false;
          clearOnSignout();
        }
      });
    }
  }, [amplify, getUserLoggedIn, clearOnSignout]);

  const [popupData, setPopupData] = useState();
  const Page = useCallback((props) => {
    const signOut = async () => {
      currentUser.current = false;
      try {
        await Auth.signOut({ global: true });
        localStorage.clear();
      }
      catch (e) {
        localStorage.clear();
      }
    }
    const changeUserValues = (temp) => {
      user.current = temp;
    }
    if (props.currentUser.current) {
      return (
        <Container loader={props.user?.current?.signInUserSession == undefined || props.TenantInfo?.current?.TenantID == undefined}>
          <ThemeProvider>
            <IdleTimeOutHandler ref={timer} user={props.user.current} signOut={signOut} />
            <NVLWebWorkerLogin changeUserValues={changeUserValues} signOut={signOut} user={props.user.current} />
            {(props.popupData != undefined && props.popupData?.length != 0) && (<NVLWelcomeInfoPopup setPopupData={setPopupData} popupData={props.popupData} ></NVLWelcomeInfoPopup>)}
            <DashLayout ReduceNewDataFunction={props.ReduceNewDataFunction} changeRef={props.changeRef.current} NotificationPK={props.notificationPK.current} Menu={props.menu} user={props.user.current} signOut={signOut} title={Component.name} TenantInfo={props.TenantInfo.current} clearOnSignout={props.clearOnSignout} TenantLogo={props.logoPath.current} UserProfile={userprofileName.current}>
              {props.isLoder ? (<NVLLoadingSpinner></NVLLoadingSpinner>) :
                <Component ReduceNewData={props.ReduceNewData}  {...pageProps} signOut={signOut} user={props.user.current} TenantInfo={props.TenantInfo.current} RoleData={props.RoleDataJson.current?.[props.router.pathname.split("/")[1]]} GeneralRoleData={props.RoleDataJson.current?.General} />}
            </DashLayout>
          </ThemeProvider>
        </Container>
      );
    }
    else if (props.currentUser.current != undefined) {
      return (
        <>
          <Login />
        </>
      )
    }
    else {
      return (
        <>
          <Container loader={true} title={""} />
        </>
      )
    }
  }, [Component.name, pageProps])


  return (
    <>
      {router.pathname === '/WebView/WebView' && <WebView />}
      {router.pathname !== '/WebView/WebView' && <div className="h-screen font-Montserrat" ref={page}>
       
        <div className={!currentUser.current ? (isLogo ? "" : "") : null}>
          <Page popupData={popupData} getUserLoggedIn={getUserLoggedIn} currentUser={currentUser} user={user} router={router} pageProps={pageProps} menu={menu} isLoder={isLoder} changeRef={changeRef} notificationPK={notificationPK} TenantInfo={TenantInfo} logoPath={logoPath} RoleDataJson={RoleDataJson} clearOnSignout={clearOnSignout} ReduceNewDataFunction={ReduceNewDataFunction} ReduceNewData={ReduceNewData.current} />
        </div>
      </div>}
    </>
  );
};

export default App;