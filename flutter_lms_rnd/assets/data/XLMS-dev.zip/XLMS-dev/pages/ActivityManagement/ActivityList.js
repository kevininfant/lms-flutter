import { createMeeting } from "@components/Common/ZoomMeeting";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { BatchPut } from "BatchPutItem/BatchPut";
import { APIGatewayGetRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useState } from "react";
import { createXlmsActivityManagementShardingInfo, updateXlmsActivityManagementInfo } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, listXlmsActivityManagementInfos } from "src/graphql/queries";

export default function ActivityList(props) {
  const router = useRouter();
  const [popupValues, setPopupValues] = useState({});
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [search, setSearch] = useState("")
  const headerColumn = [
    { HeaderName: "Activity Name", Columnvalue: "ActivityName", HeaderCss: "w-3/12", },
    { HeaderName: "Activity Type", Columnvalue: "ActivityType", HeaderCss: "w-8/12", },
    { HeaderName: "Date", Columnvalue: "CreatedDate", HeaderCss: "w-0/12 whitespace-nowrap" },
    { HeaderName: "Activity Status", Columnvalue: "IsSuspend", HeaderCss: "w-0/12", },
    { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
  ];
  const searchBoxVal = (e) => {
    setSearch(e);
    setIsRefreshing((count) => {
      return count + 1;
    });
  }

  const refreshData = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };
  const refreshGrid = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };

  function resetPopUp() {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    document.getElementById("tableSearch").value = "";
  }

  function popup(type, PK, SK, Content, getItem) {
    setPopupValues({ Content: Content, Type: type, Item: getItem });
  }
  async function updateField(e) {
    e.preventDefault();
    let isSus = false;
    let isDelete = false;
    if (popupValues.Type == "isSuspend") {
      isSus = true;
    } else if (popupValues.Type == "isDelete") {
      isDelete = true;
      isSus = true;
      if (popupValues?.Item?.SK?.split("#")[1] == "Zoom") {
        let EditData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: popupValues.Item.PK, SK: popupValues.Item.SK }, props.user.signInUserSession.accessToken.jwtToken);
        EditData = EditData.res?.getXlmsActivityManagementInfo;

        const meetingDetails = {
          topic: "Deleted",
          type: 2,
          timezone: "UTC",
          agenda: "Zoom Test"
        };
        let groupMenuName = "ActivityManagement";
        let menuId = "500014";
        const headers = { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, menuid: menuId, groupmenuname: groupMenuName, defaultrole: props.TenantInfo.UserGroup, };
        let ZoomResponse = await APIGatewayGetRequest(process.env.APIGATEWAY_ZOOM_TOKEN, { method: 'GET', headers: headers });
        const temp = await ZoomResponse?.res.text();
        createMeeting({ token: JSON.parse(temp)?.access_token, meetingDetails: meetingDetails, meetingID: EditData?.MeetingID, mode: "delete" })
      }
    }
    refreshData();
    if (popupValues.Item.Shard != undefined) {
      BatchPut({ Values: popupValues.Item, Shard: popupValues.Item.Shard, query: createXlmsActivityManagementShardingInfo, UpdateData: { IsSuspend: isSus, IsDeleted: isDelete, ModifiedDate: new Date() }, user: props.user.signInUserSession.accessToken.jwtToken });
    }
    let FinalStatus = await AppsyncDBconnection(updateXlmsActivityManagementInfo, { input: { PK: popupValues.Item.PK, SK: popupValues.Item.SK, IsSuspend: isSus, IsDeleted: isDelete, ModifiedDate: new Date() } }, props.user.signInUserSession.accessToken.jwtToken)

    if (FinalStatus.Status == "Success") {
      refreshData();
    }
    resetPopUp();
  }

  function getDateFormat(CreatedDt) {
    return (new Date(CreatedDt).toDateString().substring(4))
  }

  const actionRestriction = useCallback((getItem) => {
    let actionList = [];
    if (props.RoleData?.ShowActivity && getItem.IsSuspend) {
      actionList.push(
        {
          id: 1,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
          name: "Show Activity",
          action: () =>
            popup("", getItem.PK, getItem.SK, "Are you sure to Show Activity?", getItem),
        }
      )
    }
    if (props.RoleData?.DeleteActivity && getItem.IsSuspend) {
      actionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete Activity",
          action: () =>
            popup("isDelete", getItem.PK, getItem.SK, "Are you sure to Delete Activity?", getItem),
        }
      )

    }
    if (props.RoleData?.EditActivity && !getItem.IsSuspend) {

      actionList.push(
        {
          id: 4,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit Activity",
          action: () =>
            router.push(`/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
        }
      )
    }
    if (props.RoleData?.EditActivitySettings && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 5,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit Settings",
          action: () =>
            router.push(
              `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`
            ),
        },
      )
      if (getItem.ActivityType == "Discussion")
        actionList.push(
          {
            id: 12,
            Color: "text-green-700",
            Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
            name: "Topic List",
            action: () =>
              router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityName=Discussion&ActivityID=${getItem.ActivityID}`),
          },
        )
    }
    if (props.RoleData?.ActivityEnrollUser && !getItem.IsSuspend && ((getItem?.FileProcessing != undefined && getItem?.FileProcessing == 0 && (getItem.ActivityType == "ScormPackage" || getItem.ActivityType == "Video")) || (getItem.ActivityType != "ScormPackage" || getItem.ActivityType != "Video"))) {
      actionList.push(
        {
          id: 6,
          Color: "text-blue-700",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Enroll User",
          action: () =>
            router.push(`/ActivityManagement/EnrollUser?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
        },
      )
    }
    if (props.RoleData?.ActivityEnrollUser && !getItem.IsSuspend && ((getItem?.FileProcessing != undefined && getItem?.FileProcessing == 0 && (getItem.ActivityType == "ScormPackage" || getItem.ActivityType == "Video")) || (getItem.ActivityType != "ScormPackage" || getItem.ActivityType != "Video"))) {
      actionList.push({
        id: 6,
        Color: "text-blue-700",
        Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
        name: "Enrollment List",
        action: () => router.push(`/ActivityManagement/DismissUser?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
      });
    }
    if (props.RoleData?.AddActivityCertificate && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 7,
          Color: "text-blue-700",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Add Certificate",
          action: () =>
            router.push(`/ActivityManagement/Certificate?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
        },
      )
    }
    if (props.RoleData?.AddActivityBadge && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 8,
          Color: "text-blue-700",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Add Badge",
          action: () =>
            router.push(`/ActivityManagement/AddBadge?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
        },
      )
    }
    if (props.RoleData?.SendNotificationActivity && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 9,
          Color: "text-blue-700",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Send Notification",
          action: () =>
            router.push(`/ActivityManagement/SendNotificationList?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
        },
      )
    }
    if (props.RoleData?.HideActivity && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 10,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
          name: "Hide Activity",
          action: () =>
            popup("isSuspend", getItem.PK, getItem.SK, "Are you sure to Hide Activity?", getItem),
        }
      )
    }
    if (getItem.ActivityType == "Quiz" && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 11,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-plane-circle-xmark text-red-600 bg-red-100 w-6",
          name: "Offline Quiz Grade",
          action: () =>
            router.push(`/ActivityManagement/OfflineQuiz?ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
        },
        {
          id: 12,
          Color: "text-yellow-600",
          Icon: "fa fa-wpforms text-blue-600 w-6",
          name: "Quiz Response",
          action: () =>
            router.push(`/ActivityManagement/QuizResponse?ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}`),
        }
      )
    }
    if (getItem.ActivityType == "Zoom" && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 11,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Meeting Preview",
          action: () =>
            router.push(`/ActivityManagement/ZoomAdminView?ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
        },

      )
    }
    if (getItem.ActivityType == "Assignment" && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 11,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Admin Page",
          action: () =>
            router.push(`/ActivityManagement/AssignmentAdminPage?ActivityID=${getItem.ActivityID}`),
        },

      )
    }
    return actionList;
  }, [router, props])

  const gridDataBind = useCallback(
    (viewData) => {
      const rowGrid = [];
      viewData && viewData.map((getItem, index) => {
        let regex = /(<([^>]+)>)/gi,
          body = getItem.ActivityDescription,
          result = body?.replace(regex, "").body?.replace(/&amp;/g, "&").replace(/&nbsp;/g, ' '),
          actionList = [];
        actionList = actionRestriction(getItem)
        rowGrid.push({
          PK: (
            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
          ),
          SK: (
            <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
          ),
          ActivityId: (
            <NVLlabel id={"lblActivityId" + (index + 1)} name="ActivityId" text={getItem.SK} />
          ),
          ActivityName: (
            <>
              <NVLlabel id={"txtActivityName" + (index + 1)} text={getItem.ActivityName}></NVLlabel>
            </>
          ),
          ActivityType: (
            <NVLlabel id={"txtActivitycategory" + (index + 1)} text={getItem.ActivityType == "ScormPackage" ? "SCORM Package" : getItem.ActivityType}></NVLlabel>
          ),
          CreatedDate: (
            <NVLlabel
              id={"txtName" + (index + 1)}
              text={getDateFormat(getItem.CreatedDate)}
            ></NVLlabel>
          ),
          IsSuspend: (
            <>
              <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                <div
                  className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"
                    }	`}
                ></div>
                <NVLlabel
                  className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"
                    } my-auto ml-2	`}
                  text={!getItem.IsSuspend ? "Active" : "Inactive"}
                ></NVLlabel>
              </div>
            </>
          ),
          Action: (
            <NVLRapidModal
              id={"RapidModal" + (index + 1)}
              ActionList={actionList}
            ></NVLRapidModal>
          ),
        });
      });
      return rowGrid;
    }, [actionRestriction]
  );

  const headerHandler = (e, url) => {
    e.preventDefault();
    router.push(url);
  };
  const cancelEvent = (e) => {
    e.preventDefault();
    resetPopUp();
  };
  const variable = { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#" }
  const pageRoutes = [
    { path: "", breadcrumb: "Activity Management" }
  ];
  return (
    <>
      <Container title="Activity Management">
        <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} IsSearch={props.RoleData?.SeTenanthActivity ? true : false} ButtonID5="btnCreateActivity" LinkName5="+ Create Activity" className5={props.RoleData?.CreateActivity ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectHome={"/"} RedirectAction5={(e) => headerHandler(e, "/ActivityManagement/ActivityInfo?Mode=Create")} href5="/ActivityManagement/ActivityInfo?Mode=Create" placeholder={"Search by "} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshGrid} RedirectAction4={() => refreshGrid()} IsNestedHeader />
        <div className="max-w-full w-full justify-center">
          <NVLGridTable
            user={props.user}
            refershPage={isRefreshing}
            id="tblActivityList" Search={search}
            HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsActivityManagementInfos}
            querryName={"listXlmsActivityManagementInfos"}
            variable={variable} />
        </div>
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
      </Container>
    </>
  );
}