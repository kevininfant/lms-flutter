import { GetDateFormat } from '@components/Common/DateFormat';
import Container from '@components/Container/Container';
import NVLAlert, { ModalOpen } from '@components/Controls/NVLAlert';
import NVLButton from '@components/Controls/NVLButton';
import NVLFileUpload from '@components/Controls/NVLFileUpload';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLLoader from '@components/Controls/NVLLoader';
import NVLSelectField from '@components/Controls/NVLSelectField';
import NVLWarning from '@components/Controls/NVLWarning';
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from 'aws-amplify';
import { APIGatewayGetRequest, APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from 'next/router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { getXlmsActivityManagementInfo, listXlmsActivityEnrollUser } from 'src/graphql/queries';
import * as Yup from "yup";

function OfflineQuiz(props) {

  const router = useRouter();
  const activityId = useMemo(() => {
    let Activityid;
    if (props?.mode == "ModuleDirect") {
      Activityid = props?.ActivityID
    } else {
      Activityid = router.query["ActivityID"];
    }
    return Activityid;
  }, [props?.ActivityID, props?.mode, router.query])


  const activityType = useMemo(() => {
    let activityType;
    if (props?.mode == "ModuleDirect") {
      activityType = props?.ActivityType
    } else {
      activityType = router.query["ActivityType"]
    }
    return activityType
  }, [props?.ActivityType, props?.mode, router.query])

  const userSub = useMemo(() => {
    let sub;
    if (props.mode == "ModuleDirect") {
      sub = props.UserSub;
    } else {
      sub = props.user.attributes["sub"];
    }
    return sub;
  }, [props.UserSub, props.mode, props.user.attributes])

  const [fileValues, setFileValues] = useState({
    TextName: "Select File",
    FilePath: null,
    path: null,
    pathchanged: false,
  });
  const [modalValues, setModalValues] = useState({});
  const [currentBatch, setBatch] = useState()

   const batchName= useMemo(()=>{
    const batchName = [{ value: "", text: "Select" }];
       props?.BatchData && props?.BatchData.map((batch) => {
      batchName.push({ value: batch.BatchID, text: batch.BatchName });
    });
   return batchName;
  },[props?.BatchData]);
 

  const [fetchedQuizData, setFetchedQuizData] = useState()

  useEffect(() => {
    async function fetchData() {
      let userCount = await AppsyncDBconnection(listXlmsActivityEnrollUser, { GsiPK: "ACTIVITYID#" + activityId, GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#" }, props.user.signInUserSession.accessToken.jwtToken);
      let activityData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId, }, props.user.signInUserSession.accessToken.jwtToken);
      if (props.mode == "ModuleDirect") {
        setFetchedQuizData({EnrolledUser: props.EnrolledUser,ActivityData: props.ActivityData})
      } else {
        setFetchedQuizData({EnrolledUser: userCount.res?.listXlmsActivityEnrollUser?.items != undefined ? (userCount.res?.listXlmsActivityEnrollUser?.items) : [],ActivityData: activityData.res?.getXlmsActivityManagementInfo
        })
      }
    }
    fetchData()
    return (() => {
      setFetchedQuizData((temp) => { return { ...temp } });
    })
  }, [activityId, activityType, props.ActivityData, props.EnrolledUser, props.TenantInfo.TenantID, props.mode, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const validationSchema = Yup.object().shape({
    File: Yup.string().test("file_Error", "", (e, { createError }) => {
      if (e == undefined || e == "false" || fileValues.TextName == undefined) {
        return createError({ message: "File is required" });
      }
      if (e == "fileType") {
        return createError({ message: "Invalid file type" });
      }
      if (e == "Empty" || e == undefined) {
        return createError({ message: "Empty File... Please fill values" });
      }
      if (e == "HeaderMismatch" || e == undefined) {
        return createError({
          message: "Header Mismatch. Please choose correct format.",
        });
      }
      if (e == "FileSize") {
        setFileValues({ TextName: "Select File" });
        return createError({ message: "File size should be 5MB" });
      }
      if (e == "Error") {
        return createError({ message: "Server Error Please Try Again" });
      }
      return true;
    }),
    ddlBatch: props.mode == "ModuleDirect" ? Yup.string().required("Batch is required").test("", "", (e) => {
      setBatch(e)
      if (currentBatch != e) {
        setFileValues({ TextName: "Select File", FilePath: null });
      }
      return true
    })
      : Yup.string().nullable()
  })

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, reset, watch, formState } = useForm(formOptions);
  const { errors } = formState;
  
  const csvHeader = useMemo(() => {
    return [
      { HeaderName: "Username", Action: "true" },
      { HeaderName: "EmailID", Action: "true" },
      { HeaderName: "MarkScored", Action: "true" },
      { HeaderName: "PassingGrade", Action: "true" },
      { HeaderName: "TotalMark", Action: "true" },
      { HeaderName: "Grade", Action: "true" }]
  }, [])

  const finalResponse = (response) => {
    if (response != "Success") {
      setModalValues({ModalInfo: "Danger",ModalTopMessage: "Error",ModalBottomMessage: response, });
      ModalOpen();
      return;
    } else {
      setModalValues({ModalInfo: "Success",ModalTopMessage: "Sucesss",ModalBottomMessage: "File Uploaded Successfully.",ModalOnClickEvent: () => {  if (props?.mode == "ModuleDirect") {    router.push(`/CourseManagement/ModulesList?CourseID=${encodeURIComponent(props?.CourseID)}`);  } else {    router.push("/ActivityManagement/ActivityList")  }}});
      ModalOpen();
    }
  };

  const clearForm = useCallback(() => {
    setFileValues({ TextName: "Select File", FilePath: null });
    setValue("submit", false);
    reset()
  }, [reset, setValue]);

  const downloadCsvFile = useCallback(
    async (e) => {
      if (e?.type == "click") {
        let rows = [];
        csvHeader?.forEach((element) => {element.Action === "true" ? rows.push(element.HeaderName) : "";});
        let csvContent = rows;
        csvContent += "\r\n";
        let link = document.createElement("a");
        link.id = "download-csv";
        link.setAttribute("href","data:text/plain;charset=utf-8," + encodeURIComponent(csvContent));
        link.setAttribute("download", "OfflineQuizGrade.csv");
        document.body.appendChild(link);
        document.querySelector("#download-csv").click();
      }
    },
    [csvHeader]
  );

  async function fileValidation(e) {
    const file = e.target.files[0];
    let fileInput = document.getElementById("getFile");
    let filePath = fileInput.value;
    let allowedExtensions = /(\.csv)$/i;
    if (!allowedExtensions.exec(filePath)) {
      fileInput.value = "";
      setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
      setValue("File", "fileType", { shouldValidate: true });
      return false;
    } else if (file.size > process.env.ACTIVITY_ENROLLUSER_FILE_SIZE) {
      setValue("File", "FileSize", { shouldValidate: true });
    } else {
      await uploadFile(e);
    }
  }

  async function uploadFile(e) {
     const file = e.target.files[0];
    
    if (file == undefined) {
      if (fileValues?.FilePath != undefined || fileValues?.FilePath != "") {
        setValue("File", "exist", { shouldValidate: true });
      }
      else {
        setValue("File", "Empty", { shouldValidate: true });
      }
      return true;
    }
    const csvReader = new FileReader();
    csvReader.onload = async function (e) {
      const text = e.target.result;
      let lines = text.split("\n");
      let values = lines[0].split(",");
      let isCSVDatacheck = false;
      for (let i = 0; i < csvHeader.length; i++) {
        if (values[i].trim() != csvHeader[i].HeaderName.trim() || values.length != csvHeader.length) {
          setValue("File", "HeaderMismatch", { shouldValidate: true });
          isCSVDatacheck = true;
          return;
        }
      }
      if (!isCSVDatacheck) {
        let data = lines[1].split(",");
        if (data.length != csvHeader.length) {
          setValue("File", "Empty", { shouldValidate: true });
          isCSVDatacheck = true;
          return;
        }
      }

      let fetchUrl;
      if (!isCSVDatacheck) {
        if (props?.mode == "ModuleDirect") {
          fetchUrl = process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +`?FileName=${file.name}&TenantID=${props?.TenantInfo.TenantID}&CourseType=Module&RootFolder=${props?.TenantInfo.RootFolder}&BucketName=${props?.TenantInfo.BucketName}&Type=OfflineQuiz&ManagementType=CourseManagement`
        } else {
          fetchUrl =process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +`?FileName=${file.name}&TenantID=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&ActivityType=${activityType}&Type=OfflineQuiz`;
        }
        let groupMenuName = props?.mode == "ModuleDirect" ? "CourseManagement" : "ActivityManagement";
        let menuId = props?.mode == "ModuleDirect" ? "300406" : "500002";
        let headers = {method: "GET",headers: {  authorizationToken: await Auth.currentSession().then((s) =>    s.getAccessToken().getJwtToken()  ),  defaultrole: props?.TenantInfo.UserGroup,  groupmenuname: groupMenuName,  menuid: menuId,},};
        let extension = file.name.substring(file.name.lastIndexOf(".") + 1).toLowerCase();
        let contentType =extension == "csv"  ? "text/" + extension  : ImageExtension.indexOf(extension) >= 0    ? "image/" + extension    : VideoExtension.indexOf(extension) >= 0      ? "video/" + extension      : "application/" + extension;
        let presignedHeader = {method: "PUT",headers: {  
         // "x-amz-acl": "public-read",
          "content-type": contentType,  defaultrole: props?.TenantInfo.UserGroup,  groupmenuname: groupMenuName,  menuid: menuId,},body: file,
        };
        let finalStatus = await APIGatewayPutRequest(fetchUrl, headers, presignedHeader);
        if (finalStatus[0] != "Success") {
          setFileValues({ ...fileValues, TextName: "Select File", FilePath: "",});
          setValue("File", "Error", { shouldValidate: true });
          return;
        } else {
          setValue("File", "exist", { shouldValidate: true });
          setFileValues({...fileValues,TextName: file.name,FilePath: finalStatus[1],
          });
        }
      }
    };
    csvReader.readAsText(file);
  }


  const uploadHandler = async () => {
    setValue("submit", true);
    if (fileValues.FilePath == null) {
      setValue("File", "false", { shouldValidate: true });
      setValue("submit", false);
      return;
    }

    let fetchURL =props?.mode == "ModuleDirect"  ? process.env.ACTIVITY_UNSAVED_TO_SAVED +  `?FileName=${fileValues.TextName}&ActivityID=${activityId}&Type=OfflineQuiz&TenantID=${props?.TenantInfo.TenantID}&RootFolder=${props?.TenantInfo.RootFolder}&BucketName=${props?.TenantInfo.BucketName}&ActivityType=${activityType}&ManagementType=CourseManagement&CourseID=${props?.CourseID}&ModuleID=${props?.ModuleID}&CourseType=Module`  : process.env.ACTIVITY_UNSAVED_TO_SAVED +  `?FileName=${fileValues.TextName}&ActivityID=${activityId}&Type=OfflineQuiz&TenantID=${props?.TenantInfo.TenantID}&RootFolder=${props?.TenantInfo.RootFolder}&BucketName=${props?.TenantInfo.BucketName}&ActivityType=${activityType}`;
    let groupMenuName = props?.mode == "ModuleDirect" ? "CourseManagement" : "ActivityManagement";
    let menuId = props?.mode == "ModuleDirect" ? "300406" : "500002"
    let presignedHeader = { method: "GET", headers: {   authorizationtoken:     props?.user.signInUserSession.accessToken.jwtToken,   defaultrole: props?.TenantInfo.UserGroup,   groupmenuname: groupMenuName,   menuid: menuId, },};
    let finalStatus = await APIGatewayGetRequest(fetchURL, presignedHeader);
    let finalFileResponse = await finalStatus?.res?.text();
    let keyValue = finalFileResponse && finalFileResponse?.substring(1)
    let filePathDate = props?.mode == "ModuleDirect" ? finalFileResponse && (finalFileResponse).split("/")[8] : finalFileResponse && (finalFileResponse).split("/")[7];
    let finalFileName = props?.mode == "ModuleDirect" ? finalFileResponse && (finalFileResponse).split("/")[10] : finalFileResponse && (finalFileResponse).split("/")[9];
    let stateMachineArn = process.env.STEP_FUNCTION_ARN_OFFLINE_QUIZ;
    let randomId = Math.random().toString().substring(2, 10)
    let convertUrl = process.env.APIGATEWAY_URL_QUIZ_TEMPLATE_UPLOAD + `?S3KeyName=${props?.TenantInfo.RootFolder}/${props?.TenantInfo.TenantID}&S3BucketName=${props?.TenantInfo.BucketName}`;
    let activityJsonSaveData = '{"TenantId":  "' + props?.TenantInfo.TenantID + '","RandomID": "' + randomId + '", "ActivityType": "' + activityType + '","Type": "OfflineQuiz","CourseID": ' + null + ' , "Filename": "' + finalFileName + '","ActivityID": "' + activityId + '", "BucketName":"' + props?.TenantInfo.BucketName + '","RootFolder":"' + props?.TenantInfo.RootFolder + '" ,"Date":"' + filePathDate + '" ,"Key":"' + keyValue + '","BatchID":' + null + ', "Adminusersub": "' + userSub + '"}';
    let courseJsonSaveData = '{"TenantId":  "' + props?.TenantInfo.TenantID + '","RandomID": "' + randomId + '","ActivityType": "' + activityType + '","CourseID": "' + props?.CourseID + '","ModuleID": "' + props?.ModuleID + '","BatchID": "' + watch("ddlBatch") + '" ,"Type": "OfflineQuiz", "Filename": "' + finalFileName + '","ActivityID": "' + activityId + '", "BucketName":"' + props?.TenantInfo.BucketName + '","RootFolder":"' + props?.TenantInfo.RootFolder + '" ,"Date":"' + filePathDate + '" , "Key": "' + keyValue + '", "Adminusersub": "' + userSub + '" }';
    let jsonSaveData = props?.mode == "ModuleDirect" ? courseJsonSaveData : activityJsonSaveData
    

    let headers = { method: "POST", headers: {   "Content-Type": "application/json",   Authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,   defaultrole: props?.TenantInfo.UserGroup,   groupmenuname: "ActivityManagement",   menuid: "500012",   statemachinearn: stateMachineArn, }, body: jsonSaveData,};
    let finalResult = await APIGatewayPostRequest(convertUrl, headers);
    finalResponse(finalResult.Status);
    setValue("submit", false);
    clearForm();
  };

  const dateCoversion = (date) => {
    let dateTime = new Date(date);
    let dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + dateTime.getDate() + "T" + (dateTime.getHours() < 10 ? "0" : "") + dateTime.getHours() + ":" + (dateTime.getMinutes() < 10 ? "0" : "") + dateTime.getMinutes();
    let splitdate = dateTimeString.split("-")[2][1] == "T" ? dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-0" + dateTime.getDate() + "T" + (dateTime.getHours() < 10 ? "0" : "") + dateTime.getHours() + ":" + (dateTime.getMinutes() < 10 ? "0" : "") + dateTime.getMinutes() : dateTimeString;
    return splitdate;
  };

  const courseEndDate = useRef();
  let dateExceed = useMemo(() => {
    let exceeded;
    if (props?.mode == "ModuleDirect") {
      courseEndDate.current = props?.CourseData?.EndDateTime
      if ((fetchedQuizData?.ActivityData?.EndDate != undefined || fetchedQuizData?.ActivityData?.EndDate != null) && dateCoversion(fetchedQuizData?.ActivityData?.EndDate) < dateCoversion(new Date())) {
        exceeded = true;
      }
      if (courseEndDate.current != "" && GetDateFormat(courseEndDate.current, "±YYYYYY-MM-DDTHH:mm:ss") < new Date()) {
        exceeded = true;
      }
    } else {
      if (fetchedQuizData?.ActivityData?.EndDate != undefined || fetchedQuizData?.ActivityData?.EndDate != null) {
        if (dateCoversion(fetchedQuizData?.ActivityData?.EndDate) < dateCoversion(new Date())) {
          exceeded = true;
        }
      } else {
        exceeded = false;
      }
    }
    return exceeded;
  }, [fetchedQuizData?.ActivityData?.EndDate, props?.CourseData, props?.mode])

  let messageArray = useMemo(() => {
    let array = [{ Expiry: `${(GetDateFormat(courseEndDate.current, "±YYYYYY-MM-DDTHH:mm:ss") < new Date()) ? "Course" : "Activity"} is expired.`, Enroll: `${props?.mode == "ModuleDirect" ? "Course" : "Activity"} is not enrolled for any users.` }]
    return array;
  }, [props?.mode])

  let content = useMemo(() => {
    let messageContent;
    messageArray?.map((item) => {
      if (fetchedQuizData?.EnrolledUser && fetchedQuizData?.EnrolledUser.length == 0 && dateExceed == true) {
        messageContent = item.Enroll + " Also " + item.Expiry
      } else if (dateExceed == true) {
        messageContent = item.Expiry
      } else if ((fetchedQuizData?.EnrolledUser && fetchedQuizData?.EnrolledUser.length == 0)) {
        messageContent = item.Enroll
      }
    })
    return messageContent;
  }, [dateExceed, messageArray, fetchedQuizData?.EnrolledUser])
  let Warning = ((fetchedQuizData?.EnrolledUser && fetchedQuizData?.EnrolledUser.length == 0) || dateExceed == true) ? true : false;

  // Bread Crumbs
  const pageRoutes = [
    { path: props?.mode == "ModuleDirect" ? `/CourseManagement/ModulesList?CourseID=${props?.CourseID}` : "/ActivityManagement/ActivityList", breadcrumb: props.mode == "ModuleDirect" ? "Manage Course" : "Activity Management"},
    { path: "", breadcrumb: "Offline Quiz Grade" }
  ];
  
  return (
    <>
      <Container title="OfflineQuiz" loader={fetchedQuizData == undefined} PageRoutes={pageRoutes}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(uploadHandler)} id="Formjs">
          {Warning == true && <NVLWarning Header={"Upload is not possible..!"} Content={`${content} Hence, upload cannot be done. Please, contact administrator for further details. `} />}
          <div className={`nvl-FormContent ${Warning == true ? "pointer-events-none" : ""} `}>
            <div className="pt-12">
              <div className={props.mode != "ModuleDirect" ? "hidden" : ""}>
                <NVLSelectField id="ddlBatch" labelText="Batch Name" labelClassName="nvl-Def-Label" className="nvl-mandatory nvl-Def-Input " options={batchName} errors={errors} disabled={watch("submit") || watch("File") == "Uploading" || props.mode != "ModuleDirect" ? true : false} register={register} />
              </div>
              <NVLlabel text="Upload File" className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: .csv <br>File size should be 5MB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
              <div className={`${watch("File") == "Uploading" || watch("submit") ? "pointer-events-none" : ""} `}>
                <NVLFileUpload id="getFile" text={fileValues.TextName == null ? "Select File" : fileValues.TextName} accept={`${"Acceptable file format: .csv<br>File size should not exceed more than 50KB"}`} ButtonType="success" onChange={(e) => fileValidation(e)}></NVLFileUpload>
                <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
              </div>
              <div className={"Center-Aligned-Items {invalid-feedback} text-red-500 text-sm "}>{errors?.File?.message}</div>
              <div className="flex my-4 justify-between">
                <NVLlabel text={"Download sample file"} className="nvl-Def-Label my-auto" />
                <NVLButton text={"Download"} type={"button"} className="bg-primary nvl-button rounded-2xl text-white" disabled={watch("File") == "Uploading" || watch("submit") ? true : false} onClick={(e) => downloadCsvFile(e)} />
              </div>
              <div className="flex gap-4 pt-4 justify-center">
                <NVLButton text={!watch("submit") ? "Upload" : ""} type={"submit"} disabled={watch("File") == "Uploading" || watch("submit") ? true : false}
                  className={props?.ButtonClassName ? props?.ButtonClassName : `w-24 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`} ButtonType="success" >
                  {watch("submit") && (<i className="fa fa-circle-notch fa-spin mr-2"> </i>)}
                </NVLButton>
                <NVLButton id="btnCancel" text={"Reset"} type="button" disabled={watch("File") == "Uploading" || watch("submit") ? true : false} className="w-24 nvl-button" onClick={() => clearForm()} />
              </div>
            </div>
          </div>
        </form>
      </Container>
    </>
  )
}

export default OfflineQuiz;
