import NVLCheckbox from '@components/Controls/NVLCheckBox';
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLSelectField from "@components/Controls/NVLSelectField";
import Container from "@Container/Container";
import NVLButton from "@Controls/NVLButton";
import NVLGridTable from "@Controls/NVLGridTable";
import NVLlabel from "@Controls/NVLlabel";
import NVLRadio from "@Controls/NVLRadio";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayGetRequest, APIGatewayPostRequest } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function QuizResponse(props) {
    const router = useRouter();
    const [activePage, setActivePage] = useState("");
    const refScoreWiseReportID = useRef();
    const refQuestionWiseReportID = useRef();
    const [scoreWiseReport, setScoreWiseReport] = useState();
    const [questionWiseReport, setQuestionWiseReport] = useState();


    useEffect(() => {
        async function fetchData() {           
            let queryVal;
            if (props.CourseID != undefined) {
                queryVal = `?ActivityID=${router.query["ActivityID"]}&TenantID=${props.TenantInfo.TenantID}&QuizFilter=Both&BucketName=${props.BucketName}&RootFolder=${props.RootFolder}`;
            }
            else {
                queryVal = `?ActivityID=${router.query["ActivityID"]}&TenantID=${props.TenantInfo.TenantID}&QuizFilter=Both&BucketName=${router.query["BucketName"]}&RootFolder=${router.query["RootFolder"]}`;
            }
            let getQuestionWiseScoreReportData = await APIGatewayGetRequest(process.env.REPORT_SCORE_WISE_ASSESSMENT + queryVal,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    }
                });

            let getQuestionScoreData = await getQuestionWiseScoreReportData?.res?.text();
            let getQuestionWiseReportData = await APIGatewayGetRequest(process.env.REPORT_QUESTION_WISE_ASSESSMENT + queryVal , { method: "GET", headers: { "Content-Type": "application/text", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, }, });
            let getQuestionWiseReport = await getQuestionWiseReportData?.res?.text();
            setScoreWiseReport((getQuestionScoreData != undefined && getQuestionScoreData != "No Records Found") && JSON.parse(getQuestionScoreData))
            setQuestionWiseReport(getQuestionWiseReport != undefined && getQuestionWiseReport != "No Records Found") && JSON.parse(getQuestionWiseReport)
        }
        fetchData()
        return (() => {
            setScoreWiseReport((temp) => { return { ...temp } })
            setQuestionWiseReport((temp) => { return { ...temp } })
        })
    }, [props.BucketName, props.CourseID, props.RootFolder, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query])

    const validationSchema = Yup.object().shape({})
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, formState, watch, reset } = useForm(formOptions);
    const { errors } = formState;

    const headerColumn = useMemo(() => {
        let header;
        let scoreHeader = [
            { HeaderName: "User Name", Columnvalue: "ScoreUserName", HeaderCss: "w-1/6" },
            { HeaderName: "EmailID", Columnvalue: "ScoreEmailID", HeaderCss: "w-1/6" },
            { HeaderName: "Status", Columnvalue: "ScoreStatus", HeaderCss: "w-1/6" },
            { HeaderName: "Start Date", Columnvalue: "StartedOn", HeaderCss: "w-1/6" },
            { HeaderName: "Completion Date", Columnvalue: "CompletedOn", HeaderCss: "w-1/6" },
            { HeaderName: "Time Taken", Columnvalue: "TimeTaken", HeaderCss: "w-1/6" },
            // { HeaderName: "Grade", Columnvalue: "ScoreGrade", HeaderCss: "w-1/6" },
        ];

        let questionWiseHeader = [
            { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/6" },
            { HeaderName: "EmailID", Columnvalue: "EmailID", HeaderCss: "w-1/6" },
            { HeaderName: "State", Columnvalue: "Status", HeaderCss: "w-1/6" },
            { HeaderName: "Grade", Columnvalue: "Grade", HeaderCss: "w-1/6" },
        ];

        if (activePage == "" || activePage == "Question") {
            (questionWiseReport) && Object.values(questionWiseReport)?.forEach((item, index) => {
                if ((activePage == "" || activePage == "Question")) {
                    item[index]?.Questionsdata && Object.values(item[index]?.Questionsdata).forEach((element, idx) => {
                        questionWiseHeader.push({
                            HeaderName: `Question ${idx == 0 ? 1 : idx + 1}`, Columnvalue: `Q${idx}`,
                        },
                            { HeaderName: `Response ${idx == 0 ? 1 : idx + 1}`, Columnvalue: "Response" + index, HeaderCss: "w-1/6" },
                            { HeaderName: `Right Answer ${idx == 0 ? 1 : idx + 1}`, Columnvalue: "RightAnswer" + index, HeaderCss: "w-1/6" },
                        )
                    });
                }
            })

        }
        else {
            (scoreWiseReport) && Object.values(scoreWiseReport)?.forEach((item, index) => {

                if ((activePage == "" || activePage == "Score")) {
                    item[index]?.Questionsdata && Object.values(item[index]?.Questionsdata).forEach((element, idx) => {
                        scoreHeader.push({
                            HeaderName: `Q${idx == 0 ? 1 : idx + 1} / ${(item[index]?.Questionsdata[idx]?.QuestionMark ||
                                element?.Questionsdata?.[0]?.YourMark) ?? 0}`, Columnvalue: `Q${idx}`
                        })
                    });
                }
            })
        }

        let filterStatus = watch("chkQuestionText") && watch("chkResponse") && watch("chkRightAnswer")
        header = (activePage == "" || activePage == "Question") ? questionWiseHeader : scoreHeader
        let filteredData = questionWiseHeader;

        if ((activePage == "" || activePage == "Question") && !filterStatus) {
            if (watch("chkQuestionText")) {
                filteredData = header.filter(item => !item.HeaderName.startsWith('Response') &&
                    !item.HeaderName.startsWith('Right Answer'));
            }
            if (watch("chkResponse")) {
                filteredData = header.filter(item => !item.HeaderName.startsWith('Question') &&
                    !item.HeaderName.startsWith('Right Answer')
                );
            }
            if (watch("chkRightAnswer")) {
                filteredData = header.filter(item => !item.HeaderName.startsWith('Question') &&
                    !item.HeaderName.startsWith('Response')
                );
            }
            if (watch("chkQuestionText") && watch("chkResponse")) {
                filteredData = header.filter(item => !item.HeaderName.startsWith('Right Answer'));
            }
            if (watch("chkRightAnswer") && watch("chkResponse")) {
                filteredData = header.filter(item => !item.HeaderName.startsWith('Question'));
            }
            if (watch("chkQuestionText") && watch("chkRightAnswer")) {
                filteredData = header.filter(item => !item.HeaderName.startsWith('Response'));
            }
            header = filteredData
        }
        return header;
    }, [activePage, questionWiseReport, scoreWiseReport, watch])

    const scoreWiseGridDataBind = useCallback(() => {
        let rowGrid = [];
        let staticColumns = [], dynamicColumns = [];
        refScoreWiseReportID.current = scoreWiseReport?.QuizResponse;
        if (activePage == "" || activePage == "Score") {
            (scoreWiseReport) && Object.values(scoreWiseReport)?.[0]?.map((item, index) => {
                item?.Questionsdata && Object.values(item?.Questionsdata).map((items, idx) => {
                    dynamicColumns.push({ [`Q${idx}`]: <NVLlabel text={items.YourMark} /> })
                })
                staticColumns.push({
                    ScoreUserName: <NVLlabel text={item.UserName} className="py-2" />,
                    ScoreEmailID: <NVLlabel text={item.EmailID} />,
                    ScoreStatus: <NVLlabel text={item.Status} />,
                    StartedOn: <NVLlabel text={item.StartedOn} />,
                    CompletedOn: <NVLlabel text={item.CompletedOn} />,
                    TimeTaken: <NVLlabel text={item.TimeTaken} />,
                    // ScoreGrade: <NVLlabel text={item.Grade} className="" />
                })

                if (typeof staticColumns[index] !== 'undefined' && staticColumns[index] !== null) {
                    rowGrid.push(Object.assign(staticColumns[index], ...dynamicColumns));
                } else {
                    rowGrid.push({ StaticColumns: staticColumns });
                }
            })
        }

        return rowGrid
    }, [activePage, scoreWiseReport]);

    const questionWiseGridDataBind = useCallback(() => {
        let rowGrid = [], staticColumns = [], dynamicColumns = [];
        refQuestionWiseReportID.current = questionWiseReport?.QuizResponse;
        if (activePage == "" || activePage == "Question") {
            (questionWiseReport) && Object.values(questionWiseReport)?.[0]?.map((item, index) => {
                item?.Questionsdata && Object.values(item?.Questionsdata).map((items, idx) => {
                    dynamicColumns.push({
                        [`Q${idx}`]: <NVLlabel text={items?.Question?.replace(/(<([^>]+)>)/gi, "")} className="py-2" />,
                        [`Response${idx}`]: <NVLlabel text={items?.YourAns} className="py-2" />,
                        [`RightAnswer${idx}`]: <NVLlabel text={items?.ActualAns} className="py-2" />
                    }
                    )
                })
                staticColumns.push({
                    UserName: <NVLlabel text={item.UserName} className="py-2" />,
                    EmailID: <NVLlabel text={item.EmailID} className="py-2" />,
                    Status: <NVLlabel text={item.Status} className="py-2" />,
                    StartedOn: <NVLlabel text={item.StartedOn} className="py-2" />,
                    CompletedOn: <NVLlabel text={item.CompletedOn} className="py-2" />,
                    TimeTaken: <NVLlabel text={item.TimeTaken} className="py-2" />,
                    Grade: <NVLlabel text={item.Grade} className="py-2" />,
                })
                if (typeof staticColumns[index] !== 'undefined' && staticColumns[index] !== null) {
                    rowGrid.push(Object.assign(staticColumns[index], ...dynamicColumns));
                } else {
                    rowGrid.push({ StaticColumns: staticColumns });
                }
            })
        }

        return rowGrid
    }, [activePage, questionWiseReport])

    const pageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity List" },
        { path: "", breadcrumb: "Quiz Response" }

    ];

    const CompletionStatus = useMemo(() => {
        return [
            { value: "UserAttempted", text: "Users who have attempted the quiz" },
            { value: "UserNotAttempted", text: "Users who have not attempted the quiz" },
            { value: "AllUsers", text: "All the users who have and have not attempted the quiz." }]

    }, [])

    const questionstatus = useMemo(() => {
        return [
            { value: "No", text: "No" },
            { value: "Yes", text: "Yes" }]
    }, [])


    async function fileDownload(e, Mode) {
        
        let fetchURL = process.env.APIGATEWAY_INVOKEURL;
        let bucketName;
        if(props.CourseID != undefined){
            bucketName = props.BucketName
        }
        else{
            bucketName = router.query["BucketName"]   
        }
        let headers = { method: "POST", headers: { "Content-Type": "text/csv", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, bucketName: bucketName, }, body: Mode == "Score" ? refScoreWiseReportID.current : refQuestionWiseReportID.current, };
        let finalStatus = await APIGatewayPostRequest(fetchURL, headers);
        let finalResponse = await finalStatus.res.text();
        var win = window.open(finalResponse, '_blank');
    }

    const showReportHandler = useCallback(async () => {
      let queryVal;
      if(props.CourseID != undefined){
          queryVal =`?ActivityID = ${ router.query["ActivityID"] }& TenantID=${ props?.TenantInfo.TenantID }& QuizFilter=${ watch("rbFilterAttempts") }& BucketName=${ props.BucketName}& RootFolder=${ props.RootFolder}`
      }
      else{
          queryVal =`?ActivityID = ${ router.query["ActivityID"] }& TenantID=${ props?.TenantInfo.TenantID }& QuizFilter=${ watch("rbFilterAttempts") }& BucketName=${ router.query["BucketName"] }& RootFolder=${ router.query["RootFolder"] }`
      }
        let getReportData, getFinalReportData;
        setValue("fetch", true);
        try {
            getReportData = await APIGatewayGetRequest(activePage == "" || activePage == "Score" ? process.env.REPORT_SCORE_WISE_ASSESSMENT + queryVal : process.env.REPORT_QUESTION_WISE_ASSESSMENT + queryVal, { method: "GET", headers: { "Content-Type": "application/text", authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken, }, });
            getFinalReportData = await getReportData?.res?.text();
        } catch (error) {
            console.log("Something went wrong", error);
        }

        if ((activePage == "" || activePage == "Score")) {
            setScoreWiseReport(getFinalReportData != undefined && JSON.parse(getFinalReportData))

        } else {
            setQuestionWiseReport(getFinalReportData != undefined && JSON.parse(getFinalReportData))

        }
        setValue("fetch", false);

    }, [props.CourseID, props?.TenantInfo.TenantID, props.BucketName, props.RootFolder, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue, activePage, router.query, watch])

    return (
        <>
            <Container title="Analytics And Reports" loader={scoreWiseReport == undefined || questionWiseReport == undefined} PageRoutes={pageRoutes} >
                <form onSubmit={handleSubmit(showReportHandler)}>
                    <div className="flex gap-2 px-3">
                        <NVLButton id="btnCancel" text={"Question With Score"} type="reset" className={`nvl-button w-56 !font-semibold  ${activePage == "Score" ? "bg-primary text-white" : ""}`} onClick={() => { setActivePage("Score"); reset() }} />
                        <NVLButton id="btnCancel" text={"Question Wise Analytics"} type="reset" className={`nvl-button w-56 !font-semibold  ${activePage == "Question" ? "bg-primary text-white" : ""}`} onClick={() => { setActivePage("Question"); reset() }} />
                    </div>
                    {/* QuestionWise */}
                    <div className={`${(activePage == "" || activePage == "Score") ? "hidden" : ""}`}>

                        <div className="flex mb-4 px-3 pb-56">
                            <div className="w-1/3 h-12 py-4">
                                <NVLlabel htmlFor="Question" className="  block text-lg font-medium text-gray-600 py-1">
                                    What to include in the report
                                </NVLlabel>
                                <div className="pb-4">
                                    <NVLlabel className="block w-1/2 text-sm font-medium text-gray-600 " text=" Attempts that are"> </NVLlabel>
                                </div>

                                <div className="pb-4 pt-10">
                                    <NVLlabel htmlFor="Question" className="block text-lg font-medium text-gray-600 py-1">
                                        Display Options
                                    </NVLlabel>
                                </div>
                                <div className="pb-2">
                                    <NVLlabel className="nvl-Def-Label w-52" text="Show the"></NVLlabel>
                                </div>
                            </div>

                            <div className="w-2/3  h-12 pt-14">
                                {/* <div className="pb-4">
                                <NVLSelectField id="ddlCompletionStatus" errors={errors}
                                    className="  border-gray-300"
                                    placeholder="Enrollred users who have attempted the quiz"
                                    options={CompletionStatus}
                                    register={register} showFull></NVLSelectField>
                            </div> */}
                                <div className="flex items-center gap-4">
                                    <div className="pb-3">
                                        <NVLRadio
                                            text="Completed" id="rbQuestionFilter" value={'Finished'} name="rbQuestionFilter" errors={errors} register={register} setValue={setValue}
                                        ></NVLRadio>
                                    </div>
                                    <div className="pb-3">
                                        <NVLRadio
                                            text="Yet to start" id="rbQuestionFilter" value={'YetToStart'} name="rbQuestionFilter" errors={errors} register={register} setValue={setValue}
                                        ></NVLRadio>
                                    </div>
                                    <div className="pb-3">
                                        <NVLRadio
                                            text="Both" id="rbQuestionFilter" defaultChecked value={'Both'} name="rbQuestionFilter" errors={errors} register={register} setValue={setValue}
                                        ></NVLRadio>
                                    </div>
                                </div>
                                <div className="pb-3 flex items-center">
                                    <div>
                                        <NVLCheckbox
                                            text={`Show at most one finished attempt per user`} id="chkFinishedAttempt" errors={errors} register={register} setValue={setValue} showFull
                                        ></NVLCheckbox>
                                    </div>
                                    <div>
                                        <span className="text-blue-600 text-xs">(Highest grade)</span>
                                    </div>
                                </div>
                                {/* <div className="pb-4">
                                <NVLCheckbox
                                    text="that have been regraded / are marked as needing regraded" id="chkRegarded" errors={errors} register={register} setValue={setValue} showFull
                                ></NVLCheckbox>
                            </div> */}
                                <div className="pt-2 flex">
                                    <div className="pb-4 pt-12">
                                        <NVLCheckbox
                                            text="question text" id="chkQuestionText" errors={errors} register={register} setValue={setValue}
                                        ></NVLCheckbox>
                                    </div>
                                    <div className="pb-4 pt-12">
                                        <NVLCheckbox
                                            text="response" id="chkResponse" errors={errors} register={register} setValue={setValue}
                                        ></NVLCheckbox>
                                    </div>
                                    <div className="pb-4 pt-12">
                                        <NVLCheckbox
                                            text="right answer" id="chkRightAnswer" errors={errors} register={register} setValue={setValue}
                                        ></NVLCheckbox>
                                    </div>
                                </div>
                                <div className="pt-3 gap-2 flex">
                                    <div>
                                        <NVLButton id="btnSubmit" type={"submit"} className={"w-28 nvl-button bg-primary text-white gap-80"}
                                            text="Show report"  >
                                        </NVLButton>
                                    </div>
                                    <div>
                                        <NVLButton id="btnDownload" type={"button"} onClick={(e) => fileDownload(e, "Question")} className={"w-28 nvl-button bg-primary text-white gap-80"}
                                            text="Download"  >
                                        </NVLButton>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="pt-6">
                            {!watch("fetch") && <NVLGridTable id="tblQuestionWiseList" className="max-w-full"
                                HeaderColumn={headerColumn}
                                RowGridDataPass={{ RowGrid: questionWiseGridDataBind() }} />}
                        </div>
                        <div>
                            {watch("fetch") && <NVLLoadingSpinner />}
                        </div>
                    </div>

                    {/* Score */}
                    <div className={`${(activePage == "" || activePage == "Question") ? "hidden" : ""}`}>

                        <div className="flex px-3 pb-44">
                            <div className="w-1/3 h-12 py-4">
                                <NVLlabel htmlFor="Question" className="  block text-lg font-medium text-gray-600 py-1">
                                    What to include in the report
                                </NVLlabel>
                                {/* <div className="pb-4">
                                <NVLlabel htmlFor="Question" className="  block text-sm font-medium text-gray-600 py-1">
                                    Attemps from
                                </NVLlabel>
                            </div> */}

                                <div className="pb-4">
                                    <NVLlabel className="block w-1/2 text-sm font-medium text-gray-600 " text=" Attempts that are"> </NVLlabel>
                                </div>

                                {/* <div className="pb-6">
                                <NVLlabel htmlFor="size" className="block w-1/2 text-sm font-medium text-gray-600 py-1">
                                    Show only attempts
                                </NVLlabel>
                            </div> */}

                                <div className="pb-4 pt-14">
                                    <NVLlabel htmlFor="Question" className="block text-sm font-medium text-gray-600 py-1">
                                        Marks for each question
                                    </NVLlabel>
                                </div>

                            </div>

                            <div className="w-2/3  h-12 pt-14">
                                {/* <div className="pb-4">
                                <NVLSelectField id="ddlScoreCompletion" errors={errors}
                                    className="  border-gray-300"
                                    placeholder="Enrollred users who have attempted the quiz"
                                    options={CompletionStatus}
                                    register={register} showFull></NVLSelectField>
                            </div> */}
                                <div className="flex items-center gap-4">
                                    <div className="pb-4">
                                        <NVLRadio
                                            text="Completed" id="rbFilterAttempts" value={"Finished"} name="rbFilterAttempts" errors={errors} register={register} setValue={setValue}
                                        ></NVLRadio>
                                    </div>
                                    <div className="pb-4">
                                        <NVLRadio
                                            text="Yet to start" id="rbFilterAttempts" value={"YetToStart"} name="rbFilterAttempts" errors={errors} register={register} setValue={setValue}
                                        ></NVLRadio>
                                    </div>
                                    <div className="pb-4">
                                        <NVLRadio
                                            text="Both" id="rbFilterAttempts" defaultChecked value={"Both"} name="rbFilterAttempts" errors={errors} register={register} setValue={setValue}
                                        ></NVLRadio>
                                    </div>

                                </div>
                                <div className="pb-4 flex items-center">
                                    <div>
                                        <NVLCheckbox
                                            text={`Show at most one finished attempt per user`} id="chkCompleteTheActivity" errors={errors} register={register} setValue={setValue} showFull
                                        ></NVLCheckbox>
                                    </div>
                                    <div>
                                        <span className="text-blue-600 text-xs">(Highest grade)</span>
                                    </div>
                                </div>
                                {/* <div className="pb-4">
                                <NVLCheckbox
                                    text="that have been regraded / are marked as needing regraded." id="chkCompleteTheActivity" errors={errors} register={register} setValue={setValue} showFull
                                ></NVLCheckbox>
                            </div> */}
                                <div className="pt-2">
                                    <NVLSelectField id="ddlScoreStatus" errors={errors}
                                        className="mt-1 block w-44 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"
                                        options={questionstatus}
                                        register={register}></NVLSelectField>
                                </div>
                                <div className="pt-5 gap-2 flex">
                                    <div>
                                        <NVLButton id="btnScoreSubmit" type={"submit"} className={"w-28 nvl-button bg-primary text-white gap-80"}
                                            text="Show report"  >
                                        </NVLButton>
                                    </div>
                                    <div>
                                        <NVLButton id="btnScoreDownload" onClick={(e) => fileDownload(e, "Score")} type={"button"} className={"w-28 nvl-button bg-primary text-white gap-80"}
                                            text="Download"  >
                                        </NVLButton>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="pt-4">
                            {/* {!watch("fetch") && */}
                            <NVLGridTable id="tblScoreList" className="max-w-full"
                                HeaderColumn={headerColumn}
                                RowGridDataPass={{ RowGrid: scoreWiseGridDataBind() }
                                } />
                            {/* } */}

                        </div>
                        <div>
                            {watch("fetch") && <NVLLoadingSpinner />}
                        </div>
                    </div>
                </form>
            </Container>
        </>
    )
}

export default QuizResponse
