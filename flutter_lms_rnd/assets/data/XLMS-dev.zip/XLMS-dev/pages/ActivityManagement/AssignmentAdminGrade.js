import NVLFileList from "@Pages/ActivityManagement/CommonActivitySettings/NVLFileList";
import Container from "@components/Container/Container";
import NVLFileViewer from "@components/Controls/NVLFileViewer";
import { createXlmsUserCertificateInfo } from "@graphql/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseEnrollUser, getXlmsCourseManagementInfo, getXlmsCourseModule, getXlmsEnrollUser, listXlmsActivityEnrollPageTypelistInfo, listXlmsCourseEnrollPageTypelistInfo } from "@graphql/graphql/queries";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useRef, useState } from "react";

export default function AssignmentAdminGrade(props) {
  const router = useRouter();
  const token = useRef({ next: true, prev: true })
  const [data, setData] = useState({ index: 0, list: [], name: "", GradeOption: "", passgrade: "" });
  const [filesource, setFileSource] = useState({ fullview: false, popup: false, filepath: 0, files: [] })

  const pageRoutes = (router.query.CourseID !== undefined) ? [
    { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
    { path: `/CourseManagement/ModulesList?CourseID=${router.query.CourseID}`, breadcrumb: "Manage Course" },
    { path: `/CourseManagement/AssignmentAdminPage?CourseID=${router.query.CourseID}&ModuleID=${router.query.ModuleID}&ActivityID=${router.query.ActivityID}`, breadcrumb: "Assignment Admin" },
    { path: ``, breadcrumb: "Assignment Grade" }
  ] : [
    { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
    { path: `/ActivityManagement/AssignmentAdminPage?ActivityID=${router.query.ActivityID}`, breadcrumb: "Assignment Admin" },
    { path: "", breadcrumb: "Assignment Grade" }
  ];

  const next = async () => {
    if (data.index < data.list.length - 1) {
      setData(prev => ({ ...prev, index: prev.index + 1 }));
    }
    else if (token.current.next) {
      if(router.query["CourseID"]!==undefined)
      {
        const response=await AppsyncDBconnection(listXlmsCourseEnrollPageTypelistInfo,{GsiPK:"TENANT#"+props.TenantInfo.TenantID+"#COURSEID#"+router.query["CourseID"],GsiSK:"BATCH#"+router.query["BatchID"]+"#COURSE#ENROLLUSER#"+data.list[data.index].UserSub,BatchID:router.query["BatchID"], PageType: "Next", limit: "10" },props.user.signInUserSession.accessToken.jwtToken);
        if(response?.res?.listXlmsCourseEnrollPageTypelistInfo?.items!==undefined&&response?.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length>0)
        {
          setData(prev=>({...prev,index:prev?.list?.length,list:[...prev.list,...response?.res?.listXlmsCourseEnrollPageTypelistInfo?.items]}))
        }
        if(response?.res?.listXlmsCourseEnrollPageTypelistInfo?.nextToken===null||response?.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length<10)
        {
          token.current.next = false
        }
      }
      else
      {
        const response = await AppsyncDBconnection(listXlmsActivityEnrollPageTypelistInfo, { GsiPK: "ACTIVITYID#" + router.query["ActivityID"], GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#" + data.list[data.index].UserSub, PageType: "Next", limit: "10" }, props.user.signInUserSession.accessToken.jwtToken)
        if(response?.res?.listXlmsActivityEnrollPageTypelistInfo?.items!==undefined)
        {
          setData(prev => ({ ...prev, index: prev.list.length, list: [...prev.list, ...response?.res?.listXlmsActivityEnrollPageTypelistInfo?.items] }))
        }
        if (response?.res?.listXlmsActivityEnrollPageTypelistInfo?.nextToken === null) {
          token.current.next = false;
        }
      }
    }
    setFileSource(prev=>({...prev,filepath:0}))
  }

  const prev = async () => {
    if (data.index != 0) {
      setData(prev => ({ ...prev, index: prev.index - 1 }));
    }
    else if (token.current.prev) {
      if(router.query["CourseID"]!==undefined)
      {
        const response=await AppsyncDBconnection(listXlmsCourseEnrollPageTypelistInfo,{GsiPK:"TENANT#"+props.TenantInfo.TenantID+"#COURSEID#"+router.query["CourseID"],GsiSK:"BATCH#"+router.query["BatchID"]+"#COURSE#ENROLLUSER#"+data.list[data.index].UserSub,BatchID:router.query["BatchID"], PageType: "", limit: "10" },props.user.signInUserSession.accessToken.jwtToken)
        if(response.res?.listXlmsCourseEnrollPageTypelistInfo?.nextToken===null||response?.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length<10)
        {
          token.current.prev = false;
        }
        if(response.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length>0&&response.res?.listXlmsCourseEnrollPageTypelistInfo?.items!==undefined)
        {
          let temp=[...response.res?.listXlmsCourseEnrollPageTypelistInfo?.items]
          temp.reverse();
          setData(prev=>({...prev,list:[...temp,...prev.list],index:response.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length-1}))
        }
      }
      else
      {
        const response = await AppsyncDBconnection(listXlmsActivityEnrollPageTypelistInfo, { GsiPK: "ACTIVITYID#" + router.query["ActivityID"], GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#" + data.list[0].UserSub, PageType: "", limit: "10" }, props.user.signInUserSession.accessToken.jwtToken)
        if (response?.res?.listXlmsActivityEnrollPageTypelistInfo?.nextToken === null) {
          token.current.prev = false;
        }
        if (response?.res?.listXlmsActivityEnrollPageTypelistInfo?.items?.length > 0) {
          let temp = [...response?.res?.listXlmsActivityEnrollPageTypelistInfo?.items]
          temp.reverse();
          setData(prev => ({ ...prev, list: [...temp, ...prev.list], index: response?.res?.listXlmsActivityEnrollPageTypelistInfo?.items.length - 1 }))
        }
      }
      }
    setFileSource(prev=>({...prev,filepath:0}))
  }
  const generateCertificate = useCallback(async () => {
    if (props?.TenantInfo?.TenantID == undefined) {
        return;
    }
    if (router.query["CourseID"] != undefined) {
        AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSEBADGE#" + router?.query?.["CourseID"] }, props?.user.signInUserSession.accessToken.jwtToken).then((QueryData) => {
            if (QueryData?.res?.getXlmsCourseManagementInfo != undefined) {
                const variables = {
                    input: {
                        PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + data.list?.[data.index]?.UserSub,
                        SK: "BADGE#" + router?.query?.["CourseID"],
                        CertificateImagePath: QueryData?.res?.getXlmsCourseManagementInfo?.BadgeUploadFile,
                        BadgeName: QueryData?.res?.getXlmsCourseManagementInfo?.BadgeName,
                        IsAvailable: true
                    }
                };
                AppsyncDBconnection(createXlmsUserCertificateInfo, variables, props?.user.signInUserSession.accessToken.jwtToken);
            }
        });
        AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSECERTIFICATE#" + router?.query?.["CourseID"] }, props?.user.signInUserSession.accessToken.jwtToken).then((QueryData) => {
            if (QueryData?.res?.getXlmsCourseManagementInfo != undefined && data?.list?.[data?.index]?.CertificatePath == undefined) {
                const fetchURL = `${process.env.APIGATEWAY_URL_SCORMFILEUPlOAD}?S3BucketName=${props?.TenantInfo?.BucketName}&S3KeyName=${props?.TenantInfo?.RootFolder}`;
                const statemachinearn = process.env.STEP_FUNCTION_ARN_CERTIFICATE_GENERATION;
                const json = {
                    "TenantID": props?.TenantInfo?.TenantID,
                    "UserSub": data.list?.[data.index]?.UserSub,
                    "CourseID": router?.query?.["CourseID"],
                    "BatchID": router?.query?.["BatchID"],
                    "ActivityType": "",
                    "ActivityID": ""
                };
                const headers = {
                    method: "POST",
                    headers: {
                        authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
                        defaultrole: props?.TenantInfo?.UserGroup,
                        groupmenuname: "ActivityManagement",
                        menuid: "500013",
                        statemachinearn: statemachinearn
                    },
                    body: JSON.stringify(json),
                };
                APIGatewayPostRequest(fetchURL, headers);
            }
        });
    }
    else {
        AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#Assignment#ACTIVITYID#" + router.query["ActivityID"]},
            props?.user.signInUserSession.accessToken.jwtToken).then((QueryData) => {
                if (QueryData?.res?.getXlmsActivityManagementInfo?.BadgeUploadFile != undefined) {
                    const variables = {
                        input: {
                            PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + data.list?.[data.index]?.UserSub,
                            SK: "BADGE#" +  router.query["ActivityID"],
                            CertificateImagePath: QueryData?.res?.getXlmsActivityManagementInfo?.BadgeUploadFile,
                            BadgeName: QueryData?.res?.getXlmsActivityManagementInfo?.BadgeName,
                            IsAvailable: true
                        }
                    };
                    AppsyncDBconnection(createXlmsUserCertificateInfo, variables, props?.user.signInUserSession.accessToken.jwtToken);
                }
                if (QueryData?.res?.getXlmsActivityManagementInfo?.CertificateTemplate != undefined && data?.list?.[data?.index]?.CertificatePath == undefined) {
                    const fetchURL = `${process.env.APIGATEWAY_URL_SCORMFILEUPlOAD}?S3BucketName=${props?.TenantInfo?.BucketName}&S3KeyName=${props?.TenantInfo?.RootFolder}`;
                    const statemachinearn = process.env.STEP_FUNCTION_ARN_CERTIFICATE_GENERATION;
                    const json = {
                        "TenantID": props?.TenantInfo?.TenantID,
                        "UserSub": data.list?.[data.index]?.UserSub,
                        "CourseID": "",
                        "BatchID": "",
                        "ActivityType":"Assignment",
                        "ActivityID": router.query["ActivityID"]
                    };
                    const headers = {
                        method: "POST",
                        headers: {
                            authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
                            defaultrole: props?.TenantInfo?.UserGroup,
                            groupmenuname: "ActivityManagement",
                            menuid: "500013",
                            statemachinearn: statemachinearn
                        },
                        body: JSON.stringify(json),

                    };
                    APIGatewayPostRequest(fetchURL, headers);
                }
            });
    }
},[data.index, data.list, props.TenantInfo?.BucketName, props.TenantInfo?.RootFolder, props.TenantInfo.TenantID, props.TenantInfo?.UserGroup, props?.user.signInUserSession.accessToken.jwtToken, router.query])

  const DownloadFiles = useCallback(async (url) => {
      let fetchURL = process.env.APIGATEWAY_INVOKEURL;
      let headers = { method: "POST", headers: { "Content-Type": "text/csv", authorizationtoken: props.user?.signInUserSession?.accessToken?.jwtToken, bucketname: props.TenantInfo?.BucketName, }, body: url, };
      let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
      window.open(await FinalStatus.res.text(), '_blank');
    }, [props.TenantInfo?.BucketName, props.user?.signInUserSession?.accessToken?.jwtToken])

  useEffect(() => {
    if(router.query.CourseID!==undefined&&data?.list?.[data?.index]?.SubmissionAssignment!==undefined&&data?.list?.[data?.index]?.SubmissionAssignment!==null)
    {
      const file=JSON.parse(data?.list?.[data?.index]?.SubmissionAssignment)[router.query.ActivityID];
      setFileSource(prev=>({...prev,files:file}))
    }
    else
    {
      setFileSource(prev => {
        return ({ ...prev, files: data?.list?.[data.index]?.SubmissionAssignment && JSON.parse(data?.list?.[data.index]?.SubmissionAssignment) })
      })
    }
    
  }, [data.index, data, router.query.CourseID, router.query.ActivityID])

  useEffect(() => {
    const getdata = async () => {
      if(router.query["CourseID"]!==undefined)
      {
        const response=await AppsyncDBconnection(getXlmsCourseEnrollUser,{PK:"TENANT#"+props.TenantInfo.TenantID +"#COURSE#ENROLLUSER#"+router.query["UserSub"],SK:"COURSE#"+router.query["CourseID"]+"#BATCH#"+router.query["BatchID"] },props.user.signInUserSession.accessToken.jwtToken)
        const prevdata=await AppsyncDBconnection(listXlmsCourseEnrollPageTypelistInfo,{GsiPK:"TENANT#"+props.TenantInfo.TenantID+"#COURSEID#"+router.query["CourseID"],GsiSK:"BATCH#"+router.query["BatchID"]+"#COURSE#ENROLLUSER#"+router.query["UserSub"], BatchID:router.query["BatchID"],PageType: "", limit: "10" },props.user.signInUserSession.accessToken.jwtToken)
        const nextdata=await AppsyncDBconnection(listXlmsCourseEnrollPageTypelistInfo,{GsiPK:"TENANT#"+props.TenantInfo.TenantID+"#COURSEID#"+router.query["CourseID"],GsiSK:"BATCH#"+router.query["BatchID"]+"#COURSE#ENROLLUSER#"+router.query["UserSub"], BatchID:router.query["BatchID"],PageType: "Next", limit: "10" },props.user.signInUserSession.accessToken.jwtToken)
        const activity = await AppsyncDBconnection(getXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID, SK:"COURSEID#" +router.query.CourseID+"#MODULEID#"+router.query.ModuleID+"#ACTIVITYTYPE#Assignment#ACTIVITYID#" + router.query["ActivityID"] }, props.user.signInUserSession.accessToken.jwtToken)
        let temp=[];
        if(prevdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length > 0)
        {
          temp=prevdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.items;
          temp.reverse();
        }
        if(prevdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.nextToken ===null||prevdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length<10) {
          token.current.prev = false;
        }
        if(nextdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.nextToken ===null||nextdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.items?.length<10){
          token.current.next = false;
        }
        if(nextdata?.res?.listXlmsCourseEnrollPageTypelistInfo!==undefined)
        {
          setData(prev=>({
            ...prev,list:[...temp,response?.res?.getXlmsCourseEnrollUser,...nextdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.items],
            index:prevdata?.res?.listXlmsCourseEnrollPageTypelistInfo?.items.length,name:activity?.res?.getXlmsCourseModule?.ActivityName,
            GradeOption:activity?.res?.getXlmsCourseModule?.IsGradableActivity,passgrade:Number(activity?.res?.getXlmsCourseModule?.PassingGrade),
            EndDate:activity?.res?.getXlmsCourseModule?.EndDate
          }))
        }
        
        if(response?.res?.getXlmsCourseEnrollUser?.SubmissionAssignment!==undefined&&response?.res?.getXlmsCourseEnrollUser?.SubmissionAssignment!==null)
        {
          if(JSON.parse(response?.res?.getXlmsCourseEnrollUser?.SubmissionAssignment).hasOwnProperty(router.query.ActivityID))
          {
            let files=JSON.parse(response?.res?.getXlmsCourseEnrollUser?.SubmissionAssignment)[router.query.ActivityID]
            setFileSource(prev=>({...prev,files:files}))
          }
        }
      }
      else{
        const response = await AppsyncDBconnection(getXlmsEnrollUser, { PK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#" + router.query["UserSub"], SK: "ACTIVITYID#" + router.query["ActivityID"] }, props.user.signInUserSession.accessToken.jwtToken);
      const prevdata = await AppsyncDBconnection(listXlmsActivityEnrollPageTypelistInfo, { GsiPK: "ACTIVITYID#" + router.query["ActivityID"], GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#" + router.query["UserSub"], PageType: "", limit: "10" }, props.user.signInUserSession.accessToken.jwtToken)
      const nextdata = await AppsyncDBconnection(listXlmsActivityEnrollPageTypelistInfo, { GsiPK: "ACTIVITYID#" + router.query["ActivityID"], GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#" + router.query["UserSub"], PageType: "Next", limit: "10" }, props.user.signInUserSession.accessToken.jwtToken)
      const activity = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#Assignment#ACTIVITYID#" + router.query["ActivityID"] }, props.user.signInUserSession.accessToken.jwtToken)
      let temp = [];
      if (prevdata?.res?.listXlmsActivityEnrollPageTypelistInfo?.items?.length > 0) {
        temp = prevdata?.res?.listXlmsActivityEnrollPageTypelistInfo?.items;
        temp.reverse();
      }
      if (prevdata?.res?.listXlmsActivityEnrollPageTypelistInfo?.nextToken === null) {
        token.current.prev = false;
      }
      if (nextdata?.res?.listXlmsActivityEnrollPageTypelistInfo?.nextToken === null) {
        token.current.next = false;
      }
      setData(prev => ({
        ...prev, list: nextdata?.res?.listXlmsActivityEnrollPageTypelistInfo?.items &&
          [...temp, response.res.getXlmsEnrollUser, ...nextdata?.res?.listXlmsActivityEnrollPageTypelistInfo?.items],
        index: prevdata?.res?.listXlmsActivityEnrollPageTypelistInfo?.items.length, name: activity?.res?.getXlmsActivityManagementInfo?.ActivityName, GradeOption: (activity?.res?.getXlmsActivityManagementInfo?.IsGradableActivity), passgrade: Number(activity?.res?.getXlmsActivityManagementInfo?.PassingGrade),
        EndDate:activity?.res?.getXlmsActivityManagementInfo?.EndDate
      }))

      if (response?.res?.getXlmsEnrollUser?.SubmissionAssignment !== undefined && response?.res?.getXlmsEnrollUser?.SubmissionAssignment !== null) {
        setFileSource((prev) => ({ ...prev, files: JSON.parse(response?.res?.getXlmsEnrollUser?.SubmissionAssignment) }))
      }}
    }
    getdata();
  }, [props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const FileView = useCallback(({data,filesource}) => {
    return (<>
      {(data?.list?.[data.index]?.SubmissionAssignment !== null && data?.list?.[data.index]?.SubmissionAssignment !== undefined && filesource?.files?.length !== 0) && <div className="w-[40%] h-full p-3 relative"><button className="absolute right-3 top-3 bg-black px-2" onClick={() => setFileSource(prev => ({ ...prev, fullview: true }))}><i className="fa fa-expand text-white" aria-hidden="true"></i></button><NVLFileViewer src={`${filesource.files && filesource?.files?.[filesource?.filepath]?.FilePath}`} /></div>}
    </>)
  }, [])
  
  if (!filesource.fullview) {
    return (<>
      <Container PageRoutes={pageRoutes} loader={data?.list?.[data.index] == undefined} title={"AdminGrade"} >
        <div className={"w-full h-auto flex justify-between gap-2"}>
          <NVLFileList data={data} filesource={filesource} prev={prev} next={next} setData={setData} setFileSource={setFileSource} prevtoken={token.current.prev} nexttoken={token.current.next}
           generateCertificate={generateCertificate} pageRoutes={pageRoutes} download={DownloadFiles} CourseID={router.query["CourseID"]} TenantInfo={props.TenantInfo} user={props.user}/>
          <FileView data={data} filesource={filesource} />
        </div>
      </Container>
    </>)
  }
  else {
    return <><div className="w-full h-full p-3 relative"><button className="absolute right-3 top-3 bg-black px-2" onClick={() => setFileSource(prev => ({ ...prev, fullview: false }))}><i className="fa fa-expand text-white" aria-hidden="true"></i></button><NVLFileViewer src={`${filesource?.files[filesource?.filepath].FilePath}`} className="!h-full" /></div></>

  }
}
