import { AssignmentActivity } from "@Pages/ActivityManagement/CommonActivitySettings/AssignmentActivity";
import { DiscussionActivity } from "@Pages/ActivityManagement/CommonActivitySettings/DiscussionActivity";
import { FeedbackActivity } from "@Pages/ActivityManagement/CommonActivitySettings/FeedbackActivity";
import { FileActivity } from "@Pages/ActivityManagement/CommonActivitySettings/FileActivity";
import { LearningBytesActivity } from "@Pages/ActivityManagement/CommonActivitySettings/LearningBytesActivity";
import { MeetingActivity } from "@Pages/ActivityManagement/CommonActivitySettings/MeetingActivity";
import { PageActivity } from "@Pages/ActivityManagement/CommonActivitySettings/PageActivity";
import { QuizActivity } from "@Pages/ActivityManagement/CommonActivitySettings/QuizActivity";
import { ScormPackageActivity } from "@Pages/ActivityManagement/CommonActivitySettings/ScormPackageActivity";
import { SurveyActivity } from "@Pages/ActivityManagement/CommonActivitySettings/SurveyActivity";
import { UrlActivity } from "@Pages/ActivityManagement/CommonActivitySettings/UrlActivity";
import { DateCoversion, GetOnlyDate } from "@Pages/ActivityManagement/CommonActivitySettings/ValidationsSchema";
import { VideoActivity } from "@Pages/ActivityManagement/CommonActivitySettings/VideoActivity";
import Container from "@components/Container/Container";
import NVLAlert, { ModalClose, ModalOpen } from "@components/Controls/NVLAlert";
import { APIGatewayGetRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { updateXlmsActivityManagementInfo, updateXlmsCourseModule, updateXlmsTrainingManagementActivityInfo } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseActivityConfig, getXlmsCourseModule, listXlmsLanguages } from "src/graphql/queries";
import PollActivity from "./CommonActivitySettings/PollActivity";

const CalendarComponent = React.forwardRef((props, ref) => (
  <PageActivity {...props} forwardedRef={ref} />
));
CalendarComponent.displayName = "CalendarComponent";

function EditActivity(props) {
  const [Page, setPageData] = useState({ ...props });

  const zoomMode = useMemo(() => {
    let zoommode;
    if (props.CourseID != undefined) {
      if (props.mode == "PreAssessment" || props.mode == "PostAssesment" || props.mode == "Feedback") {
        zoommode = "ModuleDirect"
      }
    }
    return zoommode;
  }, [props.CourseID, props.mode])



  useEffect(() => {
    const dataSource = async (i) => {
      let tenantId = props.user.attributes["custom:tenantid"];
      let tenantname = props.user.attributes["name"];
      let mode = decodeURIComponent(String(router.query["Mode"]));
      let activityId = decodeURIComponent(String(router.query["ActivityID"]));
      let activityType = decodeURIComponent(String(router.query["ActivityType"]));
      let courseData = decodeURIComponent(String(router.query["CourseData"]));
      let courseId = decodeURIComponent(String(router.query["CourseId"]));
      let moduleId = decodeURIComponent(String(router.query["ModuleId"]));

      let isUpdateData;
      if (mode == "ModuleDirect") {
        let ModuleActivityEdit = await AppsyncDBconnection(getXlmsCourseModule, { PK: "TENANT#" + tenantId, SK: "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId, }, props.user.signInUserSession.accessToken.jwtToken);
      }
      if (router?.query["ZoomActivityID"] != undefined) {
        isUpdateData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + tenantId, SK: "ACTIVITYTYPE#" + activityType + "#ZOOM#" + router.query["ZoomActivityID"] + "#" + router.query["ZoomActivityMode"] + "#ACTIVITYID#" + activityId, }, props.user.signInUserSession.accessToken.jwtToken)
      } else {
        isUpdateData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + tenantId, SK: "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId, }, props.user.signInUserSession.accessToken.jwtToken);
      }
      let recordContentData = await AppsyncDBconnection(getXlmsCourseActivityConfig, { PK: "XLMS#LEARNINGBYTES", SK: "OPTION#OptionName" }, props.user.signInUserSession.accessToken.jwtToken);
      let recordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME" }, props.user.signInUserSession.accessToken.jwtToken);
      let certContent = {};
      setPageData({
        ...props,
        ActivityID: activityId,
        ActivityType: activityType,
        TenantName: tenantname,
        mode: mode,
        certContent: certContent,
        EditData: isUpdateData.res?.getXlmsActivityManagementInfo,
        RecordContent: recordContentData?.res?.getXlmsCourseActivityConfig,
        LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
        ZoomActivityID: router?.query["ZoomActivityID"]
      })
    }
    if (props.CourseID == undefined && (Page?.mode != "TrainingEdit"))
      dataSource();
    return (() => {
      setPageData((temp) => { return { ...temp } });
    })
  }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, props, Page?.mode, router?.query])

  const languageType = useMemo(() => {
    let languageType = [{ value: "", text: "Select" }];
    if (Page?.LanguageName != undefined) {
      if (
        Object.keys(JSON.parse(Page?.LanguageName?.items[0].LanguageName)) !=
        undefined
      ) {
        Object.entries(
          JSON.parse(Page?.LanguageName?.items[0].LanguageName)
        ).forEach(([key, value]) => {
          languageType = [...languageType, { value: value, text: key }];
        });
      }
    }
    return languageType;
  }, [Page?.LanguageName]);

  const router = useRouter();
  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      if (Page.ActivityType == "Feedback") {
        let Mode = Page.mode == "ModuleDirect" ? "ModuleEdit" : "Edit";
        if (router.query["ZoomActivityID"] != undefined) {
          router.push(`/ActivityManagement/FeedbackActivityOverView?Mode=${Mode}&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page?.CourseID != "" ? Page?.CourseID : ""}&ModuleID=${Page.ModuleID != "" ? Page.ModuleID : ""}&ZoomActivityID=${Page.ZoomActivityID}&ZoomMode=${router.query["ZoomActivityMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`);
        } else {
          router.push(`/ActivityManagement/FeedbackActivityOverView?Mode=${Mode}&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page?.CourseID != "" ? Page?.CourseID : ""}&ModuleID=${Page.ModuleID != "" ? Page.ModuleID : ""}`);
        }
      }
      else if (Page.ActivityType == "Quiz") {
        if (Page.mode != "ModuleDirect") {
          if (router.query["ZoomActivityID"] != undefined) {
            router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomActivityMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
          } else {
            router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}`)
          }
        } else {
          if (router.query["ZoomActivityID"] != undefined) {
            router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page.CourseID}&ModuleID=${Page?.EditData?.ModuleID}&ZoomActivityID=${Page.ZoomActivityID}&ZoomMode=${router.query["ZoomActivityMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
          } else {
            router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page.CourseID}&ModuleID=${Page?.EditData?.ModuleID}`);
          }
        }
      } else if (Page.mode == "ModuleDirect") {
        router.push(`/CourseManagement/ModulesList?CourseID=${Page.CourseID}`);
      } else if (Page.mode == "TrainingDirect") {
        router.push(`/TrainingManagement/TrainingManagementList`)
      } else {
        router.push("/ActivityManagement/ActivityList");
      }
    },
  };
  const pageRef = useRef({});
  const [getData, setData] = useState(1);
  const [customMessage, setCustomMessage] = useState("");
  const [contents, setContents] = useState();
  const [modalValues, setModalValues] = useState(initialModalState);
  const [tags] = useState(Page.EditData?.Keywords != undefined ? JSON?.parse(Page.EditData?.Keywords) : []);
  const [fileValues, setFileValues] = useState([]);
  const [langValues, setLangValue] = useState([]);
  const [DynamicError, SetDynamicError] = useState("");
  const ActivityCompletionRef = useRef(Page.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : Page.EditData?.IsActivityCompletion?.toString());

  const attempt = useMemo(() => {
    return [
      { value: "", text: "Unlimited" },
      { value: "2", text: "1" },
      { value: "3", text: "2" },
      { value: "4", text: "3" },
      { value: "5", text: "4" },
      { value: "6", text: "5" },
      { value: "7", text: "6" },
      { value: "8", text: "7" },
      { value: "9", text: "8" },
      { value: "10", text: "9" },
      { value: "11", text: "10" },
    ];
  }, []);

  const allowAttempts = useMemo(() => {
    return [
      { value: "", text: "Select" },
      { value: "if not Passed", text: "If not passed" },
      { value: "Always", text: "Always" },
    ];
  }, []);

  const decimal = useMemo(() => {
    return [
      { value: "", text: "Select" },
      { value: "1", text: "1" },
      { value: "2", text: "2" },
      { value: "3", text: "3" },
    ];
  }, []);

  const gradeMethod = useMemo(() => {
    return [
      { value: "", text: "Select" },
      { value: "Highest Grade", text: "Highest Grade" },
      { value: "Average Grade", text: "Average Grade" },
      { value: "First Attempt", text: "First Attempt" },
      { value: "Last Attempt", text: "Last Attempt" },
    ];
  }, []);


  const content = useMemo(() => {
    let options = [{ value: "", text: "Select" }];
    if (Page.RecordContent != undefined) {
      JSON.parse(Page.RecordContent?.OptionName)?.map((getItem) => {
        options.push({ value: getItem, text: getItem });
      });
    }
    return options;
  }, [Page.RecordContent]);

  const publishResult = useMemo(() => {
    return [
      { value: "0", text: "Do not publish results" },
      { value: "1", text: "Show the results to user after they answered" },
      { value: "2", text: "Show the results to user only after the poll has closed", },
      { value: "3", text: "Always show results" },
    ];
  }, []);

  const appearance = useMemo(() => {
    return [
      { value: "", text: "Select" },
      { value: "Embed", text: "Embed" },
      { value: "NewTab", text: "New Tab" },
    ];
  }, []);

  const record = useMemo(() => {
    return [
      { value: "ShowWithAnswers", text: "User's name will be logged and shown with answers", },
      { value: "ShowWithoutAnswers", text: "User's will be logged and showed without answers", },
    ];
  }, []);

  const finalResponse = useCallback(
    (finalStatus) => {
      if (finalStatus != "Success") {
        setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus, ModalOnClickEvent: () => { ModalClose(); }, });
        ModalOpen();
        return;
      } else {
        setModalValues({
          ModalInfo: "Success",
          ModalTopMessage: "Success",
          ModalBottomMessage: Page.ActivityType == "ScormPackage" ? "Scorm file is in process... " : "Details have been saved successfully.",
          ModalOnClickEvent: () => {
            if (Page.ActivityType == "Feedback") {
              let Mode = Page.mode == "ModuleDirect" ? "ModuleEdit" : "Edit";
              if (Page?.mode == "TrainingEdit") {
                router.push(`/TrainingManagement/AddQuestionnaireTemplate?Mode=${Page?.mode}&TrainingID=${Page?.TrainingID}&ActivityID=${Page.ActivityID}&ActivityType=${Page?.EditData?.ActivityType}&${Page?.Root == "TemplateList" ? "Root=TemplateList" : ""}`);
              } else if (router.query["ZoomActivityID"] != undefined) {
                router.push(`/ActivityManagement/FeedbackActivityOverView?Mode=${Mode}&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page?.CourseID != "" ? Page?.CourseID : ""}&ModuleID=${Page.ModuleID != "" ? Page.ModuleID : ""}&ZoomActivityID=${Page.ZoomActivityID}&ZoomMode=${router.query["ZoomActivityMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`);
              } else {
                router.push(`/ActivityManagement/FeedbackActivityOverView?Mode=${Mode}&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page?.CourseID != "" ? Page?.CourseID : ""}&ModuleID=${Page.ModuleID != "" ? Page.ModuleID : ""}`);
              }
            }
            else if (Page.ActivityType == "Quiz") {
              if (Page.mode != "ModuleDirect") {
                if (router.query["ZoomActivityID"] != undefined) {
                  router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomActivityMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
                } else if (Page?.mode == "TrainingEdit") {
                  if (router.query["Root"] == "TemplateList") {
                    router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&TrainingID=${Page?.TrainingID}&AssessmentType=${Page?.AssessmentType}&TrainingName=${Page?.TrainingName}&Settings=QuizList&Root=TemplateList`)
                  } else {
                    router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&TrainingID=${Page?.TrainingID}&AssessmentType=${Page?.AssessmentType}&TrainingName=${Page?.TrainingName}&Settings=QuizList`)
                  }
                } else {
                  router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}`)
                }
              } else {
                if (router.query["ZoomActivityID"] != undefined) {
                  router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page.CourseID}&ModuleID=${Page?.EditData?.ModuleID}&ZoomActivityID=${Page.ZoomActivityID}&ZoomMode=${router.query["ZoomActivityMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
                } else {
                  router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page.CourseID}&ModuleID=${Page?.EditData?.ModuleID}`);
                }
              }
            } else if (Page.mode == "ModuleDirect") {
              router.push(`/CourseManagement/ModulesList?CourseID=${Page.CourseID}`);
            } else {
              router.push("/ActivityManagement/ActivityList");
            }
          },
        });
        ModalOpen();
      }
    },
    [Page, router]
  );

  const keyCodes = {
    comma: 188,
    enter: 13,
    tab: 9,
  };

  const delimiters = useMemo(() => {
    return [keyCodes.comma, keyCodes.enter, keyCodes.tab];
  }, [keyCodes.comma, keyCodes.enter, keyCodes.tab]);

  const unSavedtoSaved = useCallback(
    async (fileValues) => {
      /*File Bulk upload */
      let finalResult, multilangFiles, LangFileUpload;
      if (
        Page.ActivityType == "File" ||
        Page.ActivityType == "ScormPackage" ||
        Page.ActivityType == "Assignment" ||
        Page.ActivityType == "LearningBytes" ||
        Page.ActivityType == "Video" ||
        Page.ActivityType == "Survey"
      ) {
        LangFileUpload = "{";
        let id = Page.ActivityType == "File" ? "ddlFile" : Page.ActivityType == "Video" ? "ddlVideo" : Page.ActivityType == "Survey" ? "ddlFileSurvey" : Page.ActivityType == "ScormPackage" ? "ddlFileScorm" : "ddlAssignment";
        fileValues.map((getItem, index) => {
          if (getItem?.PathChanged == true) {
            LangFileUpload += (index != 0 ? "," : "") + ('"' + document.getElementById(id + index)?.options[document.getElementById(id + index)?.selectedIndex]?.value + '":"' + getItem.FileName + '"');
          } else {
            LangFileUpload += (index != 0 ? "," : "") + ('"' + document.getElementById(id + index)?.options[document.getElementById(id + index)?.selectedIndex]?.value + '":"' + getItem.FilePath + '"');
          }
        });
        LangFileUpload += "}";
        let fetchURL;
        if (Page?.CourseID != undefined)
          fetchURL = process.env.ACTIVITY_LANG_UNSAVED_TO_SAVED + `?CourseID=${Page.CourseID}&ActivityType=${Page.ActivityType}&CourseType=Module&ModuleID=${Page.ModuleID}&ActivityID=${Page.ActivityID}&ManagementType=CourseManagement&Type=Course&TenantID=${Page.TenantInfo.TenantID}&RootFolder=${Page.TenantInfo.RootFolder}&BucketName=${Page.TenantInfo.BucketName}&ActivityType=${Page.ActivityType}`;
        else
          fetchURL = process.env.ACTIVITY_LANG_UNSAVED_TO_SAVED + `?ActivityID=${Page.ActivityID}&Type=Activity&TenantID=${Page.TenantInfo.TenantID}&RootFolder=${Page.TenantInfo.RootFolder}&BucketName=${Page.TenantInfo.BucketName}&ActivityType=${Page.ActivityType}`;

        let groupMenuName = Page.mode == "ModuleDirect" ? "CourseManagement" : "ActivityManagement";
        let menuId = Page.mode == "ModuleDirect" ? "300200" : "500005";
        let presignedHeader = { method: "POST", body: LangFileUpload, headers: { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: Page.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, };
        finalResult = await APIGatewayGetRequest(fetchURL, presignedHeader);
        multilangFiles = await finalResult?.res?.json();

        if (Page.ActivityType == "Video") {
          let fetchUrl;
          if (Page?.CourseID != undefined)
            fetchUrl = process.env.ACTIVITY_VIDEO_COURSE_STREAMING + `?CourseID=${Page.CourseID}&ActivityID=${Page.ActivityID}&Type=Course&ManagementType=CourseManagement&ModuleID=${Page.ModuleID}&TenantID=${Page.TenantInfo.TenantID}&RootFolder=${Page.TenantInfo.RootFolder}&BucketName=${Page.TenantInfo.BucketName}&ActivityType=${Page.ActivityType}&UserSub=${Page?.user?.attributes["sub"]}`;
          else
            fetchUrl = process.env.ACTIVITY_VIDEO_STREAMING + `?ActivityID=${Page.ActivityID}&Type=Activity&TenantID=${Page.TenantInfo.TenantID}&RootFolder=${Page.TenantInfo.RootFolder}&BucketName=${Page.TenantInfo.BucketName}&ActivityType=${Page.ActivityType}&UserSub=${Page?.user?.attributes["sub"]}`;
          const headers = { method: "POST", headers: { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: Page.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, body: LangFileUpload, };
          await APIGatewayGetRequest(fetchUrl, headers);
        }
      }
      if (multilangFiles == "Error") {
        finalResponse("Some error occured while upload");
        return null;
      }
      return multilangFiles;
    },
    [Page.ActivityType, Page.CourseID, Page.ModuleID, Page.ActivityID, Page.TenantInfo.TenantID, Page.TenantInfo.RootFolder, Page.TenantInfo.BucketName, Page.TenantInfo.UserGroup, Page.mode, Page?.user?.attributes, props.user.signInUserSession.accessToken.jwtToken, finalResponse]
  );

  const EditActivitySettings = useCallback(() => {
    let CurrentDiv = Page.ActivityType;
    switch (CurrentDiv) {
      case "Page":
        return (
          <CalendarComponent
            LanguageType={languageType}
            ref={pageRef}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            CurrentDiv={CurrentDiv}
            FinalResponse={finalResponse}
            setContents={setContents}
            contents={contents}
            props={{ ...props, ...Page }}
            tags={tags}
            delimiters={delimiters}
            router={router}
          />
        );
      case "Url":
        return (
          <UrlActivity
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            CurrentDiv={CurrentDiv}
            CustomMessage={customMessage}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={Page}
            tags={tags}
            delimiters={delimiters}
            router={router}
          />
        );
      case "File":
        return (
          <FileActivity
            UnSavedtoSaved={unSavedtoSaved}
            CurrentDiv={CurrentDiv}
            LanguageType={languageType}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            ActivityType={Page.ActivityType}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            delimiters={delimiters}
            router={router}
            CustomMessage={customMessage}
          />
        );
      case "Assignment":
        return (
          <AssignmentActivity
            ErrorRef={DynamicError}
            GetOnlyDate={GetOnlyDate}
            CustomMessage={customMessage}
            Attempt={attempt}
            CurrentDiv={CurrentDiv}
            AllowAttempts={allowAttempts}
            GradeMethod={gradeMethod}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            delimiters={delimiters}
            router={router}
          />
        );
      case "Discussion":
        return (
          <DiscussionActivity
            DateCoversion={DateCoversion}
            Attempt={attempt}
            CurrentDiv={CurrentDiv}
            AllowAttempts={allowAttempts}
            GradeMethod={gradeMethod}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            CustomMessage={customMessage}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            delimiters={delimiters}
            router={router}
          />
        );
      case "Video":
        return (
          <VideoActivity
            CurrentDiv={CurrentDiv}
            CustomMessage={customMessage}
            ErrorRef={DynamicError}
            LanguageType={languageType}
            UnSavedtoSaved={unSavedtoSaved}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            delimiters={delimiters}
            router={router}
          />
        );
      case "Feedback":
        return (
          <FeedbackActivity
            DateCoversion={DateCoversion}
            CustomMessage={customMessage}
            CurrentDiv={CurrentDiv}
            Attempt={attempt}
            AllowAttempts={allowAttempts}
            GradeMethod={gradeMethod}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            query={Page.mode == "TrainingEdit" ? updateXlmsTrainingManagementActivityInfo : (Page.mode != "ModuleDirect" || router.query["CourseID"] == undefined) ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            delimiters={delimiters}
            router={router}
            Record={record}
          />
        );
      case "ScormPackage":
        return (
          <ScormPackageActivity
            CustomMessage={customMessage}
            ErrorRef={DynamicError}
            Attempt={attempt}
            DateCoversion={DateCoversion}
            CurrentDiv={CurrentDiv}
            AllowAttempts={allowAttempts}
            GradeMethod={gradeMethod}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FileValues={fileValues}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            delimiters={delimiters}
            router={router}
          />
        );
      case "GoogleMeet":
      case "Zoom":
      case "MSTeams":
        return (
          <MeetingActivity
            DateCoversion={DateCoversion}
            CurrentDiv={CurrentDiv}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            setFileValues={setFileValues}
            FileValues={fileValues}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            delimiters={delimiters}
            router={router}
          />
        );
      case "Quiz":
        return (
          <QuizActivity

            DateCoversion={DateCoversion}
            CustomMessage={customMessage}
            CurrentDiv={CurrentDiv}
            Attempt={attempt}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            query={Page.mode == "ModuleDirect" ? updateXlmsCourseModule : Page?.mode == "TrainingEdit" ? updateXlmsTrainingManagementActivityInfo : updateXlmsActivityManagementInfo}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            delimiters={delimiters}
            // handleAddition={handleAddition} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit}
            router={router}
            ZoomMode={zoomMode}
            setData={setData}
          />
        );
      case "LearningBytes":
        return (
          <LearningBytesActivity
            Attempt={attempt}
            CurrentDiv={CurrentDiv}
            AllowAttempts={allowAttempts}
            GradeMethod={gradeMethod}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            setFileValues={setFileValues}
            FileValues={fileValues}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            //setValue={setValue} register={register} errors={errors}  watch={watch}
            //delimiters={delimiters} handleAddition={handleAddition} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit}
            router={router}
          />
        );
      case "Survey":
        return (
          <SurveyActivity
            LangValues={langValues}
            LanguageType={languageType}
            setLangValue={setLangValue}
            CurrentDiv={CurrentDiv}
            DateCoversion={DateCoversion}
            CustomMessage={customMessage}
            UnSavedtoSaved={unSavedtoSaved}
            setFileValues={setFileValues}
            FileValues={fileValues}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            //setValue={setValue} register={register} errors={errors} watch={watch}
            //delimiters={delimiters} handleAddition={handleAddition} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit}
            router={router}
          />
        );
      case "Poll":
        return (
          <PollActivity
            Attempt={attempt}
            CurrentDiv={CurrentDiv}
            AllowAttempts={allowAttempts}
            GradeMethod={gradeMethod}
            UnSavedtoSaved={unSavedtoSaved}
            LanguageType={languageType}
            setFileValues={setFileValues}
            FileValues={fileValues}
            query={Page.mode != "ModuleDirect" ? updateXlmsActivityManagementInfo : updateXlmsCourseModule}
            Appearance={appearance}
            FinalResponse={finalResponse}
            props={{ ...props, ...Page }}
            tags={tags}
            //delimiters={delimiters} handleAddition={handleAddition} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit}
            router={router}
          />
        );
      default:
        return <></>;
    }
  }, [Page, languageType, finalResponse, contents, props, tags, delimiters, router, customMessage, appearance, unSavedtoSaved, DynamicError, attempt, allowAttempts, gradeMethod, record, fileValues, zoomMode, langValues]);

  // Bread Crumbs
  let PageRoutes = [];
  if (Page?.mode == "ModuleDirect") {
    if (router.query["ZoomActivityID"] != undefined) {
      PageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${Page.CourseID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${Page.CourseID}&ModuleID=${Page.ModuleID}&ModuleName=${Page.EditData?.ModuleName}`, breadcrumb: "Edit Activity Zoom" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${Page.CourseID}&ModuleID=${Page.ModuleID}`, breadcrumb: "Edit Settings Zoom" },
        { path: `/CourseManagement/ModuleInfo?Mode=${router.query["ZoomActivityMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${Page.ActivityType}&CourseID=${Page.CourseID}&ModuleID=${Page.ModuleID}&ModuleName=${Page.EditData?.ModuleName}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
        { path: "", breadcrumb: "Edit Settings" }
      ];
    } else {
      PageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${Page.CourseID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&CourseID=${Page.CourseID}&ModuleID=${Page.ModuleID}&ModuleName=${Page.EditData?.ModuleName}`, breadcrumb: "Edit Activity" },
        { path: "", breadcrumb: "Edit Settings" }
      ];
    }
  } else if (Page?.mode == "TrainingEdit") {
    if (Page?.Root == "TemplateList") {
      PageRoutes = [
        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management", },
        { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${Page.TrainingID}&TrainingName=${Page.TrainingName}`, breadcrumb: "Training Template List" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${router.query["TrainingID"]}&TrainingName=${Page.TrainingName}&ActivityType=${router.query["ActivityType"]}&AssessmentType=${Page?.AssessmentType}&Root=TemplateList`, breadcrumb: "Edit Activity" },
        { path: ``, breadcrumb: "Edit Settings" }
      ];
    } else {
      PageRoutes = [
        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${router.query["TrainingID"]}&TrainingName=${Page.TrainingName}&ActivityType=${router.query["ActivityType"]}&AssessmentType=${Page?.AssessmentType}`, breadcrumb: "Edit Activity" },
        { path: ``, breadcrumb: "Edit Settings" }
      ];
    }

  } else {
    if (router.query["ZoomActivityID"] != undefined && !router.query["NavigationMode"]) {
      PageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
        { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Activity Zoom" },
        { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Settings Zoom" },
        { path: `/ActivityManagement/ActivityInfo?Mode=${router.query["ZoomActivityMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${Page.ActivityType}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
        { path: "", breadcrumb: "Edit Settings" }
      ];
    } else if (router.query["ZoomActivityID"] != undefined && router.query["NavigationMode"]) {
      PageRoutes = [
        { path: `/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`, breadcrumb: "Activity Management" },
        { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["ZoomActivityMode"]}`, breadcrumb: "Edit Activity" },
        { path: "", breadcrumb: "Edit Settings" }
      ];
    } else {
      PageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
        { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${Page.ActivityID}&ActivityType=${Page.ActivityType}`, breadcrumb: "Edit Activity" },
        { path: "", breadcrumb: "Edit Settings" }
      ];
    }
  }
  return (
    <>
      <Container PageRoutes={PageRoutes} loader={Page.EditData == undefined} title="Edit Settings">
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <div id="divEditActivitySettings" className="">
          {Page.EditData != undefined && <EditActivitySettings />}
        </div>
      </Container>
    </>
  );
}

export default EditActivity;


