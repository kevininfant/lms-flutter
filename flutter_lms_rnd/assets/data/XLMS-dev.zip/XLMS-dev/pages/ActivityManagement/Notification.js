import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLMultiSelect from "@components/Controls/NVLMultiSelectDropdown";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLRichTextBox, {
  getContents,
  setContents,
  setHTMLContents
} from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXLMSSendNotificationList } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import {
  APIGatewayGetRequest,
  APIGatewayPostRequest,
  APIGatewayPutRequest,
  AppsyncDBconnection
} from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import {
  getXlmsDefaultNotificationFields,
  getXLMSSendNotificationList,
  listXlmsCustomFields, listXlmsTrainingEnrollUserList, listXlmsUserListInfos
} from "src/graphql/queries";
import * as Yup from "yup";

function Notification(props) {
  const router = useRouter();
  const [notificationData, setNotificationData] = useState();
  const refDiv = useRef();
  const refSelectAll = useRef();
  const refMultiselect = useRef([]);
  const refReset = useRef(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const dataSource = async () => {
      var tenantId = props.user.attributes["custom:tenantid"];
      let groupId = Math.random().toString(25).substring(2, 12);
      let activityId, activityType, courseId;
      let mode = decodeURIComponent(String(router.query["Mode"]));
      if (mode == "Edit") {
        activityId = decodeURIComponent(String(router.query["ActivityID"]));
        activityType = decodeURIComponent(String(router.query["ActivityType"]));
      } else {
        courseId = decodeURIComponent(String(router.query["CourseID"]));

      }
      const notificationFields = await AppsyncDBconnection(getXlmsDefaultNotificationFields, { PK: "XLMS#DELIMETERFIELDS", SK: "NOTIFICATIONFIELDS#DELIMETER" }, props.user?.signInUserSession?.accessToken?.jwtToken);
      const customFieldData = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#" }, props.user?.signInUserSession?.accessToken?.jwtToken);
      const userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + tenantId, SK: "#USERINFO#", IsSuspend: false }, props.user?.signInUserSession?.accessToken?.jwtToken);
      const enrollUserData = await AppsyncDBconnection(listXlmsTrainingEnrollUserList, { PK: "TENANT#" + tenantId + "#TRAININGID#" + props?.TrainingID, SK: "TRAINING#ENROLLUSER#USERSUB#", IsSuspend: false, Department: "", Designation: "", UserName: "", EmailID: "" }, props.user?.signInUserSession?.accessToken?.jwtToken)
      let notificationData, ResendData;
      if (router.query["NotificationID"] != undefined) {
        let SK = router.query["Mode"] == "Edit" ? "SENDNOTIFICATION#ACTIVITYID#" + activityId + "#" + router.query["NotificationID"] : props?.TrainingID ? "SENDNOTIFICATION#TRAININGID#" + props?.TrainingID + "#" + router.query["NotificationID"] : "SENDNOTIFICATION#COURSEID#" + courseId + "#" + router.query["NotificationID"]
        notificationData = await AppsyncDBconnection(getXLMSSendNotificationList, { PK: "TENANT#" + tenantId, SK: SK }, props.user?.signInUserSession?.accessToken?.jwtToken)
        ResendData = notificationData.res?.getXLMSSendNotificationList
      }
      setNotificationData({
        userData: userData.res?.listXlmsUserListInfos?.items,
        TenantId: tenantId,
        mode: mode,
        ActivityID: mode == "Edit" && activityId,
        ActivityType: mode == "Edit" && activityType,
        CourseId: mode == "CourseDirect" && courseId,
        GroupID: groupId,
        NotificationData: notificationFields.res?.getXlmsDefaultNotificationFields?.DefaultFields,
        CustomFieldData: customFieldData.res?.listXlmsCustomFields?.items,
        EnrollUserData: enrollUserData?.res?.listXlmsTrainingEnrollUserList?.items,
        ResendData: ResendData
      })
      if (router.query["NotificationID"] != undefined) {
        setValue("txtSubject", ResendData?.Subject)
        setValue("rbUser", ResendData?.SentType)
        const FilePathIndex = props?.TrainingID ? 6 : 9
        setFileValues({
          ...fileValues,
          TextName: ResendData?.NotificationAttachment?.split("/")[FilePathIndex],
          FilePath: ResendData?.NotificationAttachment,
        })

      }

    }
    dataSource();

    return (() => {
      setNotificationData((temp) => { return { ...temp } });
    })

  }, [fileValues, message, props?.TrainingID, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue])


  useEffect(() => {
    if (router.query["NotificationID"] != undefined) {
      if (message != "" && message != undefined) {
        setHTMLContents(notificationData?.ResendData?.Message, message);
        setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
        message?.history?.clear();
      }
    }
  }, [message, notificationData?.ResendData?.Message, router.query, setValue])

  const TenantInfo = props.TenantInfo;
  const [currentDiv, setCurrentDiv] = useState("All User");
  const [filePathChanged, setfilePathChanged] = useState(false);

  const notificationFields = useMemo(() => {
    if (notificationData?.NotificationData != undefined) {
      let delimeterData = JSON.parse(notificationData.NotificationData);

      let customFieldDataList = [];
      notificationData?.CustomFieldData &&
        notificationData?.CustomFieldData?.map((customField) => {
          customFieldDataList.push(customField.ProfileFieldName);
        });

      let finalCustomFieldData = [];
      customFieldDataList?.map((customField) => {
        finalCustomFieldData.push({ customField: customField });
      });
      let finalDelimetersData = props?.TrainingID ? {
        ...delimeterData?.CompanyDetails,
        ...delimeterData?.UserDetails,
        ...delimeterData?.TrainingDetails,
        ...customFieldDataList,
      } : {
        ...delimeterData?.CompanyDetails,
        ...delimeterData?.ActivityDetails,
        ...delimeterData?.UserDetails,
        ...delimeterData?.CourseDetails,
        ...customFieldDataList,
      };

      return Object.entries(finalDelimetersData);
    }
  }, [notificationData?.CustomFieldData, notificationData?.NotificationData, props?.TrainingID]);
  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Notification sent successfully",
    ModalOnClickEvent: () => {
      if (notificationData.mode == "CourseDirect") {
        router.push("/CourseManagement/CourseList");
      } else if (props?.TrainingID) {
        router.push("/TrainingManagement/TrainingManagementList");
      } else {
        router.push("/ActivityManagement/ActivityList");
      }
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);
  const [multiselected, setMultiSelected] = useState([]);
  const [fileValues, setFileValues] = useState({
    TextName: "Select File",
    FilePath: "",
  });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const userList = [];
  if (notificationData?.userData != undefined) {
    if (props?.TrainingID) {
      if ((notificationData.userData && notificationData.userData.length > 0) && (notificationData?.EnrollUserData && notificationData?.EnrollUserData?.length > 0)) {
        notificationData.userData.map((getItem) => {
          if (getItem.EmailID != null) {
            notificationData?.EnrollUserData && (notificationData?.EnrollUserData?.some((x) => x?.UserSub == getItem?.UserSub)) ? userList.push({ value: getItem.UserSub, label: getItem.EmailID }) : ""
          }
        });
      }
    } else {
      if (notificationData.userData && notificationData.userData.length > 0) {
        notificationData.userData.map((getItem) => {
          if (getItem.EmailID != null) {
            userList.push({ value: getItem.UserSub, label: getItem.EmailID });
          }
        });
      }
    }
  }

  useEffect(() => {
    if (message != "") {
      message?.on("text-change", () => {
        if (
          getContents(message) == "" ||
          getContents(message)
            .replaceAll(/(<([^>]+)>)/gi, "")
            .trim().length == 0
        ) {
          setValue("txtDescription", "Empty", { shouldValidate: true });
        } else {
          setValue("txtDescription", "NotEmpty", { shouldValidate: true });
        }
        setValue("txtDescription", "NotEmpty", { shouldValidate: true });
      });
    }


  }, [message, router.query, setValue]);

  function resetData() {
    setMultiSelected([]);
    setValue("ddlAssignGroup", "", { shouldValidate: true });
    setValue("txtSubject", "");
    setHTMLContents("", message);
    document.getElementsByClassName("ql-editor")[0].innerHTML = "";
    setFileValues({ TextName: "Select File", FilePath: "" });
    setValue("File", "", { shouldValidate: true });
  }

  // useEffect(() => {
  //   if (Message != "") {
  //     Message?.on("text-change", () => {
  //       if (
  //         getContents(Message) == "" ||
  //         getContents(Message)
  //           .replaceAll(/(<([^>]+)>)/gi, "")
  //           .trim().length == 0
  //       ) {
  //         setValue("RichTextBox", "Empty", { shouldValidate: true });
  //       } else {
  //         setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
  //       }
  //     });
  //   }
  // }, [Message, setValue]);

  const validationSchema = Yup.object().shape({
    rbUser: Yup.string().test("NOValid", "novalid", (e) => {
      if (e == "All User" && e != currentDiv) {
        setCurrentDiv("All User");
        reset({}, { keepValues: true, keepDirty: true });
        refMultiselect.current.resetSelectedValues();
      } else if (e == "Custom" && e != currentDiv) {
        setCurrentDiv("Custom");
        reset({}, { keepValues: true, keepDirty: true });
        refMultiselect?.current?.resetSelectedValues();
      }
      return true;
    }),
    txtSubject: Yup.string()
      .required("Enter Subject").max(500, "Maximum limit exceeds")
      // .matches(Regex("AlphanumSpecialCharModified"),"Enter valid Subject")
      .nullable(),
    // RichTextBox: Yup.string()
    //   .nullable()
    //   .test("", "Message is required", (e) => {
    //     if (e == "Empty" || e == undefined) {
    //       return false;
    //     } else {
    //       return true;
    //     }
    //   }),
    txtDescription: Yup.string()
      .test("", "Description is required", (e, { createError }) => {
        if (getContents(message)?.replaceAll(/(<([^>]+)>)/gi, "").length > 2000) {
          document.getElementById("desc_errors")?.classList.remove("hidden");
          return createError({ message: "Maximum limit exceeds" });
        }
        if (!message?.editor.delta.ops[0]["insert"].image) {
          if (
            message?.editor.delta.ops[0]["insert"]
              ?.replaceAll(/(<([^>]+)>)/gi, "re")
              ?.trim().length == 0 ||
            getContents(message)?.replaceAll(/(<([^>]+)>)/gi, "")?.length == 0
          ) {
            document.getElementById("desc_errors")?.classList.remove("hidden");
            return false;
          } else {
            document.getElementById("desc_errors")?.classList.add("hidden");
            return true;
          }
        } else {
          if (
            message?.editor.delta.ops[0]["insert"].image
              ?.replaceAll(/<img[^>]+>/g, "re")
              ?.trim().length == 0 ||
            getContents(message)?.replaceAll(/<img[^>]+>/g, "")?.length == 0
          ) {
            document.getElementById("desc_errors")?.classList.remove("hidden");
            return false;
          } else {
            document.getElementById("desc_errors")?.classList.add("hidden");
            return true;
          }
        }
      })
      .nullable(),
    File: Yup.string().test("file_Error", "", (e, { createError }) => {
      if (e == "fileType") {
        setFileValues({ TextName: "Select File", FilePath: "" });
        return createError({ message: "Invalid file type" });
      }
      if (e == "filesize") {
        setFileValues({ TextName: "Select File", FilePath: "" });
        return createError({ message: " file size should be 2MB!" });
      }

      if (e == "Error") {
        return createError({ message: "Server Error Please Try Again" });
      }
      return true;
    }),
    ddlAssignGroup: !router.query["NotificationID"] && Yup.string()
      .test("MultiSlect_EmptyHandler", "", (e, { createError }) => {
        if (e == "equal") { clearErrors(["ddlAssignGroup"]) }
        if (e == "maxLimit") { return createError({ message: "Maximum Limit exceed" }); }
        if (multiselected?.length >= 1) return true;
        if ((e == "Empty" || e == undefined || multiselected?.length == 0) && currentDiv == "Custom") {
          return createError({ message: "Please choose users from the list" });
        }
        if (e == "NoData") {
          return createError({ message: "Please choose users from the list" });
        }
        return true;
      })
      .nullable(),
  });

  const formOptions = {
    mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false,
  };
  const { register, handleSubmit, setValue, watch, formState, reset, clearErrors } = useForm(formOptions);
  const { errors } = formState;

  const finalResponse = (finalStatus) => {
    if (finalStatus == "Success") {
      setModalValues({
        ModalInfo: "Success",
        ModalTopMessage: finalStatus,
        ModalBottomMessage: "Notification sent successfully",
        ModalOnClickEvent: () => {
          if (notificationData.mode == "CourseDirect") {
            router.push(`/CourseManagement/CourseNotification?Mode=CourseDirect&CourseID=${router?.query["CourseID"]}`);
          } else if (props?.TrainingID) {
            router.push(`/TrainingManagement/TrainingNotificationList?TrainingID=${props?.TrainingID}`);
          } else {
            router.push(`/ActivityManagement/SendNotificationList?Mode=Edit&ActivityID=${router?.query["ActivityID"]}&ActivityType=${router?.query["ActivityType"]}`);
          }
        },
      });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: finalStatus,
      });
      ModalOpen();
    }
  };

  async function fileValidation(e) {
    if (e.target.files.length == 0) {
      return;
    }
    setValue("File", "Uploading");
    setfilePathChanged(true);
    var fileInput = document.getElementById("getFile");
    var filePath = fileInput.value;
    var allowedExtensions =
      /(\.csv|\.txt|\.doc|\.docx|\.pdf|\.jpg|\.jpeg|\.png|\.mp4|\.ppt|\.xlsx|\.xls|\.pptx)$/i;

    var filesize = fileInput.files[0]?.size;

    if (filesize > process.env.NOTIFICATION_UPLOAD_FILE_SIZE) {
      setValue("File", "filesize", { shouldValidate: true });

      fileInput.value = "";
      // setTextName("select file");
      // setFilePath("");
      return false;
    }
    if (!allowedExtensions.exec(filePath) || fileInput == null) {
      fileInput.value = "";
      setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
      setValue("File", "fileType", { shouldValidate: true });
      setValue("File", "fileType", { shouldValidate: true });

      return false;
    } else {
      await uploadFile(e);
    }
  }

  async function uploadFile(e) {
    const file = e.target.files[0];
    const csvReader = new FileReader();
    let name = e.target.files[0].name;
    let fileExtension = [
      "csv",
      "txt",
      "doc",
      "docx",
      "pdf",
      "ppt",
      "xlsx",
      "xls",
      "pptx",
    ];
    let imageExtension = ["jpg", "jpeg", "png"];
    let videoExtension = ["mp4"];
    let header = '';
    let temp, fileType;
    csvReader.onload = async function () {
      const arr = (new Uint8Array(csvReader.result)).subarray(0, 4);
      for (let i = 0; i < arr.length; i++) {
        header += arr[i].toString(16);
      }
      const extension = e.target.value
        .substring(e.target.value.lastIndexOf(".") + 1)
        .toLowerCase();
      let contentType =
        extension == "csv"
          ? "text/" + extension
          : imageExtension.indexOf(extension) >= 0
            ? "image/" + extension
            : videoExtension.indexOf(extension) >= 0
              ? "video/" + extension
              : fileExtension.indexOf(extension) >= 0
                ? extension == "xls"
                  ? "application/vnd.ms-excel"
                  : extension == "ppt"
                    ? "application/vnd.ms-powerpoint"
                    : extension == "pptx"
                      ? "application/vnd.openxmlformats-officedocument.presentationml.presentation"
                      : extension == "xlsx"
                        ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        : extension == "txt" && header == "5574696c"
                          ? "text/plain"
                          : extension == "txt" && header == "73646661"
                            ? "text/html"
                            : extension == "doc" ?
                              "application/msword"
                              : extension == "docx" ?
                                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                : "application/" + extension
                : "application/" + extension;
      switch (header + '|' + contentType) {
        case '89504e47|image/png':
          fileType = 'image/png';
          break;
        case 'ffd8ffe0|image/jpg':
        case 'ffd8ffe1|image/jpg':
        case 'ffd8ffdb|image/jpg':
        case 'ffd8ffe2|image/jpg':
          fileType = 'image/jpg';
          break;
        case 'ffd8ffe0|image/jpeg':
        case 'ffd8ffe1|image/jpeg':
        case 'ffd8ffe2|image/jpeg':
          fileType = 'image/jpeg';
          break;
        case '000001ba|video/mp4':
        case '00020|video/mp4':
          fileType = 'video/mp4';
          break;
        case '25504446|application/pdf':
          fileType = 'application/pdf';
          break;
        case 'd0cf11e0|application/vnd.ms-powerpoint': /*ppt*/
          fileType = 'application/vnd.ms-powerpoint'
          break;
        case '73646661|text/html':
          fileType = 'text/html';
          break;
        case '5574696c|text/plain': /*txt*/
          fileType = 'text/plain';
          break;
        case '504b34|application/vnd.openxmlformats-officedocument.presentationml.presentation': /*pptx*/
          fileType = 'application/vnd.openxmlformats-officedocument.presentationml.presentation';
          break;
        case '504b34|application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': /*xlsx*/
          fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
          break;
        case '89504e47|application/vnd.ms-excel':
        case 'd0cf11e0|application/vnd.ms-excel':
        case '65737472|application/vnd.ms-excel':
          fileType = 'application/vnd.ms-excel'; // XLS file format
          break;
        case '51756573|text/csv':
        case '504b2c53|text/csv':
        case '22636f75|text/csv':
        case '55736572|text/csv':
        case '22557365|text/csv':
        case '2c53616d|text/csv':
          fileType = 'text/csv';
          break;
        case 'd0cf11e0a1b11ae1|application/msword':
        case 'd0cf11e0|application/msword':
          fileType = 'application/msword'; // DOC file format
          break;
        case '504b030414000600|application/vnd.openxmlformats-officedocument.wordprocessingml.document':
        case '504b34|application/vnd.openxmlformats-officedocument.wordprocessingml.document':
          fileType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';// DOCX file format
          break;
        default:
          temp = 1;
          setValue("File", "fileType", { shouldValidate: true });
          setFileValues({ TextName: "Select File", FilePath: "", path: "" })
          break;
      }
      if (temp == 1) {
        return false;
      }

      let fetchURL =
        notificationData.mode == "Edit"
          ? process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
          `?FileName=${file.name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ActivityType=${notificationData.ActivityType}&Type=SendNotification`
          : props?.TrainingID ? process.env.APIGATEWAY_URL_UPLOAD_FILE_TRAINING + `?FileName=${file.name}&Page=SendNotification&TenantId=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder + "/" + props.TenantInfo.TenantID}` : process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
            `?FileName=${file.name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&Type=Course&CourseType=SendNotification&ManagementType=CourseManagement`;

      let groupmenuName = notificationData.mode == "Edit" ? "ActivityManagement" : props?.TrainingID ? "TrainingManagement" : "CourseManagement";
      let menuId = notificationData.mode == "Edit" ? "500002" : props?.TrainingID ? "401100" : "300406";

      let headers = { method: "GET", headers: { authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupmenuName, menuid: menuId, }, };

      let presignedHeader = {
        method: "PUT",
        headers: {
          // "x-amz-acl": "public-read",
          "content-type": contentType,
          defaultrole: props.TenantInfo.UserGroup,
          groupmenuname: groupmenuName,
          menuid: menuId,
        },
        body: file,
      };

      let finalStatus = await APIGatewayPutRequest(
        fetchURL,
        headers,
        presignedHeader
      );
      if (finalStatus[0] != "Success") {
        setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
        setValue("File", "Error", { shouldValidate: true });
        return;
      } else {
        setValue("File", "exist", { shouldValidate: true });
        setFileValues({
          ...fileValues,
          TextName: name,
          FilePath: finalStatus[1],
        });
      }
    };
    csvReader.readAsArrayBuffer(file);
  }

  const submithandler = async (data) => {
    document?.activeElement?.blur();
    setValue("submit", true);
    let description = getContents(message);

    if (
      getContents(message) == "" ||
      getContents(message)
        .replaceAll(/(<([^>]+)>)/gi, "")
        .trim().length == 0
    ) {
      setValue("txtDescription", "Empty", { shouldValidate: true });
      // return false;
    }

    const finalData = [];
    if (currentDiv == "Custom") {
      if (multiselected && multiselected.length > 0) {
        for (var i = 0; i < multiselected.length; i++) {
          for (var j = 0; j < notificationData.userData.length; j++) {
            if (notificationData.userData[j].UserSub == multiselected[i].value?.split("#")?.[2]) {
              finalData.push(notificationData.userData[j].UserSub);
            }
          }
        }
      }
    } else {
      userList.map((user) => {
        finalData.push(user.value);
      });
    }

    if (!router.query["NotificationID"]) {
      if (currentDiv == "Custom" && multiselected.length == 0) {
        setValue("ddlAssignGroup", "NoData", { shouldValidate: true });
        setValue("submit", false);
        return;
      }
    }
    let fetchURL =
      notificationData.mode == "Edit"
        ? process.env.ACTIVITY_UNSAVED_TO_SAVED +
        `?FileName=${fileValues.TextName}&ActivityID=${notificationData.ActivityID}&Type=Activity&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&ActivityType=${notificationData.ActivityType}&&Type=SendNotification`
        : props?.TrainingID ? process.env.TRAINING_UNSAVED_TO_SAVED + `?FileName=${fileValues.TextName}&Id=${router.query["TrainingID"]}&Page=SendNotification&TenantId=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder + "/" + props.TenantInfo.TenantID}`
          : process.env.ACTIVITY_UNSAVED_TO_SAVED +
          `?FileName=${fileValues.TextName}&CourseID=${notificationData.CourseId}&Type=Course&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&CourseType=SendNotification&ManagementType=CourseManagement`;

    let groupMenuName = notificationData.mode == "Edit" ? "ActivityManagement" : props?.TrainingID ? "TrainingManagement" : "CourseManagement";
    let menuId = notificationData.mode == "Edit" ? "500002" : props?.TrainingID ? "401100" : "300406";
    const headers = {
      method: "GET",
      headers: {
        authorizationToken: await Auth.currentSession().then((s) =>
          s.getAccessToken().getJwtToken()
        ),
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: groupMenuName,
        menuid: menuId,
      },
    };

    let finalResult;
    if (!router.query["NotificationID"]) {
      finalResult = filePathChanged && (await APIGatewayGetRequest(fetchURL, headers));
    }

    let attachFilePath = router.query["NotificationID"] != undefined ? notificationData?.ResendData?.NotificationAttachment : await finalResult?.res?.text();
    if (filePathChanged && attachFilePath == undefined) {
      finalResponse("Some error occured while upload");
    }

    const UsersData = (router.query["NotificationID"] != undefined && currentDiv == "Custom") ? JSON.parse(notificationData?.ResendData?.UserSub) : finalData
    var fetchUrl = process.env.ACTIVITY_SENDNOTIFICATION_EVENT_BRIDGE;
    var jsonSaveData =
    // props?.TrainingID ? {
    //   TenantID: TenantInfo.TenantID,
    //   CreatedBy: "",
    //   CreatedDate: "",
    //   LastModifiedBy: "",
    //   TrainingID: props?.TrainingID,
    //   AllUser: watch("rbUser") == "Custom" ? false : true,
    //   LastModifiedDate: props.TenantInfo.BucketName,
    //   UserList: UsersData,
    //   Content: description,
    //   Subject: data.txtSubject,
    // } : 
    {
      TenantID: TenantInfo.TenantID,
      CourseID: notificationData.mode == "CourseDirect" ? notificationData.CourseId : "",
      ActivityID: notificationData.mode == "Edit" ? notificationData.ActivityID : "",
      ActivityType: notificationData.mode == "Edit" ? notificationData.ActivityType : "",
      TrainingID: props?.TrainingID ? props?.TrainingID : "",
      TargetPlatForms: "EMAIL",
      BucketName: props.TenantInfo.BucketName,
      UserDetails: UsersData,
      NotificationAttachment: attachFilePath,
      Subject: data.txtSubject,
      Message: description,
    };

    let headerList = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: props?.TrainingID ? "TrainingManagement" : "ActivityManagement",
        menuid: props?.TrainingID ? 401100 : 500011,
      },
      body: JSON.stringify(jsonSaveData),
    };
    let finalStatus;

    finalStatus = await APIGatewayPostRequest(fetchUrl, headerList);
    if (finalStatus?.Status.toLocaleLowerCase() == "success") {
      let notificationID = crypto.randomUUID().toString(25).substring(2, 12);
      let sk = notificationData.mode == "Edit" ? "SENDNOTIFICATION#ACTIVITYID#" + notificationData.ActivityID + "#" + notificationID : props?.TrainingID ? "SENDNOTIFICATION#TRAININGID#" + props?.TrainingID + "#" + notificationID : "SENDNOTIFICATION#COURSEID#" + notificationData.CourseId + "#" + notificationID
      let variables = {
        input: {
          PK: "TENANT#" + TenantInfo.TenantID,
          SK: sk,
          TenantID: TenantInfo.TenantID,
          CourseID: notificationData.mode == "CourseDirect" ? notificationData.CourseId : "",
          ActivityID: notificationData.mode == "Edit" ? notificationData.ActivityID : "",
          ActivityType: notificationData.mode == "Edit" ? notificationData.ActivityType : "",
          TrainingID: props?.TrainingID ? props?.TrainingID : "",
          TargetPlatForms: "EMAIL",
          BucketName: props.TenantInfo.BucketName,
          NotificationAttachment: attachFilePath,
          Subject: data.txtSubject,
          Message: description,
          UserSub: JSON.stringify(UsersData),
          CreatedDate: new Date(),
          SentType: data.rbUser
        },
      };
      finalStatus = await AppsyncDBconnection(createXLMSSendNotificationList, variables, props.user?.signInUserSession?.accessToken?.jwtToken)
      finalResponse(finalStatus.Status);
    }

    setValue("submit", false);
  };

  useEffect(() => {
    setValue("rbUser", "All User");
  }, [setValue]);

  useEffect(() => {
    if (!router.query["NotificationID"]) {
      setValue("txtSubject", "");
      if (currentDiv == "AllUser") setValue("ddlAssignGroup", []);
    }
  }, [setValue, message, currentDiv, router.query]);
  // Bread Crumbs
  const pageRoutes = [
    {
      path: notificationData?.mode == "Edit" ? "/ActivityManagement/ActivityList" : props?.TrainingID ? "/TrainingManagement/TrainingManagementList" : "/CourseManagement/CourseList",
      breadcrumb: notificationData?.mode == "Edit" ? "Activity Management" : props?.TrainingID ? "Training Management" : "Course Management "
    },
    {
      path: notificationData?.mode == "Edit" ? `/ActivityManagement/SendNotificationList?Mode=Edit&ActivityID=${router?.query["ActivityID"]}&ActivityType=${router?.query["ActivityType"]}` : props?.TrainingID ? `/TrainingManagement/TrainingNotificationList?TrainingID=${props?.TrainingID}` : `/CourseManagement/CourseNotification?Mode=CourseDirect&CourseID=${router?.query["CourseID"]}`,
      breadcrumb: "Send Notification List"
    },

    { path: "", breadcrumb: "Send Notification" }
  ];


  const [refersh, setRefersh] = useState(1);
  const temp = () => {
    setRefersh((data) => { return data + 1 })
  }

  const GetMultisSelect = useCallback(() => {
    return (
      <>
        <div ref={refDiv} className={`${router.query["NotificationID"] != undefined ? "hidden" : ""}`}>
          <NVLMultiSelect
            reference={refMultiselect}
            type={props?.TrainingID ? "Custom" : "User"}
            id="ddlAssignGroup"
            className="!w-96 nvl-mandatory"
            onSelect={(event) => {
              setMultiSelected(event);
              if (!(event?.length <= 25)) {
                setValue("ddlAssignGroup", "maxLimit", { shouldValidate: true });
              }
              if (event?.length == undefined || event.length == 0) {
                setValue("ddlAssignGroup", "Empty", { shouldValidate: true });
              } else {
                reset({}, { keepValues: true, keepDirty: true });
                return true;
              }
            }}
            onRemove={(e) => {
              if ((e?.length <= 25)) {
                setValue("ddlAssignGroup", "equal", { shouldValidate: true });
              }
            }}
            options={userList}
            placeholder={"Search user"}
            user={props?.user}
            TenantInfo={props?.TenantInfo}
            temp={temp}
            showToolTip={true}
            HelpInfo="Search with minimum three characters using Name/UserID,Only 25 users can only send notification at a time"
          />
        </div>
      </>
    )
  }, [props?.TenantInfo, props?.TrainingID, props?.user, reset, router.query, setValue, userList])

  return (
    <>

      <Container PageRoutes={pageRoutes} loader={notificationData?.mode == undefined} >
        <NVLAlert
          ButtonYestext={"X"}
          MessageTop={modalValues.ModalTopMessage}
          MessageBottom={modalValues.ModalBottomMessage}
          ModalOnClick={modalValues.ModalOnClickEvent}
          ModalInfo={modalValues.ModalInfo}
        />

        <form onSubmit={handleSubmit(submithandler)} id="Formjs" className={`${watch("File") == "Uploading" || watch("submit") ? "pointer-events-none" : ""}`}>
          <div className=" justify-center flex gap-3 pt-5 md: px-20 py-10">
            <div className="Center-Aligned-Items">
              <div className={router.query["NotificationID"] != undefined ? "hidden" : ""}>
                <div className="flex gap-20 text-xs font-medium">
                  <NVLRadio
                    id="rbUser"
                    type="radio"
                    errors={errors}
                    register={register}
                    text="All User"
                    name="rbUser"
                    value={"All User"}
                    onClick={() => resetData()}
                  />
                  <NVLRadio
                    id="rbUser"
                    type="radio"
                    errors={errors}
                    register={register}
                    text="Custom"
                    name="rbUser"
                    value={"Custom"}
                    onClick={() => resetData()}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="md: px-10">
            <div
              className={watch("rbUser") == "All User" ? "hidden Disabled" : "w-96"}>
              {GetMultisSelect()}

              <div className="block {invalid-feedback} text-red-500  text-sm">
                {errors.ddlAssignGroup?.message}
              </div>
            </div>
            <div className={`${router.query["NotificationID"] != undefined ? "pointer-events-none" : ""}`}>
              <div className="pt-4 ">
                <NVLTextbox
                  id="txtSubject"
                  title="Subject"
                  tabIndex={router.query["NotificationID"] != undefined ? -1 : 0}
                  errors={errors}
                  register={register}
                  className={`w-full nvl-mandatory ${router.query["NotificationID"] != undefined ? "Disabled" : ""}`}
                />
              </div>
              <div className="pt-2">
                <NVLRichTextBox
                  id="txtDescription"
                  className={`isResizable nvl-mandatory ${router.query["NotificationID"] != undefined ? "Disabled" : ""}`}
                  setState={setMessage}
                  isDisabled={router.query["NotificationID"] ? true : false}
                />
                <div
                  className="{invalid-feedback} text-red-500 text-sm pt-2"
                  id="desc_errors"
                >
                  {errors?.txtDescription?.message}
                </div>
              </div>
              <div className="pt-4">
                <NVLlabel
                  text="* Click on the below items to add it in the Description field."
                  className="pt-4"
                  showFull
                ></NVLlabel>
              </div>
              <div className="pt-2 flex gap-6 font-semibold">
                <div className="gap-4 flex flex-wrap text-2xl">
                  {notificationFields &&
                    Array.from(notificationFields)?.map((fieldsData) => {
                      return (
                        <>
                          <NVLlabel
                            id="lblUserName"
                            className="NotifyItems text-lg"
                            text={fieldsData?.[1]}
                            onClick={() => {
                              setContents(
                                "{" + fieldsData?.[0] > 0
                                  ? fieldsData?.[0]
                                  : "{" + fieldsData?.[1] + "}",
                                message
                              );
                            }}
                          />
                        </>
                      );
                    })}
                </div>
              </div>
              <div className="flex gap-2 my-auto pt-6">
                <NVLlabel
                  text="Attachment"
                  className="pt-2 Def-Input-Label text-lg"
                ></NVLlabel>
                <NVLFileUpload
                  id="getFile"
                  text={
                    fileValues.TextName == null
                      ? "Select File"
                      : fileValues.TextName
                  }
                  ButtonType="success"
                  onChange={(e) => fileValidation(e)}
                ></NVLFileUpload>
                <div className="pt-3">
                  <NVLlabel
                    className="nvl-Def-Label"
                    HelpInfo={`${"Acceptable file format: .csv, .txt, .doc, .docx, .pdf, .jpg, .jpeg, .png ,.mp4,.mpeg4,.ppt,.pptx,.xls,.xlsx<br>File size should not exceed more than 2MB"}`}
                    HelpInfoIcon={"fa fa-solid fa-circle-question"}
                  />
                </div>
                <NVLLoader
                  className={`text-sm ${watch("File") == "Uploading" ? "my-auto" : "hidden"
                    }`}
                  id="loader"
                />
              </div>
              <div
                className={
                  "Center-Aligned-Items {invalid-feedback} text-red-500 text-sm "
                }
              >
                {errors?.File?.message}
              </div>
            </div>
          </div>
          <div className=" justify-center flex gap-3 pt-7">
            <NVLButton
              id="btnSend"
              disabled={
                watch("File") == "Uploading" || watch("submit") ? true : false
              }
              text={!watch("submit") ? "Send" : ""}
              type="submit"
              className={
                props.ButtonClassName
                  ? props.ButtonClassName
                  : `w-32 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""
                  }`
              }
            >
              {watch("submit") && (
                <i className="fa fa-circle-notch fa-spin mr-2"> </i>
              )}
            </NVLButton>
            <NVLButton
              id="btnCancel"
              text={"Cancel"}
              type="reset"
              disabled={
                watch("File") == "Uploading" || watch("submit") ? true : false
              }
              className={
                props.ButtonClassName
                  ? props.ButtonClassName
                  : `nvl-button w-28 ${watch("File") == "Uploading" ? "nvl-button-light" : ""
                  }`
              }
              onClick={() => (
                notificationData.mode == "Edit"
                  ? router.push(`/ActivityManagement/SendNotificationList?Mode=Edit&ActivityID=${notificationData.ActivityID}&ActivityType=${notificationData.ActivityType}`)
                  : props?.TrainingID ? router.push(`/TrainingManagement/TrainingNotificationList?TrainingID=${props?.TrainingID}`) : router.push(`/CourseManagement/CourseNotification?Mode=CourseDirect&CourseID=${notificationData.CourseId}`),
                resetData()
              )}
            />
          </div>
        </form>
      </Container>
    </>
  );
}

export default Notification;

