import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useState } from "react";
import { updateXlmsActivityManagementInfo } from "src/graphql/mutations";
import { listXLMSSendNotificationLists } from "src/graphql/queries";

export default function SendNotificationList(props) {

    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("")
    const headerColumn = [
        { HeaderName: "S.No", Columnvalue: "SNo", HeaderCss: "!w-1/5" },
        { HeaderName: "Subject", Columnvalue: "Subject", HeaderCss: "!w-2/5" },
        { HeaderName: "Sent Date", Columnvalue: "CreatedDate", HeaderCss: "!w-1/5" },
        { HeaderName: "Users", Columnvalue: "Type", HeaderCss: "" },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "" },
    ];
    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    }

    const refreshData = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };
    const refreshGrid = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    function resetPopUp() {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
        document.getElementById("tableSearch").value = "";
    }

    function popup(type, PK, SK, Content) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
    }
    async function updateField(e) {
        e.preventDefault();
        let isSus = false;
        let isDelete = false;
        if (popupValues.Type == "isSuspend") {
            isSus = true;
        } else if (popupValues.Type == "isDelete") {
            isDelete = true;
        }
        refreshData();
        let FinalStatus = await AppsyncDBconnection(updateXlmsActivityManagementInfo, { input: { PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus, IsDeleted: isDelete } }, props.user.signInUserSession.accessToken.jwtToken)
        if (FinalStatus.Status == "Success") {
            refreshData();
        }
        resetPopUp();
    }

    function getDateFormat(CreatedDt) {
        return (new Date(CreatedDt).toDateString().substring(4))
    }
    const actionRestriction = useCallback((getItem) => {
        let NotificationID = getItem.SK.split("#")[3]
        let actionList = [];
        if ((props.RoleData?.SendNotificationActivity || props.RoleData?.SendNotificationCourse || props.RoleData?.TrainingSendNotification) && !getItem.IsSuspend) {
            actionList.push(
                {
                    id: 9,
                    Color: "text-blue-700",
                    Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                    name: "Resend",
                    action: () => {
                        router.query["Mode"] == "Edit" ?
                            router.push(`/ActivityManagement/Notification?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}&NotificationID=${NotificationID}`)
                            : props?.TrainingID ? router.push(`/TrainingManagement/TrainingSendNotification?TrainingID=${props?.TrainingID}&NotificationID=${NotificationID}`)
                                : router.push(`/CourseManagement/CourseSendNotification?Mode=CourseDirect&CourseID=${router.query["CourseID"]}&NotificationID=${NotificationID}`)
                    },
                },
            )
        }

        return actionList;
    }, [router, props])

    const gridDataBind = useCallback(
        (viewData) => {
            const rowGrid = [];
            // viewData.sort((a,b)=>new Date(a?.CreatedDate)?.getTime()- new Date(b?.CreatedDate)?.getTime());
            let activityFilter = viewData?.filter((i) => i?.ZoomActivityID == undefined || i?.ZoomActivityID == null);
            activityFilter &&
                activityFilter.map((getItem, index) => {
                    let regex = /(<([^>]+)>)/gi,
                        body = getItem.ActivityDescription,
                        result = body?.replace(regex, "").body?.replace(/&amp;/g, "&").replace(/&nbsp;/g, ' '),
                        actionList = [];
                    actionList = actionRestriction(getItem)
                    rowGrid.push({
                        PK: (
                            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
                        ),
                        SK: (
                            <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
                        ),
                        ActivityId: (
                            <NVLlabel id={"lblActivityId" + (index + 1)} name="ActivityId" text={getItem.SK} />
                        ),
                        SNo: (<NVLlabel id={"lblSNo" + (index + 1)} name="S.No" text={index + 1}></NVLlabel>),
                        Subject: (
                            <>
                                <NVLlabel id={"txtActivityName" + (index + 1)} text={getItem.Subject}></NVLlabel>
                            </>
                        ),
                        CreatedDate: (
                            <NVLlabel
                                id={"txtName" + (index + 1)}
                                text={getDateFormat(getItem.CreatedDate)}
                            ></NVLlabel>
                        ),
                        Type: (
                            <>
                                <NVLlabel
                                    text={getItem.SentType}
                                ></NVLlabel>
                            </>
                        ),
                        Action: (
                            <NVLRapidModal
                                id={"RapidModal" + (index + 1)}
                                ActionList={actionList}
                            ></NVLRapidModal>
                        ),
                    });
                });
            return rowGrid;
        }, [actionRestriction]
    );

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };
    const cancelEvent = (e) => {
        e.preventDefault();
        resetPopUp();
    };
    const variable = {
        PK: "TENANT#" + props.TenantInfo.TenantID,
        SK: router?.query["Mode"] == "Edit" ? `SENDNOTIFICATION#ACTIVITYID#${router.query["ActivityID"]}` : props?.TrainingID ? `SENDNOTIFICATION#TRAININGID#${props?.TrainingID}` : `SENDNOTIFICATION#COURSEID#${router.query["CourseID"]}`
    }

    const pageRoutes = [
        {
            path: router?.query["Mode"] == "Edit" ? "/ActivityManagement/ActivityList" : props?.TrainingID ? "/TrainingManagement/TrainingManagementList" : "/CourseManagement/CourseList",
            breadcrumb: router?.query["Mode"] == "Edit" ? "Activity Management" : props?.TrainingID ? "Training Management" : "Course Management"
        },
        {
            path: "",
            breadcrumb: "Send Notification List"
        }
    ]
    return (
        <>
            <Container title="Send Notification">
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab}
                    IsSearch={props.RoleData?.SeTenanthActivity || props.RoleData?.SeTenanthCourse || props?.RoleData?.SeTenanthTraining ? true : false}
                    ButtonID5="btnSendNotification"
                    LinkName5="Send Notification"
                    className5={props.RoleData?.SendNotificationCourse || props.RoleData?.SendNotificationActivity || props.RoleData?.TrainingSendNotification ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectHome={"/"}
                    RedirectAction5={(e) => headerHandler(e, router?.query["Mode"] == "Edit" ? `/ActivityManagement/Notification?Mode=Edit&ActivityID=${router?.query["ActivityID"]}&ActivityType=${router?.query["ActivityType"]}` : props?.TrainingID ? `/TrainingManagement/TrainingSendNotification?TrainingID=${props?.TrainingID}` : `/CourseManagement/CourseSendNotification?Mode=CourseDirect&CourseID=${router.query["CourseID"]}`)}
                    href5="/ActivityManagement/Notification?Mode=Create" placeholder={"Search "} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshGrid} RedirectAction4={() => refreshGrid()} IsNestedHeader />
                <div className="max-w-full w-full justify-center">
                    <NVLGridTable
                        user={props.user}
                        refershPage={isRefreshing}
                        id="tblActivityList" Search={search}
                        HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXLMSSendNotificationLists}
                        querryName={"listXLMSSendNotificationLists"}
                        variable={variable} />
                </div>
            </Container>
        </>
    );
}