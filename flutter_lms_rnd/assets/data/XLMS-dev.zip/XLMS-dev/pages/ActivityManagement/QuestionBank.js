import NVLlabel from "@components/Controls/NVLlabel";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import { useCallback, useState } from "react";

function QuestionBank(props){
   const [templateList, setTemplateList] = useState("");
   function createOptions(options) {
      let opts = [];
      options &&
        options.map((opt) => {
          opts.push(
            <option key={opt.value} value={opt.value}>
              {opt.text}
            </option>
          );
        });
      return opts;
    }
    const templateBinding = useCallback(
      (a) => {
        const courseTemplate = [{ value: "", text: "Choose" }];
        const publicTemplate = [{ value: "", text: "Choose" }];
        if (templateList && templateList?.length > 0) {
          templateList.map((getItem) => {
            if (!getItem.IsPublic) {
              courseTemplate.push({ value: getItem.SK, text: getItem.TemplateName });
            } else {
              publicTemplate.push({ value: getItem.SK, text: getItem.TemplateName });
            }
          });
        }
        if (a == "Public") {
          return publicTemplate;
        }
        return courseTemplate;
      },
      [templateList]
    );
         return(
            <>
            <div>
            <div className="flex gap-4 ">
           <NVLlabel className="nvl-Def-Label w-52" text="MultipleChoice Type"></NVLlabel>
             </div>
             <div>
                <NVLSettingsCard>
                    <div className="nvl-FormContent flex gap-4">
                       <NVLlabel text="Question"></NVLlabel>
                    </div>
                </NVLSettingsCard>
                <div className="flex gap-3 pt-4">
              <div>
                <NVLlabel text="Use a Template" className="px-6 font-medium text-sky-600"></NVLlabel>
              </div>
              <div className="pl-2">
                <select id="ddlTemplate" className="nvl-SelectField w-96" {...register("ddlTemplate", { shouldValidate: true })}>
                  <optgroup label="Course">{createOptions(templateBinding())}</optgroup>
                  <optgroup label="Public">{createOptions(templateBinding("Public"))}</optgroup>
                </select>
              </div>
             </div>
             </div>
            </div>
            </>
          )
}

export default QuestionBank;