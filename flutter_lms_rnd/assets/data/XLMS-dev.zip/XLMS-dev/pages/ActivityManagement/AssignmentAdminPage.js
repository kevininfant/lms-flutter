import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import { listXlmsActiveCourseBatch, listXlmsActivityEnrollUserListView, listXlmsCourseEnrollUserListView } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

export default function AssignmentAdminPage(props) {
  const router = useRouter();
  const [data, setData] = useState();
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [variable, setVariable] = useState((router.query.CourseID != null || router.query.CourseID != undefined) ? { GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + router.query.CourseID, GsiSK: "BATCH##", Department: "", Designation: "", IsSuspend: false } : { GsiPK: "ACTIVITYID#" + router.query["ActivityID"], GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#", Department: "", Designation: "", IsSuspend: false });
  const pageRoutes = (router.query.CourseID !== undefined) ? [{ path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" }, { path: `/CourseManagement/ModulesList?CourseID=${router.query.CourseID}`, breadcrumb: "Manage Course" }, { path: "", breadcrumb: "AssignmentAdminPage" }] : [{ path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" }, { path: "", breadcrumb: "AssignmentAdminPage" }];
  const SetPageZero = useRef(0);

  const courseId = useMemo(() => { return router.query["CourseID"]; }, [router.query])
  const headerColumn = [
    { HeaderName: "Username/Firstname", Columnvalue: "FirstName", HeaderCss: "!w-3/12 px-6", },
    { HeaderName: "Email", Columnvalue: "EmailID", HeaderCss: "!w-3/12 px-6" },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-3/12 px-6" },
    { HeaderName: "Final Grade", Columnvalue: "Grade", HeaderCss: "!w-1/12 px-6" }
  ];
  const Search = useRef("")
  const Deptdes=useRef({BatchID:""})

  const searchBoxVal = (e) => {
    Search.current = e;
    refreshGrid("noSearch");
  };

  const refreshGrid = useCallback(async (val) => {
    if (val == undefined) {
      Search.current = "";
    }
    if (courseId != null) {
      setValue("dropdown1",Deptdes.current.BatchID)
    }
    setIsRefreshing((count) => {
      return count + 1;
    });
  },[courseId, setValue])

  const validationSchema = Yup.object().shape({
    dropdown1:Yup.string().test("no valid","",val=>{
      if(val!==undefined&&courseId != undefined&&Deptdes.current.BatchID!==val)
      { 
        Deptdes.current.BatchID = val;
        setVariable((prev) => ({...prev,GsiSK: "BATCH#" + val + "#COURSE#ENROLLUSER#"}));
        refreshGrid();
      }
    })
  })

  const batchData = useMemo(() => {
    let temp = [{ value: "", text: "Select Batch" }]
    let badgeData = [...new Map(data?.BatchData?.map(item => [item["BatchID"], item])).values()];
    badgeData?.map((getItem) => {
      temp.push({ value: getItem?.BatchID, text: getItem?.BatchName })
    });
    return temp
  }, [data?.BatchData]);

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, setValue, watch, formState, reset } = useForm(formOptions);
  const { errors } = formState;

  const gridDataBind = useCallback(async (viewData, idx) => {
    function getDateFormat(CreatedDt) {
      return new Date(CreatedDt).toDateString().substring(4);
    }
    const rowGrid = [];
    viewData &&
      viewData?.map((getItem, index) => {
        const status={submit:false,grade:false}
        if(courseId!==undefined&&getItem?.SubmissionAssignment!==null)
        {
          if(JSON.parse(getItem.SubmissionAssignment).hasOwnProperty(router.query.ActivityID)&&JSON.parse(getItem?.SubmissionAssignment)[router.query.ActivityID].length>0)
          {
            status.submit=true;
          }
          else
          {
            status.submit=false;
          }
          if(JSON.parse(getItem?.UserGradeDetails!=undefined?getItem?.UserGradeDetails:"{}").hasOwnProperty(router.query["ModuleID"])&&JSON.parse(getItem?.UserGradeDetails!=undefined?getItem?.UserGradeDetails:"{}")[router.query["ModuleID"]].hasOwnProperty(router.query["ActivityID"]))
          {
            status.grade=true;
          }
          else
          {
            status.grade=false;
          }
        } 
        else
        {
          status.submit=getItem?.SubmissionAssignment!=undefined&&getItem?.SubmissionAssignment!=null&&JSON.parse(getItem?.SubmissionAssignment).length>0?true:false;
          status.grade=getItem?.UserGradeDetails != undefined&&getItem?.UserGradeDetails != null?true:false
        }
        if (getItem != null && !getItem?.IsDeleted) {  
          rowGrid = [...rowGrid, {
            PK: <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />,
            SK: <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />,
            FirstName: <NVLlabel id={"txtName" + (index + 1)} text={getItem.UserName} className="py-2 w-full"></NVLlabel>,
            EmailID: <NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.EmailID} className="py-2 w-full "></NVLlabel>,
            Department: <NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.Department}></NVLlabel>,
            Designation: <NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.Designation}></NVLlabel>,
            EnrollmentDate: <NVLlabel id={"txtName" + (index + 1)} text={getDateFormat((getItem.ModifiedDate == undefined || getItem?.ModifiedDate == null || getItem?.ModifiedDate == "null") ? (getItem?.CreatedDate) : (getItem?.ModifiedDate))}></NVLlabel>,
            Status: <NVLlabel id={"txtStatus" + (index + 1)} text={ status.submit ? "Submitted" : "Not Submitted"} className={`py-2 w-full ${status.submit? "text-green-600" : "text-red-600"} `}></NVLlabel>,
            NumberOfSubmission: <NVLlabel id={"txtStatus" + (index + 1)} text={getItem.NumberOfSubmission} className="py-2 w-full"></NVLlabel>,
            Grade: <NVLButton text={status.grade != undefined&&status.grade? "Grade Again" : "Grade"} className={"rounded-full m-auto font-semibold py-1 w-full bg-slate-300 hover:scale-105 "} 
            onClick={() => router.push((router.query.CourseID !== undefined) ? `/CourseManagement/AssignmentAdminGrade?BatchID=${getItem.BatchID}&UserSub=${getItem.UserSub}&CourseID=${router.query.CourseID}&ActivityID=${router.query.ActivityID}&ModuleID=${router.query.ModuleID}` : `/ActivityManagement/AssignmentAdminGrade?ActivityID=${router.query.ActivityID}&UserSub=${getItem.UserSub}`)} />
          }];
        }
      }
      );
    return rowGrid;
  }, [courseId, router]);

  useEffect(() => {
    if (data?.Length == undefined) {
      setIsRefreshing((data) => {
        return data + 1
      })
    }
  }, [data?.Length])

  useEffect(() => {
    const req=async()=>{
      if(router.query.CourseID!==undefined)
      {
        const batch=await AppsyncDBconnection(listXlmsActiveCourseBatch,{ PK: "TENANT#" + props.TenantInfo?.TenantID + "#COURSEINFO#" + router.query["CourseID"], SK: "COURSEBATCH#", CurrentDate: new Date().toISOString().slice(0, 10),IsDeleted:false},props.user.signInUserSession.accessToken.jwtToken)
        setData(prev=>({...prev,BatchData:batch?.res?.listXlmsActiveCourseBatch?.items}))
        // const course=await AppsyncDBconnection(listXlmsActivityEnrollUserListView,{ GsiPK: "ACTIVITYID#" + router.query["ActivityID"], GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#", Department: "", Designation: "", IsSuspend: false },props.user.signInUserSession.accessToken.jwtToken) 
      }
    }
    req()
    let courseId = decodeURIComponent(String(router.query["CourseID"]));
    let activityId = decodeURIComponent(String(router.query["ActivityID"]));
    if (router.query["CourseID"]) {
      setData(prev=>({...prev,CourseID: courseId }))
    } else {
      setData({ ActivityID: activityId })
    }
  }, [props.TenantInfo?.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query])

  return (
    <>
      <Container title="Enrollment List" PageRoutes={pageRoutes}  >
        <div>
          <NVLHeader IsSearch={true} SearchonChange={(e) => searchBoxVal(e)} placeholder={"Search by Username/emailId"} 
          Search={Search.current}
          onClick1={() => { refreshGrid() }}
          isDropdownRequired1={router.query["CourseID"] && true}
          DropdownData1={batchData}
          register={register} errors={errors}
           IsNestedHeader></NVLHeader>
          <NVLGridTable 
            pageSize={10}
            DonotLoad={false}
            HeaderColumn={headerColumn}
            query={router.query["CourseID"] ?listXlmsCourseEnrollUserListView: listXlmsActivityEnrollUserListView}
            GridDataBind={gridDataBind}
            refershPage={isRefreshing}
            Search={Search.current}
            querryName={router.query["CourseID"] ?"listXlmsCourseEnrollUserListView":"listXlmsActivityEnrollUserListView"}
            variable={variable}
            setPagezero={SetPageZero.current}
            user={props.user}
            id="tblActivityList" />
        </div>
      </Container>
    </>)
}