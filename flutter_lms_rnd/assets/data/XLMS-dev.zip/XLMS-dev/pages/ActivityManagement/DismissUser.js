import NVLAlert, { ModalClose, ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import Container from "@Container/Container";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsCourseEnrollUser, createXlmsEnrollUser } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo, getXlmsCustomField, listXlmsActiveCourseBatch, listXlmsActivityEnrollUserListView, listXlmsCourseEnrollUserListView } from "src/graphql/queries";
import * as Yup from "yup";

function DismissUser(props) {
  const router = useRouter();

  const [isRefreshing, setIsRefreshing] = useState(true);
  const [Data, setData] = useState();
  const [popupValues, setPopupValues] = useState({});
  const [variable, setvariable] = useState((courseId != null || courseId != undefined) ? {
    GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + courseId,
    GsiSK: "BATCH##",
    Department: "",
    Designation: "",
    IsSuspend: false
  } : {
    GsiPK: "ACTIVITYID#" + router.query["ActivityID"],
    GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#",
    Department: "",
    Designation: "",
    IsSuspend: false
  });

  const Search = useRef("")
  const SetPageZero = useRef(0);

  const multipleUserdata = useRef({ id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0 });
  const courseId = useMemo(() => { return router.query["CourseID"]; }, [router.query])

  //Search box
  const searchBoxVal = (e) => {
    Search.current = e;
    refreshGrid("noSearch");
  };

  //Grid data refresh
  const refreshGrid = useCallback(async (e) => {
    if (watch("dropdown1") == "") {
      setValue("dropdown3", "", { shouldValidate: true })
      setValue("dropdown2", "", { shouldValidate: true })
    }
    multipleUserdata.current = { id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0, };
    setValue("chkAll", false);
    reset();
    if (courseId != null) {
      setValue("dropdown1", Deptdes.current.BatchID);
      setValue("dropdown2", Deptdes.current.Department);
      setValue("dropdown3", Deptdes.current.Designation);
    }
    if (e == undefined) {
      Search.current = "";
    }
    setIsRefreshing((count) => {
      return count + 1;
    });
  }, [courseId, reset, setValue, watch])

  useEffect(() => {
    multipleUserdata.current = { id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0, };
    setvariable((data) => {
      return (courseId != null || courseId != undefined) ? { GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + courseId, GsiSK: "BATCH##", Department: "", Designation: "", IsSuspend: false } : { GsiPK: "ACTIVITYID#" + router.query["ActivityID"], GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#", Department: "", Designation: "", IsSuspend: false }
    })
  }, [courseId, props.TenantInfo.TenantID, router.query])

  const initialModalState = useMemo(() => {
    return {
      ModalInfo: "Info", ModalTopMessage: "In Progress", ModalBottomMessage: "Dismiss is in progress.", ModalOnClickEvent: () => {
        ModalClose();
        refreshGrid();
      }
    };
  }, [refreshGrid])
  const Deptdes = useRef({ Department: "", Designation: "", BatchID: "" })

  const [modalValues, setModalValues] = useState(initialModalState);
  const validationSchema = Yup.object().shape({
    dropdown2: Yup.string().test("novalid", "novalid", e => {
      if (Deptdes.current.Department != e && e != undefined) {
        Deptdes.current = { ...Deptdes.current, Department: e }
        setvariable((data) => {
          return {
            ...data,
            Department: e,
          }
        })
        setValue("chkAll", false)
        refreshGrid()
      }
      return true;
    }),
    dropdown3: Yup.string().test("novalid", "novalid", e => {
      if (Deptdes.current.Designation != e && e != undefined) {
        Deptdes.current = { ...Deptdes.current, Designation: e }
        setvariable((data) => {
          return {
            ...data,
            Designation: e,
          }
        })
        setValue("chkAll", false)
        setValue("chkAll", false);
        refreshGrid()
      }
      return true;

    }),
    dropdown1: Yup.string().test("novalid", "", e => {
      if (Deptdes.current.BatchID != e && courseId != undefined && e != undefined) {
        Deptdes.current.BatchID = e;
        SetPageZero.current = SetPageZero.current + 1;
        setvariable((data) => { return { ...data, GsiSK: "BATCH#" + e + "#COURSE#ENROLLUSER#" } });
        setValue("chkAll", false)
        refreshGrid();
      }
    }),
    ddlSearch: router.query["CourseID"] ? Yup.string()
      .required("Please Select The Field")
      .test("NOValid", "ChangeHandler", (e) => {

      })
      : Yup.string().nullable(),
    chkAll: Yup.bool().nullable().test("check", "defaulterror", e => {
      let temp = watch(multipleUserdata.current.id)
      if (e && multipleUserdata.current.currentstate && (temp.indexOf(false) != -1)) {
        setValue("chkAll", false)
        multipleUserdata.current.currentstate = false;
      } else if (e) {
        multipleUserdata.current.id.map((getItem) => {
          if (!watch(getItem))
            setValue(getItem, true);
        })
        multipleUserdata.current.currentstate = true;
      }
      else if (!e && multipleUserdata.current.currentstate) {
        multipleUserdata.current.id.map((getItem) => {
          if (watch(getItem))
            setValue(getItem, false);
        })
        multipleUserdata.current.currentstate = false;
      }
      else if (!e && !multipleUserdata.current.currentstate) {
        let check = 0;
        multipleUserdata.current.id.map((getItem) => {
          if (!watch(getItem)) {
            check++;
          }
        });
        if (check == 0) {
          setValue("chkAll", true);
          multipleUserdata.current.currentstate = true;
        }
      }
      temp = watch(multipleUserdata.current.id)
      if (!e && (temp.indexOf(false) == -1)) {
        setValue("chkAll", true)
      }
      return true;
    }),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, setValue, watch, formState, reset } = useForm(formOptions);
  const { errors } = formState;


  const finalResponse = useCallback((finalStatus) => {
    if (finalStatus != "Success") {
      setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: "Something went wrong while dismiss the user!", });
      ModalOpen();
    } else {
      setModalValues(initialModalState)
      ModalOpen();
    }

  }, [initialModalState])

  useEffect(() => {
    const DataSource = async (i) => {
      let tenantId = props.user.attributes["custom:tenantid"];
      let courseId = decodeURIComponent(String(router.query["CourseID"]));
      let activityId = decodeURIComponent(String(router.query["ActivityID"]));
      let batchId = decodeURIComponent(String(router.query["BatchID"]));
      let ActivityType = decodeURIComponent(String(router.query["ActivityType"]));
      let courseName = decodeURIComponent(String(router.query["CourseName"]));
      let batchData = await AppsyncDBconnection(listXlmsActiveCourseBatch, { PK: "TENANT#" + props.TenantInfo?.TenantID + "#COURSEINFO#" + router.query["CourseID"], SK: "COURSEBATCH#", CurrentDate: new Date().toISOString().slice(0, 10), IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      let departmentList = await AppsyncDBconnection(getXlmsCustomField, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#DropdownMenu#FIELDID#DDLDepartment001" }, props.user.signInUserSession.accessToken.jwtToken);
      let designationList = await AppsyncDBconnection(getXlmsCustomField, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#DropdownMenu#FIELDID#DDLDesignation001" }, props.user.signInUserSession.accessToken.jwtToken);
      const courseDataResponse = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#" + router.query["CourseID"] }, props.user.signInUserSession.accessToken.jwtToken);
      let tempDeptList = departmentList.res?.getXlmsCustomField?.FieldOptions != undefined ? JSON.parse(departmentList.res?.getXlmsCustomField?.FieldOptions) : [{ text: "", value: "" }];
      let tempDesignaionList = designationList.res?.getXlmsCustomField?.FieldOptions != undefined ? JSON.parse(designationList.res?.getXlmsCustomField?.FieldOptions) : [{ text: "", value: "" }];
      tempDeptList[0].text = "Filter By Department";
      tempDesignaionList[0].text = "Filter By Designation";
      if (router.query["CourseID"]) {
        setData({ CourseData: courseDataResponse?.res?.getXlmsCourseManagementInfo, BatchData: batchData.res?.listXlmsActiveCourseBatch?.items, TenantID: tenantId, CourseID: courseId, BatchID: batchId, Department: tempDeptList, Designation: tempDesignaionList, CourseName: courseName })
      } else {
        setData({ TenantID: tenantId, ActivityID: activityId, ActivityType: ActivityType, Department: tempDeptList, Designation: tempDesignaionList, })
      }
    }
    DataSource();
    return (() => {
      setData((temp) => { return { ...temp } });
    })
  }, [Data?.CourseID, props.TenantInfo?.TenantID, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query])

  const popup = useCallback((type, Content) => {
    let isPopupVisible = false;
    multipleUserdata.current.values.map(async (item, index) => {
      if (watch(item.id)) {
        isPopupVisible = true;
        return;
      }
    })
    if (isPopupVisible) {
      setPopupValues({ Content: Content, Type: type, isWarring: false });
    } else {
      setPopupValues({ Content: "select atleast one user to withdraw enrollment", Type: "", isWarring: true });
    }
  }, [watch])

  const cancelEvent = (e) => {
    e.preventDefault();
    resetPopUp();
  };

  const removeUser = useCallback(async () => {
    let deletedStatus;
    if (Data?.CourseID) {
      let deletedUersList = [];
      multipleUserdata.current.values.map(async (item, index) => {
        if (watch(item.id)) {
          deletedUersList = [...deletedUersList, { PK: item.PK, SK: item.SK, IsSuspend: true,LastModifiedDate:new Date(),UserSub:item.UserSub,TenantID:props.TenantInfo?.TenantID ,CourseID:Data?.CourseID,BatchID:Deptdes.current.BatchID}];
        }
      });
      deletedUersList = [...new Map(deletedUersList?.map(item => [item["SK"] && item["PK"], item])).values()];
      deletedStatus = await AppsyncDBconnection(createXlmsCourseEnrollUser,
        { input: [...deletedUersList], }, props?.user?.signInUserSession?.accessToken?.jwtToken);
    }
    else {
      let deletedUersList = [];
      multipleUserdata.current.values.map(async (item, index) => {
        if (watch(item.id)) {
          deletedUersList = [...deletedUersList, { PK: item.PK, SK: item.SK, IsSuspend: true ,LastModifiedDate:new Date(),UserSub:item.UserSub,TenantID:props.TenantInfo?.TenantID }];
        }
      });
      deletedUersList = [...new Map(deletedUersList?.map(item => [item["SK"] && item["PK"], item])).values()];
      deletedStatus = await AppsyncDBconnection(createXlmsEnrollUser,
        { input: [...deletedUersList], }, props?.user?.signInUserSession?.accessToken?.jwtToken);
    }
    finalResponse(deletedStatus?.Status);
  }, [Data?.CourseID, finalResponse, props?.user?.signInUserSession?.accessToken?.jwtToken, props.TenantInfo?.TenantID, watch]);

  const headerColumn = useMemo(() => [
    { HeaderName: <NVLCheckbox id="chkAll" className="cursor-pointer" errors={errors} register={register} text="SelectAll" />, Columnvalue: "SelectAll", HeaderCss: "!w-2/12" },
    { HeaderName: "UserName", Columnvalue: "UserName", HeaderCss: "!w-2/12" },
    { HeaderName: "EmailID", Columnvalue: "EmailID", HeaderCss: "!w-3/12" },
    { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "!w-2/12" },
    { HeaderName: "Designation", Columnvalue: "Designation", HeaderCss: "!w-2/12" },
    { HeaderName: "Enrollment Date", Columnvalue: "EnrollmentDate", HeaderCss: "!w-2/12" },
  ], [errors, register]);

  const pageChangeCall = useCallback((page) => {
    multipleUserdata.current = { ...multipleUserdata.current, page: page }
  }, [])

  useEffect(() => {
    if (Data?.Length == undefined) {
      setIsRefreshing((data) => {
        return data + 1
      })
    }
  }, [Data?.Length])
  const gridDataBind = useCallback(async (viewData, idx) => {
    function getDateFormat(CreatedDt) {
      return new Date(CreatedDt).toDateString().substring(4);
    }
    const rowGrid = [];
    let temp = { ...multipleUserdata.current, currentstate: false }
    let isCount = multipleUserdata.current.Called

    viewData &&
      viewData?.map((getItem, index) => {
        let tempusername = (getItem.FirstName != undefined || getItem.LastName != undefined) ? (getItem.FirstName).concat(getItem.LastName) : ""
        if (getItem != null && !getItem?.IsDeleted) {
          rowGrid = [...rowGrid, {
            PK: <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />,
            SK: <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />,
            SelectAll: <NVLCheckbox id={"chkAll" + (isCount)} className="cursor-pointer" errors={errors} register={register} />,
            UserName: <NVLlabel id={"txtName" + (index + 1)} text={tempusername} className="py-2"></NVLlabel>,
            EmailID: <NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.EmailID}></NVLlabel>,
            Department: <NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.Department}></NVLlabel>,
            Designation: <NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.Designation}></NVLlabel>,
            EnrollmentDate: <NVLlabel id={"txtName" + (index + 1)} text={getDateFormat((getItem.ModifiedDate == undefined || getItem?.ModifiedDate == null || getItem?.ModifiedDate == "null") ? (getItem?.CreatedDate) : (getItem?.ModifiedDate))}></NVLlabel>,
          }];
          let id = "chkAll" + (isCount);
          temp = {
            ...temp, id: [...temp.id, id], values: [...temp.values,
            {
              PK: getItem.PK,
              SK: getItem.SK,
              id: id,
              UserSub:getItem.UserSub,
              currentstate: watch(id)
            }]
          }
          isCount++;
          if (watch("chkAll")) {
            setValue("chkAll", false);
          }
        }
        multipleUserdata.current = { ...temp, Called: isCount };
      });
    setData((data) => {
      return { ...data, Length: temp.id?.length }
    })
    return rowGrid;
  }, [errors, register, watch, setValue]);

  const resetPopUp = useCallback(() => {
    multipleUserdata.current = { id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0, };
    setPopupValues({ PK: "", SK: "", Content: "", Type: "", isWarring: false });
    refreshGrid();
  }, [refreshGrid])
  async function updateField(e) {
    e.preventDefault();
    removeUser();
    resetPopUp();
  }

  useEffect(() => {
    multipleUserdata?.current?.values?.map(async (item, index) => {
      if (watch("chkAll"))
        setValue(item.id, true)
      else
        setValue(item.id, false)
    });
    return null;

  }, [setValue, multipleUserdata, watch, batchData])

  const pageRoutes = [
    { path: Data?.ActivityID ? "/ActivityManagement/ActivityList" : "/CourseManagement/CourseList", breadcrumb: Data?.ActivityID ? "Activity Management" : "Course Management" },
    { path: "", breadcrumb: "Enrollment List" }];

  const batchData = useMemo(() => {
    let temp = [{ value: "", text: "Select Batch" }]
    let badgeData = [...new Map(Data?.BatchData?.map(item => [item["BatchID"], item])).values()];
    badgeData?.map((getItem) => {
      temp.push({ value: getItem?.BatchID, text: getItem?.BatchName })
    });
    return temp
  }, [Data?.BatchData]);

  const headerHandler = (e, url) => {
    e.preventDefault();
    router.push(url);
  };

  return (
    <>
      <Container title="Enrollment List" PageRoutes={pageRoutes} loader={Data?.TenantID == undefined} >
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage}
          MessageBottom={modalValues.ModalBottomMessage}
          ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <div className="pt-3"></div>
        <NVLHeader IsSearch={true} SearchonChange={(e) => searchBoxVal(e)} onClick1={() => { refreshGrid() }} className5={(router.query["CourseID"]) ? (Data?.CourseData?.ActiveActivityCount == 0 || Data?.CourseData?.ActiveActivityCount == undefined || Data?.CourseData?.ActiveActivityCount == null) ? "pointer-events-none nvl-button-gray" : "nvl-button-success" : "nvl-button-success"} LinkName5={"Enroll"} type5={"button"} RedirectAction5={(e) => headerHandler(e, (courseId == undefined || courseId == null) ? `EnrollUser?Mode=EnrollmentList&ActivityID=${Data?.ActivityID}&ActivityType=${Data.ActivityType}` : `/CourseManagement/CourseEnrollUser?Mode=EnrollmentList&CourseID=${courseId}&CourseName=${Data?.CourseName}`)} placeholder={"Search by Username/emailId"}
          Search={Search.current}
          isDropdownRequired2={true}
          isDropdownRequired3={true}
          dropdownclass2={router.query["CourseID"] && (watch("dropdown1") == "" || watch("dropdown1") == undefined) ? "Disabled" : ""}
          dropdownclass3={router.query["CourseID"] && (watch("dropdown1") == "" || watch("dropdown1") == undefined) ? "Disabled" : ""}
          IsDropdownDisable2={router.query["CourseID"] && (watch("dropdown1") == "" || watch("dropdown1") == undefined) ? true : false}
          IsDropdownDisable3={router.query["CourseID"] && (watch("dropdown1") == "" || watch("dropdown1") == undefined) ? true : false}
          isDropdownRequired1={router.query["CourseID"] && true} DropdownData2={Data?.Department} DropdownData3={Data?.Designation} DropdownData1={batchData} IsNestedHeader register={register} errors={errors} />
        <div className="">
          <NVLGridTable user={props.user}
            DonotLoad={false}
            refershPage={isRefreshing}
            id="tblUserList"
            Search={Search.current} HeaderColumn={headerColumn}
            GridDataBind={gridDataBind}
            query={router.query["ActivityID"] ? listXlmsActivityEnrollUserListView : listXlmsCourseEnrollUserListView}
            LoadInSinglePage={true}
            querryName={router.query["ActivityID"] ? "listXlmsActivityEnrollUserListView" : "listXlmsCourseEnrollUserListView"}
            variable={variable}
            pageChangeCall={pageChangeCall}
            setPagezero={SetPageZero.current} />
        </div>
        {Data?.Length > 0 && <div className="px-2 mt-2"> <NVLButton text="Withdraw Enrollment" ButtonType="danger" className="px-40 nvl-button bg-red-800 text-white" type={"submit"} SubmitClick={() => removeUser()}
          onClick={() => popup("isDelete", "Do you wish to Proceed?")} /></div>}
        {popupValues?.isWarring ?
          <NVLModalPopup CancelClick={(e) => cancelEvent(e)}
            ButtonNotext="OK"
            CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} /> : <NVLModalPopup SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)}
              ButtonNotext="NO"
              ButtonYestext="Yes"
              CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />}
      </Container>
    </>
  );
}
export default DismissUser;