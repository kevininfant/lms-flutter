import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLImageUpload from "@components/Controls/NVLImageUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { APIGatewayGetRequest, APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { WithContext as ReactTags } from "react-tag-input";
import { Regex } from "RegularExpression/Regex";
import { createXlmsActivityManagementInfo, createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo, createXlmsCourseModule, createXlmsTrainingManagementActivityInfo, updateXlmsActivityManagementInfo, updateXlmsCourseManagementInfo, updateXlmsCourseModule, updateXlmsTrainingManagementActivityInfo } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseActivityConfig, getXlmsCourseManagementInfo, getXlmsCourseModule, listXlmsActivityManagementInfos, listXlmsActivityNameExistInfos, listXlmsCourseBatch, listXlmsCourseManagementInfo, listXlmsCourseManagementModuleActivityExistInfos, listXlmsCourseModule, listXlmsCourseModulesKeys } from "src/graphql/queries";
import * as Yup from "yup";


function ActivityInfo(props) {
  const router = useRouter();
  const activityFile = useRef();
  const [pageData, setPageData] = useState(props);
  const [courseData, setCourseData] = useState();
  const zoomMode = useMemo(() => {
    let mode;
    if ((pageData?.mode == "PreAssessment" || pageData?.mode == "PostAssessment" || pageData?.mode == "Feedback") && pageData?.EditData != undefined) {
      mode = "Edit"
    } else if ((pageData?.mode == "PreAssessment" || pageData?.mode == "PostAssessment" || pageData?.mode == "Feedback") && pageData?.EditData == undefined) {
      mode = "Create"
    }
    return mode;
  }, [pageData?.EditData, pageData?.mode])

  const [logo, setLogo] = useState({
    Logofile: (pageData?.mode == "Edit" || pageData?.mode == "ModuleEdit" || zoomMode == "Edit") && pageData.EditData?.ThumbNailPath != undefined ? pageData.EditData?.ThumbNailPath : null,
    ImgHeight: (pageData?.mode == "Edit" || pageData?.mode == "ModuleEdit" || zoomMode == "Edit") && pageData.EditData?.ThumbNailPath != undefined ? pageData.EditData?.ThumbNailPath != null ? "w-44 h-20" : "" : "",
    lblFile: "",
    uploadImage: "",
    TentImgUrl: (pageData?.mode == "Edit" || pageData?.mode == "ModuleEdit" || zoomMode == "Edit") && pageData.EditData?.ThumbNailPath != undefined ? pageData.EditData?.ThumbNailPath : null,
    setimg: "",
  });

  useEffect(() => {
    const fetchData = async (i) => {
      let tenantName = props.user.attributes["name"];
      let tenantID = props.user.attributes["custom:tenantid"];
      let mode = router.query["Mode"];
      let activityID = router.query["ActivityID"];
      let activityType = router.query["ActivityType"];
      let activityData = await AppsyncDBconnection(getXlmsCourseActivityConfig, { PK: "XLMS#ACTIVITY", SK: "ACTIVITY#ACTIVITYTYPE", }, props.user.signInUserSession.accessToken.jwtToken);
      let editData, editZoomData, courseData, moduleActivityData;
      if (mode == "ModuleDirect") {
        let moduleSingleDataResponse = await AppsyncDBconnection(getXlmsCourseModule, {
          PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + router.query["CourseID"],
          SK: "COURSEMODULE#" + props.ModuleData?.ModuleID,
        }, props.user.signInUserSession.accessToken.jwtToken)
        let moduleDataResponse = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + tenantID, SK: "COURSEID#" + router.query["CourseID"] + "#MODULEID#" + props.ModuleData?.ModuleID + "#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken)
        let courseDataResponse = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantID, SK: "COURSEINFO#" + router.query["CourseID"], }, props.user.signInUserSession.accessToken.jwtToken);
        courseData = courseDataResponse?.res?.getXlmsCourseManagementInfo
        moduleActivityData = moduleDataResponse?.res?.listXlmsCourseManagementInfo?.items
        setCourseData({ CourseData: courseData, ModuleActivityData: moduleActivityData, ModuleSingleDataResponse: moduleSingleDataResponse?.res?.getXlmsCourseModule })
      }
      if (mode != "ModuleEdit" && mode != "ModuleDirect" && props.CourseID == undefined && (pageData?.mode != "TrainingDirect")) {
        if (mode == "Edit" && !router.query["ZoomActivityID"]) {
          editData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + tenantID, SK: "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityID, }, props.user.signInUserSession.accessToken.jwtToken);
        } else if (mode == "Edit" && router.query["NavigationMode"] != undefined) {
          editZoomData = await AppsyncDBconnection(listXlmsActivityManagementInfos, { PK: "TENANT#" + tenantID, SK: "ACTIVITYTYPE#" + activityType + "#ZOOM#" + router.query["ZoomActivityID"] + "#" + router.query["NavigationMode"], }, props.user.signInUserSession.accessToken.jwtToken);
        } else {
          editZoomData = await AppsyncDBconnection(listXlmsActivityManagementInfos, { PK: "TENANT#" + tenantID, SK: "ACTIVITYTYPE#" + activityType + "#ZOOM#" + router.query["ZoomActivityID"] + "#" + router.query["Mode"], }, props.user.signInUserSession.accessToken.jwtToken)
        }
        if (pageData?.mode != "TrainingDirect") {
          let ZoomData = editZoomData?.res?.listXlmsActivityManagementInfos?.items?.[0]
          let FinalEdit = (mode == "Edit" && !router.query["ZoomActivityID"]) ? editData?.res?.getXlmsActivityManagementInfo : ZoomData
          let typesOfActy = activityData.res?.getXlmsCourseActivityConfig?.ActivityType != undefined && JSON.parse(activityData.res?.getXlmsCourseActivityConfig?.ActivityType).filter((Act) => {
            return Act != "Survey"
          })
          let typeOfAcitivities = { ...activityData.res?.getXlmsCourseActivityConfig, ActivityType: JSON.stringify(typesOfActy) }
          const temp = {
            ActivityData: typeOfAcitivities, EditData: FinalEdit, TenantName: tenantName, TenantID: tenantID, mode: mode, ActivityType: activityType, user: props.user,
            CourseData: courseData
          }
          setPageData((data) => { return { ...data, ...temp } });
          setLogo({ Logofile: mode == "Edit" || mode == "ModuleEdit" || zoomMode == "Edit" ? FinalEdit?.ThumbNailPath : null, ImgHeight: mode === "Edit" || mode == "ModuleEdit" || zoomMode == "Edit" ? FinalEdit?.ThumbNailPath != null ? "w-44 h-20" : "" : "", lblFile: "", uploadImage: "", TentImgUrl: mode === "Edit" || mode == "ModuleEdit" || zoomMode == "Edit" ? FinalEdit?.ThumbNailPath : null, setimg: "", })
        }

      }
    }
    fetchData();
    return (() => {
      setPageData((temp) => { return { ...temp } });
    })
  }, [zoomMode, props.CourseID, props.user, router.query, props?.TenantInfo?.TenantID, props.ModuleData?.ModuleID, pageData?.mode]);

  const navigationHandler = useCallback((ButtonName, ActivityID, ActivityType, SK) => {
    if (ButtonName == "SaveAndContinue") {
      if (pageData?.mode == "TrainingDirect") {
        return router.push(`/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${ActivityID}&ActivityType=${ActivityType}&TrainingID=${pageData?.TrainingId}&TrainingName=${pageData?.TrainingName}&AssessmentType=${pageData?.AssessmentType}&${pageData?.Root == "TemplateList" ? "Root=TemplateList" : ""}`);
      } else if (props.CourseID != undefined) {
        if (pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit") {
          return router.push(`/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${ActivityID}&ActivityType=${ActivityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleId}`);
        } else {
          return router.push(`/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${ActivityID}&ActivityType=${ActivityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleId}&ZoomActivityID=${props.ZoomActivityID}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["Mode"]}`);
        }
      } else {
        if (router.query["ZoomActivityID"] != undefined) {
          if (!router.query["NavigationMode"]) {
            return router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${ActivityID}&ActivityType=${ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["Mode"]}`)
          } else {
            return router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${ActivityID}&ActivityType=${ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["NavigationMode"]}&NavigationMode=List`)
          }
        } else {
          return router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${ActivityID}&ActivityType=${ActivityType}`);
        }
      }
    }
    else {
      if (pageData?.mode == "TrainingDirect") {
        return router.push(`/TrainingManagement/TrainingManagementList`);
      } else if (router.query["ZoomActivityID"] != undefined) {
        if (!router.query["NavigationMode"]) {
          return router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`)
        } else {
          return router.push(`/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`)
        }
      } else {
        return router.push(`/ActivityManagement/ActivityList`);
      }
    }
  }, [pageData?.mode, pageData?.TrainingId, pageData?.TrainingName, pageData?.AssessmentType, pageData?.Root, props.CourseID, props.ModuleId, props.ZoomActivityID, router]);

  const previousState = useRef({ txtActivityName: {} });
  const [isRefresh, setisRefresh] = useState(true);
  const [tags, setTags] = useState([]);
  const [message, setMessage] = useState("");
  const [modalValues, setModalValues] = useState({
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => { router.push("/ActivityManagement/ActivityList"); },
  });

  useEffect(() => {
    if (pageData.mode == "TrainingDirect" && (pageData.AssessmentType == "Pre-Assessment" || pageData.AssessmentType == "Post-Assessment")) {
      setValue("ddlSelectActivity", pageData?.ActivityType);
      setValue("txtActivityName", pageData?.EditData?.TrainingName ? pageData?.EditData?.TrainingName : pageData?.TrainingName + "-" + pageData.AssessmentType)
    }
    if (pageData.mode == "TrainingDirect" && (pageData.ActivityType == "Survey" || pageData.ActivityType == "Feedback")) {
      setValue("ddlSelectActivity", pageData?.ActivityType);
      setValue("txtActivityName", pageData?.EditData?.TrainingName ? pageData?.EditData?.TrainingName : pageData?.TrainingName + "-" + (pageData?.ActivityType == "Survey" ? "Effectiveness Survey" : "Feedback"))
    }
    if (pageData.mode == "PreAssessment" || pageData.mode == "PostAssessment" || pageData.mode == "Feedback") {
      setValue("ddlSelectActivity", pageData?.ActivityType);
      setValue("txtActivityName", router.query["ZoomActivityName"] + "-" + pageData.mode)
    }
    if (pageData?.mode == "ModuleDirect") {
      setValue("ddlSelectActivity", pageData?.ActivityType);
    }
    if (message != "") {
      message?.on("text-change", () => {
        if (getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {
          setValue("RichTextBox", "Empty", { shouldValidate: true });
        } else {
          setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
        }
      });
    }
  }, [message, pageData, pageData?.ActivityType, pageData.mode, router.query, setValue]);

  const validationSchema = Yup.object().shape({

    txtActivityName: (pageData?.mode == "PreAssessment" || pageData?.mode == "PostAssessment" || pageData?.mode == "Feedback") ? Yup.string() :
      Yup.string().when("ddlSelectActivity", {
        is: "",
        then: Yup.string().test("", "Before choose Activity", () => { return false; }),
        otherwise: Yup.string().required("Activity name is required").matches(Regex("AlphanumSpecialCharModified"), "Invalid Activity Name").max(props.TrainingId != undefined ? 272 : 250, "Maximum 250 characters Reached")
          .test("name", "Activity name already exists", async (e, { createError }) => {
            if ((pageData?.mode.toLowerCase() == "edit" || pageData?.mode.toLowerCase() == "moduleedit") && (e == pageData?.EditData?.ActivityName)) {
              return true;
            }
            if (e == "" || e == undefined || e == []) {
              previousState.current = { ...previousState.current, txtActivityName: { previousVal: e, previousState: false }, };
              return createError({ message: "Activity name cannot be empty" })
            }
            if (previousState?.current?.txtActivityName?.previousVal != undefined && e == previousState?.current.txtActivityName?.previousVal) {
              return previousState?.current.txtActivityName.previousState;
            }
            let query = pageData?.mode == "ModuleEdit" || pageData?.mode == "ModuleDirect" ? listXlmsCourseManagementModuleActivityExistInfos : listXlmsActivityNameExistInfos;
            let tenantId = pageData?.mode == "ModuleEdit" || pageData?.mode == "ModuleDirect" ? props.TenantInfo.TenantID : pageData?.TenantID;
            let variables = pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" ? { PK: "TENANT#" + tenantId, SK: "COURSEID#" + props.ModuleData?.CourseID + "#MODULEID#" + props.ModuleData?.ModuleID + "#ACTIVITYTYPE#", ActivityNameLowerCase: e.toLowerCase(), IsDeleted: false } : { PK: "TENANT#" + tenantId, SK: "ACTIVITYTYPE#", ActivityNameLowerCase: e.toLowerCase(), };
            let getResponse = await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
            if (getResponse.Status == "Success") {
              let getData = pageData?.mode == "ModuleEdit" || pageData?.mode == "ModuleDirect" ? getResponse?.res?.listXlmsCourseManagementModuleActivityExistInfos?.items : getResponse?.res?.listXlmsActivityNameExistInfos?.items;
              let isData = true;
              if (getData?.length > 0) {
                getData?.map((e) => {
                  if (e.ActivityType == watch("ddlSelectActivity")) {
                    isData = false;
                    return;
                  }
                });
                if (!isData) {
                  previousState.current = { ...previousState.current, txtActivityName: { previousVal: e, previousState: false }, };
                  return false;
                }
              }
              previousState.current = { ...previousState.current, txtActivityName: { previousVal: e, previousState: true }, };
              return true;
            }
            return createError({ message: "server error" });
          })
      }),

    ReactTags: Yup.string()
      .test("testReactTags", "Keywords is Required", (e) => {
        return true;
      })
      .nullable(),
    RichTextBox: Yup.string().max(500, "Maximum character exceeds").nullable(),
    ddlSelectActivity: Yup.string().required("Choose a activity").test("Choose a activity", "Choose a activity", (e) => {
      if (errors?.txtActivityName?.message == "Before choose Activity") {
        clearErrors(["txtActivityName"])
      }
      if (e == undefined || e == "" || e == null) {
        return false;
      } else if (activityFile.current != e) {
        if ((watch("txtActivityName") == undefined || watch("txtActivityName") == "")) {
          return true;
        }
        setValue("txtActivityName", watch("txtActivityName"), { shouldValidate: true });
        activityFile.current = e;
        previousState.current = {
          ...previousState.current,
          txtActivityName: { previousVal: undefined, previousState: true },
        };

      }
      return true;
    }),
    chkPageShowOnCourse: Yup.bool().default(false),
    imageControl: Yup.string().nullable(),
    submit: Yup.string().nullable(),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, watch, reset, formState, clearErrors } = useForm(formOptions);
  const { errors } = formState;

  useEffect(() => {

    if (pageData?.mode == "Edit" || pageData?.mode == "ModuleEdit" || zoomMode == "Edit" || (pageData?.mode == "TrainingDirect" && pageData?.EditData)) {
      setValue("txtActivityName", pageData?.mode == "TrainingDirect" && (pageData?.AssessmentType == "Pre-Assessment" || pageData?.AssessmentType == "Post-Assessment") ? pageData?.TrainingName + "-" + pageData?.AssessmentType : pageData?.mode != "TrainingDirect" ? pageData.EditData?.ActivityName : pageData?.TrainingName + "-" + (pageData?.ActivityType == "Survey" ? "Effectiveness Survey" : "Feedback"));
      setValue("ddlSelectActivity", pageData.EditData?.ActivityType);
      setValue("ThumbNailPath", pageData.EditData?.ThumbNailPath);
      setValue("chkPageShowOnCourse", pageData.EditData?.IsShowOnCoursePage);
      setValue("imageControl", pageData.EditData?.ThumbNailPath == null ? "" : "Image");
      if (message != "") {
        setHTMLContents(pageData.EditData?.ActivityDescription, message);
        setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
        message?.history?.clear();
      }
    }
  }, [props, setValue, message, router.query, pageData.EditData, pageData?.mode, zoomMode, pageData.ActivityType, pageData?.TrainingName, pageData?.AssessmentType]);

  let activity = pageData?.ActivityData?.ActivityType && JSON.parse(pageData?.ActivityData?.ActivityType);
  const activityList = [{ value: "", text: "Select" }];

  if (activity != undefined) {
    activity?.map((getItem) => {
      if (getItem == "ScormPackage") {
        activityList.push({ value: getItem, text: "SCORM Package" });
      } else {
        activityList.push({ value: getItem, text: getItem });
      }
    });
  }

  const keyCodes = { comma: 188, enter: 13, tab: 9, };
  const delimiters = [keyCodes.comma, keyCodes.enter, keyCodes.tab];
  const handleDelete = (i) => {
    setTags(tags.filter((tag, index) => index !== i));
    setValue("ReactTags", "Delete", { shouldValidate: true });
  };

  const handleAddition = (tag) => {
    setTags([...tags, tag]);
    setValue("ReactTags", "Add", { shouldValidate: true });
  };

  const handleDrag = (tag, currPos, newPos) => {
    const newTags = tags.slice();
    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);
    setTags(newTags);
  };

  useMemo(() => {
    if (pageData.EditData != undefined) {
      if ((pageData?.mode == "Edit" || pageData?.mode == "ModuleEdit" || zoomMode == "Edit" || pageData?.mode == "TrainingDirect") && pageData.EditData?.Keywords) {
        setTags(JSON.parse(pageData.EditData?.Keywords));
      }
    }
    setisRefresh(false);
  }, [pageData.EditData, pageData?.mode, zoomMode]);

  const finalResponse = useCallback((finalStatus, ButtonName, ActivityID, ActivityType, SK) => {
    if (finalStatus != "Success") {
      setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus, });
      ModalOpen();
      return;
    } else {
      setValue("submit", "");
      setModalValues({ ModalInfo: "Success", ModalOnClickEvent: () => { navigationHandler(ButtonName, ActivityID, ActivityType, SK); }, });
      ModalOpen();
    }
  }, [navigationHandler, setValue]);

  const createFile = (bits, name) => {
    try {
      return new File(bits, name, {
        type: "image/" + name.split(".").pop(),
        lastModified: new Date(),
      });
    } catch (e) {
      let myBlob = new Blob(bits);
      myBlob.lastModified = new Date();
      myBlob.name = name;
      return myBlob;
    }
  };

  const uploadThumbnail = useCallback(
    async (e) => {
      if (watch("ddlSelectActivity") == "") {
        setValue("ddlSelectActivity", "", { shouldValidate: true });
        document.getElementById("fulogo").value = null;
        return;
      }
      if (e.target.files.length == 0) {
        return;
      }
      document.getElementById("Filerequired").style.display = "none";
      document.getElementById("divCreateActivity")?.classList?.add("pointer-events-none");
      setValue("imageControl", "Upload");
      const file = e.target.files[0];
      let ActivityType = pageData?.mode != "Edit" ? watch("ddlSelectActivity") : pageData?.EditData?.ActivityType;
      let extension = e.target.files[0].name.substring(e.target.files[0].name.lastIndexOf(".") + 1).toLowerCase();
      let FileName = e.target.files[0].name;
      if ((file.name.split(".").pop() == "jpg" && file.type.split("/").pop() == "jpeg") || (file.name.split(".").pop() == "jpeg" && file.type.split("/").pop() == "jpg")) {
        FileName = FileName.split(".")[0] + "." + file.type.split("/").pop();
        file = createFile([file], FileName);
      }
      setLogo({ Logofile: file, lblFile: "", ImgHeight: "w-44 h-20", uploadImage: file, TentImgUrl: FileName, });

      if (process.env.ACTIVITY_THUMBNAIL_EXTENTION.indexOf(extension) <= -1) {
        setLogo({ ...logo, Logofile: null, lblFile: "Please upload only .jpg, .jpeg, .png file!", });
        setValue("imageControl", "Please upload only .jpg, .jpeg, .png file!", { shouldValidate: true, });
        document.getElementById("Filerequired").innerHTML =
          "Please upload only .jpg, .jpeg, .png file!";
        document.getElementById("Filerequired").style.display = "block";
        document
          .getElementById("divCreateActivity")
          ?.classList?.remove("pointer-events-none");
        return false;
      } else if (file.type.split("/").pop() != file.name.split(".").pop()) {
        setLogo({
          ...logo,
          Logofile: null,
          lblFile: " File format seems to be changed!",
        });
        setValue("imageControl", " File format seems to be changed!!", {
          shouldValidate: true,
        });
        document.getElementById("Filerequired").innerHTML =
          " File format seems to be changed!";
        document.getElementById("Filerequired").style.display = "block";
        document
          .getElementById("divCreateActivity")
          ?.classList?.remove("pointer-events-none");
        return false;
      } else if (file.size > process.env.ACTIVITY_THUMBNAIL_SIZE) {
        setLogo({
          ...logo,
          Logofile: null,
          lblFile: "File size should be 50KB",
        });
        setValue("imageControl", "File size should be 50KB", {
          shouldValidate: true,
        });
        document.getElementById("Filerequired").innerHTML =
          "File size should be 50KB";
        document.getElementById("Filerequired").style.display = "block";
        document
          .getElementById("divCreateActivity")
          ?.classList?.remove("pointer-events-none");
        return false;
      }

      const filename = encodeURIComponent(file.name);
      extension = filename.substring(filename.lastIndexOf(".") + 1).toLowerCase();
      let groupMenuName = pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" ? "CourseManagement" : "ActivityManagement";
      let menuId = pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" ? "300406" : "500002";
      const headers = { method: "GET", headers: { authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, };
      let fetchURL;

      fetchURL = pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" ? process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${filename}&TenantID=${props.TenantInfo.TenantID}&CourseType=Module&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&Type=Course&ManagementType=CourseManagement` : process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${filename}&TenantID=${props.TenantInfo.TenantID}&ActivityType=${ActivityType}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&Type=Activity`;
      let presignedHeader = {
        method: "PUT", headers: {
          //"x-amz-acl": "public-read",
          "content-type": `image/${extension}`, defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId,
        }, body: file,
      };
      let finalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);
      if (finalStatus[0] == "Success") {
        setLogo({ Logofile: file, lblFile: "", ImgHeight: "w-44 h-20", uploadImage: file, TentImgUrl: finalStatus[1], setimg: "Image", });
        setValue("imageControl", "Image", { shouldValidate: true });
        document.getElementById("divCreateActivity")?.classList?.remove("pointer-events-none");
      } else {
        setValue("imageControl", "Error", { shouldValidate: true });
        setLogo({ Logofile: null, ImgHeight: "", lblFile: "", uploadImage: "", TentImgUrl: null, });
        document.getElementById("divCreateActivity")?.classList?.remove("pointer-events-none");
        finalResponse(finalStatus[1]);
        return;
      }
    },
    [watch, setValue, pageData?.mode, pageData?.EditData?.ActivityType, props.TenantInfo.UserGroup, props.TenantInfo.TenantID, props.TenantInfo.RootFolder, props.TenantInfo.BucketName, logo, finalResponse]
  );

  const removeImg = () => {
    setLogo({ Logofile: null, ImgHeight: "", lblFile: "", uploadImage: "", TentImgUrl: null, setimg: "removeimage", });
    setValue("imageControl", "");
  };

  const submithandler = async (data, ButtonName) => {
    document?.activeElement?.blur();
    if (ButtonName == "SaveAndContinue") {
      setValue("SavebtnLoader", true);
    } else {
      setValue("submit", true);
    }


    if (document.getElementById("divCreateActivity") != null) {
      if (!document.getElementById("divCreateActivity")?.classList?.contains("pointer-events-none")) {
        document.getElementById("divCreateActivity")?.classList?.add("pointer-events-none");
      }
    }
    let pk = "", activityId = "", sk = "";
    let DateTime = new Date();
    let activityType = document.getElementById("ddlSelectActivity").options[document.getElementById("ddlSelectActivity").selectedIndex]?.value;
    if (pageData?.mode == "Create" || pageData?.mode == "ModuleDirect" || zoomMode == "Create" || pageData.mode == "TrainingDirect") {
      pk = "TENANT#" + props.TenantInfo.TenantID
    } else {
      pk = pageData.EditData.PK
    }

    activityId = (pageData?.mode == "Create" || pageData?.mode == "ModuleDirect" || zoomMode == "Create" || (pageData.mode == "TrainingDirect" && pageData?.EditData == null)) ? Math.random().toString(25).substring(2, 12) : pageData.EditData.ActivityID;

    if (pageData?.mode == "ModuleDirect" || (props.CourseID != undefined && zoomMode == "Create")) {
      const variable = { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEID#" + props.ModuleData?.CourseID + "#MODULEID#" + props.ModuleData?.ModuleID + "#ACTIVITYTYPE#" };
      const response = await AppsyncDBconnection(listXlmsCourseModulesKeys, variable, props.user.signInUserSession.accessToken.jwtToken);
      let length = (response.res.listXlmsCourseModulesKeys?.items.length + 1).toString();
      while (length.length <= 5) {
        length = "0" + length
      }
      activityId = props.ModuleData?.ModuleID + length;
    }

    if (props.CourseID == undefined && zoomMode == "Create") {
      sk = "ACTIVITYTYPE#" + activityType + "#ZOOM#" + router.query["ZoomActivityID"] + "#" + pageData?.mode + "#ACTIVITYID#" + activityId
    } else if (pageData?.mode == "Create") {
      sk = "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId
    }
    else if (pageData?.mode == "ModuleDirect" || (props.CourseID != undefined && zoomMode == "Create")) {
      sk = "COURSEID#" + props.ModuleData?.CourseID + "#MODULEID#" + props.ModuleData?.ModuleID + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId
    } else if (pageData.mode == "TrainingDirect") {
      sk = "TRAINING#" + pageData?.TrainingId + "#ACTIVITYTYPE#" + pageData.ActivityType + "#ACTIVITYID#" + activityId
    } else {
      sk = pageData?.EditData?.SK
    }

    let query;

    if (pageData?.mode == "Edit" || (zoomMode == "Edit" && props.CourseID == undefined)) {
      query = updateXlmsActivityManagementInfo
    } else if (pageData?.mode == "Create" || (zoomMode == "Create" && props.CourseID == undefined)) {
      query = createXlmsActivityManagementInfo
    } else if (pageData?.mode == "ModuleEdit" || (zoomMode == "Edit" && props.CourseID != undefined)) {
      query = updateXlmsCourseModule
    } else if (pageData.mode == "TrainingDirect") {
      query = pageData?.EditData ? updateXlmsTrainingManagementActivityInfo : createXlmsTrainingManagementActivityInfo
    } else {
      query = createXlmsCourseModule
    }

    let finalResult, fetchURL;
    if (logo.setimg == "Image") {
      fetchURL = pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" ? process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${logo.Logofile.name}&ActivityID=${activityId}&Type=Course&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&ActivityType=${pageData?.ActivityType == undefined ? data.ddlSelectActivity : pageData?.ActivityType}&ManagementType=CourseManagement&CourseID=${props.ModuleData?.CourseID}&ModuleID=${props.ModuleData?.ModuleID}&CourseType=Module` : process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${logo.Logofile.name}&ActivityID=${activityId}&Type=Activity&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&ActivityType=${activityType}`;
      let groupMenuName = pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" ? "CourseManagement" : "ActivityManagement";
      let menuId = pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" ? "300406" : "500002";
      const headers = { method: "GET", headers: { authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, };
      finalResult = await APIGatewayGetRequest(fetchURL, headers);
    }
    let thumbnailUrl = await finalResult?.res?.text();

    let activityVariables = {
      input: {
        PK: pk,
        SK: sk,
        ActivityID: activityId,
        ActivityName: data.txtActivityName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        ActivityNameLowerCase: data?.txtActivityName?.toLowerCase()?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        ActivityDescription: getContents(message),
        ActivityType: data.ddlSelectActivity,
        Keywords: JSON.stringify(tags),
        TenantName: props.TenantDisplayName,
        TenantID: props.TenantInfo.TenantID,
        ThumbNailPath: logo?.setimg == "Image" ? thumbnailUrl : logo?.setimg == "removeimage" && pageData?.mode.toLowerCase() == "edit" ? null : pageData?.EditData?.ThumbNailPath,
        IsDeleted: false,
        IsSuspend: false,
        IsShowOnCoursePage: data.chkPageShowOnCourse,
        CreatedBy: pageData?.mode != "Edit" || zoomMode == "Create" ? props.user.username : pageData?.EditData?.CreatedBy,
        CreatedDate: pageData?.mode != "Edit" || zoomMode == "Create" ? DateTime : pageData?.EditData?.CreatedDate,
        ModifiedBy: (pageData?.mode == "Edit" || zoomMode == "Edit") ? props.user.username : pageData?.EditData?.ModifiedBy,
        ModifiedDate: DateTime,
        ZoomActivityID: router?.query["ZoomActivityID"],
        GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY",
        GsiSK: sk
      },
    };

    let moduleVariables = {
      input: {
        PK: pk,
        SK: sk,
        ActivityID: activityId,
        ActivityName: document.getElementById("txtActivityName").value?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        ActivityDescription: getContents(message),
        ActivityNameLowerCase: data?.txtActivityName?.toLowerCase()?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        ActivityType: data.ddlSelectActivity,
        Keywords: JSON.stringify(tags),
        TenantName: props.TenantDisplayName,
        TenantID: props.TenantInfo.TenantID,
        ThumbNailPath: thumbnailUrl,
        IsDeleted: false,
        IsSuspend: false,
        IsShowOnCoursePage: data.chkPageShowOnCourse,
        CreatedBy: pageData?.mode != "ModuleEdit" ? props.user.username : pageData?.EditData?.CreatedBy,
        CreatedDate: pageData?.mode != "ModuleEdit" ? DateTime : pageData?.EditData?.CreatedDate,
        ModifiedBy: pageData?.mode == "ModuleEdit" ? props.user.username : pageData?.EditData?.ModifiedBy,
        ModifiedDate: DateTime,
        ModuleID: props.ModuleData?.ModuleID,
        ModuleName: props.ModuleData?.ModuleName,
        CourseID: props.ModuleData?.CourseID,
        CourseName: props.ModuleData?.CourseName,
        Shard: pageData?.ModuleData?.Shard,
        ZoomActivityID: router?.query["ZoomActivityID"]
      },
    };

    let trainingVariables = {
      input: {
        PK: pk,
        SK: sk,
        ActivityID: activityId,
        ActivityName: document.getElementById("txtActivityName").value?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        ActivityDescription: getContents(message),
        ActivityNameLowerCase: data?.txtActivityName?.toLowerCase()?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        ActivityType: data.ddlSelectActivity,
        Keywords: JSON.stringify(tags),
        TenantID: props.TenantInfo.TenantID,
        // ThumbNailPath: thumbnailUrl,
        IsDeleted: false,
        IsSuspend: false,
        IsShowOnCoursePage: data.chkPageShowOnCourse,
        CreatedBy: (pageData?.mode == "TrainingDirect" && pageData?.EditData) ? pageData?.EditData?.CreatedBy : props.user.username,
        CreatedDate: (pageData?.mode == "TrainingDirect" && pageData?.EditData) ? pageData?.EditData?.CreatedDate : DateTime,
        LastModifiedBy: (pageData?.mode == "TrainingDirect" && pageData?.EditData) ? pageData?.EditData?.ModifiedBy : props.user.username,
        LastModifiedDate: DateTime,
        TrainingID: pageData?.TrainingId,
        TrainingName: pageData?.TrainingName,
        AssessmentType: pageData?.AssessmentType
      },
    };
    let variables = pageData?.mode == "TrainingDirect" ? trainingVariables : pageData.mode == "ModuleDirect" || pageData.mode == "ModuleEdit" || props.CourseID != undefined ? moduleVariables : pageData.mode == "Create" || pageData.mode.toLowerCase() == "edit" || pageData?.EditData?.CourseID == undefined ? activityVariables : "";
    if (pageData.mode == "ModuleEdit" || pageData.mode == "Edit" || pageData.mode == "ModuleDirect" || pageData.mode == "Create") {
      // let Shard = (props.mode == "ModuleEdit") ? (props?.ModuleActivityData?.Shard) : props?.EditData?.Shard;
      let queryBatch = (pageData.mode == "ModuleEdit" || pageData.mode == "ModuleDirect" || pageData.EditData?.CourseID != undefined) ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
        /*Batch Update*/ if (pageData?.ModuleActivityData?.Shard != undefined || pageData?.ModuleActivityData?.Shard != null || pageData?.EditData?.Shard != null || pageData?.EditData?.Shard != undefined) {

        for (let i = 1; i <= pageData?.EditData?.Shard; i++) {
          UpdateBatch({ UpdateData: pageData.EditData, inn: { ...pageData.EditData, ...variables.input }, props: props, pk: "TENANT#" + pageData?.TenantInfo?.TenantID + "#" + i, query: queryBatch, })
        }
      };
      if ((courseData?.CourseData?.Shard != null || courseData?.CourseData?.Shard != undefined)) {
        for (let i = 1; i <= courseData?.CourseData?.Shard; i++) {
          UpdateBatch({ inn: { ...variables.input }, props: props, pk: "TENANT#" + pageData?.TenantInfo?.TenantID + "#" + i, query: queryBatch, })
        }
      }
    }

    variables = pageData?.mode == "TrainingDirect" ? trainingVariables : pageData.mode == "ModuleDirect" || pageData.mode == "ModuleEdit" || props.CourseID != undefined ? moduleVariables : pageData.mode == "Create" || pageData.mode.toLowerCase() == "edit" || zoomMode == "Create" || zoomMode == "Edit" || pageData.EditData.CourseID == undefined ? activityVariables : "";
    /*Restriction Set*/
    if (pageData.mode == "ModuleDirect" && props.CourseID != undefined && (pageData.mode != "TrainingDirect")) {
      const jsonSaveData = "";
      const moduleListResponse = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + props.CourseID, SK: "COURSEMODULE#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
      const stateMachineArn = process.env.BATCH_RESTRICTION_SET;
      const restrictionUrl = process.env.BATCH_RESTRICTION_API;
      let moduleList = moduleListResponse?.res?.listXlmsCourseModule?.items;
      let moduleActivityListResponse;
      if (moduleList.length < 1) {
        moduleActivityListResponse = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEID#" + props.CourseID + "#MODULEID#" + moduleList[0].ModuleID + "#ACTIVITYTYPE#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
        if (moduleActivityListResponse?.res?.listXlmsCourseModule?.items?.length < 1) {
          jsonSaveData = '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","CourseID": "' + props?.CourseID + '","ModuleID": "' + props?.ModuleId + '","ModuleName": "' + props?.ModuleData.ModuleName + '","Mode": "Add","BatchID": [],  "ActivityData": [{"ActivityID": "' + activityId + '","ActivityName": "' + document.getElementById("txtActivityName").value?.replace(/\s{2,}(?!\s)/g, ' ').trim() + '","ActivityType": "' + props?.ActivityType + '","ZoomActivityID": "';
          if (router["ZoomActivityID"] != undefined) {
            jsonSaveData += router?.query["ZoomActivityID"] + '" }]}';
          }
          else {
            jsonSaveData += '" }]}';
          }
        }
      }
      else if (moduleList.length >= 1) {
        const listActivity = [];
        moduleList.map(async (getItem) => {
          moduleActivityListResponse = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEID#" + props.CourseID + "#MODULEID#" + getItem.ModuleID + "#ACTIVITYTYPE#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
          if (moduleActivityListResponse?.res?.listXlmsCourseModule?.items?.length < 1) {
            listActivity.push(getItem.ModuleID)
          }
        })
        if (listActivity.length == moduleList.length) {
          jsonSaveData = '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","CourseID": "' + props?.CourseID + '","ModuleID": "' + props?.ModuleId + '","ModuleName": "' + props?.ModuleData.ModuleName + '","Mode": "Add","BatchID": [],  "ActivityData": [{"ActivityID": "' + activityId + '","ActivityName": "' + document.getElementById("txtActivityName").value?.replace(/\s{2,}(?!\s)/g, ' ').trim() + '","ActivityType": "' + props?.ActivityType + '","ZoomActivityID": "';
          if (router["ZoomActivityID"] != undefined) {
            jsonSaveData += router?.query["ZoomActivityID"] + '" }]}';
          }
          else {
            jsonSaveData += '" }]}';
          }
        }
        else {
          const batchList = [];
          let moduleBatchListResponse = await AppsyncDBconnection(listXlmsCourseBatch, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + props?.CourseID, SK: "COURSEBATCH#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
          moduleBatchListResponse?.res?.listXlmsCourseBatch?.items.map((getItem) => {
            batchList.push(getItem.BatchID)
          })
          jsonSaveData = '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","CourseID": "' + props?.CourseID + '","ModuleID": "' + props?.ModuleId + '","ModuleName": "' + props?.ModuleData.ModuleName + '","Mode": "Add","BatchID": ' + JSON.stringify(batchList) + ',  "ActivityData": [{"ActivityID": "' + activityId + '","ActivityName": "' + document.getElementById("txtActivityName").value?.replace(/\s{2,}(?!\s)/g, ' ').trim() + '","ActivityType": "' + props?.ActivityType + '","ZoomActivityID": "';
          if (router["ZoomActivityID"] != undefined) {
            jsonSaveData += router?.query["ZoomActivityID"] + '" }]}';
          }
          else {
            jsonSaveData += '" }]}';
          }
        }
      }
      let headers = { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken, defaultrole: props?.TenantInfo.UserGroup, groupmenuname: "CourseManagement", menuid: "300406", statemachinearn: stateMachineArn, }, body: jsonSaveData, };
      let finalResult = await APIGatewayPostRequest(restrictionUrl, headers);
    }
    /*End of Restriction*/
    let finalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken));
    if (pageData?.mode == "ModuleDirect") {
      let activityCount = (courseData?.CourseData?.ActivityCount == undefined || courseData?.CourseData?.ActivityCount == null) ? (courseData?.ModuleActivityData?.length < 1) ? 1 : courseData?.ModuleActivityData?.length : ~~courseData?.CourseData?.ActivityCount + 1;
      let activeActivityCount = (courseData?.CourseData?.ActiveActivityCount == undefined || courseData?.CourseData?.ActiveActivityCount == null) ? (courseData?.ModuleActivityData?.length < 1) ? 1 : courseData?.ModuleActivityData?.length : ~~courseData?.CourseData?.ActiveActivityCount + 1

      const variables = {
        input: {
          PK: courseData?.CourseData?.PK,
          SK: courseData?.CourseData?.SK,
          ActivityCount: activityCount,
          ActiveActivityCount: activeActivityCount
        }
      }
      finalStatus = (await AppsyncDBconnection(updateXlmsCourseManagementInfo, variables, props?.user?.signInUserSession?.accessToken?.jwtToken));

      let activityCounts = (courseData?.ModuleActivityData?.length != 0 ? courseData?.ModuleActivityData?.length : 1)
      let activeActivityCounts = (courseData?.ModuleActivityData?.length != 0 ? courseData?.ModuleActivityData?.length : 1)

      const variable = {
        input: {
          PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + courseData?.CourseData?.CourseID,
          SK: "COURSEMODULE#" + props.ModuleData?.ModuleID,
          ActivityCount: activityCounts,
          ActiveActivityCount: activeActivityCounts
        }
      }
      finalStatus = (await AppsyncDBconnection(updateXlmsCourseModule, variable, props?.user?.signInUserSession?.accessToken?.jwtToken));
    }
    if (document.getElementById("divCreateActivity") != null) {
      if (document.getElementById("divCreateActivity")?.classList?.contains("pointer-events-none")) {
        document.getElementById("divCreateActivity")?.classList?.remove("pointer-events-none");
      }
    }
    finalResponse(finalStatus.Status, ButtonName, activityId, activityType, sk);
    setValue("SavebtnLoader", false);
    setValue("submit", false);
  };


  const clearForm = () => {
    if ((pageData?.EditData != undefined && pageData?.EditData?.ZoomActivityID != undefined) || pageData?.ZoomActivityID != undefined) {
      reset({
        txtActivityDescription: "", rcttags: "", ReactTags: "", chkPageShowOnCourse: false,
        imageControl: ""
      });
    } else {
      reset({
        txtActivityName: "", txtActivityDescription: "", rcttags: "", ReactTags: "", chkPageShowOnCourse: false,
        imageControl: ""
      });
    }

    document.getElementById("rcttags").value = ""
    if (router.query["ZoomActivityID"] != undefined) {
      setValue("chkPageShowOnCourse", false)
    } else {
      setValue("chkPageShowOnCourse", false)
      setValue("txtActivityName", "")
    }
    setTags([]);
    removeImg();
    setHTMLContents("", message);
    document.getElementById("Filerequired").style.display = "none";
    if (pageData?.mode == "Create") {
      setValue("ddlSelectActivity", "");
    }
  };

  let count = Object.keys(errors);
  let focus = false;
  if (count.length == 1 && count[0] == "ReactTags") {
    focus = true;
  }

  // Bread Crumbs
  let pageRoutes = [];
  if (pageData?.mode == "ModuleEdit" || pageData?.mode == "ModuleDirect" || props.CourseID != undefined) {
    if (props.ZoomActivityID != null || props?.ZoomActivityID != undefined) {
      pageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management", },
        { path: `/CourseManagement/ModulesList?CourseID=${props.CourseID}`, breadcrumb: "Manage Course", },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${props.ZoomActivityID}&ActivityType=Zoom&CourseID=${props.CourseID}&ModuleID=${props.ModuleId}&ModuleName=${props.EditData?.ModuleName}`, breadcrumb: "Edit Activity Zoom" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${props.ZoomActivityID}&ActivityType=Zoom&CourseID=${props.CourseID}&ModuleID=${props.ModuleId}`, breadcrumb: "Edit Settings Zoom" },
        { path: "", breadcrumb: zoomMode == "Create" ? "Create Activity" : "Edit Activity", },
      ];
    } else {
      pageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management", },
        { path: `/CourseManagement/ModulesList?CourseID=${props.CourseID}`, breadcrumb: "Manage Course", },
        { path: "", breadcrumb: pageData?.mode == "ModuleEdit" ? "Edit Activity" : "Create Activity", },
      ];
    }
  } else if (pageData?.mode == "TrainingDirect") {
    if (pageData?.Root == "TemplateList") {
      pageRoutes = [

        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management", },
        { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${pageData.TrainingId}&TrainingName=${pageData?.EditData?.TrainingName ? pageData?.EditData?.TrainingName : pageData?.TrainingName}`, breadcrumb: "Training Template List" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${pageData.TrainingId}&TrainingName=${pageData?.EditData?.TrainingName ? pageData?.EditData?.TrainingName : pageData?.TrainingName}&ActivityType=${pageData?.ActivityType}&Root=TemplateList`, breadcrumb: pageData?.EditData ? "Edit Activity" : "Create Activity" }
      ];
    } else {
      pageRoutes = [
        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management", },
        { path: "", breadcrumb: pageData?.EditData ? "Edit Activity" : "Create Activity" }
      ];
    }

  } else {
    if (router.query["ZoomActivityID"] != undefined && !router.query["NavigationMode"]) {
      pageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
        { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Activity Zoom" },
        { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Settings Zoom" },
        { path: "", breadcrumb: zoomMode == "Edit" ? "Edit Activity" : "Create Activity", },
      ];
    } else if (router.query["ZoomActivityID"] != undefined && router.query["NavigationMode"] != undefined) {
      pageRoutes = [
        { path: `/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`, breadcrumb: "Activity Management" },
        { path: "", breadcrumb: pageData?.mode == "Edit" ? "Edit Activity" : "Create Activity", },
      ];
    } else {
      pageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
        { path: "", breadcrumb: pageData?.mode == "Edit" ? "Edit Activity" : "Create Activity", },
      ];
    }
  }
  return (
    <>
      <Container PageRoutes={pageRoutes} loader={pageData?.TenantID == undefined} title="ActivityInfo">
      <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form id="activityForm">
          <div className="nvl-FormContent" id="divCreateActivity">
            <NVLSelectField labelText="Select Activity" labelClassName="nvl-Def-Label" required id="ddlSelectActivity" disabled={watch("imageControl") == "Image" || watch("imageControl") == "Upload" ? true : false} options={activityList} className={`${pageData?.mode == "Create" ? "nvl-mandatory nvl-Def-Input " : "nvl-Def-Input Disabled"}`} errors={errors} register={register} />
            <div className="hidden">
              <NVLlabel id="lblActivityID" text="Activity ID :" className="nvl-Def-Label" />
            </div>
            <NVLTextbox labelText="Activity Name" labelClassName="nvl-Def-Label" id="txtActivityName" title="Activity Name"
              className={` ${(pageData?.EditData != undefined && pageData?.EditData?.ZoomActivityID != undefined) || pageData?.ZoomActivityID != undefined || pageData?.mode == "TrainingDirect" ? "Disabled" : ""}
            nvl-mandatory nvl-Def-Input ${(router.query["ZoomActivityID"] != undefined) ? (router.query["ZoomActivityID"] != undefined && ((watch("txtActivityName")?.includes("PreAssessment") && watch("txtActivityName") != "PreAssessment") || (watch("txtActivityName")?.includes("PostAssessment") && watch("txtActivityName") != "PostAssessment") || (watch("txtActivityName")?.includes("Feedback") && watch("txtActivityName") != "Feedback"))) && "Disabled" : ""}
            `} maxLength={"50"} errors={errors} register={register}

              disabled={(router.query["ZoomActivityID"] != undefined) ? (zoomMode != undefined || (router.query["ZoomActivityID"] != undefined ||
                ((watch("txtActivityName")?.includes("PreAssessment") && watch("txtActivityName") != "PreAssessment") ||
                  (watch("txtActivityName")?.includes("PostAssessment") && watch("txtActivityName") != "PostAssessment") ||
                  (watch("txtActivityName")?.includes("Feedback") && watch("txtActivityName") != "Feedback"))
              )) && true : false} />
            <div className="flex pb-1">
              <NVLlabel text="Activity Description" className="nvl-Def-Label" />
            </div>
            <NVLRichTextBox id="RichTextBox" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} />
            <div className="{invalid-feedback} text-red-500 text-sm pt-2">
              {errors?.RichTextBox?.message}
            </div>
            {/* <div className={`${router.query["CourseID"] != undefined ? "hidden" : "flex"}`}>
              <div>
                <NVLCheckbox id="chkPageShowOnCourse" errors={errors} register={register} />
              </div>
              <div>
                <NVLlabel text="Show on course page " className="nvl-Def-Label" />
              </div>
            </div> */}
            <div className="flex pb-1">
              <NVLlabel text="Keywords" className="nvl-Def-Label" />
            </div>
            <ReactTags className="nvl-Def-Input" id="rcttags" autofocus={focus} inline allowUnique tags={tags} placeholder="Type and Press Enter to add new keywords" delimiters={delimiters} handleDelete={handleDelete} handleAddition={handleAddition} handleDrag={handleDrag} inputFieldPosition="top" />
            <div className="{invalid-feedback} text-red-500 text-xs pt-2">
              {errors?.ReactTags?.message}
            </div>
            {pageData?.mode != "TrainingDirect" && <div className={`${props.CourseID != undefined || props.mode == "ModuleDirect" || props.mode == "ModuleEdit" ? "hidden" : ""}`}>
              <div className="flex pb-1">
                <NVLlabel text="Upload ThumbNail" className="nvl-Def-Label" />
                <NVLlabel className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: jpg, png, jpeg.<br>File size should not exceed more than 50KB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
              </div>
              <NVLImageUpload watch={watch} control={"imageControl"} accept={`${"Acceptable file format: jpg, png, jpeg.<br>File size should not exceed more than 50KB"}`} Logofile={logo.Logofile} text={"Upload Thumbnail"} uploadImage={logo.uploadImage} ImgHeight={logo.ImgHeight} mode={props.mode} UploadLogo={uploadThumbnail} removeImg={removeImg} />
            </div>}
            <div id="Filerequired" className="{invalid-feedback} text-red-500 text-xs pt-2" />
            <div className="grid  grid-flow-col gap-1 nvl-Def-Input mt-2">
              <NVLButton id="btnSave" text={!watch("submit") ? "Save" : ""} type="button" disabled={watch("imageControl") == "Upload" || watch("submit") ? true : false} onClick={handleSubmit((data) => submithandler(data, "Save"))} className={` nvl-button bg-primary text-white ${pageData?.mode == "ModuleDirect" || pageData?.mode == "ModuleEdit" || props.CourseID != undefined ? "hidden" : ""}`}>
                {watch("submit") && (
                  <i className="fa fa-circle-notch fa-spin mr-2"></i>
                )}
              </NVLButton>
              <NVLButton id="btnSaveandContinue" disabled={watch("imageControl") == "Upload" || watch("SavebtnLoader") ? true : false} text={!watch("SavebtnLoader") ? "Save and Continue" : ""} onClick={handleSubmit((data) => submithandler(data, "SaveAndContinue"))} className={"nvl-button bg-primary text-white "}>
                {watch("SavebtnLoader") && (
                  <i className="fa fa-circle-notch fa-spin mr-2"></i>
                )}
              </NVLButton>
              <NVLButton id="btnCancel" disabled={watch("imageControl") == "Upload" || watch("submit") == "Submit" ? true : false}
                text={pageData?.mode == "Create" || pageData?.mode == "ModuleDirect" || zoomMode == "Create" ? "Clear" : "Cancel"} type="button" className="nvl-button"
                onClick={() => {
                  if (pageData?.mode == "Create" || pageData?.mode == "ModuleDirect" || zoomMode == "Create") {
                    clearForm()
                  } else if (pageData?.mode == "TrainingDirect") {
                    return router.push(`/TrainingManagement/TrainingManagementList`);
                  } else if (props.mode == "ModuleEdit") {
                    return router.push(`/CourseManagement/ModulesList?CourseID=${props.CourseID}`)
                  } else if (zoomMode == "Edit" && props.CourseID != undefined) {
                    return router.push(`/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${props.CourseID}&ModuleID=${props.ModuleId}`)
                  }
                  else if (zoomMode == "Edit") {
                    return router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`)
                  } else {
                    if (!router.query["NavigationMode"]) {
                      return router.push("/ActivityManagement/ActivityList")
                    } else {
                      return router.push(`/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`)
                    }
                  }
                }} >
              </NVLButton>
            </div>
          </div >
        </form >
      </Container >
    </>
  );
}

export default ActivityInfo;