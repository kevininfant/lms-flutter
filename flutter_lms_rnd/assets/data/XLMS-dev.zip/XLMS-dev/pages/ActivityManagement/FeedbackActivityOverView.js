import FeedBackQuestion from "@Pages/ActivityManagement/CommonActivitySettings/FeedBackQuestion";
import FeedBackResponse from "@Pages/ActivityManagement/CommonActivitySettings/FeedBackResponse";
import FeedBackTemplate from "@Pages/ActivityManagement/CommonActivitySettings/FeedBackTemplate";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLHeader from "@components/Controls/NVLHeader";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsCourseFeedbackTemplate, createXlmsFeedbackTemplate, deleteXlmsCourseFeedbackTemplate, deleteXlmsFeedbackTemplate, updateXlmsActivityManagementInfo, updateXlmsCourseModule, updateXlmsTrainingManagementActivityInfo } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseFeedbackTemplate, getXlmsCourseModule, getXlmsFeedbackTemplate, getXlmsTrainingManagement, getXlmsTrainingManagementActivityInfo, listXlmsActivityEnrollUser, listXlmsCourseBatch, listXlmsCourseBatchWiseDismissUserList, listXlmsCourseFeedbackTemplate, listXlmsCourseFeedbackTemplateNameExists, listXlmsFeedbackTemplate, listXlmsFeedbackTemplateNameExists, listXlmsLanguages, listXlmsTrainingTemplateInfos } from "src/graphql/queries";
import * as Yup from "yup";
import FeedBackAnalysis from "./CommonActivitySettings/FeedBackAnalysis";

function FeedbackActivityOverview(props) {
  const router = useRouter()
  const [pageData, setPageData] = useState({});
  const Question = useRef();
  const UpdateQuestion = useCallback((temp) => { Question.current = temp; }, [])
  const zoomActivityId = useMemo(() => { return decodeURIComponent(String(router.query["ZoomActivityID"])) }, [router.query])
  const zoomActivityMode = useMemo(() => { return decodeURIComponent(String(router.query["ZoomMode"])) }, [router.query])

  useEffect(() => {
    async function fetchData() {
      let tenantId = props.user.attributes["custom:tenantid"];
      let courseActivityId = decodeURIComponent(String(router.query["CourseID"]));
      let currentMode = decodeURIComponent(String(router.query["Mode"]));
      let moduleId = decodeURIComponent(String(router.query["ModuleID"]));
      let activityId = decodeURIComponent(String(router.query["ActivityID"]));
      let activityType = decodeURIComponent(String(router.query["ActivityType"]));
      let TrainingID = decodeURIComponent(String(router.query["TrainingID"]));
      let root = decodeURIComponent(String(router.query["Root"]));
      let isUpdateData, trainingData;
      if (currentMode == "TrainingEdit") {
        isUpdateData = await AppsyncDBconnection(getXlmsTrainingManagementActivityInfo, {
          PK: "TENANT#" + tenantId,
          SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId,
        }, props?.user.signInUserSession.accessToken.jwtToken);
        trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, { PK: "TENANT#" + tenantId, SK: "TRAININGINFO#" + TrainingID }, props?.user.signInUserSession.accessToken.jwtToken)
      } else {
        isUpdateData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + tenantId, SK: "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId, }, props?.user.signInUserSession.accessToken.jwtToken);

      }
      let zoomActData;
      if (currentMode != "ModuleEdit" && router.query["ZoomActivityID"] != undefined) {
        zoomActData = await AppsyncDBconnection(
          getXlmsActivityManagementInfo,
          {
            PK: "TENANT#" + tenantId,
            SK: "ACTIVITYTYPE#" + activityType + "#ZOOM#" + router.query["ZoomActivityID"] + "#" + router.query["ZoomMode"] + "#ACTIVITYID#" + activityId,
          }, props?.user.signInUserSession.accessToken.jwtToken
        );
      }
      let activityData = (currentMode != "ModuleEdit" && router.query["ZoomActivityID"] != undefined) ?
        zoomActData.res?.getXlmsActivityManagementInfo :
        currentMode != "TrainingEdit" ? isUpdateData.res?.getXlmsActivityManagementInfo : isUpdateData.res?.getXlmsTrainingManagementActivityInfo
      let moduleData;
      if (currentMode == "ModuleEdit") {
        moduleData = await AppsyncDBconnection(getXlmsCourseModule, { PK: "TENANT#" + tenantId, SK: "COURSEID#" + courseActivityId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId }, props?.user.signInUserSession.accessToken.jwtToken);
        moduleData = moduleData.res?.getXlmsCourseModule;
      }
      let query = (courseActivityId == "undefined") ? listXlmsFeedbackTemplate : listXlmsCourseFeedbackTemplate;
      let mode = activityData != null ? "Edit" : "Create";
      let templateSk = currentMode == "ModuleEdit" ? "COURSEQUESTIONNAIRETEMPLATE#" : "QUESTIONNAIRETEMPLATE#";
      let templateData = await AppsyncDBconnection(query, { PK: "TENANT#" + tenantId, SK: templateSk, }, props?.user.signInUserSession.accessToken.jwtToken);

      if (currentMode == "TrainingEdit") {
        let trainingTemp = await AppsyncDBconnection(listXlmsTrainingTemplateInfos, { PK: "TENANT#" + tenantId, SK: "TRAININGQUESTIONNAIRETEMPLATE#", IsDeleted: false, TemplateType: activityType }, props?.user.signInUserSession.accessToken.jwtToken);
        let TrainingTempBinding = [];
        trainingTemp.res?.listXlmsTrainingTemplateInfos?.items.map((item) => {
          TrainingTempBinding.push({
            ActivityType: item?.TemplateType,
            IsPublic: item?.IsPublic,
            PK: item?.PK,
            SK: item?.SK,
            Status: item?.IsPublic,
            TemplateName: item?.TemplateType == "Feedback" ? item?.TrainingFeedbackTemplateName : item?.TrainingSurveyTemplateName,
            TemplateNameLowerCase: item?.TemplateNameLowerCase,
            TemplateOption: item?.TemplateOption,
            TenantID: item?.TenantID,
          })
        })
        if (activityType == "Survey")
          templateData = TrainingTempBinding;
        else
        templateData = TrainingTempBinding;
      }
      let RecordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME", }, props?.user.signInUserSession.accessToken.jwtToken);
      let responseQuery = currentMode == "ModuleEdit" ? listXlmsCourseBatchWiseDismissUserList : listXlmsActivityEnrollUser;
      let responseVariable = currentMode == "ModuleEdit" ? { GsiPK: "TENANT#" + tenantId + "#COURSEID#" + courseActivityId, GsiSK: "BATCH#" } : { GsiPK: "ACTIVITYID#" + activityId, GsiSK: "TENANT#" + tenantId + "#ACTIVITY#ENROLLUSER#" };

      const courseUserCount = await AppsyncDBconnection(responseQuery, responseVariable, props?.user.signInUserSession.accessToken.jwtToken);
      let userResponse = currentMode == "ModuleEdit" ? courseUserCount.res?.listXlmsCourseBatchWiseDismissUserList?.items : courseUserCount.res?.listXlmsActivityEnrollUser?.items;
      let batchData;

      if (currentMode == "ModuleEdit") {
        batchData = await AppsyncDBconnection(
          listXlmsCourseBatch,
          {
            PK: "TENANT#" + tenantId + "#COURSEINFO#" + courseActivityId,
            SK: "COURSEBATCH#",
          },
          props?.user.signInUserSession.accessToken.jwtToken
        );
      }
      const temp = {
        Root: root,
        TrainingData: trainingData?.res?.getXlmsTrainingManagement,
        CourseActivityID: courseActivityId,
        ModuleId: moduleId != undefined && moduleId,
        CM_Mode: currentMode,
        ActivityID: activityId,
        ActivityType: activityType,
        mode: currentMode != undefined && currentMode,
        TrainingID: TrainingID,
        ModuleData: moduleData != undefined && moduleData,
        Editdata: currentMode == "ModuleEdit" ? moduleData : activityData,
        TemplateData: currentMode == "TrainingEdit" ? templateData : currentMode == "ModuleEdit" ? templateData.res?.listXlmsCourseFeedbackTemplate?.items : templateData.res?.listXlmsFeedbackTemplate?.items,
        LanguageName: RecordContentDataLanguage?.res?.listXlmsLanguages,
        EnrolledUserResponses: userResponse != undefined ? userResponse : [],
        BatchData: currentMode == "ModuleEdit" && batchData.res?.listXlmsCourseBatch?.items
      }
      let actQues = (activityData?.QuestionandOptions != undefined && currentMode != "ModuleEdit") ? JSON.parse(activityData?.QuestionandOptions) : (moduleData?.QuestionandOptions != undefined ? JSON.parse(moduleData?.QuestionandOptions) : []);

      Question.current = actQues;

      setPageData(temp);
    }
    fetchData();
    return (() => {
      setPageData({})
    })
  }, [zoomActivityId, zoomActivityMode, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query]);


  const [active, setActive] = useState(router.query["ActivityType"]=="Survey" ? "divEdit" : "divAnalysis");


  const [modalValues, setModalValues] = useState({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully.", });

  const tabItems = useMemo(() => {

    let surveyTabs = [
      { id: "1", TabName: "Edit Question", Tabid: "divEdit" },
      { id: "2", TabName: "Template", Tabid: "divTemplate" },
    ]
    let tabItems = [

      { id: "1", TabName: "Analysis", Tabid: "divAnalysis" },
      { id: "2", TabName: "Edit Question", Tabid: "divEdit" },
      { id: "3", TabName: "Template", Tabid: "divTemplate" },
      { id: "4", TabName: "Responses", Tabid: "divResponses" },
    ]

    return router.query["ActivityType"]=="Survey" ? surveyTabs : tabItems

  }, [router.query])

  const query = useMemo(() => {
    let currentquery = [];
    if (pageData.Editdata?.CourseID != null || pageData.Editdata?.CourseID != undefined) {
      currentquery = [createXlmsCourseFeedbackTemplate, getXlmsCourseFeedbackTemplate, listXlmsCourseFeedbackTemplate, deleteXlmsCourseFeedbackTemplate, listXlmsCourseFeedbackTemplateNameExists];
    }
    else {
      currentquery = [createXlmsFeedbackTemplate, getXlmsFeedbackTemplate, listXlmsFeedbackTemplate, deleteXlmsFeedbackTemplate, listXlmsFeedbackTemplateNameExists]
    }
    return currentquery;

  }, [pageData.Editdata])
  const queryName = useMemo(() => {
    let currentquery = [];
    if (pageData.Editdata?.CourseID != null || pageData.Editdata?.CourseID != undefined) {
      currentquery = ["createXlmsCourseFeedbackTemplate", "getXlmsCourseFeedbackTemplate", "listXlmsCourseFeedbackTemplate", "deleteXlmsCourseFeedbackTemplate", "listXlmsCourseFeedbackTemplateNameExists"];
    }
    else {
      currentquery = ["createXlmsFeedbackTemplate", "getXlmsFeedbackTemplate", "listXlmsFeedbackTemplate", "deleteXlmsFeedbackTemplate", "listXlmsFeedbackTemplateNameExists"]
    }
    return currentquery;
  }, [pageData.Editdata?.CourseID])

  const languageType = useMemo(() => {
    let LanguageType = [];
    if (pageData.LanguageName != undefined) {
      if (Object.keys(JSON.parse(pageData?.LanguageName?.items[0].LanguageName)) != undefined) {
        Object.entries(JSON.parse(pageData?.LanguageName?.items[0].LanguageName)).forEach(([key, value]) => {
          LanguageType = [...LanguageType, { value: value, text: key }];
        });
      }
    }
    return LanguageType;
  }, [pageData]);

  const validationSchema = Yup.object().shape({
    ddlTemplate: Yup.string(),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true, };
  const { register, handleSubmit, setValue, watch, reset, formState, setFocus } = useForm(formOptions);
  const { errors } = formState;

  const menuTab = useCallback((menuName) => {
    setActive(menuName);
    reset();
  }, [reset]);


  const finalResponse = (FinalStatus, IsState) => {
    if (FinalStatus != "Success") {
      setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: FinalStatus, });
      ModalOpen();
      return;
    } else {
      if (IsState) {
        setModalValues({
          ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully.",
          ModalOnClickEvent: () => {
            if (pageData?.mode == "TrainingEdit") {
              router.push("/TrainingManagement/TrainingManagementList");
            }
          },
        });
      } else {
        setModalValues({
          ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully.",
        });

      }
      ModalOpen();
    }
  };

  //const handle drag sorting
  const handleSort = useCallback(async (QuesAns, setQuestions, dragItem, dragOverItem) => {
    let mode = pageData.CM_Mode;
    let courseId = pageData.CourseActivityID;
    let moduleId = pageData.ModuleId;
    if (QuesAns != null && Object.keys(QuesAns).length != 0) {
      let draggedElement = Object.values(QuesAns);
      const draggedItemContent = draggedElement.splice(dragItem.current, 1)[0];
      draggedElement.splice(dragOverItem.current, 0, draggedItemContent);
      dragItem.current = null;
      dragOverItem.current = null;
      let swappedElement = {};
      for (var i = 0; i < draggedElement.length; i++) {
        swappedElement = {
          ...swappedElement,
          [draggedElement[i]?.Question]: { ...draggedElement[i], Position: i, },
        };
      }
      setQuestions(swappedElement);
      let sk;
      if (mode == "ModuleEdit") {
        sk = "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + pageData.ActivityType + "#ACTIVITYID#" + pageData.ActivityID
      } else if (mode == "Edit" && (router.query["ZoomActivityID"] != undefined)) {
        sk = "ACTIVITYTYPE#" + pageData.ActivityType + "#ZOOM#" + router.query["ZoomActivityID"] + "#" + router.query["ZoomMode"] + "#ACTIVITYID#" + pageData.ActivityID
      } else if (pageData?.mode == "TrainingEdit") {
        sk = "TRAINING#" + pageData.TrainingID + "#ACTIVITYTYPE#" + pageData.ActivityType + "#ACTIVITYID#" + pageData.ActivityID;
      } else {
        sk = "ACTIVITYTYPE#" + pageData.ActivityType + "#ACTIVITYID#" + pageData.ActivityID;
      }

      let questionVariables = {
        input: {
          PK: "TENANT#" + props.TenantInfo.TenantID,
          SK: sk,
          QuestionandOptions: JSON.stringify(swappedElement),
        },
      };
      let query = pageData?.mode == "TrainingEdit" ? updateXlmsTrainingManagementActivityInfo : mode == "ModuleEdit" ? updateXlmsCourseModule : updateXlmsActivityManagementInfo;
      await AppsyncDBconnection(query, questionVariables, props?.user.signInUserSession.accessToken.jwtToken).Status;
    } else {
      setQuestions({});
    }
  }, [pageData.CM_Mode, pageData.CourseActivityID, pageData.ModuleId, pageData?.mode, pageData.ActivityType, pageData.ActivityID, pageData.TrainingID, router.query, props.TenantInfo.TenantID, props?.user.signInUserSession.accessToken.jwtToken]);

  const sortusingpostion = useCallback((QuesAns) => {
    if (QuesAns && Object.values(QuesAns).length > 0) {
      var sorted = Object.values(QuesAns).sort(function (a, b) {
        return a.Position - b.Position;
      });
      return sorted;
    }
    return [];
  }, []);

  let PageRoutes = [];
  if (pageData?.CM_Mode == "ModuleEdit" || pageData?.CM_Mode == "ModuleDirect") {
    if (router.query["ZoomActivityID"] != undefined) {
      PageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${pageData.CourseActivityID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${pageData.CourseActivityID}&ModuleID=${pageData.ModuleId}&ModuleName=${pageData?.ModuleData?.ModuleName}`, breadcrumb: "Edit Activity Zoom" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${pageData.CourseActivityID}&ModuleID=${pageData.ModuleId}`, breadcrumb: "Edit Settings Zoom" },
        { path: `/CourseManagement/ModuleInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${pageData.ActivityType}&CourseID=${pageData.CourseActivityID}&ModuleID=${pageData.ModuleId}&ModuleName=${pageData?.ModuleData?.ModuleName}&ZoomActivityName=${router.query["ZoomactivityName"]}`, breadcrumb: "Edit Activity" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}&CourseID=${pageData.CourseActivityID}&ModuleID=${pageData.ModuleId}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
        { path: "", breadcrumb: "Feedback" }
      ];
    } else {
      PageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${pageData.CourseActivityID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}&CourseID=${pageData.CourseActivityID}&ModuleID=${pageData.ModuleId}&ModuleName=${pageData?.ModuleData?.ModuleName}`, breadcrumb: "Edit Activity" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}&CourseID=${pageData.CourseActivityID}&ModuleID=${pageData.ModuleId}`, breadcrumb: "Edit Settings" },
        { path: "", breadcrumb: "Feedback" }
      ];
    }
  } else if (pageData?.mode == "TrainingEdit") {
    if (pageData?.Root == "TemplateList") {
      PageRoutes = [
        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management" },
        { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${router.query["TrainingID"]}&TrainingName=${pageData.TrainingData?.TrainingName}`, breadcrumb: "Training Template List", },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${pageData?.TrainingID}&TrainingName=${pageData.TrainingData?.TrainingName}&ActivityType=${pageData.ActivityType}&Root=TemplateList`, breadcrumb: "Edit Activity" },
        { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${pageData?.ActivityID}&ActivityType=${pageData.ActivityType}&TrainingID=${pageData?.TrainingID}&Root=TemplateList`, breadcrumb: "Edit Settings" },
        { path: ``, breadcrumb: pageData.ActivityType }
      ];
    } else {
      PageRoutes = [
        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${pageData?.TrainingID}&TrainingName=${pageData.TrainingData?.TrainingName}&ActivityType=${pageData.ActivityType}`, breadcrumb: "Edit Activity" },
        { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${pageData?.ActivityID}&ActivityType=${pageData.ActivityType}&TrainingID=${pageData?.TrainingID}`, breadcrumb: "Edit Settings" },
        { path: ``, breadcrumb: pageData.ActivityType }
      ];
    }


  } else {
    if (router.query["ZoomActivityID"] != undefined) {
      PageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
        { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Settings Zoom" },
        { path: `/ActivityManagement/ActivityInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${pageData.ActivityType}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
        { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
        { path: "", breadcrumb: "Feedback" }
      ];
    } else {
      PageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
        { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}`, breadcrumb: "Edit Activity" },
        { path: `${`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}`}`, breadcrumb: "Edit Settings" },
        { path: "", breadcrumb: "Feedback" }
      ];
    }
  }
  const FeedBackOverview = useCallback((props) => {
    if (props.active == "divAnalysis" && props.user != undefined && (props.pageData?.mode != "TrainingEdit" || props.pageData?.ActivityType == "Feedback")) {
      return (
        <>
          <FeedBackAnalysis sortusingpostion={props.sortusingpostion} pageData={props.pageData} Question={props.Question.current} UpdateQuestion={props.UpdateQuestion} user={props.user} languageType={props.languageType}></FeedBackAnalysis>
        </>
      );
    }
    else if (props.active == "divEdit" && props.user != undefined) {
      return (
        <>
          <FeedBackQuestion active={props.active} Question={props.Question.current} UpdateQuestion={props.UpdateQuestion} finalResponse={props.finalResponse} router={props.router} sortusingpostion={props.sortusingpostion} handleSubmit={props.handleSubmit} handleSort={props.handleSort} message={props.message} setMessage={props.setMessage} watch={props.watch} languageType={props.languageType} reset={props.reset} errors={props.errors} TenantInfo={props.TenantInfo} user={props.user} pageData={props.pageData} />
        </>
      );
    }
    else if (props.active == "divTemplate" && props.user != undefined) {
      return (
        <>
          <FeedBackTemplate setPageData={setPageData} active={props.active} Question={props.Question.current} sortusingpostion={props.sortusingpostion} UpdateQuestion={props.UpdateQuestion} finalResponse={props.finalResponse} handleSubmit={props.handleSubmit} handleSort={props.handleSort} message={props.message} setMessage={props.setMessage} watch={props.watch} languageType={props.languageType} reset={props.reset} TenantInfo={props.TenantInfo} pageData={props.pageData} user={props.user} query={props.query} queryName={props.queryName} router={props.router} menuTab={props.menuTab} />
        </>
      )
    }
    else if (props.active == "divResponses" && props.user != undefined && (props.pageData?.mode != "TrainingEdit" || props.pageData?.ActivityType == "Feedback")) {
      return (
        <>
          <FeedBackResponse questions={props.Question.current} active={props.active} user={props.user} pageData={props.pageData} watch={props.watch} register={props.register} errors={props.errors} mode={props.pageData.mode} TenantInfo={props.TenantInfo} ActivityID={props.pageData?.ActivityID} setValue={props.setValue} CourseActivityID={props.pageData?.CourseActivityID} BatchData={props.pageData?.BatchData} />
        </>
      );
    }
    else {
      return (<></>);
    }
  }, [])

  return (
    <>
      <Container PageRoutes={PageRoutes} loader={Object.keys(pageData) == 0}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <NVLHeader RedirectHome={pageData.CM_Mode != "ModuleEdit" ? `${`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}`}` : `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${pageData.ActivityID}&ActivityType=${pageData.ActivityType}&CourseID=${pageData.CourseActivityID}&ModuleID=${pageData.ModuleId}`}></NVLHeader>
        <div className="w-full sm:w-1/2 md:w-1/2 lg:w-full xl:w-full p-1">
          <div className="mb-4 border-b border-gray-200 dark:border-gray-700">
            <ul className="flex flex-wrap w-full" id="myTab" data-tabs-toggle="#myTabContent" role="tablist">
              {tabItems &&
                tabItems.map((getItem, index) => {
                  return (
                    <li className="mr-2" role="presentation" key={index}>
                      <button onClick={() => { if (active != getItem.Tabid) { menuTab(getItem.Tabid) } }} className={`inline-flex py-4 px-4 text-sm font-medium text-center text-gray-500 rounded-t-lg border-b-2 border-transparent hover:text-gray-600 hover:border-gray-300 dark:text-gray-400 dark:hover:text-gray-300 ${active == getItem.Tabid ? "!border-blue-500 !text-blue-500" : ""}`} 
                      id={`${getItem.Tabid}`} data-tabs-target="#Mycourse" type="button" role="tab" aria-controls="Mycourse" aria-selected="false">
                        {getItem.TabName}
                      </button>
                    </li>
                  );
                })}
            </ul>
          </div>
        </div>
        <FeedBackOverview Question={Question} active={active} UpdateQuestion={UpdateQuestion} finalResponse={finalResponse} router={router} sortusingpostion={sortusingpostion} handleSort={handleSort} languageType={languageType} TenantInfo={props.TenantInfo} user={props.user} pageData={pageData} query={query} menuTab={menuTab} queryName={queryName} />
      </Container>
    </>
  );
}

export default FeedbackActivityOverview;