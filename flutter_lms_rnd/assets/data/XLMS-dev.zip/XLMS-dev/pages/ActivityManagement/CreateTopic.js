import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { WithContext as ReactTags } from "react-tag-input";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseDiscussionChat, createXlmsDiscussionChat, updateXlmsCourseDiscussionChat, updateXlmsDiscussionChat } from "src/graphql/mutations";
import { getXlmsCourseDiscussionChatInfo, getXlmsDiscussionChatInfo, getXlmsEnrollUser, listXlmsCourseDiscussionChat, listXlmsCourseDiscussionChatNameExits, listXlmsCourseModule, listXlmsDiscussionChat, listXlmsDiscussionChatNameExits } from "src/graphql/queries";
import * as Yup from "yup";


function CreateTopic(props) {
  const router = useRouter();
  let initialModalState = {};
  const [csrFetchedData, setCsrFetchedData] = useState([]);
  const previousState = useRef({ txtTopicName: {} });
  useEffect(() => {
    const dataSource = async (i) => {
      let tenantId = props.user.attributes["custom:tenantid"];
      let userSub = props.user.attributes["sub"];
      let activityId = decodeURIComponent(String(router.query["ActivityID"]));
      let topicSub = decodeURIComponent(String(router.query["TopicSub"]));
      let courseId = decodeURIComponent(String(router.query["CourseID"]));
      let moduleId = decodeURIComponent(String(router.query["ModuleID"]));
      let courseName = decodeURIComponent(String(router.query["CourseName"]));


      let Query = (courseId != "undefined") ? getXlmsCourseDiscussionChatInfo : getXlmsDiscussionChatInfo;
      let queryName = (courseId != "undefined") ? "getXlmsCourseDiscussionChatInfo" : "getXlmsDiscussionChatInfo";
      let listQuery = (courseId != "undefined") ? listXlmsCourseDiscussionChat : listXlmsDiscussionChat;
      let getDiscussionSortKey = (courseId != "undefined") ? "COURSEID#" + courseId + "#MODULE#" + moduleId + "#ACTIVITY#" + activityId + "#TOPIC#" + topicSub : "ACTIVITY#" + activityId + "#TOPIC#" + topicSub;
      let listDiscussionSortKey = (courseId == "undefined") ? "ACTIVITY#" + activityId + "#TOPIC#" : "COURSEID" + courseId + "MODULE#" + moduleId + "ACTIVITY#" + activityId + "#TOPIC#";
      const editTopicData = await AppsyncDBconnection(Query, { PK: "TENANT#" + tenantId, SK: getDiscussionSortKey, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let mode = editTopicData.res?.[queryName] != null ? "Edit" : "Create";
      let discussionData = await AppsyncDBconnection(listQuery, { PK: "TENANT#" + tenantId, SK: listDiscussionSortKey, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const activityEnrollData = await AppsyncDBconnection(getXlmsEnrollUser, { PK: "TENANT#" + tenantId + "#ACTIVITY#ENROLLUSER#" + userSub, SK: "ACTIVITYID#" + activityId, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let actData = [];
      if (courseId != "undefined") {
        const activityVariable = { PK: "TENANT#" + tenantId, SK: "COURSEID#" + courseId, IsDeleted: false }
        let actList = (await AppsyncDBconnection(listXlmsCourseModule, activityVariable, props?.user?.signInUserSession?.accessToken?.jwtToken));
        actData = actList?.res?.listXlmsCourseModule?.items.filter((item) => item.ActivityID === activityId)[0];
      }
      if (actData == undefined) { actData = []; }

      setCsrFetchedData({
        TenantID: tenantId,
        ActivityID: activityId,
        TopicSub: topicSub,
        DiscussionData: discussionData.res?.ListQuery?.items != undefined ? discussionData.res?.ListQuery?.items : [],
        mode: mode,
        CourseID: courseId,
        ModuleID: moduleId,
        EditTopicData: editTopicData.res?.[queryName] == undefined ? {} : editTopicData.res?.[queryName],
        ActivityEnrollData: activityEnrollData.res?.getXlmsEnrollUser,
        ActivityData: courseId != "undefined" && actData,
        CourseName: courseName,
      })
    }
    let initialModalState = {
      ModalInfo: "Success",
      ModalTopMessage: "Success",
      ModalBottomMessage: "Discussion started successfully.",
      ModalOnClickEvent: () => {
        if (CourseID != "undefined")
          router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityID=${ActivityID}&CourseID=${CourseID}&ModuleID=${ModuleID}&CourseName=${CourseName}&ActivityName=Discussion`);
        else
          router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityName=Discussion&ActivityID=${ActivityID}`);
      },
    };

    dataSource();
    return (() => {
      setCsrFetchedData((temp) => { return { ...temp } });

    })

  }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router, router.query])
  const [tags, setTags] = useState(csrFetchedData?.EditTopicData?.Keywords != undefined ? JSON?.parse(csrFetchedData?.EditTopicData?.Keywords) : []);


  const query = useMemo(() => {
    let currentquery = [];
    (csrFetchedData.CourseID == "undefined") ?
      currentquery = [createXlmsDiscussionChat, getXlmsDiscussionChatInfo, updateXlmsDiscussionChat, listXlmsDiscussionChat, listXlmsDiscussionChatNameExits]
      : currentquery = [createXlmsCourseDiscussionChat, getXlmsCourseDiscussionChatInfo, updateXlmsCourseDiscussionChat, listXlmsCourseDiscussionChat, listXlmsCourseDiscussionChatNameExits];
    return currentquery;
  }, [csrFetchedData.CourseID]);
  const queryName = useMemo(() => {
    let currentquery = [];
    (csrFetchedData.CourseID == "undefined") ?
      currentquery = ["createXlmsDiscussionChat", "getXlmsDiscussionChatInfo", "updateXlmsDiscussionChat", "listXlmsDiscussionChat", "listXlmsDiscussionChatNameExits"]
      : currentquery = ["createXlmsCourseDiscussionChat", "getXlmsCourseDiscussionChatInfo", "updateXlmsCourseDiscussionChat", "listXlmsCourseDiscussionChat", "listXlmsCourseDiscussionChatNameExits"];
    return currentquery;
  }, [csrFetchedData.CourseID]);


  const [modalValues, setModalValues] = useState(initialModalState);
  const validationSchema = Yup.object().shape({
    txtTopicName: Yup.string().required("Topic name is required").matches(Regex("AlphaNumForTopicName"), "Invalid Topic Name").min(3, "Topic Name should me minimum of 3 characters").max(250, ("Maximum 250 characters Reached"))
      .test("name", ("Topic Name Already Exists"), async (e) => {
        if (csrFetchedData.mode.toLowerCase() == "edit" && e?.toLowerCase() == csrFetchedData?.EditTopicData?.TopicName?.toLowerCase()) {
          return true;
        }
        if (e == "" || !Regex("AlphaNumForTopicName").exec(e)) {
          previousState.current = { ...previousState.current, txtTopicName: { previousVal: e, previousState: false } };
          return false;
        }

        if (e.length >= 3) {
          let SK = router.query["CourseID"] != undefined ? "COURSEID#" + csrFetchedData?.CourseID + "#MODULE#" + csrFetchedData?.ModuleID + "#ACTIVITY#" : "ACTIVITY#";
          let variables = { PK: ("TENANT#" + csrFetchedData.TenantID), SK: SK, TopicNameLowerCase: e.toLowerCase() };
          let finalResponse = (await AppsyncDBconnection(query[4], variables, props?.user?.signInUserSession?.accessToken.jwtToken));
          if (finalResponse.Status == "Success") {
            if (finalResponse?.res?.[queryName[4]].items.length > 0) {
              previousState.current = { ...previousState.current, txtTopicName: { previousVal: e, previousState: false } };
              return false;
            } else {
              previousState.current = { ...previousState.current, txtTopicName: { previousVal: e, previousState: true } };
              return true;
            }
          }
        }
        if (previousState.current?.txtTopicName?.previousVal != undefined && e == previousState.current.txtTopicName?.previousVal.toLowerCase()) {
          return true;
        }
        return false;
      }),
  });

  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };

  if (csrFetchedData?.EditData?.Keywords) {
    setTags(JSON.parse(csrFetchedData.EditData?.Keywords));
  }

  const { register, handleSubmit, formState, watch, setValue, reset } = useForm(formOptions);
  const { errors } = formState;
  const keyCodes = {
    comma: 188,
    enter: 13,
    tab: 9,
  };

  const delimiters = useMemo(() => {
    return [keyCodes.comma, keyCodes.enter, keyCodes.tab];
  }, [keyCodes.comma, keyCodes.enter, keyCodes.tab]);
  const finalResponse = useCallback((FinalStatus) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", "")
      setModalValues({
        ModalInfo: "Success",
        ModalOnClickEvent: () => {
          if (csrFetchedData.CourseID != "undefined")
            router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityID=${csrFetchedData?.ActivityID}&CourseID=${csrFetchedData.CourseID}&CourseName=${csrFetchedData.CourseName}&ModuleID=${csrFetchedData.ModuleID}&ActivityName=Discussion`)
          else
            router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityName=Discussion&ActivityID=${csrFetchedData?.ActivityID}`)
        },
      });
      ModalOpen();
    }
  }, [csrFetchedData?.ActivityID, csrFetchedData.CourseID, csrFetchedData.CourseName, csrFetchedData.ModuleID, router, setValue]);

  useEffect(() => {
    if (csrFetchedData.mode == "Edit") {
      setValue("txtTopicName", csrFetchedData?.EditTopicData?.TopicName)
      setValue("txtDiscussionmsg", csrFetchedData?.EditTopicData?.Description)
     
    }
    if (watch("isClean")) {
      setValue("txtTopicName", "")
      setTags([])
      setValue("txtDiscussionmsg", "")
      setValue("isClean", false)
    }
  }, [csrFetchedData?.EditTopicData, csrFetchedData?.EditTopicData?.Description, csrFetchedData?.EditTopicData?.TopicName, csrFetchedData.mode, setValue, watch])


  useMemo(() => {
    if (csrFetchedData?.EditTopicData!= undefined) {
      if ((csrFetchedData.mode == "Edit") && csrFetchedData?.EditTopicData?.Keywords) {
        setTags(JSON.parse(csrFetchedData?.EditTopicData?.Keywords));
      }
    }
   
  }, [csrFetchedData?.EditTopicData, csrFetchedData.mode]);

  const handleDelete = useCallback(
    (i) => {
      setTags(tags.filter((tag, index) => index !== i));
      setValue("ReactTags", "Delete", { shouldValidate: true });
    },
    [setValue, tags]
  );
  const handleAddition = useCallback(
    (tag) => {
      setTags([...tags, tag]);
      setValue("ReactTags", "Add", { shouldValidate: true });
    },
    [setValue, tags]
  );

  const handleDrag = useCallback(
    (tag, currPos, newPos) => {
      const newTags = tags.slice();
      newTags.splice(currPos, 1);
      newTags.splice(newPos, 0, tag);
      setTags(newTags);
    },
    [tags]
  );

  const ReactTagsButton = ({ tags, ButtonClassName, ButtonText, errors, watch, delimiters, handleAddition, handleDelete, handleDrag, handleSubmit, router, submitHandler, props, Flag, Data }) => {
    let count = Object.keys(errors);
    let focus = false;
    if (count.length == 1 && count[0] == "ReactTags") {
      focus = true;
    }

    {/*Reset All Data */ }
    const resetData = useCallback(() => {
      setTags([]);
      setValue("txtTopicName", "")
      setValue("txtDiscussionmsg", "")
      setValue("isClean", true)
    }, []);

    return (
      <>
        <div className="">
          <ReactTags className="" id="rcttags" autofocus={focus} inline allowUnique tags={tags} placeholder="Type and Press Enter to add new keywords" delimiters={delimiters} handleDelete={handleDelete} handleAddition={handleAddition} handleDrag={handleDrag} inputFieldPosition="top" />
          <div className="{invalid-feedback} text-red-500 text-sm">
            {errors?.ReactTags?.message}
          </div>
        </div>
        <div className="flex justify-between gap-1 nvl-Def-Input pt-6">
          <NVLButton id="btnSave" Flag={Flag} text={ButtonText ? ButtonText : "Submit"} disabled={watch("File") == "Uploading" ? true : false} type={"submit"} className={ButtonClassName ? ButtonClassName : `w-32 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`} onClick={handleSubmit((data) => submitHandler(data, "Page"))} />
          <NVLButton id="btnCancel" text={"Cancel"} disabled={watch("File") == "Uploading" ? true : false}
            type="button" className={`nvl-button w-28 ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`}
            onClick={() => Data.CourseID != "undefined" ? router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityID=${Data?.ActivityID}&CourseID=${Data.CourseID}&CourseName=${Data.CourseName}&ModuleID=${Data.ModuleID}&ActivityName=Discussion`) : router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityName=Discussion&ActivityID=${Data?.ActivityID}`)} ></NVLButton>
        </div>
      </>
    );
  }

  const submitHandler = async (data) => {
    let currentquery = (csrFetchedData.mode == "Edit" ? query[2] : query[0]);
    let topicId = (csrFetchedData.mode == "Edit" ? csrFetchedData?.TopicSub : crypto.randomUUID());
    let sk = (csrFetchedData.CourseID != "undefined") ? ("COURSEID#" + csrFetchedData.CourseID + "#MODULE#" + csrFetchedData.ModuleID + "#ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + topicId) : ("ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + topicId);

    let variables = {
      input: {
        PK: "TENANT#" + props.TenantInfo.TenantID,
        SK: sk,
        ActivityID: csrFetchedData?.ActivityID,
        Description: data.txtDiscussionmsg,
        TopicName: data.txtTopicName,
        TopicNameLowerCase: data.txtTopicName.toLowerCase(),
        Keywords: JSON.stringify(tags),
        CreatedDate: new Date(),
        TopicID: topicId,
        TenantID: props.TenantInfo.TenantID,
        IsDelete: false,
      },
    };
    if (csrFetchedData.mode != "Edit") {
      variables.input = { ...variables.input, UserSub: props?.user?.attributes["sub"] };
    }

    let finalStatus = (await AppsyncDBconnection(currentquery, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
    finalResponse(finalStatus)

  };
  let pageRoutes = [];
  if (csrFetchedData?.CourseID != "undefined") {
    pageRoutes = [
      { path: "/CourseManagement/CourseList", breadcrumb: "Course Management" },
      { path: `/CourseManagement/ModulesList?CourseID=${csrFetchedData.CourseID}`, breadcrumb: "Manage Course" },
      { path: `/ActivityManagement/UserConsume?Mode=Start&ActivityID=${csrFetchedData?.ActivityID}&CourseID=${csrFetchedData.CourseID}&ModuleID=${csrFetchedData.ModuleID}&CourseName=${csrFetchedData.CourseName}&ActivityName=Discussion`, breadcrumb: ` Topic List` },
      { path: "", breadcrumb: csrFetchedData.mode == "Edit" ? "Edit Topic" : "Create Topic" }
    ];
  } else {
    pageRoutes = [
      { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
      { path: `/ActivityManagement/UserConsume?Mode=Start&ActivityName=Discussion&ActivityID=${csrFetchedData?.ActivityID}`, breadcrumb: ` Discussion ` },
      { path: "", breadcrumb: csrFetchedData.mode == "Edit" ? "Edit Topic" : "Create Topic" }
    ];
  }
  return (
    <>
      <Container PageRoutes={pageRoutes} loader={csrFetchedData.TenantID == undefined}>
        <NVLAlert ButtonYesstext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(submitHandler)}>
          <div className="nvl-FormContent !overflow-y-visible	">
            <NVLTextbox labelClassName="nvl-Def-Label"
              labelText="Topic" id="txtTopicName" placeholder={"Topic Name"}
              className={("nvl-mandatory nvl-Def-Input")}
              register={register} errors={errors} />
            <NVLMultilineTxtbox labelClassName="nvl-Def-Label" id="txtDiscussionmsg" title="Type your Message" labelText="Description" placeholder="Discussion" className=".nvl-non-mandatory nvl-Def-Input" register={register} errors={errors} />
            <div className="Center-Aligned-Items flex items-center">
              <div className="pt-1">
                <div className="Center-Aligned-Items {invalid-feedback} text-red-500  text-sm">{errors.File?.message}</div>
              </div>
            </div>
            <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52"></NVLlabel>
            <div>
              <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} tags={tags} props={props} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} Data={csrFetchedData} />
            </div>
          </div>
        </form>
      </Container>
    </>
  )
}

export default CreateTopic;

