import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLMultiSelect from "@components/Controls/NVLMultiSelect";
import NVLRadio from "@components/Controls/NVLRadio";
import { createXlmsBatchTrainingManagement } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsActivityEnrollUserListView, listXlmsTrainingEnrollUserList, listXlmsUserBulkUploadListInfos, listXlmsUserGroupListInfos, listXlmsUserListInfos } from "src/graphql/queries";
import * as Yup from "yup";
import { getXlmsTrainingManagement } from "../../src/graphql/queries";

function EnrollUser(props) {
  const router = useRouter();
  const [enrollData, setData] = useState();
  const [isRefreshing, setIsRefreshing] = useState(0);
  const [search, setSearch] = useState("");
  const [popupValues, setPopupValues] = useState({});

  useEffect(() => {
    const dataSource = async (i) => {
      let tenantId = props?.user?.attributes["custom:tenantid"];
      let activityId = decodeURIComponent(String(router.query["ActivityID"]));
      let mode = decodeURIComponent(String(router.query["Mode"]));
      let activityType = decodeURIComponent(String(router.query["ActivityType"]));
      let tempdata = [];
      let userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + tenantId, SK: "#USERINFO#", IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAININGINFO#" + props?.TrainingID }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let trainingEnrollUser = await AppsyncDBconnection(listXlmsTrainingEnrollUserList, { PK: "TENANT#" + tenantId + "#TRAININGID#" + props?.TrainingID, SK: "TRAINING#ENROLLUSER#USERSUB#", IsSuspend: false, Department: "", Designation: "", UserName: "", EmailID: "" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let userDetail = userData?.res?.listXlmsUserListInfos?.items != undefined ? userData?.res?.listXlmsUserListInfos?.items : []
      tempdata = [...tempdata, ...userDetail];
      while (userData?.res?.listXlmsUserListInfos?.nextToken != null) {
        userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + tenantId, SK: "#USERINFO#", IsSuspend: false, nextToken: userData.res?.listXlmsUserListInfos.nextToken }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        if (userData?.res?.listXlmsUserListInfos?.items?.length > 0) {
          tempdata = [...tempdata, ...userData.res?.listXlmsUserListInfos?.items];
        }
      }
      const EnrollData = await AppsyncDBconnection(listXlmsActivityEnrollUserListView, { GsiPK: "ACTIVITYID#" + activityId, GsiSK: "TENANT#" + tenantId + "#ACTIVITY#ENROLLUSER#", Department: "", Designation: "", IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let UserSub = [];
      if (tempdata?.length > 0) {
        let enrollData = EnrollData.res?.listXlmsActivityEnrollUserListView?.items;
        if (enrollData?.length > 0) {
          enrollData.map((data) => { UserSub = [...UserSub, data.UserSub] })
        }
        tempdata = tempdata.filter((item) => { return !UserSub.includes(item.UserSub) })
      }
      const groupData = await AppsyncDBconnection(listXlmsUserGroupListInfos, { PK: "TENANT#" + tenantId, SK: "GROUPINFO#", IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      let temp = {};
      userData.res?.listXlmsUserListInfos?.items.map((item) => {
        temp = { ...temp, [item.UserSub]: { Department: item.Department, Designation: item.Designation, FirstName: item.FirstName, LastName: item.LastName, } }
      })
      setData({ mode: mode, TrainingEnrollData: trainingEnrollUser?.res?.listXlmsTrainingEnrollUserList?.items, TrainingData: trainingData?.res?.getXlmsTrainingManagement, userData: tempdata, TenantID: tenantId, GroupData: groupData?.res?.listXlmsUserGroupListInfos?.items, ActivityID: activityId, ActivityType: activityType, userDeptData: temp })
    }
    dataSource();
    return (() => {
      setData((temp) => { return { ...temp } });
    })
  }, [props?.TenantInfo?.TenantID, props?.TrainingEnrollData, props?.TrainingID, props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query])

  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "User Enrolled Successfully.",
    ModalOnClickEvent: () => { props.TrainingID ? router.push("/TrainingManagement/TrainingManagementList") : router.push("/ActivityManagement/ActivityList"); }
  };

  const [modalValues, setModalValues] = useState(initialModalState);
  const [textName, setTextName] = useState(initialModalState);

  const validationSchema = Yup.object().shape({
    rbUser: Yup.string().test("NOValid", "novalid", (e) => {
      if (e == "User" && e != currentDiv) {
        setCurrentDiv("User");
        userHandler();
      } else if (e == "Group" && e != currentDiv) {
        setCurrentDiv("Group");
        groupHandler();
      } else if (e == "BulkUpload" && e != currentDiv) {
        setCurrentDiv("BulkUpload");
        bulkUploadHandler();
      }
      return true;
    }),

    ddlUser: Yup.string().test(
      "MultiSlect_EmptyHandler",
      "",
      (e, { createError }) => {
        if ((e == "Empty" || e == undefined) && multiselected == null) {
          return createError({ message: `${watch("rbUser") == "User" ? "Users required" : watch("rbUser") == "Group" ? "Group is required" : ""}`, });
        }
        if (e == "NoData") {
          return createError({ message: `${watch("rbUser") == "User" ? "There is no User found" : "There is no group found"}`, });
        }
        return true;
      }
    ),

    File: Yup.string().when("rbUser", {
      is: "BulkUpload",
      then: Yup.string().test("file_Error", "", (e, { createError }) => {
        if (e == undefined || e == "false" || textName == undefined) {
          return createError({ message: "File is required" });
        }
        if (e == "fileType") {
          return createError({ message: "Invalid file type" });
        }
        if (e == "Empty" || e == undefined) {
          return createError({ message: "Empty File... Please Fill Values" });
        }
        if (e == "HeaderMismatch" || e == undefined) {
          return createError({
            message: "Header Mismatch Please Choose Correct Format.",
          });
        }
        if (e == "FileSize") {
          setTextName("Select File");

          return createError({ message: "File size should be 5MB" });
        }
        if (e == "Error") {
          return createError({ message: "Server Error Please Try Again" });
        }
        return true;
      }),
    }),
  });

  const [currentDiv, setCurrentDiv] = useState("User");
  const [fileValues, setFileValues] = useState({ TextName: "Select File", FilePath: "", });

  const [multiselected, setMultiSelected] = useState([]);

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, reset, watch, formState } = useForm(formOptions);
  const { errors } = formState;

  const searchBoxVal = (e) => {
    setSearch(e);
  };

  //Grid data refresh
  const refreshData = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };
  const MultiSelectList = useMemo(() => {
    let multiSelectUserOrGroup = currentDiv == "User" ? enrollData?.userData : enrollData?.GroupData;
    let MultiSelectList = [];
    if (multiSelectUserOrGroup && multiSelectUserOrGroup.length > 0) {
      if (currentDiv == "User") {
        if (props?.TrainingID && enrollData?.TrainingEnrollData?.length > 0) {
          multiSelectUserOrGroup.map((getItem) => {
            if (getItem.EmailID != null) {
              enrollData?.TrainingEnrollData != undefined && (enrollData?.TrainingEnrollData?.some((x) => x?.UserSub == getItem?.UserSub)) ? "" : MultiSelectList.push({ value: getItem.UserSub, label: getItem.EmailID, Name: getItem?.UserName, Department: getItem?.Department, Designation: getItem?.Designation, FirstName: getItem?.FirstName, LastName: getItem?.LastName });
            }
          })
        }
        else {
          multiSelectUserOrGroup.map((getItem) => {
            if (getItem.EmailID != null) {
              MultiSelectList.push({ value: getItem.UserSub, label: getItem.EmailID, Name: getItem?.UserName, Department: getItem?.Department, Designation: getItem?.Designation, FirstName: getItem?.FirstName, LastName: getItem?.LastName });
            }
          });
        }
      } else {
        multiSelectUserOrGroup.map((getItem) => {
          MultiSelectList.push({ value: getItem.SK, label: getItem.GroupName });
        });
      }
    }
    return MultiSelectList;
  }, [currentDiv, enrollData?.GroupData, enrollData?.TrainingEnrollData, enrollData?.userData, props?.TrainingID]);

  const userTemplate = useMemo(() => {
    return [
      { HeaderName: "UserSub", Action: "true" },
      { HeaderName: "UserName", Action: "true" },
      { HeaderName: "EmailID", Action: "true" },
      { HeaderName: "Department", Action: "true" },
      { HeaderName: "Designation", Action: "true" },
      { HeaderName: "FirstName", Action: "true" },
      { HeaderName: "LastName", Action: "true" },
    ];
  }, []);

  const downloadCsvFile = useCallback(async (e) => {
    if (e?.type == "click") {
      const UserListJson = enrollData?.userData;
      let rows = [];
      userTemplate.forEach((element) => {
        element.Action === "true" ? rows.push(element.HeaderName) : "";
      });
      let csvContent = "data:text/csv;charset=utf-8,";
      csvContent += rows + "\r\n";
      if (UserListJson?.length > 0) {
        UserListJson.forEach((element) => {
          if (element.UserSub != null) {
            csvContent += element.UserSub + "," + element.UserName + "," + element.EmailID + "," + element.Department + "," + element.Designation + "," + element.FirstName + "," + element.LastName;
            csvContent += "\n";
          }
        });
      }
      let encodedUri = encodeURI(csvContent);
      let link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", "UserList.csv");
      link.click();
      link.remove();
    }
  }, [enrollData?.userData, userTemplate]);

  async function fileValidation(e) {
    const file = e.target.files[0];
    if (file == undefined) {
      e.stopPropagation();
      e.preventDefault();
      e.target.value = null;
      return;
    }
    setValue("File", "Uploading");
    let fileInput = document.getElementById("getFile");
    let filePath = fileInput.value;
    let allowedExtensions = /(\.csv)$/i;
    if (!allowedExtensions.exec(filePath)) {
      fileInput.value = "";
      setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
      setValue("File", "fileType", { shouldValidate: true });
      return false;
    } else if (file.size > process.env.ACTIVITY_ENROLLUSER_FILE_SIZE) {
      setValue("File", "FileSize", { shouldValidate: true });
    } else {
      await UploadFile(e);
    }
  }

  async function UploadFile(e) {
    const file = e.target.files[0];
    const csvReader = new FileReader();
    csvReader.onload = async function (e) {
      const text = e.target.result;
      let lines = text.split("\n");
      let values = lines[0].split(",");
      let isCSVDatacheck = false;
      for (let i = 0; i < userTemplate.length; i++) {
        if (values[i].trim() != userTemplate[i].HeaderName.trim() || values.length != userTemplate.length) {
          setValue("File", "HeaderMismatch", { shouldValidate: true });
          isCSVDatacheck = true;
          return;
        }
      }
      if (!isCSVDatacheck) {
        let data = lines[1].split(",");
        if (data.length != userTemplate.length) {
          setValue("File", "Empty", { shouldValidate: true });
          isCSVDatacheck = true;
          return;
        }
      }
      if (!isCSVDatacheck) {
        let fetchURL = props?.TrainingID ? process.env.APIGATEWAY_URL_UPLOAD_FILE_TRAINING + `?FileName=${file.name}&TenantID=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&ActivityType=${enrollData?.ActivityType}&Type=BulkUserUpload` :
          process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${file.name}&TenantID=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&ActivityType=${enrollData?.ActivityType}&Type=BulkUserUpload`;
        let headers = {
          method: "GET",
          headers: {
            authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
            defaultrole: props?.TenantInfo.UserGroup,
            groupmenuname: props?.TrainingID ? "TrainingManagement" : "ActivityManagement",
            menuid: props?.TrainingID ? "400102" : "500002",
          },
        };
        let extension = file.name.substring(file.name.lastIndexOf(".") + 1).toLowerCase();
        let contentType = extension == "csv" ? "text/" + extension : ImageExtension.indexOf(extension) >= 0 ? "image/" + extension : VideoExtension.indexOf(extension) >= 0 ? "video/" + extension : "application/" + extension;
        let presignedHeader = {
          method: "PUT",
          headers: {
            "content-type": contentType,
            defaultrole: props?.TenantInfo.UserGroup,
            groupmenuname: props?.TrainingID ? "TrainingManagement" : "ActivityManagement",
            menuid: props?.TrainingID ? "400102" : "500002",
          },
          body: file,
        };
        let finalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);
        if (finalStatus[0] != "Success") {
          setFileValues({ ...fileValues, TextName: "Select File", FilePath: "", });
          setValue("File", "Error", { shouldValidate: true });
          return;
        } else {
          setValue("File", "exist", { shouldValidate: true });
          setFileValues({ ...fileValues, TextName: file.name, FilePath: finalStatus[1], });
        }
      }
    };
    csvReader.readAsText(file);
  }

  const userHandler = async () => {
    setMultiSelected([]);
    setFileValues({ TextName: "Select File", FilePath: "" });
    setValue("ddlUser", "", { shouldValidate: true });
    setValue("File", "", { shouldValidate: true });
  };

  const groupHandler = async () => {
    setMultiSelected([]);
    setFileValues({ TextName: "Select File", FilePath: "" });
    setValue("ddlUser", "", { shouldValidate: true });
    setValue("File", "", { shouldValidate: true });
  };

  const bulkUploadHandler = async () => {
    setMultiSelected([]);
    setValue("ddlUser", "", { shouldValidate: true });
  };

  const finalResponse = useCallback((FinalStatus) => {
    if (FinalStatus != "Success") {
      setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: FinalStatus, });
      ModalOpen();
      return;
    } else {
      let temp;
      if (enrollData?.mode == "EnrollmentList") {
        temp = () => {
          router.push(`/ActivityManagement/DismissUser?Mode=Edit&ActivityID=${enrollData?.ActivityID}&ActivityType=${enrollData?.ActivityType}`);
        }
      } else if (props?.TrainingID) {
        temp = () => {
          router.push("/TrainingManagement/TrainingManagementList");
        }
      }
      else {
        temp = () => {
          router.push("/ActivityManagement/ActivityList");
        }
      }
      setModalValues({ ModalInfo: "Success", ModalTopMessage: FinalStatus, ModalBottomMessage: "User Enrolled Successfully", ModalOnClickEvent: temp, });
      ModalOpen();
    }
  }, [enrollData?.ActivityID, enrollData?.ActivityType, enrollData?.mode, props?.TrainingID, router]);

  useEffect(() => {
    setValue("rbUser", "User");
  }, [setValue]);

  const RemoveNull = (obj) => {
    let tempjson = {};
    obj && Object.keys(obj).forEach((k) => {
      if (obj?.[k] != undefined) {
        tempjson = { ...tempjson, [k]: obj?.[k] }
      }
    });
    return tempjson;
  };

  const submitHandler = async () => {
    setValue("submit", true);
    let updateTraining = RemoveNull(enrollData?.TrainingData)
    let variable = {
      input: { ...updateTraining }
    }
    await AppsyncDBconnection(createXlmsBatchTrainingManagement, variable, props?.user?.signInUserSession?.accessToken?.jwtToken)
    const finalData = [];
    if (currentDiv == "User" && multiselected.length == 0) {
      setValue("ddlUser", "NoData", { shouldValidate: true });
      setValue("submit", false);
      return;
    } else if (currentDiv == "Group" && multiselected.length == 0) {
      setValue("ddlUser", "NoData", { shouldValidate: true });
      setValue("submit", false);
      return;
    }

    if (fileValues.FilePath == "" && currentDiv == "BulkUpload") {
      setValue("File", "false", { shouldValidate: true });
      setValue("submit", false);
      return;
    }

    if (currentDiv == "User") {
      for (let i = 0; i < multiselected.length; i++) {
        if (!props?.TrainingID) {
          finalData.push({ UserSub: multiselected[i].value, EmailID: multiselected[i].label, UserName: multiselected[i].Name, ActivityID: enrollData?.ActivityID, Department: multiselected[i]?.Department, Designation: multiselected[i]?.Designation, FirstName: multiselected[i]?.FirstName, LastName: multiselected[i]?.LastName, });
        } else {
          finalData.push(multiselected[i].value);
        }
      }
    }
    if (currentDiv != "User" && multiselected.length > 0) {
      for (let i = 0; i < multiselected.length; i++) {
        finalData.push({ GroupID: multiselected[i].value.split("#")[1], GroupName: multiselected[i].label, ActivityID: enrollData?.ActivityID, });
      }
    }

    let fetchURL = props?.TrainingID ? ((currentDiv == "BulkUpload" ? process.env.APIGATEWAY_URL_TRAINING_ENROLL_BULKUPLOAD + `?S3KeyName=${props?.TenantInfo.RootFolder}/${enrollData?.TenantID}&S3BucketName=${props?.TenantInfo.BucketName}` : process.env.APIGATEWAY_URL_TRAINING_ENROLL_UPLOADUSER))
      : (currentDiv == "BulkUpload" ? process.env.APIGATEWAY_URL_ENROLL_BULKUPLOAD + `?S3KeyName=${props?.TenantInfo.RootFolder}/${enrollData?.TenantID}&S3BucketName=${props?.TenantInfo.BucketName}` : currentDiv == "User" ? process.env.APIGATEWAY_URL_ENROLL_UPLOADUSER : process.env.APIGATEWAY_URL_ENROLL_UPLOADGROUP);
    let stateurl = props?.TrainingID ? process.env.STEP_FUNCTION_ARN_TRAINING_ENROLL_BULKUPLOAD : process.env.STEP_FUNCTION_ARN_ENROLL_BULKUPLOAD;
    let jsonBulkSaveData;
    let jsonSaveData

    if (currentDiv == "BulkUpload") {
      jsonBulkSaveData = props?.TrainingID ? '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","Type": "BulkUserUpload", "FileName": "' + document.getElementById("getFile")?.files[0]?.name + '","TrainingID": "' + props?.TrainingID + '", "BucketName":"' + props?.TenantInfo.BucketName + '","RootFolder":"' + props?.TenantInfo.RootFolder + '" }'
        : '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","ActivityType": "' + enrollData?.ActivityType + '","Type": "BulkUserUpload", "FileName": "' + document.getElementById("getFile")?.files[0]?.name + '","ActivityID": "' + enrollData?.ActivityID + '", "BucketName":"' + props?.TenantInfo.BucketName + '","RootFolder":"' + props?.TenantInfo.RootFolder + '" }';
    }
    else {
      jsonSaveData = props?.TrainingID ? '{ "NotificationSub":"","TrainingID":"' + props?.TrainingID + '","CreatedBy":"' + enrollData?.TrainingData?.CreatedBy + '","CreatedDate":"' + enrollData?.TrainingData?.CreatedDate + '","LastModifiedBy":"' + enrollData?.TrainingData?.LastModifiedBy + '","LastModifiedDate":"' + enrollData?.TrainingData?.LastModifiedDate + '","Type":"' + currentDiv + '","TenantID":"' + props?.TenantInfo.TenantID + '","UserDetails":' + JSON.stringify(finalData) + "}"
        : '{ "Type":"' + currentDiv + '","TenantID":"' + props?.TenantInfo.TenantID + '","ActivityType":"' + enrollData?.ActivityType + '","UserDetails":' + JSON.stringify(finalData) + "}";
    }

    let userHeaders = props?.TrainingID ? {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props?.TenantInfo.UserGroup,
        groupmenuname: "TrainingManagement",
        menuid: "400102",
        stateMachineArn: process.env.STEP_FUNCTION_ARN_TRAINING_ENROLL_UPLOADUSER,
      },
      body: jsonSaveData,
    } : {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props?.TenantInfo.UserGroup,
        groupmenuname: "ActivityManagement",
        menuid: "500006",
      },
      body: jsonSaveData,
    };
    let bulkHeaders = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props?.TenantInfo.UserGroup,
        groupmenuname: props?.TrainingID ? "TrainingManagement" : "ActivityManagement",
        menuid: props?.TrainingID ? "400102" : "500006",
        stateMachineArn: stateurl,
      },
      body: jsonBulkSaveData,
    };
    let headers = currentDiv == "BulkUpload" ? bulkHeaders : userHeaders;


    let finalStatus = await APIGatewayPostRequest(fetchURL, headers);
    finalResponse(finalStatus.Status);
    setValue("submit", false);
  };
  // Bread Crumbs

  const overrideStrings = useMemo(() => {
    return {
      "allItemsAreSelected": currentDiv == "User" ? "All Users are Selected" : "All Groups are Selected",
      "noOptions": currentDiv == "User" ? "No Users Found" : "No Groups Found",
      "selectSomeItems": currentDiv == "User" ? "Select Users" : "Select Group",
    }
  }, [currentDiv])
  const pageRoutes = useMemo(() => {
    if (router.query["Mode"] != "EnrollmentList") {
      return [{ path: props?.TrainingID ? "/TrainingManagement/TrainingManagementList" : "/ActivityManagement/ActivityList", breadcrumb: props?.TrainingID ? "Training Management" : 'Activity Management' }, { path: "", breadcrumb: "Enroll User" }];
    }
    else {
      return [
        { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
        { path: `/ActivityManagement/DismissUser?Mode=Edit&ActivityID=${enrollData?.ActivityID}&ActivityType=${enrollData?.ActivityType}`, breadcrumb: "Enrollment List" },
        { path: "", breadcrumb: "Enroll User" }
      ];

    }

  }, [enrollData?.ActivityID, enrollData?.ActivityType, props?.TrainingID, router.query])

  const gridHeaderColumn = useMemo(() => {
    return [{ HeaderName: "Template Name", Columnvalue: "TemplateName", HeaderCss: "!w-3/12", },
    { HeaderName: "Uploaded Date ", Columnvalue: "UploadDate", HeaderCss: "!w-2/12" },
    { HeaderName: "Uploaded By", Columnvalue: "UploadedBy", HeaderCss: "!w-2/12", },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-2/12", },
    { HeaderName: "Download", Columnvalue: "Download", HeaderCss: "!w-1/12", }]
  }, [])

  const variable = useMemo(() => { return { PK: "TENANT#" + props?.TenantInfo.TenantID + "#BULKUPLOADTEMPLATE", SK: "" }; }, [props?.TenantInfo.TenantID]);

  const DownloadFiles = useCallback(async (url) => {
    setValue("download", true)
    let fetchURL = process.env.APIGATEWAY_INVOKEURL;
    let headers = {
      method: "POST",
      headers: {
        "Content-Type": "text/csv",
        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
        bucketname: props.TenantInfo.BucketName,
      },
      body: url,
    };
    let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
    var win = window.open(await FinalStatus.res.text(), '_blank');
    setValue("download", false)
  }, [props.TenantInfo.BucketName, props.user.signInUserSession.accessToken.jwtToken, setValue])

  const gridDataBind = useCallback((viewData) => {
    const rowGrid = [];
    viewData && viewData.map(() => {
      rowGrid.push({
        PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
        SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="PK" text={getItem.SK} />),
        SNo: (<NVLlabel id={"lblSNo" + (index + 1)} name="SNo" text={index + 1}></NVLlabel>),
        TemplateName: (<NVLlabel id={"lblName" + (index + 1)} name="Name" text={getItem.TemplateName} />),
        UploadDate: <NVLlabel id={"lblDate" + (index + 1)} name="Date" text={getItem.UploadDate} />,
        UploadedBy: <NVLlabel id={"lblBy" + (index + 1)} name="By" text={getItem.UploadedBy} />,
        Status: <NVLlabel id={"lblStatus" + (index + 1)} name="Status" text={getItem.Status} />,
        Download: (<NVLButton type={"button"} className="inline-flex justify-center  text-sm font-medium text-white shadow-sm hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-50 focus:ring-offset-2" onClick={(getItem.Status != "Inprogress") ? () => { DownloadFiles(getItem.DownloadFileUrl) } : () => { return [] }} >
          <i className={(getItem.Status != "Inprogress") ? "fa-solid fa-download text-black fa-lg" : "fa-solid fa-download  fa-lg fa-fade text-slate-600"}  ></i></NVLButton>)
      })
    })
    return rowGrid;
  }, [DownloadFiles])

  function popup(Content) {
    setPopupValues({ Content: Content });
  }

  function resetPopUp() {
    setPopupValues({ Content: "" });
  }

  const cancelEvent = (e) => {
    e.preventDefault();
    resetPopUp();
  };

  return (
    <>
      <Container PageRoutes={pageRoutes} loader={enrollData?.ActivityID == undefined} title={"Enroll User"}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(submitHandler)} id="Formjs">
          <div className={`nvl-FormContent ${(watch("submit") || watch("download")) ? "pointer-events-none" : ""}`}>
            <NVLlabel className="nvl-Def-Label" text="Enroll By"></NVLlabel>
            <div className={`flex  pt-2 flex-wrap ${props?.TrainingID ? "gap-20" : "gap-3"}`}>
              <NVLRadio id="rbUser" type="radio" text="User" value={"User"} errors={errors} register={register} name="rbUser" />
              {!props?.TrainingID && <NVLRadio id="rbUser" type="radio" text="Group" value={"Group"} errors={errors} register={register} name="rbUser" />}
              <NVLRadio id="rbUser" type="radio" text="Bulk Upload" value={"BulkUpload"} errors={errors} register={register} name="rbUser" />
            </div>
            <section id="divUser" className={currentDiv == "BulkUpload" ? "hidden" : "pt-4"}>
              <div className="flex ">
                <NVLMultiSelect overrideStrings={overrideStrings} id="ddlUser" className="w-96" required={currentDiv == "User"} disabled={true} options={MultiSelectList} value={multiselected} onChange={(event) => { setMultiSelected(props?.TrainingID ? event?.length <= (enrollData?.TrainingData?.BatchSize - enrollData?.TrainingData?.EnrollCount) ? event : multiselected : event); if (event?.length == undefined || event.length == 0) { setValue("ddlUser", "Empty", { shouldValidate: true }); } else if (props?.TrainingID && !(event?.length <= (enrollData?.TrainingData?.BatchSize - enrollData?.TrainingData?.EnrollCount))) { popup(`Enrollment work according to the training batch size,Batch Size : ${enrollData?.TrainingData?.BatchSize} EnrollUser Count : ${(enrollData?.TrainingData?.EnrollCount != null || enrollData?.TrainingData?.EnrollCount != undefined) ? enrollData?.TrainingData?.EnrollCount : 0}`) } else { setValue("ddlUser", "", { shouldValidate: true }); } }} />
                <div className="pt-3">
                  {props?.TrainingID ?
                    <NVLlabel className="nvl-Def-Label" HelpInfo={`${"Enrollment work according to the training batch size"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} /> : ""
                  }
                </div>
              </div>
              <div className="block {invalid-feedback} text-red-500  text-sm">
                {errors.ddlUser?.message}
              </div>
            </section>
            <section id="divBulkUpload" className={currentDiv != "BulkUpload" ? "hidden" : ""}>
              <div className="pt-4 flex">
                <div>
                  <NVLlabel text="Upload File" className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: .csv <br>File size should be 5MB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                  <div className="flex xl:flex-wrap items-center">
                    <div>
                      <NVLFileUpload text={fileValues.TextName == null ? "Select File" : fileValues.TextName} accept={`${"Acceptable file format: csv<br>File size should not exceed more than 50KB"}`} onChange={(e) => fileValidation(e)} />
                      <div className={"Center-Aligned-Items {invalid-feedback} text-red-500 text-sm "}>
                        {errors?.File?.message}
                      </div>
                      <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                      <div className="flex my-4 justify-between">
                        <NVLlabel text={"Download sample template"} className="nvl-Def-Label my-auto" />
                        <NVLButton text={!watch("download") ? "Download" : ""} type={"button"} className="bg-primary nvl-button rounded-2xl text-white" onClick={(e) => downloadCsvFile(e)} >
                          {watch("download") && (
                            <i className="fa fa-circle-notch fa-spin mr-2"> </i>
                          )}
                        </NVLButton>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
            <div className="justify-center flex gap-4 pt-4">
              <NVLButton text={currentDiv == "BulkUpload" && !watch("submit") ? "Upload" : currentDiv != "BulkUpload" && !watch("submit") ? "Enroll" : ""} type={"submit"} disabled={watch("File") == "Uploading" || watch("submit") ? true : false} className={props?.ButtonClassName ? props?.ButtonClassName : `w-32 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`} ButtonType="success">
                {watch("submit") && (
                  <i className="fa fa-circle-notch fa-spin mr-2"> </i>
                )}
              </NVLButton>
            </div>
          </div>
        </form>
        {(props.TrainingID && currentDiv == "BulkUpload") && <div className="pt-12">
          <NVLHeader placeholder={"Search by Templatename/Status"} IsSearch={true} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshData} IsNestedHeader></NVLHeader>
          <NVLGridTable user={props.user} refershPage={isRefreshing} Search={search} query={listXlmsUserBulkUploadListInfos} GridDataBind={gridDataBind} querryName={"listXlmsUserBulkUploadListInfos"} variable={variable} HeaderColumn={gridHeaderColumn}></NVLGridTable>
        </div>}
        <NVLModalPopup CancelClick={(e) => cancelEvent(e)} ButtonNotext="OK" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
      </Container>
    </>
  );
}
export default EnrollUser;
