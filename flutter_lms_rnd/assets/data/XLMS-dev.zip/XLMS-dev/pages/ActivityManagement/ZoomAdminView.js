import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLLink from "@components/Controls/NVLLink";
import { getXlmsActivityManagementInfo } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";

function ZoomAdminView( props ) {
    const router=useRouter();
    const [ExistData,setExistData]=useState();
  
    useEffect(()=>{
        async function MeetingData(){
           if (!router.query["CourseID"]) {
               let ZoomData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#" + router.query["ActivityType"] + "#ACTIVITYID#" + router.query["ActivityID"], }, props.user.signInUserSession.accessToken.jwtToken);
               let FinalData = ZoomData.res.getXlmsActivityManagementInfo
               setExistData(FinalData)
           } else {
              setExistData(props.FinalData)
           }
        }
        MeetingData()
        return (() => {
            setExistData((temp) => { return { ...temp } });
          })
    },[ExistData?.HostURL, ExistData?.MeetingID, props.FinalData, props?.TenantInfo?.TenantID, props?.user?.signInUserSession.accessToken.jwtToken, router.query])
    const openInNewTab = useCallback((url) => {  
        const newWindow = window.open(url, '_blank', 'noopener,noreferrer')   
        if (newWindow) newWindow.opener = null
      },[])

      const pageRoutes = useMemo(()=>{
        let Routes;
        if(!router.query["CourseID"]) {
            Routes= [
                { path:  "/ActivityManagement/ActivityList", breadcrumb: "Activity Management"},
                { path: "", breadcrumb: "Zoom Meeting" }
              ]; 
        } else {
            Routes= [
                { path:  `/CourseManagement/CourseList`, breadcrumb: "Course Management"},
                { path:  `/CourseManagement/ModulesList?CourseID=${router.query["CourseID"]}`, breadcrumb: "Manage Course"},
                { path: "", breadcrumb: "Zoom Meeting" }
              ]; 
        }
        return Routes;
      },[router.query])  

      const getDateFormat= useCallback((ConvertDate)=>{
         let date = new Date(ConvertDate)
        let FormattedDate=date.toLocaleString('en-US',{weekday:'long',month:'long',day:'numeric',year:'numeric',hour:'numeric',minute:'numeric',hour12:true})
        return FormattedDate;
      },[])
         
      const getDuration = useCallback(()=>{
        let hours = Math.floor(ExistData?.ActivityDuration / 60);
        let minutes = ExistData?.ActivityDuration  % 60;
        return hours+ " hrs " +minutes + " mins "
      },[ExistData?.ActivityDuration])
     
     
    return (
        <Container title="AdminView" loader={ExistData == undefined} PageRoutes={pageRoutes}>
        <div className="overflow-y-hidden">
                <div className="container mx-auto px-4 sm:px-8 pt-2">
                    <div className="float-right">
                        <NVLButton text={"Start Meeting"} ButtonType={"success"} 
                        onClick={()=>openInNewTab(ExistData?.HostURL)} 
                        />
                    </div>
                    <div className="py-9">                                          
                        <div className="-mx-4 sm:-mx-8 px-4 sm:px-8 py-4 overflow-x-auto">
                            <div className="inline-block min-w-full shadow rounded-lg overflow-hidden">
                                <table className="table-fixed w-full justify-center text-center">
                                    <tbody>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2">Start Time</td>
                                            <td className="border w-1/2 px-4 py-2">{getDateFormat(ExistData?.StartDate)}</td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">Duration(minutes)</td>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">{getDuration()}</td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2">Password protected</td>
                                            <td className="border w-1/2 px-4 py-2">{ExistData?.Password ? "Yes" : "No"}</td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">Join Link</td>
                                            <td className="border bg-gray-100 flex justify-center">
                                                <NVLLink ButtonType="link" text={ExistData?.HostURL ? ExistData?.HostURL:"-"}/>
                                                </td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">Join meeting before host</td>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">{ExistData?.IsEnableBeforeHost ? "Yes" : "No"}</td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2">Start video when host join</td>
                                            <td className="border w-1/2 px-4 py-2">{ExistData?.IsHostVideo ? "Yes":"No"}</td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">Start video when participant join</td>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">{ExistData?.IsParticipantsVideo ?"Yes":"No"}</td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2">Audio options</td>
                                            <td className="border w-1/2 px-4 py-2">{ExistData?.AudioOption}</td>
                                        </tr>
                                        <tr>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">Status</td>
                                            <td className="border w-1/2 px-4 py-2 bg-gray-100">{getDateFormat(ExistData?.StartDate)}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        </Container>
    )
}

export default ZoomAdminView;
