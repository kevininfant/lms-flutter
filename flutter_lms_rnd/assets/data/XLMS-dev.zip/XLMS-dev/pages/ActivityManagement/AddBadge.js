import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseManagementInfo, createXlmsTrainingBadgeCertificate, updateXlmsActivityManagementInfo, updateXlmsCourseManagementInfo, updateXlmsTrainingBadgeCertificate } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseManagementInfo, getXlmsTrainingBadgeCertificate } from "src/graphql/queries";
import * as Yup from "yup";

function AddBadge(props) {
  const router = useRouter();
  const [fetchedBadgeData, setFetchedBadgeData] = useState([]);
  const [file, setFile] = useState({});
  const trainingMode = useRef(props?.mode)
  useEffect(() => {
    const DataSource = async (i) => {
      let tenantId = props.user.attributes["custom:tenantid"];
      let tenantName = props.user.attributes["name"];
      let mode = decodeURIComponent(String(router.query["Mode"]));
      let activityId, activityType, courseId;
      if (mode == "Edit") {
        activityId = decodeURIComponent(String(router.query["ActivityID"]));
        activityType = decodeURIComponent(String(router.query["ActivityType"]));
      } else {
        courseId = decodeURIComponent(String(router.query["CourseID"]));
      }
      const isUpdateData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + tenantId, SK: "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId, }, props.user?.signInUserSession?.accessToken?.jwtToken);
      const courseEdit = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEBADGE#" + courseId, }, props.user?.signInUserSession?.accessToken?.jwtToken);
      const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEINFO#" + courseId, }, props.user?.signInUserSession?.accessToken?.jwtToken);
      const trainingData = await AppsyncDBconnection(getXlmsTrainingBadgeCertificate, { PK: "TENANT#" + tenantId, SK: "TRAININGBADGE#" + props?.trainerID }, props.user?.signInUserSession?.accessToken?.jwtToken)
      setFetchedBadgeData({
        ActivityID: mode == "Edit" && activityId,
        ActivityType: mode == "Edit" && activityType,
        TenantName: tenantName,
        mode: mode,
        Editdata: isUpdateData.res?.getXlmsActivityManagementInfo,
        CourseEditData: mode == "CourseDirect" && courseEdit.res?.getXlmsCourseManagementInfo,
        Coursedata: mode == "CourseDirect" && courseData.res?.getXlmsCourseManagementInfo,
        TrainingData: props?.mode == "TrainingDirect" && trainingData?.res?.getXlmsTrainingBadgeCertificate,
        TenantID: tenantId,
      })
      let fileNameSource = mode == "Edit" ? isUpdateData?.res.getXlmsActivityManagementInfo.BadgeUploadFile : (props?.mode == "TrainingDirect") ? trainingData?.res?.getXlmsTrainingBadgeCertificate?.BadgeUploadFile : mode == "CourseDirect" && courseEdit.res?.getXlmsCourseManagementInfo?.BadgeUploadFile;
      setFile({ TextName: (mode == "Edit" || mode == "CourseDirect" || props?.mode == "TrainingDirect") ? fileNameSource && fileNameSource.substring(fileNameSource.lastIndexOf("/") + 1, fileNameSource.length) : "", FilePath: (mode == "Edit" || mode == "CourseDirect" || props?.mode == "TrainingDirect") ? fileNameSource : "", FileName: (mode == "Edit" || mode == "CourseDirect" || props?.mode == "TrainingDirect") ? fileNameSource : "" })
      if (fileNameSource != undefined) {
        setValue("File", "exist", { shouldValidate: true });

      }
    }
    DataSource();
    return (() => {
      setFetchedBadgeData((temp) => { return { ...temp } });
    })


  }, [props, props.TenantInfo.TenantID, props?.mode, props?.trainerID, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue])
  const [filePathChanged, setfilePathChanged] = useState(false);

  const validationSchema = Yup.object().shape({
    txtBadgeName: Yup.string()
      .required("Badge name is required")
      .matches(
        Regex("AlphaNumForTopicName"),
        "Enter Valid Badge name"
      )
      .max(250, "Maximum length exceeded 250")
      .nullable(),
    txtBadgeDescription: Yup.string()
      .max(500, "Maximum length exceeded 500")
      .nullable(),
    txtIssuerName: Yup.string()
      .notRequired()
      .max(500, "Maximum length exceeded 500")
      .test("", "Enter a valid Issuer Name", (e) => {
        if (e == undefined || e == "") {
          return true;
        }
        const regex = new RegExp(/^(?!\s)(?!.*\s$)[a-zA-Z\s]+$/);
        if (!regex.test(e)) {
          return false;
        }
        return true;
      })
      .nullable(),
    txtIssuerEmailID: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .min(3, "Required minimum of 3 character")
      .max(128, "Maximum limit exceeds")
      .test("", "Enter a Valid Email", (e) => {
        if (e == undefined || e == "") {
          return true;
        }
        const regex = new RegExp(
          /^[a-zA-Z0-9.+_-]{2}[a-z.A-Z0-9+_-]+@[a-zA-Z0-9]{1}[a-zA-Z0-9-]+[.][a-zA-Z0-9]{1}[a-zA-Z0-9]+$/
        );
        if (!regex.test(e)) {
          return false;
        }
        return true;
      })
      .nullable(),
    File: Yup.string().test("file_Error", "", (e, { createError }) => {
      if ((e == undefined || e == "false" || e == "File") && (file.TextName == undefined || fetchedBadgeData.FileNameSource == undefined)) {
        return createError({ message: "File is required" });
      }
      if (e == "fileType") {
        setFile((temp) => {
          return ({ ...temp, TextName: "Select File" })
        })
        return createError({ message: "Invalid file type" });
      }
      if (e == "Error") {
        return createError({ message: "Server Error Please Try Again" });
      }
      if (e == "FileSize") {
        setFile((temp) => {
          return ({ ...temp, TextName: "Select File" })
        })
        return createError({ message: "File size should be 50KB" });
      }
      if (e == "filetypeChange") {
        setFile((temp) => {
          return ({ ...temp, TextName: "Select File" })
        })
        return createError({ message: "File type seems to be changed." });
      }

      return true;
    }),

    txtValidity: Yup.string().test("len", "Numbers only allowed", (val, { createError }) => {
      let LimitedTime = 9999;
      if (!/^\d+$/.test(val) && val) {
        return createError({
          message: `Numbers only allowed.`,
        });
      }
      if (val == "") return true;
      if (val == "0") {
        return createError({
          message: `Days should be greater than zero.`,
        });
      }
      if (val?.length == "1") {
        return true;
      }

      else if (val > LimitedTime) {
        return createError({
          message: `Maximum only 4 digits.`,
        });
      }
      else if (parseInt(val) <= 0) {
        return createError({ message: `Days only positive values and more then zero` });
      }
      else {
        return true;
      }
    }).nullable()
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, formState, watch, setValue, reset } =
    useForm(formOptions);
  const { errors } = formState;

  const initialModalState = { ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully.", ModalOnClickEvent: () => { if (fetchedBadgeData.mode == "CourseDirect") { router.push("/CourseManagement/CourseList"); } else if (trainingMode.current == "TrainingDirect") { router.push("/TrainingManagement/TrainingManagementList"); } else { router.push("/ActivityManagement/ActivityList"); } }, };
  const [modalValues, setModalValues] = useState(initialModalState);

  useEffect(() => {
    if (fetchedBadgeData.mode == "Edit" || fetchedBadgeData.mode == "CourseDirect" || trainingMode.current == "TrainingDirect") {
      let editData = fetchedBadgeData.mode == "Edit" ? fetchedBadgeData.Editdata : (trainingMode.current == "TrainingDirect") ? fetchedBadgeData?.TrainingData : fetchedBadgeData.CourseEditData;
      setValue("rbAddRestrict", editData?.ADDRestrict);
      setValue("txtBadgeName", editData?.BadgeName);
      setValue("txtBadgeDescription", editData?.BadgeDescription);
      setValue("txtIssuerName", editData?.IssuerName);
      setValue("txtIssuerEmailID", editData?.IssuerEmailID);
      setValue("txtValidity", editData?.BadgeValidityByDays);
      setValue("txtstdate", editData?.BadgeValidityByDate);
      setValue("rbActivityCohort", editData?.ADDRestrict);
      setValue("txtGrade", editData?.BadgeGrade);
      setValue("rbValidity", editData?.BadgeValidityByDays == null ? "ByDate" : "NumberOfDays");
    }
  }, [fetchedBadgeData.CourseEditData, fetchedBadgeData.Editdata, fetchedBadgeData.TrainingData, fetchedBadgeData.mode, props, setValue]);

  const finalResponse = (finalStatus) => {
    if (finalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus,
      });
      ModalOpen();
      return;
    } else {
      setModalValues(initialModalState)
      ModalOpen();
    }
  };

  async function fileValidation(e) {
    setValue("File", "Uploading");
    setfilePathChanged(true);
    let fileInput = e.target;
    let filePath = fileInput.value;
    let allowedExtensions = /(\.jpg|\.jpeg|\.png)$/i;
    if (!allowedExtensions.exec(filePath)) {
      setValue("File", "fileType", { shouldValidate: true });
      fileInput.value = "";
      setFile((temp) => {
        return ({ ...temp, TextName: "Select File", FilePath: "" })
      })
      setValue("File", "fileType", { shouldValidate: true });
      return false;
    } else if (e.target.files[0].size > process.env.ACTIVITY_THUMBNAIL_SIZE) {
      setValue("File", "FileSize", { shouldValidate: true });
    } else {
      setFile((temp) => {
        return ({ ...temp, TextName: document.getElementById("getFile") != null ? fileInput.files[0].name : "", FilePath: "" })
      })
      setValue("File", "exist", { shouldValidate: true });
      await uploadBadge(e);
    }
  }

  const uploadBadge = async (e) => {
    const filename = encodeURIComponent(e.target.files[0].name);
    const file = e.target.files[0];
    setFile((temp) => {
      return ({ ...temp, FileName: filename })
    })

    const csvReader = new FileReader();
    csvReader.onload = async function () {

      let fileUploadType;
      const arr = (new Uint8Array(csvReader.result)).subarray(0, 4);
      let header = '', temp = 0;
      let groupMenuName = (fetchedBadgeData.mode == "Edit") ? "ActivityManagement" : (trainingMode.current == "TrainingDirect") ? "TrainingManagement" : "CourseManagement"
      let menuId = (fetchedBadgeData.mode == "Edit") ? "500002" : (trainingMode.current == "TrainingDirect") ? "400104" : "300406"

      const headers = { method: "GET", headers: { authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, };

      let fetchURL = fetchedBadgeData.mode == "Edit" ?
        process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${e.target.files[0].name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ActivityType=${fetchedBadgeData.ActivityType}&Type=Badge` :
        (props?.mode == "TrainingDirect") ? process.env.APIGATEWAY_URL_UPLOAD_FILE_TRAINING + `?FileName=${e.target.files[0].name}&TenantId=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&Page=Badge&S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder + "/" + props.TenantInfo.TenantID}` :
          process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${e.target.files[0].name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&Type=Course&CourseType=Badge&ManagementType=CourseManagement`;
      let extension = document.getElementById("getFile").value.substring(document.getElementById("getFile").value.lastIndexOf(".") + 1).toLowerCase();

      const imageExtension = ["jpg", "jpeg", "png"];
      const contentType = imageExtension.indexOf(extension) >= 0 ? "image/" + extension : "application/" + extension;

      for (let i = 0; i < arr.length; i++) {
        header += arr[i].toString(16);
      }
      switch (header + '|' + contentType) {
        case '89504e47|image/png':
          fileUploadType = 'image/png';
          break;
        case 'ffd8ffe0|image/jpg':
        case 'ffd8ffe1|image/jpg':
        case 'ffd8ffe2|image/jpg':
          fileUploadType = 'image/jpg';
          break;
        case 'ffd8ffe0|image/jpeg':
        case 'ffd8ffe1|image/jpeg':
        case 'ffd8ffe2|image/jpeg':
          fileUploadType = 'image/jpeg';
          break;
        default:
          fileUploadType = 'unknown';

          if (fileUploadType != contentType) {
            setFile({
              ...file,
              TextName: "Select File",
              FilePath: "",
            });
            setValue("File", "filetypeChange", { shouldValidate: true });
          }
          return false;
          break;
      }
      if (temp == 1) {
        return false;
      }


      let presignedHeader = {
        method: "PUT", headers: {
          // "x-amz-acl": "public-read",
          "content-type": contentType, defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId,
        }, body: file,
      };

      let finalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);
      if (finalStatus[0] != "Success") {
        setValue("File", "");
        return;
      } else {
        setValue("File", "", { shouldValidate: true });
        setFile((temp) => {
          return ({ ...temp, FilePath: finalStatus[1] })
        })

      }
    };
    csvReader.readAsArrayBuffer(file);
  };

  // const dateCoversion = (date) => {
  //   let dateTime = new Date(date);
  //   let BindDate =
  //     dateTime.getFullYear() +
  //     "-" +
  //     (dateTime.getMonth() < 9 ? "0" : "") +
  //     (dateTime.getMonth() + 1) +
  //     "-" +
  //     dateTime.getDate();
  //   return BindDate;
  // };
  const submitHandler = async (data) => {
    document?.activeElement?.blur()
    setValue("submit", true);
    setValue("File", "", { shouldValidate: true });
    let pk = "TENANT#" + fetchedBadgeData.TenantID;
    let sk = fetchedBadgeData.mode == "CourseDirect" ? "COURSEBADGE#" + fetchedBadgeData.Coursedata.CourseID : (trainingMode.current == "TrainingDirect") ? "TRAININGBADGE#" + props?.trainerID : "ACTIVITYTYPE#" + fetchedBadgeData.ActivityType + "#ACTIVITYID#" + fetchedBadgeData.ActivityID;
    let query = props?.mode == "TrainingDirect" ? (fetchedBadgeData.TrainingData != null ? updateXlmsTrainingBadgeCertificate : createXlmsTrainingBadgeCertificate) : fetchedBadgeData.mode == "CourseDirect" ? (fetchedBadgeData.CourseEditData != null ? updateXlmsCourseManagementInfo : createXlmsCourseManagementInfo) : updateXlmsActivityManagementInfo;

    let fetchURL = fetchedBadgeData.mode == "Edit" ?
      process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${file.FileName}&ActivityID=${fetchedBadgeData?.ActivityID}&Type=Badge&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&ActivityType=${fetchedBadgeData.ActivityType}` :
      (props?.mode == "TrainingDirect") ? process.env.TRAINING_UNSAVED_TO_SAVED + `?FileName=${file.FileName}&TenantId=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&Page=Badge&S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder + "/" + props.TenantInfo.TenantID}&Id=${props?.trainerID}` :
        process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${file.FileName}&CourseID=${fetchedBadgeData.Coursedata.CourseID}&Type=Course&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&CourseType=Badge&ManagementType=CourseManagement`;
    let groupMenuName = (fetchedBadgeData.mode == "Edit") ? "ActivityManagement" : (props?.mode == "TrainingDirect") ? "TrainingManagement" : "CourseManagement"
    let menuId = (fetchedBadgeData.mode == "Edit") ? "500002" : (props?.mode == "TrainingDirect") ? "400104" : "300406"

    const headers = { method: "GET", headers: { authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, };
    let finalResult = filePathChanged && (await APIGatewayGetRequest(fetchURL, headers));
    let attachFilePath = await finalResult?.res?.text();

    if (filePathChanged && attachFilePath == null) {
      finalResponse("Some error occured while upload");
    }

    let activityVariables = {
      input: {
        PK: pk,
        SK: sk,
        BadgeName: data.txtBadgeName,
        BadgeDescription: data.txtBadgeDescription,
        IssuerName: data.txtIssuerName,
        IssuerEmailID: data.txtIssuerEmailID,
        ModifiedDate: new Date(),
        BadgeUploadFile: filePathChanged ? attachFilePath : file.FilePath,
        // BadgeValidityByDate:
        //   watch("rbValidity") == "ByDate" ? data.txtstdate : "",
        BadgeValidityByDays:
          watch("rbValidity") == "NumberOfDays" ? (data?.txtValidity ?? "") : "",
      },
    };

    let coursevariables = {
      input: {
        PK: pk,
        SK: sk,
        BadgeName: data.txtBadgeName,
        BadgeDescription: data.txtBadgeDescription,
        IssuerName: data.txtIssuerName,
        IssuerEmailID: data.txtIssuerEmailID,
        BadgeUploadFile: filePathChanged ? attachFilePath : file.FilePath,
        // BadgeValidityByDate: watch("rbValidity") == "ByDate" ? data.txtstdate : "",
        BadgeValidityByDays: watch("rbValidity") == "NumberOfDays" ? (data?.txtValidity ?? "") : "",
        CourseID: fetchedBadgeData.Coursedata.CourseID,
        CourseName: fetchedBadgeData.Coursedata.CourseName,
        LastModifiedDate: new Date()
      },
    };

    let trainingVariables = {
      input: {
        PK: pk,
        SK: sk,
        BadgeName: data.txtBadgeName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        BadgeDescription: data.txtBadgeDescription,
        IssuerName: data.txtIssuerName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        IssuerEmailID: data.txtIssuerEmailID,
        LastModifiedDate: new Date(),
        BadgeUploadFile: filePathChanged ? attachFilePath : file.FilePath,
        TrainingID: props?.trainerID,
        TrainingName: props?.trainerName,
        BadgeValidityByDays: watch("rbValidity") == "NumberOfDays" ? (data?.txtValidity ?? "") : "",
      },
    };
    let variables = fetchedBadgeData.mode == "CourseDirect" ? coursevariables : (trainingMode.current == "TrainingDirect") ? trainingVariables : activityVariables;
    let finalStatus = (await AppsyncDBconnection(query, variables, props.user?.signInUserSession?.accessToken?.jwtToken)).Status;
    finalResponse(finalStatus);
    setValue("submit", false);
  };
  let today = new Date();
  let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T" + today.getHours() + ":" + (today.getMinutes() > 9 ? today.getMinutes() : "0" + today.getMinutes());

  // Bread Crumbs
  const pageRoutes = [
    { path: fetchedBadgeData.mode == "Edit" ? "/ActivityManagement/ActivityList" : (props?.mode == "TrainingDirect") ? "/TrainingManagement/TrainingManagementList" : "/CourseManagement/CourseList", breadcrumb: fetchedBadgeData.mode == "Edit" ? "Activity Management" : (props?.mode == "TrainingDirect") ? "Training Management" : "Course Management" },
    { path: "", breadcrumb: "Add Badge" }
  ];
  const restAction = useCallback(() => {
    document?.activeElement?.blur()
  }, [])
  return (
    <>

      <Container PageRoutes={pageRoutes} loader={fetchedBadgeData.TenantID == undefined}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(submitHandler)}>
          <div className="nvl-FormContent !overflow-y-visible">
            <div className="">
              <div className="pt-1">
                <NVLTextbox id="txtBadgeName" labelText="Badge Name" labelClassName="font-bold text-gray-600 pb-2" type="text" title="Badge Name" pattern="^\S[ a-zA-Z\d@#$_.\-\s]*" errors={errors} register={register} className="nvl-mandatory nvl-Def-Input " />
              </div>
            </div>
            <div className="Center-Aligned-Items flex items-center">
              <div className=" pt-1 ">
                <NVLlabel text="Upload Badge" className="font-bold text-gray-600 pb-2 " HelpInfo={`${"Acceptable file format: jpg, png, jpeg.<br>File size should be 50KB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} >
                  <span className="text-red-500 text-xl">*</span>
                </NVLlabel>
                <NVLFileUpload text={file.TextName == null || file.TextName == "" ? "Select File" : file.TextName} className="nvl-mandatory nvl-Def-Input " errors={errors} register={register} onChange={(e) => fileValidation(e)}
                ></NVLFileUpload>
                <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                <div className="Center-Aligned-Items {invalid-feedback} text-red-500  text-sm">
                  {errors.File?.message}
                </div>
              </div>
            </div>
            <div className="Center-Aligned-Items pt-1">
              <NVLMultilineTxtbox
                id="txtBadgeDescription"
                labelText="Badge Description"
                labelClassName="font-bold text-gray-600 pb-2"
                title="Badge Description"
                errors={errors}
                register={register}
                className="nvl-non-mandatory nvl-Def-Input"
              />
            </div>
            <div className="Center-Aligned-Items">
              <NVLTextbox
                id="txtIssuerName"
                type="text"
                labelText="Issuer Name"
                labelClassName="font-bold text-gray-600 pb-2"
                title="Issuer Name"
                className="nvl-non-mandatory nvl-Def-Input"
                maxLength={"50"}
                errors={errors}
                register={register}
              />
            </div>
            <div className="Center-Aligned-Items">
              <NVLTextbox
                id="txtIssuerEmailID"
                labelText="Issuer Contact Email Id"
                labelClassName="font-bold text-gray-600 pb-2"
                title="Issuer Contact Email Id"
                className="nvl-non-mandatory nvl-Def-Input"
                maxLength={"50"}
                errors={errors}
                register={register}
                pattern={`^[a-z0-9]+\.+@[a-z]+\.[a-z]+\.[a-z]{2,3}`}
              />
            </div>
            {/* <div className="flex gap-8 font-bold text-gray-600">
              <NVLRadio id="rbValidity" text="Number Of Days" name="rbValidity" value={"NumberOfDays"} errors={errors} register={register}></NVLRadio>
            </div>
            <div className={`Center-Aligned-Items pt-4
                }`}
            > */}
            <NVLTextbox
              id="txtValidity"
              title="Number of days"
              className={"nvl-Def-Input nvl-non-mandatory"}
              errors={errors}
              register={register}
              labelClassName={"font-bold text-gray-600 pb-2"}
              labelText="Validity : Number of days"
            ></NVLTextbox>
            {/* </div> */}
            <div className="Center-Aligned-Item flex justify-center gap-3 pt-4">
              <div>
                <NVLButton
                  id="btnSubmit"
                  disabled={
                    watch("File") == "Uploading" || watch("submit")
                      ? true
                      : false
                  }
                  text={watch("File") == "Uploading" || watch("submit") ? "" : "Create"}
                  type="submit"
                  onClick={restAction}
                  className={`w-32 nvl-button bg-primary text-white  ${watch("File") == "Uploading" ? "nvl-button-light" : ""
                    }`}
                >
                  {watch("submit") && (
                    <i className="fa fa-circle-notch fa-spin mr-2"> </i>
                  )}
                </NVLButton>
              </div>
              <div>
                <NVLButton
                  id="btnCancel"
                  text={`Cancel`}
                  type="button"
                  className="nvl-button w-28"
                  onClick={() =>
                    fetchedBadgeData.mode == "Edit" ? router.push("/ActivityManagement/ActivityList") :
                      (fetchedBadgeData.mode == "TrainingDirect") ? router.push("/TrainingManagement/TrainingManagementList") :
                        router.push("/CourseManagement/CourseList")
                  }
                ></NVLButton>
              </div>
            </div>
          </div>
        </form>
      </Container>
    </>
  );
}

export default AddBadge;
