import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseManagementInfo, createXlmsTrainingBadgeCertificate, updateXlmsActivityManagementInfo, updateXlmsCourseManagementInfo, updateXlmsTrainingBadgeCertificate } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseManagementInfo, listXlmsCustomCertificate } from "src/graphql/queries";
import * as Yup from "yup";

function Certificate(props) {
  const router = useRouter();
  let mode = useMemo(() => { return decodeURIComponent(String(router.query["Mode"])) }, [router.query]);
  const [pageData, setPageData] = useState({ ...props });
  const [modalValues, setModalValues] = useState(() => {
    return {
      ModalInfo: "Success",
      ModalTopMessage: "Success",
      ModalBottomMessage: "Details have been saved successfully.",
      ModalOnClickEvent: () => {
        if (mode == "CourseDirect") {
          router.push("/CourseManagement/CourseList")
        } else if (pageData.mode == "TrainingDirect") {
          router.push("/TrainingManagement/TrainingManagementList");
        } else {
          router.push("/ActivityManagement/ActivityList");
        }
      },
    }
  });

  useEffect(() => {
    const fetchData = async (i) => {
      let tenantId = props?.user.attributes["custom:tenantid"];
      let tenantName = props?.user.attributes["name"];
      let activityId, ActivityType, CourseId;
      let mode = decodeURIComponent(String(router.query["Mode"]));
      if (mode == "Edit") {
        activityId = decodeURIComponent(String(router.query["ActivityID"]));
        ActivityType = decodeURIComponent(String(router.query["ActivityType"]));
      } else {
        CourseId = decodeURIComponent(String(router.query["CourseID"]));
      }

      const isUpdateData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + tenantId, SK: "ACTIVITYTYPE#" + ActivityType + "#ACTIVITYID#" + activityId }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const courseEdit = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSECERTIFICATE#" + CourseId }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEINFO#" + CourseId }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const certificateList = await AppsyncDBconnection(listXlmsCustomCertificate, { PK: "TENANT#" + tenantId, SK: "CUSTOMCERTIFICATE#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);

      const temp = {
        ActivityID: mode == "Edit" && activityId,
        ActivityType: mode == "Edit" && ActivityType,
        TenantName: tenantName,
        mode: mode,
        TenantID: tenantId,
        CourseCertificateEditData: mode == "CourseDirect" && courseEdit.res?.getXlmsCourseManagementInfo,
        CourseData: mode == "CourseDirect" && courseData.res?.getXlmsCourseManagementInfo,
        Editdata: isUpdateData?.res?.getXlmsActivityManagementInfo,
        CertificateData: certificateList?.res?.listXlmsCustomCertificate?.items
      }

      setPageData(temp);
    }
    if (props?.mode != "TrainingDirect") fetchData();
    return (() => {
      setPageData((temp) => { return { ...temp } });
    })
  }, [props?.mode, props?.user.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, router, router.query]);

  const validationSchema = Yup.object().shape({
    ddlCertificateTemplate: Yup.string().required("Certificate Template is required").nullable(),
    txtCertificateName: Yup.string().required("Certificate name is required ").matches(Regex("AlphaNumForTopicName"), "Enter Valid Ceritificate name").max(250, "Maximum length exceeded 250").nullable(),
    txtCertificateDescription: Yup.string().max(500, "Maximum length exceeded 500").nullable(),
    txtValidity: Yup.string()
      .test("len", "Numbers only allowed", (val, { createError }) => {
        let LimitedTime = 9999;
        if (!/^\d+$/.test(val) && val) {
          return createError({
            message: `Numbers only allowed.`,
          });
        }
        if (val == "") return true;
        if (val == "0") {
          return createError({
            message: `Days should be greater than zero.`,
          });
        }
        if (val?.length == "1") {
          return true;
        }

        else if (val > LimitedTime) {
          return createError({
            message: `Maximum only 4 digits.`,
          });
        }
        else if (parseInt(val) <= 0) {
          return createError({ message: `Days only positive values and more then zero` });
        }
        else {
          return true;
        }
      }).nullable(),
    // txtstdate: Yup.string()
    //   .nullable()
    //   .test("check", "Validaty Date should not be past date", (e) => {

    //     let NewDate = new Date(e);

    //     let current_date = new Date();
    //     let Curr = current_date.getFullYear() + "-" + (current_date.getMonth() + 1) + "-" + current_date.getDate();
    //     let New = NewDate.getFullYear() + "-" + (NewDate.getMonth() + 1) + "-" + NewDate.getDate();
    //     if (e && NewDate < new Date() && Curr != New) {
    //       return false;
    //     }
    //     return true;
    //   }),
  });

  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };

  const { register, handleSubmit, formState, setValue, watch } = useForm(formOptions);
  const { errors } = formState;

  useEffect(() => {
    if ((pageData.mode == "Edit" || pageData.mode == "CourseDirect") || (pageData.mode == "TrainingDirect" && pageData?.Editdata)) {
      let Editdata;
      if (pageData?.Editdata && pageData.mode == "TrainingDirect") Editdata = pageData?.Editdata;
      else Editdata = pageData.mode == "Edit" ? pageData.Editdata : pageData.CourseCertificateEditData;

      let tempArr = certificateTemplate();
      let certID = pageData?.Editdata && pageData.mode == "TrainingDirect" ? Editdata?.TemplateID : Editdata?.CertificateTemplate;
      let finalCert = tempArr.filter((e) => e?.value == certID)
      setValue("txtCertificateName", Editdata?.CertificateName);
      setValue("txtCertificateDescription", Editdata?.CertificateDescription);
      if (finalCert?.length != 0) {
        setValue("ddlCertificateTemplate", certID);
      }
      setValue("txtValidity", Editdata?.CertificateValidityByDays);
      setValue("txtstdate", Editdata?.CertificateValidityByDate);
      setValue("rbValidity", "NumberOfDays");
    }
  }, [certificateTemplate, certificateTemplate?.length, pageData, setValue]);

  const finalResponse = useCallback((FinalStatus) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
        ModalOnClickEvent: () => {
          if (mode == "CourseDirect") {
            router.push("/CourseManagement/CourseList")
          } else if (mode == "TrainingDirect") {
            router.push("/TrainingManagement/TrainingManagementList");
          } else {
            router.push("/ActivityManagement/ActivityList");
          }
        },
      });
      ModalOpen();
      return;
    } else {
      ModalOpen();
    }
  }, [mode, router])

  const validity = [
    { value: "", text: "Unlimited" },
    { value: "20", text: "20 days" },
    { value: "30", text: "30 days" },
    { value: "100", text: "100 days" },
  ];

  const certificateTemplate = useCallback(() => {
    let certificateList = [{ value: "", text: "Select Certificate" }];
    pageData?.CertificateData?.map((getItem) => {
      certificateList.push({ value: getItem.TemplateID, text: getItem.TemplateName })
    });
    return certificateList;
  }, [pageData.CertificateData])


  const submitHandler = async (data) => {
    document?.activeElement?.blur();
    setValue("submit", true);
    let coursemode = (pageData.CourseCertificateEditData != null || pageData.CourseCertificateEditData != undefined) ? "CertificateEdit" : "CertificateCreate"
    let pk = "TENANT#" + props.TenantInfo.TenantID;
    let query, sk;
    if (pageData.mode == "TrainingDirect") {
      sk = "TRAININGCERTIFICATE#" + pageData?.TraningId
      query = pageData?.Editdata ? updateXlmsTrainingBadgeCertificate : createXlmsTrainingBadgeCertificate;
    } else {
      sk = pageData.mode == "CourseDirect" ? "COURSECERTIFICATE#" + pageData.CourseData.CourseID : "ACTIVITYTYPE#" + pageData.ActivityType + "#ACTIVITYID#" + pageData.ActivityID;
      query = pageData.mode == "CourseDirect" ? (coursemode == "CertificateCreate" ? createXlmsCourseManagementInfo
        : updateXlmsCourseManagementInfo) : updateXlmsActivityManagementInfo;
    }

    let activityvariables, coursevariables, Trainingvariables;
    if (props?.mode != "TrainingDirect") {
      activityvariables = {
        input: {
          PK: pk,
          SK: sk,
          CertificateTemplate: data.ddlCertificateTemplate,
          CertificateDescription: data.txtCertificateDescription,
          CertificateName: data.txtCertificateName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          CertificateValidityByDate: watch("rbValidity") == "ByDate" ? data.txtstdate : "",
          CertificateValidityByDays: data?.txtValidity,
          ModifiedDate: new Date()
        },
      };
      coursevariables = {
        input: {
          PK: pk,
          SK: sk,
          CertificateTemplate: data.ddlCertificateTemplate,
          CertificateName: data.txtCertificateName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          CertificateDescription: data.txtCertificateDescription,
          CertificateValidityByDate: watch("rbValidity") == "ByDate" ? data.txtstdate : "",
          CertificateValidityByDays: data?.txtValidity,
          CourseID: pageData.CourseData.CourseID,
          CourseName: pageData.CourseData.CourseName,
          LastModifiedDate: new Date()

        },
      };
    } else {
      Trainingvariables = {
        input: {
          PK: pk,
          SK: sk,
          TemplateID: data.ddlCertificateTemplate,
          CertificateName: data.txtCertificateName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          CertificateDescription: data.txtCertificateDescription,
          CertificateValidityByDate: watch("rbValidity") == "ByDate" ? data?.txtstdate ? data.txtstdate : "" : "",
          CertificateValidityByDays: data?.txtValidity,
          TrainingID: pageData?.TraningId,
          TrainingName: pageData?.TrainingName,
          CreatedBy: props?.user?.username,
          CreatedDate: (pageData?.Editdata?.CreatedDate && pageData?.Editdata?.CreatedDate != "") ? pageData?.Editdata?.CreatedDate : new Date(),
          LastModifiedBy: props?.user?.username,
          LastModifiedDate: new Date()
        },
      };
    }
    let variables = pageData.mode == "CourseDirect" ? coursevariables : pageData.mode == "TrainingDirect" ? Trainingvariables : activityvariables;
    let finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;

    finalResponse(finalStatus);
    setValue("submit", false);
  };

  // Bread Crumbs
  const pageRoutes = useMemo(() => {
    if (pageData.mode == "TrainingDirect") {
      return [
        { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: "", breadcrumb: "Add Certificate" }
      ];
    } else {
      return [
        { path: pageData.mode == "Edit" ? "/ActivityManagement/ActivityList" : "/CourseManagement/CourseList", breadcrumb: pageData.mode == "Edit" ? "ActivityManagement" : "Course Management" },
        { path: "", breadcrumb: "Add Certificate" }
      ]
    }
  }, [pageData.mode])
  return (
    <>
      <Container PageRoutes={pageRoutes} loader={pageData?.TenantID == undefined}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues?.ModalTopMessage} MessageBottom={modalValues?.ModalBottomMessage} ModalOnClick={modalValues?.ModalOnClickEvent} ModalInfo={modalValues?.ModalInfo} />
        <form onSubmit={handleSubmit(submitHandler)}>
          <div className="nvl-FormContent !overflow-y-visible">
            <div>
              <div className="pt-1">
                <NVLlabel text="Certificate Template" className="font-bold text-gray-600"><span className="text-red-500 text-xl">*</span></NVLlabel>
                <NVLSelectField id="ddlCertificateTemplate" options={certificateTemplate()} errors={errors} className="nvl-mandatory nvl-Def-Input " register={register} />
                <NVLlabel text="Certificate Name" className="font-bold text-gray-600"><span className="text-red-500 text-xl">*</span></NVLlabel>
                <NVLTextbox id="txtCertificateName" type="text" title="Certificate Name" pattern="^\S[ a-zA-Z\d@#$_.\-\s]*" errors={errors} register={register} className="nvl-mandatory nvl-Def-Input " />
              </div>
            </div>
            <div >
              <NVLlabel text="Certificate Description" className="font-bold text-gray-600" />
              <NVLMultilineTxtbox id="txtCertificateDescription" title="Certificate Description" errors={errors} register={register} className="nvl-non-mandatory nvl-Def-Input" />
            </div>
            <NVLlabel text="Validity : Number Of Days" className="font-bold text-gray-600" />
            <div className="flex gap-8 font-bold text-gray-600">
              {/* <NVLRadio id="rbValidity" text="By Date" name="rbValidity" value={"ByDate"} errors={errors} register={register} defaultChecked></NVLRadio> */}
              {/* <NVLRadio id="rbValidity" text="Number Of Days" name="rbValidity" value={"NumberOfDays"} errors={errors} register={register}></NVLRadio> */}
            </div>
            <div className={`Center-Aligned-Items pt-4`}>
              {/* <NVLSelectField id="ddlValidity" disabled={watch("rbValidity") == "NumberOfDays" ? false : true} options={validity} errors={errors} register={register} className="nvl-non-mandatory nvl-Def-Input"></NVLSelectField> */}
              <NVLTextbox id="txtValidity" type="text" title="Number Of Days" errors={errors} register={register} className="nvl-non-mandatory nvl-Def-Input " />

            </div>
            <div className={`${watch("rbValidity") != "ByDate" ? "hidden" : "pt-4"}`}>
              <NVLTextbox
                id="txtstdate"
                type="date"
                errors={errors}
                register={register}
                disabled={watch("rbValidity") != "ByDate" ? true : false}
                className={"nvl-non-mandatory"}
              ></NVLTextbox>
            </div>
            <div className="Center-Aligned-Item flex justify-center gap-3 pt-4">
              <div>
                <NVLButton id="btnSubmit" disabled={watch("submit") ? true : false}
                  text={`${watch("submit") ? "" : "Create"}`}
                  type="submit" className={"w-28 nvl-button bg-primary text-white"}>
                  {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"> </i>}
                </NVLButton>
              </div>
              <div>
                <NVLButton id="btnCancel" text={"Cancel"} type="button" className="nvl-button w-28" onClick={() => pageData.mode == "Edit" ? router.push("/ActivityManagement/ActivityList") : pageData?.mode == "TrainingDirect" ? router.push("/TrainingManagement/TrainingManagementList") : router.push("/CourseManagement/CourseList")}></NVLButton>
              </div>
            </div>
          </div>
        </form>
      </Container>
    </>
  );
}

export default Certificate;