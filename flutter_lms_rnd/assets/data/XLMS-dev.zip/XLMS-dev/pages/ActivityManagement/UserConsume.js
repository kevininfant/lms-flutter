import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useRef, useState } from "react";
import { updateXlmsActivityManagementInfo } from "src/graphql/mutations";
import { listXlmsCourseDiscussionChat, listXlmsDiscussionChat } from "src/graphql/queries";

export default function UserConsume(props) {
    const router = useRouter();
    const routerRef = useRef();

    useMemo(() => {
        let temp = router.query?.parameters != undefined ? router.query?.parameters : "";
        var queryParam = router.query;
        routerRef.current = {
            ActivityID: decodeURIComponent(String(queryParam["ActivityID"])),
            CourseID: decodeURIComponent(String(queryParam["CourseID"])),
            ModuleID: decodeURIComponent(String(queryParam["ModuleID"])),
            TopicSub: decodeURIComponent(String(queryParam["TopicSub"])),
            ActivityName: decodeURIComponent(String(queryParam["ActivityName"]))

        }
    }, [router])

    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("")
    const headerColumn = [
        { HeaderName: "Topic Name", Columnvalue: "TopicName", HeaderCss: "w-3/12", },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
    ];
    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    }

    const refreshData = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };
    const refreshGrid = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    function resetPopUp() {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    }

    function popup(type, PK, SK, Content) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
    }
    async function updateField(e) {
        e.preventDefault();
        let isSus = false;
        let isDelete = false;
        if (popupValues.Type == "isSuspend") {
            isSus = true;
        } else if (popupValues.Type == "isDelete") {
            isDelete = true;
        }
        refreshData();
        let finalStatus = await AppsyncDBconnection(updateXlmsActivityManagementInfo, { input: { PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus, IsDeleted: isDelete } }, props.user.signInUserSession.accessToken.jwtToken)
        if (finalStatus.Status == "Success") {
            refreshData();
        }
        resetPopUp();
    }

    function GetDateFormat(CreatedDt) {
        return (new Date(CreatedDt).toDateString().substring(4))
    }

    const actionRestriction = useCallback((getItem) => {
        let actionList = [];
        actionList.push(
            {
                id: 4,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit Topic",
                action: () =>
                    (props.CourseID == "undefined") ? router.push(`/ActivityManagement/CreateTopic?Mode=Edit&ActivityID=${getItem.ActivityID}&TopicSub=${getItem.TopicID}&ActivityName=Discussion`) :
                        router.push(`/ActivityManagement/CreateTopic?&ActivityID=${getItem.ActivityID}&CourseID=${routerRef.current.CourseID}&ModuleID=${routerRef.current.ModuleID}&TopicSub=${getItem.TopicID}&ActivityName=${routerRef.current.ActivityName}`),
            }

        )

        return actionList;
    }, [props.CourseID, router])
    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData &&
            viewData.map((getItem, index) => {
                let actionList = [];
                actionList = actionRestriction(getItem)
                rowGrid.push({
                    PK: (
                        <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
                    ),
                    SK: (
                        <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
                    ),
                    ActivityId: (
                        <NVLlabel id={"lblActivityId" + (index + 1)} name="ActivityId" text={getItem.SK} />
                    ),
                    TopicName: (
                        <NVLlabel id={"txtActivityName" + (index + 1)} text={getItem.TopicName}></NVLlabel>
                    ),
                    Action: (
                        <NVLRapidModal
                            id={"RapidModal" + (index + 1)}
                            ActionList={actionList}
                        ></NVLRapidModal>
                    ),
                });
            });
        return rowGrid;
    }, [actionRestriction]);

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };
    const cancelEvent = (e) => {
        e.preventDefault();
        resetPopUp();
    };
    const query = useMemo(() => { return (routerRef.current?.CourseID != "undefined") ? listXlmsCourseDiscussionChat : listXlmsDiscussionChat }, []);
    const queryName = useMemo(() => { return (routerRef.current?.CourseID != "undefined") ? "listXlmsCourseDiscussionChat" : "listXlmsDiscussionChat" }, []);
    const variable = useMemo(() => {
        if (routerRef.current.CourseID == "undefined") {
            return { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITY#" + routerRef.current.ActivityID }
        }
        else {
            return { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEID#" + routerRef.current.CourseID + "#MODULE#" + routerRef.current.ModuleID + "#ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#" }
        }
    }, [props.TenantInfo.TenantID])
    let pageRoutes = [];
    if (routerRef.current.CourseID != "undefined") {
        pageRoutes = [
            { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management", },
            { path: `/CourseManagement/ModulesList?CourseID=${routerRef.current.CourseID}`, breadcrumb: "Manage Course" },
            { path: "", breadcrumb: "Topic List", },
        ];
    } else {
        pageRoutes = [
            { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
            { path: "", breadcrumb: `${routerRef.current?.ActivityName}` }
        ];
    }

    return (
        <>
            <Container title="Activity Management">
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} IsSearch={props.RoleData?.SeTenanthActivity ? true : false} ButtonID5="btnCreateTopic" LinkName5="+ Create Topic" className5={(props.TabRouting == true ? "" : "nvl-button-success")} RedirectHome={"/"}
                    RedirectAction5={(e) => headerHandler(e, routerRef.current.CourseID == "undefined" ?
                        (`/ActivityManagement/CreateTopic?Mode=Create&ActivityID=${routerRef.current.ActivityID}&ActivityName=${routerRef.current.ActivityName}`)
                        : (`/ActivityManagement/CreateTopic?Mode=Create&ActivityID=${routerRef.current.ActivityID}&CourseID=${routerRef.current.CourseID}&ModuleID=${routerRef.current.ModuleID}&CourseName=${routerRef.current.ActivityName}`))} placeholder={"Search by "} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshGrid} RedirectAction4={() => refreshGrid()} IsNestedHeader />
                <div className="max-w-full w-full justify-center">
                    <NVLGridTable
                        refershPage={isRefreshing}
                        user={props?.user}
                        id="tblActivityList"
                        HeaderColumn={headerColumn}
                        GridDataBind={gridDataBind}
                        query={query}
                        Search={search}
                        querryName={queryName}
                        variable={variable}
                    />

                </div>
                <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
            </Container>
        </>
    );
}
