import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { getXlmsTrainingManagementActivityInfo, listXlmsTrainingManagement, listXlmsTrainingTemplateNameExists } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsBatchTrainingManagement, createXlmsTrainingTemplateInfo, updateXlmsActivityManagementInfo, updateXlmsCourseModule, updateXlmsTrainingManagementActivityInfo, updateXlmsTrainingTemplateInfo } from "src/graphql/mutations";
import * as Yup from "yup";

function FeedBackTemplate(props) {
    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [fileValues, setFileValues] = useState({
        TextName: props?.pageData.mode == "Edit" ? props?.pageData.Editdata?.AttachFile && props?.pageData.Editdata?.AttachFile.substring(props?.pageData.Editdata?.AttachFile.lastIndexOf("/") + 1, props?.pageData.Editdata?.AttachFile?.length) : "Select File",
        FilePath: props?.pageData.mode == "Edit" ? props?.pageData.Editdata?.AttachFile : "Select File",
    });
    const trainingStart = useRef(false);
    const submitted = useRef(false)
    const validationSchema = Yup.object().shape({
        ddlTemplate: Yup.string(),
        File: Yup.string().when("importHandle", {
            is: true,
            then: Yup.string().test("file_Error", "File is required", (event, { createError }) => {
                if (event == undefined && props?.pageData.Editdata?.AttachFile == null) {
                    return createError({ message: "File is required" });
                }
                else if (event == "fileType") {
                    return createError({ message: "Json file only allowed" });
                }
                else if (event == "Error") {
                    return createError({
                        message: "Server Error Please Try Again",
                    });
                } else if (event == "fileChanged") {
                    return createError({ message: "File format seems to be changed!" });
                }
                return true;
            }),
            otherwise: Yup.string().nullable(true)
        }),
        txtAddQuestions: Yup.string().typeError("Template name is required").required("Template name is required").matches(Regex("AllowAlphaNumWithSpace"), "Invalid Template name ").max(50, "Maximum length exceed 50")
            .test("Template_name_errors", " Template Name already exists", async (event, { createError }) => {
                if (event != "") {
                    if (!watch("importHandle")) {
                        if (props.Question && Object.keys(props.Question)?.length == 0 && event != "" || props.Question == null) {
                            return createError({
                                message: "There are no questions to create a template",
                            });
                        }
                    }
                    if(props.pageData.TemplateData.length > 0) {
                        let exist = props.pageData.TemplateData.some((x)=>x.TemplateNameLowerCase == event.toLowerCase())
                        if (exist){
                            return false;
                        }
                    }
                    if (props?.pageData?.mode != "TrainingEdit" ) {
                        let trainingCurrentSk = "TRAININGQUESTIONNAIRETEMPLATE#";
                        let trainingVariables = {
                            PK: ("TENANT#" + props.TenantInfo.TenantID), SK: trainingCurrentSk, TemplateNameLowerCase: event.toLowerCase(),
                            TemplateType: "Feedback", IsDeleted: false
                        };
                       let finalResponseTraining = (await AppsyncDBconnection(listXlmsTrainingTemplateNameExists, trainingVariables, props?.user?.signInUserSession?.accessToken.jwtToken));
                        if(finalResponseTraining.Status == "Success") {
                            if(finalResponseTraining.res?.listXlmsTrainingTemplateNameExists.items.length > 0) {
                                return createError({ message: "Template name already exists in the training management" });
                               } 
                        }else {
                            return createError({ message: "Server Error", });
                           }
                    }
                }
                return true;
            }).min(4, "Minimum template length must be 4 characters").nullable(),
    });


    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true, };
    const { register, handleSubmit, reset, formState, setFocus, watch, setValue,clearErrors } = useForm(formOptions);
    const { errors } = formState;
     
    const [templateList, setTemplateList] = useState();
    const UploadData = useRef({});
    const CurrentTemplateQuestion = useRef();
    const UpdateQuestion = useMemo(() => {
        return props.UpdateQuestion;
    }, [props.UpdateQuestion])
    const menuTab = useMemo(() => {
        return props.menuTab;
    }, [props.menuTab])

    /*Questions Downlaod  */
    const exportHandler = (e) => {
        let templateName = document.getElementById("ddlTemplate").options[document.getElementById("ddlTemplate").selectedIndex].text;
        let element = document.createElement("a");
        element.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(JSON.stringify(CurrentTemplateQuestion.current?.[watch("ddlTemplate")])));
        element.setAttribute("download", `${templateName}.json`);
        element.style.display = "none";
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    };
    useEffect(() => {
        setValue('importHandle', false)
        if (props?.pageData?.TemplateData?.length > 0) {
            let temp = {};
            props.pageData.TemplateData.map((data) => {
                temp = { ...temp, [data.SK]: JSON.parse(data?.TemplateOption != undefined ? data.TemplateOption : {}) }
            })
            CurrentTemplateQuestion.current = temp;
        }
        else {
            CurrentTemplateQuestion.current = {};
        }
        setTemplateList(() => {
            return props.pageData.TemplateData;
        }, [])
    }, [props.TenantInfo.TenantID, props.pageData?.ActivityType, props.pageData.TemplateData, props.pageData.TrainingID, props.pageData?.mode, props.user.signInUserSession.accessToken.jwtToken, setValue])

    const saveTemplate = useCallback(async (props) => {
        let courseId = props?.pageData.CourseActivityID, moduleId = props?.pageData.ModuleId, pk = "TENANT#" + props.TenantInfo.TenantID, sk;

        if (props?.pageData?.CM_Mode == "ModuleEdit") {
            sk = "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + props?.pageData.ActivityType + "#ACTIVITYID#" + props?.pageData.ActivityID
        } else if (props?.pageData?.CM_Mode == "Edit" && (props.router.query["ZoomActivityID"] != undefined)) {

            sk = "ACTIVITYTYPE#" + props?.pageData.ActivityType + "#ZOOM#" + props.router.query["ZoomActivityID"] + "#" + props.router.query["ZoomMode"] + "#ACTIVITYID#" + props?.pageData.ActivityID
        } else if (props?.pageData?.CM_Mode == "TrainingEdit") {
            sk = props?.pageData?.Editdata?.SK;
        } else {
            sk = "ACTIVITYTYPE#" + props?.pageData.ActivityType + "#ACTIVITYID#" + props?.pageData.ActivityID;
        }
        let Question = { ...props.Question, ...CurrentTemplateQuestion.current?.[watch('ddlTemplate')] }

        UpdateQuestion(Question);
        let mergedQuestionVariables = { input: { PK: pk, SK: sk, QuestionandOptions: JSON.stringify(Question) }, },
            query = props?.pageData?.CM_Mode == "ModuleEdit" ? updateXlmsCourseModule : props?.pageData?.CM_Mode == "TrainingEdit" ? updateXlmsTrainingManagementActivityInfo : updateXlmsActivityManagementInfo;

        await AppsyncDBconnection(query, mergedQuestionVariables, props?.user.signInUserSession.accessToken.jwtToken);
        menuTab('divEdit')
    }, [UpdateQuestion, menuTab, watch])
    
    const deleteTemplate = useCallback(async (watch, finalResponse, setValue, TenantInfo, user) => {
        if (watch("ddlTemplate")?.length != 0 || templateList?.length > 0) {
            let finalResult, deletedData;
            if (watch("ddlTemplate").includes("TRAININGQUESTIONNAIRETEMPLATE")) {
                finalResult = await AppsyncDBconnection(updateXlmsTrainingTemplateInfo, { input: { PK: "TENANT#" + TenantInfo.TenantID, SK: watch("ddlTemplate"), IsDeleted: true }, }, user.signInUserSession.accessToken.jwtToken);
              if (popupValues.DataUpdate.length > 0) {  
                await AppsyncDBconnection(createXlmsBatchTrainingManagement, {input:popupValues.DataUpdate}, user.signInUserSession.accessToken.jwtToken)
                const getActivityData = await AppsyncDBconnection(getXlmsTrainingManagementActivityInfo, { PK: "TENANT#" + TenantInfo.TenantID, SK: "TRAINING#" + props?.pageData?.Editdata?.TrainingID + "#ACTIVITYTYPE#" + props?.pageData?.Editdata?.ActivityType + "#ACTIVITYID#" + props?.pageData?.Editdata?.ActivityID }, props?.user.signInUserSession.accessToken.jwtToken);
                await AppsyncDBconnection(updateXlmsTrainingManagementActivityInfo,
                  {
                    input: {
                      ...getActivityData?.res?.getXlmsTrainingManagementActivityInfo,
                      IsDeleted: true,
                    }
                  },
                  props?.user.signInUserSession.accessToken.jwtToken);}
            } else {
                    finalResult = await AppsyncDBconnection(props.query[3], { input: { PK: "TENANT#" + TenantInfo.TenantID, SK: watch("ddlTemplate"), }, }, user.signInUserSession.accessToken.jwtToken);
            }
            delete CurrentTemplateQuestion.current?.[watch("ddlTemplate")];
            props?.setPageData((e)=>{
                return {...e,TemplateData: templateList.filter((object) => {
                    return object.SK != watch("ddlTemplate");
                })}
            })
            if (props?.pageData?.mode == "TrainingEdit") {
            finalResponse(finalResult.Status,true);
            } else {
                finalResponse(finalResult.Status);
            }
            setValue("ddlTemplate", "");
            setPopupValues({ Content: "", DataUpdate: "" })
        }
    }, [templateList, props, popupValues.DataUpdate]);

    const importHandler = (e) => {
            setValue('importHandle', !watch("importHandle"))
                setFileValues((fileValues) => { return { ...fileValues, TextName: "Select File", FilePath: "" } });
                setValue("File","",{shouldValidate:true})
                clearErrors(["File"])
                setValue("content-target", "");
    };
    const templateBinding = useCallback((type, templateList) => {
        const courseTemplate = [{ value: "", text: "Choose" }];
        const publicTemplate = [{ value: "", text: "Choose" }];
        if (templateList && templateList?.length > 0) {
            templateList.map((getItem) => {
                if (!getItem.IsPublic) {
                    courseTemplate.push({ value: getItem.SK, text: getItem.TemplateName, });
                } else {
                    publicTemplate.push({ value: getItem.SK, text: getItem.TemplateName, });
                }
            });
        }
        if (type == "Public") {
            return publicTemplate;
        }
        return courseTemplate;
    }, []);
    function createOptions(options) {
        let opts = [];
        options &&
            options.map((opt) => {
                opts.push(
                    <option key={opt.value} value={opt.value}>
                        {opt.text}
                    </option>
                );
            });
        return opts;
    }
    const submitHandler = async (data, Question) => {
        if(props?.pageData?.ActivityType == "Survey"){
            submitted.current = true;
        }
        setValue("submitLoading", true)
        document.activeElement?.blur();
        if (props?.pageData?.mode == "TrainingEdit") {
            let templateInfo = {}, tempTemplate = {}, temData = {}, tempnames = {}, templateID = Math.random().toString(25).substring(2, 12);
            if (props?.pageData?.ActivityType == "Feedback") tempnames = { TrainingFeedbackTemplateName: data?.txtAddQuestions, TrainingFeedbackTemplateID: templateID }
            else tempnames = { TrainingSurveyTemplateName: data?.txtAddQuestions, TrainingSurveyTemplateID: templateID }
            let Variables = {
                input: {
                    ...tempnames,
                    PK: "TENANT#" + props?.TenantInfo?.TenantID,
                    SK: "TRAININGQUESTIONNAIRETEMPLATE#" + templateID,
                    TemplateNameLowerCase: data?.txtAddQuestions.toLowerCase(),
                    TemplateOption: JSON.stringify(Question),
                    TrainingName: props?.pageData?.Editdata?.TrainingName,
                    TrainingID: props?.pageData?.TrainingID,
                    TenantID: props?.TenantInfo?.TenantID,
                    TemplateType: props?.pageData?.ActivityType,
                    IsDeleted: false,
                    IsSuspend: false,
                    IsPublic: data?.chkPublic ? data?.chkPublic : false
                }
            }

            let FinalStatus = (await AppsyncDBconnection(createXlmsTrainingTemplateInfo, Variables, props?.user?.signInUserSession?.accessToken?.jwtToken));
            if (JSON.parse(props?.pageData?.TrainingData?.QuestionandOptions)) {
                temData = JSON.parse(props?.pageData?.TrainingData?.QuestionandOptions)
            }

            if (props?.pageData?.ActivityType == "Survey") {
                tempTemplate = {
                    ...temData,
                    Survey: {
                        TemplateID: templateID,
                        ActivityID: props?.pageData?.ActivityID,
                        ActivityType: props?.pageData?.ActivityType,
                        TrainingID: props?.pageData?.TrainingID,
                        TemplateName: data?.txtAddQuestions,
                        Template: Question,
                        ActivityName: "Effectiveness Survey",
                        IsSuspend: false
                    }
                }
                templateInfo = { QuestionandOptions: JSON.stringify(tempTemplate), TrainingSurveyTemplateID: templateID, TrainingSurveyTemplateName: data?.txtAddQuestions, }
            } else {
                tempTemplate = {
                    ...temData,
                    Feedback: {
                        TemplateID: templateID,
                        ActivityID: props?.pageData?.ActivityID,
                        ActivityType: props?.pageData?.ActivityType,
                        TrainingID: props?.pageData?.TrainingID,
                        TemplateName: data?.txtAddQuestions,
                        Template: Question,
                        ActivityName: "Feedback",
                        IsSuspend: false,
                    }
                }
                templateInfo = { QuestionandOptions: JSON.stringify(tempTemplate), TrainingFeedbackTemplateID: templateID, TrainingFeedbackTemplateName: data?.txtAddQuestions, }
            }

            const updateVariables = {
                input: [
                    { ...props?.pageData?.TrainingData, ...templateInfo },
                    {
                        ...props?.pageData?.TrainingData, ...templateInfo,
                        SK: "TRAININGINFO#LASTMODIFIEDDATE#" + props?.pageData?.TrainingData?.LastModifiedDate + "#TRAININGID#" + props?.pageData?.TrainingID,
                    }]
            }
            await AppsyncDBconnection(createXlmsBatchTrainingManagement, updateVariables, props?.user.signInUserSession.accessToken.jwtToken)

            if (props?.pageData?.ActivityType == "Survey") {
                props.finalResponse(FinalStatus?.Status, true)
            } else {
                props.finalResponse(FinalStatus?.Status)
                let currentSk="TRAININGQUESTIONNAIRETEMPLATE#";
                 let questionTemplate = "TRAININGINFO#LASTMODIFIEDDATE#";
                CurrentTemplateQuestion.current = { ...CurrentTemplateQuestion.current, [questionTemplate + templateID]: Question };
                props?.setPageData((e)=>{
                    return {...e,TemplateData:[...e?.TemplateData, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: currentSk + templateID, ActivityType: props?.pageData.ActivityType, TenantID: props.TenantInfo.TenantID, TemplateOption: JSON.stringify(Question), TemplateName: data?.txtAddQuestions, TemplateNameLowerCase: data?.txtAddQuestions.toLowerCase(), IsPublic: data?.chkPublic, }]}
                })
                reset();
            }

        } else {
            let mode = props.pageData.CM_Mode;
            let courseId = props.pageData.CourseActivityID;
            let moduleId = props.pageData.ModuleId;
            let pk = "TENANT#" + props.TenantInfo.TenantID;
            let sk;

            if (mode == "ModuleEdit") {
                sk = "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + props?.pageData.ActivityType + "#ACTIVITYID#" + props?.pageData.ActivityID
            } else if (mode == "Edit" && (props.router.query["ZoomActivityID"] != undefined)) {
                sk = "ACTIVITYTYPE#" + props?.pageData.ActivityType + "#ZOOM#" + props.router.query["ZoomActivityID"] + "#" + props.router.query["ZoomMode"] + "#ACTIVITYID#" + props?.pageData.ActivityID
            } else {
                sk = "ACTIVITYTYPE#" + props?.pageData.ActivityType + "#ACTIVITYID#" + props?.pageData.ActivityID;
            }
            let templateID = Math.random().toString(25).substring(2, 12);

            let questionTemplate = mode == "ModuleEdit" ? "COURSEQUESTIONNAIRETEMPLATE#" : "QUESTIONNAIRETEMPLATE#";

            let templateVariables = {
                input: {
                    PK: pk, SK: questionTemplate + templateID,
                    ActivityType: props?.pageData.ActivityType,
                    TenantID: props.TenantInfo.TenantID,
                    TemplateOption: JSON.stringify(Question),
                    TemplateName: data?.txtAddQuestions,
                    TemplateNameLowerCase: data?.txtAddQuestions.toLowerCase(),
                    IsPublic: data?.chkPublic,
                },
            };
            let finalStatus = (await AppsyncDBconnection(props.query[0], templateVariables, props?.user.signInUserSession.accessToken.jwtToken)).Status;
            props.finalResponse(finalStatus);
            if (finalStatus == "Success") {
                let questionTemplate = mode == "ModuleEdit" ? "COURSEQUESTIONNAIRETEMPLATE#" : "QUESTIONNAIRETEMPLATE#";
                CurrentTemplateQuestion.current = { ...CurrentTemplateQuestion.current, [questionTemplate + templateID]: Question };
                props?.setPageData((e)=>{
                    return {...e,TemplateData:[...e?.TemplateData, { PK: pk, SK: questionTemplate + templateID, ActivityType: props?.pageData.ActivityType, TenantID: props.TenantInfo.TenantID, TemplateOption: JSON.stringify(Question), TemplateName: data?.txtAddQuestions, TemplateNameLowerCase: data?.txtAddQuestions.toLowerCase(), IsPublic: data?.chkPublic, }]}
                })
            }
            reset();
            setValue("chkPublic", false);
        }
        setValue("submitLoading", false)
    };
    function readFileContent(file) {
        const reader = new FileReader();
        return new Promise((resolve, reject) => {
            reader.onload = (event) => resolve(event.target.result);
            reader.onerror = (error) => reject(error);
            reader.readAsText(file);
        });
    }

    const fileValidation = useCallback(async (e) => {

        let fileInput = e.target;
        let filepath = e.target.files[0];

        if (watch("txtAddQuestions") == "") {
            e.target.value = null
            return setValue("txtAddQuestions", "", { shouldValidate: true });
        }
        if (filepath == undefined) {
            if (fileValues?.FilePath != undefined || fileValues?.FilePath != "") {
                setValue("File", true, { shouldValidate: true });
            }
            else {
                setValue("File", undefined, { shouldValidate: true });
            }
            return true;
        }
        setValue("File", "fileType", { shouldValidate: true });
        setValue("content-target", "");
        setValue("File", "Uploading");

        let filePath = fileInput.value;
        let allowedExtensions = /(\.json)$/i;
        if (!allowedExtensions.exec(filePath) || fileInput == null) {
            setValue("File", "fileType", { shouldValidate: true });
            e.target.value = null;
            fileInput.value = "";
            setFileValues((fileValues) => { return { ...fileValues, TextName: "Select File", FilePath: "" } });
            return false;
        } else {
            const input = e.target;
            if ("files" in input && input.files.length > 0) {
                placeFileContent(input.files[0]);
                setValue("File", "true", { shouldValidate: true });
            }
        }
    }, [watch, setValue, fileValues?.FilePath, placeFileContent]);

    const placeFileContent = useCallback((file) => {
        if (watch("txtAddQuestions") == "")
            return setValue("txtAddQuestions", "", { shouldValidate: true });
        readFileContent(file)
            .then(async (content) => {
                let newContent = JSON.parse(content)
                if (typeof newContent != "object") {
                    setValue("File", "fileChanged", { shouldValidate: true });
                    setFileValues((fileValues) => { return { ...fileValues, TextName: "Select File", FilePath: "" } });
                    return false;
                }
                setValue("content-target", content);
                setFileValues((fileValues) => { return { ...fileValues, TextName: file.name } });
                let mode = props.pageData.CM_Mode
                let templateId = Math.random().toString(25).substring(2, 12);
                let uploadTemplateData = {};

                if (props?.pageData?.mode == "TrainingEdit") {
                    let tempnames = {};
                    if (props?.pageData?.ActivityType == "Feedback")
                        tempnames = { TrainingFeedbackTemplateName: watch("txtAddQuestions"), TrainingFeedbackTemplateID: templateId }
                    else tempnames = { TrainingSurveyTemplateName: watch("txtAddQuestions"), TrainingSurveyTemplateID: templateId }

                    uploadTemplateData = {
                        input: {
                            ...tempnames,
                            PK: "TENANT#" + props?.TenantInfo?.TenantID,
                            SK: "TRAININGQUESTIONNAIRETEMPLATE#" + templateId,
                            TemplateNameLowerCase: watch("txtAddQuestions")?.toLowerCase(),
                            TemplateOption: content,
                            TrainingName: watch("txtAddQuestions"),
                            TrainingID: props?.pageData?.TrainingID,
                            TenantID: props?.TenantInfo?.TenantID,
                            TemplateType: props?.pageData?.ActivityType,
                            IsDeleted: false,
                            IsSuspend: false,
                            IsPublic: document.getElementById("chkPublic").checked,
                        }
                    }
                } else {
                    uploadTemplateData = {
                        input: {
                            PK: "TENANT#" + props.TenantInfo.TenantID,
                            SK: mode == "ModuleEdit" ? "COURSEQUESTIONNAIRETEMPLATE#" + templateId : "QUESTIONNAIRETEMPLATE#" + templateId,
                            TemplateOption: content,
                            TemplateName: watch("txtAddQuestions"),
                            TemplateNameLowerCase: watch("txtAddQuestions")?.toLowerCase(),
                            IsPublic: document.getElementById("chkPublic").checked,
                            TenantID: props.TenantInfo.TenantID,
                        },
                    };
                }

                UploadData.current = uploadTemplateData;
            })
            .catch((error) => { console.log("Failed to fetch", error); 
            setValue("File", "fileChanged", { shouldValidate: true });
            setFileValues((fileValues) => { return { ...fileValues, TextName: "Select File", FilePath: "" } });
         });
    }, [props.TenantInfo.TenantID, props.pageData?.ActivityType, props.pageData.CM_Mode, props.pageData?.TrainingID, props.pageData?.mode, setValue, watch]);
    const uploadJsonFileHandler = async () => {
       if ( fileValues?.TextName == "Select File") {
        setValue("File", undefined , { shouldValidate: true });
        return true
       }
        if (Object.keys(UploadData.current).length > 0) {
            if (UploadData.current != null && Object.keys(UploadData.current).length > 0) {
                let finalStatus = (await AppsyncDBconnection(props?.pageData?.mode == "TrainingEdit" ? createXlmsTrainingTemplateInfo : props.query[0], UploadData.current, props?.user.signInUserSession.accessToken.jwtToken)).Status;
                props.finalResponse(finalStatus);
                CurrentTemplateQuestion.current = { ...CurrentTemplateQuestion.current, [UploadData.current.input.SK]: JSON.parse(UploadData.current.input.TemplateOption) };
                let tempUpdate = {};
                if (props?.pageData?.mode == "TrainingEdit") {
                    tempUpdate = {
                        ActivityType: UploadData?.current?.input?.TemplateType,
                        IsPublic: UploadData?.current?.input?.IsPublic,
                        PK: UploadData?.current?.input?.PK,
                        SK: UploadData?.current?.input?.SK,
                        Status: UploadData?.current?.input?.Status,
                        TemplateName: UploadData?.current?.input?.TemplateType == "Feedback" ? UploadData?.current?.input?.TrainingFeedbackTemplateName : UploadData?.current?.input?.TrainingSurveyTemplateName,
                        TemplateNameLowerCase: UploadData?.current?.input?.TemplateNameLowerCase,
                        TemplateOption: UploadData?.current?.input?.TemplateOption,
                        TenantID: UploadData?.current?.input?.TenantID,
                    }
                } else {
                    tempUpdate = UploadData.current.input
                }
                props?.setPageData((e)=>{
                    return {...e,TemplateData:[...e?.TemplateData, { ...tempUpdate }]}
                })
            }

            UploadData.current = {};
            setValue("txtAddQuestions", "");
            setValue("chkPublic", false);
            setValue("importHandle", false);
            setValue("content-target", "");

            setFileValues(() => {
                return { TextName: "Select File" , FilePath:""}
            })
        }
        else {
            setValue("File", undefined, { shouldValidate: true })
        }

    };
    const getOptionData = useCallback((Options) => {
        let optionsData = [];
        for (let i = 0; i < Options?.length; i++) {
            optionsData?.push({ value: Options[i], text: Options[i] });
        }
        return optionsData;
    }, []);

    const cancelEvent = (e) => {
        e.preventDefault()
        setPopupValues({ Content: "", DataUpdate: "" })
    }
    
    const deleteConfirmation = useCallback(async() => {
        const filteredTraining = [],updateTraining = []
        const trainingList = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGINFO#LASTMODIFIEDDATE#", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
        const ListDetails =  trainingList.res?.listXlmsTrainingManagement?.items ? trainingList.res?.listXlmsTrainingManagement?.items : []
        filteredTraining = props?.pageData?.Editdata?.ActivityType == "Survey" ? ListDetails && ListDetails.filter((data)=> data.TrainingSurveyTemplateID == watch("ddlTemplate").split("#").pop())
                            : ListDetails && ListDetails.filter((data)=>{ return data.TrainingFeedbackTemplateID == watch("ddlTemplate").split("#").pop()})
       const UpComingTrainingList =  filteredTraining && filteredTraining.filter((data)=> {return new Date(data.StartDate) > new Date()})    
       const StartedTraining =  filteredTraining && filteredTraining.filter((data)=> {return new Date(data.StartDate) < new Date()})
                let findActy = props?.pageData?.Editdata?.ActivityType
                UpComingTrainingList && UpComingTrainingList.map((data)=>{
                    let getTempData = (JSON.parse(data.QuestionandOptions))
                    delete getTempData?.[findActy]
                    updateTraining = findActy == "Survey" ? [...updateTraining,{...data, 
                        QuestionandOptions: JSON.stringify(getTempData), 
                        TrainingSurveyTemplateID: null, TrainingSurveyTemplateName: null, SurveyActionEnable:"No", TimeLimit:0},
                    {...data,SK:"TRAININGINFO#"+ data.TrainingID , QuestionandOptions: JSON.stringify(getTempData), TrainingSurveyTemplateID: null, TrainingSurveyTemplateName: null, SurveyActionEnable:"No", TimeLimit:0 }]  
                    :  [...updateTraining,{...data, QuestionandOptions: JSON.stringify(getTempData), TrainingFeedbackTemplateID: null, TrainingFeedbackTemplateName: null,FeedbackActionEnable:"No",},
                    {...data,SK:"TRAININGINFO#"+ data.TrainingID , QuestionandOptions: JSON.stringify(getTempData), TrainingFeedbackTemplateID: null, TrainingFeedbackTemplateName: null,FeedbackActionEnable:"No"}] 
                })
                trainingStart.current = StartedTraining.length > 0 ? true : false;
     setPopupValues({ Content: StartedTraining.length > 0 ? `Template has been mapped to ${filteredTraining.length} training program(s). ${StartedTraining.length} training programs(s) has been started. Template cannot be deleted.` : ( UpComingTrainingList.length > 0 ? `Template has been mapped to ${filteredTraining.length} training program(s). Are you sure to delete the template?` : "Are you sure to delete the template?"),
      DataUpdate: StartedTraining.length > 0 ? "" : ( UpComingTrainingList.length > 0 ?  updateTraining : "")  })
    },[props.TenantInfo.TenantID, props?.pageData?.Editdata?.ActivityType, props?.user.signInUserSession.accessToken.jwtToken, watch])

    return (<>
        <NVLModalPopup ButtonYestext={!trainingStart.current ? "Yes":"OK"} IsConfirmAlert={!trainingStart.current ? undefined : trainingStart.current} SubmitClick={(e) => !trainingStart.current ? deleteTemplate(watch, props.finalResponse, setValue, props.TenantInfo, props.user) : cancelEvent(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext= {"No"} CloseIconEvent={() => cancelEvent(e)} Content={popupValues?.Content} />
        {props.pageData?.mode == "TrainingEdit" && <>
            <div className="flex flex-col sm:flex-row  gap-4">
                <NVLlabel className="nvl-Def-Label !p-4 !w-40" id="lblActivityType" text={`Activity Type :`}></NVLlabel>
                <div>
                    <NVLlabel className="nvl-Def-Label !p-4" id="lblActivityType" text={`${props?.pageData?.ActivityType}`}></NVLlabel>
                </div>
            </div>
        </>}
        <form id="divTemplate" onSubmit={handleSubmit((data) => submitHandler(data, props.Question))} className={watch("submitLoading") ? "pointer-events-none" : ""}>
            {(props.pageData?.mode == "TrainingEdit" && props.pageData?.ActivityType == "Survey") ? <>
                <div className="space-y-5">
                    <div className="grid px-40 pt-2 ml-8">
                        <div>
                            <NVLTextbox id="txtAddQuestions" className="nvl-Def-Input" type="text" title="Add Question Template" errors={errors} register={register}></NVLTextbox>
                        </div>
                        <div className="flex gap-4 ">
                            <NVLButton text={`${watch("submitLoading") ? "" : "Save"}`} ButtonType="success" className={`${watch("submitLoading") ? "Disabled" : ""}  nvl-button w-28 `} >{watch("submitLoading") && <i className="fa fa-circle-notch fa-spin mr-2"></i>} </NVLButton>
                            <NVLButton text="Cancel" onClick={(() => router.push(`/TrainingManagement/TrainingManagementList`))} className={`${watch("submitLoading") ? "Disabled nvl-button-light" : ""} nvl-button w-28 `} />
                        </div>
                    </div>
                    <div className="flex flex-col sm:flex-row  gap-4">
                        <NVLlabel text="Template Name :" className="nvl-Def-Label w-44"></NVLlabel>
                        <div>
                            <NVLSelectField id="ddlTemplate" options={templateList && templateBinding("", templateList)} className={`nvl-mandatory nvl-Def-Input `} errors={errors} register={register} />
                            <NVLButton className={`${watch("ddlTemplate") == "" ? "hidden" : ""} float-right`} id="btnAddItem" type="button" ButtonType={"link"} text="- Delete" onClick={() => deleteConfirmation() } />
                        </div>
                    </div>
                </div>
            </> : <>
                <div className="pt-2 px-40 flex">
                    <div>
                        <NVLTextbox id="txtAddQuestions" className="nvl-Def-Input" type="text" title="Add Question Template" errors={errors} register={register}></NVLTextbox>
                    </div>
                    <div className="pt-2 pl-2">
                        <NVLCheckbox id="chkPublic" type="checkbox" text="Public" errors={errors} register={register} />
                    </div>
                </div>
                {!false && (
                    <div className="px-40 pt-4">
                        <NVLButton text={`${watch("submitLoading") ? "" : "Save as new Template"}`} ButtonType="success" className={`${watch("submitLoading") || submitted.current == true ? "Disabled w-44" : ""}  px-40 nvl-button bg-primary w-44 text-white`}>{watch("submitLoading") && <i className="fa fa-circle-notch fa-spin mr-2"></i>} </NVLButton>
                    </div>
                )}
                <div className="flex gap-3 pt-4">
                    <div>
                        <NVLlabel text="Use a Template" className="px-6 font-medium text-sky-600"></NVLlabel>
                    </div>
                    <div className="pl-2">
                        <select id="ddlTemplate" className="nvl-SelectField w-96"  {...register("ddlTemplate", { shouldValidate: true })}>
                            <optgroup label="Course">
                                {createOptions(templateBinding("", templateList))}
                            </optgroup>
                            <optgroup label="Public">
                                {createOptions(templateBinding("Public", templateList))}
                            </optgroup>
                        </select>
                    </div>
                </div>
                <div className={`gap-2 pt-4 pl-40  ${watch("ddlTemplate")?.length == 0 ? "hidden" : ""}`}>
                    <div className="flex">
                        <NVLRadio id="rbTemplateAction" name={"rbTemplateAction"} value={"Delete"} register={register} errors={errors}></NVLRadio>
                        <NVLlabel text="Delete old items" className="font-medium text-sky-600"></NVLlabel>
                    </div>
                    <div className="flex pt-2">
                        <NVLRadio id="rbTemplateAction" value={"Append"} name={"rbTemplateAction"} register={register} errors={errors}></NVLRadio>
                        <NVLlabel text="Append new items" className="font-medium text-sky-600"></NVLlabel>
                    </div>
                    <div className={`flex flex-row gap-1 nvl-Def-Input mt-4`}>
                        <NVLButton id="btnSubmit" text={"Save"} type="button" className={submitted.current == true ? "Disabled w-32 nvl-button bg-primary text-white ":"w-32 nvl-button bg-primary text-white "} onClick={() => saveTemplate(props)}></NVLButton>
                        <NVLButton id="btnCancel" text={"Cancel"} type="button" className="nvl-button w-28" onClick={() => setValue("ddlTemplate", "")}></NVLButton>
                    </div>
                </div>
                {(props.pageData?.EditData?.ActivityType != "Survey") && <div className="pl-2">
                    <NVLButton id="btnDeleteTemplate" className={`nvl-button-link ${watch("ddlTemplate")?.length == 0 ? "hidden" : ""}`} text="Delete Template" type={"button"} onClick={() => props.pageData?.mode != "TrainingEdit"  ? deleteTemplate(watch, props.finalResponse, setValue, props.TenantInfo, props.user) : deleteConfirmation() } />
                </div>}
                <div className="pl-2">
                    <NVLButton id="btnExport" className={`nvl-button-link ${watch("ddlTemplate")?.length == 0 ? "hidden" : ""}`} type={"button"} text="Export questions" onClick={(e) => exportHandler(e)} />
                    <NVLButton id="btnImport" ButtonType="link" type={"button"} text="Import questions" onClick={() => importHandler()} />
                </div>
                <div id="divUpload" className={`${watch('importHandle') ? "" : "hidden"} pl-6`}>
                    <div className="flex">
                        <NVLlabel text="Upload JSON File" className="nvl-Def-Label" />
                        <NVLlabel className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: .json <br>File size should be 50KB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                    </div>
                    <NVLFileUpload id="getFile" text={fileValues?.TextName == null ? "Select File" : fileValues.TextName?.length > 20 ? fileValues.TextName?.substring(0, 20) + "..." : fileValues.TextName} onChange={(e) => fileValidation(e)}></NVLFileUpload>
                    <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                    <div className={" {invalid-feedback} text-red-500 text-sm "}>
                        {errors?.File?.message}
                    </div>
                    <NVLButton id="btnUpload" type={"button"} ButtonType="primary" text="Upload" onClick={handleSubmit(uploadJsonFileHandler)} />
                    <NVLMultilineTxtbox id="content-target" disabled className="nvl-Def-Input bg-gray-200 resize-y" register={register} title="Uploaded json data will be displayed here"></NVLMultilineTxtbox>
                </div>

            </>}
        </form>
        <div className={`${watch("ddlTemplate")?.length != 0 ? "" : "hidden"}`}>
            <div>
                <div className="list-container">
                    {Array.from(props.sortusingpostion(CurrentTemplateQuestion.current?.[watch("ddlTemplate")])).map((item, index) => {
                        return (
                            <>
                                {Object.keys(CurrentTemplateQuestion.current?.[watch("ddlTemplate")]) != "undefined" && (
                                    <div key={index} className="list-item">
                                        <div className="p-2 w-full">
                                            <div className="pt-2 grid gap-4">
                                                <div className="w-full break-all flex gap-4">
                                                    {item?.Question != undefined && (
                                                        <NVLlabel showFull text={index + 1 + "  " + item.Label + " " + item?.Question?.replace(/(<([^>]+)>)/gi, "")} />
                                                    )}
                                                </div>
                                                <div className="flex gap-4">
                                                    <div className={`${item?.Adjustment == "Horizontal" ? "flex gap-4" : ""} `} key={index}>
                                                        {item?.OptionType == "Multiple Answer" ? (
                                                            item?.Options.map((item, index) => {
                                                                return (
                                                                    <>
                                                                        <div className="gap-3">
                                                                            <NVLCheckbox id={"chkoption" + index} text={item} value={"Multiple Answer"} errors={props.errors} register={register}></NVLCheckbox>
                                                                        </div>
                                                                    </>
                                                                );
                                                            })
                                                        ) : item?.OptionType == "Single Answer" ? (
                                                            item?.Options.map((radioItem, index) => {
                                                                return (
                                                                    <>
                                                                        <div className="gap-3" key={index}>
                                                                            <NVLRadio id={"rboption" + index} text={radioItem} name={"rbOptions" + item?.Question} value={item} errors={props.errors} register={register}></NVLRadio>
                                                                        </div>
                                                                    </>
                                                                );
                                                            })
                                                        ) : item?.OptionType == "Dropdown" ? (
                                                            <>
                                                                <div className="gap-3" key={index}>
                                                                    <NVLSelectField id={"ddloption" + index} options={getOptionData(item.Options)} className="nvl-Def-Input" errors={props.errors} register={register} />
                                                                </div>
                                                            </>
                                                        ) : item?.AddQuestionType == "Short Answer" ? (
                                                            <>
                                                                <div className="gap-3" key={index}>
                                                                    <NVLMultilineTxtbox id={"txtShortOption" + index} className="nvl-Def-Input resize-y" errors={props.errors} register={register} />
                                                                </div>
                                                            </>
                                                        ) : item?.AddQuestionType == "Information" ? (
                                                            <>
                                                                <div className="gap-3" key={index}>
                                                                    <NVLlabel id={"lblInfoType" + index} text={item.InformationType} className="font-bold" />
                                                                </div>
                                                            </>
                                                        ) : (
                                                            <></>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </>
                        );
                    })}
                </div>
            </div>
        </div>
    </>
    )
}

export default FeedBackTemplate;