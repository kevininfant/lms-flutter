import NVLAlert, { ModalClose, ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { updateXlmsCourseEnrollUser, updateXlmsEnrollUser } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useRouter } from 'next/router';
import { useCallback, useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import * as Yup from 'yup';

export default function NVLGradeForm(props) {
    const router = useRouter();
    const [modalValues, setModalValues] = useState({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully." });

    const validateSchema = Yup.object().shape(
        {
            txtGrade: Yup.string().notRequired().test((val, { createError }) => {
                    if (val.split('.').length > 2) {
                        return createError({ message: `Grade is not valid contains more .` })
                    }
                    if(val.length>5)
                    {
                        setValue("txtGrade",val.slice(0,5))
                        return createError({ message: "Grade is not valid" })
                    }
                    if (!Regex("AllowOnlyNumbers").test(val)&&val!=="") {
                        return createError({ message: "Enter the valid grade" })
                    }
                    if (parseFloat(val) < 0) {
                        return createError({ message: `Grade cannot be less than 0` })
                    }
                    if (parseFloat(val) > 100.00) {
                        return createError({ message: `Maximum grade should be less than or equal to 100` })
                    }
                    return true
                }),
            txtRemarks: Yup.string().test((val, { createError })=>{
                if(val?.length>200)
                {
                    setValue("txtRemarks",val.slice(0,200));
                    createError({message:"remark is too long"})
                }
                return true
            })
        }
    )

    const submitHandler = useCallback(async (val) => {
        if(val.txtGrade===""&&val.txtRemarks==="")
        {
            setModalValues({ ModalInfo: "Danger" ,ModalTopMessage: "Failed", ModalBottomMessage: "Details cannot be Empty."  });
            ModalOpen();
            return 
        }
        const data=props.data;
        let certificate=false;
        let update="";
        if(router.query["CourseID"]!==undefined)
        {
            const ModuleID=router.query["ModuleID"];
            const activity={[router.query["ActivityID"]]:{"Grade": val.txtGrade !== undefined ? val.txtGrade : "", "Remarks": val.txtRemarks !== undefined ? val.txtRemarks.replace(/\s+/g,' ').trim(): "", "CreatedDate": new Date().toISOString()}}
            const tempdata=(data?.list?.[data.index]?.UserGradeDetails!==null)?JSON.parse(data?.list?.[data.index]?.UserGradeDetails):{};
            if(tempdata.hasOwnProperty(router.query["ModuleID"]))
            {
                tempdata[router.query["ModuleID"]]={...tempdata[router.query["ModuleID"]],...activity};
            }
            else
            {
                tempdata[router.query["ModuleID"]]=activity
            }
            update=JSON.stringify(tempdata)
        }
        else
        {
            if(router.query["ActivityID"]!==undefined)
            {
                update=JSON.stringify({"Grade": val.txtGrade !== undefined ? val.txtGrade : "", "Remarks": val.txtRemarks !== undefined ? val.txtRemarks.replace(/\s+/g,' ').trim(): "", "CreatedDate": new Date().toISOString()})
            }
        }
        const variable = { input: { PK:router.query["CourseID"]!==undefined?"TENANT#"+ props.TenantInfo?.TenantID + "#COURSE#ENROLLUSER#"+ data?.list?.[data.index]?.UserSub:"TENANT#"+ props.TenantInfo?.TenantID + "#ACTIVITY#ENROLLUSER#"+ data?.list?.[data.index]?.UserSub , SK:router.query["CourseID"]!==undefined? "COURSE#"+router.query["CourseID"]+"#BATCH#"+router.query["BatchID"]:"ACTIVITYID#" + router.query["ActivityID"], UserGradeDetails:update} };
        if (Number(data.passgrade) <= Number(val.txtGrade) && data?.GradeOption) {
            if(router.query["CourseID"]!==undefined)
            {
                let completestatus=JSON.parse((data?.list?.[data.index]?.CompletionStatus!==undefined&&data?.list?.[data.index]?.CompletionStatus!==null&&data?.list?.[data.index]?.CompletionStatus!==null)?data?.list?.[data.index]?.CompletionStatus:"{}")
                completestatus[router.query["ActivityID"]]={"CompletionStatus":"100"," CompletionDate":new Date().toISOString()};
                if(completestatus.hasOwnProperty(router.query["ModuleID"])&&completestatus[router.query["ModuleID"]].hasOwnProperty("CompletedActivity"))
                {
                    completestatus[router.query["ModuleID"]]={CompletedActivity:completestatus[router.query["ModuleID"]].CompletedActivity++,"CompletionDate":new Date().toISOString(),progress:100}
                }
                else
                {
                    completestatus[router.query["ModuleID"]]={"CompletedActivity":1,"CompletionDate":new Date().toISOString()}
                }
                if(completestatus.hasOwnProperty("CompletedActivity"))
                {
                    completestatus.CompletedActivity=completestatus.CompletedActivity+1;
                }
                else{
                    completestatus.CompletedActivity=1;
                }
                const restrict=Object.values(JSON.parse(props?.data?.list?.[props?.data?.index]?.Restriction!==undefined&&props?.data?.list?.[props?.data?.index]?.Restriction!==null?props?.data?.list?.[props?.data?.index]?.Restriction:"{}"))
                const length=restrict[0].flow?.must?.length != undefined ?restrict[0].flow?.must?.length :1;
                completestatus.progress=(completestatus.CompletedActivity*100)/length;
                const modlength=((restrict[0].flow?.must).filter(active=>
                    {
                        if(active.ModuleID===router.query["ModuleID"])
                        return active;
                    })).length
                completestatus[router.query["ModuleID"]].progress=(completestatus[router.query["ModuleID"]].CompletedActivity*100)/modlength
                if(completestatus.progress===100)
                {
                    certificate=true;
                }
                variable={...variable,input:{...variable?.input,CompletionStatus:JSON.stringify(completestatus)}}
            }
            else
            {
                variable = { ...variable, input: { ...variable?.input, CompletedStatus: "100" } };
                certificate=true;
            }
        }
        const response =(router.query.CourseID!==undefined)?await AppsyncDBconnection(updateXlmsCourseEnrollUser, variable, props.user?.signInUserSession?.accessToken?.jwtToken):await AppsyncDBconnection(updateXlmsEnrollUser,variable,props.user?.signInUserSession?.accessToken?.jwtToken)
        if (response.Status = "Success") {
            props.setData((prev) => {
                let temp = prev?.list?.[prev.index];
                temp = { ...temp, UserGradeDetails: update}
                prev?.list.splice(prev.index, 1, temp);
                return prev;
            })
            setModalValues({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully.",ModalOnClickEvent:()=>{
                if(props.data.index === props.data.list.length - 1&&!props.nexttoken)
                {
                    router.push(props.path)
                }
                else
                {
                    ModalClose()
                    props.next();
                }}})
            if(certificate)
            {
                props.generateCertificate();
            }
            ModalOpen();
        }
        else {
            setModalValues({ ModalInfo: "Danger" });
            ModalOpen();
        }
    },[props, router])
    const formoption = { mode: "onChange", resolver: yupResolver(validateSchema), reValidateMode: "onChange" }
    const { register, formState, handleSubmit, watch, setValue, clearErrors } = useForm(formoption)
    const { errors } = formState;

    useEffect(() => {
        clearErrors();
        if(router.query.CourseID!==undefined)
        {
            if (props?.data.list?.[props.data?.index]?.UserGradeDetails !== null)
            {
                const formval = JSON.parse(props?.data.list?.[props.data?.index]?.UserGradeDetails)
                if(formval.hasOwnProperty(router.query["ModuleID"])&&formval[router.query["ModuleID"]].hasOwnProperty(router.query["ActivityID"]))
                {
                    setValue("txtGrade", formval[router.query["ModuleID"]][router.query["ActivityID"]].Grade);
                    setValue("txtRemarks", formval[router.query["ModuleID"]][router.query["ActivityID"]].Remarks);
                }
                else {
                    setValue("txtGrade", "");
                    setValue("txtRemarks", "");
                }
            }
            else {
                setValue("txtGrade", "");
                setValue("txtRemarks", "");
            }
        }
        else
        {
            if (props?.data.list?.[props.data?.index]?.UserGradeDetails !== null) {
                if (props?.data.list?.[props.data?.index]?.UserGradeDetails !== undefined) {
                    const formval = JSON.parse(props?.data.list?.[props.data?.index]?.UserGradeDetails)
                    setValue("txtGrade", formval.Grade);
                    setValue("txtRemarks", formval.Remarks);
                }
            }
            else {
                setValue("txtGrade", "");
                setValue("txtRemarks", "");
            }
        } 
    }, [clearErrors, props.data?.index, props.data.list, router.query, setValue])

    return (
        <>
            <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
            <form className="py-2 space-y-2  w-full" onSubmit={handleSubmit(submitHandler)}>
                <NVLTextbox id="txtGrade" errors={errors} labelText={"Grade"} register={register} className={props?.data?.list?.[props?.data?.index]!= undefined &&props.filesource?.files?.length>0 && props?.GradeOption ? "nvl-Def-Input nvl-non-mandatory" : "nvl-Def-Input Disabled"} disabled={props.filesource?.files?.length > 0 && props.GradeOption? false : true} labelClassName="nvl-Def-Label !font-bold !text-sm" tabIndex={props?.data?.list?.[props.data?.index]!= undefined&&props.data?.list?.[props.data?.index]?.SubmissionAssignment!==undefined&& props?.data.list?.[props.data?.index].SubmissionAssignment !== null && JSON.parse(props?.data.list?.[props.data?.index]?.SubmissionAssignment)?.length !== 0 && props?.data.list?.[props.data?.index]?.SubmissionAssignment !== undefined && props.GradeOption ?0:-1}/>
                <NVLMultilineTxtbox id="txtRemarks" errors={errors} labelText={"Remarks"} register={register} labelClassName="nvl-Def-Label !font-bold !text-sm" disabled={props.filesource?.files?.length > 0 && props.GradeOption? false : true}  className={props?.data?.list?.[props?.data?.index]!= undefined &&props.filesource?.files?.length>0 && props?.GradeOption ? "nvl-Def-Input nvl-non-mandatory" : "nvl-Def-Input Disabled"} tabIndex={props?.data?.list?.[props.data?.index]!= undefined && props?.data.list?.[props.data?.index].SubmissionAssignment !== null&&props.data?.list?.[props.data?.index]?.SubmissionAssignment!==undefined && JSON.parse(props?.data.list?.[props.data?.index]?.SubmissionAssignment)?.length !== 0 && props?.data.list?.[props.data?.index]?.SubmissionAssignment !== undefined && props.GradeOption ?0:-1}/>
                <NVLButton type={"submit"} text={"Save"} ButtonType={"primary"} className={`border-none px-3 mx-2 ${props.filesource?.files?.length > 0 && props.GradeOption? "cursor-pointer " : "cursor-not-allowed"}`} disabled={props.filesource?.files?.length > 0 && props.GradeOption? false : true} />
                <NVLButton type={"button"} text={"Cancel"} ButtonType={"primary"} onClick={() => router.push(props.path)} className="border-none px-3 mx-2" />
            </form>
        </>
    )
}
