import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { updateXlmsActivityManagementInfo, updateXlmsCourseModule } from "@graphql/graphql/mutations";
import { listXlmsActivityManagementInfos, listXlmsCourseModule } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useRef, useState } from "react";
import { WithContext as ReactTags } from "react-tag-input";


export default function ActivityComponents() { };
export const Limit = ({ errors, register, setValue, watch, clearErrors }) => {
    if (!watch("chkQuizTime") && watch("txtQuizLimit") != undefined) {
        setValue("txtQuizLimit", undefined, { shouldValidate: true });
    }
    else if (!watch("chkQuizTime") && errors?.txtQuizLimit != undefined) {
        clearErrors("txtQuizLimit")
    }
    return (
        <div className="flex">
            <div className="">
                <NVLlabel text="Quiz Time Limit(Mins)"></NVLlabel>
                <NVLTextbox title="Quiz Time Limit" id="txtQuizLimit" tabIndex={!watch("chkQuizTime") ? "1" : "0"} className={!watch("chkQuizTime") ? " Disabled w-96 nvl-non-mandatory" : "w-96 nvl-non-mandatory"} disabled={!watch("chkQuizTime")} errors={errors} register={register}></NVLTextbox>
            </div>
            <div className="translate-y-8 translate-x-8">
                <NVLCheckbox text="Enable" id="chkQuizTime" disabled={watch("chkSetTime")} errors={errors} register={register}></NVLCheckbox>
            </div>

        </div>
    );
};

export const SetTime = ({ errors, register, setValue, watch }) => {

    if (!watch("chkSetTime") && watch("txtSetTime") != undefined) {
        setValue("txtSetTime", undefined, { shouldValidate: true });
    }

    return (
        <div className="mb-2">
            <div className="">
                <NVLCheckbox id="chkSetTime" disabled={watch("chkQuizTime") ? watch("chkQuizTime") : watch("movePreviousToNext")} text="Set time for each question" register={register} errors={errors}></NVLCheckbox>
            </div>
            <div className="flex">
                <div className="">
                    <NVLlabel text="Enter time for each question(min)"></NVLlabel>
                    <NVLTextbox id="txtSetTime" title="Set time for each question" className={` ${watch("chkSetTime") ? "nvl-non-mandatory w-96" : "Disabled nvl-non-mandatory w-96"}`} register={register} errors={errors}></NVLTextbox>
                </div>


            </div>
        </div>
    );
};


export const DelayEnforce = ({ errors, register, setValue, watch }) => {
    if (!watch("chkEnforcefirstEnable") && watch("txtEnforcefirstAttempt") != undefined) {
        setValue("txtEnforcefirstAttempt", undefined, { shouldValidate: true })
    }
    return (
        <div className="mr-8 flex">
            <div className="">
                <NVLlabel text="Enforced Delay between Attempts(min)" showFull></NVLlabel>
                <NVLTextbox title="" tabIndex={!watch("chkEnforcefirstEnable") ? "1" : "0"} className={!watch("chkEnforcefirstEnable") ? "Disabled w-96 nvl-non-mandatory" : "w-96 nvl-non-mandatory"} id="txtEnforcefirstAttempt" disabled={!watch("chkEnforcefirstEnable")} errors={errors} register={register} />
            </div>
            <div className="translate-y-8 translate-x-8">
                <NVLCheckbox text="Enable" id="chkEnforcefirstEnable" errors={errors} register={register} />
            </div>
        </div>
    );
}

export const DateTime = ({ errors, reset, register, setValue, watch, StartDate, EndDate, isMandatory }) => {
    let today = new Date();
    let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T00:00:00";

    if (!watch("chkEndDateEnable")) {
        if (!(watch("txtEnddate") == undefined)) {
            setValue("txtEnddate", undefined, { shouldValidate: true })
        }
    }
    return (
        <div className="grid">
            {StartDate == undefined && (
                <div className="flex">
                    <div className="pb-4">
                        <NVLlabel text="Start Date"></NVLlabel>
                        <NVLTextbox id="txtstdate" title="Start Date" type="datetime-local" tabIndex={!watch("chkStartDateEnable") ? "1" : "0"} className={!watch("chkStartDateEnable") ? "Disabled nvl-Def-Input" : `nvl-Def-Input ${isMandatory ? "nvl-mandatory" : ""}`} min={dateTime} disabled={!watch("chkStartDateEnable")} setValue={setValue} errors={errors} register={register}></NVLTextbox>
                    </div>
                    {/* <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkStartDateEnable" errors={errors} register={register}></NVLCheckbox>
                    </div> */}
                </div>
            )}
            {EndDate == undefined && (
                <div className="flex">
                    <div className="">
                        <NVLlabel text="End Date"></NVLlabel>
                        <NVLTextbox title="End Date" id="txtEnddate" type="datetime-local" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"} className={!watch("chkEndDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkEndDateEnable")} errors={errors} register={register} setValue={setValue}></NVLTextbox>
                    </div>
                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkEndDateEnable" disabled={!watch("chkStartDateEnable")} errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>
            )}
        </div>
    );
}

export const DateComponent = ({ errors, reset, register, setValue, watch, clearErrors }) => {
    let today = new Date();
    let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T" + today.getHours() + ":" + today.getMinutes();
    return (
        <>
            <div className="grid gap-4">
                <NVLlabel ClassName="nvl-Def-Label" text="Start Date"></NVLlabel>
                <div className=" gap-1">
                    <div className=" gap-16 ">
                        <NVLTextbox id="txtstdate" type="date" tabIndex={!watch("chkStartDateEnable") ? "1" : "0"} className={!watch("chkStartDateEnable") ? "Disabled w-96" : "w-96"} min={dateTime} disabled={!watch("chkStartDateEnable")} errors={errors} register={register} ></NVLTextbox>
                        <div className=" -translate-x-6 pt-3 hidden">
                            <NVLCheckbox text="Enable" id="chkStartDateEnable" errors={errors} register={register}></NVLCheckbox>
                        </div>
                    </div>
                </div>

                <div className="grid gap-4">
                    <div>
                        <NVLlabel ClassName="nvl-Def-Label" text="End Date"></NVLlabel>
                        <div className="grid grid-cols-3 ">
                            <div className="col-span-2">
                                <NVLTextbox id="txtEnddate" type="date" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"}
                                    className={!watch("chkEndDateEnable") ? "Disabled w-96" : "w-96"} disabled={!watch("chkEndDateEnable") ? true : false} min={dateTime} errors={errors} register={register} required></NVLTextbox>
                            </div>
                            <div className="translate-x-10 pt-2 col-span-1">
                                <NVLCheckbox text="Enable" id="chkEndDateEnable" disabled={!watch("chkStartDateEnable")} errors={errors} register={register}></NVLCheckbox>
                            </div>
                        </div>
                    </div>
                    <div>
                        <NVLlabel ClassName="nvl-Def-Label" text="Cut-Off Date"></NVLlabel>
                        <div className="grid grid-cols-3">
                            <div className="  col-span-2">
                                <NVLTextbox id="txtCutdate" type="date" tabIndex={!watch("chkCutDateEnable") ? "1" : "0"} className={!watch("chkCutDateEnable") ? "Disabled w-96" : "w-96"} disabled={!watch("chkCutDateEnable") ? true : false} min={dateTime} errors={errors} register={register} required></NVLTextbox>
                            </div>
                            <div className="translate-x-10 pt-2 col-span-1">
                                <NVLCheckbox text="Enable" id="chkCutDateEnable" disabled={!watch("chkEndDateEnable")} errors={errors} register={register}></NVLCheckbox>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </>
    );
}

export const ReactTagsButton = ({ tags, ButtonClassName, ButtonText, errors, watch, delimiters, handleAddition, handleDelete, handleDrag, handleSubmit, router, submitHandler, props, Flag }) => {
    let count = Object.keys(errors);
    let focus = false;
    if (count.length == 1 && count[0] == "ReactTags") {
        focus = true;
    }
    return (
        <>
            <div className="">
                <ReactTags className="" id="rcttags" autofocus={focus} inline allowUnique tags={tags} placeholder="Type and Press Enter to add new keywords" delimiters={delimiters} handleDelete={handleDelete} handleAddition={handleAddition} handleDrag={handleDrag} inputFieldPosition="top" />
                <div className="{invalid-feedback} text-red-500 text-sm">
                    {errors?.ReactTags?.message}
                </div>
            </div>
            <div className="flex justify-between gap-1 nvl-Def-Input pt-6">
                <NVLButton id="btnPrevious" text={"Previous"} disabled={watch("File") == "Uploading" || watch("submit") ? true : false} type="button" className={`nvl-button w-28 ${watch("File") == "Uploading" || watch("submit") ? "nvl-button-light" : ""}`}
                    onClick={() => {
                        if (props.mode == "Edit") {
                            if (router.query["ZoomActivityID"] != undefined) {
                                if (!router.query["NavigationMode"]) {
                                    return router.push(`/ActivityManagement/ActivityInfo?Mode=${router.query["ZoomActivityMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${props.ActivityType}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
                                } else {
                                    return router.push(`/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${props.ActivityID}&ActivityType=${props.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["ZoomActivityMode"]}`)
                                }
                            } else {
                                return router.push(`/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${props.ActivityID}&ActivityType=${props.ActivityType}`)
                            }
                        } else if (props.mode == "TrainingEdit") {
                            return router.push(`/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${props.TrainingID}&TrainingName=${props.TrainingName}&ActivityType=${props?.EditData?.ActivityType}&AssessmentType=${props?.AssessmentType}&${props?.Root == "TemplateList" ? "Root=TemplateList" : ""}`)
                        } else {
                            if (router.query["ZoomActivityID"] != undefined) {
                                return router.push(`/CourseManagement/ModuleInfo?Mode=${router.query["ZoomActivityMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${props.ActivityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props.EditData?.ModuleName}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
                            } else {
                                return router.push(`ModuleInfo?Mode=ModuleEdit&ActivityID=${props.ActivityID}&ActivityType=${props.ActivityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props.EditData.ModuleName}`)
                            }
                        }
                    }
                    }></NVLButton>
                <NVLButton id="btnSave" Flag={Flag} text={!watch("submit") ? (ButtonText ? ButtonText : "Submit") : ""} disabled={watch("submit") || watch("File") == "Uploading" ? true : false} type="button" onClick={handleSubmit((data) => submitHandler(data, "Page"))} className={ButtonClassName ? ButtonClassName : `w-32 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`} > {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>} </NVLButton>
                <NVLButton id="btnCancel" text={"Cancel"} disabled={watch("File") == "Uploading" || watch("submit") ? true : false} type="button" className={`nvl-button w-28 ${watch("File") == "Uploading" || watch("submit") ? "nvl-button-light" : ""}`}
                    onClick={() => {
                        if (props.mode == "Edit") {
                            if (router.query["ZoomActivityID"] != undefined) {
                                if (!router.query["NavigationMode"]) {
                                    return router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`)
                                } else {
                                    return router.push(`/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`)
                                }
                            } else {
                                return router.push("/ActivityManagement/ActivityList")
                            }
                        } else if (props.mode == "TrainingEdit") {
                            return router.push(`/TrainingManagement/TrainingManagementList`)
                        } else {
                            if (router.query["ZoomActivityID"] != undefined) {
                                return router.push(`/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}`)
                            } else {
                                return router.push(`/CourseManagement/ModulesList?CourseID=${props.CourseID}`)
                            }
                        }
                    }
                    }></NVLButton>
            </div>
        </>
    );
}

export const Setoptions = ({ errors, register, id }) => {
    return (
        <>
            <div id="field_div">
                <NVLlabel text={"Option " + (id + 1)} className="nvl-Def-Label w-52" />
                <div className="flex gap-10 relative">
                    <NVLTextbox title={"Option" + (id + 1)} id={"txtOption" + (id + 1)} errors={errors} register={register} />
                </div>
            </div>
        </>
    );
}

export const Options = ({ errors, register, state }) => {
    let rowGrid = [];

    for (let i = 0; i < state; i++) {
        rowGrid.push(<Setoptions errors={errors} register={register} id={i} key={i} />);
    }
    return <>{rowGrid}</>;
}

export const ActivityCompletion = ({ errors, register, watch, IsZoom }) => {
    return (
        <>
            <div className="flex gap-9">
                <NVLRadio text="Yes" value={"true"} className={`${IsZoom ? "checked:text-gray-400" : ""}`} id="rbActivityCompletion" name="rbActivityCompletion" errors={errors} register={register} watch={watch}></NVLRadio>
                <NVLRadio text="No" value={"false"} id="rbActivityCompletion" name="rbActivityCompletion" errors={errors} register={register} watch={watch}></NVLRadio>
            </div>
        </>
    );

}

export const Anonymous = ({ errors, register, watch }) => {
    return (
        <>
            <div className="flex gap-9">
                <NVLRadio text="Yes" value={"true"} id="rbRecordUserName" name="rbRecordUserName" errors={errors} register={register}></NVLRadio>
                <NVLRadio text="No" value={"false"} id="rbRecordUserName" name="rbRecordUserName" errors={errors} register={register}></NVLRadio>
            </div>
            <div className={" {invalid-feedback} text-red-500 text-sm "}>
                {errors?.rbRecordUserName?.message}
            </div>
        </>
    );
}

export const Grade = ({ ActivityType, props, errors, register, watch, AllowAttempt, setValue, Attempt }) => {
    if (ActivityType == "Quiz") {
        if (!watch(("ddlAllowAtmpt"))) {
            setValue("ddlMaxAtmpt", "");
        }
    }
    return (
        <>
            <NVLTextbox labelText="Maximum Grade (%)" type="text" id="txtMaxGrade" labelClassName="nvl-Def-Label" title="Maximum Grade" watch={watch} disabled={ActivityType == "Quiz" ? true : false} className={`${ActivityType == "Quiz" ? "nvl-mandatory nvl-Def-Input Disabled" : "nvl-non-mandatory nvl-Def-Input"}  `} errors={errors} register={register}></NVLTextbox>
            <NVLTextbox labelText="Passing Grade (%)" type="text" labelClassName="nvl-Def-Label" id="txtPassGrade" watch={watch} title="Passing Grade" className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register}></NVLTextbox>
            {AllowAttempt && (
                <NVLSelectField
                    id="ddlAllowAtmpt"
                    labelText="Allow maximum number of Attempts for"
                    showFull
                    labelClassName="nvl-Def-Label"
                    options={[
                        { value: "", text: "Select" },
                        { value: "if not Passed", text: "If not passed" },
                        { value: "Always", text: "Always" },
                    ]}
                    register={register}
                    errors={errors}
                    className="nvl-non-mandatory nvl-Def-Input"
                ></NVLSelectField>
            )}
            <NVLSelectField
                id="ddlMaxAtmpt"
                labelText="Maximum Attempt"
                labelClassName="nvl-Def-Label"
                options={[{ value: "", text: "Unlimited" },
                { value: "1", text: "1" },
                { value: "2", text: "2" },
                { value: "3", text: "3" },
                { value: "4", text: "4" },
                { value: "5", text: "5" },
                { value: "6", text: "6" },
                { value: "7", text: "7" },
                { value: "8", text: "8" },
                { value: "9", text: "9" },
                { value: "10", text: "10" },]}
                errors={errors}
                register={register}
                disabled={ActivityType == "Quiz" && (watch("ddlAllowAtmpt") == "" || watch("ddlAllowAtmpt") == undefined) ? true : false}
                className={`${ActivityType == "Quiz" && (watch("ddlAllowAtmpt") == "" || watch("ddlAllowAtmpt") == undefined) ? "Disabled " : ""} nvl-non-mandatory nvl-Def-Input`}
            ></NVLSelectField>

            <NVLSelectField
                labelText="Grading Method"
                labelClassName="nvl-Def-Label"
                id="ddlGrdMethod"
                options={[
                    { value: "", text: "Select" },
                    { value: "Highest Grade", text: "Highest Grade" },
                    { value: "Average Grade", text: "Average Grade" },
                    { value: "First Attempt", text: "First Attempt" },
                    { value: "Last Attempt", text: "Last Attempt" },
                ]}
                errors={errors}
                register={register}
                className="nvl-non-mandatory nvl-Def-Input"
            ></NVLSelectField>
        </>
    );
}

export const CheckboxesInput = (props) => {
    return (
        <>
            <div className={`${(props.watch("rbActivityCompletion") == "true"|| props?.IsZoom) ? "grid gap-1 mt-2" : "hidden"}`}>
                {props.IsViewTheActivity && (
                    <NVLCheckbox text="View this activity to complete it." className={`${props.IsZoom ? "checked:text-gray-400" : ""}`} id="chkViewTheActivity" errors={props.errors} setValue={props.setValue} watch={props.watch} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsCompleteTheActivity && (
                    <NVLCheckbox text=" To complete this activity, the user must receive a grade." id="chkCompleteTheActivity" errors={props.errors} setValue={props.setValue} watch={props.watch} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsSubmitTheActivity && (
                    <NVLCheckbox text="User must submit this activity to complete it." id="chkSubmitTheActivity" errors={props.errors} setValue={props.setValue} watch={props.watch} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsRequirePassingGrade && (
                    <NVLCheckbox text="Require Passing Grade or all available attempts completed." id="chkRequirePassingGrade" errors={props.errors} watch={props.watch} setValue={props.setValue} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsMarkTheActivity && (
                    <NVLCheckbox text="Manually mark the activity to complete it." id="chkMarkTheActivity" errors={props.errors} setValue={props.setValue} watch={props.watch} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsUserMustCreate && (
                    <NVLCheckbox text="User must create discussion or post replies." id="ChkUserCreateReplies" errors={props.errors} watch={props.watch} setValue={props.setValue} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsAvaillableAttemptsCompleted && (
                    <NVLCheckbox text="Or all available attempts completed." id="chkAvailableAttempts" errors={props.errors} watch={props.watch} setValue={props.setValue} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsShowAnswer && (
                    <NVLCheckbox text="Show the answers Posted by the user." id="chkShowAnswers" errors={props.errors} watch={props.watch} ssetValue={props.setValue} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsShowBothAnswer && (
                    <NVLCheckbox text="Show both answers posted by user and the actual answer." id="chkShowBothAnswers" errors={props.errors} setValue={props.setValue} watch={props.watch} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsShoeTheScore && (
                    <NVLCheckbox text="Show the score to all the users after the completion of quiz." id="chkShowScores" errors={props.errors} setValue={props.setValue} watch={props.watch} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsHideTheQuestions && (
                    <NVLCheckbox text="Hide the questions correctly answered by the user." id="chkHideQuestions" errors={props.errors} setValue={props.setValue} watch={props.watch} register={props.register} showFull></NVLCheckbox>
                )}
                {props.IsPassed && (
                    <NVLCheckbox text="Passed." id="chkPassed" errors={props.errors} watch={props.watch} register={props.register} setValue={props.setValue} showFull></NVLCheckbox>
                )}
                {props.IsCompleted && (
                    <NVLCheckbox text="Completed." id="chkCompleted" errors={props.errors} watch={props.watch} register={props.register} setValue={props.setValue} showFull></NVLCheckbox>
                )}
                {props.children}
            </div>

        </>
    );
};

export const TemplateVisible = ({ errors, register, watch }) => {
    return (
        <>
            <div className="gap-4">
                <div className="flex gap-14">
                    <NVLRadio text="Yes" name="rbTemplateVisible" value={"true"} id="rbTemplateVisible" errors={errors} watch={watch} register={register}></NVLRadio>
                    <NVLRadio text="No" name="rbTemplateVisible" value={"false"} id="rbTemplateVisible" errors={errors} watch={watch} register={register}></NVLRadio>
                </div>
                <div className={`w-96 pt-2 ${watch("rbTemplateVisible") == "true" ? "" : "hidden"}`}>
                    <NVLTextbox id="txtTemplateName" className="nvl-mandatory" title="Template Name" register={register} watch={watch} errors={errors}></NVLTextbox>
                </div>
                <div className={" {invalid-feedback} text-red-500 text-sm pt-2"}>
                    {errors?.rbTemplateVisible?.message}
                </div>
            </div>
        </>
    );
};

export const RecordUserName = ({ errors, register }) => {
    return (
        <>
            <div className="flex gap-16">
                <NVLRadio text="Yes" value="true" name="rbRecordUserName" id="rbRecordUserName" errors={errors} register={register}></NVLRadio>
                <NVLRadio text="No(Anonymous)" value="false" name="rbRecordUserName" id="rbRecordUserName" errors={errors} register={register}></NVLRadio>
            </div>
            <div className={"{invalid-feedback} text-red-500 text-sm "}>
                {errors?.rbRecordUserName?.message}
            </div>
        </>
    );
};

export const RadioInputs = ({ errors, register, watch, setValue, router, props, submitHandler, handleSubmit }) => {
    const [open2, setOpen2] = useState("");
    const refRouterPathName = useRef();



    const unsaveAlertPopup = (e, pathName) => {
        e.preventDefault();
        refRouterPathName.current = pathName;
        setOpen2("By Continuing, the saved information will be discarded. Wish to continue?")
        return true;
    }

    const NavigationHandler = useCallback((Mode) => {

        if (Mode == "PreAssessment") {
            if (props.mode == "ModuleDirect") {
                router.push(`ModuleInfo?Mode=PreAssessment&ActivityType=Quiz&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props.EditData.ModuleName}&ZoomActivityID=${props.ActivityID}&ZoomActivityName=${props.EditData.ActivityName}`)
            }
            else {
                router.push(`/ActivityManagement/ActivityInfo?Mode=PreAssessment&ZoomActivityID=${props.ActivityID}&ActivityType=Quiz&ZoomActivityName=${props.EditData.ActivityName}`)
            }
        } else if (Mode == "PostAssessment") {
            if (props.mode == "ModuleDirect") {
                router.push(`ModuleInfo?Mode=PostAssessment&ActivityType=Quiz&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props.EditData.ModuleName}&ZoomActivityID=${props.ActivityID}&ZoomActivityName=${props.EditData.ActivityName}`)
            }
            else {
                router.push(`/ActivityManagement/ActivityInfo?Mode=PostAssessment&ZoomActivityID=${props.ActivityID}&ActivityType=Quiz&ZoomActivityName=${props.EditData.ActivityName}`)
            }
        }
        else if (Mode == "Feedback") {
            if (props.mode == "ModuleDirect") {
                router.push(`ModuleInfo?Mode=Feedback&ActivityType=Feedback&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props.EditData.ModuleName}&ZoomActivityID=${props.ActivityID}&ZoomActivityName=${props.EditData.ActivityName}`)
            }
            else {
                router.push(`/ActivityManagement/ActivityInfo?Mode=Feedback&ZoomActivityID=${props.ActivityID}&ActivityType=Feedback&ZoomActivityName=${props.EditData.ActivityName}`)
            }
        }
    }, [props.ActivityID, props.CourseID, props.EditData.ActivityName, props.EditData.ModuleName, props.ModuleID, props.mode, router])

    const cancelClick = useCallback(() => {
        setOpen2("");
        return false;
    }, [])

    const DeleteAssessments = useCallback(async () => {
        let ActivityType = (refRouterPathName.current == "PreAssessment" || refRouterPathName.current == "PostAssessment") ? "Quiz" : "Feedback"
        let DeleteActivity;
        if (props.mode == "Edit") {
            let editZoomData = await AppsyncDBconnection(listXlmsActivityManagementInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#" + ActivityType + "#ZOOM#" + props.ActivityID + "#" + refRouterPathName.current, }, props.user.signInUserSession.accessToken.jwtToken)
            let ZoomData = editZoomData?.res?.listXlmsActivityManagementInfos?.items?.[0]
            DeleteActivity = await AppsyncDBconnection(updateXlmsActivityManagementInfo, { input: { PK: "TENANT#" + props.TenantInfo.TenantID, SK: ZoomData?.SK, IsDeleted: true } }, props.user.signInUserSession.accessToken.jwtToken)
        } else {
            let zoomWise = await AppsyncDBconnection(listXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "COURSEID#" + props.CourseID + "#MODULEID#" + props.ModuleID,
                IsDeleted: false
            }, props.user.signInUserSession.accessToken.jwtToken);

            let zoomWiseActivity = zoomWise.res.listXlmsCourseModule.items
            let filteredData = zoomWiseActivity.filter((id) => (id.ZoomActivityID == props.ActivityID && id.ActivityName?.includes(refRouterPathName.current)))
            DeleteActivity = await AppsyncDBconnection(updateXlmsCourseModule, { input: { PK: "TENANT#" + props.TenantInfo.TenantID, SK: filteredData[0]?.SK, IsDeleted: true } }, props.user.signInUserSession.accessToken.jwtToken)
        }
        setOpen2("")
        if (refRouterPathName.current == "PreAssessment") {
            setValue("rbPreAssessment", "false")
        } else if (refRouterPathName.current == "PostAssessment") {

            setValue("rbPostAssessment", "false")
        } else {
            setValue("rbFeedback", "false")
        }
    }, [props.ActivityID, props.CourseID, props.ModuleID, props.TenantInfo.TenantID, props.mode, props.user.signInUserSession.accessToken.jwtToken, setValue])
    return (
        <div className="">
            <NVLModalPopup
                ButtonYestext="Continue"
                SubmitClick={() => DeleteAssessments()}
                CancelClick={(e) => cancelClick()}
                ButtonNotext="Cancel"
                CloseIconEvent={(e) => cancelClick()}

                Content={open2} />

            <div className="w-72 py-2">
                <NVLlabel id="lblHostVideo" text="Host Video" className="nvl-Def-Label"></NVLlabel>
                <div className="grid grid-flow-col pt-1">
                    <NVLRadio text="Yes" value={true} name="rbHostVisible" id="rbHostVisible" errors={errors} register={register} />
                    <NVLRadio text="No" value={false} name="rbHostVisible" id="rbHostVisible" errors={errors} register={register} />
                </div>
                <div className={"Center-Aligned-Items {invalid-zoom} text-red-500 text-sm"}>
                    {errors?.rbHostVisible?.message}
                </div>
            </div>
            <div className="w-72 py-2">
                <NVLlabel id="lblParticipantsVideo" text="Participants Video" className="nvl-Def-Label" />
                <div className=" grid grid-flow-col pt-1">
                    <NVLRadio text="Yes" value={true} name="rbParticipantsVideo" id="rbParticipantsVideo" errors={errors} register={register} />
                    <NVLRadio text="No" value={false} name="rbParticipantsVideo" id="rbParticipantsVideo" errors={errors} register={register} />
                </div>
                <div className={"Center-Aligned-Items {invalid-zoom} text-red-500 text-sm"}>
                    {errors?.rbParticipantsVideo?.message}
                </div>
            </div>
            <div className={`${props.mode == "Edit" ? "hidden" : "w-72 py-2"}`}>
                <NVLlabel id="lblPreAssessment" text="Pre Assessment" className="nvl-Def-Label" />
                <div className="grid grid-flow-col gap-2 pt-1">
                    <NVLRadio text="Yes" value={true} name="rbPreAssessment" id="rbPreAssessment" errors={errors} register={register} />
                    <NVLRadio text="No" value={false} name="rbPreAssessment" id="rbPreAssessment" errors={errors} register={register} onClick={(e) => { return unsaveAlertPopup(e, "PreAssessment") }} />
                    <div className={`${watch("rbPreAssessment") == "false" && "hidden"}`}>
                        <NVLButton type="button" ButtonType="link" text="+ Map Question"
                            onClick={handleSubmit((data) => submitHandler(data, "PreAssessment", NavigationHandler))}
                        />
                    </div>
                </div>
                <div className={"Center-Aligned-Items {invalid-zoom} text-red-500 text-sm "}>
                    {errors?.rbPreAssessment?.message}
                </div>
            </div>
            <div className={`${props.mode == "Edit" ? "hidden" : "w-72 py-2"}`}>
                <NVLlabel id="lblPostAssessment" text="Post Assessment" className="nvl-Def-Label"></NVLlabel>
                <div className=" grid grid-flow-col pt-1 ">
                    <NVLRadio text="Yes" value={true} name="rbPostAssessment" id="rbPostAssessment" errors={errors} register={register} />
                    <NVLRadio text="No" value={false} name="rbPostAssessment" id="rbPostAssessment" errors={errors} register={register} onClick={(e) => { return unsaveAlertPopup(e, "PostAssessment") }} />
                    <div className={`${watch("rbPostAssessment") == "false" && "hidden"}`}>
                        <NVLButton type="button" ButtonType="link" text="+ Map Question"
                            onClick={handleSubmit((data) => submitHandler(data, "PostAssessment", NavigationHandler))}
                        />
                    </div>
                </div>
                <div className={"Center-Aligned-Items {invalid-zoom} text-red-500 text-sm "}>
                    {errors?.rbPostAssessment?.message}
                </div>
            </div>

            <div className={`${props.mode == "Edit" ? "hidden" : "w-72 py-2"}`}>
                <NVLlabel id="lblFeedback" text="Feedback" className="nvl-Def-Label"></NVLlabel>
                <div className="grid grid-flow-col pt-1">
                    <NVLRadio text="Yes" value={true} name="rbFeedback" id="rbFeedback" errors={errors} register={register} />
                    <NVLRadio text="No" value={false} name="rbFeedback" id="rbFeedback" errors={errors} register={register} onClick={(e) => { return unsaveAlertPopup(e, "Feedback") }} />
                    <div className={`${watch("rbFeedback") == "false" && "hidden"}`}>
                        <NVLButton type="button" ButtonType="link" text="+ Create Feedback"
                            onClick={handleSubmit((data) => submitHandler(data, "Feedback", NavigationHandler))} />
                    </div>
                </div>
                <div className={"Center-Aligned-Items {invalid-zoom} text-red-500 text-sm "} >
                    {errors?.rbFeedback?.message}
                </div>
            </div>
            <div className="mt-1">
                <div className="-translate-x-56 translate-y-4 w-28">
                    <NVLlabel className="nvl-Def-Label" id="lblaudiooption" text="Audio Option" />
                </div>
                <div className=" flex  gap-10  ">
                    <NVLRadio text="Telephony Only" value={"Telephone Only"} name="rbaudiooption" id="rbaudiooption" errors={errors} register={register} />
                    <NVLRadio text="VOIP Only" value="VOIP Only" name="rbaudiooption" id="rbaudiooption" errors={errors} register={register} />
                    <NVLRadio text="VOIP and Telephony" value="VOIP and Telephony" name="rbaudiooption" id="rbaudiooption" errors={errors} register={register} />
                </div>
                <div className={" {invalid-zoom} text-red-500 text-sm "}>
                    {errors?.rbaudiooption?.message}
                </div>
                <div className="mt-4">
                    <div className="-translate-x-56 translate-y-4 w-28">
                        <NVLlabel className="nvl-Def-Label " id="lblmeetingoption" text="Meeting option" />
                    </div>
                </div>
                <div className="  flex  gap-12">
                    <NVLCheckbox text="Enable Join Before Host " value={true} name="chkmeetingoption" id="chkmeetingoption" errors={errors} register={register} />
                </div>
                <div className={" {invalid-zoom} text-red-500 text-sm "}>
                    {errors?.rbmeetingoption?.message}
                </div>
                <div className="mt-4 pb-2">
                    <NVLlabel className="nvl-Def-Label" id="lblalternativehosts" text="Alternative Hosts" />
                </div>
                <div className="Center-Aligned-Items">
                    <NVLTextbox id="txtalternativehost"
                        className={`nvl-non-mandatory nvl-Def-Input w-44 }`} type="email" maxLength={"3"} errors={errors} title={"Enter email addresses separated by commas"} register={register} />
                </div>
            </div>
        </div>
    );
};