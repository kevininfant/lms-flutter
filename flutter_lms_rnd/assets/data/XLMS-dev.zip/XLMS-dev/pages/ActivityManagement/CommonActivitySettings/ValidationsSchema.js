import { DynamicPageLanguageValidation } from "@Pages/ActivityManagement/CommonActivitySettings/CommonFunction";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";
export const validationSchema = (watch, setValue, ActivityType, tags, setCustomMessage, SetDynamicError, FileValues, LangValues, reset, ActivityCompletionRef, pageRef, setLangValue, setFileValues) => {
  const hasDuplicate = (arrayObj, colName) => {
    var hash = Object.create(null);
    return arrayObj.some((arr) => {
      return arr[colName] && (hash[arr[colName]] || !(hash[arr[colName]] = true));
    });
  };
  
  const ResetLanguage = () => {
    if (ActivityType == "Video") {
      let isActivityCmpt = document.getElementById("rbIsURL") ? document.getElementById("rbIsURL").checked : null;
      if (isActivityCmpt) {
        setFileValues([{
          FileName: "Select File",
          FilePath: "Select File",
          path: "",
          pathchanged: false,
        }]);
      } else {
        setLangValue([{
          Language: null,
          TextURL: null,
        }]);
        DynamicTextLanguageResetData();
      }
    }
  }

 
        

  const ResetData = () => {
    if (ActivityType == "Discussion") {
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : "";
      document.getElementById("chkCompleteTheActivity") ? document.getElementById("chkCompleteTheActivity").checked = false : "";
      document.getElementById("ChkUserCreateReplies") ? document.getElementById("ChkUserCreateReplies").checked = false : "";
    }
    else if (ActivityType == "Url") {
      document.getElementById("chkViewTheActivity") ? document.getElementById("chkViewTheActivity").checked = false : "";
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : "";
    }
    else if (ActivityType == "Quiz") {
      document.getElementById("chkShowAnswers") ? document.getElementById("chkShowAnswers").checked = false : null;
      document.getElementById("chkShowScores") ? document.getElementById("chkShowScores").checked = false : null;
      document.getElementById("chkShowBothAnswers") ? document.getElementById("chkShowBothAnswers").checked = false : null;
      document.getElementById("chkHideQuestions") ? document.getElementById("chkHideQuestions").checked = false : null;
    }
    else if (ActivityType == "Survey") {
      document.getElementById("chkViewTheActivity") ? document.getElementById("chkViewTheActivity").checked = false : null;
      document.getElementById("chkCompleteTheActivity") ? document.getElementById("chkCompleteTheActivity").checked = false : null;
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : null;
    }
    else if (ActivityType == "Feedback") {

      document.getElementById("chkUserParticipant") ? document.getElementById("chkUserParticipant").checked = false : null;
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : null;
      document.getElementById("chkSubmitTheFeedback") ? document.getElementById("chkSubmitTheFeedback").checked = false : null;

    }
    else if (ActivityType == "Assignment") {
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : null;
      document.getElementById("chkViewTheActivity") ? document.getElementById("chkViewTheActivity").checked = false : null;
      document.getElementById("chkCompleteTheActivity") ? document.getElementById("chkCompleteTheActivity").checked = false : null;
      document.getElementById("chkSubmitTheActivity") ? document.getElementById("chkSubmitTheActivity").checked = false : null;
    }
    else if (ActivityType == "File") {
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : null;
      document.getElementById("chkViewTheActivity") ? document.getElementById("chkViewTheActivity").checked = false : null;
    }
    else if (ActivityType == "Video") {
      document.getElementById("chkViewTheActivity") ? document.getElementById("chkViewTheActivity").checked = false : null;
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : null;
    }
    else if (ActivityType == "ScormPackage") {
      document.getElementById("chkViewTheActivity") ? document.getElementById("chkViewTheActivity").checked = false : null;
      document.getElementById("chkSubmitTheActivity") ? document.getElementById("chkSubmitTheActivity").checked = false : null;
      document.getElementById("chkCompleteTheActivity") ? document.getElementById("chkCompleteTheActivity").checked = false : null;
      document.getElementById("chkPassed") ? document.getElementById("chkPassed").checked = false : null;
      document.getElementById("chkMarkTheActivity") ? document.getElementById("chkMarkTheActivity").checked = false : null;
      document.getElementById("chkCompleted") ? document.getElementById("chkCompleted").checked = false : null;

    }
  }
  const DynamicTextLanguageResetData = () => {
    document.getElementById("divURLLangCount") ? document.getElementById("divURLLangCount").innerHTML = 1 : ""
    document.getElementById("ddlVideoUrl0") ? document.getElementById("ddlVideoUrl0").selectedIndex = "" : "";
    document.getElementById("textVideoUrl0") ? document.getElementById("textVideoUrl0").value = "" : "";
  }

  const DynamicFileLanguageValidation = (originData, id) => {
    let errorResponse = originData;
    let checkLang = [];
    let isErrorSatus = true;

    for (let index = 0; index < parseInt(document?.getElementById("divFileLangCount")?.innerHTML); index++) {
      let language = document.getElementById(id + index)?.options[document.getElementById(id + index)?.selectedIndex]?.value;
      checkLang = [...checkLang, { lang: language }];

      if ((language == "" || language == undefined) && ((FileValues[index]?.FilePath == null || FileValues[index]?.FilePath == undefined || FileValues[index]?.FilePath == "Select File") || (FileValues[index]?.FileName == "Select File" || FileValues[index]?.FileName == null || FileValues[index]?.FileName == undefined))) {
        errorResponse = "FILELANG";
        isErrorSatus = false;
        break;
      }
      else if (language == undefined || language == "") {
        errorResponse = "LANG";
        isErrorSatus = false;
        break;
      } else if ((FileValues[index]?.FileName == "Select File" || FileValues[index]?.FileName == undefined || FileValues[index]?.FileName == null) && (FileValues[index]?.FilePath == "" || FileValues[index]?.FilePath == null)) {
        errorResponse = "FILE";
        isErrorSatus = false;
        break;
      }
    }
    if (hasDuplicate(checkLang, "lang")) {
      errorResponse = "LANGEXISTS";
    }
    else if (errorResponse == "ERROR") {
      return errorResponse;
    }
    else if (isErrorSatus) {
      errorResponse = "sucess";
    }
    return errorResponse;
  }

  const DynamicTextLanguageValidation = (originData, getTextURLID, getDDLLangID) => {

    let errorResponse = originData;
    let checkLang = [];
    let isErrorSatus = true;
    for (let index = 0; index < parseInt(document?.getElementById("divURLLangCount")?.innerHTML); index++) {
      let language = document.getElementById(getDDLLangID + index)?.options[document.getElementById(getDDLLangID + index)?.selectedIndex]?.value;
      let textid = document.getElementById(getTextURLID + index)?.value;
      checkLang = [...checkLang, { lang: language }]
      if ((language == "" || language == undefined) && (textid == "" || textid == undefined)) {
        errorResponse = "LANGTEXT";
        isErrorSatus = false;
        break;
      }
      else if (textid == "" || textid == undefined) {
        errorResponse = "TEXT";
        isErrorSatus = false;
        break;
      } else if (!Regex("Url").test(textid) && (language == "" || language == undefined)) {
        errorResponse = "LANGINVALIDURL";
        isErrorSatus = false;
        break;
      }
      else if (language == "" || language == undefined) {
        errorResponse = "LANG";
        isErrorSatus = false;
        break;
      }
      else if (!Regex("Url").test(textid)) {
        errorResponse = "INVALIDURL";
        isErrorSatus = false;
        break;
      }
    }

    if (hasDuplicate(checkLang, "lang")) {
      errorResponse = "LANGEXISTS";
    }
    else if (errorResponse == "ERROR") {
      return errorResponse;
    }
    else if (isErrorSatus) {
      errorResponse = "sucess";
    }

    return errorResponse
  };




  return Yup.object().shape({
    /*File And Language Error */
    FileLang:
      ActivityType == "File" || ActivityType == "Video" || ActivityType == "ScormPackage" || ActivityType == "Assignment" || ActivityType == "LearningBytes" || ActivityType == "Survey" || ActivityType == "Page"
        ? Yup.string()
          .test("file_Error", "", (e, { createError }) => {
            let errorName = "",
              id = "",
              message = "";
            if (ActivityType == "File" || ActivityType == "ScormPackage" || ActivityType == "Assignment") {
              id = ActivityType == "File" ? "ddlFile" : ActivityType == "Video" ? "ddlVideo" : ActivityType == "Survey" ? "ddlFileSurvey" : ActivityType == "ScormPackage" ? "ddlFileScorm" : "ddlAssignment";
              errorName = DynamicFileLanguageValidation(e, id);
            }
            if (document.getElementById("rbIsURL")?.value == "URL" && document.getElementById("rbIsURL")?.checked) {
              let textid = ActivityType == "Video" ? "textVideoUrl" : ActivityType == "Survey" ? "textSurveyUrl" : "";
              let ddlid = ActivityType == "Video" ? "ddlVideoUrl" : ActivityType == "Survey" ? "ddlSurveyUrl" : "";

              errorName = DynamicTextLanguageValidation(e, textid, ddlid);
            } else {
              if (ActivityType == "Page") {
                errorName = DynamicPageLanguageValidation(pageRef, "ddlLanguagePage")
              }
              else {
                id = ActivityType == "File" ? "ddlFile" : ActivityType == "Video" ? "ddlVideo" : ActivityType == "Survey" ? "ddlFileSurvey" : ActivityType == "ScormPackage" ? "ddlFileScorm" : "ddlAssignment";
                errorName = DynamicFileLanguageValidation(e, id);
              }

            }
            if (errorName == "LANGEXISTS") {
              message = "Language is already exists.";
            } else if (errorName == "FILE") {
              message = "File is required to upload correct format.";
            } else if (errorName == "FILELANG") {
              message = "Language and File is required.";
            } else if (errorName == "LANG") {
              message = "Language is required.";
            } else if (errorName == "ERROR") {
              message = "File not uploaded.";
            } else if (errorName == "TEXT") {
              message = "URL is required.";
            } else if (errorName == "LANGTEXT") {
              message = "Language and URL is required.";
            } else if (errorName == "INVALIDURL") {
              message = "Url is invalid.";
            } else if (errorName == "INVALIDFILE") {
              message = "File Format Is Invalid.";
            } else if (errorName == "INVALIDFILE") {
              message = "File size upto 1GB.";
            } else if (errorName == "LANGINVALIDURL") {
              message = "Language is required and URL  is invalid.";
            }
            if (message != "") {
              SetDynamicError(message);
              document.getElementById("fileErrorMessage")?.classList?.remove("hidden");

              return createError({ message: message });
            } else {
              SetDynamicError(message);
              if (!document.getElementById("fileErrorMessage")?.classList?.contains("hidden")) {
                document.getElementById("fileErrorMessage")?.classList?.add("hidden");
              }
              return true;
            }
          }).nullable()
        : Yup.string().nullable(),

    /* CheckBox Input */
    chkViewTheActivity: Yup.bool().default(false).nullable(),
    chkCompleteTheActivity: Yup.bool().default(false).nullable(),
    chkMarkTheActivity: Yup.bool().default(false).nullable(),
    chkSubmitTheActivity: Yup.bool().default(false).nullable(),
    ChkUserCreateReplies: Yup.bool().default(false).nullable(),
    chkdisplay: Yup.bool().default(false).nullable(),
    chkcopyright: Yup.bool().default(false).nullable(),
    /*Enable Host Validation*/
    txtalternativehost: Yup.string()
      .nullable()
      .when("chkmeetingoption", {
        is: true,
        then: Yup.string().required("Alternative Host is required").nullable(true),
      }),

    /* TemplateName Validation*/
    txtTemplateName: Yup.string().when("rbTemplateVisible", {
      is: "true",
      then: Yup.string()
        .typeError("Template Name is required")
        .required("Template Name is required")
        .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Enter a valid Template Name")
        .max(250, "Maximum character does not exceed 250")
        .test("", "Template Name is required", () => {
          if (document.getElementById("txtTemplateName")?.value == "") {
            return false;
          }
          return true;
        })
        .nullable(),
    }),

    txtCompletionMsg: Yup.string().nullable().max(500, "Maximum character does not exceed 500"),

    /*Date time Validation*/

    txtstdate: Yup.date()
      .nullable()
      .when("chkStartDateEnable", {
        is: true,
        then: Yup.date("Start Date is Required")
          .required("Start Date is Required")
          .nullable(true)
          .typeError("Activity can be created only for present and future date")
          .test("check", "Activity can be created only for present and future date", (e) => {
            let dateTime = new Date(e);
            if (dateTime < new Date()) {
              return false;
            }
            return true;
          }),
      }),

    txtEnddate: Yup.date()
      .when("chkEndDateEnable", {
        is: true,
        then: Yup.date().min(Yup.ref("txtstdate"), "End Date must be greater than or equal to the start date").required("End Date is Required").typeError("End Date is invalid Value").nullable(),
      })
      .nullable(),

    txtCutdate:
      ActivityType == "Assignment" &&
      Yup.date()
        .when("chkCutDateEnable", {
          is: true,
          then: Yup.date().min(Yup.ref("txtstdate"), "End Date must be greater than or equal to the start date").required("End Date is Required").typeError("End Date is invalid Value").nullable(),
        }
        ).nullable(),

    txtCutdate:
      ActivityType == "Assignment" &&
      Yup.date()
        .when("chkCutDateEnable", {
          is: true,
          then: Yup.date().required("Cut of Date is Required").min(Yup.ref("txtEnddate"), "Cut-Off Date Must Be Greater than or equal to End Date").typeError("Cut-Off Date is invalid Value").nullable(),
        })

        .nullable(),

    /* Activity Completion */
    rbActivityCompletion: Yup.string()
      .required("Activity completion is required")
      .nullable()
      .test("error", "", (e, { createError }) => {
        if (e == "true" && ActivityCompletionRef.current == "true") {
          let array = ["chkViewTheActivity", "chkCompleteTheActivity", "chkMarkTheActivity", "chkSubmitTheActivity", "ChkUserCreateReplies", "chkdisplay", "chkcopyright", "chkShowAnswers", "chkShowScores", "chkShowBothAnswers", "chkHideQuestions", "chkSubmitTheFeedback", "chkPassed", "chkCompleted"];
          let result = [];
          array.map((item, idx) => {
            result.push(document.getElementById(item)?.checked);
          });
          if (result.indexOf(true) == -1) {
            setCustomMessage("At least one field is required");
            document.getElementById("divCustomError")?.classList?.remove("hidden");
            return false;
          } else {
            setCustomMessage("");
            document.getElementById("divCustomError")?.classList?.add("hidden");
            return true;
          }
        } else {
          if (e == "true") {
            ActivityCompletionRef.current = "true";
            document.getElementById("divCustomError")?.classList?.add("hidden");
            return false;
          }
          ActivityCompletionRef.current = "false";
          ResetData();
          setCustomMessage("");
          document.getElementById("divCustomError")?.classList?.add("hidden");
        }
        return true;
      })
      .nullable(),
    /* Tags */
    ReactTags: Yup.string()
      .test("testReactTags", "Keywords is Required", (e) => {
        return true;
        if (e == "Add") {
          return true;
        } else if (e == "Delete" && tags.length == 1 && props?.EditData?.Keywords == null) {
          return false;
        }
        if (props?.EditData?.Keywords == null || tags.length == 0) {
          return false;
        } else {
          return true;
        }
      })
      .nullable(),

    /*Page */
    txtUrl: ActivityType == "Url" ? Yup.string().required("Url is required").matches(Regex("Url"), "Url is invalid").nullable() : Yup.string().nullable(),
    txtWidth: ActivityType == "Url" ? Yup.string().nullable().max(4, "Max length exceed 4") : Yup.string().nullable(),
    txtHeight: ActivityType == "Url" ? Yup.string().max(4, "Max length exceed 4").nullable() : Yup.string().nullable(),
    /* File */
    rbFileDownload: ActivityType == "File" ? Yup.string().required("File download is required").nullable() : Yup.string().nullable(),
    /* Video && Zoom && GoogleMeet */
    txtDuration:
      ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams"
        ? Yup.string()
          .transform((o, c) => (o === "" ? null : c))
          .matches(Regex("AllowZeroasSecondary"), "Numbers only allowed")
          .nullable()
          .required("Duration is required")
          .test("len", "Must be 2 digits", (val, { createError }) => {
            let LimitedTime = ActivityType == "GoogleMeet" ? 60 : "" || ActivityType == "Zoom" ? 40 : "" || ActivityType == "MSTeams" ? 1800 : "";
            if (val > LimitedTime) {
              return createError({
                message: `Duration should be less than or Equal to ${LimitedTime} Minutes`,
              });
            } else {
              return true;
            }
          })
        : ActivityType == "Video"
          ? Yup.string()
            .nullable()
            .transform((o, c) => (o === "" ? null : c))
            .max(9, "Video Duration should not Exceed more than 9 values")
            .matches(Regex("AllowZeroasSecondary"), "Enter Valid Value")
          : Yup.string().nullable(),
    /* Video && Survey*/
    rbIsURL: ActivityType == "Video" || ActivityType == "Survey" ? Yup.string().required("Attach type is required").nullable().test("", "", (e) => {
      ResetLanguage();
      return true;
    }) : Yup.string().nullable(),
    /* Discussion */
    txtMaxAttachmentSize:
      ActivityType == "Discussion"
        ? Yup.string()
          .typeError("Max attachment size is required")
          .required("Max attachment size is required")
          .matches(Regex("AllowOnlyNumbers"), "File size should not exceed more than 1024MB")
          .transform((o, c) => (o === "" ? null : c))
          .test("error", "", (val, { createError }) => {
            if (parseInt(val) >= 1024) {
              return createError({ message: "Attachment file size should be between 1-1024 MB" });
            } else if (parseInt(val) == 0) {
              return createError({ message: "Attachment file size should be between 1-1024 MB" });
            }
            return true;
          })
          .nullable()
        : Yup.string().nullable(),

    /*Validation For Record UserName*/
    rbRecordUserName: ActivityType == "Discussion" || ActivityType == "Survey" ? Yup.string().required("Record user name is required").nullable() : Yup.string().nullable(true).notRequired(),

    //  Assignment */
    txtAssgmntDuration: Yup.string()
      .nullable()
      .transform((o, c) => (o === "" ? null : c))
      .max(3, "Maximum Activity Duration must be at most 3 characters")
      .test("Enter the valid value", "Enter the valid value", (e) => {
        if (parseInt(e) == 0) {
          return false;
        }
        return true;
      }),

    //  Feedback*/
    rbTemplateVisible:
      ActivityType == "Feedback"
        ? Yup.string()
          .nullable()
          .test("", "", (e) => {
            if (e == "false") {
              document.getElementById("txtTemplateName") ? (document.getElementById("txtTemplateName").value = "") : "";
            }
            return true;
          })
        : Yup.string().nullable(),

    rbMultipleSubmission: ActivityType == "Feedback" ? Yup.string().required("Multiple submissions is required").nullable() : Yup.string().nullable(),
    rbEnableSubmission: ActivityType == "Feedback" ? Yup.string().required("Enable notification of submissions is required").nullable() : Yup.string().nullable(),
    rbRecordUser: ActivityType == "Feedback" ? Yup.string().required("Record user name is required").nullable() : Yup.string().nullable(),
    rbShowAnalysis: ActivityType == "Feedback" ? Yup.string().required("Show analysis page is required").nullable() : Yup.string().nullable(),

    // Zoom & GoogleMeet
    rbIsRecurringWebinar: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Any one required").nullable() : Yup.string().nullable(),
    txtPassword:
      ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams"
        ? Yup.string()
          .typeError("Password is required")
          .nullable()
          .required("Password is Required")
          .test("validateStrength", "", (e, { createError }) => {
            let strength = 0,
              message = "Password Should Have ";
            if (!e?.match(/\d+/g)) {
              strength++;
              message = message + "A Number";
            }

            if (!e?.match(/[A-Z]+/g)) {
              strength++;
              if (strength > 1) {
                message = message + ", ";
              }
              message = message + "A Captial Letter";
            }
            if (!e?.match(/[a-z]+/g)) {
              strength++;
              if (strength > 1) {
                message = message + ", ";
              }
              message = message + "A Small Letter";
            }
            if (e?.length < 8) {
              strength++;
              if (strength > 1) {
                message = message + ", ";
              }
              message = message + "Minimun Of Length 8";
            }
            if (strength > 0) {
              return createError({ message: message });
            }
            return true;
          })
        : Yup.string().nullable(),
    rbHostVisible: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Host Option is required").nullable() : Yup.string().nullable(),
    rbParticipantsVideo: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Participants Video is required").nullable() : Yup.string().nullable(),
    rbPreAssessment: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Pre Assessment is required").nullable() : Yup.string().nullable(),
    rbPostAssessment: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Post Assessment is required").nullable() : Yup.string().nullable(),
    rbFeedback: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Feedback is required").nullable() : Yup.string().nullable(),
    rbCertificate: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Certificate is required").nullable() : Yup.string().nullable(),
    rbaudiooption: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Audio Option is required").nullable() : Yup.string().nullable(),
    
    /*Grade Validation*/
    txtMaxGrade:
      ActivityType == "LearningBytes" || ActivityType == "ScormPackage" || ActivityType == "Quiz" || ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "Assignment" || ActivityType == "MSTeams"
        ? Yup.string()
          .nullable()
          .required("Maximum grade is required")
          .transform((o, c) => (o === "" ? null : c))
          .test("100", "Maximum grade should be less than or equal to 100.00", (val, { createError }) => {
            if (parseInt(val) == 0) {
              return createError({ message: "Enter the valid value" });
            }
            if (val != null && parseFloat(val) > "100.00") {
              return createError({ message: "Maximum grade should be less than or equal to 100.00" });
            }

            if (document.getElementById("txtPassGrade") != null && parseFloat(document.getElementById("txtPassGrade").value) > parseFloat(val)) {
              return createError({ message: "Maximum grade should be greater than passing grade" });
            }
            if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
              return false;
            }
            if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
              return false;
            }
            if (!(val == "100") && val?.length > 6 && val?.includes(".")) {
              return false;
            }
            return true;
          })
        : Yup.string().nullable(),

    ddlAllowAtmpt: ActivityType == "Quiz" ? Yup.string().required("Please Choose an item in the list").nullable() : Yup.string().nullable(),
    txtPassGrade: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .test("error", "Passing grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        if (val == null || val == undefined || val == "") {
          return true;
        }
        if (parseInt(val) == 0) {
          return createError({ message: "Enter the valid value" });
        }
        if (document.getElementById("txtMaxGrade") != null && parseFloat(document.getElementById("txtMaxGrade").value) < parseFloat(val)) {
          return createError({ message: "Passing Grade Must be less than Maximum Grade" });
        }
        if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
          return false;
        }
        if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
          return false;
        }
        if (!(val == "100") && val?.length > 6 && val?.includes(".")) {
          return false;
        }
        return true;
      })
      .nullable(),
    txtMaximum: Yup.string()
      .nullable()
      .transform((o, c) => (o === "" ? null : c))
      .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
      .test("error", "", (val, { createError }) => {
        if ((val != "" || val != undefined) && (parseInt(val) > 1024 || parseInt(val) <= 0)) {
          return createError({ message: "File size  should be between 1-1024 MB" });
        }
        return true;
      }),
    txtNoofAttachment: Yup.string()
      .nullable()
      .transform((o, c) => (o === "" ? null : c))
      .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
      .test("error", "", (val, { createError }) => {
        if ((val != "" || val != undefined) && (parseInt(val) > 20 || parseInt(val) <= 0)) {
          return createError({ message: "Attachment should be between 1-20" });
        }
        return true;
      }),
    ddlAllowAtmpt: ActivityType == "Quiz" || ActivityType == "Assignment" ? Yup.string().nullable() : Yup.string().nullable(),
    ddlMaxAtmpt:
      ActivityType == "Quiz"
        ? Yup.string()
          .nullable()
          .when("ddlAllowAtmpt", {
            is: "",
            then: Yup.string().nullable(true),
            otherwise: Yup.string().nullable(),
          })
        : Yup.string().nullable(),
    ddlGrdMethod: Yup.string().nullable(),
    /*ScormPackage*/
    txtScormDuration: Yup.string()
      .nullable()
      .transform((o, c) => (o === "" ? null : c))
      .max(4, "Scorm Duration should not Exceed more than 4 values")
      .matches(Regex("AllowZeroasSecondary"), "Enter Valid Value"),
    /*Quiz*/
    txtSettime: ActivityType == "Quiz" ? Yup.string().typeError("Value is required").matches(Regex("AllowZeroasSecondary"), "Invlid Value").min(1).max(3, "Set Time should be atmost 3 characters") : Yup.string().nullable(),
    txtEnforcefirstAttempt:
      ActivityType == "Quiz"
        ? Yup.number()
          .typeError("Invalid Value")
          .nullable()
          .when("chkEnforcefirstEnable", {
            is: true,
            then: Yup.number().typeError("Invalid Value").required("Value is required").min(1).max(999, "Maximum character exceeds").nullable(true),
          })
        : Yup.number().nullable(true),

    txtGradeBoundary:
      ActivityType == "Quiz"
        ? Yup.number()
          .typeError("Invalid Value")
          .nullable()

          .max(4, "Grade Boundary should not exceed more than 3 characters")

          .test("error", "", (val, { createError }) => {
            if (val < 1) {
              return createError({ message: "Grade Boundary should not be less than 1" });
            }
            return true;
          })
          .nullable(true)
        : Yup.number().nullable(),

    // txtGradeboundary: Yup.string()
    //   .notRequired().nullable()
    //   .test("number", "Enter a valid number", (e) => {
    //     if (e != "" && e?.length != 5) {
    //       return false;
    //     }
    //     if (e == "") {
    //       return true;
    //     }
    //     const rejax = new RegExp(/^[0-9]$/);
    //     if (!rejax.test(e)) {
    //       return false;
    //     }
    //     return true;
    //   }),

    txtQuizLimit:
      ActivityType == "Quiz"
        ? Yup.number()
          .typeError("Invalid Value")
          .nullable()
          .when("chkQuizTime", {
            is: true,
            then: Yup.number()
              .typeError("Invalid Value")
              .required("Quiz Time Limit is required")
              .max(999, "Quiz Time Limit should not exceed more than 3 characters")
              .nullable(true)
              .test("error", "", (val, { createError }) => {
                if (val < 1) {
                  return createError({ message: "Time should not be less than 1" });
                }
                return true;
              })
              .nullable(true),
          })
        : Yup.number().nullable(),
    txtSettime:
      ActivityType == "Quiz"
        ? Yup.number()
          .typeError("Invalid Value")
          .nullable()
          .when("chkSetTime", {
            is: true,
            then: Yup.number()
              .typeError("Invalid Value")
              .required("Time for each question is required")
              .max(999, "Maximum character exceeded")
              .test("error", "", (val, { createError }) => {
                if (val < 1) {
                  return createError({ message: "Time should not be less than 1" });
                }
                return true;
              })
              .nullable(true),
          })
        : Yup.number().nullable(),
    /* LearningBytes*/
    ddlRecordContentName: ActivityType == "LearningBytes" ? Yup.string().required("Choose a Validity").nullable() : Yup.string().nullable(),
    hkcopyright: ActivityType == "LearningBytes" ? Yup.bool().default(false).nullable() : Yup.string().nullable(),
    /*Poll*/
    txtOptionStaticLimit1:
      ActivityType == "Poll"
        ? Yup.string()
          .when("rbAllowTheChoice", {
            is: "true",
            then: Yup.string().required("Choice limit is required").nullable().matches(Regex("AllowOnlyNumbers"), "Invalid Choice limit").max(3, "Max length exceed"),
            otherwise: Yup.string()
              .test("NoValid", "NoValid", () => {
                setValue("txtOptionStaticLimit1", "");
                return true;
              })
              .nullable(),
          })
          .nullable()
        : Yup.string().nullable(),
    txtOptionStaticLimit2:
      ActivityType == "Poll"
        ? Yup.string()
          .when("rbLimitTheResponse", {
            is: "true",
            then: Yup.string().required("Respsonse limit is required").nullable().matches(Regex("AllowOnlyNumbers"), "Invalid Respsonse limit ").max(3, "Max length exceed 3"),
            otherwise: Yup.string()
              .test("NoValid", "NoValid", () => {
                setValue("txtOptionStaticLimit2", "");
                return true;
              })
              .nullable(),
          })
          .nullable()
        : Yup.string().nullable(),
  });
}

export const DateCoversion = (date) => {
  let dateTime = new Date(date);
  let dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + dateTime.getDate() + "T" + (dateTime.getHours() < 10 ? "0" : "") + dateTime.getHours() + ":" + (dateTime.getMinutes() < 10 ? "0" : "") + dateTime.getMinutes();
  let splitdate = dateTimeString.split("-")[2][1] == "T" ? dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-0" + dateTime.getDate() + "T" + (dateTime.getHours() < 10 ? "0" : "") + dateTime.getHours() + ":" + (dateTime.getMinutes() < 10 ? "0" : "") + dateTime.getMinutes() : dateTimeString;
  return splitdate;
};

//Date only 
export const GetOnlyDate = (date) => {

  if (date) {
    let dateTime = new Date(date);
    let dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + dateTime.getDate() + "T" + (dateTime.getHours() < 10 ? "0" : "") + dateTime.getHours() + ":" + (dateTime.getMinutes() < 10 ? "0" : "") + dateTime.getMinutes();
    let BindDate = dateTimeString?.split("-")[2][1] == "T" ? dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-0" + dateTime.getDate()
      : dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + dateTime.getDate()
    dateTimeString;
    return BindDate;
  }
};





export default validationSchema;