import NVLDynamicLanguageFile from "@components/Controls/NVLDynamicLanguageFile";
import NVLDynamicLanguageText from "@components/Controls/NVLDynamicLanguageText";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLWarning from "@components/Controls/NVLWarning";
import { yupResolver } from "@hookform/resolvers/yup";
import { DynamicFileLanguageValidation, DynamicTextLanguageValidation } from "@Pages/ActivityManagement/CommonActivitySettings/CommonFunction";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, ReactTagsButton } from "./ActivityComponents";
export const VideoActivity = ({ ErrorRef, UnSavedtoSaved, LanguageType, FinalResponse, query, props, ButtonClassName, ButtonText, delimiters, CustomMessage, router, CurrentDiv, }) => {
    let initialFileValue = [{
        Language: "",
        FileName: "Select File",
        FilePath: "",
        path: "",
        PathChanged: false,
    }]
    let initialTextValue = [{ Language: "", TextURL: "" }]
    const [FileValues, setFileValues] = useState(initialFileValue);
    const [LangValues, setLangValue] = useState(initialTextValue);
    const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
    const validationSchema = Yup.object().shape({
        txtDuration: Yup.string()
            .transform((o, c) => (o === "" ? null : c))
            .matches(Regex("AllowNumbersWithDot"), "Invalid value")
            .nullable()
            .test("len", "Must be limit digits", (val, { createError }) => {
                let LimitedTime = 999;
                if (val == "0") {
                    return createError({
                        message: `Duration should be greater than zero.`,
                    });
                }
                if (val?.length == "1") {
                    return true;
                }

                else if (val > LimitedTime) {
                    return createError({
                        message: `Duration maximum limit exceed.`,
                    });
                }
                else if (parseInt(val) <= 0) {
                    return createError({ message: `Duration only positive values and more then zero` });
                }
                else {
                    return true;
                }
            }),
        /* Dynamic Language */
        FileLang: Yup.string(). when("rbIsURL",{
            is: "File",
            then: Yup.string().test("file_Error", "", (e, { createError }) => {
                let message = "";                message = DynamicFileLanguageValidation(e, "ddlVideo", FileValues);
                if (message != "") {
                    setValue("dynamicError", message)
                    return createError({ message: message });
                } else {
                    setValue("dynamicError", undefined)
                    return true;
                }
            }).nullable(),
            otherwise: Yup.string().test("file_Error", "", (e, { createError }) => {let message = "";
            message = DynamicTextLanguageValidation(e, "textVideoUrl", "ddlVideoUrl")
            if (message != "") {
                setValue("dynamicError", message)
                return createError({ message: message });
            } else {
                setValue("dynamicError", undefined)
                return true;
            }

        }).nullable(),
    }),
        /* Video && Survey*/
        rbIsURL: Yup.string().required("Attach type is required").nullable().test("", "", (e) => {
            ResetLanguage();
            return true;
        }),
        /* Activity Completion */
        rbActivityCompletion: Yup.string()
            .required("Activity completion is required")
            .nullable()
            .test("error", "", (e, { createError }) => {
                if (e == "true") {
                    let array = ["chkViewTheActivity", "chkMarkTheActivity"];
                    let result = [];
                    array.map((item) => {
                        result.push(watch(item));
                    });
                    if (result.indexOf(true) == -1) {
                        setValue("activitycompletionError", "At least one is required.")
                        return createError({ message: "At least one is required." });
                    } else {
                        setValue("activitycompletionError", undefined)
                        return true;
                    }
                } else {
                    setValue("chkViewTheActivity", null)
                    setValue("chkMarkTheActivity", null)
                    setValue("activitycompletionError", undefined)
                }
                return true;
            })
            .nullable(),
        
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), nativeValidation: false };
    const { register, handleSubmit, setValue, watch, formState, reset } = useForm(formOptions);
    const { errors } = formState;

    /*End Batch Update*/

    useEffect(() => {
        if (watch("rbIsURL") == undefined) {
            setValue("submit", false);
            let FileOrUrl = props.EditData?.InformationType == null || props.EditData?.InformationType == undefined ? "URL" : props.EditData?.InformationType?.toString()
            setValue("txtDuration", props.EditData?.ActivityDuration);
            setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion?.toString() == null || props.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : props.EditData?.IsActivityCompletion?.toString());
            setValue("rbIsURL", FileOrUrl);
            setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
            setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);

            if (FileOrUrl == "File") {
                if (props?.EditData?.AttachFiles != null && JSON.parse(props?.EditData?.AttachFiles).length > 0) {
                    setFileValues([...JSON.parse(props?.EditData?.AttachFiles)])
                }
            } else {
                if (props?.EditData?.AttachFiles != null && JSON.parse(props?.EditData?.AttachFiles).length > 0) {
                    setLangValue([...JSON.parse(props?.EditData?.AttachFiles)])
                }
            }
        }
    }, [props, setValue, watch])

    const ResetLanguage = () => {
        if (watch("rbIsURL") != "File") {
            setFileValues([{
                FileName: "Select File",
                FilePath: "Select File",
                path: "",
                pathchanged: false,
            }]);
        } else {
            setLangValue([{
                Language: "",
                TextURL: "",
            }]);
        }

    }

    const handleDelete = useCallback(
        (i) => {
            setTags(tags.filter((tag, index) => index !== i));
            setValue("ReactTags", "Delete", { shouldValidate: true });
        },
        [setTags, setValue, tags]
    );

    const handleAddition = useCallback(
        (tag) => {
            setTags([...tags, tag]);
            setValue("ReactTags", "Add", { shouldValidate: true });
        },
        [setTags, setValue, tags]
    );

    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags, setTags]
    );
    
    const submitHandler = async (data) => {
        setValue("submit", true);
        let PK, SK;
        if (props.mode == "ModuleDirect") {
            PK = "TENANT#" + props.TenantInfo.TenantID;
            SK = props.EditData.SK
        } else if (props.mode == "Edit") {
            PK = "TENANT#" + props.TenantInfo.TenantID;
            SK = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
        }
        let MultilangFiles = [];

        if (watch("rbIsURL") == "File") {
            MultilangFiles = await UnSavedtoSaved(FileValues);
        } else {
            LangValues?.map((e, index) => {
                MultilangFiles = [...MultilangFiles, { Language: watch("ddlVideoUrl" + index), TextURL: watch("textVideoUrl" + index) }]
            });
        }
        let temp = { ...props.EditData }
        delete temp["FileProcessing"]
        let VideoVariables = {
            input: {
                PK: PK,
                SK: SK,
                InformationType: data.rbIsURL,
                ActivityDuration: data.txtDuration,
                IsAttachVideo: data.rbAttachVideo,
                AttachFiles: JSON.stringify(MultilangFiles),
                IsActivityCompletion: data.rbActivityCompletion,
                IsViewTheActivity: data.chkViewTheActivity != null ? data.chkViewTheActivity : false,
                IsMarkTheActivity: data.chkMarkTheActivity != null ? data.chkMarkTheActivity : false,
                Keywords: JSON.stringify(tags),
                ModifiedBy: props.user.username,
                ModifiedDate: new Date(),
            },
        };
        const groupBy = function (xs, key) {
            return xs.reduce(function (rv, x) {
                (rv[x[key]] = rv[x[key]] || []).push(x);
                return rv;
            }, {});
        }
        /*Batch Update*/
        let Query = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
        let pasteUrl = JSON.parse(props.EditData?.PasteURL != undefined ? props.EditData?.PasteURL : "[]");
        if (pasteUrl.length > 0) {
            pasteUrl = groupBy(pasteUrl, "FileName")
        }
        FileValues.map((data, index) => {
            if (data.FilePath != undefined) {
                let id = "ddlVideo";
                if (document.getElementById(id + index)?.options[document.getElementById(id + index)?.selectedIndex]?.value != pasteUrl?.[data.FileName]?.[0]?.Language) {
                    pasteUrl = { ...pasteUrl, [data.FileName]: [{ ...pasteUrl?.[data.FileName]?.[0], Language: document.getElementById(id + index)?.options[document.getElementById(id + index)?.selectedIndex]?.value }] }
                }
            }
        })
        let object = Object.keys(pasteUrl);
        let objectFileValues = Object.keys((groupBy(FileValues, "FileName")))
        let intersection = object.filter(x => !objectFileValues.includes(x));
        intersection.map((data) => {
            delete pasteUrl?.[data];
        })
        let pasteUrlFinal = [];
        Object.keys(pasteUrl).map(data => {
            pasteUrlFinal = [...pasteUrlFinal, ...pasteUrl?.[data]];
        })
        for (let i = 1; i <= props.EditData.Shard; i++) {
            UpdateBatch({
                inn: { ...temp, ...VideoVariables.input, PasteURL: JSON.stringify(pasteUrlFinal) },
                props: props,
                pk: "TENANT#" + props.EditData.TenantID + "#" + i,
                query: Query,
                UpdateData: props.EditData,
            });
        }

        let FinalStatus = (await AppsyncDBconnection(query, VideoVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
        setValue("submit", false);
        FinalResponse(FinalStatus);

    };

    useEffect(() => {
        if (!watch("rbIsURL")) {
            setValue("getFile", undefined);
        }
    }, [setValue, watch])


    return (
        <section>
            <form>
                <div id="divVideo" className={((props.EditData?.FileProcessing == undefined || props.EditData?.FileProcessing == 0) && (!watch("submit"))) ? " " : "block pointer-events-none"}>
                    {!(props.EditData?.FileProcessing == undefined || props.EditData?.FileProcessing == 0) && <NVLWarning Header={"In Processing!..."} Content={"Video file is processing, it will take some times"}></NVLWarning>}
                    <div className="container px-0 sm:px-12 mx-auto grid gap-8 ">
                        <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name: ${props.EditData.ActivityName}`}></NVLlabel>
                        <NVLlabel className="nvl-Def-Label " id="lblActivityType" text={`Activity Type: ${CurrentDiv}`} />
                        <div className="flex flex-col sm:flex-row gap-4">
                            <NVLlabel
                                id="lblDuration"
                                text="Duration(Min)"
                                className="nvl-Def-Label w-52">
                            </NVLlabel>
                            <NVLTextbox title="Min" id="txtDuration" className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register} />
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4 ">
                            <NVLlabel
                                className="nvl-Def-Label w-52"
                                text="Attach Type"
                            >
                                <span className="text-red-500 text-lg">*</span>
                            </NVLlabel>
                            <div className="gap-16">
                                <div className="flex gap-8 ">
                                    <NVLRadio text="Url" value={"URL"} name="rbIsURL" id="rbIsURL" errors={errors} register={register} />
                                    <NVLRadio text="Video" value={"File"} name="rbIsURL" id="rbIsURL" errors={errors} register={register} />
                                </div>
                                <div className={`${watch("rbIsURL") == "File" ? "hidden" : "nvl-Def-Input mt-3"}`}>
                                    <NVLDynamicLanguageText
                                        EditData={props.EditData}
                                        TenantInfo={props.TenantInfo}
                                        CurrentDiv={CurrentDiv}
                                        LangValues={LangValues}
                                        setLangValue={setLangValue}
                                        setValue={setValue}
                                        SelectFieldOptions={LanguageType}
                                        id="getFile"
                                        ValidateError={errors?.File?.message}
                                        LoaderId="loader"
                                        watch={watch}
                                        errors={errors}
                                        ddlLangId={"ddlVideoUrl"}
                                        ddlTextId={"textVideoUrl"}
                                        title={"Vimeo/YouTube/Streaming url"}
                                        ErrorMsg={ErrorRef}
                                        FileError={watch("dynamicError")}
                                        register={register} />
                                </div>
                                <div className={`${watch("rbIsURL") == "File" ? "nvl-Def-Input mt-3" : "hidden"}`} >
                                    <NVLDynamicLanguageFile
                                        ActivityType={props.ActivityType}
                                        ActivityID={props.ActivityID}
                                        EditData={props.EditData}
                                        TenantInfo={props.TenantInfo}
                                        CurrentDiv={CurrentDiv}
                                        mode={props.mode}
                                        FileValues={FileValues}
                                        setFileValues={setFileValues}
                                        setValue={setValue}
                                        SelectFieldOptions={LanguageType}
                                        id="getFile"
                                        ddlId="ddlVideo"
                                        ValidateError={errors?.File?.message}
                                        LoaderId="loader"
                                        watch={watch}
                                        errors={errors}
                                        register={register}
                                        FileError={watch("dynamicError")}
                                        HelpInfo="File size should be 1GB<br> Acceptable file format: avi, mov,mp4" />
                                </div>
                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4 ">
                            <NVLlabel className="nvl-Def-Label w-52" text="Activity Completion"></NVLlabel>
                            <div className="gap-16">
                                <ActivityCompletion register={register} errors={errors} watch={watch} />
                                <div className="mt-2">
                                    <CheckboxesInput
                                        CustomMessage={CustomMessage}
                                        register={register} errors={errors} watch={watch}
                                        IsViewTheActivity={true}
                                        IsMarkTheActivity={true}
                                        setValue={setValue}
                                    />
                                    <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"} >
                                        <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation"> {watch("activitycompletionError")}</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row  gap-4  ">
                            <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52" />
                            <div>
                                <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} props={props} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
                            </div>
                        </div>


                    </div>
                </div>
            </form>
        </section>
    );
}
export default VideoActivity;
