import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingIndicator from "@components/Controls/NVLLoadingIndicator";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import NVLMultiRichTextBox from "@Pages/ActivityManagement/CommonActivitySettings/NVLMultiRichTextBox";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import React, { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, ReactTagsButton } from "./ActivityComponents";
const RichTextBox = React.forwardRef((props, ref) => (<NVLMultiRichTextBox {...props} forwardedRef={ref} />));
RichTextBox.displayName = "RichTextBox"

export const PageActivity = ({ LanguageType, query, FinalResponse, props, ButtonClassName, ButtonText, delimiters, router }) => {
    const [loading, setLoading] = useState(false);
    const [getData, setData] = useState(1);
    const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
    const ref = useRef([{ ref: "", contents: "", language: "" }])
    const dynamicTextLanguageValidation = () => {
        const hasDuplicate = (arrayObj, colName) => {

            var hash = Object.create(null);
            return arrayObj.some((arr) => {
                return arr[colName] && (hash[arr[colName]] || !(hash[arr[colName]] = true));
            });
        };
        let errorResponse = "";
        let checkLang = [];
        let isErrorSatus = true;
        for (let index = 0; index < getData; index++) {
            let language = watch("ddlLanguageView" + index);
            if (ref.current[index]?.ref?.root?.innerHTML == undefined) {
                errorResponse = "LANGTEXT";
                isErrorSatus = false;
                break;
            }
            let textid = ref.current[index].ref.root.innerHTML == "" || ref.current[index].ref.root.innerHTML.replaceAll(/(<([^>]+)>)/gi, "")
            checkLang = [...checkLang, { lang: language }]
            if ((language == "" || language == undefined) && (textid == "" || textid == undefined)) {
                errorResponse = "LANGTEXT";
                isErrorSatus = false;
                break;
            }
            else if (textid == "" || textid == undefined) {

                errorResponse = "TEXT";
                isErrorSatus = false;
                break;
            }
            else if (language == "" || language == undefined) {
                errorResponse = "LANG";
                isErrorSatus = false;
                break;
            }
        }

        if (hasDuplicate(checkLang, "lang")) {
            errorResponse = "LANGEXISTS";
        }
        else if (errorResponse == "ERROR") {
            return errorResponse;
        }
        else if (isErrorSatus) {
            errorResponse = "sucess";
        }
        if (errorResponse != watch("RichTextBox")) {
            setValue("RichTextBox", errorResponse, { shouldValidate: true })
        }
        return errorResponse
    };
    const handleAddition = useCallback((tag) => {
        setTags([...tags, tag]);
        setValue("ReactTags", "Add", { shouldValidate: true });
    }, [setValue, tags]);

    const handleDelete = useCallback((i) => {
        setTags(tags.filter((tag, index) => index !== i));
        setValue("ReactTags", "Delete", { shouldValidate: true });
    }, [setValue, tags]);

    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags]
    );
    const validationSchema = Yup.object().shape({
        RichTextBox: Yup.string().test("Empty", "Hello", (e, { createError }) => {
            let errorName = dynamicTextLanguageValidation(), message = "";
            if (errorName == "LANGEXISTS") {
                message = "Language is already exists.";
            } else if (errorName == "LANG") {
                message = "Language is required.";
            } else if (errorName == "TEXT") {
                message = "Page Content is required.";
            } else if (errorName == "LANGTEXT") {
                message = "Language and Page Content is required.";
            }
            if (message != "") {
                return createError({ message: message });
            }
            return true;
        }),
        rbActivityCompletion: Yup.string().required("Activity completion is required").nullable().test("error", "At least one is required.", (e) => {
            if (e == "true") {
                let array = ["chkViewTheActivity", "chkMarkTheActivity"];
                let result = [];
                array.map((item) => {
                    result.push(watch(item));
                });
                if (result.indexOf(true) == -1) {
                    return false;
                } else {
                    return true;
                }
            } else {
                if (watch("chkViewTheActivity"))
                    setValue("chkViewTheActivity", false, { shouldValidate: true })
                if (watch("chkMarkTheActivity"))
                    setValue("chkMarkTheActivity", false, { shouldValidate: true })
            }
            return true;
        }),
        chkViewTheActivity: Yup.bool().nullable().test("e", "", e => {
            if ((e || watch("chkMarkTheActivity")) && watch("rbActivityCompletion") == "true" && errors.rbActivityCompletion?.message != undefined) {
                setValue("rbActivityCompletion", "true", { shouldValidate: true })
            }
            else if ((!e && !watch("chkMarkTheActivity")) && watch("rbActivityCompletion") == "true" && errors.rbActivityCompletion?.message == undefined) {
                setValue("rbActivityCompletion", "true", { shouldValidate: true })
            }
            return true;
        }),
        chkMarkTheActivity: Yup.bool().nullable(),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true, };
    const { register, handleSubmit, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;
    const updateref = useCallback((contents, language, index) => {
        setValue("ddlLanguageView" + (index), language, { shouldValidate: true })
        ref.current[index] = { ...ref.current[index], contents: contents.replace(/&nbsp;/g, ' '), language: language };
    }, [setValue])
    const func = useCallback(async () => {
        if (props.EditData != undefined && props.EditData.AttachFiles != undefined) {
            let json = JSON.parse(props.EditData.AttachFiles);
            json.map(async (element, index) => {
                let Contents_Promise = await fetch(
                    process.env.APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE + "?ObjectUrl=" + encodeURIComponent(element.FilePath) + "&S3BucketName=" + props.TenantInfo?.BucketName +
                    "&S3KeyName=" + props.TenantInfo?.RootFolder + "/" +
                    props.TenantInfo?.TenantID,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/text",
                            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                            defaultrole: props.TenantInfo.UserGroup,
                            groupmenuname: "SiteConfiguration",
                            menuid: "601302"
                        },
                    }
                );
                let temp = await Contents_Promise.text();
                updateref(temp, element.Language, index)
                if (index == json.length - 1) {
                    setLoading(true);
                }
            })
            setData((data) => {
                return json.length;
            })
        }
        else {
            setLoading(true);
        }

    }, [props.EditData, props.TenantInfo?.BucketName, props.TenantInfo?.RootFolder, props.TenantInfo?.TenantID, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, updateref])



    /*End Batch Update*/
    useEffect(() => {
        const a = async () => {
            setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion == null ? "false" : props.EditData?.IsActivityCompletion?.toString());
            setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
            setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
            await func();
        }
        a();
    }, [func, props.EditData?.IsActivityCompletion, props.EditData?.IsMarkTheActivity, props.EditData?.IsViewTheActivity, setValue])
    const submitHandler = async (data) => {
        setValue("submit", true);
        setValue("SaveLoader", true);
        let final = [], PK, SK;;
        for (let i = 0; i < ref.current.length; i++) {
            let fetchURL = process.env.APIGATEWAY_SAVEPAGECONTENT + `?ActivityID=${props.ActivityID}&ActivityType=${props.ActivityType}&BucketName=${props.TenantInfo.BucketName}&Language=${watch("ddlLanguageView" + i)}&RootFolder=${props.TenantInfo.RootFolder}&TenantId=${props.TenantInfo.TenantID}`;
            let options = {
                method: "POST",
                headers: {
                    authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    defaultrole: props.TenantInfo.UserGroup,
                    groupmenuname: "ActivityManagement",
                    menuid: "500005"
                },
                body: ref.current[i].ref.root.innerHTML
            }
            let finalStatus = await APIGatewayPostRequest(fetchURL, options);
            let temp = await finalStatus?.res?.text();
            final = [...final, { FilePath: temp, Language: watch("ddlLanguageView" + i) }]
        }
        if (props.mode == "ModuleDirect") {
            PK = "TENANT#" + props.TenantInfo.TenantID;
            SK = props.EditData.SK
        } else if (props.mode == "Edit") {
            PK = "TENANT#" + props.TenantInfo.TenantID;
            SK = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
        }
        let pageVariables = {
            input: {
                ...props.EditData,
                PK: PK,
                SK: SK,
                AttachFiles: JSON.stringify(final),
                TenantID: props.TenantInfo.TenantID,
                TenantName: props.TenantDisplayName,
                IsActivityCompletion: data.rbActivityCompletion,
                IsViewTheActivity: data.chkViewTheActivity != null ? data.chkViewTheActivity : false,
                IsMarkTheActivity: data.chkMarkTheActivity != null ? data.chkMarkTheActivity : false,
                Keywords: JSON.stringify(tags),
                ModifiedBy: props.user.username,
                ModifiedDate: new Date(),
            },
        };
        /*Batch Update*/
        let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
        for (let i = 1; i <= props.EditData.Shard; i++) {
            UpdateBatch({
                inn: pageVariables.input,
                props: props,
                pk: "TENANT#" + props.EditData.TenantID + "#" + i,
                query: queryBatch,
                UpdateData: props.EditData,
            });
        }
        /*Batch Update*/
        pageVariables = {
            input: {
                PK: PK,
                SK: SK,
                AttachFiles: JSON.stringify(final),
                TenantID: props.TenantInfo.TenantID,
                TenantName: props.TenantDisplayName,
                IsActivityCompletion: data.rbActivityCompletion,
                IsViewTheActivity: data.chkViewTheActivity != null ? data.chkViewTheActivity : false,
                IsMarkTheActivity: data.chkMarkTheActivity != null ? data.chkMarkTheActivity : false,
                Keywords: JSON.stringify(tags),
                ModifiedBy: props.user.username,
                ModifiedDate: new Date(),
            },
        };
        let finalStatus = (await AppsyncDBconnection(query, pageVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
        setValue("submit", false);
        setValue("SaveLoader", true);
        FinalResponse(finalStatus);
    };
    function addCustomFields() {
        let temp = dynamicTextLanguageValidation();
        if (temp == "sucess") {
            setData((data) => {
                return data + 1;
            })
            ref.current = [...ref.current, { ref: "", contents: "", language: "" }]
        }
    }
    function deleteField(index) {
        if (!(index == 0 && ref.current.length == 1)) {
            for (var i = index; i < ref.current.length - 1; i++) {
                setValue("ddlLanguageView" + i, watch("ddlLanguageView" + (i + 1)));
                ref.current[i].contents = ref.current[i + 1].ref.root.innerHTML;
                const delta = ref.current[i].ref.clipboard.convert(ref.current[i].contents);
                ref.current[i].ref.setContents(delta, "silent");
            }
            ref.current.splice(ref.current.length - 1, 1);
            setValue("ddlLanguageView" + (ref.current.length), "",{shouldValidate:true})
            setData((data) => {
                return data - 1;
            })
        }
    }


    return (
        <>  {loading ? (
            < section >
                <form>
                    <div id="divPage" className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}  >
                        <div className="container px-0 sm:px-12 mx-auto grid gap-8 ">
                            <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name: ${props.EditData.ActivityName}`}></NVLlabel>
                            <NVLlabel className="nvl-Def-Label " text={`Activity Type : Page`} />
                            <div className="">
                                <NVLlabel text="Page Content" className="nvl-Def-Label w-52"></NVLlabel>
                                {ref.current.map((element, index) => {
                                    return (
                                        <div className="p-3" key={index}>
                                            <NVLSelectField id={"ddlLanguageView" + index} className="w-44" options={LanguageType} errors={errors} register={register} />
                                            <RichTextBox watch={watch} setValue={setValue} index={index} ref={ref} />
                                            <div className={`${index == 0 ? "hidden " : "justify-end flex p-1"}`}>
                                                <NVLlabel key={index} className={`relative  cursor-pointer h-8 w-8 shadow-lg bg-red-100   inline-block text-red-600  rounded-full `} id="todo__delete" onClick={(e) => deleteField(index)} >
                                                    <i className="fa-solid fa-trash absolute top-2.5 left-2.5 text-sm"></i>
                                                </NVLlabel>
                                            </div>

                                        </div>)
                                })}
                                <div id="add" className={`grid gap-4 absolute-right-20 bottom-8`}>
                                    <NVLlabel onClick={() => addCustomFields()} className="cursor-pointer text-xs  bg-blue-100  shadow-lg text-blue-600 font-bold rounded-full h-8 w-8">
                                        <i className="fa-solid fa-plus relative left-2.5 top-2 text-sm"></i>
                                    </NVLlabel>
                                </div>
                                <div className="{invalid-feedback} text-red-500 text-sm pt-2">
                                    {errors?.RichTextBox?.message}
                                </div>

                            </div>
                            <div className="flex flex-col sm:flex-row gap-4 pt-8">
                                <NVLlabel text="Activity Completion" className="nvl-Def-Label w-52"></NVLlabel>
                                <div>
                                    <ActivityCompletion register={register} errors={errors} watch={watch} />
                                    <CheckboxesInput register={register} errors={errors} watch={watch} IsViewTheActivity={true} IsMarkTheActivity={true} setValue={setValue} />
                                    <div className="{invalid-feedback} text-red-500 text-sm pt-2">
                                        {errors?.rbActivityCompletion?.message}
                                    </div>
                                </div>
                            </div>
                            <div className="flex flex-col sm:flex-row  gap-4  ">
                                <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52" />
                                <div>
                                    <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} props={props} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </section >
        ) : (
            <NVLLoadingIndicator
            />
        )}
        </>
    );
}
export default PageActivity;