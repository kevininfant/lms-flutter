import { createMeeting } from "@components/Common/ZoomMeeting";
import Container from "@components/Container/Container";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "@graphql/graphql/mutations";
import { getXLMSThirdPartyApplication, listXlmsCourseModule, listXlmsUserInfos } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { APIGatewayGetRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, DateTime, RadioInputs, ReactTagsButton } from "./ActivityComponents";


export const MeetingActivity = ({ DateCoversion, FinalResponse, query,
    props, CurrentDiv, router }) => {

    const repeatNumber = useCallback((temp) => {
        let count = [{ value: "", text: "Select" }];
        let displayNumber;
        if (temp == "Daily") {
            checkedDayName.current = [];
            displayNumber = 14;
        } else if (temp == "Weekly") {
            displayNumber = 11;
        } else if (temp == "Monthly") {
            checkedDayName.current = [];
            displayNumber = 1;
        }
        for (let i = 0; displayNumber >= i; i++) {
            count.push({ value: i == 0 ? 1 : i + 1, text: i + 1 })
        }
        return count;
    }, [])
    const checkedDayName = useRef(props?.EditData?.ReccuringOccursOn != null && JSON.parse(props?.EditData?.ReccuringOccursOn))
    const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
    const [Text, setText] = useState("")
    const [resetDropdown, setResetDropdown] = useState(props.EditData.Meetingtype != null ? props.EditData.Meetingtype : "");
    const [userDetails, setUserDetails] = useState();
    const [open2, setOpen2] = useState("");
    const [meetingOccurence, setmeetingOccurence] = useState("");
    let refDays = useRef();

    const ResetField = () => {
        setValue("ddlRepeat", "")
        setValue("ddlDays", "")
        setValue("ddlRoutine", "")
        setValue("ddlDayofweek", "")
        setValue("rbDay", "Day")
        setText("")
        setValue("txtEnddateAdd", "")
        clearErrors(["txtEnddateAdd"])
        clearErrors(["ddlRepeat", "Dropdown", "Checkbox"])
        Object.entries(checkedDayName.current)?.map((getItem) => {
            setValue(getItem[0], false)
        })
        setmeetingOccurence("")
    };

    const validateEmails = useCallback(async (emails) => {

        if (emails == "") return true;

        const emailArray = emails?.split(',');

        for (let i = 0; i < emailArray?.length; i++) {
            const email = emailArray[i]?.trim();
            const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!pattern?.test(email)) {
                return false;
            }
        }
        return true;
    }, [])

    const validationSchema = Yup.object().shape({
        // /* CheckBox Input */
        chkViewTheActivity: Yup.bool().default(false).nullable(),
        chkCompleteTheActivity: Yup.bool().default(false).nullable(),
        chkMarkTheActivity: Yup.bool().default(false).nullable(),
        chkSubmitTheActivity: Yup.bool().default(false).nullable(),
        ChkUserCreateReplies: Yup.bool().default(false).nullable(),
        chkdisplay: Yup.bool().default(false).nullable(),
        chkcopyright: Yup.bool().default(false).nullable(),
        /*Enable Host Validation*/
        txtalternativehost: Yup.string()
            .nullable()
            .notRequired().nullable(true).test("", "Alternate host should be mail format", (e) => {
                if (e?.length != undefined || e != "")
                    return validateEmails(e)
            }).test("", "", (e, { createError }) => {
                if (e == "") {
                    return true;
                } else if (e?.split(",")?.length > 10) {
                    return createError({ message: "Email limit exceed" })
                }

                let usersDetail = [];
                userDetails?.map((email) => {
                    usersDetail.push({ email: email?.EmailID })
                }, []);
                usersDetail = usersDetail.concat([{ email: Auth?.user?.attributes["email"] }])

                const unmatchedEmails = e?.split(',').filter((item) => !usersDetail?.some((e) => e?.email === item?.trim()));
                const matchedEmails = e?.split(',').filter((item) => usersDetail?.some((e) => e?.email === item?.trim()));

                let index = 0, newArr = [];
                if (matchedEmails?.length > 0) {
                    for (let i = 0; i < matchedEmails?.length - 1; i++) {
                        for (let j = i + 1; j < matchedEmails?.length; j++) {
                            if (matchedEmails[i]?.trim() === matchedEmails[j]?.trim()) {
                                newArr[index] = matchedEmails[i];
                                index++;
                            }
                        }
                    }
                } else {
                    const length = unmatchedEmails?.length;
                    for (let i = 0; i < length - 1; i++) {
                        for (let j = i + 1; j < length; j++) {
                            if (unmatchedEmails[i]?.trim() === unmatchedEmails[j]?.trim()) {
                                newArr[index] = unmatchedEmails[i];
                                index++;
                            }
                        }
                    }

                }
                if (newArr.length != 0) {
                    return createError({ message: "Duplicate emails are not allowed" })
                }

                if (unmatchedEmails?.length) {
                    return createError({ message: `Host ${unmatchedEmails} does not belong to this company` });
                }
                return true;
            }),

        chkIsRecurringWebinar: Yup.bool().nullable()
            .test("", "", (e) => {
                if (e == false) {
                    clearErrors(["ddlRecurring"])
                    setValue("ddlRecurring", "")
                    ResetField()
                }
                return true
            }),
        ddlRecurring: Yup.string().nullable()
            .when("chkIsRecurringWebinar", {
                is: true,
                then: Yup.string().nullable(true).required("Recurrence is required").test("", "Recurrence is required", (e) => {
                    if (e != resetDropdown) {
                        ResetField()
                        setResetDropdown(e);
                    }
                    let text;
                    if (e == "Daily") {
                        watch("rbMeetingOccurence") == "byDate" ? generateMeetingOccurrences("daily", watch("ddlRepeat")) : setmeetingOccurence(watch("ddlOccurences"))
                        text = watch("ddlRepeat") != "" ? `Every ${watch("ddlRepeat") == 1 ? "Day" :
                            watch("ddlRepeat") + " Days once,"} ` : ""

                    } else if (e == "Weekly") {
                        watch("rbMeetingOccurence") == "byDate" ? getWeekDayList() : setmeetingOccurence(watch("ddlOccurences"))
                        watch("rbMeetingOccurence") == "byDate" && validateOccurence();
                        let selectedDays = Object?.entries(checkedDayName?.current).filter((i) => { return i[1] == true });
                        const dayOrder = ['Sun', 'Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat'];

                        const selectedDaysMap = {};
                        selectedDays?.forEach((day) => {
                            const [dayName] = day;
                            selectedDaysMap[dayName] = true;
                        });

                        selectedDays.sort((a, b) => {
                            const indexA = dayOrder.indexOf(a[0]);
                            const indexB = dayOrder.indexOf(b[0]);
                            return indexA - indexB;
                        });
                        let sortedDayNames = selectedDays.filter((day) => selectedDaysMap[day[0]]).map((day) => day[0]);
                        text = watch("ddlRepeat") != "" ? `Every ${watch("ddlRepeat") == 1 ? "Week" : watch("ddlRepeat") + " Weeks "}  ${"on " + sortedDayNames.join(', ')}` : ""

                    } else if (e == "Monthly") {
                        if (watch("rbDay") == "Dayofweek") {
                            const startDate = new Date(watch("txtstdate")?.slice(0, 10));
                            const endDate = new Date(watch("txtEnddateAdd")?.slice(0, 10));
                            const targetDayOfWeek = parseInt(watch("ddlDayofWeek")) - 1;
                            const selectedWeek = parseInt(watch("ddlRoutine"));
                            const repeatedMonth = parseInt(watch("ddlRepeat"));


                            watch("rbMeetingOccurence") == "byDate" ? setmeetingOccurence(getOccurrencesInSelectedWeek(startDate, endDate, targetDayOfWeek, selectedWeek, repeatedMonth)) : setmeetingOccurence(watch("ddlOccurences"))
                            watch("rbMeetingOccurence") == "byDate" && validateOccurence();
                            let Days = ["Select", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
                            let Week = ["Select", "First", "Second", "Third", "Fourth", "Fifth"]
                            let Weektext = Week[watch("ddlRoutine")] != undefined ? Week[watch("ddlRoutine")] : "";
                            let Daytext = Days[watch("ddlDayofWeek")] != undefined ? Days[watch("ddlDayofWeek")] : ""
                            text = watch("ddlRepeat") != "" ? `Every ${watch("ddlRepeat") == 1 ? "Month" : watch("ddlRepeat") + " Months "} on ${watch("ddlRoutine") == "-1" ? "Last " + Daytext : Weektext + " " + Daytext}` : ""
                        } else {
                            watch("rbMeetingOccurence") == "byDate" ? getMonthlyOccurrenceDayCount() : setmeetingOccurence(watch("ddlOccurences"))
                            watch("rbMeetingOccurence") == "byDate" && validateOccurence();

                            text = watch("ddlRepeat") != "" ?
                                `Every ${watch("ddlRepeat") == 1 ? "Month" :
                                    watch("ddlRepeat") + " Months "} on 
                            ${(watch("ddlDays") ? watch("ddlDays") + " days once, " : "")}
                            ` : ""
                        }
                    } else if (e == "AnyTime") {
                        text = "Meet Anytime"
                    } else {
                        text = ""
                    }
                    setText(text)
                    return true
                })

            }),
        ddlRepeat: Yup.string().nullable()
            .when("chkIsRecurringWebinar", {
                is: true,
                then: resetDropdown != "AnyTime" ? Yup.string().required("Repeat every is required").nullable(true) : Yup.string().nullable()
            }),
        rbDay: Yup.string().nullable()
            .when("ddlRecurring", {
                is: "Monthly",
                then: Yup.string().nullable().test("", "", (e) => {
                    if (e == "Day") {
                        setValue("ddlRoutine", "")
                        setValue("ddlDayofWeek", "")
                    } else if (e == "Dayofweek") {
                        setValue("ddlDays", "")
                    }
                    return true
                })
            }),

        txtstdate: Yup.date()
            .required("Start Date is Required")
            .typeError("Start Date is required")
            .test("Check", "Activity can be created only for present and future date", (e) => {
                if (e == "" || e == undefined || e == null) {
                    return true;
                }
                else {

                    if (new Date(e) <= new Date(new Date().setMinutes(new Date().getMinutes() - 1))) {
                        return false;
                    }
                    else {
                        return true
                    }
                }
            }).nullable(true),
        txtEnddateAdd: Yup.string().nullable()
            .when(["ddlRecurring"], {
                is: (ddlRecurring) => { return ((ddlRecurring === 'Weekly' || ddlRecurring === 'Monthly' || ddlRecurring === 'Daily') && watch("rbMeetingOccurence") != "afterOccurence") },
                then: Yup.string().required("End Date is Required").typeError("End Date is required").test("error", "End Date must be greater than or equal to the start date", (date) => {

                    if (new Date(date) > new Date(watch("txtstdate"))) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }).nullable(),
            }).nullable(true),

        // /* Activity Completion */

        rbActivityCompletion: Yup.string()
            .required("Activity completion is required")
            .nullable()
            .test("error", "", (e, { createError }) => {
                setValue("rbActivityCompletion", "true")
                setValue("chkViewTheActivity", "true");

                return true;
                let array = ["chkViewTheActivity", "chkMarkTheActivity", "chkSubmitTheActivity",];
                if (e == "true") {
                    let result = [], Days = [];
                    array.map((item, index) => {
                        result.push(watch(item));
                        // refDays?.push(index);
                        // refDays.current = Days;
                    });
                    if (result.indexOf(true) == -1) {
                        setValue("activitycompletionError", "At least one field is required");
                        return createError({ message: "At least one is required." });
                    } else {
                        setValue("activitycompletionError", undefined);
                        return true;
                    }
                }
                else if (e == "false") {
                    array.map((item) => {
                        setValue("chkViewTheActivity", null);
                        setValue("chkSubmitTheActivity", null);
                        setValue("chkMarkTheActivity", null);
                        setValue("activitycompletionError", undefined);

                    });
                }

                return true;
            })
            .nullable(),

        // /* Tags */
        ReactTags: Yup.string()
            .test("testReactTags", "Keywords is Requried", (e) => {
                return true;
                if (e == "Add") {
                    return true;
                } else if (e == "Delete" && tags.length == 1 && props?.EditData?.Keywords == null) {
                    return false;
                }
                if (props?.EditData?.Keywords == null || tags.length == 0) {
                    return false;
                } else {
                    return true;
                }
            })
            .nullable(),

        txtDuration: Yup.string()
            .transform((o, c) => (o === "" ? null : c))
            .matches(Regex("AllowNumbersWithDot"), "Invalid value")
            .required("Duration is required")
            .nullable()
            .test("len", "Must be limit digits", (val, { createError }) => {
                let LimitedTime = 999;
                if (val == "0") {
                    return createError({
                        message: `Duration should be greater than zero.`,
                    });
                }
                if (val?.length == "1") {
                    return true;
                }

                else if (val > LimitedTime) {
                    return createError({
                        message: ` Maximum duration allows only 3 characters`,
                    });
                }
                else if (parseInt(val) <= 0) {
                    return createError({ message: `Duration only positive values and more then zero` });
                }
                else {
                    return true;
                }
            }),

        txtPassword:
            Yup.string()
                .nullable(true)
                .notRequired()
                .test("validateStrength", "", (e, { createError }) => {
                    if (e?.length != undefined && e != "") {
                        let strength = 0,
                            message = "Password Should Have ";
                        if (!e?.match(/\d+/g)) {
                            strength++;
                            message = message + "A Number";
                        }

                        if (!e?.match(/[A-Z]+/g)) {
                            strength++;
                            if (strength > 1) {
                                message = message + ", ";
                            }
                            message = message + "A Captial Letter";
                        }
                        if (!e?.match(/[a-z]+/g)) {
                            strength++;
                            if (strength > 1) {
                                message = message + ", ";
                            }
                            message = message + "A Small Letter";
                        }
                        if (!e.match(/[!@#$%&*))]+/g)) {
                            strength++;
                            if (strength > 1) {
                                message = message + ", ";
                            }
                            message = message + "A Special Character";
                        }
                        if (e?.length < 5 || e?.length > 99) {
                            strength++;
                            if (strength > 1) {
                                message = message + ", ";
                            }
                            message = message + "Minimun password length 5";
                        }
                        if (e?.length > 99) {
                            strength++;
                            if (strength > 1) {
                                message = message + ", ";
                            }
                            message = message + "Maximum password length 99";
                        }
                        if (strength > 0) {
                            return createError({ message: message });
                        }
                    }
                    return true;
                }),
        rbHostVisible: CurrentDiv == "GoogleMeet" || CurrentDiv == "Zoom" || CurrentDiv == "MSTeams" ? Yup.string().nullable() : Yup.string().nullable(),
        rbParticipantsVideo: CurrentDiv == "GoogleMeet" || CurrentDiv == "Zoom" || CurrentDiv == "MSTeams" ? Yup.string().nullable() : Yup.string().nullable(),
        rbPreAssessment: CurrentDiv == "GoogleMeet" || CurrentDiv == "Zoom" || CurrentDiv == "MSTeams" ? Yup.string().nullable() : Yup.string().nullable(),
        rbPostAssessment: CurrentDiv == "GoogleMeet" || CurrentDiv == "Zoom" || CurrentDiv == "MSTeams" ? Yup.string().nullable() : Yup.string().nullable(),
        rbFeedback: CurrentDiv == "GoogleMeet" || CurrentDiv == "Zoom" || CurrentDiv == "MSTeams" ? Yup.string().nullable() : Yup.string().nullable(),
        rbaudiooption: CurrentDiv == "GoogleMeet" || CurrentDiv == "Zoom" || CurrentDiv == "MSTeams" ? Yup.string().nullable() : Yup.string().nullable(),
        Checkbox: Yup.bool().nullable()
            .when("ddlRecurring", {
                is: "Weekly",
                then: Yup.bool().nullable().test("", "At least one is required", (e) => {
                    let array = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"];
                    let result = [];
                    array.map((item) => {
                        result.push(watch(item));
                    });
                    if (result.indexOf(true) == -1) {
                        return false
                    } else {
                        clearErrors(["Checkbox"])
                        return true;
                    }
                })
            }),
        Dropdown: Yup.string().nullable()
            .when("ddlRecurring", {
                is: "Monthly",
                then: Yup.string().nullable().test("", "Choose a day", () => {
                    if (watch("rbDay") == "Dayofweek" && ((watch("ddlRoutine") == "" || watch("ddlDayofWeek") == ""))) {
                        return false
                    } else if (watch("rbDay") == "Day" && (watch("ddlDays") == "")) {
                        return false
                    } else {
                        clearErrors(["Dropdown"])
                        return true
                    }
                })
            }),

        ddlOccurences: Yup.string().nullable()
            .when("rbMeetingOccurence", {
                is: "afterOccurence",
                then: Yup.string().required("Occurence required").nullable(),
                otherwise: Yup.string().nullable()
            }).nullable()

    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, watch, formState, clearErrors, getValues, reset } = useForm(formOptions);
    const { errors } = formState;

    const keyCodes = { comma: 188, enter: 13, tab: 9, };
    const delimiters = useMemo(() => {
        return [keyCodes.comma, keyCodes.enter, keyCodes.tab];
    }, [keyCodes.comma, keyCodes.enter, keyCodes.tab]);

    const recurringType = useMemo(() => {
        let List = [
            { value: "", text: "Select" },
            { value: "Daily", text: "Daily" },
            { value: "Weekly", text: "Weekly" },
            { value: "Monthly", text: "Monthly" },
            { value: "AnyTime", text: "Any Time" }]
        return List;
    }, [])

    const PopupAlert = () => {
        // e.preventDefault();
        setOpen2("Zoom is not configured. Wish to navigate to configuration page?")
        return true;
    }

    const handleAddition = useCallback(
        (tag) => {
            setTags([...tags, tag]);
            setValue("ReactTags", "Add", { shouldValidate: true });
        },
        [setValue, tags]
    );
    const handleDelete = useCallback(
        (i) => {
            setTags(tags.filter((tag, index) => index !== i));
            setValue("ReactTags", "Delete", { shouldValidate: true });
        },
        [setValue, tags]
    );
    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags, setTags]
    );

    const repeatCount = useCallback((e) => {
        let count = [{ value: "", text: "Select" }];
        let displayNumber;
        if (e == "Daily") {
            displayNumber = 14;
        } else if (e == "Weekly") {
            displayNumber = 11;
        } else if (e == "Monthly") {
            displayNumber = 2;
        }
        for (let i = 0; displayNumber >= i; i++) {
            count.push({ value: i == 0 ? 0 : i + 1, text: i + 1 })
        }
    }, [])

    let pwShown = useRef(0);

    let a = { v: { value: "1", text: "bb" } }

    const iconOnclick = useCallback(() => {
        if (pwShown.current == 0) {
            pwShown.current = 1;
            document.getElementById("eye").classList.add("fa-eye-slash");
            document.getElementById("eye").classList.remove("fa-eye");
            hide();
        } else {
            pwShown.current = 0;
            document.getElementById("eye").classList.add("fa-eye");
            document.getElementById("eye").classList.remove("fa-eye-slash");
            show();
        }
    }, []);
    function show() {
        document.getElementById("txtPassword") != null
            ? document.getElementById("txtPassword").setAttribute("type", "text")
            : "";
    }
    function hide() {
        document.getElementById("txtPassword") != null
            ? document.getElementById("txtPassword").setAttribute("type", "password")
            : "";
    }

    useEffect(() => {
        if (props.mode == "ModuleDirect") {
            async function fetchData() {
                let zoomWise = await AppsyncDBconnection(listXlmsCourseModule, {
                    PK: "TENANT#" + props?.TenantInfo?.TenantID,
                    SK: "COURSEID#" + props.CourseID + "#MODULEID#" + props.ModuleID,
                    IsDeleted: false
                }, props.user.signInUserSession.accessToken.jwtToken);

                let zoomWiseActivity = zoomWise?.res?.listXlmsCourseModule?.items
                let PreAssessmentExistData = zoomWiseActivity?.filter((id) => (id.ZoomActivityID == props?.ActivityID && id.ActivityName?.includes("PreAssessment")))
                let PostAssessmentExistData = zoomWiseActivity?.filter((id) => (id.ZoomActivityID == props?.ActivityID && id.ActivityName?.includes("PostAssessment")))
                let FeedbackExistData = zoomWiseActivity.filter((id) => (id.ZoomActivityID == props?.ActivityID && id.ActivityName?.includes("Feedback")))
                if (PreAssessmentExistData?.length == 0) { setValue("rbPreAssessment", "false") }
                if (PostAssessmentExistData?.length == 0) { setValue("rbPostAssessment", "false") }
                if (FeedbackExistData?.length == 0) { setValue("rbFeedback", "false") }
            }
            fetchData()
        }
        setValue("txtDuration", props.EditData?.ActivityDuration);
        setValue("chkStartDateEnable", props.EditData?.IsStartDateEnable == null ? "true" : props.EditData?.IsStartDateEnable);
        setValue("txtstdate", DateCoversion(props.EditData?.StartDate) == "1970-01-01T05:30" || DateCoversion(props.EditData?.StartDate) == "NaN-NaN-NaNTNaN:NaN" ? undefined : DateCoversion(props.EditData?.StartDate));
        setValue("chkIsRecurringWebinar", props.EditData?.IsRecurring == null ? false : props.EditData?.IsRecurring);
        setValue("ddlRecurring", props.EditData?.Meetingtype)
        setValue("txtPassword", props.EditData?.Password, { shouldValidate: true });
        setValue("rbHostVisible", props.EditData?.IsHostVideo != null ? props.EditData?.IsHostVideo?.toString() : "false");
        setValue("rbParticipantsVideo", props.EditData?.IsParticipantsVideo != null ? props.EditData?.IsParticipantsVideo?.toString() : "false");
        setValue("rbPreAssessment", props.EditData?.IsPreAssessment != null ? props.EditData?.IsPreAssessment?.toString() : "false");
        setValue("rbPostAssessment", props.EditData?.IsPostAssessment != null ? props.EditData?.IsPostAssessment?.toString() : "false");
        setValue("rbFeedback", props.EditData?.IsFeedback != null ? props.EditData?.IsFeedback?.toString() : "false");
        setValue("rbaudiooption", props.EditData?.AudioOption != null ? props.EditData?.AudioOption?.toString() : "VOIP and Telephony");
        setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion != null ? props.EditData?.IsActivityCompletion.toString() : "false")
        setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
        setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
        setValue("chkCompleteTheActivity", props.EditData?.IsCompleteTheActivity);
        setValue("chkSubmitTheActivity", props.EditData?.IsSubmitTheActivity);
        setValue("chkmeetingoption", props.EditData?.IsEnableBeforeHost);
        setValue("txtalternativehost", props.EditData?.AlternativeHosts);
        setValue("ddlRepeat", props.EditData.ReccuringRepeatOn != null ? parseInt(props.EditData.ReccuringRepeatOn) : "");
        setValue("txtEnddateAdd", (DateCoversion(props.EditData.ReccuringEndDate) == "1970-01-01T05:30" || DateCoversion(props.EditData.ReccuringEndDate) == "NaN-NaN-NaNTNaN:NaN" || props.EditData?.Occurance) ? undefined : DateCoversion(props.EditData.ReccuringEndDate));
        setValue("ddlOccurences", props.EditData?.Occurance == 0 ? "" : props.EditData?.Occurance)
        setValue("rbMeetingOccurence", props.EditData?.Occurance ? "afterOccurence" : "byDate")

        if (props.EditData.ReccuringOccursOn != null && props.EditData?.Meetingtype == "Monthly") {
            setValue("ddlDays", JSON.parse(props.EditData.ReccuringOccursOn).Day != undefined ? JSON.parse(props.EditData.ReccuringOccursOn).Day : "")
            setValue("ddlRoutine", JSON.parse(props.EditData.ReccuringOccursOn).Week != undefined ? JSON.parse(props.EditData.ReccuringOccursOn).Week : "")
            setValue("ddlDayofWeek", JSON.parse(props.EditData.ReccuringOccursOn).DayofWeek != undefined ? JSON.parse(props.EditData.ReccuringOccursOn).DayofWeek : "")
            setValue("rbDay", JSON.parse(props.EditData.ReccuringOccursOn).Type != undefined ? JSON.parse(props.EditData.ReccuringOccursOn).Type : "Day")
        }
        if (props.EditData.ReccuringOccursOn != null && props.EditData?.Meetingtype == "Weekly") {

            Object?.entries(JSON?.parse(props.EditData.ReccuringOccursOn)).map((getItem) => {
                setValue(getItem[0], getItem[1])
            })
        }
    }, [DateCoversion, setValue, watch, repeatCount, props.mode, props.EditData?.ActivityDuration, props.EditData?.IsStartDateEnable, props.EditData?.StartDate, props.EditData?.IsRecurring, props.EditData?.Meetingtype, props.EditData?.Password, props.EditData?.IsHostVideo, props.EditData?.IsParticipantsVideo, props.EditData?.IsPreAssessment, props.EditData?.IsPostAssessment, props.EditData?.IsFeedback, props.EditData?.AudioOption, props.EditData?.IsActivityCompletion, props.EditData?.IsMarkTheActivity, props.EditData?.IsViewTheActivity, props.EditData?.IsCompleteTheActivity, props.EditData?.IsSubmitTheActivity, props.EditData?.IsEnableBeforeHost, props.EditData?.AlternativeHosts, props.EditData.ReccuringRepeatOn, props.EditData.ReccuringEndDate, props.EditData.ReccuringOccursOn, props?.TenantInfo?.TenantID, props.CourseID, props.ModuleID, props.user.signInUserSession.accessToken.jwtToken, props?.ActivityID, props.EditData?.Occurance])


    useEffect(() => {
        async function FetchData() {
            const userResponse = await AppsyncDBconnection(listXlmsUserInfos, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "#USERINFO#" }, props.user.signInUserSession.accessToken.jwtToken);
            setUserDetails(userResponse.res?.listXlmsUserInfos?.items);
            let ThridPartyData = await AppsyncDBconnection(getXLMSThirdPartyApplication, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "Zoom#" }, props.user.signInUserSession.accessToken.jwtToken);
            if (ThridPartyData?.res?.getXLMSThirdPartyApplication?.APIKey == null || ThridPartyData?.res?.getXLMSThirdPartyApplication?.APIKey == undefined) {
                PopupAlert()
            }
        }
        FetchData();
        return (() => {
            setUserDetails((temp) => { return { ...temp }; });
        });
    }, [props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken]);


    function getWeekDayList() {
        const startDate = watch("txtstdate") && new Date(Date.parse(new Date(watch("txtstdate"))?.toISOString()));
        const endDate = watch("txtEnddateAdd") && new Date(Date.parse(new Date(watch("txtEnddateAdd"))?.toISOString()));
        const obj = checkedDayName.current;
        const selectedDays = Object.keys(obj).filter(day => obj[day]);
        const repeatEvery = parseInt(watch("ddlRepeat")) || 1;

        const matchingDays = [];
        let currentDate = startDate;
        let occurrenceCount = 0;
        let weekCount = 0;

        while (currentDate <= endDate) {
            const dayOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat'][currentDate.getDay()];

            if (selectedDays.includes(dayOfWeek) && weekCount % repeatEvery === 0) {
                matchingDays.push(currentDate);
                occurrenceCount++;
            }
            currentDate.setDate(currentDate.getDate() + 1);

            if (currentDate.getDay() === 0) {
                weekCount++;
            }

            if (currentDate > endDate) {
                break;
            }
        }
        setText((prev) => prev + "," + occurrenceCount + " Occurrence");
        setmeetingOccurence(occurrenceCount);
    }

    // Function to generate meeting occurrences within a date range
    const generateMeetingOccurrences = useCallback((recurrencePattern, recurrenceDays) => {
        let startDate = new Date(new Date(watch("txtstdate")?.slice(0, 10)));
        let endDate = new Date(new Date(watch("txtEnddateAdd")?.slice(0, 10)));
        const occurrences = [];
        let currentDate = new Date(new Date(watch("txtstdate")?.slice(0, 10)));

        while (currentDate <= endDate) {
            if (currentDate >= startDate && currentDate <= endDate) {
                occurrences.push(currentDate.toISOString());
            }

            if (recurrencePattern === 'daily') {
                currentDate.setDate(currentDate.getDate() + parseInt(recurrenceDays))
            }
        }


        setText((prev) => prev + "," + ((watch("rbMeetingOccurence") == "byDate") ? occurrences.length : watch("ddlOccurences")) + ",Occurence")
        setmeetingOccurence(occurrences.length)
        return {
            occurrences,
            occurrenceCount: occurrences.length
        };
    }, [watch])


    function validateOccurence() {
        if (meetingOccurence == 0) {
            setValue("occurenceError", "not found");
            return false;
        } else {
            setValue("occurenceError", "");
        }
        return true;

    }
    const checkAnyDaysActive = useCallback(() => {
        const dayOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thur', 'Fri', 'Sat']
        let checkedDays = dayOfWeek?.filter((days) => {
            return watch(days)
        })

        return watch("rbMeetingOccurence") != "afterOccurence" ? checkedDays?.length : 1
    }, [watch])

    const submitHandler = async (data, SaveContent, NavigationHandler) => {
        if (meetingOccurence == 0) return false
        if (watch("ddlRecuring")) {
            if (!watch("ddlOccurences")) {
                if ((watch("errorOccurence") || meetingOccurence == 0)) return false
            }
            return true
        }
        setValue("submit", true)
        if (SaveContent != "Page") {
            NavigationHandler(SaveContent)
        }

        let pk, sk;
        if (props.mode == "ModuleDirect") {
            pk = "TENANT#" + props.TenantInfo.TenantID;
            sk = props.EditData.SK
        } else if (props.mode == "Edit") {
            pk = "TENANT#" + props.TenantInfo.TenantID;
            sk = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
        }

        let occursOnData;
        if (watch("ddlRecurring") == "Monthly") {
            if (data.rbDay == "Dayofweek") {
                occursOnData = { ...occursOnData, "Type": data.rbDay, "Week": data.ddlRoutine, "DayofWeek": data.ddlDayofWeek }
            } else {
                occursOnData = { ...occursOnData, "Type": data.rbDay, "Day": data.ddlDays }
            }
        } else if (watch("ddlRecurring") == "Weekly") {
            occursOnData = checkedDayName.current
        }

        let Start = new Date(data.txtstdate);
        let date = (Start.setMinutes(Start.getMinutes() + parseInt(data.txtDuration)))

        let today = new Date(date)
        let EndDateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate())
            + "T" + (today.getHours() < 9 ? "0" + today.getHours() : today.getHours()) + ":" + (today.getMinutes() < 9 ? "0" + today.getMinutes() : today.getMinutes());

        let meetvariables = {
            input: {
                PK: pk,
                SK: sk,
                TenantName: props.TenantInfo.TenantDisplayName,
                StartDate: data.txtstdate,
                IsStartDateEnable: data.chkStartDateEnable,
                IsEndDateEnable: data.chkEndDateEnable,
                EndDate: watch("rbMeetingOccurence") == "afterOccurence" ? "" : EndDateTime,
                ActivityDuration: data.txtDuration,
                IsRecurring: data.chkIsRecurringWebinar,
                Meetingtype: data.ddlRecurring,
                ReccuringOccursOn: JSON.stringify(occursOnData),
                ReccuringRepeatOn: data.ddlRepeat,
                ReccuringEndDate: data.txtEnddateAdd,
                Password: data.txtPassword,
                IsHostVideo: data.rbHostVisible,
                IsParticipantsVideo: data.rbParticipantsVideo,
                IsPreAssessment: data.rbPreAssessment,
                IsPostAssessment: data.rbPostAssessment,
                IsFeedback: data.rbFeedback,
                AudioOption: data.rbaudiooption,
                IsActivityCompletion: data.rbActivityCompletion,
                IsViewTheActivity: data.rbActivityCompletion == "true" ? data.chkViewTheActivity : false,
                IsCompleteTheActivity: data.rbActivityCompletion == "true" ? data.chkCompleteTheActivity : false,
                IsMarkTheActivity: data.rbActivityCompletion == "true" ? data.chkMarkTheActivity : false,
                IsSubmitTheActivity: data.rbActivityCompletion == "true" ? data.chkSubmitTheActivity : false,
                IsEnableBeforeHost: data.chkmeetingoption,
                AlternativeHosts: data.txtalternativehost,
                Occurance: watch("rbMeetingOccurence") == "afterOccurence" ? data?.ddlOccurences : "",
                Keywords: JSON.stringify(tags),
                ModifiedBy: props.user.username,
                ModifiedDate: new Date(),
            },
        };
        let finalStatus = (await AppsyncDBconnection(query, meetvariables, props.user.signInUserSession.accessToken.jwtToken)).Status;


        /*Batch Update*/
        let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
        for (let i = 1; i <= props.EditData.Shard; i++) {
            UpdateBatch({ UpdateData: props.EditData, inn: { ...props.EditData, ...meetvariables.input }, props: props, pk: "TENANT#" + props.EditData.TenantID + "#" + i, query: queryBatch });
        }

        if (finalStatus == "Success") {
            function getDays() {
                const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"];
                const objKeys = checkedDayName.current;
                const trueKeys = [];

                for (const key in objKeys) {
                    if (objKeys[key] === true) {
                        trueKeys.push(key);
                    }
                }
                const dayOfWeeksPosition = trueKeys.map((key) => {
                    let position = daysOfWeek.indexOf(key)
                    return position + 1;
                }
                );
                return dayOfWeeksPosition?.toString()
            }

            function getExactChooseDate(dateFromJson) {
                const isoDateString = dateFromJson;
                const dateToModify = new Date(Date.parse(new Date(isoDateString)));
                dateToModify.setUTCHours(dateToModify?.getHours(), dateToModify?.getMinutes());
                const updatedIsoDateString = dateToModify.toISOString();
                return updatedIsoDateString
            }

            const meetingDetails = {
                topic:
                    props.EditData.ActivityName,
                type:
                    !data.chkIsRecurringWebinar ? 2 : data.ddlRecurring == "AnyTime" ? 3 : 8,
                start_time:
                    getExactChooseDate(data?.txtstdate),
                duration:
                    data.txtDuration,
                timezone:
                    "IST",
                password:
                    data.txtPassword,
                agenda:
                    "Zoom Test",
                recurrence: {
                    type:
                        data.ddlRecurring == "Daily" ? 1 :
                            data.ddlRecurring == "Weekly" ? 2 :
                                data.ddlRecurring == "Monthly" ? 3 :
                                    3,
                    repeat_interval: watch("ddlRepeat"),
                    end_times:
                        (data.ddlRecurring != "AnyTime" && watch("rbMeetingOccurence") == "byDate") ? meetingOccurence :
                            watch("rbMeetingOccurence") != "byDate" ? watch("ddlOccurences") :
                                data.ddlRecurring == "Monthly" ? meetingOccurence :
                                    "",
                    end_date_time: watch("txtEnddateAdd") ? getExactChooseDate(data.txtEnddateAdd) : "",
                    monthly_day:
                        data.ddlRecurring == "Monthly" ? watch("ddlDays") : "",
                    monthly_week:
                        watch("ddlRoutine"),
                    monthly_week_day:
                        watch("ddlDayofWeek"),
                    weekly_days:
                        data.ddlRecurring == "Weekly" ? getDays() : ""
                },
                settings: {
                    host_video:
                        data.rbHostVisible,
                    participant_video:
                        data.rbParticipantsVideo,
                    join_before_host:
                        data.chkmeetingoption ?? false,
                    mute_upon_entry:
                        "false",
                    watermark:
                        "true",
                    waiting_room:
                        !data.chkmeetingoption ? true : false,
                    audio:
                        data.rbaudiooption == "Telephone Only" ? "telephony" :
                            data.rbaudiooption == "VOIP Only" ? "voip" : "both",
                    authentication_option:
                        data.txtPassword ? "1" : "0",
                    meeting_authentication:
                        data.txtPassword ? true : false
                }
            };

            let groupMenuName = props?.mode == "ModuleDirect" || props?.mode == "ModuleEdit" ? "CourseManagement" : "ActivityManagement";
            let menuId = props?.mode == "ModuleDirect" || props?.mode == "ModuleEdit" ? "300509" : "500014";
            const headers = { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, menuid: menuId, groupmenuname: groupMenuName, defaultrole: props.TenantInfo.UserGroup, };
            let ZoomResponse = await APIGatewayGetRequest(process.env.APIGATEWAY_ZOOM_TOKEN, { method: 'GET', headers: headers });
            const temp = await ZoomResponse?.res.text();
            let info;
            try {
                info = JSON.parse(temp);
            }
            catch {
                info = {};
            }
            let response = createMeeting({ token: info.access_token, meetingDetails: meetingDetails, meetingID: props.EditData?.MeetingID, mode: "create" })
            ZoomResponse = await response;
            let ZoomData = ZoomResponse && JSON.parse(ZoomResponse);
            let Zoomvariables = {
                input: {
                    PK: pk,
                    SK: sk,
                    JoinURL: ZoomData?.join_url,
                    HostURL: ZoomData?.start_url,
                    MeetingID: ZoomData?.id
                }
            }
            if (props.EditData?.MeetingID == null || props.EditData?.MeetingID == "null") {
                let final = await AppsyncDBconnection(query, Zoomvariables, props.user.signInUserSession.accessToken.jwtToken)
            }
        }

        if (SaveContent == "Page") {
            FinalResponse(finalStatus);
        }
        setValue("submit", false)
    };

    let dateTime = useMemo(() => {
        let today = new Date();
        let date = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T00:00:00";
        return date;
    }, [])

    const cancelClick = useCallback(() => {
        setOpen2("");
        if (props.mode == "Edit") {
            router.push(`/ActivityManagement/ActivityList`)
        } else {
            router.push(`/CourseManagement/ModulesList?CourseID=${router.query["CourseID"]}`)
        }
        return false;
    }, [props.mode, router])

    const NavigatetoConfig = useCallback(() => {
        if (props.mode == "Edit") {
            router.push(`/SiteConfiguration/ThirdPartyConfigApplication?ApplicationType=Zoom&ActivityID=${props?.ActivityID}`)
        } else {
            router.push(`/SiteConfiguration/ThirdPartyConfigApplication?ApplicationType=Zoom&CourseID=${router.query["CourseID"]}&ModuleID=${router.query["ModuleID"]}&ActivityID=${props?.ActivityID}`)
        }
    }, [props?.ActivityID, props.mode, router])

    const OccursOn = useCallback(() => {
        const days = ["Sun", "Mon", "Tue", "Wed", "Thur", "Fri", "Sat"]
        const dayDrop = [{ value: "", text: "Select" }];
        const count = [{ value: "", text: "Select" }]
        const week = [{ value: "", text: "Select" }]

        let daysCount = 30
        for (let i = 0; daysCount >= i; i++) {
            count.push({ value: i == 0 ? 1 : i + 1, text: (i + 1) })
        }
        let weekCount = ["First", "Second", "Third", "Fourth", "Last"];
        weekCount.map((item, index) => {
            week.push({ value: index == 0 ? 1 : item == "Last" ? -1 : index + 1, text: item })
        })
        let today = new Date();
        let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T00:00:00";

        return (<>

            {watch("ddlRecurring") == "Weekly" &&
                <>
                    <div>
                        <div className="flex">
                            {days.map((item, index) => {
                                return (<>
                                    <div key={index} className="px-2" >
                                        <NVLCheckbox id={item} register={register} errors={errors} text={item} name={item} onClick={(e) => { checkedDayName.current = { ...checkedDayName.current, [item]: e.target.checked } }} />
                                    </div>
                                </>)
                            })
                            }
                        </div>
                        <div className="{invalid-feedback} text-red-500 text-sm pt-2">
                            {errors?.Checkbox?.message}
                        </div>
                    </div>
                </>
            }
            {watch("ddlRecurring") == "Monthly" &&
                <>
                    <div>
                        <div className="flex gap-1">
                            <NVLRadio id="rbDay" name="rbDay" value="Day" register={register} errors={errors} />
                            <NVLlabel text="Day" className="nvl-Def-Label pt-2 px-1" />
                            <NVLSelectField id="ddlDays" options={count} register={register} errors={errors}
                                className={`w-60 ${watch("rbDay") != "Day" ? "Disabled nvl-mandatory" : "nvl-mandatory"}`} />
                            <NVLlabel text="of the month" className={`nvl-Def-Label pt-2 px-1`} />
                        </div>
                        <div className="flex gap-1 pt-2">
                            <NVLRadio id="rbDay" name="rbDay" value="Dayofweek" register={register} errors={errors} />
                            <NVLSelectField id="ddlRoutine" options={week} register={register} errors={errors}
                                className={`w-36 ${watch("rbDay") == "Day" ? "Disabled nvl-mandatory" : "nvl-mandatory"}`} />
                            {days.map((item, index) => {
                                dayDrop.push({ value: index + 1, text: item })
                            })}
                            <NVLSelectField id="ddlDayofWeek" options={dayDrop} register={register} errors={errors} className={`w-32 ${watch("rbDay") == "Day" ? "Disabled nvl-mandatory" : "nvl-mandatory"}`} />
                            <NVLlabel text="of the month" className="nvl-Def-Label pt-2 px-1" />
                        </div>
                        <div className="{invalid-feedback} text-red-500 text-sm pt-4 pl-7">
                            {errors?.Dropdown?.message}
                        </div>
                    </div>
                </>}
        </>
        )
    }, [errors, register, watch])

    const Occurences = useMemo(() => {
        const occurenceDatas = [{ value: "", text: "Select" }];
        for (let i = 1; i <= 20; i++) {
            occurenceDatas?.push({ value: i, text: i })
        }
        return occurenceDatas
    }, [])

    function occurenceHandler(handler) {
        setValue("rbMeetingOccurence", handler == "date" ? "byDate" : "afterOccurence");
        setValue(handler == "date" ? "ddlOccurences" : "txtEnddateAdd", handler == "date" ? "" : undefined)
        setText("")
    }

    function getMonthlyOccurrenceDayCount() {
        const startDate = new Date(watch("txtstdate")?.slice(0, 10));
        const endDate = new Date(watch("txtEnddateAdd")?.slice(0, 10));
        const targetDay = parseInt(watch("ddlDays"));
        const repeatMonth = parseInt(watch("ddlRepeat"));

        let currentDate = new Date(startDate);
        let occurrenceCount = 0;

        while (currentDate <= endDate) {
            const currentMonth = currentDate.getMonth();
            const currentDay = currentDate.getDate();

            if (currentDay === targetDay) {
                occurrenceCount++;
                currentDate.setMonth(currentMonth + repeatMonth);
            } else {
                currentDate.setDate(currentDay + 1);
            }
        }
        setmeetingOccurence(occurrenceCount);
    }

    function getLast7DaysSelectedDayCount(startDate, endDate, selectedDayOfWeek) {
        let currentDate = new Date(startDate);
        let occurrenceCount = 0;

        while (currentDate <= endDate) {
            const year = currentDate.getFullYear();
            const month = currentDate.getMonth();

            const lastDayOfMonth = new Date(year, month + 1, 0);

            const last7DaysStartDate = new Date(year, month, lastDayOfMonth.getDate() - 6);

            if (currentDate.getDay() === selectedDayOfWeek && currentDate >= last7DaysStartDate) {
                occurrenceCount++;
            }

            currentDate.setDate(currentDate.getDate() + 1);

            if (currentDate > endDate) {
                break;
            }
        }

        return occurrenceCount;
    }


    function getOccurrencesInSelectedWeek(startDate, endDate, targetDayOfWeek, selectedWeek, repeatedMonth) {
        let currentDate = new Date(startDate);
        let occurrenceCount = 0;

        while (currentDate <= endDate) {
            if (currentDate.getDay() === targetDayOfWeek) {
                const weekOfMonth = Math.ceil(currentDate.getDate() / 7);

                if (selectedWeek === -1 || weekOfMonth === selectedWeek) {
                    occurrenceCount++;
                }
            }

            currentDate.setDate(currentDate.getDate() + 1);

            if (currentDate > endDate) {
                break;
            }

        }
        occurrenceCount = selectedWeek == -1 ? getLast7DaysSelectedDayCount(startDate, endDate, targetDayOfWeek) : occurrenceCount;
        return occurrenceCount
    }

    return (
        <>
            <Container loader={watch("rbActivityCompletion") == undefined}>
                <section>
                    <form autoComplete="off">
                        <NVLModalPopup
                            ButtonYestext="Continue"
                            SubmitClick={() => NavigatetoConfig()}
                            CancelClick={(e) => cancelClick()}
                            ButtonNotext="Cancel"
                            CloseIconEvent={(e) => cancelClick()}
                            Content={open2} />
                        <div id="divGoogleMeet" className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}>
                            <div className="container px-0 sm:px-10 mx-auto grid gap-4">
                                <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name: ${props.EditData.ActivityName}`}></NVLlabel>
                                <NVLlabel className="nvl-Def-Label " id="lblActivityType" text={`Activity Type: ${CurrentDiv}`}></NVLlabel>
                                <div className="flex flex-col sm:flex-row gap-4">
                                    <NVLlabel text="Meeting" className="nvl-Def-Label w-52"><span className="text-red-500 text-lg">*</span></NVLlabel>
                                    <DateTime register={register} errors={errors} watch={watch} setValue={setValue} EndDate isMandatory={true} />
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 ">
                                    <NVLlabel className="nvl-Def-Label w-52" text="Activity Duration(min)"><span className="text-red-500 text-lg">*</span></NVLlabel>
                                    <NVLTextbox id="txtDuration" type="text" title={"Duration"} autoComplete="off" className="nvl-mandatory nvl-Def-Input" errors={errors} register={register} required></NVLTextbox>
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 ">
                                    <NVLlabel className="nvl-Def-Label w-52" text="Recurring Meeting"></NVLlabel>
                                    <div>
                                        <NVLCheckbox text={`Recurring Meeting ${Text}  ${meetingOccurence ? meetingOccurence + " Occurence(s)" : ""}`} showFull
                                            id="chkIsRecurringWebinar" value={true} errors={errors} register={register} />
                                    </div>
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 ">
                                    <NVLlabel className="nvl-Def-Label w-52" text="Recurrence">{watch("chkIsRecurringWebinar") && <span className="text-red-500 text-lg">*</span>}</NVLlabel>
                                    <div>
                                        <NVLSelectField id="ddlRecurring" className={`nvl-mandatory nvl-Def-Input ${!watch("chkIsRecurringWebinar") ? "Disabled" : ""}`}
                                            options={recurringType}
                                            disabled={!watch("chkIsRecurringWebinar") && true}
                                            errors={errors}
                                            register={register}
                                            showFull />
                                    </div>
                                </div>
                                <div className={`flex flex-col sm:flex-row gap-4 ${(watch("ddlRecurring") == "AnyTime" || watch("ddlRecurring") == "" || watch("ddlRecurring") == null) ? "hidden" : ""}`}>
                                    <NVLlabel className="nvl-Def-Label w-52" text="Repeat every"><span className="text-red-500 text-lg">*</span></NVLlabel>
                                    <div className="flex">
                                        <div>
                                            <NVLSelectField id="ddlRepeat" className={"nvl-mandatory nvl-Def-Input"}
                                                options={repeatNumber(resetDropdown)} errors={errors} register={register} showFull />
                                        </div>
                                        <NVLlabel className="nvl-Def-Label w-52 pt-2 px-2" text={watch("ddlRecurring") == "Daily" ? "day(s)" : watch("ddlRecurring") == "Monthly" ? "month(s)" : watch("ddlRecurring") == "Weekly" ? "week(s)" : ""}></NVLlabel>
                                    </div>
                                </div>
                                {(((meetingOccurence == 0) && watch("ddlRecurring") != "Daily" && checkAnyDaysActive() != 0 && watch("rbMeetingOccurence") != "afterOccurence") || (watch("ddlRecurring") == "Monthly") && meetingOccurence == 0) &&
                                    <div
                                        className={"{invalid-feedback} w-full text-red-500 text-sm flex translate-x-56"}>
                                        No occurrence in your selected time.
                                    </div>
                                }

                                <div className={`flex flex-col sm:flex-row gap-4 pb-4 ${(watch("ddlRecurring") && watch("ddlRecurring") != "AnyTime") ? "" : "hidden"}`}>
                                    <NVLlabel className="nvl-Def-Label w-52" id="lblgrade" text="End Date"></NVLlabel>
                                    <div className={`${watch("ddlRecurring") != "AnyTime" ? "" : "hidden"}`}>
                                        <div className={`flex gap-4 pb-2`}>
                                            <NVLRadio text={"By"} id={"rbMeetingOccurence"} value={"byDate"} name={"rbMeetingOccurence"}
                                                className={"checked:pointer-events-none"}
                                                errors={errors} register={register} onClick={() => occurenceHandler("date")}
                                            />
                                            <NVLTextbox title="End Date" id="txtEnddateAdd" type="datetime-local"
                                                className={`nvl-Def-Input !w-[331px] nvl-mandatory ${watch("rbMeetingOccurence") == "byDate" ? "" : "Disabled"}`}
                                                min={dateTime} errors={errors} register={register} setValue={setValue}></NVLTextbox>

                                        </div>
                                        <div className={`flex ${watch("ddlRecurring") != "AnyTime" ? "" : ""}`}>
                                            <NVLRadio id={"rbMeetingOccurence"} value={"afterOccurence"} name={"rbMeetingOccurence"}
                                                className={"checked:pointer-events-none"}
                                                errors={errors} register={register} onClick={() => occurenceHandler("occurence")} />
                                            <div className={`flex gap-1 items-center`}>
                                                <span className={"nvl-Def-Label"}>After</span>
                                                <NVLSelectField id="ddlOccurences" className={`nvl-mandatory w-60 
                                                ${watch("rbMeetingOccurence") == "afterOccurence" ? "" : "Disabled"}`}
                                                    options={Occurences} register={register} />
                                                <span className={"nvl-Def-Label"}>Occurences</span>

                                            </div>
                                        </div>
                                        <div className={"{invalid-feedback} w-full md:w-96 text-red-500 text-sm pl-14"}>
                                            {errors?.ddlOccurences?.message}
                                        </div>
                                    </div>
                                </div>

                                <div className="flex flex-col sm:flex-row gap-2 ">
                                    <NVLlabel text="Occurs on" className={`nvl-Def-Label w-52 ${(watch("ddlRecurring") == "" ||
                                        watch("ddlRecurring") == "Daily" || watch("ddlRecurring") == "AnyTime") ? "hidden" : ""}`} ><span className="text-red-500 text-lg">*</span></NVLlabel>
                                    {OccursOn()}
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 ">
                                    <NVLlabel text="Password" className="nvl-Def-Label w-52" ></NVLlabel>
                                    <div className="relative w-full">
                                        <NVLTextbox icon={true} title="Password" id="txtPassword" className="nvl-Def-Input nvl-non-mandatory !pr-8" required type="Password" pattern="[0-9]{1,3}" errors={errors} register={register}></NVLTextbox>
                                        <div className="absolute left-[355px] top-1 ">
                                            <i className="fa fa-eye-slash text-primary pr-2 pt-2 " id="eye" onClick={() => iconOnclick()}></i>
                                        </div>
                                        <div className={"{invalid-feedback} w-full md:w-96 text-red-500 text-sm "}>
                                            {errors?.txtPassword?.message}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 ">
                                    <NVLlabel
                                        className="nvl-Def-Label w-52"
                                        text="Settings"
                                    ></NVLlabel>
                                    <RadioInputs register={register} errors={errors} watch={watch} setValue={setValue} router={router} props={props} handleSubmit={handleSubmit} submitHandler={submitHandler} />
                                </div>

                                <div className="flex flex-col sm:flex-row gap-4 ">
                                    <NVLlabel className="nvl-Def-Label w-52" id="lblgrade" text="Activity Completion"></NVLlabel>
                                    <div className={`${watch("rbActivityCompletion") ? "pointer-events-none" : ""}`}>
                                        <ActivityCompletion register={register} errors={errors} watch={watch} setValue={setValue} IsZoom />
                                        <div className={`${watch("rbActivityCompletion") ? "pointer-events-none" : ""}`}>
                                            <CheckboxesInput IsZoom register={register} errors={errors} watch={watch} IsViewTheActivity={true}
                                                // IsSubmitTheActivity={true} 
                                                // IsMarkTheActivity={true} 
                                                setValue={setValue} />
                                        </div>
                                        <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"}>
                                            <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation">
                                                {watch("activitycompletionError")}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="flex flex-col sm:flex-row gap-4 ">
                                    <NVLlabel className="nvl-Def-Label w-52" id="lblgrade" text="Tags/Keywords"></NVLlabel>
                                    <div>
                                        <ReactTagsButton ButtonText="Submit" ButtonClassName={"nvl-button bg-primary text-white !w-40"} register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} props={props} submitHandler={submitHandler} router={router} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </section>
            </Container>
        </>
    );
}
export default MeetingActivity;