import Container from "@components/Container/Container";
import NVLAlert, { ModalClose, ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLCustomTxtBoxField from "@components/Controls/NVLCustomTxtBoxField";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsBatchTrainingManagement, createXlmsCourseQuizTemplate, createXlmsQuizTemplate, createXlmsTrainingQuizTemplate, updateXlmsCourseQuizTemplate, updateXlmsQuizTemplate, updateXlmsTrainingQuizTemplate } from "src/graphql/mutations";
import { getXlmsCourseQuizTemplateInfo, getXlmsQuizTemplateInfo, getXlmsTrainingManagement, getXlmsTrainingQuizTemplate, listXlmsLanguages } from "src/graphql/queries";
import * as Yup from "yup";

function AddQuestion(props) {
  const router = useRouter();
  const [submitRes, setSubmitRes] = useState()
  const [message, setMessage] = useState("");
  const [fetchQuizData, setFetchedQuizData] = useState(undefined);
  let initialModalState;

  const [currentDiv, setCurrentDiv] = useState();
  const mode = useMemo(() => { return router.query["Mode"] }, [router.query]);
  useEffect(() => {
    function bindData(fetchdata) {
      if (mode == "Edit" || mode == "ModuleEdit" || router?.query["Preview"] == "Preview" || fetchdata?.Edit == "Edit") {
        setValue("txtDefaultMarks", fetchdata?.Editdata?.DefaultMark, { shouldValidate: true, });
        setValue("txtQuestion", "NotEmpty", { shouldValidate: true });
        setValue("ddlQuestionType", fetchdata?.Editdata?.QuestionType, { shouldValidate: true, });
        setValue("ddlChoiceType", fetchdata?.Editdata?.NumberTheChoices);
        setValue("ddlLanguage", fetchdata?.Editdata?.Language, { shouldValidate: true, });
        if (fetchdata?.Editdata?.QuestionType == "MultipleChoice") {
          setValue("IsMultiChoicetype", fetchdata?.Editdata?.ChoiceType == null || fetchdata?.Editdata?.ChoiceType == undefined || fetchdata?.Editdata?.ChoiceType == "" ? "SingleAnswer" : fetchdata?.Editdata?.ChoiceType, { shouldValidate: true });
          let options = fetchdata?.Editdata && JSON.parse(fetchdata?.Editdata?.Options);
          options &&
            options?.map((data, index) => {
              if (data.Option != "" && data.Option != undefined && data.Option != "null") {
                setValue("txtOption" + index, data.Option);
                setValue("ddlPoints" + index, data.Grade);
              } else {
                setOptionLength(() => {
                  return 2;
                });
              }
              if (data.Feedback != "" && data.Feedback != undefined && data.Feedback != "null") {
                setValue("chkFeedback" + index, true, { shouldValidate: true });
                setValue("txtFeedback" + index, data.Feedback);
              }
            });
          setValue("ddlChoiceType", fetchdata?.Editdata?.NumberTheChoices == null || fetchdata?.Editdata?.NumberTheChoices == undefined || fetchdata?.Editdata?.NumberTheChoices == "" ? "a" : fetchdata?.Editdata?.NumberTheChoices);
          setValue("chkShuffleChoices", fetchdata?.Editdata?.IsShuffleWithInChoice);
        } else if (fetchdata?.Editdata?.QuestionType == "Ordering") {
          let optionlist = JSON.parse(fetchdata?.Editdata?.Options), field = fetchdata?.Editdata?.QuestionType == "Ordering" ? "txtFillTextfield" : "";
          optionlist.map((data, index) => {
            if (typeof data == "string") {
              setValue(field + index, data);
            } else {
              let opt;
              Object.values(data).map((item) => {
                opt = item;
                if (opt != "null") {
                  setValue(field + index, opt);
                } else {
                  setValue(field + index, "");
                  setOptionLength(() => {
                    return 2;
                  })
                }
              })
            }
          });
        } else if (fetchdata?.Editdata?.QuestionType == "Description") {
          let optionlist = JSON.parse(fetchdata?.Editdata?.Options), field = fetchdata?.Editdata?.QuestionType == "Description" ? "txtOption" : "";
          optionlist.map((data, index) => {
            if (data.Option != "" && data.Option != undefined && data.Option != "null") {
              setValue("txtOption" + index, data.Option);
              setValue("ddlPoints" + index, data.Grade);
            } else {
              setOptionLength(() => {
                return 2;
              });
            }
          });
        }
        else if (fetchdata?.Editdata?.QuestionType == "Match") {
          let optionlist = JSON.parse(fetchdata?.Editdata?.Options);
          optionlist.map((e, index) => {
            setValue("txtTextfield" + index, e[0]);
            setValue("txtTextfield" + "-" + index, e[1]);
          });
        }
        if (message != "") {
          setHTMLContents(fetchdata?.Editdata?.Question, message, { shouldValidate: true, });
          message?.history?.clear();
        }
      } else if (mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect") {
        setValue("IsMultiChoicetype", "SingleAnswer", { shouldValidate: true });
        setValue("ddlChoiceType", "a", { shouldValidate: true });
      }
      if (message != "") {
        message?.on("text-change", () => {
          if ((getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) && watch("txtQuestion") != "Empty") {
            setValue("txtQuestion", "Empty", { shouldValidate: true });
          } else if (watch("txtQuestion") != "NotEmpty" && !(getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0)) {
            setValue("txtQuestion", "NotEmpty", { shouldValidate: true });
          }
        });
      }
    }
    async function FetchData() {
      let tenantId = props?.TenantInfo?.TenantID
      let courseId = router.query["CourseID"];
      let moduleId = router.query["ModuleID"];
      let activityId = router.query["ActivityID"];
      let activityType = router.query["ActivityType"];
      let preview = router.query["Preview"];
      let questionId = router.query["QuestionID"];
      let languageCode = router.query["Language"];
      let recordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME" }, props.user.signInUserSession.accessToken.jwtToken);
      let query = mode == "ModuleEdit" ? getXlmsCourseQuizTemplateInfo : props?.mode == "TrainingDirect" ? getXlmsTrainingQuizTemplate : getXlmsQuizTemplateInfo;
      let sk = mode == "ModuleEdit" ? "COURSE#" + courseId + "#MODULE#" + moduleId + "#ACTIVITYID#" + activityId + "#LANGUAGE#" + languageCode + "#QUESTION#" + questionId : props?.mode == "TrainingDirect" ? "TRAINING#" + props?.TrainingId + "#ACTIVITYID#" + props?.ActivityID + "#LANGUAGE#" + languageCode + "#QUESTION#" + questionId : "ACTIVITYID#" + activityId + "#LANGUAGE#" + languageCode + "#QUESTION#" + questionId;
      const quizData = await AppsyncDBconnection(query, { PK: "TENANT#" + tenantId, SK: sk }, props.user?.signInUserSession?.accessToken?.jwtToken);
      let quizEditData;
      if (mode != "Create") { quizEditData = mode == "ModuleEdit" ? quizData?.res?.getXlmsCourseQuizTemplateInfo : props?.mode == "TrainingDirect" ? quizData?.res?.getXlmsTrainingQuizTemplate : quizData?.res?.getXlmsQuizTemplateInfo; }
      let trainingData
      if (props?.mode == "TrainingDirect" || router?.query["Edit"] == "Edit") {
        trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, { PK: "TENANT#" + tenantId, SK: "TRAININGINFO#" + props?.TrainingId }, props.user?.signInUserSession?.accessToken?.jwtToken);
      }

      let temp = {
        TrainingData: trainingData?.res?.getXlmsTrainingManagement,
        ActivityID: activityId,
        ActivityType: activityType,
        QuestionID: mode != "Create" && questionId,
        Preview: preview,
        Edit: router?.query["Edit"],
        LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
        Editdata: mode != "Create" && quizEditData,
        CourseID: (mode == "ModuleDirect" || mode == "ModuleEdit") && courseId,
        ModuleID: (mode == "ModuleDirect" || mode == "ModuleEdit") && moduleId,
      }
      bindData(temp)
      setFetchedQuizData((data) => { return temp })
      let initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
          if (watch("chkNew") == false) {
            if (mode == "ModuleDirect" || mode == "ModuleEdit") {
              if (router.query["ZoomActivityID"] != undefined) {
                router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);

              } else {
                router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}`);
              }
            } else if (props?.mode == "TrainingDirect") {
              if (router.query["Root"] == "TemplateList") {
                router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&AssessmentType=${props?.AssessmentType}&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&Settings=QuizList&Root=TemplateList`)
              } else {
                router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&AssessmentType=${props?.AssessmentType}&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&Settings=QuizList`)
              }
            } else {

              if (router.query["ZoomActivityID"] != undefined) {
                router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`);
              } else {
                router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`);
              }
            }
          }
          else {
            ModalClose();
            setCurrentDiv("Select")
            reset({ ddlQuestionType: "Select" });
            for (let i = 0; i < optionsLength; i++) {
              setValue("txtFillTextfield" + i, "")
              setValue("txtTextfield"+i,"")
              setValue("txtTextfield-"+i,"")
            }
          }
        },
      };
      setModalValues(initialModalState)
      let optionSize = quizEditData && JSON?.parse(quizEditData?.Options).length;
      if (optionSize) {
        setOptionLength(optionSize)
      }
    }
    FetchData();

    return (() => {
      setFetchedQuizData((temp) => { return { ...temp } })
    })

  }, [message, mode, optionsLength, props?.ActivityID, props?.AssessmentType, props?.TenantInfo?.TenantID, props?.TrainingId, props?.TrainingName, props?.mode, props.user.signInUserSession.accessToken.jwtToken, reset, router, router.query, setValue, watch])


  const [modalValues, setModalValues] = useState(initialModalState);

  const languageType = useMemo(() => {
    let languageType = [{ value: "", text: "Select" }];
    if (fetchQuizData != undefined) {
      if (Object?.keys(JSON?.parse(fetchQuizData?.LanguageName?.items[0]?.LanguageName != undefined ? fetchQuizData?.LanguageName?.items[0]?.LanguageName : "[]")) != undefined) {
        Object.entries(JSON.parse(fetchQuizData?.LanguageName?.items[0]?.LanguageName != undefined ? fetchQuizData?.LanguageName?.items[0]?.LanguageName : "[]")).forEach(([key, value]) => {
          languageType = [...languageType, { value: value, text: key }];
        })
      }
    };
    return languageType;
  }, [fetchQuizData]);

  const [optionsLength, setOptionLength] = useState(() => {
    let optionSize = 2;
    if (mode == "Edit" || mode == "ModuleEdit" || fetchQuizData?.Preview == "Preview")
      optionSize = fetchQuizData?.Editdata && JSON?.parse(fetchQuizData?.Editdata?.Options).length;
    return optionSize;
  });

  const Setoptions = useCallback((props) => {
    let tempJson = [];
    const RoundedOffData = (props.Points).map((a, index) => {
      tempJson = { "text": Math.round(parseInt(a["text"])) + "%", "value": String(Math.round(parseInt(a["value"]))) }
      return tempJson;
    })
    return (
      <>
        <div id={"field_div" + props?.id}>
          <div className="flex flex-col sm:flex-row gap-4 ">
            {props.CurrentDiv == "MultipleChoice" && <NVLlabel text={"Choice " + (props?.id + 1)} id={"lblChoice" + props?.id} className="nvl-Def-Label w-52">  <span className="text-red-500 text-lg">*</span></NVLlabel>}
            <div className="flex gap-8 ">
              <NVLTextbox className="w-64" title={"Choice " + (props?.id + 1)} id={"txtOption" + props?.id} errors={props?.errors} register={props.register} />
              <NVLSelectField id={"ddlPoints" + props?.id} options={RoundedOffData} className={"nvl-Def-Label w-24 nvl-mandatory"} errors={props?.errors} register={props.register}></NVLSelectField>
              {props.CurrentDiv == "MultipleChoice" && <NVLCheckbox className="my-auto" value={true} id={"chkFeedback" + props?.id} text={"Feedback"} errors={props?.errors} register={props.register}></NVLCheckbox>}
              <div className={`pt-2 ${props?.id > 1 ? "" : "hidden"}`}>
                <i className="fa-solid fa-trash text-red-600" onClick={() => { props.DeleteOption(props?.id, props?.totalItem); }}></i>
              </div>
            </div>
          </div>
          <div className={`pl-56 pt-4 ${props.watch != undefined ? (props.watch("chkFeedback" + props?.id) ? "" : "hidden") : ""}`}>
            {props.CurrentDiv == "MultipleChoice" && <NVLMultilineTxtbox id={"txtFeedback" + props?.id} title={"Feedback"} register={props.register}></NVLMultilineTxtbox>}
          </div>
        </div>
      </>
    );
  }, []);

  const addOption = useCallback(() => {
    setOptionLength((data) => {
      return data + 1;
    });
  }, []);

  let dynamicYupfields = {
    ["ddlQuestionType"]: Yup.string()
      .required("Select a type")
      .test("QuestionType_Handler", "", (e) => {
        if (e != currentDiv) {
          setCurrentDiv(e)
          setOptionLength(() => {
            return 2;
          });
          reset({ txtDefaultMarks: "", checkDefaultMarks: "error", ddlChoiceType: "a", IsMultiChoicetype: "SingleAnswer", chkShuffleChoices: false, chkNew: false, });
          if (message != "") setHTMLContents("", message);
        }
        return true;
      }),
    ["txtDefaultMarks"]: Yup.string()
      .typeError()
      .required("Default Marks is required")
      .matches(Regex("AllowOnlyNumbers"), "Only numeric values will be allowed")
      .max(3, "Default Marks should not exceed more than 3 characters")
      .test("Mark_check", "", (e, { createError }) => {
        let val = e;
        if (val == 0) {
          return createError({ message: "Default Marks cannot be Zero" });
        }
        else if (val < 0) {
          return createError({ message: "Negative marks cannot be allowed" });
        }
        return true;
      }),
    ["ddlLanguage"]: Yup.string().typeError().required("Language is required"),
    ["IsMultiChoicetype"]:
      currentDiv == "MultipleChoice"
        ? Yup.string().required("Multi Choice Type is required").nullable()
        : Yup.string().nullable(),
    ["checkDefaultMarks"]: Yup.string().test(
      "test",
      "Points are not equal to total",
      (e) => {
        if (currentDiv == "MultipleChoice" || currentDiv == "Description") {
          let positive = 0;
          for (let i = 0; i < optionsLength; i++) {
            if (watch("ddlPoints" + i) != undefined && parseInt(watch("ddlPoints" + i)) > 0) {
              positive += parseInt(watch("ddlPoints" + i));
            }
          }
          if (positive != 100 && positive > 0) {
            if (watch("checkDefaultMarks") != "error") {
              setValue("checkDefaultMarks", "error", { shouldValidate: true });
            }
            return false;
          } else if ((optionsLength > 0 && positive == 0)) {
            if (watch("checkDefaultMarks") != "error") {
              if (e == "NotInitial") {
                setValue("checkDefaultMarks", "error", { shouldValidate: true });
              }
            }
            return false;
          }
          else {
            if (watch("checkDefaultMarks") == "error") {
              setValue("checkDefaultMarks", "okay", { shouldValidate: true });
            }
            return true;
          }
        }
        return true;
      }
    ),
    ["txtQuestion"]: Yup.string().test(
      "CheckingRichTextBox",
      "Enter Question",
      (e) => {
        if (e == "Empty" || e == undefined) {
          return false;
        }
        return true;
      }
    ),
  };
  if (currentDiv == "MultipleChoice") {
    for (let i = 0; i < optionsLength; i++) {
      dynamicYupfields = {
        ...dynamicYupfields,
        ["txtOption" + i]: Yup.string().required("Option is required"),
        ["ddlPoints" + i]: Yup.string().required("Points is required"),
        ["chkFeedback" + i]: Yup.bool().test("novalid", "test", (e) => {
          if (!e && watch("txtFeedback" + i) != "") {
            setValue("txtFeedback" + i, "");
          }
          return true;
        }),
      };
    }
  } else if (currentDiv == "Ordering") {
    let field =
      currentDiv == "Ordering" ? "txtFillTextfield" : "";
    for (let i = 0; i < optionsLength; i++) {
      dynamicYupfields = {
        ...dynamicYupfields,
        [field + i]: Yup.string().required("Option is required"),

      };
    }
  }
  else if (currentDiv == "Description") {
    for (let i = 0; i < optionsLength; i++) {
      dynamicYupfields = {
        ...dynamicYupfields,
        ["txtOption" + i]: Yup.string().required("Choice is required"),
        ["ddlPoints" + i]: Yup.string().required("Points is required"),
      };
    }
  }
  else if (currentDiv == "Match") {
    for (let i = 0; i < optionsLength; i++) {
      dynamicYupfields = {
        ...dynamicYupfields,
        ["txtTextfield" + i]: Yup.string().required("Option is required"),
        ["txtTextfield" + "-" + i]: Yup.string().required("Option is required"),
      };
    }
  }
  const validationSchema = Yup.object().shape(dynamicYupfields);

  const points = useMemo(() => {
    return [
      { text: "0", value: "0" },
      { text: "5%", value: "5" },
      { text: "10%", value: "10" },
      { text: "20%", value: "20" },
      { text: "30%", value: "30" },
      { text: "40%", value: "40" },
      { text: "50%", value: "50" },
      { text: "60%", value: "60" },
      { text: "70%", value: "70" },
      { text: "80%", value: "80" },
      { text: "90%", value: "90" },
      { text: "100%", value: "100" },
      { text: "-5%", value: "-5" },
      { text: "-10%", value: "-10" },
      { text: "-20%", value: "-20" },
      { text: "-30%", value: "-30" },
      { text: "-40%", value: "-40" },
      { text: "-50%", value: "-50" },
      { text: "-60%", value: "-60" },
      { text: "-70%", value: "-70" },
      { text: "-80%", value: "-80" },
      { text: "-90%", value: "-90" },
      { text: "-100%", value: "-100" },
    ];
  }, []);
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, watch, formState, reset } = useForm(formOptions);
  const { errors } = formState;
  const questionType = useMemo(() => {
    return [
      { value: "Select", text: "Select" },
      { value: "MultipleChoice", text: "Multiple Choice" },
      { value: "FillInTheBlank", text: "Fill in the blank" },
      { value: "Ordering", text: "Ordering" },
      { value: "Match", text: "Match the Following" },
      { value: "Description", text: "Description" },
    ];
  }, []);
  const choiceType = useMemo(() => {
    return [
      { value: "a", text: "a.,b.,c.,d." },
      { value: "A", text: "A.,B.,C.,D." },
      { value: "i", text: "i.,ii.,iii.,iv." },
      { value: "I", text: "I.,II.,III.,IV." },
      { value: "No Numbering", text: "No Numbering" },
    ];
  }, []);

  const Options = useCallback((props) => {
    let rowGrid = [];
    for (let i = 0; i < props.Optionslength; i++) {
      rowGrid.push(
        <Setoptions id={i} Points={props.Points} watch={props.watch} DeleteOption={props.DeleteOption} register={props.register} CurrentDiv={props.CurrentDiv} totalItem={props.Optionslength} errors={props.errors} />
      );
    }

    return <>{rowGrid}</>;
  }, []);


  const deleteOption = useCallback((id) => {
    setOptionLength((data) => {
      for (let i = id; i < data - 1; i++) {
        setValue("txtOption" + i, watch("txtOption" + (i + 1)));
        setValue("ddlPoints" + i, watch("ddlPoints" + (i + 1)));
        setValue("chkFeedback" + i, watch("chkFeedback" + (i + 1)));
        setValue("txtFeedback" + i, watch("txtFeedback" + (i + 1)));
      }
      setValue("txtOption" + (data - 1), "");
      setValue("ddlPoints" + (data - 1), "0");
      return data - 1;
    });
  },
    [setValue, watch]
  );

  const DefaultMark = useCallback((props) => {
    return (
      <>
        <div className={`flex flex-col sm:flex-row gap-4 ${props.CurrentDiv == "MultipleChoice" ? " justify-center ml-20" : "justify-end"}`}>
          <NVLlabel className="nvl-Def-Label w-52" text=""></NVLlabel>
          <div className="grid gap-2">
            <NVLTextbox id="txtDefaultMarks" labelText="Default Marks" labelClassName="nvl-Def-Label" required className="nvl-mandatory w-28 nvl-Def-Label my-auto " register={props.register} errors={props.errors}></NVLTextbox>
          </div>
        </div>
      </>
    );
  }, []);

  const Language = useCallback((props) => {
    return (
      <div>
        <NVLSelectField
          id="ddlLanguage"
          options={props.LanguageType}
          className={`${props.Mode == "Edit" || props.Mode == "ModuleEdit"
            ? "Disabled w-44"
            : "nvl-mandatory w-44"
            }`}
          labelText="Select Language"
          labelClassName="nvl-Def-Label"
          required
          register={props.register}
          errors={props.errors}
        ></NVLSelectField>
      </div>
    );
  }, []);

  const Buttons = useCallback(() => {
    return (
      <>
        <div className="flex justify-center gap-8 pt-6">
          <NVLButton
            id="btnSave"
            text={"Submit"}
            type={"submit"}
            disabled={submitRes}
            className={`w-32 nvl-button bg-primary text-white  "nvl-button-light" `}
          ></NVLButton>
          <NVLButton
            id="btnCancel"
            text={"Cancel"}
            type="button"
            className={`nvl-button w-28 "nvl-button-light" `}
            onClick={() => {
              if (mode == "ModuleDirect" || mode == "ModuleEdit" && fetchQuizData != undefined) {
                if (router.query["ZoomActivityID"] != undefined) {
                  router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
                } else {
                  router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}`)
                }
              } else if (props?.mode == "TrainingDirect") {
                if (router.query["Root"] == "TemplateList") {
                  router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList&Root=TemplateList`);
                }
                else {
                  router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList`);
                }
              } else {
                if (router.query["ZoomActivityID"] != undefined) {
                  router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`);
                } else {
                  router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}`);
                }
              }
            }
            }
          ></NVLButton>
        </div>
      </>
    );
  }, [submitRes, mode, fetchQuizData, props?.mode, props?.ActivityID, props?.TrainingId, props?.AssessmentType, props?.TrainingName, router]);

  const submitHandler = async (data) => {
    document?.activeElement?.blur();
    setSubmitRes(true)
    let questionName = getContents(message),
      pk = "TENANT#" + props?.TenantInfo.TenantID,
      questionId = crypto.randomUUID(),
      sk = "ACTIVITYID#" + fetchQuizData?.ActivityID + "#LANGUAGE#" + data.ddlLanguage + "#QUESTION#" + questionId,
      variables = {};
    if (props?.mode == "TrainingDirect") {
      sk = "TRAINING#" + props?.TrainingId + "#ACTIVITYID#" + props?.ActivityID + "#LANGUAGE#" + data.ddlLanguage + "#QUESTION#" + questionId
    }
    if (mode == "Edit" || mode == "ModuleEdit" || fetchQuizData?.Edit == "Edit") {
      pk = fetchQuizData?.Editdata.PK;
      sk = fetchQuizData?.Editdata.SK;
      questionId = fetchQuizData?.Editdata?.QuestionID;
    }
    if (mode == "ModuleDirect") {
      pk = "TENANT#" + props?.TenantInfo.TenantID;
      sk = "COURSE#" + fetchQuizData?.CourseID + "#MODULE#" + fetchQuizData?.ModuleID + "#ACTIVITYID#" + fetchQuizData?.ActivityID + "#LANGUAGE#" + data.ddlLanguage + "#QUESTION#" + questionId;
    }
    if (currentDiv == "MultipleChoice") {
      let option = [];
      for (let i = 0; i < optionsLength; i++) {
        option = [
          ...option,
          {
            Option: data?.["txtOption" + i],
            Grade: data?.["ddlPoints" + i],
            Feedback: data?.["txtFeedback" + i],
          },
        ];
      }
      variables = props?.mode == "TrainingDirect" ? {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: questionName,
          DefaultMark: data.txtDefaultMarks,
          ChoiceType: data.IsMultiChoicetype,
          Options: JSON.stringify(option),
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          IsDeleted: false,
          CreatedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata?.CreateBy,
          CreatedDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata?.CreateDate,
          LastModifiedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata?.ModifyBy,
          LastModifiedDate: new Date(),
          IsShuffleWithInChoice: data.chkShuffleChoices,
          NumberTheChoices: data.ddlChoiceType,
        },
      } : {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: questionName,
          DefaultMark: data.txtDefaultMarks,
          ChoiceType: data.IsMultiChoicetype,
          Options: JSON.stringify(option),
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          IsDelete: false,
          CreateBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata?.CreateBy,
          CreateDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata?.CreateDate,
          ModifyBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata?.ModifyBy,
          ModifyDate: new Date(),
          IsShuffleWithInChoice: data.chkShuffleChoices,
          NumberTheChoices: data.ddlChoiceType,
        },
      };
    } else if (currentDiv == "FillInTheBlank") {
      let question = questionName.split('|')
      let questionarray = question.filter(function(str) {
        return /\S/.test(str);
     });

      variables = props?.mode == "TrainingDirect" ? {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: questionarray?.join("|"),
          DefaultMark: data.txtDefaultMarks,
          ChoiceType: data.IsMultiChoicetype,
          Options: JSON.stringify([]),
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          IsDeleted: false,
          CreatedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreatedDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          LastModifiedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          LastModifiedDate: new Date(),
          IsShuffleWithInChoice: data.chkShuffleChoices,
          NumberTheChoices: data.ddlChoiceType,
        },
      } : {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question:  questionarray?.join("|"),
          DefaultMark: data.txtDefaultMarks,
          ChoiceType: data.IsMultiChoicetype,
          Options: JSON.stringify([]),
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          IsDelete: false,
          CreateBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreateDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          ModifyBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          ModifyDate: new Date(),
          IsShuffleWithInChoice: data.chkShuffleChoices,
          NumberTheChoices: data.ddlChoiceType,
        },
      };
    } else if (currentDiv == "Ordering") {
      let textControl = [];
      for (let i = 0; i < optionsLength; i++) {
        textControl = [...textControl, data?.["txtFillTextfield" + i]];
      }
      variables = props?.mode == "TrainingDirect" ? {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: getContents(message),
          DefaultMark: data.txtDefaultMarks,
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          Options: JSON.stringify(textControl),
          IsDeleted: false,
          CreatedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreatedDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          LastModifiedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          LastModifiedDate: new Date()
        },
      } : {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: getContents(message),
          DefaultMark: data.txtDefaultMarks,
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          Options: JSON.stringify(textControl),
          IsDelete: false,
          CreateBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreateDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          ModifyBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          ModifyDate: new Date()
        },
      };
    } else if (currentDiv == "Match") {
      let textControl = [];
      for (let i = 0; i < optionsLength; i++) {
        textControl = [
          ...textControl,
          [data?.["txtTextfield" + i], data?.["txtTextfield" + "-" + i]],
        ];
      }
      variables = props?.mode == "TrainingDirect" ? {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: getContents(message),
          DefaultMark: data.txtDefaultMarks,
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          Options: JSON.stringify(textControl),
          IsDeleted: false,
          CreatedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreatedDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          LastModifiedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          LastModifiedDate: new Date()
        },
      } : {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: getContents(message),
          DefaultMark: data.txtDefaultMarks,
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          Options: JSON.stringify(textControl),
          IsDelete: false,
          CreateBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreateDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          ModifyBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          ModifyDate: new Date()
        },
      };
    } else if (currentDiv == "Description") {
      let option = [];
      for (let i = 0; i < optionsLength; i++) {
        option = [
          ...option,
          {
            Option: data?.["txtOption" + i],
            Grade: data?.["ddlPoints" + i],

          },
        ];
      }
      variables = props?.mode == "TrainingDirect" ? {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: getContents(message),
          DefaultMark: data.txtDefaultMarks,
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          Options: JSON.stringify(option),
          IsDeleted: false,
          CreatedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreatedDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          LastModifiedBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          LastModifiedDate: new Date()

        },
      } : {
        input: {
          PK: pk,
          SK: sk,
          QuestionID: questionId,
          Question: getContents(message),
          DefaultMark: data.txtDefaultMarks,
          QuestionType: data.ddlQuestionType,
          Language: data.ddlLanguage,
          Options: JSON.stringify(option),
          IsDelete: false,
          CreateBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.CreateBy,
          CreateDate:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? new Date()
              : fetchQuizData?.Editdata.CreateDate,
          ModifyBy:
            mode == "Create" || mode == "ModuleDirect" || props?.mode == "TrainingDirect"
              ? props?.user.username
              : fetchQuizData?.Editdata.ModifyBy,
          ModifyDate: new Date()
        },
      };
    }
    if (props?.mode == "TrainingDirect" || fetchQuizData?.Edit == "Edit") {
      let variable = {
        input: [{
          ...fetchQuizData?.TrainingData,
          SK: "TRAININGINFO#LASTMODIFIEDDATE#" + fetchQuizData?.TrainingData?.LastModifiedDate + "#TRAININGID#" + props?.TrainingId,
          IsDeleted: true,
          AutoDelete: Date.now() / 1000 + 24 * 60 | 0
        },
        { ...fetchQuizData?.TrainingData, QuestionandOptions: getContents(message) },
        { ...fetchQuizData?.TrainingData, QuestionandOptions: getContents(message), SK: "TRAININGINFO#LASTMODIFIEDDATE#" + new Date().toISOString() + "#TRAININGID#" + props?.TrainingId, }]
      }
      let finalResponse = (await AppsyncDBconnection(createXlmsBatchTrainingManagement, variable, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;

    }
    let finalVariables = (mode == "ModuleDirect" || mode == "ModuleEdit") ? { input: { ...variables.input, ModuleID: fetchQuizData?.ModuleID, CourseID: fetchQuizData?.CourseID, }, } : { input: { ...variables.input } };
    let query;
    if (mode == "Edit") {
      query = updateXlmsQuizTemplate;
    } else if (mode == "ModuleDirect") {
      query = createXlmsCourseQuizTemplate;
    } else if (mode == "ModuleEdit") {
      query = updateXlmsCourseQuizTemplate;
    } else if (props?.mode == "TrainingDirect") {
      query = createXlmsTrainingQuizTemplate;
    } else if (fetchQuizData?.Edit == "Edit") {
      query = updateXlmsTrainingQuizTemplate;
    } else {
      query = createXlmsQuizTemplate;
    }
    let finalStatus = (await AppsyncDBconnection(query, finalVariables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
    finalResponse(finalStatus);
    setSubmitRes(false)
  };

  const finalResponse = (finalStatus) => {
    if (finalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: finalStatus,
      });
      ModalOpen();
      return;
    } else {
      ModalOpen();
    }
  };
  let pageRoutes = [];
  if (mode == "ModuleEdit" || mode == "ModuleDirect") {
    if (router.query["ZoomActivityID"] != undefined) {
      pageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${fetchQuizData?.CourseID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}&ModuleName=${fetchQuizData?.Editdata?.ModuleName}`, breadcrumb: "Edit Activity Zoom" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}`, breadcrumb: "Edit Settings Zoom" },
        { path: `/CourseManagement/ModuleInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}&ModuleName=${fetchQuizData?.EditData?.ModuleName}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
        { path: `/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Question" },
        { path: "", breadcrumb: mode == "ModuleEdit" ? "Edit Question" : fetchQuizData?.Preview == "Preview" ? "Preview Question" : "Add New Question" }
      ];
    } else {
      pageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${fetchQuizData?.CourseID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}&ModuleName=${fetchQuizData?.Editdata?.ModuleName}`, breadcrumb: "Edit Activity" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}`, breadcrumb: "Edit Settings" },
        { path: `/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&CourseID=${fetchQuizData?.CourseID}&ModuleID=${fetchQuizData?.ModuleID}`, breadcrumb: "Question" },
        { path: "", breadcrumb: mode == "ModuleEdit" ? "Edit Question" : fetchQuizData?.Preview == "Preview" ? "Preview Question" : "Add New Question" }
      ];
    }
  } else if (props?.mode == "TrainingDirect" || props?.mode == "TrainingEdit") {
    if (router.query["Root"] == "TemplateList") {
      pageRoutes = [
        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "TrainingManagement" },
        { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${props?.TrainingID}&TrainingName=${props?.TrainingName}`, breadcrumb: "Training Template List" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Root=TemplateList`, breadcrumb: "Edit Activity" },
        { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Root=TemplateList`, breadcrumb: "Edit Settings" },
        { path: `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList&Root=TemplateList`, breadcrumb: "Question" },
        { path: "", breadcrumb: (mode == "Edit" && fetchQuizData?.Preview != "Preview") ? "Edit Question" : fetchQuizData?.Preview == "Preview" ? "Preview Question" : "Add New Question" }
      ];
    } else {
      pageRoutes = [
        { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "TrainingManagement" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}`, breadcrumb: "Edit Activity" },
        { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&`, breadcrumb: "Edit Settings" },
        { path: `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList`, breadcrumb: "Question" },
        { path: "", breadcrumb: (mode == "Edit" && fetchQuizData?.Preview != "Preview") ? "Edit Question" : fetchQuizData?.Preview == "Preview" ? "Preview Question" : "Add New Question" }
      ];
    }
  }
  else {
    if (router.query["ZoomActivityID"] != undefined) {
      if (!router.query["NavigationMode"]) {
        pageRoutes = [
          { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
          { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Settings Zoom" },
          { path: `/ActivityManagement/ActivityInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${fetchQuizData?.ActivityType}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
          { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
          { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Question" },
          { path: "", breadcrumb: (mode == "Edit" && fetchQuizData?.Preview != "Preview") ? "Edit Question" : fetchQuizData?.Preview == "Preview" ? "Preview Question" : "Add New Question" }
        ];
      } else {
        pageRoutes = [
          { path: `/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`, breadcrumb: "Activity Management" },
          { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Activity" },
          { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}&NavigationMode=${router.query["NavigationMode"]}`, breadcrumb: "Edit Settings" },
          { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["NavigationMode"]}`, breadcrumb: "Question" },
          { path: "", breadcrumb: (mode == "Edit" && fetchQuizData?.Preview != "Preview") ? "Edit Question" : fetchQuizData?.Preview == "Preview" ? "Preview Question" : "Add New Question" }
        ];
      }
    } else {
      pageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: mode == "ModuleDirect" ? "Course Management" : "Activity Management" },
        { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}`, breadcrumb: "Edit Activity" },
        { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}`, breadcrumb: "Edit Settings" },
        { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchQuizData?.ActivityID}&ActivityType=${fetchQuizData?.ActivityType}`, breadcrumb: "Question" },
        { path: "", breadcrumb: (mode == "Edit" && fetchQuizData?.Preview != "Preview") ? "Edit Question" : fetchQuizData?.Preview == "Preview" ? "Preview Question" : "Add New Question" }
      ];
    }
  }

  return (
    <>
      <Container PageRoutes={pageRoutes} loader={fetchQuizData == undefined || props?.TenantInfo?.TenantID == undefined}>
        <NVLAlert
          ButtonYestext={"X"}
          MessageTop={modalValues?.ModalTopMessage}
          MessageBottom={modalValues?.ModalBottomMessage}
          ModalOnClick={modalValues?.ModalOnClickEvent}
          ModalInfo={modalValues?.ModalInfo}
        />
        <form
          onSubmit={
            fetchQuizData?.Preview != "Preview" ?
              handleSubmit(submitHandler) : () => { }
          }
        >
          <div
            className={`${fetchQuizData?.Preview == "Preview"
              ? "pointer-events-none flex mx-4"
              : "flex mx-4"
              }`}
          >
            <div className="flex">
              <div className="space-y-2">
                <NVLSelectField id="ddlQuestionType" options={questionType} labelText="Question Type" labelClassName="nvl-Def-Label" className={`${mode == "Edit" || mode == "ModuleEdit" ? "Disabled w-44" : "w-44 nvl-mandatory "}`} register={register}></NVLSelectField>
                <Language LanguageType={languageType} errors={errors} Mode={mode} register={register} />
              </div>
            </div>
            <div>
              <div
                className={`${currentDiv == "Select"
                  ? "hidden"
                  : "container px-0 sm:px-12 mx-auto grid gap-4 mt-10"
                  }`}
              >
                <DefaultMark CurrentDiv={currentDiv} errors={errors} register={register} />
                <div className="flex flex-col sm:flex-row gap-4 ">
                  <NVLlabel className="nvl-Def-Label w-52" text="Question">
                    <span className="text-red-500 text-lg">*</span>
                  </NVLlabel>
                  <div className="gap-16">
                    <NVLRichTextBox
                      id="txtRichQuestion"
                      register={register}
                      errors={errors}
                      className="isResizable nvl-mandatory nvl-Def-Input"
                      setState={setMessage}
                    />
                    <div className="{invalid-feedback} text-red-500 text-sm text-center p-2">
                      {errors?.["txtQuestion"]?.message}
                    </div>
                  </div>
                </div>
                {/* MultipleChoice start */}
                <div
                  className={`${currentDiv == "MultipleChoice" ? "" : "hidden"}`}
                >
                  <div className={""}>
                    <div className="flex gap-4">
                      <NVLlabel
                        className="nvl-Def-Label w-52"
                        text="MultipleChoice Type"
                      ></NVLlabel>
                      <div className="flex gap-2">
                        <NVLRadio id="IsMultiChoicetype" text="Single Answer" name="IsMultiChoicetype" value={"SingleAnswer"} errors={errors} register={register}></NVLRadio>
                        <NVLRadio id="IsMultiChoicetype" text="Multiple Answer" name="IsMultiChoicetype" value={"MultipleAnswer"} errors={errors} register={register}></NVLRadio>
                        <NVLRadio id="IsMultiChoicetype" text="Dropdown" name="IsMultiChoicetype" value={"Dropdown"} errors={errors} register={register}></NVLRadio>
                      </div>
                    </div>
                    <div className="{invalid-feedback} text-red-500 text-sm">
                      {errors?.IsMultiChoicetype?.message}
                    </div>
                  </div>
                  {/*Choice*/}
                  <div className="grid gap-4 my-4">
                    {currentDiv == "MultipleChoice" && <Options Points={points} watch={watch} DeleteOption={deleteOption} register={register} CurrentDiv={currentDiv} id={optionsLength} Optionslength={optionsLength} errors={errors} />}
                  </div>
                  <div className="{invalid-feedback} text-red-500 text-sm text-center p-2">
                    {errors?.["checkDefaultMarks"]?.message}
                  </div>
                  <div className="flex flex-col sm:flex-row gap-4 ">
                    <NVLlabel className="nvl-Def-Label w-52" text=""></NVLlabel>
                    <div className="grid gap-2">
                      <NVLButton id="btnSubmit" type="button" text={"Add Option field"} className={`w-48 nvl-button bg-primary text-white ${optionsLength == 5 ? "hidden" : ""}`} onClick={() => addOption()}></NVLButton>
                      <NVLCheckbox id="chkShuffleChoices" text="Shuffle Choices" register={register}></NVLCheckbox>
                      <NVLlabel text="Number the choices" className="font-bold"></NVLlabel>
                      <NVLSelectField id="ddlChoiceType" className="nvl-Def-Input" options={choiceType} register={register}></NVLSelectField>
                    </div>
                  </div>
                </div>
                {/* MultipleChoice End */}

                {/* FillIn The Blank Start */}
                <div className={`${currentDiv == "FillInTheBlank" ? "" : "hidden"}`} id="divFillUp">
                  <div className="flex flex-col sm:flex-row gap-4 justify-end">
                    <div className="grid gap-2">
                      Note: Example : Question[ans|dummy|dummy]
                    </div>
                  </div>
                </div>
                {/* Fill In The Blank End */}

                {/* Order Start */}
                <div className={`${currentDiv == "Ordering" ? "" : "hidden"}`} id="divOrdering">
                  <div className="flex flex-col sm:flex-row  gap-4">
                    <NVLlabel text="Add TextFields" className="nvl-Def-Label w-52">
                      <span className="text-red-500 text-lg">*</span>
                    </NVLlabel>
                    <NVLCustomTxtBoxField id="txtFillTextfield" Optionslength={optionsLength} setOptionlength={setOptionLength} setValue={setValue} watch={watch} title="Option" errors={errors} register={register} />
                  </div>
                  Ordering
                </div>
                {/* Order End */}

                {/*Match  Start*/}
                <div
                  className={`${currentDiv == "Match" ? "" : "hidden"}`}
                  id="divOrdering"
                >
                  <div className="pl-56">
                    <NVLCustomTxtBoxField id="txtTextfield" NoOfField={2} Optionslength={optionsLength} setOptionlength={setOptionLength} setValue={setValue} watch={watch} title="Option" errors={errors} register={register} />
                  </div>
                </div>
                {/*Match  End*/}
                {/*Description Start*/}
                <div
                  className={`${currentDiv == "Description" ? "" : "hidden"}`}
                  id="divOrdering"
                >
                  <div className="pl-56 grid gap-3">
                    {currentDiv == "Description" && <Options Points={points} watch={watch} DeleteOption={deleteOption} register={register} CurrentDiv={currentDiv} id={optionsLength} Optionslength={optionsLength} errors={errors} />}
                  </div>
                  <div className="{invalid-feedback} text-red-500 text-sm text-center p-2">
                    {errors?.["checkDefaultMarks"]?.message}
                  </div>
                  <NVLButton
                    id="btnSubmit"
                    type="button"
                    text={"Add Text Fields"}
                    className={`w-48 nvl-button bg-primary text-white ${optionsLength == 5 ? "hidden" : ""
                      }`}
                    onClick={() => addOption()}
                  ></NVLButton>
                </div>
                {/*Description End*/}
                <div
                  className={`flex flex-col sm:flex-row gap-4 ${mode == "Edit" ||
                    mode == "ModuleEdit" ||
                    fetchQuizData?.Preview == "Preview"
                    ? "hidden"
                    : ""
                    }`}
                >
                  <NVLlabel className="nvl-Def-Label w-52" text=""></NVLlabel>
                  <div className="grid gap-2">
                    <NVLCheckbox
                      id="chkNew"
                      errors={errors}
                      register={register}
                      text="Add new question"
                      className="font-bold"
                    />
                  </div>
                </div>
                <div
                  className={`flex flex-col sm:flex-row gap-4 ${currentDiv == "MultipleChoice"
                    ? "justify-center ml-8"
                    : "justify-end mr-14 "
                    }`}
                >
                  <div className="grid gap-2">
                    <Buttons />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </Container>
    </>
  );
}
export default AddQuestion;