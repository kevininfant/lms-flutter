
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, DelayEnforce, Grade, Limit, ReactTagsButton, SetTime } from "./ActivityComponents";

export const QuizActivity = ({ Attempt, AllowAttempts, GradeMethod, CustomMessage, UnSavedtoSaved, LanguageType, FinalResponse, query, props, ButtonClassName, ButtonText, delimiters, CurrentDiv, DateCoversion, router, setData, ZoomMode, updateOptions }) => {
  const [state, setState] = useState(props.EditData?.Options != undefined && Object.values(JSON.parse(props.EditData?.Options))?.[0]?.count != null ? Object.values(JSON.parse(props.EditData?.Options))?.[0]?.count : 1);
  
  const dynamicFileRef = useRef("1");
  const activityCompleteRef = useRef("false");
  let stDate = useRef();
  // const [courseData, setcourseData] = useState()
  let DynamicYupfields = {
    /* Activity Download */
    ["rbFileDownload"]: Yup.string()
      .nullable()
      .test("", "", () => {
        dynamicFileRef.current = dynamicFileRef.current;

        activityCompleteRef.current = activityCompleteRef.current;
        return true;
      }),

    /*Date time Validation*/
    ["txtstdate"]: Yup.string()
      .nullable(true)
      .notRequired().test("Check", "Activity can be created only for present and future date", (e, { createError }) => {
        if (e == "" || e == undefined || e == null) {
          return true;
        }
        else {
          if (new Date(e) > new Date(new Date().setMinutes(new Date().getMinutes() - 1))) {
            if ((stDate.current != e) && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
              stDate.current = e;
              setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
            } else {
              clearErrors(["txtEnddate"])
            }
            return true;
          }
          else {
            return false
          }
        }
      }).nullable(true),
    ["txtEnddate"]: Yup.string()
      .when("chkEndDateEnable", {
        is: true,
        then: Yup.string().typeError("End Date is invalid Value").required("End Date is Required").nullable().test("error", "End Date must be greater than or equal to the start date", (e) => {
          if (new Date(e) > new Date(watch("txtstdate"))) {
            return true;
          }
          else {
            return false
          }
        }),
      }
      ).nullable(true),
    otherwise: Yup.string()
      .when("chkEndDateEnable", {
        is: false,
        then: Yup.string().test("novalid", "noError", e => {
          clearErrors(["txtEnddate"])
          return true;
        })
      }).nullable(true),

    ["chkQuizTime"]: Yup.bool().test("novalid", "novalid", e => {

      if (!e && watch(" txtQuizLimit"))
        setValue(" txtQuizLimit", undefined, { shouldValidate: true })
      return true;
    }).nullable(),
    ["txtQuizLimit"]: Yup.number()
      .typeError("Only numeric values will be allowed")
      .nullable()
      .when("chkQuizTime", {
        is: true,
        then: Yup.number()
          .typeError("Only numeric values will be allowed")
          .required("Quiz Time Limit is required")
          .max(999, "Quiz Time Limit should not exceed more than 3 characters")
          .nullable(true)
          .test("error", "", (val, { createError }) => {
            if (val < 1) {
              return createError({ message: "Time should not be less than 1" });
            }

            return true;
          })
          .nullable(true),
      }),
    ["chkSetTime"]: Yup.bool().test("novalid", "novalid", e => {
      if (!e && watch("txtSetTime"))
        setValue("txtSetTime", undefined, { shouldValidate: true })
      return true;
    }).nullable(),
    ["txtSetTime"]: Yup.number()
      .typeError("Only numeric values will be allowed")
      .nullable()
      .when("chkSetTime", {
        is: true,
        then: Yup.number()
          .typeError("Only numeric values will be allowed")
          .required("Set time for each question is required")
          .max(999, "Set time for each question should not exceed more than 3 characters")
          .nullable(true)
          .test("error", "", (val, { createError }) => {
            if (val < 1) {
              return createError({ message: "Time should not be less than 1" });
            }

            return true;
          })
          .nullable(true),


      }),

    /*Grade Validation*/
    ["txtMaxGrade"]: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .nullable()
      .min(1)
      .required("Maximum grade is required")
      .matches(Regex("AllowNumbersWithDot"), "Only numeric values will be allowed")
      .test(1000, "Maximum grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        if (val == null || val == undefined || val == "") {
          return true;
        }
        if (parseInt(val) == 0) {
          return createError({ message: "Only numeric values will be allowed" });
        }
        if(parseFloat(val)>100.00)
        {
          return createError({ message: "Maximum grade should be less than or equal to 100" });
        }
        if (parseFloat(watch("txtPassGrade")) > parseFloat(val)) {
          return createError({ message: "Maximum grade should be greater than or equal to passing grade" });
        }
        if (val.includes(".")) {
          let valcheck = val.split(".");
          if (parseInt(valcheck[0]) > 999 || parseInt(valcheck[1]) > 100 || valcheck[1].length > 2) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        } else {
          if (parseInt(val) > 999) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        }
        if (parseFloat(watch("txtPassGrade")) <= parseFloat(val) && errors?.txtPassGrade != undefined) {
          clearErrors(["txtPassGrade"]);
        }
        return true;
      }),
    ["txtPassGrade"]: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .nullable()
      .min(1)
      .matches(Regex("AllowNumbersWithDot"), "Only numeric values will be allowed")
      .test("error", "Passing grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        if (val == null || val == undefined || val == "") {
          return true;
        }
        if (parseInt(val) == 0) {
          return createError({ message: "Only numeric values will be allowed" });
        }
        if (watch("txtMaxGrade") == undefined || watch("txtMaxGrade") == "" || watch("txtMaxGrade") == "0") {
          return createError({ message: "Passing Grade Must be less than or equal to maximum grade" });
        }
        else if (watch("txtMaxGrade") != undefined && parseFloat(watch("txtMaxGrade")) < parseFloat(val)) {
          return createError({ message: "Passing Grade Must be less than or equal to maximum grade" });
        }
        if (val.includes(".")) {
          let valcheck = val.split(".");
          if (parseInt(valcheck[0]) >= 1000 || parseInt(valcheck[1]) >= 100 || valcheck[1].length > 2) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        } else {
          if (parseInt(val) >= 1000) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        }
        if (parseFloat(watch("txtMaxGrade")) >= parseFloat(val) && errors?.txtMaxGrade != undefined) {
          clearErrors(["txtMaxGrade"]);
        }
        return true;
      }),


    ["txtEnforcefirstAttempt"]: Yup.number()
      .typeError("Enforce first Attempts is required")
      .nullable(true)
      .when("chkEnforcefirstEnable", {
        is: true,
        then: Yup.number().required("Enforce first Attempts is required").typeError("Only numeric values will be allowed").min(1, "Enforced Delay should not be less than 1 min").max(999, "Enforced Delay between should not exceed more than 3 characters").nullable(true),
      }),

    /* Activity Completion */

    ["rbActivityCompletion"]: Yup.string()
      .required("Activity completion is required")
      .nullable()
      .test("error", "", (e, { createError }) => {
        if (e == "true") {
          let array = ["chkViewTheActivity", "chkCompleteTheActivity", "chkRequirePassingGrade", "chkMarkTheActivity"];
          let result = [];
          array.map((item) => {
            result.push(watch(item));
          });
          if (result.indexOf(true) == -1) {
            setValue("activitycompletionError", "At least one is required.");
            return createError({ message: "At least one is required." });
          } else {
            setValue("activitycompletionError", undefined);
            return true;
          }
        } else {
          setValue("chkViewTheActivity", null);
          setValue("chkCompleteTheActivity", null);
          setValue("chkRequirePassingGrade", null);
          setValue("chkMarkTheActivity", null);
          setValue("activitycompletionError", undefined);
        }
        return true;
      })
      .nullable(),

  }
  for (let i = 0; i < state; i++) {
    DynamicYupfields = {
      ...DynamicYupfields,
      ["txtGradeBoundary" + (i + 1)]:
        Yup.string()
        .transform((o, c) => (o === "" ? null : c))
         .nullable()
          .notRequired().matches(Regex("AllowNumbersWithDot"), "Only numeric values will be allowed")
          .test("error", "", (val, { createError }) => {
            if (val == undefined || val == "" || val == null) {
              return true;
            }
            // const rejax = new RegExp(/^[0-9]+$/);
            // if (!rejax.test(val)) {
            //   return createError({ message: "Only numeric values will be allowed" });
            // }
            if (val == 0) {
              return createError({ message: "Only numeric values will be allowed" });
            }
            if (val < 1) {
              return createError({ message: "Grade Boundary should not be less than 1" });
            }
            // else if (val.length > 3) {
            //   return createError({ message: "Grade Boundary should not exceed more than 3 characters" });
            // } 
            if (val?.includes(".")) {
              let valcheck = val?.split(".");
              if (parseInt(valcheck[0]) >= 1000 || valcheck[0] > 100 || parseInt(valcheck[1]) >= 100 || valcheck[1]?.length > 2) {
                return createError({ message: "Grade Boundary will allow only 3 digit. (Eg:100.00)" });
              }
            } else {
              if (parseInt(val) >= 1000 || parseInt(val) >100 ) {
                return createError({ message: "Grade Boundary will allow only 3 digit. (Eg:100.00)" });
              }
            }
            return true;
          })
          .nullable(true),
    };
  }


  const validationSchema = Yup.object().shape(DynamicYupfields);
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, watch, formState, reset, clearErrors } = useForm(formOptions);
  const { errors } = formState;

  const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
  const handleDelete = useCallback((i) => {
    setTags(tags.filter((tag, index) => index !== i));
    setValue("ReactTags", "Delete", { shouldValidate: true });
  },
    [setTags, setValue, tags]
  );

  const handleAddition = useCallback((tag) => {
    setTags([...tags, tag]);
    setValue("ReactTags", "Add", { shouldValidate: true });
  },
    [setTags, setValue, tags]
  );

  const handleDrag = useCallback(
    (tag, currPos, newPos) => {
      const newTags = tags.slice();
      newTags.splice(currPos, 1);
      newTags.splice(newPos, 0, tag);
      setTags(newTags);
    },
    [tags, setTags]
  );

  useEffect(() => {
    
    setValue("txtstdate", DateCoversion(props.EditData?.StartDate) == "1970-01-01T05:30" || DateCoversion(props.EditData?.StartDate) == "NaN-NaN-NaNTNaN:NaN" ? undefined : DateCoversion(props.EditData?.StartDate));
    setValue("txtEnddate", DateCoversion(props.EditData?.EndDate));
    // setValue("txtTimeLimit", props.EditData?.TimeLimit);
    setValue("txtQuizLimit", props.EditData?.QuizTimeLimit);
    setValue("chkTimeLimitEnable", props.EditData?.IsTimeLimit);
    setValue("chkQuizTime", props.EditData?.IsQuizTimeLimit);
    // setValue("ddlDecimal", props.EditData?.DecimalPoint);
    // setValue("txtQuestionsPerPage", props.EditData?.QuestionsPerPage);
    // setValue("ddlNavigation", props.EditData?.NavigationMethod);
    setValue("txtEnforcefirstAttempt", props.EditData?.DelayBetweenNextAttempt);
    setValue("txtEnforcefirstAttempt", props.EditData?.DelayBetweenNextAttempt);
    setValue("movePreviousToNext", props.EditData?.IsMoveToPreviousAndNextQuestion);
    // setValue("AbortandAllowReAttempt", props.EditData?.IsAbortImmediately);
    setValue("txtGradeBoundary", props.EditData?.GradeBoundary);
    setValue("txtFeedback", props.EditData?.OverAllFeedBack);
    setValue("txtPassGrade", props.EditData?.PassingGrade);
    setValue("ddlMaxAtmpt", props.EditData?.MaximumAttempt);
    setValue("ddlAllowAtmpt", props.EditData?.AllowMaximumAttempts != null ? props.EditData?.AllowMaximumAttempts : "");
    setValue("ddlGrdMethod", props.EditData?.GradingMethod == null ? "" : props.EditData?.GradingMethod);
    setValue("rbGradableActivity", props.EditData?.IsGradableActivity?.toString());
    setValue("chkAllowProctoring", props.EditData?.IsProctoring);
    setValue("chkAllowLockScreen", props.EditData?.IsLockScreen);
    setValue("rbAllowQuizInMobile", props.EditData?.IsQuizOfflineUsingMobile?.toString());
    // setValue("chkStartDateEnable", props.EditData?.IsStartDateEnable);
    setValue("chkEndDateEnable", props.EditData?.IsEndDateEnable);
    setValue("chkOpenAttempt", props.EditData?.IsSubmissionAutomatically);
    setValue("chkRejectattempt", props.EditData?.IsNOMoreQuestionsAnswered);
    setValue("chkSubmission", props.EditData?.IsBeforeTimeExpires);
    setValue("chkEnforcefirstEnable", props.EditData?.IsDelayBetweenNextAttempt);
    setValue("chkEnforcelaterEnable", props.EditData?.IsDelayBetweenLaterAttempt);
    setValue("chkShowAnswers", props.EditData?.IsShowAnswer);
    setValue("chkShowBothAnswers", props.EditData?.IsShowBothAnswer);
    setValue("chkShowScores", props.EditData?.IsShoeTheScore);
    setValue("chkHideQuestions", props.EditData?.IsHideTheQuestions);
    setValue("chkRequirePassingGrade", props.EditData?.IsRequirePassingGrade)
    setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
    setValue("chkCompleteTheActivity", props.EditData?.IsCompleteTheActivity);
    setValue("chkAvailableAttempts", props.EditData?.IsAvaillableAttemptsCompleted);
    setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
    setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion?.toString() == null || props.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : props.EditData?.IsActivityCompletion?.toString());

    let optionsData = props.EditData?.Options && Object.values(JSON.parse(props.EditData?.Options))?.[0];

    if (optionsData?.Options != null) {
      Object.keys(optionsData.Options).map((option) => {
        setValue(option, optionsData.Options?.[option]);
      });
    }

    setValue("rbShuffleQuestions", props.EditData?.IsShuffleWithInQuestion?.toString() == null || props.EditData?.IsShuffleWithInQuestion?.toString() == undefined ? "false" : props.EditData?.IsShuffleWithInQuestion?.toString());
    setValue("rbShuffleAnswers", props.EditData?.IsShuffleWithInChoice?.toString() == null || props.EditData?.IsShuffleWithInChoice?.toString() == undefined ? "false" : props.EditData?.IsShuffleWithInChoice?.toString());
    // setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
    setValue("chkShowAnswers", props.EditData?.IsShowAnswer),
      setValue("chkShowScores", props.EditData?.IsShoeTheScore),
      setValue("chkShowBothAnswers", props.EditData?.IsShowBothAnswer),
      setValue("chkHideQuestions", props.EditData?.IsHideTheQuestions),
      // setValue("txtMaxGrade", props.EditData?.MaximumGrade);
      setValue("txtMaxGrade","100")
    setValue("chkSetTime", props.EditData?.IsSetTime);
    setValue("txtSetTime", props.EditData?.TimeForEachQuestion);
  }, [DateCoversion, props.EditData?.AllowMaximumAttempts, props.EditData?.IsActivityCompletion, props.EditData?.DelayBetweenNextAttempt, props.EditData?.EndDate, props.EditData?.GradeBoundary, props.EditData?.GradingMethod, props.EditData?.IsBeforeTimeExpires, props.EditData?.IsDelayBetweenLaterAttempt, props.EditData?.IsDelayBetweenNextAttempt, props.EditData?.IsEndDateEnable, props.EditData?.IsGradableActivity, props.EditData?.IsHideTheQuestions, props.EditData?.IsLockScreen, props.EditData?.IsMarkTheActivity, props.EditData?.IsNOMoreQuestionsAnswered, props.EditData?.IsProctoring, props.EditData?.IsQuizOfflineUsingMobile, props.EditData?.IsQuizTimeLimit, props.EditData?.IsSetTime, props.EditData?.IsShoeTheScore, props.EditData?.IsShowAnswer, props.EditData?.IsShowBothAnswer, props.EditData?.IsShuffleWithInChoice, props.EditData?.IsShuffleWithInQuestion, props.EditData.IsStartDateEnable, props.EditData?.IsSubmissionAutomatically, props.EditData?.IsTimeLimit, props.EditData?.MaximumAttempt, props.EditData?.MaximumGrade, props.EditData?.Options, props.EditData?.OverAllFeedBack, props.EditData?.PassingGrade, props.EditData?.QuizTimeLimit, props.EditData?.StartDate, props.EditData?.TimeForEachQuestion, setValue, props.EditData.IsShowTheAnswers, props.EditData.IsShowBothAnswers, props.EditData.IsShowTheScores, props.EditData?.IsMoveToPreviousAndNextQuestion, props.EditData.IsAbortImmediatelya, props.EditData.IsAbortImmediately, props.EditData?.IsViewTheActivity, props.EditData?.IsCompleteTheActivity, props.EditData?.IsAvaillableAttemptsCompleted, props.EditData.IsAvailableAttemptsCompleted, props.EditData?.IsRequirePassingGrade, props?.mode, props.TrainingData?.StartDate, props.AssessmentType, props.TrainingData?.EndDate]);


  const navigation = useMemo(() => {
    return [
      { value: "", text: "Select" },
      { value: "Free", text: "Free" },
      { value: "Sequential", text: "Sequential" },
      { value: "Locked", text: "Locked" },
    ];
  }, []);

  const decimal = useMemo(() => {
    return [
      { value: "", text: "Select" },
      { value: "1", text: "1" },
      { value: "2", text: "2" },
      { value: "3", text: "3" },
    ];
  }, []);

  const Setoptions = useCallback(
    (props) => {
      return (
        <>
          {
            <div>
              <div className="">
                <NVLlabel text={"Grade Boundary" + (props.id + 1)+(" (%)")}></NVLlabel>
                <NVLTextbox title={"Grade Boundary" + (props.id + 1)+" (%)"} id={"txtGradeBoundary" + (props.id + 1)} className="w-96 nvl-non-mandatory" errors={props.errors} register={register}></NVLTextbox>
              </div>
              <div id="field_div">
                <NVLlabel text={"Feedback " + (props.id + 1)} className="nvl-Def-Label w-52"></NVLlabel>
                <div className="flex gap-10  relative">
                  <NVLTextbox title={"Feedback" + (props.id + 1)} id={"txtFeedback" + (props.id + 1)} className="w-96 nvl-non-mandatory" errors={props.errors} reset={reset} register={register}></NVLTextbox>

                  <div className={`pt-1 ${props.id == 0 ? "hidden" : ""}`}>
                    <i
                      className="fa-solid fa-trash text-red-600"
                      onClick={() => {
                        deleteOption(props?.id + 1);
                      }}
                    ></i>
                  </div>
                </div>
              </div>
            </div>
          }
        </>
      );
    },
    [deleteOption, register, reset]
  );

  const Options = useCallback((props) => {

    let rowGrid = [];
    for (let i = 0; i < state; i++) {
      rowGrid.push(<Setoptions id={i} key={i} errors={props.errors} />);
    }
    return <>{rowGrid}</>;
  }, [state]);

  const dynamicValidation = (id) => {
    let ChoiceData = [{}];
    let c = 1;
    for (let i = 1; i < id; i++) {
      if (document.getElementById("txtFeedback" + i) != null) {
        ChoiceData.push({ OptionNo: c, OptionValue: document.getElementById("txtFeedback" + i).value });
        c++;
      }
    }
    return ChoiceData;
  };

  const deleteOption = useCallback(
    (id) => {
      setState((state) => {
        if (id != state) {
          for (let i = 0; i + id < state; i++) {
            setValue("txtFeedback" + (i + id), watch("txtFeedback" + (i + id + 1)));
            setValue("txtGradeBoundary" + (i + id), watch("txtGradeBoundary" + (i + id + 1)));
          }
          setValue("txtFeedback" + state, "");
          setValue("txtGradeBoundary" + state, "");
        } else {
          setValue("txtFeedback" + state, "");
          setValue("txtGradeBoundary" + state, "");
        }
        return state - 1;
      });
    },
    [setState, setValue, watch]
  );
  const submitHandler = async (data) => {
    document?.activeElement?.blur();
    let PK, SK;

    PK = "TENANT#" + props.TenantInfo.TenantID;
    SK = props.EditData.SK

    let options = [props.EditData?.Options];

    let optionsConrol = { count: state };
    for (let i = 1; i <= state; i++) {
      optionsConrol = {
        ...optionsConrol,
        Options: {
          ...optionsConrol.Options,
          ["txtFeedback" + i]: data?.["txtFeedback" + i],
          ["txtGradeBoundary" + i]: data?.["txtGradeBoundary" + i],
        },
      };
    }
    options = { ["Options"]: { ...optionsConrol } };

    let quizVariables = props?.mode == "TrainingEdit" ? {
      input: {
        ...props.EditData,
        PK: PK,
        SK: SK,
        // StartDate: data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : null, 
        // EndDate: data.txtEnddate != undefined && data.txtEnddate != "" ? data.txtEnddate : null,
        StartDate: props?.AssessmentType == "Post-Assessment" ? props?.TrainingData?.EndDate : (data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : null),
        EndDate: props?.AssessmentType == "Pre-Assessment" ? props?.TrainingData?.StartDate : (data.txtEnddate != undefined && data.txtEnddate != "" ? data.txtEnddate : null),
        IsEndDateEnable: data.chkEndDateEnable,
        TimeLimit: data.txtTimeLimit,
        QuizTimeLimit: data.txtQuizLimit,
        IsTimeLimit: data.chkTimeLimitEnable,
        IsQuizTimeLimit: data.chkQuizTime,
        TimeForEachQuestion: data.txtSetTime,
        IsSubmissionAutomatically: data.chkOpenAttempt,
        IsNOMoreQuestionsAnswered: data.chkRejectattempt,
        IsMoveToPreviousAndNextQuestion: data.movePreviousToNext,
        // IsAbortImmediately: data.AbortandAllowReAttempt,
        IsBeforeTimeExpires: data.chkSubmission,
        PassingGrade: data.txtPassGrade,
        MaximumGrade: data.txtMaxGrade,
        MaximumAttempt: data.ddlMaxAtmpt,
        AllowMaximumAttempts: data.ddlAllowAtmpt,
        GradingMethod: data.ddlGrdMethod,
        IsShuffleWithInQuestion: data.rbShuffleQuestions,
        IsProctoring: data.chkAllowProctoring,
        IsLockScreen: data.chkAllowLockScreen,
        DelayBetweenNextAttempt: data.txtEnforcefirstAttempt,
        IsDelayBetweenNextAttempt: data.chkEnforcefirstEnable,
        GradeBoundary: data.txtGradeBoundary,
        Options: JSON.stringify(options),
        IsSetTime: data.chkSetTime,
        TimeForEachQuestion: data.txtSetTime,
        IsShuffleWithInChoice: data.rbShuffleAnswers,
        IsActivityCompletion: data.rbActivityCompletion == null ? false : data.rbActivityCompletion,
        IsViewTheActivity: data.chkViewTheActivity,
        IsCompleteTheActivity: data.chkCompleteTheActivity,
        IsAvaillableAttemptsCompleted: data.chkAvailableAttempts,
        IsRequirePassingGrade: data.chkRequirePassingGrade,
        IsMarkTheActivity: data.chkMarkTheActivity,
        IsShowBothAnswer: data.chkShowBothAnswers,
        IsShowAnswer: data.chkShowAnswers,
        IsHideTheQuestions: data.chkHideQuestions,
        IsShoeTheScore: data.chkShowScores,
        Keywords: JSON.stringify(tags),
        LastModifiedBy: props.user.username,
        LastModifiedDate: new Date(),
        ScoredMark: "",
        QuizStatus: ""
      },
    } : {
      input: {
        ...props.EditData,
        PK: PK,
        SK: SK,
        StartDate: data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : null,
        EndDate: data.txtEnddate != undefined && data.txtEnddate != "" ? data.txtEnddate : null,
        IsEndDateEnable: data.chkEndDateEnable,
        TimeLimit: data.txtTimeLimit,
        QuizTimeLimit: data.txtQuizLimit,
        IsTimeLimit: data.chkTimeLimitEnable,
        IsQuizTimeLimit: data.chkQuizTime,
        TimeForEachQuestion: data.txtSetTime,
        IsSubmissionAutomatically: data.chkOpenAttempt,
        IsNOMoreQuestionsAnswered: data.chkRejectattempt,
        IsMoveToPreviousAndNextQuestion: data.movePreviousToNext,
        // IsAbortImmediately: data.AbortandAllowReAttempt,
        IsBeforeTimeExpires: data.chkSubmission,
        PassingGrade: data.txtPassGrade,
        MaximumGrade: data.txtMaxGrade,
        MaximumAttempt: data.ddlMaxAtmpt,
        AllowMaximumAttempts: data.ddlAllowAtmpt,
        GradingMethod: data.ddlGrdMethod,
        IsShuffleWithInQuestion: data.rbShuffleQuestions,
        IsProctoring: data.chkAllowProctoring,
        IsLockScreen: data.chkAllowLockScreen,
        DelayBetweenNextAttempt: data.txtEnforcefirstAttempt,
        IsDelayBetweenNextAttempt: data.chkEnforcefirstEnable,
        GradeBoundary: data.txtGradeBoundary,
        Options: JSON.stringify(options),
        IsSetTime: data.chkSetTime,
        TimeForEachQuestion: data.txtSetTime,
        IsShuffleWithInChoice: data.rbShuffleAnswers,
        IsActivityCompletion: data.rbActivityCompletion == null ? false : data.rbActivityCompletion,
        IsViewTheActivity: data.chkViewTheActivity,
        IsCompleteTheActivity: data.chkCompleteTheActivity,
        IsAvaillableAttemptsCompleted: data.chkAvailableAttempts,
        IsRequirePassingGrade: data.chkRequirePassingGrade,
        IsMarkTheActivity: data.chkMarkTheActivity,
        IsShowBothAnswer: data.chkShowBothAnswers,
        IsShowAnswer: data.chkShowAnswers,
        IsHideTheQuestions: data.chkHideQuestions,
        IsShoeTheScore: data.chkShowScores,
        Keywords: JSON.stringify(tags),
        ModifiedBy: props.user.username,
        ModifiedDate: new Date(),
        ScoredMark: "",
        QuizStatus: ""
      },
    };

    const RemoveNull = (obj) => {
      let tempjson = {};
      obj && Object.keys(obj).forEach((k) => {
        if (obj?.[k] != undefined) {
          tempjson = { ...tempjson, [k]: obj?.[k] }
        }
      });
      return tempjson;
    }

    let existData = RemoveNull(props.EditData)

    let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit" || props.EditData?.ZoomActivityID != null) ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
    /*Batch Update*/
    for (let i = 1; i <= props.EditData.Shard; i++) {
      UpdateBatch({ UpdateData: existData, inn: quizVariables.input, props: props, pk: "TENANT#" + props.EditData.TenantID + "#" + i, query: queryBatch, });
    }
    quizVariables = props?.mode == "TrainingEdit" ? {
      input: {
        PK: PK,
        SK: SK,
        // StartDate: data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : null,
        // EndDate: data.txtEnddate != undefined && data.txtEnddate != "" ? data.txtEnddate : null,
        StartDate: props?.AssessmentType == "Post-Assessment" ? props?.TrainingData?.EndDate : (data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : null),
        EndDate: props?.AssessmentType == "Pre-Assessment" ? props?.TrainingData?.StartDate : (data.txtEnddate != undefined && data.txtEnddate != "" ? data.txtEnddate : null),
        IsEndDateEnable: data.chkEndDateEnable,
        TimeLimit: data.txtTimeLimit,
        QuizTimeLimit: data.chkQuizTime ?data.txtQuizLimit : "",
        IsTimeLimit: data.chkTimeLimitEnable,
        IsQuizTimeLimit: data.chkQuizTime,
        TimeForEachQuestion: data.chkSetTime ? data.txtSetTime : "",
        IsSubmissionAutomatically: data.chkOpenAttempt,
        IsNOMoreQuestionsAnswered: data.chkRejectattempt,
        IsMoveToPreviousAndNextQuestion: data.movePreviousToNext,
        // IsAbortImmediately: data.AbortandAllowReAttempt,
        IsBeforeTimeExpires: data.chkSubmission,
        PassingGrade: data.txtPassGrade,
        MaximumGrade: data.txtMaxGrade,
        MaximumAttempt: data.ddlMaxAtmpt,
        AllowMaximumAttempts: data.ddlAllowAtmpt,
        GradingMethod: data.ddlGrdMethod,
        IsShuffleWithInQuestion: data.rbShuffleQuestions,
        IsProctoring: data.chkAllowProctoring,
        IsLockScreen: data.chkAllowLockScreen,
        DelayBetweenNextAttempt: data.txtEnforcefirstAttempt,
        IsDelayBetweenNextAttempt: data.chkEnforcefirstEnable,
        GradeBoundary: data.txtGradeBoundary,
        Options: JSON.stringify(options),
        IsSetTime: data.chkSetTime,
        TimeForEachQuestion: data.txtSetTime,
        IsShuffleWithInChoice: data.rbShuffleAnswers,
        IsActivityCompletion: data.rbActivityCompletion == null ? false : data.rbActivityCompletion,
        IsViewTheActivity: data.chkViewTheActivity,
        IsCompleteTheActivity: data.chkCompleteTheActivity,
        IsAvaillableAttemptsCompleted: data.chkAvailableAttempts,
        IsRequirePassingGrade: data.chkRequirePassingGrade,
        IsMarkTheActivity: data.chkMarkTheActivity,
        IsShowBothAnswer: data.chkShowBothAnswers,
        IsShowAnswer: data.chkShowAnswers,
        IsHideTheQuestions: data.chkHideQuestions,
        IsShoeTheScore: data.chkShowScores,
        Keywords: JSON.stringify(tags),
        LastModifiedBy: props.user.username,
        LastModifiedDate: new Date(),
        ScoredMark: "",
        QuizStatus: ""
      },
    } : {
      input: {
        PK: PK,
        SK: SK,
        StartDate: data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : null,
        EndDate: data.txtEnddate != undefined && data.txtEnddate != "" ? data.txtEnddate : null,
        IsEndDateEnable: data.chkEndDateEnable,
        TimeLimit: data.txtTimeLimit,
        QuizTimeLimit: data.chkQuizTime ?data.txtQuizLimit : "",
        IsTimeLimit: data.chkTimeLimitEnable,
        IsQuizTimeLimit: data.chkQuizTime,
        TimeForEachQuestion: data.chkSetTime ? data.txtSetTime : "",
        IsSubmissionAutomatically: data.chkOpenAttempt,
        IsNOMoreQuestionsAnswered: data.chkRejectattempt,
        IsMoveToPreviousAndNextQuestion: data.movePreviousToNext,
        // IsAbortImmediately: data.AbortandAllowReAttempt,
        IsBeforeTimeExpires: data.chkSubmission,
        PassingGrade: data.txtPassGrade,
        MaximumGrade: data.txtMaxGrade,
        MaximumAttempt: data.ddlMaxAtmpt,
        AllowMaximumAttempts: data.ddlAllowAtmpt,
        GradingMethod: data.ddlGrdMethod,
        IsShuffleWithInQuestion: data.rbShuffleQuestions,
        IsProctoring: data.chkAllowProctoring,
        IsLockScreen: data.chkAllowLockScreen,
        DelayBetweenNextAttempt: data.txtEnforcefirstAttempt,
        IsDelayBetweenNextAttempt: data.chkEnforcefirstEnable,
        GradeBoundary: data.txtGradeBoundary,
        Options: JSON.stringify(options),
        IsSetTime: data.chkSetTime,
        TimeForEachQuestion: data.txtSetTime,
        IsShuffleWithInChoice: data.rbShuffleAnswers,
        IsActivityCompletion: data.rbActivityCompletion == null ? false : data.rbActivityCompletion,
        IsViewTheActivity: data.chkViewTheActivity,
        IsCompleteTheActivity: data.chkCompleteTheActivity,
        IsAvaillableAttemptsCompleted: data.chkAvailableAttempts,
        IsRequirePassingGrade: data.chkRequirePassingGrade,
        IsMarkTheActivity: data.chkMarkTheActivity,
        IsShowBothAnswer: data.chkShowBothAnswers,
        IsShowAnswer: data.chkShowAnswers,
        IsHideTheQuestions: data.chkHideQuestions,
        IsShoeTheScore: data.chkShowScores,
        Keywords: JSON.stringify(tags),
        ModifiedBy: props.user.username,
        ModifiedDate: new Date(),
        ScoredMark: "",
        QuizStatus: ""
      },
    };
    let finalStatus = (await AppsyncDBconnection(query, quizVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
    FinalResponse(finalStatus);
  };

  const DateTimeControl = () => {
    let today = new Date();
    let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T" + today.getHours() + ":" + (today.getMinutes() > 9 ? today.getMinutes() : "0" + today.getMinutes());
    if (!watch("chkEndDateEnable")) {
      if (!(watch("txtEnddate") == undefined)) {
        setValue("txtEnddate", undefined, { shouldValidate: true })
      }
    }
    return (
      <div className="grid pt-2">

        <div className="flex">
          <div >
            <NVLlabel text="Start Date"></NVLlabel>
            <NVLTextbox id="txtstdate" title="Start Date" type="datetime-local" tabIndex={"1"} disbled={(props?.mode == "TrainingEdit")? true : false} className={(props?.mode == "TrainingEdit")? "Disabled nvl-Def-Input":"nvl-Def-Input"} min={dateTime} setValue={setValue} errors={errors} register={register}></NVLTextbox>
          </div>
        </div>

        <div className="flex">

          <div>
            <NVLlabel text="End Date"></NVLlabel>
            <NVLTextbox title="End Date" id="txtEnddate" type="datetime-local" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"} className={!watch("chkEndDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkEndDateEnable")} errors={errors} register={register} setValue={setValue}></NVLTextbox>
          </div>
          <div className="translate-y-8 translate-x-8">
            <NVLCheckbox text="Enable" id="chkEndDateEnable" errors={errors} register={register} disabled={(props?.mode == "TrainingEdit" && props.AssessmentType == "Pre-Assessment")? true : false}></NVLCheckbox>
          </div>
        </div>
      </div>
    );
  }


  return (
    <>
      <form>
        <div id="divQuiz" className={CurrentDiv == "Quiz" ? `${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}` : "hidden"}>
          <div className="container px-0 sm:px-12 mx-auto grid">
            <NVLlabel className="nvl-Def-Label" text={`Activity Name: ${props.EditData?.ActivityName}`}></NVLlabel>
            <NVLlabel className="nvl-Def-Label " id="lblActivityType" text={`Activity Type: ${CurrentDiv}`}></NVLlabel>
            <div className="nvl-FormContent ">
              <div className=" flex flex-col sm:flex-row gap-4">
                <DateTimeControl setValue={setValue} register={register} errors={errors} watch={watch} reset={reset} />
              </div>
              <div className="flex flex-col sm:flex-row pt-2">
                <Limit register={register} errors={errors} watch={watch} setValue={setValue} clearErrors={clearErrors} />
              </div>
            </div>
            <div className="nvl-FormContent ">
              <SetTime register={register} errors={errors} watch={watch} setValue={setValue} />
            </div>
            <div className="translate-y-8">
              <NVLlabel className="nvl-Def-Label w-52" text="When Time Expires"></NVLlabel>
            </div>
            <div className=" nvl-FormContent grid gap-1 mt-2">
              <NVLCheckbox id="chkOpenAttempt" disabled={watch("chkRejectattempt")} className="Center-Aligned-Items" text="Open attempts are submitted automatically" showFull register={register} errors={errors} />
              <NVLCheckbox id="chkRejectattempt" disabled={watch("chkOpenAttempt")} className="Center-Aligned-Items" text="Attempt will be rejected, If not submitted before the time out." register={register} showFull errors={errors} />
            </div>
            <div className="translate-y-8">
              <NVLlabel className="nvl-Def-Label w-52" text="Behaviour Options"></NVLlabel>
            </div>
            <div className="nvl-FormContent pt-2">
              <NVLCheckbox id="movePreviousToNext" disabled={ watch("chkSetTime")} className="Center-Aligned-Items" text="Allow Move to Previous and Next Question" showFull register={register} errors={errors}></NVLCheckbox>
              {/* <NVLCheckbox id="AbortandAllowReAttempt" className="Center-Aligned-Items" text="Abort Immediately Whenever Cannot pass and allow for Re-attempt" register={register} showFull errors={errors}></NVLCheckbox> */}
            </div>


            <div className="translate-y-8">
              <NVLlabel className="nvl-Def-Label w-52" text="Grade"></NVLlabel>
            </div>
            <div className="nvl-FormContent  flex-col justify-center sm:flex-row   ">
              <Grade ActivityType={"Quiz"} register={register} errors={errors} watch={watch} setValue={setValue} AllowAttempt={true} Attempt={true} />
              <div className="grid gap-2">
                <NVLlabel text="Shuffle Questions"></NVLlabel>
                <div className=" flex gap-2">
                  <NVLRadio id="rbShuffleQuestions" value={"true"} text="Yes" name="rbShuffleQuestions" register={register}></NVLRadio>
                  <NVLRadio id="rbShuffleQuestions" value={"false"} text="No" name="rbShuffleQuestions" register={register}></NVLRadio>
                </div>
                <div className={" {invalid-feedback} text-red-500 text-sm "}>{errors?.rbShuffleQuestions?.message}</div>
                <NVLlabel text="Shuffle Answers"></NVLlabel>
                <div className=" flex gap-2">
                  <NVLRadio id="rbShuffleAnswers" value={"true"} text="Yes" name="rbShuffleAnswers" register={register}></NVLRadio>
                  <NVLRadio id="rbShuffleAnswers" value={"false"} text="No" name="rbShuffleAnswers" register={register}></NVLRadio>
                </div>
                <div className={" {invalid-feedback} text-red-500 text-sm"}>{errors?.rbShuffleAnswers?.message}</div>
                <div className="grid">
                  <NVLCheckbox id="chkAllowProctoring" text="Proctoring" register={register} errors={errors}></NVLCheckbox>
                  <NVLCheckbox id="chkAllowLockScreen" text="Lock Browser" register={register} errors={errors}></NVLCheckbox>
                </div>
                <DelayEnforce register={register} errors={errors} watch={watch} setValue={setValue} />
              </div>
            </div>
            <div className="nvl-Def-Label pt-4">
              <div className="translate-y-8">
                <NVLlabel text="Overall Feedback" className="font-semibold"></NVLlabel>
              </div>
              < div className=" nvl-FormContent">
                <Options errors={errors} register={register} />
              </div>
            </div>
            <div className="nvl-FormContent">
              <NVLButton
                id="btnfield"
                text="Add one more feedback field"
                type="button"
                ButtonType="primary"
                register={register}
                onClick={() => {
                  setState((state) => {
                    return state + 1;
                  });
                }}
              ></NVLButton>
            </div>
            <div className="nvl-Def-Label pt-4">
              <NVLlabel text="Review Options" className="font-semibold"></NVLlabel>
            </div>
            <div className="nvl-FormContent">
              <NVLCheckbox showFull={"showFull"} text="Show the answers Posted by the user." id="chkShowAnswers" errors={errors} register={register} ></NVLCheckbox>
              <NVLCheckbox showFull={"showFull"} text="Show both answers posted by user and the actual answer." id="chkShowBothAnswers" errors={errors} setValue={setValue} register={register} ></NVLCheckbox>
              <NVLCheckbox showFull={"showFull"} text="Show the score to all the users after the completion of quiz." id="chkShowScores" errors={errors} setValue={setValue} register={register} ></NVLCheckbox>
              <NVLCheckbox showFull={"showFull"} text="Hide the questions correctly answered by the user." id="chkHideQuestions" errors={errors} setValue={setValue} register={register} ></NVLCheckbox>
            </div>
            <div className="nvl-Def-Label">
              <div className="translate-y-8">
                <NVLlabel text="Activity Completion" className="font-semibold"></NVLlabel>
              </div>
              < div className=" nvl-FormContent">
                <ActivityCompletion className="nvl-FormContent" register={register} errors={errors} watch={watch} />
              </div>
            </div>
            <div className="nvl-Def-Label pt-4">
            </div>
            <div className="nvl-FormContent">
              <CheckboxesInput register={register} errors={errors} watch={watch} IsViewTheActivity={true} IsCompleteTheActivity={true} IsRequirePassingGrade={true} IsMarkTheActivity={true} setValue={setValue} />
              <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"}>
                <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation">
                  {watch("activitycompletionError")}
                </div>
              </div>
              <ReactTagsButton ButtonText="Save and Continue" ButtonClassName={"nvl-button bg-primary text-white "} register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} props={props} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
            </div>
          </div>
        </div>
      </form>
    </>
  );
}
export default QuizActivity;