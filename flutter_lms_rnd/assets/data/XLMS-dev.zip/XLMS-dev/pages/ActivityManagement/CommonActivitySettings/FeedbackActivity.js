import Container from "@components/Container/Container";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, DateTime, ReactTagsButton } from "./ActivityComponents";
export const FeedbackActivity = ({ DateCoversion, FinalResponse, query, props, router, Record }) => {

    const [customMessage, setCustomMessage] = useState("")
    const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
    let stDate = useRef();
    const validationSchema = Yup.object().shape({
        /*File And Language Error */
        /* CheckBox Input */
        chkViewTheActivity: Yup.bool().default(false).nullable(),
        chkCompleteTheActivity: Yup.bool().default(false).nullable(),
        chkMarkTheActivity: Yup.bool().default(false).nullable(),
        chkSubmitTheActivity: Yup.bool().default(false).nullable(),
        ChkUserCreateReplies: Yup.bool().default(false).nullable(),
        chkdisplay: Yup.bool().default(false).nullable(),
        chkcopyright: Yup.bool().default(false).nullable(),
        /*Enable Host Validation*/
        txtalternativehost: Yup.string()
            .nullable()
            .when("chkmeetingoption", {
                is: true,
                then: Yup.string().required("Alternative Host is required").nullable(true),
            }),

        txtCompletionMsg: Yup.string().nullable().max(100, "Maximum character does not exceed 100"),

        /*Date time Validation*/

        txtstdate: Yup.string()
            .nullable(true)
            .notRequired().test("Check", "Activity can be created only for present and future date", (e, { createError }) => {
                if ((e == "" || e == undefined || e == null) || (!(new Date(props?.EditData?.StartDate) > new Date(e)) && !(new Date(props?.EditData?.StartDate) < new Date(e)))) {
                    return true;
                }
                else {
                    if (new Date(e) > new Date(new Date().setMinutes(new Date().getMinutes() - 1))) {
                        if ((stDate.current != e) && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
                            stDate.current = e;
                            setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
                        } else {
                            clearErrors(["txtEnddate"])
                        }
                        return true;
                    }
                    else {
                        return false
                    }
                }
            }).nullable(true),

        txtEnddate: Yup.date()
            .when("chkEndDateEnable", {
                is: true,
                then: Yup.date().required("End Date is Required").typeError("End Date is invalid Value").nullable().test("error", "End Date must be greater than or equal to the start date", (e) => {

                    if (new Date(e) > new Date(watch("txtstdate"))) {
                        return true;
                    }
                    else {
                        return false
                    }
                }),
            })
            .nullable(true),
        /* Activity Completion */
        rbActivityCompletion: Yup.string()
            .required("Activity completion is required")
            .nullable()
            .test("error", "", (e, { createError }) => {
                if (e == "true") {
                    let array = ["chkUserParticipant", "chkMarkTheActivity", "chkSubmitTheFeedback"];
                    let result = [];
                    array.map((item) => {
                        result.push(watch(item));
                    });
                    if (result.indexOf(true) == -1) {
                        setValue("activitycompletionError", "At least one is required.");
                        return createError({ message: "At least one is required." });
                    } else {
                        setValue("activitycompletionError", undefined);
                        return true;
                    }
                } else {
                    setValue("chkUserParticipant", null);
                    setValue("chkMarkTheActivity", null);
                    setValue("chkSubmitTheFeedback", null);
                    setValue("activitycompletionError", undefined);
                }
                return true;
            })
            .nullable(),
        /* Tags */
        ReactTags: Yup.string()
            .test("testReactTags", "Keywords is Requried", (e) => {
                return true;
                if (e == "Add") {
                    return true;
                } else if (e == "Delete" && tags.length == 1 && props?.EditData?.Keywords == null) {
                    return false;
                }
                if (props?.EditData?.Keywords == null || tags.length == 0) {
                    return false;
                } else {
                    return true;
                }
            })
            .nullable(),

        //  Feedback*/
        // rbTemplateVisible: Yup.string()
        //     .nullable()
        //     .test("", "", (e) => {
        //         if (e == "false") {
        //             document.getElementById("txtTemplateName") ? (document.getElementById("txtTemplateName").value = "") : "";
        //         }
        //         return true;
        //     }),

        rbMultipleSubmission: Yup.string().required("Multiple submissions is required").nullable(),
        rbEnableSubmission: Yup.string().required("Enable notification of submissions is required").nullable(),
        rbRecordUser: Yup.string().required("Record user name is required").nullable(),
        rbShowAnalysis: Yup.string().required("Show analysis page is required").nullable(),

        txtNoofAttachment: Yup.string()
            .nullable()
            .transform((o, c) => (o === "" ? null : c))
            .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
            .test("error", "", (val, { createError }) => {
                if ((val != "" || val != undefined) && (parseInt(val) > 20 || parseInt(val) <= 0)) {
                    return createError({ message: "Attachment should be between 1-20" });
                }
                return true;
            }),
        txtLinkNextActivity: Yup.string().test("", "Url is invalid", (e) => {
            if (e == undefined || e == "") {
                return true;
            }
            const rejax = new RegExp(/(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/g);
            if (!rejax.test(e)) {
                return false;
            }
            return true;
        })
            .nullable(),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), nativeValidation: false };
    const { register, handleSubmit, setValue, watch, formState, reset, clearErrors } = useForm(formOptions);
    const { errors } = formState;

    const keyCodes = { comma: 188, enter: 13, tab: 9, };
    const delimiters = useMemo(() => {
        return [keyCodes.comma, keyCodes.enter, keyCodes.tab];
    }, [keyCodes.comma, keyCodes.enter, keyCodes.tab]);

    const handleAddition = useCallback(
        (tag) => {
            setTags([...tags, tag]);
            setValue("ReactTags", "Add", { shouldValidate: true });
        },
        [setValue, tags]
    );
    const handleDelete = useCallback(
        (i) => {
            setTags(tags.filter((tag, index) => index !== i));
            setValue("ReactTags", "Delete", { shouldValidate: true });
        },
        [setValue, tags]
    );

    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags, setTags]
    );

    /* Batch Update */

    //   useEffect(() => {
    //     let Datas = [];
    //     if (props.mode == "Edit") {
    //       async function getList() {
    //         for (let i = 1; i <= props.EditData.Shard; i++) {
    //           let editDatalist;
    //           editDatalist = await AppsyncDBconnection(
    //             getXlmsEnrollUser,
    //             {
    //               PK: "TENANT#" + props.EditData.TenantID + "#" + i,
    //               SK:
    //                 "ACTIVITYTYPE#" +
    //                 props.EditData.ActivityType +
    //                 "#ACTIVITYID#" +
    //                 props.EditData.ActivityID,
    //             },
    //             props.user.signInUserSession.accessToken.jwtToken
    //           );
    //           Datas.push(editDatalist?.res?.getXlmsEnrollUser);
    //         }
    //         setData(Datas);
    //       }
    //       getList();
    //     }
    //   }, [props]);

    /*End Batch Update*/

    useEffect(() => {
        setValue("rbTemplateVisible", props.EditData?.IsTemplate == null ? "false" : props.EditData?.IsTemplate?.toString());
        // setValue("txtTemplateName", (props.EditData?.IsTemplate == true) ? props.EditData?.TemplateName : "");
        setValue("txtstdate", DateCoversion(props.EditData?.StartDate) == "1970-01-01T05:30" || DateCoversion(props.EditData?.StartDate) == "NaN-NaN-NaNTNaN:NaN" ? undefined : DateCoversion(props.EditData?.StartDate));
        setValue("txtEnddate", DateCoversion(props.EditData?.EndDate));
        setValue("chkStartDateEnable", props.EditData?.IsStartDateEnable == null ? true : props.EditData?.IsStartDateEnable);
        setValue("chkEndDateEnable", props.EditData?.IsEndDateEnable);
        setValue("ddlRecordUserName", props.EditData?.RecordUserName == null ? "ShowWithAnswers" : props.EditData?.RecordUserName);
        setValue("rbMultipleSubmission", props.EditData?.IsMultipleSubmissions == null ? "false" : props.EditData?.IsMultipleSubmissions?.toString());
        setValue("rbEnableSubmission", props.EditData?.IsNotificationSubmission == null ? "false" : props.EditData?.IsNotificationSubmission?.toString());
        setValue("rbRecordUser", props.EditData?.IsRecordUserName == null ? "false" : props.EditData?.IsRecordUserName?.toString());
        setValue("rbShowAnalysis", props.EditData?.IsAnalysisPage == null ? "false" : props.EditData?.IsAnalysisPage?.toString());
        setValue("txtCompletionMsg", props.EditData?.CompletionMessage);
        setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion?.toString() == null || props.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : props.EditData?.IsActivityCompletion?.toString());
        setValue("chkUserParticipant", props.EditData?.IsViewTheActivity);
        setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
        setValue("chkSubmitTheFeedback", props.EditData?.IsSubmitTheActivity);
        setValue("txtLinkNextActivity", props.EditData?.LinkNextActivity);
    }, [DateCoversion, props.EditData?.CompletionMessage, props.EditData?.EndDate, props.EditData?.IsAnalysisPage, props.EditData?.IsActivityCompletion, props.EditData?.IsEndDateEnable, props.EditData?.IsMarkTheActivity, props.EditData?.IsMultipleSubmissions, props.EditData?.IsNotificationSubmission, props.EditData?.IsRecordUserName, props.EditData?.IsStartDateEnable, props.EditData?.IsSubmitTheActivity, props.EditData?.IsTemplate, props.EditData?.IsViewTheActivity, props.EditData?.RecordUserName, props.EditData?.StartDate, props.EditData.TemplateName, setValue, watch, props.EditData?.LinkNextActivity])

    const submitHandler = async (data) => {
        setValue("submit", true)
        let PK, SK, tempDate = {};

        PK = "TENANT#" + props.TenantInfo.TenantID;
        SK = props.EditData.SK;
        if (props.mode == "TrainingEdit") {
            tempDate = {
                LastModifiedBy: props.user.username,
                LastModifiedDate: new Date()
            }
        } else {
            tempDate = {
                ModifiedBy: props.user.username,
                ModifiedDate: new Date()
            }
        }

        let feedbackVariables = {
            input: {
                ...tempDate,
                PK: PK,
                SK: SK,
                IsTemplate: data.rbTemplateVisible,
                StartDate: data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : null,
                EndDate: data.txtEnddate != undefined || data.txtEnddate != "" ? data.txtEnddate : undefined,
                AvailabilityStartTime: data.txtStarttime,
                AvailabilityEndTime: data.txtEndtime,
                RecordUserName: data.ddlRecordUserName,
                IsStartDateEnable: data.chkStartDateEnable,
                IsEndDateEnable: data.chkEndDateEnable,
                IsMultipleSubmissions: data.rbMultipleSubmission,
                IsNotificationSubmission: data.rbEnableSubmission,
                IsRecordUserName: data.rbRecordUser,
                IsAnalysisPage: data.rbShowAnalysis,
                CompletionMessage: data.txtCompletionMsg,
                IsActivityCompletion: data.rbActivityCompletion,
                IsViewTheActivity: watch("rbActivityCompletion") == false ? false : data.chkUserParticipant,
                IsMarkTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkMarkTheActivity,
                IsSubmitTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkSubmitTheFeedback,
                Keywords: JSON.stringify(tags),
                LinkNextActivity: data.txtLinkNextActivity,
            },
        };

        /*Batch Update*/
        let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
        for (let i = 1; i <= props.EditData.Shard; i++) {
            UpdateBatch({
                inn: { ...props.EditData, ...feedbackVariables.input },
                props: props,
                pk: "TENANT#" + props.EditData.TenantID + "#" + i,
                query: queryBatch,
                UpdateData: props.EditData,
            });
        }

        let finalStatus = (await AppsyncDBconnection(query, feedbackVariables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        FinalResponse(finalStatus);
        setValue("submit", false)
    };
    return (
        <Container loader={watch("chkStartDateEnable") == undefined}>
            <form>
                <div id="divFeedback" className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}>
                    <div className="container px-12 mx-auto grid gap-8">
                        <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name : ${props.EditData?.ActivityName}`}></NVLlabel>
                        <NVLlabel
                            className="nvl-Def-Label "
                            id="lblActivityType"
                            text={`Activity Type : ${router?.query?.ActivityType}`}
                        ></NVLlabel>
                        {/* <div className="flex flex-col sm:flex-row  gap-4">
                            <NVLlabel
                                className="nvl-Def-Label w-52"
                                id="lblTemplate"
                                text="Template"
                            ></NVLlabel>
                            <TemplateVisible register={register} errors={errors} watch={watch} />
                        </div> */}
                        <div className="flex flex-col sm:flex-row  gap-4 ">
                            <NVLlabel
                                className="nvl-Def-Label w-52"
                                id="lblAvailability"
                                text="Availabilty"
                            ></NVLlabel>
                            <DateTime setValue={setValue} register={register} errors={errors} watch={watch} reset={reset} />
                        </div>
                        <div className="flex flex-col sm:flex-row  gap-4">
                            <NVLlabel
                                text="Question & Submission Settings"
                                className="nvl-Def-Label w-52"
                            ></NVLlabel>
                            <div>
                                <NVLlabel text="Record User Names"></NVLlabel>
                                <NVLSelectField
                                    id="ddlRecordUserName"
                                    className={"nvl-non-mandatory nvl-Def-Input"}
                                    options={Record}
                                    errors={errors}
                                    register={register}
                                    showFull
                                ></NVLSelectField>
                                <NVLlabel
                                    text="Allow Multiple Submissions"
                                    className="pt-3 nvl-Def-Label w-52"
                                ></NVLlabel>
                                <div className="flex gap-16">
                                    <NVLRadio
                                        text="Yes"
                                        name="rbMultipleSubmission"
                                        id="rbMultipleSubmission"
                                        value={"true"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                    <NVLRadio
                                        text="No"
                                        name="rbMultipleSubmission"
                                        id="rbMultipleSubmission"
                                        value={"false"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                </div>
                                <div
                                    className={" {invalid-feedback} text-red-500 text-sm "}
                                >
                                    {errors?.rbMultipleSubmission?.message}
                                </div>
                                <NVLlabel
                                    className="pt-3 nvl-Def-Label w-full"
                                    text="Enable notification of submissions"
                                ></NVLlabel>
                                <div className="flex gap-16">
                                    <NVLRadio
                                        text="Yes"
                                        name="rbEnableSubmission"
                                        id="rbEnableSubmission"
                                        value={"true"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                    <NVLRadio
                                        text="No"
                                        name="rbEnableSubmission"
                                        id="rbEnableSubmission"
                                        value={"false"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                </div>
                                <div
                                    className={" {invalid-feedback} text-red-500 text-sm "}
                                >
                                    {errors?.rbEnableSubmission?.message}
                                </div>
                                <NVLlabel
                                    className="pt-3 nvl-Def-Label w-52"
                                    text="Record User Name"
                                ></NVLlabel>
                                <div className="flex gap-16">
                                    <NVLRadio
                                        text="Yes"
                                        name="rbRecordUser"
                                        id="rbRecordUser"
                                        value={"true"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                    <NVLRadio
                                        text="No"
                                        name="rbRecordUser"
                                        id="rbRecordUser"
                                        value={"false"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                </div>
                                <div
                                    className={" {invalid-feedback} text-red-500 text-sm "}
                                >
                                    {errors?.rbRecordUser?.message}
                                </div>

                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row  gap-4">
                            <NVLlabel
                                text="After Submission"
                                className="nvl-Def-Label w-52"
                            ></NVLlabel>
                            <div>
                                <NVLlabel
                                    className="pt-0 nvl-Def-Label w-52"
                                    text="Show Analysis Page"
                                ></NVLlabel>
                                <div className="flex gap-16">
                                    <NVLRadio
                                        text="Yes"
                                        name="rbShowAnalysis"
                                        id="rbShowAnalysis"
                                        value={"true"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                    <NVLRadio
                                        text="No"
                                        name="rbShowAnalysis"
                                        id="rbShowAnalysis"
                                        value={"false"}
                                        errors={errors}
                                        register={register}
                                    ></NVLRadio>
                                </div>
                                <div
                                    className={" {invalid-feedback} text-red-500 text-sm "}
                                >
                                    {errors?.rbShowAnalysis?.message}
                                </div>
                            </div>

                        </div>
                        <div className="flex flex-col sm:flex-row gap-4   ">
                            <NVLlabel
                                className="pt-3 nvl-Def-Label w-52"
                                text="Completion Message"
                            ></NVLlabel>
                            <NVLMultilineTxtbox
                                id="txtCompletionMsg"
                                title="Completion Message"
                                className={"nvl-non-mandatory nvl-Def-Input"}
                                errors={errors}
                                register={register}
                            ></NVLMultilineTxtbox>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-4   ">
                            <NVLlabel
                                className="pt-3 nvl-Def-Label w-52"
                                text="Link to next activity / URL"
                            ></NVLlabel>
                            <NVLTextbox
                                id="txtLinkNextActivity"
                                title="Url"
                                className={"nvl-non-mandatory nvl-Def-Input"}
                                errors={errors}
                                register={register}
                            ></NVLTextbox>
                        </div>

                        <div className="flex flex-col sm:flex-row gap-4 ">
                            <NVLlabel text="Activity Completion" className="nvl-Def-Label w-52"></NVLlabel>
                            <div>
                                <ActivityCompletion register={register} errors={errors} watch={watch} />
                                <CheckboxesInput register={register} errors={errors} watch={watch} CustomMessage={customMessage} IsMarkTheActivity={true}>
                                    <NVLCheckbox text="User participant the activity to complete it." id="chkUserParticipant" errors={errors} register={register} showFull>
                                        {" "}
                                    </NVLCheckbox>
                                    <NVLCheckbox text="View as completed if the feedback is submitted." id="chkSubmitTheFeedback" errors={errors} register={register} setValue={setValue} showFull></NVLCheckbox>
                                </CheckboxesInput>
                                <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"} >
                                    <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation">
                                        {watch("activitycompletionError")}
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4  ">
                            <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52" />
                            <div>
                                <ReactTagsButton ButtonText="Save and Continue" ButtonClassName={"nvl-button bg-primary text-white "} register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} props={props} submitHandler={submitHandler} router={router} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </Container>
    );
}
export default FeedbackActivity;