import NVLButton from "@components/Controls/NVLButton";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLlabel from "@components/Controls/NVLlabel";
import { useState } from "react";
import NVLGradeForm from "./NVLGradeForm";

export default function NVLFileList(props) {

    const [comment,setComment]=useState("");

    function getDateFormat(CreatedDt) {
        return new Date(CreatedDt).toDateString().substring(4);
    }

    return (
        <div className="w-[60%] my-auto p-2 flex flex-col justify-between gap-2">
            <NVLModalPopup Content={comment} IsCloseIcon CloseIconEvent={() => setComment("")} IsConfirmAlert />
            <section className="border h-1/6 p-2 rounded-xl shadow-md flex justify-between">
                <article className="w-2/4 m-auto px-2 space-y-1">
                    {(props.CourseID !== undefined)&&<div className="w-full flex"><label className="nvl-Def-Label !font-bold w-[40%]">{"Course Name"}</label><label className="nvl-Def-Label w-[60%]">: {` ${props.data?.list?.[props.data.index]?.CourseName}`}</label></div>}
                    <div className="w-full flex"><label className="nvl-Def-Label !font-bold w-[40%]">{"Activity Name"}</label><label className="nvl-Def-Label w-[60%]">{`: ${props.data?.name}`}</label></div>
                    <div className="w-full flex"><label className="nvl-Def-Label !font-bold w-[40%]">No.of attempts</label><label className="nvl-Def-Label w-[60%]">{`: 1`}</label></div>
                    {/* {(props.CourseID !== undefined) ? <NVLlabel text={"Course : course1"} className={"nvl-Def-Label"} /> : <NVLlabel text={`Activity Name : ${props.data?.name} `} className={"nvl-Def-Label"} />}
                    <NVLlabel text={"No.of attempts : 1"} className={"nvl-Def-Label"} /> */}
                </article>
                <article className="px-7 m-auto relative w-2/4">
                    <div className="w-full flex overflow-hidden"><label className="nvl-Def-Label !font-bold w-[40%]">User Name</label><label className="nvl-Def-Label w-[60%] whitespace-nowrap">{`: ${props.data?.list?.length > 0 && props.data?.list[props.data.index]?.UserName}`}</label></div>
                    <div className="w-full flex overflow-hidden"><label className="nvl-Def-Label !font-bold w-[40%]">MailID</label><label className="nvl-Def-Label w-[60%] font-light whitespace-nowrap">{`: ${props.data?.list?.length > 0 && props.data?.list[props.data.index]?.EmailID}`}</label></div>
                    <div className="w-full flex"><label className="nvl-Def-Label !font-bold w-[40%]">End Date</label><label className="nvl-Def-Label w-[60%]">{`: ${props.data?.EndDate!==undefined&&props.data?.EndDate!==null?getDateFormat(props.data?.EndDate):"mm/dd/yyyy"}`}</label></div>
                   {/* <NVLlabel text={`User Name : ${props.data?.list?.length > 0 && props.data?.list[props.data.index]?.FirstName}`} className={"nvl-Def-Label"} />
                    <NVLlabel text={`MailID : ${props.data?.list?.length > 0 && props.data?.list[props.data.index]?.EmailID}`} className={"nvl-Def-Label"} />
                    <NVLlabel text={"End date : 15-Feb-2023"} className={"nvl-Def-Label"} /> */}
                    {props.data.index !== 0 ? <button id="prev-btn" className="absolute top-0 left-0 p-2 bottom-0 h-full" onClick={() => props.prev()}><i className="fa-solid fa-caret-left"></i></button> : props.prevtoken && <button id="prev-btn" className="absolute top-0 left-0 p-2 bottom-0 h-full" onClick={() => props.prev()}><i className="fa-solid fa-caret-left"></i></button>}
                    {props.data.index !== props.data?.list?.length - 1 ? <button id="next-btn" className="absolute top-0 p-2 right-0 bottom-0 h-full" onClick={() => props.next()}><i className="fa-solid fa-caret-right"></i></button> :  props.nexttoken && <button id="next-btn" className="absolute top-0 p-2 right-0 bottom-0 h-full" onClick={() => props.next()}><i className="fa-solid fa-caret-right"></i></button>}
                </article>
            </section>
            <section className="border h-5/6 rounded-xl shadow-md p-2 space-y-2  w-full">
                <NVLlabel text={"Details"} className={"nvl-Def-Label !font-extrabold !text-sm"} />
                <div className="w-3/4 flex "><label className="nvl-Def-Label !font-bold !text-sm w-2/4">Status</label><label className="text-sm">{`:${props.data?.list?.[props.data?.index]?.UserGradeDetails != undefined ? " Graded" : " Not Graded"}`}</label></div>
                <div className="w-3/4 flex"><label className="nvl-Def-Label !font-bold !text-sm w-2/4">Submission Date</label><label className="text-sm">{`: ${props.filesource?.files?.length > 0 ? getDateFormat(props.filesource?.files?.[0]?.Date) : " Not submitted"}`}</label></div>
                <div className="w-3/4 flex"><label className="nvl-Def-Label !font-bold !text-sm w-2/4">Final Submission</label><label className="text-sm">{`: ${props.filesource?.files?.length > 0 ? getDateFormat(props.filesource?.files?.[props.filesource?.filepath]?.Date) : " Not submitted"}`}</label></div>
                {/* <NVLlabel text={`Status : ${props.data?.list?.[props.data?.index]?.UserGradeDetails != undefined ? "Graded" : "Not Graded"}`} className={"nvl-Def-Label"} />
                <NVLlabel text={`Submission Date : ${props.filesource?.files?.length > 0 ? getDateFormat(props.filesource?.files?.[props.filesource?.filepath]?.Date) : "Not submitted"}`} className={"nvl-Def-Label"} /> */}
                {/* <NVLlabel text={"Final Submission : 22/08/2023"} className={"nvl-Def-Label"} /> */}
                <NVLlabel text={"User Attached File"} className={"nvl-Def-Label !font-extrabold !text-sm"} />
                {(props.filesource?.files?.length > 0 && props.data?.list?.[props.data?.index]?.SubmissionAssignment !== null) ? props.filesource?.files?.map((data, index) => <div className="flex justify-between w-full" key={index}>
                <NVLlabel text={data.FileName} className="!text-sm" showFull/>
                <section className="inline-flex gap-3">
                    {data.FileName !== undefined && <span onClick={() => props.download(data?.FilePath?.substring(1))} className="fa-solid fa-download text-xl text-blue-500 cursor-pointer"><i className="fa-downloadtext-xl text-blue-500 cursor-pointer"></i></span>}
                    {data.FileName !== undefined && <NVLButton type={"button"} text={"view"} ButtonType={"primary"} className="w-fit border-none bg-transparent" onClick={() => props.setFileSource(prev => ({ ...prev, filepath: index }))} />}
                    {(data.Comments !== undefined) && <><NVLButton type={"button"} text={"Show Comment"} ButtonType={data.Comments != "" ? "primary" : "light"} className="w-fit border-none bg-transparent" onClick={() => setComment(data.Comments)} /></>}
                </section>
                </div>): <NVLlabel text={"No file is uploaded"} className="!text-sm"></NVLlabel>}
                <NVLGradeForm TenantInfo={props.TenantInfo} setData={props.setData} user={props.user} data={props.data} path={props.pageRoutes?.[props.pageRoutes?.length - 2]?.path} GradeOption={props.data?.GradeOption} generateCertificate={props.generateCertificate} filesource={props.filesource} next={props.next} nexttoken={props.nexttoken}/>
            </section>
        </div>
    )
}
