import { DynamicFileLanguageValidation } from "@Pages/ActivityManagement/CommonActivitySettings/CommonFunction";
import { GetDateFormat } from "@components/Common/DateFormat";
import NVLDynamicLanguageFile from "@components/Controls/NVLDynamicLanguageFile";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, DateComponent, Grade, ReactTagsButton } from "./ActivityComponents";

export const AssignmentActivity = ({ CurrentDiv, CustomMessage, ErrorRef,
  Attempt, UnSavedtoSaved, LanguageType, FinalResponse, query, props,
  delimiters, router, GetOnlyDate }) => {

  let initialValue = [{ Language: "", FileName: props.mode == "Edit" ? props.EditData?.AttachFile && props.EditData?.AttachFile.substring(props.EditData?.AttachFile.lastIndexOf("/") + 1, props.EditData?.AttachFile.length) : "Select File", FilePath: props.mode == "Edit" ? props.EditData?.AttachFile : "", path: props.mode == "Edit" ? props.EditData?.AttachFile : "", PathChanged: false, }]
  const [fileValues, setFileValues] = useState(initialValue);
  const dynamicFileRef = useRef("1");
  const activityCompleteRef = useRef("false");
  const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);

  const stDate = useRef();
  const endDate = useRef();

  const validationSchema = Yup.object().shape({
    /* Dynamic Language */
    FileLang: Yup.string()
      .test("file_Error", "", (e, { createError }) => {
        let message = DynamicFileLanguageValidation(e, "ddlAssignment", fileValues);
        if (message != "" && message != watch("dynamicError")) {
          setValue("dynamicError", message);
          return createError({ message: message });
        }
        else if (watch("dynamicError") != undefined && message != "") {
          return createError({ message: watch("dynamicError") });

        } else if (watch("dynamicError") != undefined) {
          setValue("dynamicError", undefined);
          return true;
        }
        else {
          return true;
        }

      })
      .nullable(),

    /* Activity Download */
    rbFileDownload: Yup.string()
      .nullable()
      .test("", "", () => {
        dynamicFileRef.current = dynamicFileRef.current;
        activityCompleteRef.current = activityCompleteRef.current;
        return true;
      }),
    txtstdate: Yup.string()
      .nullable(true)
      .notRequired().test("Check", "Activity can be created only for present and future date", (e, { createError }) => {
        if (e == "" || e == undefined || e == null) {
          return true;
        }
        else {
          if (new Date(e).toDateString() != new Date(props.EditData?.StartDate).toDateString()) {
            if (new Date(e) > new Date(new Date().setDate(new Date().getDate() - 1))) {
              if ((stDate.current != e)) {
                if ((watch("chkEndDateEnable") != undefined && watch("chkEndDateEnable")) &&
                  ((watch("chkEndDateEnable") != undefined && (new Date(watch("txtEnddate")) < new Date(e))))) {
                  setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
                } else {
                  clearErrors(["txtEnddate"])
                }
                if ((watch("chkCutDateEnable") != undefined && watch("chkCutDateEnable"))
                  && (watch("txtCutdate") != undefined && watch("txtEnddate") != undefined) &&
                  (new Date(watch("txtCutdate")) < new Date(e) || new Date(watch("txtCutdate")) < new Date(watch("txtEnddate")))) {
                  setValue("txtCutdate", watch("txtCutdate"), { shouldValidate: true })
                } else {
                  clearErrors(["txtCutdate"])
                }
                stDate.current = e;
              }
              return true;
            }
            else {
              return false
            }
          } else {
            return true
          }
        }
      }).nullable(true),

    txtEnddate: Yup.string()
      .when("chkEndDateEnable", {
        is: true,
        then: Yup.string().required("End Date is Required").typeError("End Date is invalid Value").test("error", "End Date must be greater than the start date", (e) => {
          if (new Date(e) > new Date(watch("txtstdate"))) {
            if ((endDate.current != e)) {
              if ((watch("chkCutDateEnable") != undefined && watch("chkCutDateEnable"))
                && (watch("txtCutdate") != undefined && watch("txtstdate") != undefined) &&
                (new Date(watch("txtCutdate")) < new Date(watch("txtstdate")) || new Date(watch("txtCutdate")) < new Date(e))) {
                setValue("txtCutdate", watch("txtCutdate"), { shouldValidate: true })
              } else {
                clearErrors(["txtCutdate"])
              }
              endDate.current = e;
            }

            return true;
          }
          else {
            return false
          }
        }),
        otherwise: Yup.string().test("novalid", "noError", e => {
          if (e != undefined) {
            setValue("txtEnddate", "");
          }
          if (watch("chkEndDateEnable") == false) {
            setValue("chkCutDateEnable", false);
          }
          if (watch("chkCutDateEnable") == false) {
            setValue("chkCutDateEnable", false);
          }
          if (watch("txtCutdate") != undefined) {
            setValue("txtCutdate", undefined);
          }
          clearErrors(["txtEnddate", "txtCutdate"])

          return true
        }).nullable(true)
      })
      .nullable(true),
    chkCutDateEnable: Yup.bool().nullable(true).test("e", "novalid", e => {
      if ((!e || e == undefined) && errors?.txtCutdate?.message != undefined) {
        setValue("txtCutdate", undefined);
        clearErrors(["txtCutdate"])
      }
      return true;
    }),
    txtCutdate: Yup.date()
      .when("chkCutDateEnable", {
        is: true,
        then: Yup.date().required("Cut-Off Date is Required").typeError("Cut-Off Date is invalid Value").test("error", "Cut Off Date must be greater than the End Date", (e) => {
          if (new Date(e) > new Date(watch("txtstdate")) && new Date(e) > new Date(watch("txtEnddate"))) {
            return true;
          }
          else {
            return false
          }
        }),
        otherwise: Yup.date().nullable(true).test("novalid", "noError", e => {
          if (e != undefined) {
            setValue("txtCutdate", undefined);
          }
          if (errors?.txtCutdate?.message != undefined) {
            clearErrors(["txtCutdate"])
          }
          return true
        })
      })
      .nullable(true),
    txtAssgmntDuration: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .matches(Regex("AllowOnlyNumbers"), "Invalid value")
      .nullable()
      .test("len", "Must be limit digits", (val, { createError }) => {
        let LimitedTime = 999;
        if (val == "0") {
          return createError({
            message: `Duration should be greater than zero.`,
          });
        }
        if (val?.length == "1") {
          return true;
        }

        else if (val > LimitedTime) {
          return createError({
            message: `Maximum duration allows only 3 digits.`,
          });
        }
        else if (parseInt(val) <= 0) {
          return createError({ message: `Duration only positive values and more then zero` });
        }
        else {
          return true;
        }
      }),
    txtMaximum: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .required("Enter valid value")
      .nullable()
      .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
      .test("error", "", (val, { createError }) => {
        if ((val != "" || val != undefined)) {
          if ((parseInt(val) > 1024 || parseInt(val) <= 0)) {
            return createError({ message: "Maximum File Size should be 1-1024 MB" });
          }
        }
        return true;
      }),
    txtNoofAttachment: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .required("Enter valid value")
      .nullable()
      .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
      .test("error", "", (val, { createError }) => {
        if ((val != "" || val != undefined) && (parseInt(val) > 20 || parseInt(val) <= 0)) {
          return createError({ message: "Attachment should be between 1-20" });
        }
        return true;
      }),

    /* Activity Completion */
    rbActivityCompletion: Yup.string()
      .required("Activity completion is required")
      .nullable()
      .test("error", "", (e, { createError }) => {
        if (e == "true") {
          let array = ["chkViewTheActivity", "chkCompleteTheActivity", "chkMarkTheActivity", "chkSubmitTheActivity", "chkUserCompleteTheActivity"];
          let result = [];
          array.map((item) => {
            result.push(watch(item));
          });
          if (result.indexOf(true) == -1) {
            setValue("activitycompletionError", "At least one is required.");
            return createError({ message: "At least one is required." });
          } else {
            setValue("activitycompletionError", undefined);
            return true;
          }
        } else {
          if (watch("chkViewTheActivity") != null)
            setValue("chkViewTheActivity", null);
          if (watch("chkCompleteTheActivity") != null)
            setValue("chkCompleteTheActivity", null);
          if (watch("chkSubmitTheActivity") != null)
            setValue("chkSubmitTheActivity", null);
          if (watch("chkMarkTheActivity") != null)
            setValue("chkMarkTheActivity", null);
          if (watch("chkUserCompleteTheActivity") != null)
            setValue("chkUserCompleteTheActivity", null)
          if (watch("activitycompletionError") != null)
            setValue("activitycompletionError", undefined);
        }
        return true;
      })
      .nullable(),
    ddlAllowAtmpt: Yup.string().nullable(),
    ddlMaxAtmpt: Yup.string().nullable(),
    ddlGrdMethod: Yup.string().nullable(),
    txtMaxGrade: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .nullable()
      .min(1)
      .matches(Regex("AllowNumbersWithDot"), "Numbers only Allowed")
      .test(1000, "Maximum grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        if (val == null || val == undefined || val == "") {
          return true;
        }
        if (parseInt(val) == 0) {
          return createError({ message: "Enter the valid value" });
        }
        if (parseFloat(val) > 100.00) {
          return createError({ message: "Maximum grade should be less than or equal to 100" });
        }
        if (parseFloat(watch("txtPassGrade")) > parseFloat(val)) {
          return createError({ message: "Maximum grade should be greater than or equal to passing grade" });
        }
        if (val.includes(".")) {
          let valcheck = val.split(".");
          if (parseInt(valcheck[0]) > 999 || parseInt(valcheck[1]) >= 100 || valcheck[1].length > 2) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        } else {
          if (parseInt(val) > 999) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        }
        if (parseFloat(watch("txtPassGrade")) <= parseFloat(val) && errors?.txtPassGrade != undefined) {
          clearErrors(["txtPassGrade"]);
        }
        return true;
      }),
    txtPassGrade: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .nullable()
      .min(1)
      .matches(Regex("AllowNumbersWithDot"), "Numbers only Allowed")
      .test("error", "Passing grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        if (val == null || val == undefined || val == "") {
          return true;
        }
        if (parseInt(val) == 0) {
          return createError({ message: "Enter the valid value" });
        }
        if (watch("txtMaxGrade") == undefined || watch("txtMaxGrade") == "" || watch("txtMaxGrade") == "0") {
          return createError({ message: "Passing Grade Must be less than or equal to maximum grade" });
        }
        else if (watch("txtMaxGrade") != undefined && parseFloat(watch("txtMaxGrade")) < parseFloat(val)) {
          return createError({ message: "Passing Grade Must be less than or equal to maximum grade" });
        }
        if (val.includes(".")) {
          let valcheck = val.split(".");
          if (parseInt(valcheck[0]) >= 1000 || parseInt(valcheck[1]) >= 100 || valcheck[1].length > 2) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        } else {
          if (parseInt(val) >= 1000) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        }
        if (parseFloat(watch("txtMaxGrade")) >= parseFloat(val) && errors?.txtMaxGrade != undefined) {
          clearErrors(["txtMaxGrade"]);
        }
        return true;
      }),
    /* Activity Download */
    rbFileDownload: Yup.string().nullable(),
  });
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), nativeValidation: false };
  const { register, handleSubmit, setValue, clearErrors, watch, formState, reset } = useForm(formOptions);
  const { errors } = formState;

  const handleDelete = useCallback(
    (i) => {
      setTags(tags.filter((tag, index) => index !== i));
      setValue("ReactTags", "Delete", { shouldValidate: true });
    },
    [setValue, tags]
  );

  const handleAddition = useCallback(
    (tag) => {
      setTags([...tags, tag]);
      setValue("ReactTags", "Add", { shouldValidate: true });
    },
    [setValue, tags]
  );

  const handleDrag = useCallback(
    (tag, currPos, newPos) => {
      const newTags = tags.slice();
      newTags.splice(currPos, 1);
      newTags.splice(newPos, 0, tag);
      setTags(newTags);
    },
    [tags, setTags]
  );
  useEffect(() => {
    if (watch("rbFileDownload") == undefined) {
      setValue("rbFileDownload", (props.EditData?.IsDownload == null || props.EditData?.IsDownload == undefined ? "false" : props.EditData?.IsDownload?.toString()));
      setValue("txtAssgmntDuration", props.EditData?.ActivityDuration);
      setValue("txtMaxGrade", props.EditData?.MaximumGrade);
      setValue("ddlAllowAtmpt", props.EditData?.AllowMaximumAttempts);
      setValue("txtPassGrade", props.EditData?.PassingGrade);
      setValue("ddlMaxAtmpt", props.EditData?.MaximumAttempt == null ? "" : props.EditData?.MaximumAttempt);
      setValue("ddlGrdMethod", props.EditData?.GradingMethod == null ? "" : props.EditData?.GradingMethod);
      setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
      setValue("chkCompleteTheActivity", props.EditData?.IsGradableActivity)
      setValue("chkSubmitTheActivity", props.EditData?.IsSubmitTheActivity);
      setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
      setValue("chkStartDateEnable", props.EditData?.IsStartDateEnable == null ? true : props.EditData?.IsStartDateEnable);
      setValue("chkEndDateEnable", props.EditData?.IsEndDateEnable);
      setValue("chkCutDateEnable", props.EditData?.IsCutOfDateEnable);
      setValue("txtstdate", GetOnlyDate(props.EditData?.StartDate));
      setValue("txtEnddate", GetOnlyDate(props.EditData?.EndDate));
      setValue("txtCutdate", GetOnlyDate(props.EditData?.CutOfDate));
      setValue("txtMaximum", props.EditData?.MaxmumAttachmentSize);
      setValue("txtNoofAttachment", props.EditData?.MaximumNumberOfAttachment);
      setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion == null ? "false" : props.EditData?.IsActivityCompletion?.toString());
      if (props?.EditData?.AttachFiles != null && JSON.parse(props?.EditData?.AttachFiles).length > 0) {
        setFileValues([...JSON.parse(props?.EditData?.AttachFiles)])
      }
    }
  }, [GetOnlyDate, props, setValue, watch])

  const submitHandler = async (data) => {
    setValue("submit", true);
    let PK, SK;
    if (props.mode == "ModuleDirect") {
      PK = "TENANT#" + props.TenantInfo.TenantID;
      SK = props?.EditData?.SK
    } else if (props.mode == "Edit") {
      PK = "TENANT#" + props.TenantInfo.TenantID;
      SK = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
    }
    let MultilangFiles = await UnSavedtoSaved(fileValues);

    if (MultilangFiles != null || MultilangFiles != undefined) {
      let Asgnmtvariables = {
        input: {
          PK: PK,
          SK: SK,
          AttachFiles: JSON.stringify(MultilangFiles),
          TenantName: props.TenantDisplayName,
          AttachFile: fileValues.pathchanged ? objUrl : props.EditData?.AttachFile,
          ActivityDuration: data.txtAssgmntDuration,
          IsDownload: data.rbFileDownload,
          MaximumGrade: data.txtMaxGrade,
          MaximumAttempt: data.ddlMaxAtmpt,
          PassingGrade: data.txtPassGrade,
          GradingMethod: data.ddlGrdMethod,
          AllowMaximumAttempts: data.ddlAllowAtmpt,
          StartDate: GetDateFormat(data.txtstdate, "±YYYYYY-MM-DDTHH:mm:ss"),
          EndDate: GetDateFormat(data.txtEnddate, "±YYYYYY-MM-DDTHH:mm:ss"),
          CutOfDate: GetDateFormat(data.txtCutdate, "±YYYYYY-MM-DDTHH:mm:ss"),
          IsActivityCompletion: data.rbActivityCompletion,
          IsViewTheActivity: watch("rbActivityCompletion") == "true" ? data.chkViewTheActivity : false,
          IsSubmitTheActivity: watch("rbActivityCompletion") == "true" ? data.chkSubmitTheActivity : false,
          IsMarkTheActivity: watch("rbActivityCompletion") == "true" ? data.chkMarkTheActivity : false,
          IsGradableActivity: watch("rbActivityCompletion") == "true" ? data.chkCompleteTheActivity : false,
          IsStartDateEnable: data.chkStartDateEnable,
          IsEndDateEnable: data.chkEndDateEnable,
          IsCutOfDateEnable: data.chkCutDateEnable,
          MaxmumAttachmentSize: data.txtMaximum,
          MaximumNumberOfAttachment: data.txtNoofAttachment,
          Keywords: JSON.stringify(tags),
          ModifiedBy: props.user.username,
          ModifiedDate: new Date()
        },
      };
      /*Batch Update*/
      let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
      for (let i = 1; i <= props.EditData.Shard; i++) {
        UpdateBatch({ UpdateData: props.EditData, inn: { ...props.EditData, ...Asgnmtvariables.input }, props: props, pk: "TENANT#" + props.EditData.TenantID + "#" + i, query: queryBatch });
      }
      /*Batch Update*/
      let FinalStatus = (await AppsyncDBconnection(query, Asgnmtvariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
      FinalResponse(FinalStatus);
      setValue("submit", false);
    }
  };

  return (
    <section>
      <form>
        <div id="divAssignment" className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}>
          <div className="container px-12 mx-auto grid gap-8 ">
            <NVLlabel showFull={true} className="nvl-Def-Label" text={`Activity Name : ${props?.EditData?.ActivityName}`} />
            <NVLlabel className="nvl-Def-Label " text={`Activity Type  :  Assignment`} />
            <div className="flex flex-col sm:flex-row  gap-4">
              <NVLlabel text="Attach File" className="nvl-Def-Label w-52">
                <span className="text-red-500 text-lg">*</span>
              </NVLlabel>
              <NVLDynamicLanguageFile mode={props.mode} ActivityType={props.ActivityType} ActivityID={props.ActivityID} EditData={props.EditData} TenantInfo={props.TenantInfo} CurrentDiv={CurrentDiv} FileValues={fileValues} setFileValues={setFileValues} setValue={setValue} SelectFieldOptions={LanguageType} id="getFile" ddlId="ddlAssignment" ValidateError={errors?.File?.message} LoaderId="loader" watch={watch} errors={errors} register={register} FileError={watch("dynamicError")} HelpInfo="File size should be 1GB<br> Acceptable file format: docx, doc, ppt,pptx, pdf, csv, jpg, jpeg, png, avi, mov,xls,xlsx, mp4" />
            </div>
            <div className="flex flex-col sm:flex-row  gap-4 ">
              <NVLlabel className="nvl-Def-Label w-52" text="Activity Duration(min)"></NVLlabel>
              <NVLTextbox id="txtAssgmntDuration" title={"Duration"} className="nvl-non-mandatory w-64 md:w-96" errors={errors} register={register}></NVLTextbox>
            </div>

            <div className="flex flex-col sm:flex-row  gap-4 ">
              <NVLlabel className="nvl-Def-Label w-52" text="Maximum Size(Megabytes)"> <span className="text-red-500 text-xl">*</span></NVLlabel>
              <NVLTextbox id="txtMaximum" title={"Maximum Size"} className="nvl-mandatory w-64 md:w-96" errors={errors} register={register}></NVLTextbox>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <NVLlabel className="nvl-Def-Label w-52" text="Maximum Number of Attachments"> <span className="text-red-500 text-xl">*</span></NVLlabel>
              <NVLTextbox id="txtNoofAttachment" title={"Number of Attachments"} className="nvl-mandatory w-64 md:w-96" errors={errors} register={register}></NVLTextbox>
            </div>

            <div className="flex flex-col sm:flex-row  gap-4 ">
              <NVLlabel className="nvl-Def-Label w-52" text="Availability" />
              <div>
                <DateComponent clearErrors={clearErrors} errors={errors} register={register} setValue={setValue} watch={watch} reset={reset} />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel text="Grade" className="nvl-Def-Label w-52"></NVLlabel>
              <div>
                <Grade Attempt={Attempt} register={register} errors={errors} watch={watch} setValue={setValue} ActivityType={props.ActivityType} />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4 ">
              <NVLlabel className="nvl-Def-Label w-52" text="Download"></NVLlabel>
              <div className="grid">
                <div className="flex gap-9">
                  <NVLRadio text="Yes" value={"true"} id="rbFileDownload" name="rbFileDownload" errors={errors} register={register} />
                  <NVLRadio text="No" value={"false"} id="rbFileDownload" name="rbFileDownload" errors={errors} register={register} />
                </div>
                <div className={"{invalid-feedback} text-red-500 text-sm "}> {errors?.rbFileDownload?.message}
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel id="lblActivityCompletion" text="Activity Completion" className="nvl-Def-Label w-52" />
              <div>
                <ActivityCompletion watch={watch} setValue={setValue} register={register} errors={errors} />
                <CheckboxesInput register={register} errors={errors} watch={watch} CustomMessage={CustomMessage} IsViewTheActivity={true} IsSubmitTheActivity={true} IsMarkTheActivity={true} IsCompleteTheActivity={true} setValue={setValue} >
                </CheckboxesInput>
                <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"}>
                  <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation">
                    {" "}
                    {watch("activitycompletionError")}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52" />
              <div>
                <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} props={props} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
              </div>
            </div>
          </div>
        </div>
      </form>
    </section>
  );
}
export default AssignmentActivity;
