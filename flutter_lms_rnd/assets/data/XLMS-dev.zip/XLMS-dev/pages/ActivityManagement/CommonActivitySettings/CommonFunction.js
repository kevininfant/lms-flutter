import { Regex } from "RegularExpression/Regex";

export default function CommonFunction() { };

export const hasDuplicate = (arrayObj, colName) => {
    var hash = Object.create(null);
    return arrayObj.some((arr) => {
        return arr[colName] && (hash[arr[colName]] || !(hash[arr[colName]] = true));
    });
};

export function DynamicPageLanguageValidation(pageRef, getDDLLangID) {
    let errorResponse = "";
    let length = Object.keys(pageRef.current).length;
    let checkLang = [];
    let isErrorSatus = true;
    for (let index = 0; index < length; index++) {

        let language = document.getElementById(getDDLLangID + index)?.options[document.getElementById(getDDLLangID + index)?.selectedIndex]?.value;
        let textId;
        try {
            textId = JSON.parse(pageRef.current?.["NVLCustomEditor" + index]);
        }
        catch (e) {

            errorResponse = "TEXT";
            isErrorSatus = false;
            break;
        }
        checkLang = [...checkLang, { lang: language }]
        if ((language == "" || language == undefined) && (textId == "" || textId == undefined)) {
            errorResponse = "LANGTEXT";
            isErrorSatus = false;
            break;
        }
        else if (textId.blocks == undefined) {
            errorResponse = "TEXT";
            isErrorSatus = false;
            break;
        }
        else if (language == "" || language == undefined) {
            errorResponse = "LANG";
            isErrorSatus = false;
            break;
        }
        else {
            let check = 0;
            for (let i = 0; i < textId.blocks.length; i++) {
                if (textId.blocks[i]?.data?.text == undefined) {
                    check = 1;
                    break;
                }
                if (textId.blocks[i]?.data?.text == "") {
                    check = 1;
                    break;
                }
                else if (textId.blocks[i]?.data?.text.replaceAll("&nbsp;", "") == "") {
                    check = 1;
                    break;
                }
            }
            if (check == 1) {
                errorResponse = "TEXT";
                isErrorSatus = false;
                break;
            }
        }
    }

    if (hasDuplicate(checkLang, "lang")) {
        errorResponse = "LANGEXISTS";
    }
    else if (errorResponse == "ERROR") {
        return errorResponse;
    }
    else if (isErrorSatus) {
        errorResponse = "sucess";
    }

    return errorResponse
};

export function DynamicFileLanguageValidation(originData, id,FileValues){
  
    let errorResponse = originData;
    let checkLang = [];
    let isErrorSatus = true;
    for (let index = 0; index < parseInt(document?.getElementById("divFileLangCount")?.innerHTML); index++) {
      let language = document.getElementById(id + index)?.options[document.getElementById(id + index)?.selectedIndex]?.value;
      checkLang = [...checkLang, { lang: language }];
      if ((language == "" || language == undefined) && ((FileValues[index]?.FilePath == null || FileValues[index]?.FilePath == undefined || FileValues[index]?.FilePath == "Select File") || (FileValues[index]?.FileName == "Select File" || FileValues[index]?.FileName == null || FileValues[index]?.FileName == undefined))) {
        errorResponse = "FILELANG";
        isErrorSatus = false;
        break;
      }
      else if (language == undefined || language == "") {
        errorResponse = "LANG";
        isErrorSatus = false;
        break;
      }
      else if ((FileValues[index]?.FileName == "Select File" || FileValues[index]?.FileName == undefined || FileValues[index]?.FileName == null) && (FileValues[index]?.FilePath == "" || FileValues[index]?.FilePath == null)) {
        errorResponse = "FILE";
        isErrorSatus = false;
        break;
      }
      else if((language != "" || language != undefined)&&(FileValues[index]?.FilePath == null || FileValues[index]?.FilePath == undefined || FileValues[index]?.FilePath == "Select File") || (FileValues[index]?.FileName == "Select File" || FileValues[index]?.FileName == null || FileValues[index]?.FileName == undefined)){
        errorResponse = "FILENOTATTACHED";
        isErrorSatus = false;
        break;
      }
    
     
      
    }
    if (hasDuplicate(checkLang, "lang")) {
      errorResponse = "LANGEXISTS";
    }
    else if (errorResponse == "ERROR") {
      return errorResponse;
    }
    else if (isErrorSatus) {
      errorResponse = "sucess";
    }
 
    return ErrorMessage(errorResponse);
};

export function DynamicTextLanguageValidation(originData, getTextURLID, getDDLLangID){

    let errorResponse = originData;
    let checkLang = [];
    let isErrorSatus = true;
    for (let index = 0; index < parseInt(document?.getElementById("divURLLangCount")?.innerHTML); index++) {
      let language = document.getElementById(getDDLLangID + index)?.options[document.getElementById(getDDLLangID + index)?.selectedIndex]?.value;
      let textid = document.getElementById(getTextURLID + index)?.value;
      checkLang = [...checkLang, { lang: language }]
      if ((language == "" || language == undefined) && (textid == "" || textid == undefined)) {
        errorResponse = "LANGTEXT";
        isErrorSatus = false;
        break;
      }
      else if (textid == "" || textid == undefined) {
        errorResponse = "TEXT";
        isErrorSatus = false;
        break;
      } 
      else if (!Regex("Url").test(textid) && (language == "" || language == undefined)) {
        errorResponse = "LANGINVALIDURL";
        isErrorSatus = false;
        break;
      }
      else if (language == "" || language == undefined) {
        errorResponse = "LANG";
        isErrorSatus = false;
        break;
      }
      else if (!Regex("Url").test(textid)) {
        errorResponse = "INVALIDURL";
        isErrorSatus = false;
        break;
      }
    }

    if (hasDuplicate(checkLang, "lang")) {
      errorResponse = "LANGEXISTS";
    }
    else if (errorResponse == "ERROR") {
      return errorResponse;
    }
    else if (isErrorSatus) {
      errorResponse = "sucess";
    }

    return ErrorMessage(errorResponse)
};

const ErrorMessage=(errorName)=>{
  let message = "";
        if (errorName == "LANGEXISTS") {
          message = "Language is already exists."
        } else if (errorName == "FILE") {
          message = "File is required to be upload in correct format.";
        } else if (errorName == "FILELANG") {
          message = "Language and File is required.";
        } else if (errorName == "LANG") {
          message = "Language is required.";
        } else if (errorName == "ERROR") {
          message = "File not uploaded.";
        } else if (errorName == "TEXT") {
          message = "URL is required.";
        } else if (errorName == "LANGTEXT") {
          message = "Language and URL is required.";
        } else if (errorName == "INVALIDURL") {
          message = "Url is invalid.";
        } else if (errorName == "INVALIDFILE") {
          message = "File Format Is Invalid.";
        } else if (errorName == "INVALIDFILE") {
          message = "File size upto 1GB.";
        } else if (errorName == "LANGINVALIDURL") {
          message = "Language is required and URL  is invalid.";
        } else if (errorName == "FILENOTATTACHED") {
          message = "File is required.";
        }
        return message;
}

