import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, ReactTagsButton } from "./ActivityComponents";
export const UrlActivity = ({ FinalResponse, query, Appearance, props, CustomMessage, router }) => {
  const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
  const validationSchema = Yup.object().shape({
    txtUrl: Yup.string().required("Url is required").matches(Regex("Url"), "Url is invalid").nullable(),
    txtWidth: Yup.string().nullable().max(4, "Max length exceed 4"),
    txtHeight: Yup.string().max(4, "Max length exceed 4").nullable(),

    /* Activity Download */
    rbFileDownload: Yup.string().nullable().test("", "", () => {
      // dynamicFileRef.current=dynamicFileRef.current;
      // activityCompleteRef.current=activityCompleteRef.current;
      return true;
    }),

    /* Activity Completion */
    rbActivityCompletion: Yup.string()
      .required("Activity completion is required")
      .nullable()
      .test("error", "", (e, { createError }) => {
        if (e == "true") {
          let array = ["chkViewTheActivity", "chkMarkTheActivity"];
          let result = [];
          array.map((item) => {
            result.push(watch(item));
          });
          if (result.indexOf(true) == -1) {
            setValue("activitycompletionError", "At least one is required.")
            return createError({ message: "At least one is required." });
          } else {
            setValue("activitycompletionError", undefined)
            return true;
          }
        } else {
          // activityCompleteRef.current=((e=="true")?"true":"false");
          setValue("chkViewTheActivity", null)
          setValue("chkMarkTheActivity", null)
          setValue("activitycompletionError", undefined)
        }
        return true;
      })
      .nullable(),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), nativeValidation: false };
  const { register, handleSubmit, setValue, watch, formState, reset } = useForm(formOptions);
  const { errors } = formState;
  const [Data, setData] = useState([]);
  const KeyCodes = {
    comma: 188,
    enter: 13,
    tab: 9,
  };

  const delimiters = useMemo(() => {
    return [KeyCodes.comma, KeyCodes.enter, KeyCodes.tab];
  }, [KeyCodes.comma, KeyCodes.enter, KeyCodes.tab]);

  const handleAddition = useCallback(
    (tag) => {
      setTags([...tags, tag]);
      setValue("ReactTags", "Add", { shouldValidate: true });
    },
    [setTags, setValue, tags]
  );
  const handleDelete = useCallback(
    (i) => {
      setTags(tags.filter((tag, index) => index !== i));
      setValue("ReactTags", "Delete", { shouldValidate: true });
    },
    [setValue, tags]
  );

  const handleDrag = useCallback(
    (tag, currPos, newPos) => {
      const newTags = tags.slice();
      newTags.splice(currPos, 1);
      newTags.splice(newPos, 0, tag);
      setTags(newTags);
    },
    [tags, setTags]
  );


  /*End Batch Update*/
  useEffect(() => {
    setValue("txtUrl", props.EditData?.AttachFile);
    setValue("ddlAppearance", ((props.EditData?.Appearance == null || props.EditData?.Appearance == undefined) ? "" : props.EditData?.Appearance?.toString()));
    setValue("txtHeight", props.EditData?.PopUpHeight != null ? props.EditData?.PopUpHeight : 1920);
    setValue("txtWidth", props.EditData?.PopUpWidth != null ? props.EditData?.PopUpWidth : 360);
    setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion?.toString() == null || props.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : props.EditData?.IsActivityCompletion?.toString());
    setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
    setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
  }, [props.EditData?.Appearance, props.EditData?.AttachFile, props.EditData?.IsActivityCompletion, props.EditData?.IsMarkTheActivity, props.EditData?.IsViewTheActivity, props.EditData?.PopUpHeight, props.EditData?.PopUpWidth, setValue])
  const submitHandler = async (data) => {
    setValue("submit", true)
    let PK, SK;
    if (props.mode == "ModuleDirect") {
      PK = "TENANT#" + props.TenantInfo.TenantID;
      SK = props.EditData.SK
    } else if (props.mode == "Edit") {
      PK = "TENANT#" + props.TenantInfo.TenantID;
      SK = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
    }
    let UrlVariables = {
      input: {
        ...props.EditData,
        PK: PK,
        SK: SK,
        AttachFile: data.txtUrl,
        Appearance: data.ddlAppearance,
        IsActivityCompletion: watch("rbActivityCompletion") == "false" ? false : data.rbActivityCompletion,
        IsViewTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkViewTheActivity,
        IsMarkTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkMarkTheActivity,
        Keywords: JSON.stringify(tags),
        ModifiedBy: props.user.username,
        ModifiedDate: new Date(),
      },
    };
    /*Batch Update*/
    let Query = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
    for (let i = 1; i <= props.EditData.Shard; i++) {
      UpdateBatch({
        inn: UrlVariables.input,
        props: props,
        pk: "TENANT#" + props.EditData.TenantID + "#" + i,
        query: Query,
        UpdateData: props.EditData,
      });
    }
    UrlVariables = {
      input: {
        PK: PK,
        SK: SK,
        AttachFile: data.txtUrl,
        Appearance: data.ddlAppearance,
        IsActivityCompletion: watch("rbActivityCompletion") == "false" ? false : data.rbActivityCompletion,
        IsViewTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkViewTheActivity,
        IsMarkTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkMarkTheActivity,
        Keywords: JSON.stringify(tags),
        ModifiedBy: props.user.username,
        ModifiedDate: new Date(),
      },
    };
    /*Batch Update*/
    let FinalStatus = (await AppsyncDBconnection(query, UrlVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
    FinalResponse(FinalStatus);
    setValue("submit", false)
  };
  return (
    <section>
      <form>
        <div id="divURL" className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}>
          <div className="container px-0 sm:px-12 mx-auto grid gap-8 ">
            <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name: ${props.EditData.ActivityName}`}></NVLlabel>
            <NVLlabel className="nvl-Def-Label " text={`Activity Type: URL`}></NVLlabel>
            <div className="flex flex-col sm:flex-row gap-4">
              <NVLlabel text="Paste URL" className="nvl-Def-Label w-52"><span className="text-red-500 text-lg">*</span></NVLlabel>
              <NVLTextbox id="txtUrl" className="nvl-mandatory nvl-Def-Input" type="url" title="URL" required maxLength={"3"} errors={errors} register={register}></NVLTextbox>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <NVLlabel text="Appearance" className="nvl-Def-Label w-52"></NVLlabel>
              <div className="">
                <NVLSelectField id="ddlAppearance" options={Appearance} className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register}></NVLSelectField>
                <div className="flex gap-4">
                  {/* <div>
                                        <NVLlabel text="Pop-up width(in pixels)" className="nvl-Def-Label w-52"></NVLlabel>
                                        <NVLTextbox title="Pixels" id="txtWidth" className="w-36 nvl-non-mandatory"  type="number" pattern="[0-9]" maxLength={"3"} errors={errors} register={register}></NVLTextbox>
                                    </div>
                                    <div>
                                        <NVLlabel text="Pop-up height(in pixels)" className="nvl-Def-Label w-52"></NVLlabel>
                                        <NVLTextbox title="Pixels" id="txtHeight" className="w-36 nvl-non-mandatory"  type="number" pattern="[0-9]" maxLength={"3"} errors={errors} register={register}></NVLTextbox>
                                    </div> */}
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <NVLlabel text="Activity Completion" className="nvl-Def-Label w-52"></NVLlabel>
              <div>
                <ActivityCompletion register={register} errors={errors} />
                <CheckboxesInput register={register} errors={errors} watch={watch} IsViewTheActivity={true} IsMarkTheActivity={true} CustomMessage={CustomMessage} setValue={setValue} />
                <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"} >
                  <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation"> {watch("activitycompletionError")}</div>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52" />
              <div>
                <ReactTagsButton register={register} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} tags={tags} delimiters={delimiters} errors={errors} props={props} watch={watch}
                  handleAddition={handleAddition} handleDelete={handleDelete} handleDrag={handleDrag} />
              </div>
            </div>
          </div>
        </div>
      </form>
    </section>
  )
}
export default UrlActivity;