import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsBatchTrainingManagement, createXlmsQuizConsumeStatus, createXlmsQuizCourseConsumeStatus, createXlmsTrainingQuizTemplate, updateXlmsCourseQuizTemplate, updateXlmsQuizTemplate, updateXlmsTrainingQuizTemplate } from "src/graphql/mutations";
import { listXlmsCourseQuizTemplate, listXlmsLanguages, listXlmsQuizTemplate, listXlmsTrainingQuizTemplateInfos } from "src/graphql/queries";
import * as Yup from "yup";
import UploadQuestion from "./UploadQuestion";

function QuestionList(props) {
  const router = useRouter();
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [popupValues, setPopupValues] = useState({});
  const [open, setOpen] = useState(false);
  const [popUpName, setPopupName] = useState("");

  const Search = useRef("");
  const variable = useRef();
  const dropdownState = useRef("en")

  const multipleUserdata = useRef({ id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0 });
  const [rowData, setRowData] = useState(0);
  const [languageData, setLanguageData] = useState()

  const [modalValues, setModalValues] = useState({
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Questions have been saved successfully.",
    ModalOnClickEvent: () => {
      if (mode == "ModuleDirect") {
        router.push(`/CourseManagement/ModulesList?CourseID=${props.CourseID}`)
      } else {
        router.push(`/ActivityManagement/ActivityList`)
      }
    },
  });
  const mode = useMemo(() => {
    let mode;
    if (props.mode == "ModuleDirect") {
      mode = props.mode
    } else {
      mode = router.query["Mode"];
    }
    return mode;
  }, [props.mode, router.query])

  const activityType = useMemo(() => {
    return (mode == "ModuleDirect" || props?.mode == "TrainingDirect" ? props?.ActivityType : router.query["ActivityType"])
  }, [mode, props.ActivityType, props?.mode, router.query])

  const activityId = useMemo(() => {
    return mode == "ModuleDirect" || props?.mode == "TrainingDirect" ? props.ActivityID : router.query["ActivityID"]
  }, [mode, props.ActivityID, props?.mode, router.query])

  const userSub = useMemo(() => {
    return mode == "ModuleDirect" ? props.UserSub : props.user.attributes["sub"];
  }, [mode, props.UserSub, props.user.attributes])

 
  useEffect(() => {
    async function quizDataFetch() {
      let recordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME", }, props.user.signInUserSession.accessToken.jwtToken);
      setLanguageData((data) => {
        if (data == undefined) {
          multipleUserdata.current = { id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0, };
        }
        return recordContentDataLanguage.res?.listXlmsLanguages;
      })
    }
    quizDataFetch()
    return (() => {
      setLanguageData((temp) => { return { ...temp } });
    })
  }, [activityId, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken]);
  
  const query = useMemo(()=>{
    let query = mode == "ModuleDirect" ? listXlmsCourseQuizTemplate
      : props?.mode == "TrainingDirect" ? listXlmsTrainingQuizTemplateInfos : listXlmsQuizTemplate;
      return query;
  },[mode, props?.mode])

  const queryName = useMemo(()=>{
    let queryName = mode == "ModuleDirect" ? "listXlmsCourseQuizTemplate"
        : props?.mode == "TrainingDirect" ? "listXlmsTrainingQuizTemplateInfos" : "listXlmsQuizTemplate";
        return queryName
  },[mode, props?.mode])
 

  useEffect(() => {
    let SK = mode == "ModuleDirect" ? "COURSE#" + props?.CourseID + "#MODULE#" + props?.ModuleID + "#ACTIVITYID#" + activityId + "#LANGUAGE#" + dropdownState.current : props?.mode == "TrainingDirect" ? "TRAINING#" + props?.TrainingId + "#ACTIVITYID#" + props?.ActivityID + "#LANGUAGE#" + dropdownState.current : "ACTIVITYID#" + activityId + "#LANGUAGE#" + dropdownState.current;
    variable.current = props?.mode == "TrainingDirect" ? { PK: "TENANT#" + props.TenantInfo.TenantID, SK: SK, IsDeleted: false } : { PK: "TENANT#" + props.TenantInfo.TenantID, SK: SK, IsDelete: false, };
    questionDataFetch()
  }, [activityId, mode, props, props?.ActivityID, props?.CourseID, props?.ModuleID, props.TenantInfo.TenantID, props?.TrainingId, props?.mode, questionDataFetch])
 
  const questionDataFetch = useCallback(async()=>{
    let questions = await AppsyncDBconnection(query, variable.current, props.user.signInUserSession.accessToken.jwtToken);
    let questionData = mode == "ModuleDirect" ? questions.res?.listXlmsCourseQuizTemplate.items :
    props.mode == "TrainingDirect" ? questions.res?.listXlmsTrainingQuizTemplateInfos?.items : questions.res?.listXlmsQuizTemplate?.items
    setRowData(() => { return questionData ? questionData.length : 0});
  },[mode, props.mode, props.user.signInUserSession.accessToken.jwtToken, query])

  const validationSchema = Yup.object().shape({
    ddlSearch: Yup.string().test("Dropdown_handler", "", (e) => {
      if (e != dropdownState.current) {
        multipleUserdata.current = { id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0, };
        dropdownState.current = e;
        let SK = mode == "ModuleDirect" ? "COURSE#" + props?.CourseID + "#MODULE#" + props?.ModuleID + "#ACTIVITYID#" + activityId + "#LANGUAGE#" + dropdownState.current : props?.mode == "TrainingDirect" ? "TRAINING#" + props?.TrainingId + "#ACTIVITYID#" + props?.ActivityID + "#LANGUAGE#" + dropdownState.current : "ACTIVITYID#" + activityId + "#LANGUAGE#" + dropdownState.current;
        variable.current = props?.mode == "TrainingDirect" ? { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: SK, IsDeleted: false, } : { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: SK, IsDelete: false, };
        setValue("chkAll", false);
        refreshGrid();
      }
      return true;
    }),
    chkAll: Yup.bool()
      .nullable()
      .test("check", "defaulterror", (e) => {
        let temp = watch(multipleUserdata.current.id)
        if (e && multipleUserdata.current.currentstate && (temp.indexOf(false) != -1)) {
          setValue("chkAll", false)
          multipleUserdata.current.currentstate = false;
        } else if (e) {
          multipleUserdata.current.id.map((getItem) => {
            if (!watch(getItem))
              // setValue("chkAll",true)
              setValue(getItem, true)
          })
          multipleUserdata.current.currentstate = true;
        }
        else if (!e && multipleUserdata.current.currentstate) {
          multipleUserdata.current.id.map((getItem) => {
            if (watch(getItem))
              setValue(getItem, false);
          })
          multipleUserdata.current.currentstate = false;
        }
        else if (!e && !multipleUserdata.current.currentstate) {
          let check = 0;
          multipleUserdata.current.id.map((getItem) => {
            if (!watch(getItem)) {
              check++;
            }
          });
          if (check == 0) {
            setValue("chkAll", true);
            multipleUserdata.current.currentstate = true;
          }
        }
        temp = watch(multipleUserdata.current.id)
        if (!e && (temp.indexOf(false) == -1)) {
          setValue("chkAll", true)
        }
        return true;
      }),
  });
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };

  const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
  const { errors } = formState;

  const language = useMemo(() => {
    let languageType = [];
    if (languageData != undefined) {
      if (languageData && Object?.keys(JSON?.parse(languageData?.items[0]?.LanguageName)) != undefined) {
        Object?.entries(JSON.parse(languageData?.items[0]?.LanguageName)).forEach(([key, value]) => {
          languageType = [...languageType, { value: value, text: key }];
        });
      }
    }
    return languageType;
  }, [languageData]);

  const headerColumn = useMemo(
    () => [
      {
        HeaderName: (
          <NVLCheckbox
            id="chkAll"
            errors={errors}
            register={register}
            text="SelectAll"
          />
        ),
        Columnvalue: "SelectAll",
        HeaderCss: "!w-3/12",
      },
      { HeaderName: "Question", Columnvalue: "Question", HeaderCss: "!w-3/12" },
      {
        HeaderName: "Question Type",
        Columnvalue: "QuestionType",
        HeaderCss: "!w-2/12",
      },
      { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-1/12" },
    ],
    [errors, register]
  );
  
  
  const refreshGrid = useCallback(async () => {
    Search.current = "";
    setValue("chkAll", false)
    multipleUserdata.current = { id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0, };
    setIsRefreshing((count) => {
      return count + 1;
    });
    questionDataFetch()
  }, [questionDataFetch, setValue]);
  const finalResponse = useCallback((FinalStatus, type, NavigateMode) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
      });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: type == "popup" ? "File Upload is under progress. Incase invalid data found in the uploaded file. The error details will be available in the notification." : "Questions have been saved successfully.",
        ModalOnClickEvent: () => {
          if (type == "popup") {
            if (NavigateMode == "ModuleDirect") {
              if (router.query["ZoomActivityID"] != undefined) {
                router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props?.CourseID}&ModuleID=${props?.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
              } else {
                router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props?.CourseID}&ModuleID=${props?.ModuleID}`)
              }
            } else if (props?.TrainingId) {
              router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=Pre-Assessment&TrainingName=${props?.TrainingName}&Settings=QuizList`)
            } else {
              if (router.query["ZoomActivityID"] != undefined) {
                router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`);
              } else {
                router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`);
              }
            }
          } else if (props?.mode == "TrainingDirect") {
            router.push(`/TrainingManagement/TrainingManagementList`)
          } else {
            if (mode == "ModuleDirect") {
              if (router.query["ZoomActivityID"] != undefined) {
                router.push(`/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}`)
              } else {
                router.push(`/CourseManagement/ModulesList?CourseID=${props.CourseID}`)
              }
            } else {
              if (router.query["ZoomActivityID"] != undefined) {
                if (!router.query["NavigationMode"]) {
                  return router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`)
                } else {
                  return router.push(`/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`)
                }
              } else {
                return router.push(`/ActivityManagement/ActivityList`)
              }
            }
          }
        }
      });
      ModalOpen();
    }
  }, [props?.mode, props?.TrainingId, props.CourseID, props.ModuleID, props?.ActivityID, props?.TrainingName, router, activityId, activityType, mode])

  function resetPopUp() {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    refreshGrid();
  }

  function popup(type, PK, SK, Content) {
    setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
  }

  async function updateField(e) {
    e.preventDefault();
    let query = mode == "ModuleDirect" ? updateXlmsCourseQuizTemplate : props?.mode == "TrainingDirect" ? updateXlmsTrainingQuizTemplate : updateXlmsQuizTemplate
    let deletedStatus = await AppsyncDBconnection(
      query,
      {
        input: props?.mode == "TrainingDirect" ? {
          PK: popupValues.PK,
          SK: popupValues.SK,
          IsDeleted: true,
        } : {
          PK: popupValues.PK,
          SK: popupValues.SK,
          IsDelete: true,
        },
      },
      props?.user?.signInUserSession?.accessToken?.jwtToken
    );
    if (deletedStatus.Status == "Success") {
      refreshGrid();
    }
    resetPopUp();
  }

  const removeQuestions = useCallback(async () => {
    let deletedStatus;
    let questionData = [];
    let finalData = [];

    multipleUserdata.current.values.map((item, index) => {
      if (watch(item.id)) {
        questionData?.push(item);
      }
    });

    questionData?.forEach((itm, idx) => {
      if (idx + 1 == multipleUserdata.current.values.length) {
        refreshGrid();
        reset();
      }
      if (props?.mode == "TrainingDirect") {
        finalData.push({ ...itm?.value, IsDeleted: true });
      } else {
        finalData.push({ ...itm?.value, IsDelete: true });
      }
      
    });


    let variable = { input: [...finalData] };
    let query = mode == "ModuleDirect" ? createXlmsQuizCourseConsumeStatus : props?.mode == "TrainingDirect" ? createXlmsTrainingQuizTemplate : createXlmsQuizConsumeStatus;
    if (questionData.length != 0) {
      deletedStatus = (await AppsyncDBconnection(query, variable, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;

      if (deletedStatus == "Success") {
        multipleUserdata.current.id.map((getItem) => { if (watch(getItem)) setValue(getItem, false); });
        multipleUserdata.current = {
          id: [], values: [], currentstate: false, page: 0, CurrentId: [], Called: 0,
        };
        refreshGrid();
      }

    }
  }, [mode, props?.mode, props?.user?.signInUserSession?.accessToken?.jwtToken, refreshGrid, reset, setValue, watch]);

  const resetData = useCallback(() => {
    if (dropdownState.current != "en") {
      setValue("ddlSearch", "en", { shouldValidate: true });
    }
    else {
      refreshGrid();
    }
  },[refreshGrid, setValue])

  const headerHandler = useCallback((e, url) => {
    e.preventDefault();
    router.push(url);
  },[router])

  useEffect(() => {
    setValue("ddlSearch", "en");
  }, [setValue, watch]);

  const pageChangeCall = useCallback((page) => {
    multipleUserdata.current = {
      ...multipleUserdata.current,
      page: page,
    };
  }, []);

  const gridDataBind = useCallback(
    (viewData) => {
      const rowGrid = [];
      let isCheckAll = true;
      let temp = { ...multipleUserdata.current };
      let isCount = multipleUserdata.current.Called;
     
      viewData &&
      viewData.map((getItem, index) => {
          let QuestionType =
            getItem.QuestionType == "MultipleChoice"
              ? "Multiple choice"
              : getItem.QuestionType == "FillInTheBlank"
                ? "Fill in the blank"
                : getItem.QuestionType == "Match"
                  ? "Match the following"
                  : getItem.QuestionType;
          let regex = /(<([^>]+)>)/gi,
            body = getItem.Question,
            result = body?.replace(regex, "");
          let actionList = [];
          actionList.push(
            {
              id: 1,
              Color: "text-yellow-600",
              Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
              name: "Preview",
              action: () => {
                if (mode == "ModuleDirect") {
                  if (router.query["ZoomActivityID"] != undefined) {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=ModuleEdit&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&Preview=Preview&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
                  } else {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=ModuleEdit&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&Preview=Preview`)
                  }
                } else if (props?.mode == "TrainingDirect") {
                  router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&Preview=Preview&Settings=AddQuestion&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}`)
                } else {
                  if (router.query["ZoomActivityID"] != undefined) {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&Preview=Preview&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
                  } else {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&Preview=Preview`)
                  }
                }
              }
            },
            {
              id: 2,
              Color: "text-green-700",
              Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
              name: "Edit",
              action: () => {
                if (mode == "ModuleDirect") {
                  if (router.query["ZoomActivityID"] != undefined) {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=ModuleEdit&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
                  } else {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=ModuleEdit&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}`)
                  }
                } else if (props?.mode == "TrainingDirect") {
                  router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&Settings=AddQuestion&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&Edit=Edit`)
                } else {
                  if (router.query["ZoomActivityID"] != undefined) {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
                  } else {
                    router.push(`/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&QuestionID=${getItem.QuestionID}&Language=${getItem.Language}&`)
                  }
                }
              }
            },
            {
              id: 3,
              Color: "text-rose-700",
              Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
              name: "Delete",
              action: () =>
                popup(
                  "isDelete",
                  getItem.PK,
                  getItem.SK,
                  "Are you sure want to Delete Question ?"
                ),
            }
          );

          rowGrid.push({

            SelectAll: (
              <NVLCheckbox
                id={"chk" + isCount}
                errors={errors}
                register={register}
              />
            ),
            Question: (
              <>
                <div className="flex">
                  <NVLlabel
                    id={"txtQuestion" + (index + 1)}
                    className="pt-2"
                    // title={result}
                    text={
                      !getItem.IsRandomQuestion
                        ? result
                        : `Random Question (From Question bank ${getItem.QuestionBank})`
                    }
                  ></NVLlabel>
                  <div className={!getItem.IsRandomQuestion ? "hidden" : ""}>
                    <NVLLink
                      id="qsnlink"
                      text="(see all questions)"
                      onClick={() => {
                        if (mode == "ModuleDirect") {
                          if (router.query["ZoomActivityID"] != undefined) {
                            router.push(`/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&QuestionBankID=${getItem.QuestionBankID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
                          } else {
                            router.push(`/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&QuestionBankID=${getItem.QuestionBankID}`)
                          }
                        } else if (props?.mode == "TrainingDirect") {
                          router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${router.query["TrainingID"]}&Settings=QuestionBank&QuestionBankID=${getItem.QuestionBankID}`)
                        } else {
                          if (router.query["ZoomActivityID"] != undefined) {
                            router.push(`/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&QuestionBankID=${getItem.QuestionBankID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
                          } else {
                            router.push(`/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&QuestionBankID=${getItem.QuestionBankID}`)
                          }
                        }
                      }
                      }
                    />
                  </div>
                </div>
              </>
            ),
            QuestionType: (
              <NVLlabel
                id={"txtType" + (index + 1)}
                text={QuestionType}
              ></NVLlabel>
            ),
            Action: (
              <NVLRapidModal
                id={"RapidModal" + (index + 1)}
                ActionList={actionList}
              ></NVLRapidModal>
            ),
          });
          let id = "chk" + isCount;
          let val = getItem;
          if (getItem.IsConsume) {
            setValue(id, true);
          }
          else {
            setValue(id, false);
            isCheckAll = false;
          }
          temp = {
            ...temp,
            id: [...temp.id, id],
            values: [
              ...temp.values,
              {
                value: val,
                id: id,
                currentstate: watch(id),
              },
            ],
          };
          isCount++;
        });
      multipleUserdata.current = { ...temp, Called: isCount };
      let tempValue = watch(multipleUserdata.current.id)
      if (isCheckAll && (tempValue.indexOf(false) == -1)) {
        setValue("chkAll", true)
        multipleUserdata.current = { ...multipleUserdata.current, currentstate: true }
      }
      else {
        setValue("chkAll", false)
        multipleUserdata.current = { ...multipleUserdata.current, currentstate: false }
      }
      return rowGrid;
    },
    [watch, errors, register, mode, props?.mode, props.CourseID, props.ModuleID, props?.ActivityID, props?.ActivityType, props?.TrainingId, props?.AssessmentType, router, activityId, activityType, setValue]
  );
  const submitHandler = useCallback(async () => {
    document?.activeElement?.blur();
    setValue("submit", true);
    let QuestionBankData = [];
    let finalQuestionBankData = [];
    let questionAndQptions;
    let Question = [];
    const RemoveNull = (obj) => {
      let tempjson = {};
      obj && Object.keys(obj).forEach((k) => {
        if (obj?.[k] != undefined) {
          tempjson = { ...tempjson, [k]: obj?.[k] }
        }
      });
      return tempjson;
    }
   
    multipleUserdata.current.values.map(async (item, index) => {
      let existData = RemoveNull(item?.value)
      if (watch(item.id)) {
        finalQuestionBankData.push({ ...existData, IsConsume: true });
        Question.push({ Qusetion: existData?.Question, Option: existData?.Options, QuestionType: existData?.QuestionType, Language: existData?.Language })
      }
      else {
        finalQuestionBankData.push({ ...existData, IsConsume: false });
      }

    });
    questionAndQptions = { ...props?.TrainingData?.QuestionandOptions && JSON.parse(props?.TrainingData?.QuestionandOptions), [props?.AssessmentType]: { TemplateID: props?.ActivityID, ActivityID: props?.ActivityID, ActivityType: props?.ActivityType, TrainingID: props?.TrainingId, TrainingName: props?.TrainingData?.TrainingName, TemplateName: props?.TrainingData?.TrainingName + "-" + props?.AssessmentType, AssessmentType: props?.AssessmentType, Template: JSON.stringify(Question), IsSuspend: false } }

    let finalStatus;
    if (finalQuestionBankData.length != 0) {
      let query =
      mode == "ModuleDirect"
      ? createXlmsQuizCourseConsumeStatus
      : props?.mode == "TrainingDirect" ? createXlmsTrainingQuizTemplate : createXlmsQuizConsumeStatus;
      while (finalQuestionBankData.length > 25) {
        let tempArray = finalQuestionBankData.splice(0, 25);
        AppsyncDBconnection(query, { input: tempArray }, props.user.signInUserSession.accessToken.jwtToken);
      } 
      finalStatus = ( await AppsyncDBconnection(query, {input : finalQuestionBankData }, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
      const updateVariables = {
        input: [
          {
            ...props?.TrainingData,
            QuestionandOptions: JSON.stringify(questionAndQptions),
          },
          {
            ...props?.TrainingData,
            SK: "TRAININGINFO#LASTMODIFIEDDATE#" + props?.TrainingData?.LastModifiedDate + "#TRAININGID#" + props?.TrainingId,
            QuestionandOptions: JSON.stringify(questionAndQptions),
          }]
      }
      await AppsyncDBconnection(createXlmsBatchTrainingManagement, updateVariables, props?.user?.signInUserSession?.accessToken?.jwtToken);
    }
    finalResponse(finalStatus);
    refreshGrid();
    setValue("submit", false);
  },[finalResponse, mode, props?.ActivityID, props?.ActivityType, props?.AssessmentType, props?.TrainingData, props?.TrainingId, props?.mode, props.user.signInUserSession.accessToken.jwtToken, refreshGrid, setValue, watch])

  const GetComponent = useCallback(
    (PopupName) => {
      let ComponentData = {
        Upload: (
          <UploadQuestion
            user={props?.user}
            setOpen={setOpen}
            open={open}
            TenantInfo={props.TenantInfo}
            ActivityID={activityId}
            ActivityType={activityType}
            NavigateMode={mode}
            CourseID={props.CourseID}
            ModuleID={props.ModuleID}
            TrainingID={props?.TrainingId}
            TrainingName={props?.TrainingName}
            Language={languageData}
            UserSub={userSub}
            modalValues={modalValues}
            FinalResponse={finalResponse}
            Mode="Popup"
          />
        ),
      };
      return ComponentData[PopupName];
    },
    [props?.user, props.TenantInfo, props.CourseID, props.ModuleID, props?.TrainingId, props?.TrainingName, open, activityId, activityType, mode, languageData, userSub, modalValues, finalResponse]
  );


  useEffect(() => {
    if (multipleUserdata != undefined) {
      multipleUserdata?.current?.values?.map(async (item, index) => {
        if (watch("chkAll")) {
          setValue(item.id, true)
          setValue("chkAll", true)
        }
        else
          setValue(item.id, false)
      });
      return null;
    }
  }, [setValue, watch])
  
  const pageRoutes = useMemo(()=>{
    let pageRoutes = [];
    if (mode != "Edit") {
      if (router.query["ZoomActivityID"] != undefined) {
        pageRoutes = [
          { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
          { path: `/CourseManagement/ModulesList?CourseID=${props.CourseID}`, breadcrumb: "Manage Course" },
          { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props.EditData?.ModuleName}`, breadcrumb: "Edit Activity Zoom" },
          { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}`, breadcrumb: "Edit Settings Zoom" },
          { path: `/CourseManagement/ModuleInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props.EditData?.ModuleName}&ZoomActivityName=${router.query["ZoomactivityName"]}`, breadcrumb: "Edit Activity" },
          { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
          { path: "", breadcrumb: "Question" }
        ];
      }
      else if (props?.mode == "TrainingDirect") {
        if (router.query["Root"] == "TemplateList") {
          pageRoutes = [
            { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management" },
            { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${props?.TrainingId}&TrainingName=${props.TrainingName}`, breadcrumb: "Training Template List" },
            { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${props?.TrainingId}&ActivityType=Quiz&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Root=TemplateList`, breadcrumb: "Edit Activity" },
            { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Root=TemplateList`, breadcrumb: "Edit Settings" },
            { path: "", breadcrumb: "Question" }
          ];
        } else {
          pageRoutes = [
            { path: `/TrainingManagement/TrainingManagementList`, breadcrumb: "Training Management" },
            { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${props?.TrainingId}&ActivityType=Quiz&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}`, breadcrumb: "Edit Activity" },
            { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&`, breadcrumb: "Edit Settings" },
            { path: "", breadcrumb: "Question" }
          ];
        }
      }
      else {
        pageRoutes = [
          { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
          { path: `/CourseManagement/ModulesList?CourseID=${props.CourseID}`, breadcrumb: "Manage Course" },
          { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ModuleName=${props?.Editdata?.ModuleName}`, breadcrumb: "Edit Activity" },
          { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}`, breadcrumb: "Edit Settings" },
          { path: "", breadcrumb: "Question" }
        ];
      }
  
    }
    else {
      if (router.query["ZoomActivityID"] != undefined) {
        if (!router.query["NavigationMode"]) {
          pageRoutes = [
            { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
            { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Settings Zoom" },
            { path: `/ActivityManagement/ActivityInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${activityType}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
            { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
            { path: "", breadcrumb: "Question" }
          ];
        } else {
          pageRoutes = [
            { path: `/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`, breadcrumb: "Activity Management" },
            { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Activity" },
            { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}&NavigationMode=${router.query["NavigationMode"]}`, breadcrumb: "Edit Settings" },
            { path: "", breadcrumb: "Question" }
          ];
        }
      } else {
        pageRoutes = [
          { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
          { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`, breadcrumb: "Edit Activity", breadcrumb: "Edit Activity" },
          { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`, breadcrumb: "Edit Settings" },
          { path: "", breadcrumb: "Question" }
        ];
      }
    }
    return pageRoutes
  },[activityId, activityType, mode, props?.ActivityID, props?.AssessmentType, props.CourseID, props.EditData?.ModuleName, props?.Editdata?.ModuleName, props.ModuleID, props?.TrainingId, props.TrainingName, props?.mode, router.query])
  return (
    <>
      <NVLPageModalPopup
        ModalType="Page"
        ScreenName={`Upload Question`}
        PageComponent={GetComponent(popUpName)}
        open={open}
        setOpen={setOpen}
        user={props?.user}
      />
      <Container title="Activity Management" loader={languageData == undefined || props.TenantInfo.TenantID == undefined} PageRoutes={pageRoutes}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <NVLHeader IsNestedHeader ButtonID1="is" IsDropdown={true} DropdownRequired DropdownData={language} errors={errors} register={register} LinkName4="+ Add New Question" ButtonID3="upload" LinkName3="Upload Question" LinkName2="From Question Bank" LinkName1="Random Questions"
          RedirectAction4={(e) => {
            if (mode == "Edit") {
              if (router.query["ZoomActivityID"] != undefined) {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=Create&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
              } else {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=Create&ActivityID=${activityId}&ActivityType=${activityType}`)
              }
            } else {
              if (router.query["ZoomActivityID"] != undefined) {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
              }
              else if (props?.mode == "TrainingDirect") {
                if (router.query["Root"] == "TemplateList") {
                  headerHandler(e, `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&Settings=AddQuestion&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Root=TemplateList`)
                }
                else {
                  headerHandler(e, `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&Settings=AddQuestion&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}`)
                }
              }
              else {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/AddQuestion?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}`)
              }
            }
          }
          }
          RedirectAction3={() => {
            setPopupName("Upload");
            setOpen((open) => {
              return open + 1;
            });
          }}
          RedirectAction2={(e) => {
            if (mode == "Edit") {
              if (router.query["ZoomActivityID"] != undefined) {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
              } else {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`)
              }
            } else if (props?.mode == "TrainingDirect") {
              if (router.query["Root"] == "TemplateList") {
                headerHandler(e, `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&AssessmentType=${props?.AssessmentType}&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingName=${props?.TrainingName}&TrainingID=${props?.TrainingId}&Settings=QuestionBank&Root=TemplateList`)
              } else {
                headerHandler(e, `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&AssessmentType=${props?.AssessmentType}&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingName=${props?.TrainingName}&TrainingID=${props?.TrainingId}&Settings=QuestionBank`)
              }
            } else {
              if (router.query["ZoomActivityID"] != undefined) {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
              } else {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/QuestionBank?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}`)
              }
            }
          }
          }
          RedirectAction1={(e) => {
            if (mode == "Edit") {
              if (router.query["ZoomActivityID"] != undefined) {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/RandomQuestions?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
              } else {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/RandomQuestions?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`)
              }
            } else if (props?.mode == "TrainingDirect") {
              if (router.query["Root"] == "TemplateList") {
                headerHandler(e, `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&AssessmentType=${props?.AssessmentType}&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&Settings=RandomQuestion&TrainingName=${props?.TrainingName}&Root=TemplateList`)
              } else {
                headerHandler(e, `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&AssessmentType=${props?.AssessmentType}&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&Settings=RandomQuestion&TrainingName=${props?.TrainingName}`)
              }
            } else {
              if (router.query["ZoomActivityID"] != undefined) {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/RandomQuestions?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`)
              } else {
                headerHandler(e, `/ActivityManagement/CommonActivitySettings/RandomQuestions?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${props.CourseID}&ModuleID=${props.ModuleID}`)
              }
            }
          }
          }
        />
        <form onSubmit={handleSubmit(submitHandler)} id="Formjs">
          <NVLGridTable
            refershPage={isRefreshing}
            Search={Search.current}
            id="tblQuestionList"
            HeaderColumn={headerColumn}
            GridDataBind={gridDataBind}
            DonotLoad={true}
            query={query}
            querryName={queryName}
            variable={variable.current}
            LoadInSinglePage={true}
            pageChangeCall={pageChangeCall}
            user={props?.user}
          />
          <div
            id="buttons"
            className={`justify-between flex p-4 ${rowData == 0 ? "hidden" : ""
              }`}
          >
            <div className="flex gap-2">
              <NVLButton text="Save" ButtonType="Success" disabled={watch("submit")}  className="px-40 nvl-button-success text-white" type={"submit"} />
              <NVLButton text="Reset" className="nvl-button" type={"button"} onClick={() => resetData()} />
            </div>
            <div>
              <NVLButton
                text="Remove"
                ButtonType="danger"
                className="px-40 nvl-button bg-red-400 text-white"
                type={"button"}
                onClick={() => removeQuestions()}
              />
            </div>
          </div>
        </form>
        <NVLModalPopup
          ButtonYestext="Yes"
          SubmitClick={(e) => updateField(e)}
          CancelClick={() => resetPopUp()}
          ButtonNotext="No"
          CloseIconEvent={() => resetPopUp()}
          Content={popupValues.Content}
        ></NVLModalPopup>
      </Container>
    </>
  );
}

export default QuestionList;

