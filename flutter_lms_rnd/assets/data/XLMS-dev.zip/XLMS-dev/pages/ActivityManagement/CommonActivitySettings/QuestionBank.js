import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsCourseQuizTemplate, createXlmsQuizTemplate, createXlmsTrainingQuizTemplate } from "src/graphql/mutations";
import { listXlmsActivityManagementInfos, listXlmsCourseModule, listXlmsCourseQuizTemplate, listXlmsLanguages, listXlmsQuizTemplate, listXlmsTrainingManagementActivityInfos, listXlmsTrainingQuizTemplateInfos } from "src/graphql/queries";
import * as Yup from "yup";

function QuestionBank(props) {

  const [isRefreshing, setIsRefreshing] = useState(true);
  const [rowData, setRowData] = useState(0)
  const [search, setSearch] = useState("");
  const router = useRouter();
  const multipleQuestiondata = useRef({
    id: [],
    values: [],
    currentstate: false,
    page: 0,
    CurrentId: [],
    Called: 0,
  });


  const mode = useMemo(() => { return router.query["Mode"] }, [router.query])
  const activityId = useMemo(() => { return router.query["ActivityID"] }, [router.query])
  const activityType = useMemo(() => { return router.query["ActivityType"] }, [router.query])
  const courseId = useMemo(() => { return router.query["CourseID"] }, [router.query])
  const moduleId = useMemo(() => { return router.query["ModuleID"] }, [router.query])
  const questionBankId = useMemo(() => { return router.query["QuestionBankID"] }, [router.query])
  const [dropdownState, setDropdownState] = useState(
    {
      Language: "en",
      Questionbank: questionBankId,
      TrainingID: ""
    });

  const [modalValues, setModalValues] = useState({
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Questions have been added successfully.",
    ModalOnClickEvent: () => {
      if (mode == "ModuleDirect") {
        if (router.query["ZoomActivityID"] != undefined) {
          router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
        } else {
          router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}`);
        }
      } else if (props?.mode == "TrainingDirect") {
        if (router.query["Root"] == "TemplateList") {
          router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList&Root=TemplateList`);
        } else {
          router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList`);
        }
      } else {
        if (router.query["ZoomActivityID"] != undefined) {
          router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
        } else {
          router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`);
        }
      }
    }
  });
  const [quizData, setQuizData] = useState()

  useEffect(() => {
    async function fetchQuizData() {
      let authorizedToken = props.user.signInUserSession.accessToken.jwtToken;
      let query = (mode == "ModuleDirect") ? listXlmsCourseModule : props?.mode == "TrainingDirect" ? listXlmsTrainingManagementActivityInfos : listXlmsActivityManagementInfos
      let sk = (mode == "ModuleDirect") ? "COURSEID#" + courseId + "#MODULEID#"  : props?.mode == "TrainingDirect" ? "TRAINING#" : "ACTIVITYTYPE#Quiz"
      let recordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME", }, authorizedToken);
      let response = await AppsyncDBconnection(query, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: sk, IsDeleted: false }, authorizedToken);
      let quizActivities;
      if (mode == "ModuleDirect") {
        quizActivities = response?.res?.listXlmsCourseModule?.items != undefined ? response?.res?.listXlmsCourseModule?.items : []
      } else if (props?.mode == "TrainingDirect") {
        quizActivities = response?.res?.listXlmsTrainingManagementActivityInfos?.items != undefined ? response?.res?.listXlmsTrainingManagementActivityInfos?.items : []
      } else {
        quizActivities = response?.res?.listXlmsActivityManagementInfos?.items
      }
      response = await AppsyncDBconnection(query, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSE#" + courseId + "#QUESTIONBANKINFO#", IsDeleted: false }, authorizedToken);
      setQuizData({
        QuizActivities: quizActivities,
        Language: recordContentDataLanguage?.res?.listXlmsLanguages,
      })
    }
    fetchQuizData()
    setValue("ddlSearch", "en")
    if (questionBankId != undefined) {
      setValue("ddlQuestionBank", questionBankId)
    } else {
      setValue("ddlQuestionBank", "")
    }
    return (() => {
      setQuizData((temp) => { return { ...temp } });
    })
  }, [courseId, mode, moduleId, questionBankId, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, setValue, props?.mode])

  const language = useMemo(() => {
    let languageType = [];
    if (quizData?.Language != undefined) {
      if (Object?.keys(JSON?.parse(quizData?.Language?.items[0]?.LanguageName)) != undefined) {
        Object?.entries(JSON.parse(quizData?.Language?.items[0]?.LanguageName)).forEach(([key, value]) => {
          languageType = [...languageType, { value: value, text: key }];
        });
      }
    }
    return languageType;
  }, [quizData?.Language]);
  const questionBankList = useMemo(() => {
    let selectField = [{ value: "", text: "Select" }];
    if (quizData?.QuizActivities != undefined) {
      quizData?.QuizActivities.forEach((item) => {
        if (item?.ActivityType == "Quiz") {
          // trainingID = item?.SK.split("#")[1]
          if(item.ActivityID != activityId){
            selectField.push({ value: item.ActivityID, text: item.ActivityName })
          }
        }
      })
    }
    return selectField;
  }, [activityId, quizData?.QuizActivities])

  const refreshGrid = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };

  const validationSchema = Yup.object().shape({
    ddlSearch: Yup.string().test("Dropdown_handler", "", (e) => {
      if (e != dropdownState.Language) {
        setDropdownState({ ...dropdownState, Language: e });
        setValue("chkAll", false)
        multipleQuestiondata.current.id.map((getItem) => {
          if (watch(getItem))
            setValue(getItem, false);
        })
        multipleQuestiondata.current = {
          id: [],
          values: [],
          currentstate: false,
          page: 0,
          CurrentId: [],
          Called: 0,
        };
        setValue("chkAll", false);
        refreshGrid();
      }
      return true;
    }),
    ddlQuestionBank: Yup.string().test("Dropdown", "", (e) => {
      if(e == "") {
        setDropdownState({ ...dropdownState, Questionbank: e })
      }
      if (e != dropdownState.Questionbank) {
        quizData?.QuizActivities?.map((getItem) => {
          if (e == getItem?.ActivityID) {
            setDropdownState({ ...dropdownState, Questionbank: e, TrainingID: getItem?.SK?.split("#")[1] })
          }
        })
        setValue("chkAll", false)
        multipleQuestiondata.current.id.map((getItem) => {
          if (watch(getItem))
            setValue(getItem, false);
        })
        multipleQuestiondata.current = {
          id: [],
          values: [],
          currentstate: false,
          page: 0,
          CurrentId: [],
          Called: 0,
        };
        setValue("chkAll", false);
        refreshGrid();
      }
      return true;
    }),

    chkAll: Yup.bool().nullable().test("check", "defaulterror", e => {
      let temp = watch(multipleQuestiondata.current.id)
      if (e && multipleQuestiondata.current.currentstate && temp.indexOf(false) != -1) {
        setValue("chkAll", false)
        multipleQuestiondata.current.currentstate = false;
      } else if (e) {
        multipleQuestiondata.current.id.map((getItem) => {
          if (!watch(getItem))
            setValue(getItem, true);
        })
        multipleQuestiondata.current.currentstate = true;
      }
      else if (!e && multipleQuestiondata.current.currentstate) {
        multipleQuestiondata.current.id.map((getItem) => {
          if (watch(getItem))
            setValue(getItem, false);
        })
        multipleQuestiondata.current.currentstate = false;
      }
      else if (!e && !multipleQuestiondata.current.currentstate) {
        let check = 0;
        multipleQuestiondata.current.id.map((getItem) => {
          if (!watch(getItem)) {
            check++;
          }
        });
        if (check == 0) {
          setValue("chkAll", true);
          multipleQuestiondata.current.currentstate = false;
        }
      }
      return true;
    }),
  });
  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };

  const { register, handleSubmit, setValue, watch, reset, formState } =
    useForm(formOptions);
  const { errors } = formState;

  const headerColumn = [
    { HeaderName: (<NVLCheckbox id="chkAll" errors={errors} register={register} text="SelectAll" />), Columnvalue: "SelectAll", HeaderCss: "!w-1/6", },
    { HeaderName: "Question", Columnvalue: "Question", HeaderCss: "!w-5/6" },
  ];
  const getTrainingID = useCallback((e) => {
    quizData?.QuizActivities?.map((item) => {
      if (e == item.ActivityID && item.ActivityType == "Quiz") {
        setDropdownState({ Language: item?.SK?.split("#")[5], Questionbank: item.ActivityID, TrainingID: item?.SK?.split("#")[1] })
      }
    })
  }, [quizData?.QuizActivities])
  useEffect(() => {
    setValue("ddlSearch", "en")
    if (questionBankId != undefined) {
      getTrainingID(questionBankId)
      setValue("ddlQuestionBank", questionBankId)
    } else {
      setValue("ddlQuestionBank", "")
    }
  }, [getTrainingID, questionBankId, router, setValue, watch])

  const finalResponse = (FinalStatus, ModalType) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", "");

      setModalValues({
        ModalInfo: "Success",
        ModalBottomMessage: "Questions have been added successfully",
        ModalOnClickEvent: () => {
          if (mode == "ModuleDirect") {
            if (router.query["ZoomActivityID"] != undefined) {
              router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
            } else {
              router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}`);
            }
          } else if (props?.mode == "TrainingDirect") {
            if (router.query["Root"] == "TemplateList") {
              router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList&Root=TemplateList`)
            } else {
              router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList`)
            }
          } else {
            if (router.query["ZoomActivityID"] != undefined) {
              router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
            } else {
              router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`);
            }
          }
        },
      });
      ModalOpen();
    }
  };

  const pageChangeCall = useCallback((page) => {
    multipleQuestiondata.current = {
      ...multipleQuestiondata.current,
      page: page,
    };
  }, []);

  const gridDataBind = useCallback(
    (viewData) => {
      let temp = { ...multipleQuestiondata.current };
      let isCount = multipleQuestiondata.current.Called;
      const rowGrid = [];

      setRowData(viewData.length)
      // let temp = { id: [], values: [] }
      viewData &&
        viewData.map((getItem, index) => {
          let regex = /(<([^>]+)>)/gi,
            body = getItem.Question,
            result = body?.replace(regex, "");
          // if (!getItem.IsRandomQuestion) {
            rowGrid.push({
              SelectAll: (
                <NVLCheckbox
                  id={"chk" + isCount}
                  errors={errors}
                  register={register}
                />
              ),
              Question: (
                <NVLlabel
                  id={"txtQuestion" + (index + 1)}
                  className=" p-2"
                  showFull
                  title={result}
                  text={result}
                ></NVLlabel>
              ),

            });
          // }
          // else {
          //   rowGrid.push({
          //     SelectAll: (
          //       <NVLCheckbox
          //         id={"chk" + isCount}
          //         errors={errors}
          //         register={register}
          //       />
          //     ),
          //     Question: (
          //       <NVLlabel
          //         id={"txtQuestion" + (index + 1)}
          //         className=" p-2"
          //         showFull
          //         title={"Random Question"}
          //         text={"Random Question"}
          //       ></NVLlabel>
          //     ),

          //   });
          // }
          let id = "chk" + isCount;
          let val = getItem
          temp = { ...temp, id: [...temp.id, id], values: [...temp.values, { val: val, id: id, currentstate: watch(id) }] }
          isCount++;
        });
      multipleQuestiondata.current = { ...temp, Called: isCount };

      // MultipleQuestiondata.current = { ...MultipleQuestiondata.current, ...temp };
      return rowGrid;
    },
    [errors, register, watch]
  );


  const submitHandler = async () => {
    document?.activeElement?.blur();
    setValue("submit", true);

    let questionBankData = [];
    let finalQuestionBankData = [];
    const RemoveNull = (obj) => {
      let tempjson = {};
      obj && Object.keys(obj).forEach((k) => {
        if (obj?.[k] != undefined) {
          tempjson = { ...tempjson, [k]: obj?.[k] }
        }
      });
      return tempjson;
    }
    multipleQuestiondata.current.values.map(async (item, index) => {
      if (watch(item.id)) {
        questionBankData?.push(item);
      }
    })

    questionBankData?.forEach((itm, idx) => {
      let existData = RemoveNull(itm?.val)
      let SK = mode == "ModuleDirect" ? "COURSE#" + courseId + "#MODULE#" + moduleId + "#ACTIVITYID#" + activityId + "#LANGUAGE#" + existData?.Language + "#QUESTION#" + existData?.QuestionID : props?.mode == "TrainingDirect" ? "TRAINING#" + props?.TrainingId + "#ACTIVITYID#" + props?.ActivityID + "#LANGUAGE#" + existData?.Language + "#QUESTION#" + existData?.QuestionID : "ACTIVITYID#" + activityId + "#LANGUAGE#" + existData?.Language + "#QUESTION#" + existData?.QuestionID
      finalQuestionBankData.push({ ...existData, SK: SK,IsConsume:false,IsRandomQuestion: false, QuestionBank: "", QuestionBankID: "" });
    })
    
    let finalStatus;
    let query = mode == "ModuleDirect" ? createXlmsCourseQuizTemplate : props?.mode == "TrainingDirect" ? createXlmsTrainingQuizTemplate : createXlmsQuizTemplate
    if (finalQuestionBankData.length != 0) {
      while (finalQuestionBankData.length > 25) {
     
        let tempArray = finalQuestionBankData.splice(0, 25);
        AppsyncDBconnection(query, { input: tempArray }, props.user.signInUserSession.accessToken.jwtToken);
      } 
      finalStatus = (await AppsyncDBconnection(query,  { input: finalQuestionBankData }, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
      finalResponse(finalStatus)
    }
    refreshGrid();
    setValue("submit", false);
  }
  
  const variable = useMemo(() => {
    let moduleId = dropdownState.Questionbank?.toString()?.substring(0, 6)
    let sk = (mode == "ModuleDirect") ? "COURSE#" + courseId + "#MODULE#" + moduleId + "#ACTIVITYID#" + dropdownState.Questionbank + "#LANGUAGE#" + dropdownState?.Language: props?.mode == "TrainingDirect" ? "TRAINING#" + dropdownState?.TrainingID + "#ACTIVITYID#" + dropdownState?.Questionbank + "#LANGUAGE#" + dropdownState?.Language + "#QUESTION#" : "ACTIVITYID#" + dropdownState?.Questionbank + "#LANGUAGE#" + dropdownState?.Language
    return props?.mode == "TrainingDirect" ? {
      PK: "TENANT#" + props.TenantInfo.TenantID,
      SK: sk,
      IsDeleted: false,
    } : {
      PK: "TENANT#" + props.TenantInfo.TenantID,
      SK: sk,
      IsDelete: false,
    };
  }, [mode, courseId, dropdownState?.Questionbank, dropdownState?.Language, dropdownState?.TrainingID, props?.mode, props?.TenantInfo.TenantID]);
  const query = useMemo(()=>{
    let query = mode == "ModuleDirect" ? listXlmsCourseQuizTemplate : props?.mode == "TrainingDirect" ? listXlmsTrainingQuizTemplateInfos : listXlmsQuizTemplate
    return query
  },[mode, props?.mode])
  const queryName = useMemo(()=>{
    let queryName = mode == "ModuleDirect" ? "listXlmsCourseQuizTemplate" : props?.mode == "TrainingDirect" ? "listXlmsTrainingQuizTemplateInfos" : "listXlmsQuizTemplate"
    return queryName
  },[mode, props?.mode])

  const pageRoutes = useMemo(()=>{
    let pageRoutes = [];
    if (mode == "ModuleEdit" || mode == "ModuleDirect") {
      if (router.query["ZoomActivityID"] != undefined) {
        pageRoutes = [
          { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
          { path: `/CourseManagement/ModulesList?CourseID=${courseId}`, breadcrumb: "Manage Course" },
          { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${courseId}&ModuleID=${moduleId}&ModuleName=${props?.Editdata?.ModuleName}`, breadcrumb: "Edit Activity Zoom" },
          { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${courseId}&ModuleID=${moduleId}`, breadcrumb: "Edit Settings Zoom" },
          { path: `/CourseManagement/ModuleInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ModuleName=${props.EditData?.ModuleName}&ZoomActivityName=${router.query["ZoomactivityName"]}`, breadcrumb: "Edit Activity" },
          { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
          { path: `/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Question" },
          { path: "", breadcrumb: "Question Bank" }
        ];
      } else {
        pageRoutes = [
          { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
          { path: `/CourseManagement/ModulesList?CourseID=${courseId}`, breadcrumb: "Manage Course" },
          { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ModuleName=${props?.Editdata?.ModuleName}`, breadcrumb: "Edit Activity" },
          { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}`, breadcrumb: "Edit Settings" },
          { path: `/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}`, breadcrumb: "Question" },
          { path: "", breadcrumb: "Question Bank" }
        ];
      }
    } else if (props?.mode == "TrainingDirect") {
      if (router.query["Root"] == "TemplateList") {
        pageRoutes = [
          { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
          { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${props?.TrainingID}&TrainingName=${props?.TrainingName}`, breadcrumb: "Training Template List" },
          { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Root=TemplateList`, breadcrumb: "Edit Activity" },
          { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Root=TemplateList`, breadcrumb: "Edit Settings" },
          { path: `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList&Root=TemplateList`, breadcrumb: "Question" },
          { path: "", breadcrumb: "Question Bank" }
        ];
      } else {
        pageRoutes = [
          { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
          { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}`, breadcrumb: "Edit Activity" },
          { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&`, breadcrumb: "Edit Settings" },
          { path: `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList`, breadcrumb: "Question" },
          { path: "", breadcrumb: "Question Bank" }
        ];
      }
    } else {
      if (router.query["ZoomActivityID"] != undefined) {
        if (!router.query["NavigationMode"]) {
          pageRoutes = [
            { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
            { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Settings Zoom" },
            { path: `/ActivityManagement/ActivityInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${activityType}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
            { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
            { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Question" },
            { path: "", breadcrumb: "Question Bank" }
          ];
        } else {
          pageRoutes = [
            { path: `/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`, breadcrumb: "Activity Management" },
            { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Activity" },
            { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}&NavigationMode=${router.query["NavigationMode"]}`, breadcrumb: "Edit Settings" },
            { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["NavigationMode"]}`, breadcrumb: "Question" },
            { path: "", breadcrumb: "Question Bank" }
          ];
        }
      } else {
        pageRoutes = [
          { path: "/ActivityManagement/ActivityList", breadcrumb: mode == "ModuleDirect" ? "Course Management" : "Activity Management" },
          { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`, breadcrumb: "Edit Activity" },
          { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`, breadcrumb: "Edit Settings" },
          { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`, breadcrumb: "Question" },
          { path: "", breadcrumb: "Question Bank" }
        ];
      }
    }
    return pageRoutes;
  },[activityId, activityType, courseId, mode, moduleId, props?.ActivityID, props?.ActivityType, props?.AssessmentType, props.EditData?.ModuleName, props?.Editdata?.ModuleName, props?.TrainingID, props?.TrainingId, props?.TrainingName, props?.mode, router.query])
 
  return (
    <>
      <Container title="QuestionBank" loader={quizData == undefined} PageRoutes={pageRoutes}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <NVLHeader IsNestedHeader IsDropdown={true}
          DropdownRequired DropdownData={language} errors={errors} register={register}> </NVLHeader>
        <form onSubmit={handleSubmit(submitHandler)} id="Formjs">
          <div className="p-3">
            <NVLSelectField id="ddlQuestionBank" errors={errors} register={register} options={questionBankList} className="nvl-SelectField w-64" />
          </div>
          <NVLGridTable
            refershPage={isRefreshing}
            Search={search}
            id="tblQuestionList"
            HeaderColumn={headerColumn}
            GridDataBind={gridDataBind}
            query={query}
            querryName={queryName}
            DonotLoad={true}
            LoadInSinglePage={true}
            pageChangeCall={pageChangeCall}
            variable={variable}
            user={props?.user}
          />
          <div id="buttons" className={`justify-center flex p-4 ${rowData == 0 ? "hidden" : ""}`}>
            <div className="flex gap-2">
              <NVLButton id="btnAdd" text={!watch("submit") ? "Add" : ""} disabled={watch("submit") ? true : false} type="submit" className={watch("submit") ? "w-24 nvl-button-success text-white" : " w-24 nvl-button-success text-white"}> {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
              <NVLButton
                text="Cancel"
                className="w-24 nvl-button"
                type={"button"}
                onClick={() => {
                  if (mode == "ModuleDirect") {
                    if (router.query["ZoomActivityID"] != undefined) {
                      router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
                    } else {
                      router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${activityId}&ActivityType=${activityType}&CourseID=${courseId}&ModuleID=${moduleId}`);
                    }
                  } else if (props?.mode == "TrainingDirect") {
                    router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Settings=QuizList`);
                  } else {
                    if (router.query["ZoomActivityID"] != undefined) {
                      router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
                    } else {
                      router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${activityId}&ActivityType=${activityType}`);
                    }
                  }
                }}
              />
            </div>
          </div>
        </form>
      </Container>
    </>
  )
}

export default QuestionBank;

