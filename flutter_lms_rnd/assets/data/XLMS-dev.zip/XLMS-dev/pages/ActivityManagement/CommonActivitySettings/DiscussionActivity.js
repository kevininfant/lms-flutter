import { DynamicFileLanguageValidation } from "@Pages/ActivityManagement/CommonActivitySettings/CommonFunction";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, Anonymous, CheckboxesInput, ReactTagsButton } from "./ActivityComponents";
export const DiscussionActivity = ({ DateCoversion, Attempt, AllowAttempts, GradeMethod, CustomMessage, UnSavedtoSaved, LanguageType, setFileValues, FileValues, FinalResponse, query, props, ButtonClassName, ButtonText, delimiters, router }) => {

    const stDate = useRef();
    const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
    const validationSchema = Yup.object().shape({
        /* Dynamic Language */
        FileLang: Yup.string()
            .test("file_Error", "", (e, { createError }) => {
                let message = DynamicFileLanguageValidation(e, "ddlAssignment", FileValues);
                if (message != "") {
                    setValue("dynamicError", message)
                    return createError({ message: message });
                } else {
                    setValue("dynamicError", undefined)
                    return true;
                }
            }).nullable(),

        /* Activity Download */
        rbFileDownload: Yup.string().nullable().test("", "", () => {
            return true;
        }),
        /* Discussion */
        txtMaxAttachmentSize: Yup.string()
            .typeError("Maximum attachment size is required")
            .required("Maximum attachment size is required")
            .matches(Regex("AllowOnlyNumbers"), "Attachment size allows only numerics")
            .transform((o, c) => (o === "" ? null : c))
            .test("error", "", (val, { createError }) => {
                if (parseInt(val) > 1024) {
                    return createError({ message: "Maximum Attachment Size 1-1024 MB" });
                } else if (parseInt(val) == 0) {
                    return createError({ message: "Maximum Attachment Size 1-1024 MB" });
                }
                return true;
            })
            .nullable(true),
        txtMaxNoOfAttachment: Yup.string()
            .typeError("Maximum attachment size is required")
            .transform((o, c) => (o === "" ? null : c))
            .required("Maximum number of attachment is required")
            .nullable()
            .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
            .test("error", "", (val, { createError }) => {
                if ((val != "" || val != undefined) && (parseInt(val) > 20 || parseInt(val) <= 0)) {
                    return createError({ message: "Attachment should be between 1-20" });
                }
                return true;
            }),

        /* Activity Completion */
        rbActivityCompletion: Yup.string()
            .required("Activity completion is required")
            .nullable()
            .test("error", "", (e, { createError }) => {
                if (e == "true") {
                    let array = ["chkViewTheActivity", "chkCompleteTheActivity", "chkMarkTheActivity", "chkSubmitTheActivity", "ChkUserCreateReplies"];
                    let result = [];
                    array.map((item) => {
                        result.push(watch(item));
                    });
                    if (result.indexOf(true) == -1) {
                        setValue("activitycompletionError", "At least one is required.")
                        return createError({ message: "At least one is required." });
                    } else {
                        setValue("activitycompletionError", undefined)
                        return true;
                    }
                } else {
                    setValue("chkViewTheActivity", null)
                    setValue("chkCompleteTheActivity", null)
                    setValue("chkSubmitTheActivity", null)
                    setValue("chkMarkTheActivity", null)
                    setValue("ChkUserCreateReplies", null)
                    setValue("activitycompletionError", undefined)
                }
                return true;
            })
            .nullable(),
        txtstdate: Yup.string()
            .nullable(true)
            .notRequired().test("Check", "Activity can be created only for present and future date", (e, { createError }) => {
                if (e == "" || e == undefined || e == null) {
                    return true;
                }
                else {
                    if (new Date(e) > new Date(new Date().setDate(new Date().getDate() - 1))) {
                        if ((stDate.current != e) && (watch("chkEndDateEnable") != undefined && watch("chkEndDateEnable"))
                            && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
                            stDate.current = e;
                            setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
                        } else if (watch("chkEndDateEnable") && watch("txtEnddate") != undefined && watch("txtEnddate") != "") {
                            clearErrors(["txtEnddate"])
                        }
                        return true;
                    }
                    else {
                        return false
                    }
                }
            }).nullable(true),
        txtEnddate: Yup.date()
            .when("chkEndDateEnable", {
                is: true,
                then: Yup.date().required("End Date is Required").test("error", "End Date must be greater than the start date", (e, { createError }) => {
                    if (e == undefined ) {
                        return createError({ message: "End Date is Required" })
                    }
                    if (e > new Date(watch("txtstdate"))) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }).typeError("End Date is Required").nullable(),
            }).nullable(true),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), nativeValidation: false };
    const { register, handleSubmit, setValue, watch, formState, reset, clearErrors } = useForm(formOptions);
    const { errors } = formState;


    const handleDelete = useCallback(
        (i) => {
            setTags(tags.filter((tag, index) => index !== i));
            setValue("ReactTags", "Delete", { shouldValidate: true });
        },
        [setValue, tags]
    );

    const handleAddition = useCallback(
        (tag) => {
            setTags([...tags, tag]);
            setValue("ReactTags", "Add", { shouldValidate: true });
        },
        [setValue, tags]
    );

    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags, setTags]
    );

    useEffect(() => {

        setValue("ddlForumtype", props.EditData?.ForumType == null ? "StandardForum" : props.EditData?.ForumType);
        setValue("chkStartDateEnable", props.EditData?.IsStartDateEnable == null ? true : props.EditData?.IsStartDateEnable);
        setValue("chkEndDateEnable", props.EditData?.IsEndDateEnable);
        setValue("txtstdate", props.EditData?.StartDate != undefined ? DateCoversion(props.EditData?.StartDate) : undefined);
        setValue("txtEnddate", props.EditData?.EndDate != undefined ? DateCoversion(props.EditData?.EndDate) : undefined);
        setValue("txtMaxAttachmentSize", props.EditData?.MaxmumAttachmentSize);
        setValue("txtMaxNoOfAttachment", props.EditData?.MaximumNumberOfAttachment);
        setValue("rbRecordUserName", props.EditData?.IsRecordUserName == null ? "false" : props.EditData?.IsRecordUserName.toString())
        setValue("ddlDiscussion", ((props.EditData?.ForumType == undefined || props.EditData?.ForumType == null) ? "" : props.EditData?.ForumType))
        setValue("chkCompleteTheActivity", props.EditData?.IsCompleteTheActivity);
        setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
        setValue("ChkUserCreateReplies", props.EditData?.IsUserMustCreate);
        setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion == null ? "false" : props.EditData?.IsActivityCompletion?.toString());
    }, [DateCoversion, props.EditData?.EndDate, props.EditData?.ForumType, props.EditData?.IsActivityCompletion, props.EditData?.IsCompleteTheActivity, props.EditData?.IsEndDateEnable, props.EditData?.IsMarkTheActivity, props.EditData?.IsRecordUserName, props.EditData?.IsStartDateEnable, props.EditData?.IsUserMustCreate, props.EditData?.MaximumNumberOfAttachment, props.EditData?.MaxmumAttachmentSize, props.EditData?.StartDate, setValue])

    const discussionLocking = useMemo(() => {
        return [
            { value: "", text: "Select" },
            { value: "DonotLockDiscussions", text: "Do not Lock Discussions" },
            { value: "1Day", text: "1 Day" },
            { value: "1Week", text: "1 Week" },
            { value: "2Weeks", text: "2 Weeks" },
            { value: "1Month", text: "1 Month" },
            { value: "2Months", text: "2 Months" },
            { value: "3Months", text: "3 Months" },
            { value: "6Months", text: "6 Months" },
            { value: "1Year", text: "1 Year" },
        ];
    }, []);
    const submitHandler = async (data) => {
        setValue("submit", true)
        let PK, SK;
        if (props.mode == "ModuleDirect") {
            PK = "TENANT#" + props.TenantInfo.TenantID;
            SK = props.EditData.SK
        } else if (props.mode == "Edit") {
            PK = "TENANT#" + props.TenantInfo.TenantID;
            SK = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
        }

        let discussionVariables = {
            input: {
                PK: PK,
                SK: SK,
                ForumType: data.ddlDiscussion,
                StartDate: data.txtstdate != undefined && data.txtstdate != "" ? data.txtstdate : "",
                EndDate: data.txtEnddate != undefined && data.txtEnddate != "" ? data.txtEnddate : "",
                IsStartDateEnable: data.chkStartDateEnable,
                IsEndDateEnable: data.chkEndDateEnable,
                MaxmumAttachmentSize: data.txtMaxAttachmentSize,
                MaximumNumberOfAttachment: data.txtMaxNoOfAttachment,
                IsActivityCompletion: watch("rbActivityCompletion") == "false" ? false : data.rbActivityCompletion,
                IsCompleteTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkCompleteTheActivity,
                IsUserMustCreate: watch("rbActivityCompletion") == "false" ? false : data.ChkUserCreateReplies,
                IsMarkTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkMarkTheActivity,
                IsRecordUserName: data.rbRecordUserName,
                Keywords: JSON.stringify(tags),
                ModifiedBy: props.user.username,
                ModifiedDate: new Date()
            },
        };
        /*Batch Update*/
        let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
        for (let i = 1; i <= props.EditData.Shard; i++) {
            UpdateBatch({ inn: { ...props.EditData, ...discussionVariables.input }, props: props, pk: "TENANT#" + props.EditData.TenantID + "#" + i, query: queryBatch, UpdateData: props.EditData, });
        }
        /*Batch Update*/
        let finalStatus = (await AppsyncDBconnection(query, discussionVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
        FinalResponse(finalStatus);
        setValue("submit", false)
    };

    const DateTimeControl = () => {
        let today = new Date();
        let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T00:00:00";
        if (!watch("chkEndDateEnable")) {
            if (!(watch("txtEnddate") == undefined)) {
                setValue("txtEnddate", undefined, { shouldValidate: true })
            }
        }
        return (
            <div className="grid pt-2">

                <div className="flex">
                    <div className="pb-2">
                        <NVLlabel text="Start Date"></NVLlabel>
                        <NVLTextbox id="txtstdate" title="Start Date" type="datetime-local" tabIndex={!watch("chkStartDateEnable") ? "1" : "1"} className={"nvl-Def-Input"} min={dateTime} setValue={setValue} errors={errors} register={register}></NVLTextbox>
                    </div>
                </div>

                <div className="flex">
                    <div className="">
                        <NVLlabel text="End Date"></NVLlabel>
                        <NVLTextbox title="End Date" id="txtEnddate" type="datetime-local" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"} className={!watch("chkEndDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkEndDateEnable")} errors={errors} register={register} setValue={setValue}></NVLTextbox>
                    </div>
                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkEndDateEnable" errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <section>
            <form>
                <div id="divDiscussion" className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}>
                    <div className="container px-12 mx-auto grid gap-8 ">
                        <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name: ${props?.EditData?.ActivityName}`}></NVLlabel>
                        <NVLlabel className="nvl-Def-Label " id="lblActivityType" text={`Activity Type : Discussion`}></NVLlabel>
                        <div className="flex flex-col sm:flex-row  gap-4">
                            <NVLlabel className="nvl-Def-Label w-52" id="lblForumType" text="Discussion Locking"></NVLlabel>
                            <NVLSelectField id="ddlDiscussion" options={discussionLocking} className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register}></NVLSelectField>
                        </div>
                        <div className="flex flex-col sm:flex-row  gap-4 ">
                            <NVLlabel className="nvl-Def-Label w-52" id="lblAvailability" text="Availabilty" ></NVLlabel>
                            <DateTimeControl setValue={setValue} register={register} errors={errors} watch={watch} reset={reset} />
                        </div>
                        <div className="flex flex-col sm:flex-row  gap-4 ">
                            <NVLlabel className="nvl-Def-Label w-52" id="lblAttachments" text="Attachments"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <div className="gap-4">
                                <div>
                                    <NVLlabel text="Maximum Attachment Size (in MB)" id="lblAttachmentsize"></NVLlabel>
                                    <NVLTextbox title="Maximum Attachment size" id="txtMaxAttachmentSize" className="nvl-mandatory w-96 " type="text" errors={errors} register={register}></NVLTextbox>
                                </div>
                                <div className=" pt-6 gap-4">
                                    <NVLlabel text="Maximum Number of attachments" id="lblNoOfAttachment"></NVLlabel>
                                    <NVLTextbox title="Maximum number of attachments" id="txtMaxNoOfAttachment" className="nvl-mandatory w-96" type="number" errors={errors} register={register}></NVLTextbox>
                                </div>
                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4 ">
                            <NVLlabel className="nvl-Def-Label w-52" id="lblAnonymous" text="Record User as Anonymous"></NVLlabel>
                            <div>
                                <Anonymous watch={watch} register={register} errors={errors}></Anonymous>
                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4 ">
                            <NVLlabel id="lblActivityCompletion" text="Activity Completion" className="nvl-Def-Label w-52"></NVLlabel>
                            <div>
                                <ActivityCompletion register={register} errors={errors} watch={watch} />
                                <CheckboxesInput register={register} errors={errors} watch={watch}
                                    CustomMessage={CustomMessage}
                                    IsMarkTheActivity={true} IsUserMustCreate={true} >
                                    <NVLCheckbox text="User participates the activity to complete it." id="chkCompleteTheActivity" errors={errors} register={register} setValue={setValue} showFull
                                    ></NVLCheckbox></CheckboxesInput>
                                <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"} >
                                    <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation"> {watch("activitycompletionError")}</div>
                                </div>
                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4">
                            <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52"></NVLlabel>
                            <div>
                                <ReactTagsButton register={register} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} props={props} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} handleDelete={handleDelete} handleDrag={handleDrag} />
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </section >
    );
}
export default DiscussionActivity;