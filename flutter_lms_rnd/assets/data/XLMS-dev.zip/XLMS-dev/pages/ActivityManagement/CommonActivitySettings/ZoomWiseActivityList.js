import Container from "@components/Container/Container";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { updateXlmsActivityManagementInfo } from "@graphql/graphql/mutations";
import { listXlmsActivityManagementInfos } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useState } from "react";

export default function ZoomWiseActivityList(props) { 
    const router = useRouter();
  const [popupValues, setPopupValues] = useState({});
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [Search, setSearch] = useState("")
  const HeaderColumn = [
    { HeaderName: "Activity Name", Columnvalue: "ActivityName", HeaderCss: "w-3/12", },
    { HeaderName: "Activity Type", Columnvalue: "ActivityType", HeaderCss: "w-8/12", },
    { HeaderName: "Date", Columnvalue: "CreatedDate", HeaderCss: "w-0/12 whitespace-nowrap" },
    { HeaderName: "Activity Status", Columnvalue: "IsSuspend", HeaderCss: "w-0/12", },
    { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
  ];
  
  const refreshData = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };
  const refreshGrid = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };

  function ResetPopUp() {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
  }

  function popup(type, PK, SK, Content) {
    setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
  }
  async function UpdateField(e) {
    e.preventDefault();
    let isSus = false;
    let isDelete = false;
    if (popupValues.Type == "isSuspend") {
      isSus = true;
    } else if (popupValues.Type == "isDelete") {
      isDelete = true;
    }
    refreshData();
    let FinalStatus = await AppsyncDBconnection(updateXlmsActivityManagementInfo, { input: { PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus, IsDeleted: isDelete } }, props.user.signInUserSession.accessToken.jwtToken)
    if (FinalStatus.Status == "Success") {
      refreshData();
    }
    ResetPopUp();
  }

  function GetDateFormat(CreatedDt) {
    return (new Date(CreatedDt).toDateString().substring(4))
  }

  const ActionRestriction = useCallback((getItem) => {
    let ActionList = [];
    if (props.RoleData?.ShowCourseActivity && getItem.IsSuspend) {
      ActionList.push(
        {
          id: 1,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
          name: "Show Activity",
          action: () => popup("",getItem.PK,getItem.SK,"Are you sure to Show Activity?"),
        }
      )
    }
    if (props.RoleData?.DeleteActivity && getItem.IsSuspend) {
      ActionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete Activity",
          action: () => popup( "isDelete", getItem.PK, getItem.SK, "Are you sure to Delete Activity?"),
        }
      )
    }
    if (props.RoleData?.EditActivity && !getItem.IsSuspend) {
      ActionList.push(
        {
          id: 4,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit Activity",
          action: () =>
          router.push(
            `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}&ZoomActivityID=${getItem.ZoomActivityID}&ZoomActivityName=${getItem.ActivityName.split("-")[0]}&NavigationMode=${getItem.ActivityName.split("-")[1]}`
          ),
          // router.push(`/ActivityManagement/ActivityInfo?Mode=${getItem.ActivityName.split("-")[1]}&ZoomActivityID=${getItem.ZoomActivityID}&ActivityType=${getItem.ActivityType}&ZoomActivityName=${getItem.ActivityName.split("-")[0]}`)
        }
      )
    }
    if (props.RoleData?.EditActivitySettings && !getItem.IsSuspend) {
      ActionList.push(

        {
          id: 5,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit Settings",
          action: () =>
          router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}&ZoomActivityID=${getItem.ZoomActivityID}&ZoomActivityName=${getItem.ActivityName.split("-")[0]}&ZoomActivityMode=${getItem.ActivityName.split("-")[1]}&NavigationMode=List`)
        },
      )
      }
    if (props.RoleData?.HideCourseActivity && !getItem.IsSuspend) {
      ActionList.push(
        {
          id: 10,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
          name: "Hide Activity",
          action: () =>
            popup(
              "isSuspend",
              getItem.PK,
              getItem.SK,
              "Are you sure to Hide Activity?"
            ),
        }
      )
    }
    return ActionList;
  }, [router, props])

  const GridDataBind = useCallback(
    (viewData) => {
      const RowGrid = [];
      let ZoomWiseActivityFilter = viewData?.filter((i) => i.ZoomActivityID == router.query["ActivityID"]);

      ZoomWiseActivityFilter &&
      ZoomWiseActivityFilter.map((getItem, index) => {
          let regex = /(<([^>]+)>)/gi,
            body = getItem.ActivityDescription,
            result = body?.replace(regex, "").body?.replace(/&amp;/g, "&").replace(/&nbsp;/g, ' '),
            ActionList = [];
          ActionList = ActionRestriction(getItem)
            RowGrid.push({
              PK: (
                <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
              ),
              SK: (
                <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
              ),
              ActivityId: (
                <NVLlabel id={"lblActivityId" + (index + 1)} name="ActivityId" text={getItem.SK} />
              ),
              ActivityName: (
                <NVLlabel id={"txtActivityName" + (index + 1)} text={getItem.ActivityName}></NVLlabel>
              ),
              ActivityType: (
                <NVLlabel id={"txtActivitycategory" + (index + 1)} text={getItem.ActivityType}></NVLlabel>
              ),
              CreatedDate: (
                <NVLlabel id={"txtName" + (index + 1)} text={GetDateFormat(getItem.CreatedDate)}></NVLlabel>
              ),
              IsSuspend: (
                <>
                  <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                    <div className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600" }	`}></div>
                    <NVLlabel className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2	`} text={!getItem.IsSuspend ? "Active" : "Inactive"}></NVLlabel>
                  </div>
                </>
              ),
              Action: (
                <NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={ActionList}></NVLRapidModal>
              ),
            });
        });
      return RowGrid;
    }, [ActionRestriction, router.query]
  );
  const CancelEvent = (e) => {
    e.preventDefault();
    ResetPopUp();
  };
  const variable = { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#"  }
  const PageRoutes = [
    { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
    { path: "", breadcrumb: "Zoom Wise Activity List" }
  ];
    return (
        <>
        <Container title="Activity Management">
        <NVLBreadCrumbs Routes={PageRoutes}></NVLBreadCrumbs>
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} />
        <div className="max-w-full w-full justify-center">
          <NVLGridTable user={props.user} refershPage={isRefreshing} id="tblActivityList" Search={Search} HeaderColumn={HeaderColumn} GridDataBind={GridDataBind} query={listXlmsActivityManagementInfos} querryName={"listXlmsActivityManagementInfos"} variable={variable} />
        </div>
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => UpdateField(e)} CancelClick={(e) => CancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => ResetPopUp()} Content={popupValues.Content} />
        </Container>
        </>
    )
 }