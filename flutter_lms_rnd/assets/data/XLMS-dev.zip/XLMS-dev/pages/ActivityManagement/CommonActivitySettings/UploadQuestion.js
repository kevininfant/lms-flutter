import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import {
  APIGatewayGetRequest,
  APIGatewayPostRequest,
  APIGatewayPutRequest
} from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function UploadQuestion(props) {
  
  const [fileValues, setFileValues] = useState({
    TextName: "Select File",
    FilePath: null,
    path: null,
    pathchanged: false,
  });
  const [textName, setTextName] = useState(props.modalValues);

  const validationSchema = Yup.object().shape({
    File: Yup.string().test("file_Error", "", (e, { createError }) => {
      if (e == undefined || e == "false" || textName == undefined) {
        return createError({ message: "File is required" });
      }
      if (e == "fileType") {
        return createError({ message: "Invalid file type" });
      }
      if (e == "Empty" || e == undefined) {
        return createError({ message: "Empty File... Please Fill Values" });
      }
      if (e == "HeaderMismatch" || e == undefined) {
        return createError({
          message: "Header Mismatch Please Choose Correct Formate.",
        });
      }
      if (e == "FileSize") {
        setTextName("Select File");

        return createError({ message: "File size should be 5MB" });
      }
      if (e == "Error") {
        return createError({ message: "Server Error Please Try Again" });
      }
      return true;
    }),
  });

  const clearForm = useCallback(() => {
    setFileValues({ TextName: "Select File", FilePath: null });
    setValue("ddlLanguage", "en");
    setValue("File", "", { shouldValidate: true });
    setValue("submit", false);
  }, [setValue]);
  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };
  const { register, handleSubmit, setValue, reset, watch, formState } =
    useForm(formOptions);
  const { errors } = formState;
  const questionHeader = useMemo(() => {
    return [
      // { HeaderName: "QuestionNumber", Action: "true" },
      { HeaderName: "Question", Action: "true" },
      { HeaderName: "QuestionType", Action: "true" },
      { HeaderName: "ChoiceType", Action: "true" },
      { HeaderName: "Option1", Action: "true" },
      { HeaderName: "Option2", Action: "true" },
      { HeaderName: "Grade", Action: "true" },
      { HeaderName: "Feedback", Action: "true" },
      { HeaderName: "DefaultMark", Action: "true" },
      { HeaderName: "NumberTheChoices", Action: "true" },
      // { HeaderName: "Grade1", Action: "true" },
      // { HeaderName: "Feedback1", Action: "true" },
      // { HeaderName: "Option2", Action: "true" },
      // { HeaderName: "Grade2", Action: "true" },
      // { HeaderName: "Feedback2", Action: "true" },
      // { HeaderName: "Option3", Action: "true" },
      // { HeaderName: "Grade3", Action: "true" },
      // { HeaderName: "Feedback3", Action: "true" },
      // { HeaderName: "Option4", Action: "true" },
      // { HeaderName: "Grade4", Action: "true" },
      // { HeaderName: "Feedback4", Action: "true" },
      // { HeaderName: "Option5", Action: "true" },
      // { HeaderName: "Grade5", Action: "true" },
      // { HeaderName: "Feedback5", Action: "true" },
     
    ];
  }, []);

  const language = useMemo(() => {
    let languageType = [];
    if (
      Object.keys(JSON?.parse(props?.Language?.items[0]?.LanguageName)) !=
      undefined
    ) {
      Object.entries(
        JSON?.parse(props?.Language?.items[0].LanguageName)
      ).forEach(([key, value]) => {
        languageType = [...languageType, { value: value, text: key }];
      });
    }
    return languageType;
  }, [props?.Language?.items]);

  const downloadCsvFile = useCallback(
    async (e) => {
      if (e?.type == "click") {
        let rows = [];
        questionHeader?.forEach((element) => {
          element.Action === "true" ? rows.push(element.HeaderName) : "";
        });

        let csvContent = rows;
        csvContent += "\r\n";

        let sampleArray = [
          {
            Question:
              "How Can you protect data from being stolen while going for lunch?",
            QuestionType: "MultipleChoice",
            ChoiceType: "MultipleAnswer",
            Option1: "With screen saver",
            Option2: "By Locking your computer with windows+L Keys.",
            Grade:"100",
            Feedback:"Correct Answer",
            DefaultMark: "1",
            NumberTheChoices:"1"
            // Grade1: "0",
            // Feedback1: "Wrong Answer",
            // Grade2: "100",
            // Feedback2: "Correct Answer",
            // Option3: "By turning off the monitor",
            // Grade3: "0",
            // Feedback3: "Wrong Answer",
            // Option4: "null",
            // Grade4: "null",
            // Feedback4: "null",
            // Option5: "null",
            // Grade5: "null",
            // Feedback5: "null",
          },
          {
            Question:
              "The Worst punishment an employee can get for sharing his/her passwords with others is[Termination|Salary Deduction|No Promotion|A few days suspension from work]______",
            QuestionType: "FillInTheBlank",
            ChoiceType: "null",
            Option1: "null",
            Option2: "null",
            Grade:"100",
            Feedback:"Correct Answer",
            DefaultMark: "1",
            NumberTheChoices:"1"
            // Grade1: "null",
            // Feedback1: "null",
            // Grade2: "null",
            // Feedback2: "null",
            // Option3: "null",
            // Grade3: "null",
            // Feedback3: "null",
            // Option4: "null",
            // Grade4: "null",
            // Feedback4: "null",
            // Option5: "null",
            // Grade5: "null",
            // Feedback5: "null",
            // DefaultMark: "1",
          },
          {
            Question: "Give Brief description about ISMS",
            QuestionType: "Description",
            ChoiceType: "null",
            Option1: "null",
            Option2: "null",
            Grade:"100",
            Feedback:"Correct Answer",
            DefaultMark: "1",
            NumberTheChoices:"1"
            // Grade1: "null",
            // Feedback1: "null",
            // Grade2: "null",
            // Feedback2: "null",
            // Option3: "null",
            // Grade3: "null",
            // Feedback3: "null",
            // Option4: "null",
            // Grade4: "null",
            // Feedback4: "null",
            // Option5: "null",
            // Grade5: "null",
            // Feedback5: "null",
            // DefaultMark: "1",
          },
        ];
        let note =
          "Instructions:" +
          "," +
          "\n 1.While uploading the template ensure to delete all the sample question and instruction." +
          "," +
          " \n 2.Except headers remove sample questions and instructions.";
        sampleArray.map((item, index) => {
          // (csvContent +=
          //   index +
          //   1 +
          //   "," +
          //   item.Question +
          //   "," +
          //   item.QuestionType +
          //   "," +
          //   item.ChoiceType +
          //   "," +
          //   item.Option1 +
          //   "," +
          //   item.Grade1 +
          //   "," +
          //   item.Feedback1 +
          //   "," +
          //   item.Option2 +
          //   "," +
          //   item.Grade2 +
          //   "," +
          //   item.Feedback2 +
          //   "," +
          //   item.Option3 +
          //   "," +
          //   item.Grade3 +
          //   "," +
          //   item.Feedback3 +
          //   "," +
          //   item.Option4 +
          //   "," +
          //   item.Grade4 +
          //   "," +
          //   item.Feedback4 +
          //   "," +
          //   item.Option5 +
          //   "," +
          //   item.Grade5 +
          //   "," +
          //   item.Feedback5 +
          //   "," +
          //   item.DefaultMark),
            (csvContent +=
              item.Question +
              "," +
              item.QuestionType +
              "," +
              item.ChoiceType +
              "," +
              item.Option1 +
              "," +
              item.Option2 +
              "," +
              item.Grade +
              "," +
              item.Feedback +
              "," +
              item.DefaultMark+
              "," + 
              item.NumberTheChoices),
            (csvContent += "\n");
        });
        let link = document.createElement("a");
        link.id = "download-csv";
        link.setAttribute(
          "href",
          "data:text/plain;charset=utf-8," +
          encodeURIComponent(csvContent + "\n" + note)
        );
        link.setAttribute("download", "Question Template.csv");
        document.body.appendChild(link);
        document.querySelector("#download-csv").click();
      }
    },
    [questionHeader]
  );
  
  async function fileValidation(e) {
    setValue("File", "Uploading");
    const file = e.target.files[0];
    if (file == undefined) {
      if (fileValues?.FilePath != undefined || fileValues?.FilePath != "") {
        setValue("File", "exist", { shouldValidate: true });
      }
      else {
        setValue("File", "Empty", { shouldValidate: true });
      }
      return true;
    }
    let fileInput = document.getElementById("getFile");
    let filePath = fileInput.value;
    let allowedExtensions = /(\.csv)$/i;

    if (!allowedExtensions.exec(filePath)) {
      fileInput.value = "";
      setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
      setValue("File", "fileType", { shouldValidate: true });
      return false;
    } else if (file.size > process.env.ACTIVITY_ENROLLUSER_FILE_SIZE) {
      setValue("File", "FileSize", { shouldValidate: true });
    } else {
      await uploadFile(e);
    }
  }
  async function uploadFile(e) {
    const file = e.target.files[0];
    const csvReader = new FileReader();
    csvReader.onload = async function (e) {
      const text = e.target.result;
      let lines = text.split("\n");
      let values = lines[0].split(",");
      let isCSVDatacheck = false;
      // for (let i = 0; i < questionHeader.length; i++) {
      //   if (
      //     values[i].trim() != questionHeader[i].HeaderName.trim() ||
      //     values.length != questionHeader.length
      //   ) {
      //     setValue("File", "HeaderMismatch", { shouldValidate: true });
      //     isCSVDatacheck = true;
      //     return;
      //   }
      // }
      // if (!isCSVDatacheck) {
      //   let data = lines[1].split(",");
      //   if (data.length != questionHeader.length) {
      //     setValue("File", "Empty", { shouldValidate: true });
      //     isCSVDatacheck = true;
      //     return;
      //   }
      // }

      let fetchURL;
      if (!isCSVDatacheck) {
        if (props.NavigateMode == "ModuleDirect") {
          fetchURL = process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
            `?FileName=${file.name}&TenantID=${props.TenantInfo.TenantID}&CourseType=Module&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&Type=QuizQuestionTemplate&ManagementType=CourseManagement`
        } else {
          fetchURL =
            process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
            `?FileName=${file.name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ActivityType=${props.ActivityType}&Type=QuizQuestionTemplate`;
        }

        let groupMenuName = props.NavigateMode == "ModuleDirect" ? "CourseManagement" : "ActivityManagement";
        let menuId = props.NavigateMode == "ModuleDirect" ? "300406" : "500002";
        let headers = {
          method: "GET",
          headers: {
            authorizationToken: await Auth.currentSession().then((s) =>
              s.getAccessToken().getJwtToken()
            ),
            defaultrole: props.TenantInfo.UserGroup,
            groupmenuname: groupMenuName,
            menuid: menuId,
          },
        };
        let extension = file.name
          .substring(file.name.lastIndexOf(".") + 1)
          .toLowerCase();
        let ContentType =
          extension == "csv"
            ? "text/" + extension
            : ImageExtension.indexOf(extension) >= 0
              ? "image/" + extension
              : VideoExtension.indexOf(extension) >= 0
                ? "video/" + extension
                : "application/" + extension;
        let presignedHeader = {
          method: "PUT",
          headers: {
            // "x-amz-acl": "public-read",
            "content-type": ContentType,
            defaultrole: props.TenantInfo.UserGroup,
            groupmenuname: groupMenuName,
            menuid: menuId,
          },
          body: file,
        };

        let finalStatus = await APIGatewayPutRequest(
          fetchURL,
          headers,
          presignedHeader
        );
        if (finalStatus[0] != "Success") {

          setFileValues({
            ...fileValues,
            TextName: "Select File",
            FilePath: "",
          });
          setValue("File", "Error", { shouldValidate: true });
          return;
        } else {
          setValue("File", "exist", { shouldValidate: true });
          setFileValues({
            ...fileValues,
            TextName: file.name,
            FilePath: finalStatus[1],
          });
          // setFilePath(FinalStatus[1]);
        }
      }
    };
    csvReader.readAsText(file);
  }
  useEffect(() => {
    if (props.open == 1) {
      clearForm();
    }
  }, [clearForm, props.open]);

  const uploadHandler = async () => {

    setValue("submit", true);

    if (fileValues.FilePath == null) {
      setValue("File", "false", { shouldValidate: true });
      setValue("submit", false);
      return;
    }

    let fetchUrl;
    if (props.NavigateMode == "ModuleDirect") {
      fetchUrl =
        process.env.ACTIVITY_LANG_UNSAVED_TO_SAVED +
        `?CourseID=${props.CourseID}&ActivityType=${props.ActivityType}&CourseType=Module&ModuleID=${props.ModuleID}&ActivityID=${props.ActivityID}&ManagementType=CourseManagement&Type=QuizQuestionTemplate&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&ActivityType=${props.ActivityType}`;
    } else {
      fetchUrl =
        process.env.ACTIVITY_LANG_UNSAVED_TO_SAVED +
        `?ActivityID=${props.ActivityID}&Type=QuizQuestionTemplate&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&ActivityType=${props.ActivityType}`;
    }


    let langFileUpload = "{";
    langFileUpload +=
      '"' + watch("ddlLanguage") + '":"' + fileValues.TextName + '"';
    langFileUpload += "}";

    let groupMenuName =!props.TrainingID? (props.NavigateMode == "ModuleDirect" ? "CourseManagement" : "ActivityManagement"): "TrainingManagement";
    let menuId =!props.TrainingID?( props.NavigateMode == "ModuleDirect" ? "300200" : "500005"):"400401"

    let presignedHeader = {
      method: "POST",
      body: langFileUpload,
      headers: {
        authorizationtoken:
          props.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: groupMenuName,
        menuid: menuId,
      },
    };
    let finalStatus = await APIGatewayGetRequest(fetchUrl, presignedHeader);
    let finalFileResponse = await finalStatus?.res?.text();
    let filePathDate = props.NavigateMode == "ModuleDirect" ? finalFileResponse && JSON?.parse(finalFileResponse)?.[0]?.FilePath.split("/")?.[8] : finalFileResponse && JSON?.parse(finalFileResponse)?.[0]?.FilePath.split("/")?.[7];
    let language = finalFileResponse && JSON?.parse(finalFileResponse)?.[0]?.Language;
    let finalFileName = finalFileResponse && JSON?.parse(finalFileResponse)?.[0]?.FileName;
    let stateMachineArn = process.env.STEP_FUNCTION_ARN_QUIZ_TEMPLATE_UPLOAD;

    let convertUrl = process.env.APIGATEWAY_URL_QUIZ_TEMPLATE_UPLOAD + `?S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}&S3BucketName=${props.TenantInfo.BucketName}`;

    let activityJsonSaveData = '{' + '"TenantId":  "' + props.TenantInfo.TenantID + '", "Filename": "' + finalFileName + '","ActivityID": "' + props.ActivityID + '", "BucketName":"' + props.TenantInfo.BucketName + '","CourseID":"' + "" + '","TrainingID":"' +  "" + '","TrainingName":"' +  "" + '","RootFolder":"' + props.TenantInfo.RootFolder + '" ,"Language":"' + language  + '" ,"CreatedDate":"' + new Date() + '" ,"CreatedBy":"' + props.user.username + '" ,"LastModifiedDate":"' + new Date() + '" ,"LastModifiedBy":"' + props.user.username+ '","ModuleID":"' + "" + '" }';
    let trainingmanagementSaveData ='{' + '"TenantId":  "' + props.TenantInfo.TenantID + '", "Filename": "' + finalFileName + '","ActivityID": "' + props.ActivityID + '", "BucketName":"' + props.TenantInfo.BucketName + '","CourseID":"' + "" + '","TrainingID":"' +  props.TrainingID + '","TrainingName":"' +  props.TrainingName + '","RootFolder":"' + props.TenantInfo.RootFolder + '" ,"Language":"' + language  + '" ,"CreatedDate":"' + new Date() + '" ,"CreatedBy":"' + props.user.username + '" ,"LastModifiedDate":"' + new Date() + '" ,"LastModifiedBy":"' + props.user.username+ '","ModuleID":"' + "" + '" }';
    let courseJsonSaveData = '{' + '"TenantId":  "' + props.TenantInfo.TenantID + '", "Filename": "' + finalFileName + '","ActivityID": "' + props.ActivityID + '", "BucketName":"' + props.TenantInfo.BucketName + '","CourseID":"' + props.CourseID + '","TrainingID":"' +  "" + '","TrainingName":"' +  "" + '","RootFolder":"' + props.TenantInfo.RootFolder + '" ,"Language":"' + language  + '" ,"CreatedDate":"' + new Date() + '" ,"CreatedBy":"' + props.user.username + '" ,"LastModifiedDate":"' + new Date() + '" ,"LastModifiedBy":"' + props.user.username+ '","ModuleID":"' + props.ModuleID + '" }';

    let jsonSaveData = !props.TrainingID ? (props.NavigateMode == "ModuleDirect" ? courseJsonSaveData : activityJsonSaveData ): trainingmanagementSaveData

    let headersDetail = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken:
          props.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: groupMenuName,
        menuid: menuId,
        statemachinearn: stateMachineArn,
      },
      body: jsonSaveData,
    };
    let finalResult = await APIGatewayPostRequest(convertUrl, headersDetail);
    props.FinalResponse(finalResult.Status, "popup", props.NavigateMode);
    setValue("submit", false);
    clearForm();
  };

  useEffect(() => {
    setValue("ddlLanguage", "en");
    setFileValues({ TextName: "Select File", FilePath: null });
  }, [clearForm, props.open, setValue]);

  return (
    <Container>
      <form onSubmit={handleSubmit(uploadHandler)} id="Formjs">
        <div className="flex gap-2">
          {" "}
          <div className="pl-28">
            <NVLSelectField
              id="ddlLanguage"
              errors={errors}
              register={register}
              options={language}
              className="nvl-Def-Input"
            />

            <NVLFileUpload
              id="getFile"
              text={
                fileValues.TextName == null
                  ? "Select File"
                  : fileValues.TextName
              }
              accept={`${"Acceptable file format: .csv<br>File size should not exceed more than 50KB"}`}
              ButtonType="success"
              onChange={(e) => fileValidation(e)}
            ></NVLFileUpload>
            <NVLLoader
              className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"
                }`}
              id="loader"
            />
            <div
              className={
                "Center-Aligned-Items {invalid-feedback} text-red-500 text-sm "
              }
            >
              {errors?.File?.message}
            </div>

            <NVLlabel text="Max File Size: 5mb" />
            <NVLlabel text="File type: .csv" />
            <div className="flex gap-1 pt-2 pl-24">
              <NVLButton
                text={!watch("submit")
                  ? "Upload" : ""}
                type={"submit"}
                disabled={
                  watch("File") == "Uploading" || watch("submit") ? true : false
                }
                className={
                  props.ButtonClassName
                    ? props.ButtonClassName
                    : `w-24 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""
                    }`
                }
                ButtonType="success"
              >
                {watch("submit") && (
                  <i className="fa fa-circle-notch fa-spin mr-2"> </i>
                )}
              </NVLButton>
              <NVLButton
                disabled={
                  watch("File") == "Uploading" || watch("submit") ? true : false
                }
                id="btnCancel"
                text={"Clear"}
                type="button"
                className="w-24 nvl-button"
                onClick={() => clearForm()}
              ></NVLButton>
            </div>
          </div>
          <div className="my-12">
            <NVLButton
              text={"Download"}
              type={"button"}
              className="bg-primary nvl-button rounded-2xl text-white"
              onClick={(e) => downloadCsvFile(e)}
            />
          </div>{" "}
        </div>
      </form>
    </Container>
  );
}

export default UploadQuestion;
