import ResizeModule from "@Controls/NVLRichTextImageResize";
import 'quill/dist/quill.bubble.css';
import 'quill/dist/quill.snow.css';
import { useCallback, useEffect, useMemo, useRef } from "react";
import { useQuill } from "react-quilljs";
export default function NVLMultiRichTextBox(props) {

    let fonts = useMemo(() => { return process.env.QUILLEDITORFONT }, []);
    // generate code friendly names
    const getFontName = useCallback((font) => {
        let cssFont = font.toLowerCase().replace(/\s/g, "-");
        if (cssFont == "times-new-roman")
            return cssFont.replace("times-new-roman", "Times");
        else
            return cssFont;
    }, []);

    let fontNames = useMemo(() => { let lfontValue = fonts?.map(font => getFontName(font)); lfontValue.push(false); return lfontValue }, [fonts, getFontName]);

    // add fonts to style
    let fontStyles = "";
    fonts?.forEach(function (font) {
        let fontName = getFontName(font);
        fontStyles += ".ql-snow .ql-picker.ql-font .ql-picker-label[data-value=" + fontName + "]::before, .ql-snow .ql-picker.ql-font .ql-picker-item[data-value=" + fontName + "]::before {" +
            "content: '" + font + "';" +
            "font-family: '" + font + "', sans-serif;" +
            "}" +
            ".ql-font-" + fontName + "{" +
            " font-family: '" + font + "', sans-serif;" +
            "}.ql-snow .ql-picker{height:auto !important}";
    });

    let node = document?.createElement('style');
    node.innerHTML = fontStyles;
    document?.body?.appendChild(node);

    let video;
    const modules = useMemo(() => {
        return {
            toolbar: {
                container: [["bold", "italic", "underline"], [{ indent: "-1" }, { indent: "+1" }], [{ size: ["small", false, "large", "huge"] }], ["undo", "redo"], [{ color: [] }], [{ font: fontNames }], [{ align: [] }], ['video'], ["link", "image"]],
                handlers: {
                    undo: undoChange,
                    redo: redoChange,
                    video: () => {
                        showVideoUploadModal();
                    }
                },
            },
            resize: {},
            history: {
                delay: 1000,
                maxStack: 500,
            },
        }
    }, [fontNames]);
    const file = useRef(null)

    function showVideoUploadModal() {
        file.current.click();
    }
    const theme = "snow";
    const formats = ["header", "font", "size", "bold", "italic", "underline", "align", "strike", "script", "blockquote", "background", "list", "bullet", "indent", "link", "image", "video", "color", "code-block"];
    const { quill, quillRef, Quill } = useQuill({ modules, formats, theme });
    if (Quill && !quill) {
        Quill.register("modules/resize", ResizeModule);
        video = Quill.import("formats/video");
        class CoustumViedo extends video {
            static create(value) {
                const node = super.create();
                if (value != undefined) {
                    const temp = document.createElement("video");
                    temp.setAttribute('controls', true);
                    temp.setAttribute('type', "video/mp4");
                    temp.setAttribute('src', value);
                    node.appendChild(temp)
                }
                return node;
            }
        }
        CoustumViedo.blotName = "video";
        CoustumViedo.className = "ql-video";
        CoustumViedo.tagName = "DIV";
        Quill.register("formats/video", CoustumViedo)
        let icons = Quill.import("ui/icons");
        icons["undo"] = `<i class="fa-solid fa-rotate-left"></i>`;
        icons["redo"] = `<i class="fa-solid fa-rotate-right"></i>`;

        let Font = Quill.import('formats/font');
        Font.whitelist = fontNames;
        Quill.register(Font, true);
    }
    const getBase64 = file => {
        return new Promise(resolve => {
            let baseURL = "";
            let reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => {
                baseURL = reader.result;
                resolve(baseURL);
            };
        });
    };

    useEffect(() => {
        props.forwardedRef.current[props.index].ref = quill;
        if (props.forwardedRef.current[props.index].contents != "" && quill != undefined && quill.root.innerHTML == "<p><br></p>") {
            quill.root.innerHTML = props.forwardedRef.current[props.index].contents;
        }
        if (quill != "" && quill != undefined) {
            quill.on("text-change", () => {
                if (quill.root.innerHTML == "" || quill.root.innerHTML.replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0)
                    props.setValue("RichTextBox", "Change", { shouldValidate: true })
                else if (props.watch("RichTextBox") == 'TEXT' || props.watch("RichTextBox") == "LANGTEXT")
                    props.setValue("RichTextBox", "Change", { shouldValidate: true })
            });
            quill?.clipboard?.addMatcher('span', preserveSizeFormat);
        }    
    }, [quill, props.index, props.forwardedRef, props])

    function preserveSizeFormat(node, delta) {
        const match = node.className.match(/ql-size-(.*)/)
        const fmatch = node.className.match(/ql-font-(.*)/)
        const fontSize = node.style['font-size']
        const fontFamily = node.style['font-family']
        const styleMatch = fontSize && fontSize !== '16px'
        
        delta.map(function (op) {
          if (!op.attributes) {
            op.attributes = {}
          }
          if (match) {
            op.attributes.size = match[1]
          }
          else if (styleMatch) {
            const large = fontSize === '19.5px' || fontSize === '1.5rem'
            op.attributes.size = (large ? 'large' : ((large ? 'huge' : (fontSize == '0.75rem' || fontSize == "9.75px") ? "small" : "")))
          }
          if (fmatch) {
            op.attributes.font = fmatch[1]
          } else {
            op.attributes.font = fontFamily
          }
          return op
        })
        return delta
      }
      
    function undoChange() {
        this.quill.history.undo();
    }
    function redoChange() {
        this.quill.history.redo();
    }
    async function handleViedo(e) {
        const range = quill.getSelection(true);
        let tempvideo = await getBase64(e.target.files[0]);
        quill.insertEmbed(range.index, "video", tempvideo, 'user');
        quill.setSelection(range.index + 1);
        quill.focus();
    }
    return (
        <>
            <div>
                <div ref={quillRef}>
                </div>
                <input type="file" style={{ display: 'none' }} ref={file} onChange={(e) => handleViedo(e)} />
            </div>
        </>);

}
