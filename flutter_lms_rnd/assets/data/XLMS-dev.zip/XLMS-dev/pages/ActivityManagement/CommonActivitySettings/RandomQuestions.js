import Container from '@components/Container/Container';
import NVLAlert, { ModalOpen } from '@components/Controls/NVLAlert';
import NVLButton from '@components/Controls/NVLButton';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLSelectField from '@components/Controls/NVLSelectField';
import NVLTextbox from '@components/Controls/NVLTextBox';
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { createXlmsCourseQuizTemplate, createXlmsQuizTemplate, createXlmsTrainingQuizTemplate } from 'src/graphql/mutations';
import { listXlmsActivityManagementInfos, listXlmsCourseModule, listXlmsCourseQuizTemplate, listXlmsQuizTemplate, listXlmsTrainingManagementActivityInfos, listXlmsTrainingQuizTemplateInfos } from 'src/graphql/queries';
import * as Yup from "yup";

function RandomQuestions(props) {

  const [eachQuestionBankData, setEachQuestionBankData] = useState()
  const router = useRouter();
  const [dropDownState, setDropdownstate] = useState("")
  const trainingID = useRef();
  const [fetchdata, setFetchdata] = useState();
  const [modalValues, setModalValues] = useState({
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Questions have been added successfully.",
    ModalOnClickEvent: () => {
      if (fetchdata?.mode == "ModuleDirect") {
        if (router.query["ZoomActivityID"] != undefined) {
          router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
        } else {
          router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}`);
        }
      } else if (props?.mode == "TrainingDirect") {
        if (router.query["Root"] = "TemplateList") {
          router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Settings=QuizList&Root=TemplateList`);
        } else {
          router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Settings=QuizList`);
        }
      } else {
        if (router.query["ZoomActivityID"] != undefined) {
          router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
        } else {
          router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}`);
        }
      }
    }
  });
  useEffect(() => {
    async function fetchData() {
      let courseId = router.query["CourseID"];
      let mode = router.query["Mode"];
      let moduleId = router.query["ModuleID"];
      let activityId = router.query["ActivityID"];
      let activityType = router.query["ActivityType"];
      let query = mode == "ModuleDirect" ? listXlmsCourseModule : props?.mode == "TrainingDirect" ? listXlmsTrainingManagementActivityInfos : listXlmsActivityManagementInfos
      let sk = mode == "ModuleDirect" ? "COURSEID#" + courseId + "#MODULEID#" : props?.mode == "TrainingDirect" ? "TRAINING#" : "ACTIVITYTYPE#Quiz"
      let variables = props?.mode == "TrainingDirect" ? { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: sk, Type: "ActiveList", IsSuspend: false, IsDeleted: false } : { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: sk, IsDeleted: false }
      let response = await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
      let quizActivities = mode == "ModuleDirect" ? response?.res?.listXlmsCourseModule?.items : props?.mode == "TrainingDirect" ? response?.res?.listXlmsTrainingManagementActivityInfos?.items : response?.res?.listXlmsActivityManagementInfos?.items
      setFetchdata({
        QuizActivities: quizActivities != undefined ? quizActivities : [],
        ActivityID: activityId,
        ActivityType: activityType,
        mode: mode,
        CourseID: mode == "ModuleDirect" && courseId,
        ModuleID: mode == "ModuleDirect" && moduleId


      })
    }
    fetchData();
    return (() => {
      setFetchdata((temp) => { return { ...temp } })
    })
  }, [props?.TenantInfo?.TenantID, props?.mode, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const finalResponse = (finalStatus, ModalType) => {
    if (finalStatus != "Success") {
      setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus, });
      ModalOpen();
      return;
    } else {
      setValue("submit", "");

      setModalValues({
        ModalInfo: "Success",
        ModalBottomMessage: "Questions have been added successfully",
        ModalOnClickEvent: () => {
          if (fetchdata?.mode == "ModuleDirect") {
            if (router.query["ZoomActivityID"] != undefined) {
              router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
            } else {
              router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}`);
            }
          } else if (props?.mode == "TrainingDirect") {
            router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Settings=QuizList`);
          } else {
            if (router.query["ZoomActivityID"] != undefined) {
              router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
            } else {
              router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}`);
            }
          }
        }
      });
      ModalOpen();
    }
  };
  const questionBank = useMemo(() => {
    let list = [{ value: "", text: "Select" }]
    if (fetchdata?.QuizActivities != undefined) {
      fetchdata?.QuizActivities.forEach((item) => {
        if (item?.ActivityType == "Quiz") {
          if (item.ActivityID != router?.query["ActivityID"]) {
            list.push({ value: item.ActivityID, text: item.ActivityName })
          }
        }
      })
    }
    return list;
  }, [fetchdata?.QuizActivities, router?.query]);

  const getTrainingID = useCallback((e) => {
    fetchdata?.QuizActivities.map((item) => {
      if (e == item.ActivityID) {
        return trainingID.current = item.SK.split("#")[1]
      }
    })
  }, [fetchdata?.QuizActivities])
  const validationSchema = Yup.object().shape({
    ddlQuestionBank: Yup.string().required("Choose a question bank").nullable().test("test", "", async (e) => {
      if (e != dropDownState) {
        setDropdownstate(e);
        setValue("txtNoOfQuestions", "")
      }
      getTrainingID(e);
      let query = fetchdata?.mode == "ModuleDirect" ? listXlmsCourseQuizTemplate : props?.mode == "TrainingDirect" ? listXlmsTrainingQuizTemplateInfos : listXlmsQuizTemplate;
      let moduleId = e?.toString()?.substring(0, 6);
      let sk = fetchdata?.mode == "ModuleDirect" ? "COURSE#" + fetchdata?.CourseID + "#MODULE#" + moduleId + "#ACTIVITYID#" + e  : props?.mode == "TrainingDirect" ? "TRAINING#" + trainingID.current + "#ACTIVITYID#" + e + "#LANGUAGE#" : "ACTIVITYID#" + e + "#LANGUAGE#"
      let quizActivities = await AppsyncDBconnection(query, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: sk }, props.user.signInUserSession.accessToken.jwtToken);
      let questionData = fetchdata?.mode == "ModuleDirect" ? quizActivities.res?.listXlmsCourseQuizTemplate?.items : props?.mode == "TrainingDirect" ? quizActivities.res?.listXlmsTrainingQuizTemplateInfos?.items : quizActivities.res?.listXlmsQuizTemplate?.items
      setEachQuestionBankData(questionData)
      return true
    }),
    txtNoOfQuestions: Yup.string().required("Enter number of questions").nullable()
      .test("Exist check", "", (e, { createError }) => {
        if (e > eachQuestionBankData?.length) {
          return createError({ message: `Question bank contains only ${eachQuestionBankData?.length} questions` })
        }
        return true
      })
  })

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, watch, formState } = useForm(formOptions);
  const { errors } = formState;
  const submitHandler = async (data) => {
    document?.activeElement?.blur();
    setValue("submit", true);
    const randomIndex = [];
    let i;
    for (eachQuestionBankData, i = parseInt(data.txtNoOfQuestions); i--;) {
      randomIndex.push(eachQuestionBankData.splice(Math.floor(Math.random() * (i + 1)), 1)[0]);
    }

    let randomQuestions = [...new Map(randomIndex?.map(item => [item?.["SK"], item])).values()]
    let variable;
    let questionBankName = document.getElementById("ddlQuestionBank")?.options[document.getElementById("ddlQuestionBank")?.selectedIndex]?.text
    let randomised = [];

    const RemoveNull = (obj) => {
      let tempjson = {};
      obj && Object.keys(obj).forEach((k) => {
        if (obj?.[k] != undefined) {
          tempjson = { ...tempjson, [k]: obj?.[k] }
        }
      });
      return tempjson;
    }

    randomQuestions.forEach((item, idx) => {
      let existData = RemoveNull(item)
      let sk = fetchdata?.mode == "ModuleDirect" ? "COURSE#" + fetchdata?.CourseID + "#MODULE#" + fetchdata?.ModuleID + "#ACTIVITYID#" + fetchdata?.ActivityID + "#LANGUAGE#" + existData.Language + "#QUESTION#" + existData.QuestionID : props?.mode == "TrainingDirect" ? "TRAINING#" + props?.TrainingId + "#ACTIVITYID#" + props?.ActivityID + "#LANGUAGE#" + existData.Language + "#QUESTION#" + existData.QuestionID : "ACTIVITYID#" + fetchdata?.ActivityID + "#LANGUAGE#" + existData.Language + "#QUESTION#" + existData.QuestionID
      randomised.push({ ...existData, SK: sk, IsRandomQuestion: true, QuestionBank: questionBankName, QuestionBankID: watch("ddlQuestionBank"), IsConsume: false })
    })
    // variable = { input: [...randomised] };
    let queryparam = fetchdata?.mode == "ModuleDirect" ? createXlmsCourseQuizTemplate : props?.mode == "TrainingDirect" ? createXlmsTrainingQuizTemplate : createXlmsQuizTemplate
    while (randomised.length > 25) {
      let tempArray = randomised.splice(0, 25);
      AppsyncDBconnection(queryparam, { input: tempArray }, props.user.signInUserSession.accessToken.jwtToken);
    }
    let finalStatus = (await AppsyncDBconnection(queryparam, { input: randomised }, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
    finalResponse(finalStatus)
    setValue("submit", false);
  }


  let pageRoutes = [];
  if (fetchdata?.mode == "ModuleEdit" || fetchdata?.mode == "ModuleDirect") {
    if (router.query["ZoomActivityID"] != undefined) {
      pageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${fetchdata.CourseID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${fetchdata.CourseID}&ModuleID=${fetchdata.ModuleID}&ModuleName=${fetchdata?.Editdata?.ModuleName}`, breadcrumb: "Edit Activity Zoom" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom&CourseID=${fetchdata.CourseID}&ModuleID=${fetchdata.ModuleID}`, breadcrumb: "Edit Settings Zoom" },
        { path: `/CourseManagement/ModuleInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata.CourseID}&ModuleID=${fetchdata.ModuleID}&ModuleName=${fetchdata.EditData?.ModuleName}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata.CourseID}&ModuleID=${fetchdata?.ModuleID}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
        { path: `/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Question" },
        { path: "", breadcrumb: "Random Question" }
      ];
    } else {
      pageRoutes = [
        { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
        { path: `/CourseManagement/ModulesList?CourseID=${fetchdata?.CourseID}`, breadcrumb: "Manage Course" },
        { path: `/CourseManagement/ModuleInfo?Mode=ModuleEdit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}&ModuleName=${fetchdata?.Editdata?.ModuleName}`, breadcrumb: "Edit Activity" },
        { path: `/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}`, breadcrumb: "Edit Settings" },
        { path: `/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}`, breadcrumb: "Question" },
        { path: "", breadcrumb: "Random Question" }
      ];
    }
  } else if (props?.mode == "TrainingDirect") {
    if (router.query["Root"] == "TemplateList") {
      pageRoutes = [
        { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}`, breadcrumb: "Training Template List" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Root=TemplateList`, breadcrumb: "Edit Activity" },
        { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Root=TemplateList`, breadcrumb: "Edit Settings" },
        { path: `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList&Root=TemplateList`, breadcrumb: "Question" },
        { path: "", breadcrumb: "Random Question" }
      ];
    }
    else {
      pageRoutes = [
        { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: `/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}`, breadcrumb: "Edit Activity" },
        { path: `/TrainingManagement/TrainingActivitySettings?Mode=TrainingEdit&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&`, breadcrumb: "Edit Settings" },
        { path: `/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=Quiz&TrainingID=${props?.TrainingId}&AssessmentType=${props?.AssessmentType}&TrainingName=${props?.TrainingName}&Settings=QuizList`, breadcrumb: "Question" },
        { path: "", breadcrumb: "Random Question" }
      ];
    }
  } else {
    if (router.query["ZoomActivityID"] != undefined) {
      if (!router.query["NavigationMode"]) {
        pageRoutes = [
          { path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
          { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ZoomActivityID"]}&ActivityType=Zoom`, breadcrumb: "Edit Settings Zoom" },
          { path: `/ActivityManagement/ActivityInfo?Mode=${router.query["ZoomMode"]}&ZoomActivityID=${router.query["ZoomActivityID"]}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Edit Activity" },
          { path: `/ActivityManagement/EditActivitySettings?Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Settings" },
          { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`, breadcrumb: "Question" },
          { path: "", breadcrumb: "Random Question" }
        ];
      } else {
        pageRoutes = [
          { path: `/ActivityManagement/CommonActivitySettings/ZoomWiseActivityList?ActivityID=${router.query["ZoomActivityID"]}`, breadcrumb: "Activity Management" },
          { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["ZoomMode"]}`, breadcrumb: "Edit Activity" },
          { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&ZoomActivityMode=${router.query["ZoomMode"]}&NavigationMode=${router.query["NavigationMode"]}`, breadcrumb: "Edit Settings" },
          { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&NavigationMode=${router.query["NavigationMode"]}`, breadcrumb: "Question" },
          { path: "", breadcrumb: "Random Question" }
        ];
      }
    } else {
      pageRoutes = [
        { path: "/ActivityManagement/ActivityList", breadcrumb: fetchdata?.mode == "ModuleDirect" ? "Course Management" : "Activity Management" },
        { path: `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}`, breadcrumb: "Edit Activity" },
        { path: `/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}`, breadcrumb: "Edit Settings" },
        { path: `/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}`, breadcrumb: "Question" },
        { path: "", breadcrumb: "Random Question" }
      ];
    }
  }
  return (
    <>
      <Container PageRoutes={pageRoutes} loader={fetchdata?.QuizActivities == undefined}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(submitHandler)} id="RandomForm">
          <div className="nvl-FormContent my-8">
            <NVLSelectField id="ddlQuestionBank" labelText="Select Question Bank" labelClassName="nvl-Def-Label" errors={errors} register={register} options={questionBank} className="nvl-Def-Input nvl-mandatory" />
            <NVLlabel text={`Available Questions: ${eachQuestionBankData ? Object.values(eachQuestionBankData)?.length : "0"}`} className={"nvl-Def-Label pb-2"} />
            <NVLTextbox id="txtNoOfQuestions" type="number" title="Number of Questions" className="nvl-mandatory" errors={errors} register={register} />
          </div>
          <div id="buttons" className={`justify-center flex p-4`}>
            <div className="flex gap-2">
              <NVLButton id="btnAdd" text={!watch("submit") ? "Add" : ""} disabled={watch("submit") ? true : false} type="submit" className={watch("submit") ? "w-24 nvl-button-success text-white" : " w-24 nvl-button-success text-white"}> {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
              <NVLButton
                text="Cancel"
                className="w-24 nvl-button"
                type={"button"}
                onClick={() => {
                  if (fetchdata?.mode == "ModuleDirect") {
                    if (router.query["ZoomActivityID"] != undefined) {
                      router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}`);
                    } else {
                      router.push(`/CourseManagement/QuestionList?Mode=ModuleDirect&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&CourseID=${fetchdata?.CourseID}&ModuleID=${fetchdata?.ModuleID}`);
                    }
                  } else if (props?.mode == "TrainingDirect") {
                    router.push(`/TrainingManagement/QuizCommonSettings?Mode=TrainingDirect&ActivityID=${props?.ActivityID}&ActivityType=${props?.ActivityType}&TrainingID=${props?.TrainingId}&TrainingName=${props?.TrainingName}&AssessmentType=${props?.AssessmentType}&Settings=QuizList`);
                  } else {
                    if (router.query["ZoomActivityID"] != undefined) {
                      router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}&ZoomActivityID=${router.query["ZoomActivityID"]}&ZoomMode=${router.query["ZoomMode"]}&ZoomActivityName=${router.query["ZoomActivityName"]}&${router.query["NavigationMode"] ? `NavigationMode=${router.query["NavigationMode"]}` : ""}`)
                    } else {
                      router.push(`/ActivityManagement/CommonActivitySettings/QuestionList?Mode=Edit&ActivityID=${fetchdata?.ActivityID}&ActivityType=${fetchdata?.ActivityType}`);
                    }
                  }
                }
                }
              />
            </div>
          </div>
        </form>
      </Container>
    </>
  )
}

export default RandomQuestions
