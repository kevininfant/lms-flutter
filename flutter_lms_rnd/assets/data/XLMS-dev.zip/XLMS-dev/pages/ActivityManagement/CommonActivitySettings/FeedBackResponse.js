import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsActivityUserInfo, getXlmsCourseActivityUserInfo, listXlmsActivityEnrollUser, listXlmsCourseBatchWiseDismissUserList } from "src/graphql/queries";
import * as Yup from "yup";

function FeedBackResponse(props) {
    const validationSchema = Yup.object().shape({
        btndownload: Yup.string().nullable(),
        ddlSearch: Yup.string()

    })
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true, };
    const { register, handleSubmit, reset, formState, setFocus, watch, setValue } = useForm(formOptions);
    const { errors } = formState;
    const query = useMemo(() => {
        return props.mode == "Edit" ? listXlmsActivityEnrollUser : listXlmsCourseBatchWiseDismissUserList;
    }, [props.mode])
    const queryName = useMemo(() => {
        return props.mode == "Edit" ? "listXlmsActivityEnrollUser" : "listXlmsCourseBatchWiseDismissUserList";
    }, [props.mode])

    const dropdownData = useMemo(() => {
        let batchlist = [{ value: "Select", text: "Select" }]
        if (props?.mode == "ModuleEdit") {
            props?.BatchData?.map((batch) => {
                batchlist.push({ value: batch.BatchID, text: batch.BatchName });

            });
        }
        return batchlist
    }, [props.BatchData, props.mode])
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [userDataRef, setUserDataRef] = useState("");
    const [disableDownload,setDisable] = useState(true)
    const [responseData,setResponseData] = useState([])

    const headerColumn = useMemo(() => {
        let Header = [{ HeaderName: "SI.No", Columnvalue: "Serialnumber", HeaderCss: "w-1/12" },
        { HeaderName: "Participant Name", Columnvalue: "UserName", HeaderCss: "w-1/12" },];
        props.questions && Object.values(props.questions)?.forEach((item) => {
            Header.push({ HeaderName: item.Question, Columnvalue: item.Question, HeaderCss: "w-3/12" })
        })
        return Header;
    }, [props.questions])

    const [search, setSearch] = useState("")

    useEffect(()=>{
        async function fetch(){
            let variable = props.mode == "Edit" ? {
                GsiPK: "ACTIVITYID#" + props.ActivityID,
                GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#"
            } : { GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + props.CourseActivityID, GsiSK: "BATCH#" };
    
            const responseData = await AppsyncDBconnection(query,variable, props.user.signInUserSession.accessToken.jwtToken)
            const responses = props.mode == "Edit" ? responseData.res?.listXlmsActivityEnrollUser?.items : (props?.mode == "ModuleEdit") ? responseData.res?.listXlmsCourseBatchWiseDismissUserList?.items : []
           
            let enrolledData;
            responses && responses.forEach(getitem => {
            if (props.mode == "Edit") {
                enrolledData = { ...enrolledData, [getitem?.UserSub]: JSON.parse(getitem?.QuestionandOptions) }
            } else {
                let optionData = getitem && JSON?.parse(getitem?.QuestionandOptions)
                optionData && Object?.values(optionData)?.map((QuestionandOptions) => {
                    enrolledData = { ...enrolledData, [getitem?.UserSub]: QuestionandOptions }
                })
            }
        });
            setResponseData(enrolledData ? enrolledData : {})
        }
        fetch()
        return setDisable((data)=> {return data})   
    },[props.ActivityID, props.CourseActivityID, props.TenantInfo.TenantID, props.mode, props.user.signInUserSession.accessToken.jwtToken, query])

    const searchBoxVal = (e) => {
        setSearch(e);
        if (e == "") {
            setSearch("");
            setUserDataRef("")
        }
        setIsRefreshing((count) => {
            return count + 1;
        });
    }
    const refreshGrid = async () => {
        setSearch("");
        setUserDataRef("")
        setIsRefreshing((count) => {
            return count + 1;
        });
    };
    const response = useRef();

    const getSearchValue = useCallback((getItem, UserResponse) => {
        let SearchData;
        SearchData = UserResponse && UserResponse?.filter((y) => { return y.UserName == search })
        SearchData && SearchData.map((itm) => {
            setUserDataRef(itm.UserSub)
        })
        return
    }, [search])

    const gridDataBind = useCallback(async (viewData) => {
        setDisable((Object.entries(responseData).length == 0 && (viewData && viewData?.length == 0 )) ? true : false);
        const rowGrid = [];
        let enrolledData;
        let userinfo = [];
        viewData.forEach(getitem => {
            if (props.mode == "Edit") {
                enrolledData = { ...enrolledData, [getitem?.UserSub]: JSON.parse(getitem?.QuestionandOptions) }
            } else {
                let optionData = getitem && JSON?.parse(getitem?.QuestionandOptions)
                optionData && Object?.values(optionData)?.map((QuestionandOptions) => {
                    enrolledData = { ...enrolledData, [getitem?.UserSub]: QuestionandOptions }
                })
            }
        });

        async function getUserData(userinfo) {
            let query = props.mode == "Edit" ? getXlmsActivityUserInfo : getXlmsCourseActivityUserInfo;
            enrolledData && Object.keys(enrolledData).forEach((items) => {
                userinfo.push("#USERINFO#" + items)
            })
            if (userinfo.length != 0) {
                let IsUserData = await AppsyncDBconnection(query, {
                    PK: "TENANT#" + props.TenantInfo.TenantID,
                    SK: userinfo,
                }, props.user.signInUserSession.accessToken.jwtToken);
                return IsUserData
            }
        }
        let resUserInfo = await getUserData(userinfo);
        let userResponse = props.mode == "Edit" ? resUserInfo?.res?.getXlmsActivityUserInfo : resUserInfo?.res?.getXlmsCourseActivityUserInfo;
        let headerQuestionLimt = 5;
        userResponse &&
            userResponse.map((getItem, index) => {
                let enrollerDt = getItem && enrolledData[getItem?.UserSub]
                if (search == getItem.UserName) {
                    getSearchValue(getItem, userResponse)
                }
                let ans = [];
                props.questions && Object.keys(props.questions).map((x) => {
                    let val = enrollerDt && Object.values(enrollerDt).filter((y) => { return y.Question == x })
                    ans = { ...ans, [x]: (val?.[0]?.["UserFeedBack"] == undefined ? "-" : JSON.stringify(val?.[0]?.["UserFeedBack"])) };
                    if (val?.[0]?.["UserFeedBack"] != undefined) {
                        response.current = true;
                    }
                })
                response.current == true &&
                    rowGrid.push({
                        Serialnumber: <NVLlabel id={"txtnumber" + index + 1} text={index + 1}></NVLlabel>,
                        UserName: <NVLlabel id={"txtname" + index + 1} text={getItem.UserName}></NVLlabel>,
                        ...ans
                    })
            })
        return rowGrid;
    }, [responseData, props.mode, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, props.questions, search, getSearchValue])

    const fileDownload = useCallback(async (e) => {
        setValue("download", true)
        if (e?.type == "click") {
            let fileName = "Feedback Report.csv"
            let activityJson = '{' + '"TenantID": "' + props.TenantInfo.TenantID + '","ActivityID":"' + props?.pageData?.ActivityID + '", "ActivityType":"' + props?.pageData.ActivityType + '", "FileName": "' + fileName + '", "Type": "' + "Activity" + '", "BucketName": "' + props.TenantInfo.BucketName + '", "RootFolder": "' + props.TenantInfo.RootFolder + '" }'
            let courseJson = '{' + '"TenantID": "' + props.TenantInfo.TenantID + '","ActivityID":"' + props?.pageData?.ActivityID + '", "ActivityType":"' + props?.pageData.ActivityType + '","CourseID":"' + props?.pageData.CourseActivityID + '", "ModuleID":"' + props?.pageData?.ModuleId + '","BatchID":"' + watch("ddlSearch") + '","FileName": "' + fileName + '", "Type": "' + "Course" + '", "BucketName": "' + props.TenantInfo.BucketName + '", "RootFolder": "' + props.TenantInfo.RootFolder + '" }'
            let ssondata = props?.pageData.mode == "Edit" ? activityJson : courseJson
            let lstrPresignedFileURL = process.env.APIGATEWAY_FEEDBACK_REPORT_DOWNLOAD_URL;
            let headers = { method: "POST", headers: { authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken, }, body: ssondata, };
            let lstrFileDwnld = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
            var win = window.open(await lstrFileDwnld.res?.text(), "_self");
        }
        setValue("download", false)
    }, [props.TenantInfo.BucketName, props.TenantInfo.RootFolder, props.TenantInfo.TenantID, props?.pageData?.ActivityID, props?.pageData.ActivityType, props?.pageData.CourseActivityID, props?.pageData?.ModuleId, props?.pageData.mode, props?.user.signInUserSession.accessToken.jwtToken, setValue, watch]);
    const Responses = useCallback((props) => {
        let variable = props.mode == "Edit" ? {
            GsiPK: "ACTIVITYID#" + props.ActivityID,
            GsiSK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#ENROLLUSER#"
        } : { GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + props.CourseActivityID, GsiSK: "BATCH#" + props.watch("ddlSearch") };

        return (
            <>
                <div className={`pl-6 pt-4 ${(props.mode == "Edit" || props.mode == "TrainingEdit" )? "hidden" : ""}`}>
                    <NVLlabel text="Batch Name" className="nvl-Def-Label" />
                    <NVLSelectField id="ddlSearch" className="w-72" errors={props.errors} register={props.register} disabled={props.mode == "Edit" ? true : false} options={props.dropdownData} />
                </div>
                <NVLHeader IsSearch={disableDownload ? false : true} IsNestedHeader SearchonChange={(e) => searchBoxVal(e)} placeholder={"Search by User name"} onClick1={refreshGrid} />
                {props.user != undefined && <NVLGridTable Search={userDataRef} refershPage={isRefreshing} id="tblResponseList"
                    HeaderColumn={headerColumn} GridDataBind={gridDataBind}
                    query={props.query} querryName={props.queryName} variable={variable} user={props?.user} />}
            </>
        )
    }, [disableDownload, gridDataBind, headerColumn, isRefreshing, userDataRef])


    return (
        <>
            <div className="pt-4 px-6 flex gap-4">
                <NVLButton id="btndownload" type={"button"} text={`${watch("download") ? "" : "Download as csv"}`} className={`${disableDownload ? "Disabled !text-gray-400" : "" } inline-flex justify-center rounded-md border border-transparent bg-green-600 py-2 px-4 text-sm font-medium text-white shadow-sm hover:bg-green-800 focus:outline-none focus:ring-2 focus:bg-green-600 focus:ring-offset-2 ${watch("download") ? "w-44 h-8" : ""}`} onClick={(e) => fileDownload(e)}>
                    <i className={`${watch("download") ? " fa fa-circle-notch fa-spin mr-2" : " fa-solid fa-download pt-1 px-2 text-md"}  `}></i>
                </NVLButton>
            </div>
            <Responses mode={props.mode} watch={watch} errors={errors} register={register} dropdownData={dropdownData} query={query} queryName={queryName} TenantInfo={props.TenantInfo} ActivityID={props.ActivityID} CourseActivityID={props.CourseActivityID} user={props.user} />
        </>
    );
}

export default FeedBackResponse;
