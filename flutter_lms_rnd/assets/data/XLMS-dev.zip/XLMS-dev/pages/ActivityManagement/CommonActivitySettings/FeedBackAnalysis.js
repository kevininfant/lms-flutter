import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingIndicator from "@components/Controls/NVLLoadingIndicator";
import NVLNoImage from "@components/Controls/NVLNoImage";
import { yupResolver } from "@hookform/resolvers/yup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Bar } from "react-chartjs-2";
import { useForm } from "react-hook-form";
import { listXlmsActivityEnrollUser, listXlmsCourseBatchInfos, listXlmsCourseBatchWiseDismissUserList } from "src/graphql/queries";
import * as Yup from "yup";

Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);


function FeedBackAnalysis(props) {
    const [resData, setResData] = useState()
    const [responseCount, setResponse] = useState()
    const [dropDownChange, setDropDown] = useState({})

    useEffect(() => {
        const fetch = async () => {
            const headers = {
                "Content-Type": "application/text",
                menuid: props.pageData?.CM_Mode == "ModuleDirect" || props.pageData?.CM_Mode == "ModuleEdit" ? "118001" : "118000",
                tenantid: props.pageData?.Editdata?.TenantID,
                courseid: props.pageData.CourseActivityID,
                authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
            };
            const feedbackReport = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: headers,
                body: (props.pageData?.CM_Mode == "ModuleDirect" || props.pageData?.CM_Mode == "ModuleEdit") ? props.pageData.Editdata?.ActivityID : `WHERE  activitytype='Feedback' and tenantid='${props.pageData?.Editdata?.TenantID}' and activityid='${props.pageData.ActivityID}'`,
            });
            const tempJSON = await feedbackReport?.res?.text();
            const tempQuesResponse = tempJSON && JSON.parse(JSON.parse(tempJSON).State);

            let variable = props.pageData?.CM_Mode == "Edit" ? {
                GsiPK: "ACTIVITYID#" + props.pageData?.ActivityID,
                GsiSK: "TENANT#" + props.pageData?.Editdata?.TenantID + "#ACTIVITY#ENROLLUSER#"
            } : { GsiPK: "TENANT#" + props.pageData?.Editdata?.TenantID + "#COURSEID#" + props.pageData?.CourseActivityID, GsiSK: "BATCH#" }
            const query = props.pageData?.CM_Mode == "Edit" ? listXlmsActivityEnrollUser : listXlmsCourseBatchWiseDismissUserList
            const submissionData = await AppsyncDBconnection(query, variable, props?.user.signInUserSession.accessToken.jwtToken)
            const UserSubmissionCount = props.pageData?.CM_Mode == "Edit" ? submissionData.res?.listXlmsActivityEnrollUser?.items : submissionData.res?.listXlmsCourseBatchWiseDismissUserList?.items
            const Count = UserSubmissionCount && UserSubmissionCount.filter((feedback) => { return feedback.QuestionandOptions != null && feedback })

            if (props.pageData?.CM_Mode == "Edit") {
                setResData({
                    ResponseData: tempQuesResponse,
                    EnrolledUser: Count
                });
            } else if(props.pageData?.CM_Mode == "ModuleDirect" || props.pageData?.CM_Mode == "ModuleEdit"){
                const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + props.pageData?.Editdata?.TenantID + "#COURSEINFO#" + props.pageData.CourseActivityID, SK: "COURSEBATCH#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
                const SortedBatch = batchData.res?.listXlmsCourseBatchInfos?.items.sort((a, b) => { return b.CreatedDate.localeCompare(a.CreatedDate) })
                let batchFilter, userFilter;
                let NewArray = batchData.res?.listXlmsCourseBatchInfos.items.reduce((a, b) => {
                    return new Date(a.CreatedDate) > new Date(b.CreatedDate) ? a : b;
                });
                batchFilter = tempQuesResponse?.filter((data) => { return data.batchid == NewArray?.BatchID })
                userFilter = Count?.filter((data) => { return data.BatchID == NewArray?.BatchID })
                setResData({
                    BatchData: SortedBatch,
                    ResponseData: batchFilter,
                    ReResponseData: tempQuesResponse,
                    EnrolledUser: userFilter
                });
            } else {
                setResData({
                    ResponseData: {},
                    EnrolledUser: {}
                });
            }

        };
        if (Object.keys(props.Question)?.length > 0) {
            fetch();
        }
        return (() => {
            setResData((data) => { return { ...data } });
        })
    }, [props]);

    const getResponse = useCallback(async (batchId) => {
        setValue("dropdown2", batchId)
        let variable = { GsiPK: "TENANT#" + props.pageData?.Editdata?.TenantID + "#COURSEID#" + props.pageData?.CourseActivityID, GsiSK: "BATCH#" + batchId };

        const query = listXlmsCourseBatchWiseDismissUserList
        const submissionData = await AppsyncDBconnection(query, variable, props?.user.signInUserSession.accessToken.jwtToken)
        const UserSubmissionCount = submissionData.res?.listXlmsCourseBatchWiseDismissUserList?.items
        const Count = UserSubmissionCount && UserSubmissionCount.filter((feedback) => { return feedback.QuestionandOptions != null && feedback })
        let batchFilter = resData?.ReResponseData?.filter((data) => {
            return data.batchid == batchId
        })
        let userFilter = Count?.filter((data) => { return data.BatchID == batchId })

        const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + props.pageData?.Editdata?.TenantID + "#COURSEINFO#" + props.pageData.CourseActivityID, SK: "COURSEBATCH#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const SortedBatch = batchData.res?.listXlmsCourseBatchInfos?.items.sort((a, b) => { return b.CreatedDate.localeCompare(a.CreatedDate) })
        setResData({
            ResponseData: batchFilter,
            BatchData: SortedBatch,
            ReResponseData: resData?.ReResponseData,
            EnrolledUser: userFilter
        });
    }, [props.pageData.CourseActivityID, props.pageData?.Editdata?.TenantID, props?.user.signInUserSession.accessToken.jwtToken, resData?.ReResponseData, setValue])

    const validationSchema = Yup.object().shape({
        dropdown2: props.pageData?.CM_Mode != "Edit" && Yup.string().test((e) => {
            if (dropDownChange?.Batch != e && e!= undefined) {
                setDropDown((data) => { return { ...data, Batch: e } })
                getResponse(e)
            }
            return true
        }).nullable(),
        dropdown3: Yup.string().test((e) => {
            if (dropDownChange?.Language != e && e!= undefined) {
                setDropDown((data) => { return { ...data, Language: e } })
            }
            return true
        }).nullable()
    })
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, watch, formState, setValue } = useForm(formOptions);
    const { errors } = formState;

    const batchList = useMemo(() => {
        let listData = [{ value: "", text: "Select Batch" }]
        if (resData?.BatchData != undefined) {
            resData?.BatchData?.length > 0 && resData?.BatchData.map((getItem) => {
                listData.push({ value: getItem.BatchID, text: getItem.BatchName })
            })
            listData = listData?.filter((data) => { return data.value != "" && data })
        }
        return listData;
    }, [resData?.BatchData])

    const LanguageList = useMemo(()=>{
        let ArrayList =[{ value: "", text: "Select Language" }], List=[];
        props?.Question && Object.values(props?.Question)?.forEach((getItem,idx)=>{
        props?.languageType.forEach((data)=>{ 
                if (data.value == getItem.Language) {
                    List.push(data)
                }
            })
        })
        function getUniqueListBy(List, key) {
            return [...new Map(List.map(item => [item[key], item])).values()]
        }
        let UniqueList = getUniqueListBy(List,"value")
        ArrayList = UniqueList?.filter((data) => { return data.value != "" && data })
        setDropDown((data)=> {return {...data, Language: ArrayList[0]?.value}})
        return ArrayList
    },[props.Question, props?.languageType])

    const feedbackReportInput = useMemo(() => {
        let attempt = {}, UserCount = []

        resData?.ResponseData?.length > 0 && resData?.ResponseData?.map((data) => {
            UserCount = [...UserCount, (data?.UserAttemptCount)]
            attempt = { ...attempt, [data?.Question]: parseInt(data?.UserAttemptCount) };
        });

        const tempviewData = props.Question != undefined && Object.values(props.sortusingpostion(props.Question))?.filter((data) => { return data.Language == dropDownChange?.Language && data });
        setResponse(tempviewData.length)

        let noOfQuestion = [], QuestionNo = [];
        tempviewData && tempviewData.map((getItem, index) => {
            QuestionNo = [...QuestionNo, (getItem?.Question?.replace(/(<([^>]+)>)/gi, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ").replace(/(.{150})/g, '$1\n'))]
            noOfQuestion = [...noOfQuestion, attempt?.[getItem?.Question] != undefined ? attempt?.[getItem?.Question] : 0];
        });
        let ChartData = [{
            label: "User submissions",
            data: noOfQuestion,
            barPercentage: 1.0,
            borderWidth: 1,
            backgroundColor: "rgba(75,192,192,1)",
            borderColor: "rgba(0,0,0,1)",
            fill: true,
            tension: 0.5,
            barThickness: 30,
            minPointLength: 0
        }]
        return { labels: QuestionNo, datasets: ChartData }
    }, [dropDownChange?.Language, props, resData?.ResponseData])

    return (
        <>
            <div className="pl-4">
                <div className="pt-4">
                    <NVLlabel text={`Total Submisssions : ${props.pageData.Editdata?.TotalCount == undefined || props.pageData.Editdata?.TotalCount == "NaN" ? 0 : props.pageData.Editdata?.TotalCount}`} className="font-bold" />
                    <div id="divOverView">
                        <NVLlabel text={`Questions : ${props.Question ? Object.keys(props.Question)?.length : 0}`} className="font-bold" />
                    </div>
                </div>
                {(props?.pageData?.Editdata?.IsAnalysisPage && Object.keys(props.Question)?.length > 0) &&
                    <div>
                        <div className="-translate-y-10">
                        <NVLHeader
                            isDropdownRequired2={true} isDropdownRequired3={true} DropdownData2={batchList} DropdownData3={LanguageList}
                            dropdownclass2={(props.pageData?.CM_Mode == "Edit" || props.pageData?.CM_Mode == "TrainingEdit") ? "invisible" : resData == undefined ? "Disabled w-60" : ""}
                            dropdownclass3={resData == undefined ? "Disabled" : ""}
                            IsDropdownDisable2={resData == undefined ? true : false}
                            IsDropdownDisable3={resData == undefined ? true : false}
                            IsNestedHeader register={register} errors={errors} />
                            </div>
                        {
                            ((resData?.ResponseData != undefined) ?
                                <>
                                   <div className={`${props.pageData?.CM_Mode != "Edit" && watch("dropdown2") == "" ? "hidden" : "pt-8"}`}>
                                        <Bar data={feedbackReportInput}
                                            options={
                                                {
                                                    cutoutPercentage: 90,
                                                    responsive: true,
                                                    aspectRatio: 3,
                                                    plugins: {
                                                        legend: {
                                                            display: false,
                                                        },
                                                        tooltip: {
                                                            intersect: false,
                                                        },
                                                    },
                                                    scales: {
                                                        x: {
                                                            grid: {
                                                                display: false,
                                                            },
                                                            ticks: {
                                                                callback: function (index) {
                                                                    return "Q." + (index + 1)
                                                                },
                                                            }
                                                        },
                                                        y: {
                                                            max: props.pageData.Editdata?.TotalCount && props.pageData.Editdata?.TotalCount > 100 ? props.pageData.Editdata?.TotalCount : 100,
                                                            min: 0,
                                                            ticks: {
                                                                stepSize: props.pageData.Editdata?.TotalCount && props.pageData.Editdata?.TotalCount > 100 ? 5 : 10,
                                                                beginAtZero: true,
                                                                display: true
                                                            }
                                                        }
                                                    },
                                                }}
                                        />
                                    </div> 
                                </> :
                                (resData == undefined && Object.keys(props.Question)?.length > 0) &&
                                <div>
                                    <NVLLoadingIndicator IsLoad={true} />
                                </div>)
                        }
                    </div>}
                {(props?.pageData?.Editdata?.IsAnalysisPage && Object.keys(props.Question)?.length == 0) &&
                    <div className="pt-4" >
                        <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />
                    </div>}
            </div>
        </>);
}
export default FeedBackAnalysis;