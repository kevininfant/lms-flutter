import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo, updateXlmsActivityManagementInfo, updateXlmsCourseModule, updateXlmsTrainingManagementActivityInfo } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function FeedBackQuestion(props) {
    const [message, setMessage] = useState("");
    const ddlchange = useRef();


    function clearFields() {
        setValue("txtQuestion", "")
        setValue("IsMultiChoicetype", "")
        setHTMLContents("", message);
        setValue("IsAdjustment", "")
        setValue("txtShortQuestion", "")
        setValue("txtInfoQuestion", "")
        setValue("txtShortAnsLabel", "")
        setValue("ddlInfoType", "")
        setValue("rboption", false)
        setValue("chkLine", "")
        setValue("txtMultiple", "")
        setValue("txtInfoLabel", "")
        reset({}, { keepValues: true, keepDirty: true });
    }
    const validationSchema = Yup.object().shape({

        ddlLanguage: Yup.string().test("clearFieldsWhileSwitch", "", (e) => {

            if (ddlchange.current != undefined) {
                if (e != ddlchange?.current?.ddlLanguage && ((e != "")) || (e == "" && ddlchange?.current.ddlLanguage != undefined)) {
                    ddlchange.current.ddlLanguage = e;
                    clearFields()
                }
            }
            return true;
        }),
        ddlType: Yup.string()
            .required("Select a Type")
            .test("QuestionType_Handler", "", (e) => {
                if (ddlchange.current != undefined) {
                    if (e != ddlchange?.current?.ddlType && ((e != "")) || (e == "" && ddlchange?.current.ddlType != undefined)) {
                        ddlchange.current.ddlType = e;
                        clearFields();
                    }
                }
                return true;
            }),
        rboption: Yup.string().nullable(),
        txtQuestion: Yup.string().when("ddlType", {
            is: "Multiple Choice",
            then: Yup.string()
                .typeError("Question is required")
                .nullable()
                .required("Question is required").test("", "", (e, { createError }) => {
                    if (e?.trim() == "") {
                        return createError({ message: "Question is required" })
                    }
                    if (e != undefined) {
                        ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice" };
                    }
                    return true;
                }),
            otherwise: Yup.string().when("ddlType", {
                is: "Multiple Choice(rated)",
                then: Yup.string()
                    .typeError("Question is required")
                    .nullable()
                    .required("Question is required").test("", "", (e, { createError }) => {
                        if (e?.trim() == "") {
                            return createError({ message: "Question is required" })
                        }
                        if (e != undefined) {
                            ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice(rated)" };

                        }
                        return true;
                    }),
            }),
        }),

        txtMultiple: Yup.string().when("ddlType", {
            is: "Multiple Choice",
            then: Yup.string().typeError("Multiple choice value is required")
                .nullable()
                .required("Multiple choice value is required").test("", "", (e, { createError }) => {
                    if (e?.trim() == "") {
                        return createError({ message: "Multiple choice value is required" })
                    }
                    if (e != undefined) {
                        ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice" };
                    }
                    return true;
                }),
            otherwise: Yup.string().when("ddlType", {
                is: "Multiple Choice(rated)",
                then: Yup.string().typeError("Multiple choice value is required")
                    .test("Number", "Numbers only allowed", (e) => {
                        const isHasString = /[^0-9,\s]/gi
                        if (isHasString.test(e)) {
                            return false;
                        }
                        return true;
                    })
                    .required("Multiple choice value is required")
                    .test("", "Duplicate number not allowed", (e) => {
                        const ranking = e?.includes(",") ? e?.split(',')?.map(Number) : e?.trim()?.split('\n').map(Number)
                        const repeatedNumber = new Set();

                        for (const num of ranking) {
                            if (repeatedNumber?.has(num)) {
                                return false;
                            }
                            repeatedNumber?.add(num);
                        }
                        return true
                    })
                    .test("", "", (e, { createError }) => {
                        if (e?.trim() == "") {
                            return createError({ message: "Multiple choice value is required" })
                        }
                        if (e != undefined) {
                            ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice(rated)" };
                        }
                        return true;
                    }).nullable(),
            }),

        }),

        IsMultiChoicetype: Yup.string().when("ddlType", {
            is: "Multiple Choice",
            then: Yup.string().nullable().required("Multiple choice Type is required").test("", "", (e) => {
                if (e != undefined) {
                    ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice" };
                }
                if (e == "Dropdown") {
                    clearErrors(["IsAdjustment"])
                }
                return true;
            }),
            otherwise: Yup.string().nullable()
            .when("ddlType", {
                is: "Multiple Choice(rated)",
                then: Yup.string().nullable().required("Multiple choice Type is required").test("", "", (e) => {
                    if (e != undefined) {
                        ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice(rated)" };
                    }
                    if (e == "Dropdown") {
                        clearErrors(["IsAdjustment"])
                    }
                    return true;
                })
            }),
        }),

        IsAdjustment: Yup.string().nullable().when("ddlType", {
            is: "Multiple Choice",
            then: Yup.string().nullable().when("IsMultiChoicetype", {
                is: "Dropdown",
                then: Yup.string().nullable(),
                otherwise: Yup.string().nullable().required("Adjustment is required").test("", "", (e) => {
                    if (e != undefined) {
                        ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice" };
                    }
                    return true;
                }
                ),
            }),
            otherwise: Yup.string().nullable().when("ddlType", {
                is: "Multiple Choice(rated)",
                then: Yup.string().nullable().when("IsMultiChoicetype", {
                    is: "Dropdown",
                    then: Yup.string().nullable(),
                    otherwise: Yup.string().nullable().required("Adjustment is required").test("", "", (e) => {
                        if (e != undefined) {
                            ddlchange.current = { ...ddlchange.current, ddlType: "Multiple Choice(rated)" };
                        }
                        return true;
                    }
                    ),
                }),
            }),
        }),
        txtShortQuestion: Yup.string().when("ddlType", {
            is: "Short Answer",
            then: Yup.string().typeError("Question is required").nullable().required("Question is required").test("", "", (e, { createError }) => {
                if (e?.trim() == "") {
                    return createError({ message: "Question is required" })
                }
                if (e != undefined) {
                    ddlchange.current = { ...ddlchange.current, ddlType: "Short Answer" };
                }
                return true;
            }),
            otherwise: Yup.string().nullable(),
        }),

        txtInfoQuestion: Yup.string().when("ddlType", {
            is: "Information",
            then: Yup.string().typeError("Question is required").nullable().required("Question is required").test("", "", (e, { createError }) => {
                if (e?.trim() == "") {
                    return createError({ message: "Question is required" })
                }
                if (e != undefined) {
                    ddlchange.current = { ...ddlchange.current, ddlType: "Information" };
                }
                return true;
            }),
            otherwise: Yup.string().nullable()
        }),

        ddlInfoType: Yup.string().when("ddlType", {
            is: "Information",
            then: Yup.string().typeError("Information type is required").nullable().required("Information type is required").test("", "", (e) => {
                if (e != undefined) {
                    ddlchange.current = { ...ddlchange.current, ddlType: "Information" };
                }
                return true;
            }),
        }),

        RichTextBox: Yup.string().when("ddlType", {
            is: "Label",
            then: Yup.string().test("", "Label description is required", (e, { createError }) => {
                let finalState=false;
                message?.editor?.delta?.ops.map((item) => {
                    if (item?.insert?.image!=undefined) finalState =true;
                })
                if (finalState) return createError({ message: "In Valid" })
                
                if (e != "") {
                    ddlchange.current = { ...ddlchange.current, ddlType: "Label" };
                }
                if (message?.editor.delta.ops[0]["insert"]?.replaceAll(/(<([^>]+)>)/gi, "re")?.trim().length == 0 || getContents(message)?.replaceAll(/(<([^>]+)>)/gi, "")?.length == 0) {
                    document.getElementById("desc_errors").classList.remove("hidden");
                    return false;
                } else {
                    document.getElementById("desc_errors").classList.add("hidden");
                    return true;
                }
            }).nullable(),
            otherwise: Yup.string().nullable()
        }),


    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true, };
    const { register, handleSubmit, setValue, reset, setFocus, setError, watch, formState, clearErrors } = useForm(formOptions);
    const { errors } = formState;


    useEffect(() => {
        if (message != "") {
            message?.on("text-change", () => {
                if (getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {
                    setValue("RichTextBox", "Empty", { shouldValidate: true });
                } else {
                    setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
                }
                setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
            });
        }
        setValue("rbTemplateAction", "Delete");
    }, [setValue, message]);

    useEffect(() => {
        setValue("ddlLanguage", "en");
        setValue("ddlInfoType", "")
    }, [setValue]);

    const dragItem = useRef(null);
    const dragOverItem = useRef(null);
    const [questions, setQuestions] = useState({});
    const [editQuestion, setEditQuestion] = useState(undefined);

    const UpdateQuestion = useMemo(() => {
        return props.UpdateQuestion;
    }, [props.UpdateQuestion])

    useEffect(() => {
        if (Object.keys(questions).length != 0) {
            UpdateQuestion(questions)
        }
    }, [UpdateQuestion, questions])

    useMemo(() => {
        setEditQuestion(undefined);
        setValue("ddlLanguage", "en", { shouldValidate: true });
        setValue("ddlInfoType", "")
    }, [setValue])

    useEffect(() => {
        setQuestions(() => {
            return props.Question;
        });
    }, [props.Question])

    useEffect(() => {
        if (editQuestion != undefined) {
            setFocus("ddlLanguage")
        }

    }, [editQuestion, setFocus])


    const resetValues = useCallback((message) => {
        setValue("txtQuestion", "")
        setValue("IsMultiChoicetype", "")
        setHTMLContents("", message);
        setValue("IsAdjustment", "")
        setValue("txtShortQuestion", "")
        setValue("txtInfoQuestion", "")
        setValue("txtShortAnsLabel", "")
        setValue("ddlInfoType", "")
        setValue("rboption", false)
        setValue("chkLine", "")
        setValue("txtMultiple", "")
        setValue("txtInfoLabel", "")
    }, [setValue]);

    const QuestionsData = useCallback((props) => {
        const getOptionData = (Options) => {
            let optionsData = [];
            for (let i = 0; i < Options?.length; i++) {
                optionsData?.push({ value: Options[i], text: Options[i] });
            }
            return optionsData;
        };
        const editQuestions = (reset, setValue, question, options, Type, Adjustment, AddQuestionType, Label, InfoType, Labeltxt, UseoneLine, Language) => {
            reset({ txtQuestion: "", txtShortQuestion: "", txtInfoQuestion: "", txtMultiple: "", IsMultiChoicetype: "", IsAdjustment: "", txtShortAnsLabel: "", ddlInfoType: "", chkLine: "", txtAddQuestions: "", });
            setEditQuestion(question);

            AddQuestionType == "Multiple Choice" ? setValue("txtQuestion", question) :
                AddQuestionType == "Short Answer" ? setValue("txtShortQuestion", question) :
                    AddQuestionType == "Information" ? setValue("txtInfoQuestion", question) : "";
            AddQuestionType == "Multiple Choice(rated)" ? setValue("txtQuestion", question) : "";
            AddQuestionType == "Short Answer" ? setValue("txtShortAnsLabel", Label) : AddQuestionType == "Information" ? setValue("txtInfoLabel", Label) : "";
            setValue("IsMultiChoicetype", Type, {});
            setValue("ddlInfoType", InfoType);
            setValue("txtMultiple", options?.toString());
            setValue("IsAdjustment", Adjustment);
            setValue("chkLine", UseoneLine);
            setValue("ddlLanguage", Language);
            setValue("ddlType", AddQuestionType);
            ddlchange.current = { ddlType: AddQuestionType, ddlLanguage: Language }
            if (props.message != "") {
                setHTMLContents(Labeltxt, props.message);
                props.message?.history?.clear();
            }

        };
        const deleteQuestions = (item,) => {
            let questions = props.questions;
            delete questions?.[item];
            props.handleSort(questions, setQuestions, dragItem, dragOverItem);
            let mode = props.CM_Mode, courseId = props.CourseActivityID, moduleID = props.ModuleId, pk = "TENANT#" + props.TenantInfo.TenantID, sk;
            if (mode == "ModuleEdit") {
                sk = "COURSEID#" + courseId + "#MODULEID#" + moduleID + "#ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID
            } else if (mode == "Edit" && (props.router.query["ZoomActivityID"] != undefined)) {
                sk = "ACTIVITYTYPE#" + props.ActivityType + "#ZOOM#" + props.router.query["ZoomActivityID"] + "#" + props.router.query["ZoomMode"] + "#ACTIVITYID#" + props.ActivityID
            } else if (props?.PageData?.CM_Mode == "TrainingEdit") {
                sk = props?.PageData?.Editdata?.SK;
            } else {
                sk = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
            }
            let questionVariables = { input: { PK: pk, SK: sk, QuestionandOptions: JSON.stringify(questions), }, },
                query = mode == "ModuleEdit" ? updateXlmsCourseModule : props?.PageData?.CM_Mode == "TrainingEdit" ? updateXlmsTrainingManagementActivityInfo : updateXlmsActivityManagementInfo,
                variables = questionVariables;
            AppsyncDBconnection(query, variables, props?.user.signInUserSession.accessToken.jwtToken);
            props.setValue("ddlType", "Select");
            props.setValue("ddlLanguage", "en");
            resetValues(props?.message);
        }
        return (
            <>
                <div className="list-container">
                    {Array.from(props.sortusingpostion(props.questions)).map((item, index) => {
                        return (
                            <>
                                {Object.keys(props.questions) != "undefined" && (
                                    <div key={index} className="" draggable onDragStart={(e) => (dragItem.current = index)} onDragEnter={(e) => (dragOverItem.current = index)} onDragEnd={() => props.handleSort(props.questions, setQuestions, dragItem, dragOverItem)} onDragOver={(e) => e.preventDefault()}>
                                        <div className="p-2 w-full">
                                            <div className="pt-2 grid gap-4">
                                                <div className="w-full break-all flex gap-4">
                                                    {item?.Question != undefined && (<NVLlabel showFull text={index + 1 + "." + "  " + item.Label + " " + item?.Question?.replace(/(<([^>]+)>)/gi, "")} />)}
                                                    <i className="fa-solid fa-pencil text-tiny text-emerald-600 " onClick={() => editQuestions(props.reset, props.setValue, item?.Question, item?.Options, item?.OptionType, item?.Adjustment, item?.AddQuestionType, item?.Label, item?.InformationType, item?.LabelText, item?.UseoneLine, item?.Language)} />
                                                    <i className="fa fa-trash-o text-rose-700 text-tiny" onClick={() => deleteQuestions(item?.Question)} />
                                                </div>
                                                <div className="flex gap-4">
                                                    <div className={`${item?.Adjustment == "Horizontal" ? "flex gap-4" : ""} `} key={index}>
                                                        {item?.OptionType == "Multiple Answer" ? (
                                                            item?.Options.map((item, index) => {
                                                                return (
                                                                    <>
                                                                        <div className="gap-3">
                                                                            <NVLCheckbox id={"chkoption" + index} text={item} value={"Multiple Answer"} errors={props.errors} register={props.register}></NVLCheckbox>
                                                                        </div>
                                                                    </>
                                                                );
                                                            })
                                                        ) : item?.OptionType == "Single Answer" ? (
                                                            item?.Options.map((radioItem, index) => {
                                                                return (
                                                                    <>
                                                                        <div className="gap-3" key={index}>
                                                                            <NVLRadio id={"rboption" + index} text={radioItem} name={"rbOptions" + item?.Question} value={item} errors={props.errors} register={props.register}></NVLRadio>
                                                                        </div>
                                                                    </>
                                                                );
                                                            })
                                                        ) : item?.OptionType == "Dropdown" ? (
                                                            <>
                                                                <div className="gap-3" key={index}>

                                                                    <NVLSelectField id={"ddloption" + index} options={getOptionData(item.Options)} className="nvl-Def-Input" errors={props.errors} register={props.register} />
                                                                </div>
                                                            </>
                                                        ) : item?.AddQuestionType == "Short Answer" ? (
                                                            <>
                                                                <div className="gap-3" key={index}>
                                                                    <NVLMultilineTxtbox id={"txtShortOption" + index} className="nvl-Def-Input resize-y" errors={props.errors} register={props.register} />
                                                                </div>
                                                            </>
                                                        ) : item?.AddQuestionType == "Information" ? (
                                                            <>
                                                                <div className="gap-3" key={index}>
                                                                    <NVLlabel id={"lblInfoType" + index} text={item.InformationType} className="font-bold" />
                                                                </div>
                                                            </>
                                                        ) : (
                                                            <></>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </>
                        );
                    })}
                </div>
            </>
        );
    }, [resetValues]);

    const submitHandler = async (data, editQuestion, temp, setValue) => {
        let question = data?.txtQuestion || data?.txtShortQuestion || data?.txtInfoQuestion, Label = data?.txtShortAnsLabel || data?.txtInfoLabel, splitOperatior = data?.chkLine == true ? "," : "\n", options = data?.txtMultiple?.trim().split(splitOperatior);
        let quesAns = temp, Position = temp && Object.keys(temp).length;

        let questions = getContents(message) || question, 
         existQuestion = quesAns && Object.keys(quesAns)
        let questionFound = existQuestion?.some((question) => question?.toLowerCase() == questions?.toLowerCase() && (questions?.toLowerCase() != editQuestion?.toLowerCase()));
        if (questionFound) {
            setValue("ddlType", "Select")
            setError("ddlType", { message: "Question already exists" })
            resetValues()
            return false;
        }
        else {
            if (editQuestion != undefined) {
                Position = quesAns?.[editQuestion]?.Position;
                delete quesAns?.[editQuestion];
            }
            if (data?.txtMultiple != undefined) {
                options = options.filter((item) => item.trim() != "");
            }

            quesAns = {
                ...quesAns,
                [data?.ddlType == "Label" ? getContents(message) : question]: { Question: data?.ddlType == "Label" ? getContents(message) : question, Options: options, Label: Label, AddQuestionType: data?.ddlType, LabelText: getContents(message), OptionType: data?.IsMultiChoicetype, Adjustment: data?.IsAdjustment, IsUseOneLineAnswer: data?.chkLine, InformationType: data?.ddlInfoType, UseoneLine: data?.chkLine, Position: Position, Language: data?.ddlLanguage, },
            };
            let mode = props.pageData.CM_Mode, courseId = props.pageData.CourseActivityID, moduleId = props.pageData.ModuleId, pk = "TENANT#" + props.TenantInfo.TenantID, sk;
            if (mode == "ModuleEdit") {
                sk = "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + props.pageData.ActivityType + "#ACTIVITYID#" + props.pageData.ActivityID
            } else if (mode == "Edit" && (props.router.query["ZoomActivityID"] != undefined)) {
                sk = "ACTIVITYTYPE#" + props.pageData.ActivityType + "#ZOOM#" + props.router.query["ZoomActivityID"] + "#" + props.router.query["ZoomMode"] + "#ACTIVITYID#" + props.pageData.ActivityID
            } else if (props?.pageData?.mode == "TrainingEdit") {
                sk = "TRAINING#" + props?.pageData?.TrainingID + "#ACTIVITYTYPE#" + props.pageData.ActivityType + "#ACTIVITYID#" + props?.pageData?.ActivityID
            } else {
                sk = "ACTIVITYTYPE#" + props.pageData.ActivityType + "#ACTIVITYID#" + props.pageData.ActivityID;
            }
            let questionVariables, finalStatus;

            if (props?.pageData?.mode == "TrainingEdit") {
                questionVariables = {
                    input: {
                        PK: pk, SK: sk,
                        ActivityID: props.pageData.ActivityID,
                        TenantID: props.TenantInfo.TenantID,
                        AddQuestionType: data?.ddlType,
                        QuestionandOptions: JSON.stringify(quesAns),
                    },
                }

            } else {
                questionVariables = { input: { PK: pk, SK: sk, ActivityID: props.pageData.ActivityID, TenantID: props.TenantInfo.TenantID, AddQuestionType: data?.ddlType, QuestionandOptions: JSON.stringify(quesAns), }, };
            }

            if (mode == "ModuleEdit") {
                finalStatus = (await AppsyncDBconnection(updateXlmsCourseModule, questionVariables, props?.user.signInUserSession.accessToken.jwtToken));
            }
            else {
                if (props?.pageData?.mode == "TrainingEdit") {

                    finalStatus = (await AppsyncDBconnection(updateXlmsTrainingManagementActivityInfo, questionVariables, props?.user.signInUserSession.accessToken.jwtToken));

                } else {
                    finalStatus = (await AppsyncDBconnection(updateXlmsActivityManagementInfo, questionVariables, props?.user.signInUserSession.accessToken.jwtToken));
                }

            }


            if (finalStatus.Status == "Success") {
                props.finalResponse(finalStatus.Status);
                resetData("clear");
                setQuestions(quesAns);
                let Query = (props?.pageData?.CM_Mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
                if (props?.pageData?.Editdata?.Shard != null || props?.pageData?.Editdata?.Shard != "") {
                    for (let i = 1; i <= props?.pageData?.Editdata?.Shard; i++) {
                        UpdateBatch({ UpdateData: props?.pageData?.Editdata, inn: { ...questionVariables.input }, props: props, pk: "TENANT#" + props.pageData?.Editdata.TenantID + "#" + i, query: Query });
                    }
                }
            }
            else {
                props.finalResponse(finalStatus.Status)
            }
            reset();
        }

    }

    const resetData = useCallback((mode) => {
        reset({ txtQuestion: "", txtShortQuestion: "", txtInfoQuestion: "", txtMultiple: "", IsMultiChoicetype: "", IsAdjustment: "", txtShortAnsLabel: "", txtInfoLabel: "", ddlInfoType: "", chkLine: "", txtAddQuestions: "", ddlLanguage: "en" });
        if (message != "") { setHTMLContents("", message); }
        setEditQuestion(() => {
            return undefined;
        })
        setValue("content-target", "");
        setValue("ddlTemplate", "")
        if (mode == "clear") {
            setValue("ddlType", "Select");
            setValue("ddlLanguage", "en");
        }
    }, [message, reset, setValue]);

    const FeedBackQuestion = useCallback((props) => {

        const questionType = [
            { value: "Select", text: "Select" },
            { value: "Multiple Choice", text: "Multiple Choice" },
            { value: "Multiple Choice(rated)", text: "Multiple Choice(rated)" },
            { value: "Label", text: "Label" },
            { value: "Short Answer", text: "Short Answer" },
            // { value: "Information", text: "Information" },
        ];
        const informationType = [
            { value: "", text: "Select" },
            { value: "Course", text: "Course" },
            { value: "Category", text: "Course Category" },
        ];
        return (
            <div className="nvl-FormContent !h-fit">
                <form onSubmit={props.handleSubmit((data) => props.submitHandler(data, props.editQuestion, props.questions, props.setValue, props?.mode))} id="Formjs">
                    <NVLSelectField id="ddlLanguage" labelText="Select Language" labelClassName="font-bold" className="nvl-Def-Input nvl-non-mandatory" options={props.languageType} title="Select Template" errors={props.errors} register={props.register}></NVLSelectField>
                    <NVLSelectField id="ddlType" labelText="Add Question" labelClassName="font-bold" className="nvl-Def-Input nvl-mandatory" options={questionType} title="Select Template" errors={props.errors} register={props.register}></NVLSelectField>
                    <div className={`${props.watch("ddlType") == "Multiple Choice" || props?.watch("ddlType") == "Multiple Choice(rated)" ? "" : "hidden"}`} id="divMultiChoice">

                        <div className="Center-Aligned-Items">
                            <NVLMultilineTxtbox id="txtQuestion" labelText="Question" labelClassName="font-bold" className="nvl-Def-Input nvl-mandatory" title="Question" errors={props.errors} register={props.register}></NVLMultilineTxtbox>
                        </div>
                        <div className="Center-Aligned-Items pt-3">
                            <NVLlabel text="Multiple Choice Type" className="font-bold"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <div className="Center-Aligned-Items flex gap-7">
                                <NVLRadio id="IsMultiChoicetype" text="Single Answer" name="IsMultiChoicetype" value={"Single Answer"} errors={props.errors} register={props.register}></NVLRadio>
                                {props?.watch("ddlType") == "Multiple Choice" && <NVLRadio id="IsMultiChoicetype" text="Multiple Answer" name="IsMultiChoicetype" value={"Multiple Answer"} errors={props.errors} register={props.register}></NVLRadio>}
                                <NVLRadio id="IsMultiChoicetype" text="Dropdown" name="IsMultiChoicetype" defaultChecked value={"Dropdown"} errors={props.errors} register={props.register}></NVLRadio>
                            </div>
                            <div className={" {invalid-feedback} text-red-500 text-sm "}>
                                {props.errors?.IsMultiChoicetype?.message}
                            </div>
                        </div>
                        <div className={`Left-Aligned-Items font-bold pt-5 ${props.watch("IsMultiChoicetype") == "Dropdown" ? "hidden" : ""}`}>
                            <NVLlabel text="Adjustment"><span className="text-red-500 text-lg">*</span></NVLlabel>
                        </div>
                        <div className={`Center-Aligned-Items flex gap-12 ${props.watch("IsMultiChoicetype") == "Dropdown" ? "hidden" : ""}`}>
                            <NVLRadio id="IsAdjustment" text="Horizontal" name="IsAdjustment" value={"Horizontal"} errors={props.errors} register={props.register} required></NVLRadio>
                            <NVLRadio id="IsAdjustment" text="Vertical" name="IsAdjustment" value={"Vertical"} errors={props.errors} register={props.register} required></NVLRadio>
                        </div>
                        <div className={" {invalid-feedback} text-red-500 text-sm "}>
                            {props.errors?.IsAdjustment?.message}
                        </div>
                        <div className="Center-Aligned-Items pt-4 ">
                            <NVLlabel text="Multiple Choice Value" className="font-bold"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <NVLMultilineTxtbox id="txtMultiple" className="nvl-Def-Input nvl-mandatory" title="Multiple Choice Value" errors={props.errors} register={props.register}></NVLMultilineTxtbox>
                        </div>
                        <div className="Center-Aligned-Items pt-1">
                            <NVLCheckbox id="chkLine" text="Use One line for each answer" value={"true"} errors={props.errors} register={props.register}></NVLCheckbox>
                        </div>
                    </div>
                    <div className={`${props.watch("ddlType") == "Label" ? "" : "hidden"} `}>
                        <NVLlabel text="Label" className="font-bold"><span className="text-red-500 text-lg">*</span></NVLlabel>
                        <NVLRichTextBox id="txtLbl" setState={props.setMessage} className=" isResizable nvl-mandatory"></NVLRichTextBox>
                        <div className="{invalid-feedback} text-red-500 text-sm pt-2" id="desc_errors">
                            {props.errors?.RichTextBox?.message}
                        </div>
                    </div>
                    <div className={`${props.watch("ddlType") == "Short Answer" ? "" : "hidden"}`}>
                        <div>
                            <NVLlabel text="Question" className="font-bold"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <NVLTextbox id="txtShortQuestion" className="nvl-Def-Input nvl-mandatory" title="Question" errors={props.errors} register={props.register}></NVLTextbox>
                        </div>
                        <div>
                            <NVLlabel text="Label" className="font-bold"></NVLlabel>
                            <NVLTextbox id="txtShortAnsLabel" className="nvl-Def-Input nvl-non-mandatory" title={`Label`} type="text" errors={props.errors} register={props.register}></NVLTextbox>
                        </div>
                    </div>
                    <div className={`${props.watch("ddlType") == "Information" ? "" : "hidden"}`}>
                        <div>
                            <NVLlabel text="Question" className="font-bold"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <NVLTextbox id="txtInfoQuestion" className="nvl-Def-Input nvl-mandatory" type="text" title="Question" errors={props.errors} register={props.register}></NVLTextbox>
                        </div>
                        <div>
                            <NVLlabel text="Label" className="font-bold"></NVLlabel>
                            <NVLTextbox id="txtInfoLabel" className="nvl-Def-Input nvl-non-mandatory" title={`Label`} errors={props.errors} register={props.register}></NVLTextbox>
                        </div>
                        <div>
                            <NVLlabel text="Information Type" className="font-bold"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <NVLSelectField id="ddlInfoType" className="nvl-Def-Input nvl-mandatory" options={informationType} errors={props.errors} register={props.register}></NVLSelectField>
                        </div>
                    </div>
                    {props.watch("ddlType") && <div className={`${props.watch("ddlType") == "Select" || props.watch("ddlType") == "" ? "hidden" : ""} flex flex-row gap-1 justify-center nvl-Def-Input mt-4`}>
                        <NVLButton id="btnSubmit" text={"Submit"} type="submit" className={"w-32 nvl-button bg-primary text-white "}></NVLButton>
                        <NVLButton id="btnCancel" text={"Clear"} type="button" className="nvl-button w-28" onClick={() => props.resetData("clear")}></NVLButton>
                    </div>}
                </form>
            </div>
        )
    }, [])

    return (
        <>
            <Container>
                <FeedBackQuestion resetData={resetData} submitHandler={submitHandler} questions={questions} handleSubmit={handleSubmit} register={register} watch={watch} languageType={props.languageType} errors={errors} editQuestion={editQuestion} setMessage={setMessage} setValue={setValue} />
                {questions != null &&
                    <div>
                        <QuestionsData UpdateQuestion={props.UpdateQuestion} message={message} sortusingpostion={props.sortusingpostion} handleSort={props.handleSort} errors={errors} register={register} questions={questions} reset={reset} setValue={setValue} setQuestions={setQuestions} TenantInfo={props.TenantInfo} ActivityID={props?.pageData?.ActivityID} ActivityType={props.pageData?.ActivityType} CM_Mode={props.CM_Mode} user={props.user} CourseActivityID={props?.pageData.CourseActivityID} ModuleId={props?.pageData?.ModuleId} router={props.router} PageData={props?.pageData} />
                    </div>
                }
            </Container>
        </>
    );
}

export default FeedBackQuestion;