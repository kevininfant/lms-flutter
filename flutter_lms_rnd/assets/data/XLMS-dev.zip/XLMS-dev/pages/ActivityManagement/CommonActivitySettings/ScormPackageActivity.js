import { DynamicFileLanguageValidation } from "@Pages/ActivityManagement/CommonActivitySettings/CommonFunction";
import NVLDynamicLanguageFile from "@components/Controls/NVLDynamicLanguageFile";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLWarning from "@components/Controls/NVLWarning";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, DateTime, Grade, ReactTagsButton } from "./ActivityComponents";

export const ScormPackageActivity = ({ CurrentDiv, ErrorRef, LanguageType, GradeMethod,
  AllowAttempts, query, Attempt, DateCoversion, FinalResponse, props, delimiters, router, CustomMessage }) => {
  const appearanceOptions = useMemo(() => {
    return [
      { value: "", text: "Select" },
      { value: "CurrentWindow", text: "Current Window" },
      { value: "NewWindow", text: "New Window" },
    ];
  }, []);

  let initialValue = [{
    Language: "",
    FileName:
      props.mode == "Edit" && props.EditData?.AttachFile &&
        props.EditData?.AttachFile.substring(
          props.EditData?.AttachFile.lastIndexOf("/") + 1,
          props.EditData?.AttachFile.length
        ) != ""
        ? props.EditData?.AttachFile &&
        props.EditData?.AttachFile.substring(
          props.EditData?.AttachFile.lastIndexOf("/") + 1,
          props.EditData?.AttachFile.length
        )
        : "Select File",
    FilePath: props.mode == "Edit" ? props.EditData?.AttachFile : "",
    path: props.mode == "Edit" ? props.EditData?.AttachFile : "",
    PathChanged: false,
  }]

  const [fileValues, setFileValues] = useState(initialValue);
  const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);
  const stDate = useRef()
  const validationSchema = Yup.object().shape({
    /* Dynamic Language */
    FileLang: Yup.string()
      .test("file_Error", "", (e, { createError }) => {
        let message = DynamicFileLanguageValidation(e, "ddlFileScorm", fileValues);
        if (message != "") {
          setValue("dynamicError", message);
          return createError({ message: message });
        } else {
          setValue("dynamicError", undefined);
          return true;
        }
      })
      .nullable(),
    /* Activity Completion */
    rbActivityCompletion: Yup.string()
      .required("Activity completion is required")
      .nullable()
      .test("error", "", (e, { createError }) => {
        if (e == "true") {
          let array = ["chkViewTheActivity", "chkCompleteTheActivity", "chkMarkTheActivity", "chkSubmitTheActivity", "chkPassed", "chkCompleted"];
          let result = [];
          array.map((item) => {
            result.push(watch(item));
          });
          if (result.indexOf(true) == -1) {
            setValue("activitycompletionError", "At least one is required.");
            return createError({ message: "At least one is required." });
          } else {
            setValue("activitycompletionError", undefined);
            return true;
          }
        } else {
          setValue("chkViewTheActivity", null);
          setValue("chkMarkTheActivity", null);
          setValue("chkCompleteTheActivity", null);
          setValue("chkSubmitTheActivity", null);
          setValue("chkPassed", null);
          setValue("chkCompleted", null);
          setValue("activitycompletionError", undefined);
        }
        return true;
      })
      .nullable(),
    txtScormDuration: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .matches(Regex("AllowNumbersWithDot"), "Invalid value")
      .nullable()
      .test("len", "Must be limit digits", (val, { createError }) => {
        let LimitedTime = 999;
        if (val > LimitedTime) {
          return createError({
            message: `Duration maximum limit exceed.`,
          });
        }
        else if (parseInt(val) <= 0) {
          return createError({ message: `Duration should be only positive values and more then zero` });
        }
        else {
          return true;
        }
      }),

    /*Grade Validation*/
    txtMaxGrade: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .nullable()
      .min(1)
      .matches(Regex("AllowNumbersWithDot"), "Numbers only Allowed")
      .test(999, "Maximum grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        if (val == null || val == undefined || val == "") {
          return true;
        }
        if (parseInt(val) == 0) {
          return createError({ message: "Enter the valid value" });
        }
        if(parseFloat(val)>100.00)
        {
          return createError({ message: "Maximum grade should be less than or equal to 100.00" });
        }
        if (parseFloat(watch("txtPassGrade")) > parseFloat(val)) {
          return createError({ message: "Maximum grade should be greater than or equal to passing grade" });
        }
        if (val.includes(".")) {
          let valcheck = val.split(".");
          if (parseInt(valcheck[0]) > 999 || parseInt(valcheck[1]) > 100 || valcheck[1].length > 2) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        } else {
          if (parseInt(val) > 999) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        }
        if (parseFloat(watch("txtPassGrade")) < parseFloat(val)) {
          clearErrors(["txtPassGrade"])
        }
        return true;
      }),
    txtPassGrade: Yup.string()
      .transform((o, c) => (o === "" ? null : c))
      .nullable()
      .min(1)
      .matches(Regex("AllowNumbersWithDot"), "Numbers only Allowed")
      .test("error", "Passing grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        if (val == null || val == undefined || val == "") {
          return true;
        }
        if (parseInt(val) == 0) {
          return createError({ message: "Enter the valid value" });
        }
        if (watch("txtMaxGrade") == undefined || watch("txtMaxGrade") == "" || watch("txtMaxGrade") == "0") {
          return createError({ message: "Passing Grade Must be less than or equal to maximum grade" });
        }
        else if (watch("txtMaxGrade") != undefined && parseFloat(watch("txtMaxGrade")) < parseFloat(val)) {
          return createError({ message: "Passing Grade Must be less than or equal to maximum grade" });
        }
        if (val.includes(".")) {
          let valcheck = val.split(".");
          if (parseInt(valcheck[0]) >= 1000 || parseInt(valcheck[1]) >= 100 || valcheck[1].length > 2) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        } else {
          if (parseInt(val) >= 1000) {
            return createError({ message: "Maximum grade will allow only 3 digit. (Eg:100.00)" });
          }
        }
        return true;
      }),
    /*Date time Validation*/
    txtstdate: Yup.string()
      .nullable(true)
      .notRequired().test("Check", "Activity can be created only for present and future date", (e, { createError }) => {
        if (watch("txtstdate") == "NaN-NaN-NaNTNaN:NaN" || e == "" || e == undefined || e == null) {
          return true;
        }
        else {
          if (new Date(e) > new Date(new Date().setDate(new Date().getDate() - 1))) {
            if ((stDate.current != e)) {
              if ((watch("chkEndDateEnable") != undefined && watch("chkEndDateEnable")) &&
                (((watch("chkEndDateEnable") != undefined && watch("txtEnddate") != undefined) && (new Date(watch("txtEnddate")) <= new Date(e))))) {
                setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
              } else {
                clearErrors(["txtEnddate"])
              }
              stDate.current = e;
            }
            return true;
          }
          else {
            return false
          }
        }
      }).nullable(true),
    txtEnddate: Yup.date()
      .when("chkEndDateEnable", {
        is: true,
        then: Yup.date().required("End Date is Required").typeError("End Date is invalid Value").nullable().test("error", "End Date must be greater than or equal to the start date", (e) => {
          if (e > new Date(watch("txtstdate"))) {
            return true;
          }
          else {
            return false
          }
        }),
      })
      .nullable(true),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), nativeValidation: false };
  const { register, handleSubmit, setValue, watch, formState, reset, clearErrors } = useForm(formOptions);
  const { errors } = formState;

  const handleDelete = useCallback(
    (i) => {
      setTags(tags.filter((tag, index) => index !== i));
      setValue("ReactTags", "Delete", { shouldValidate: true });
    },
    [setTags, setValue, tags]
  );

  const handleAddition = useCallback(
    (tag) => {
      setTags([...tags, tag]);
      setValue("ReactTags", "Add", { shouldValidate: true });
    },
    [setTags, setValue, tags]
  );

  const handleDrag = useCallback(
    (tag, currPos, newPos) => {
      const newTags = tags.slice();
      newTags.splice(currPos, 1);
      newTags.splice(newPos, 0, tag);
      setTags(newTags);
    },
    [tags, setTags]
  );
  /* Batch Update */

  // useEffect(() => {
  //   let Datas = [];
  //   if (props.mode == "Edit") {
  //     async function getList() {
  //       for (let i = 1; i <= props.EditData.Shard; i++) {
  //         let editDatalist;
  //         editDatalist = await AppsyncDBconnection(
  //           getXlmsEnrollUser,
  //           {
  //             PK: "TENANT#" + props.EditData.TenantID + "#" + i,
  //             SK:
  //               "ACTIVITYTYPE#" +
  //               props.EditData.ActivityType +
  //               "#ACTIVITYID#" +
  //               props.EditData.ActivityID,
  //           },
  //           props.user.signInUserSession.accessToken.jwtToken
  //         );
  //         Datas.push(editDatalist?.res?.getXlmsEnrollUser);
  //       }
  //       setData(Datas);
  //     }
  //     getList();
  //   }
  // }, [props]);

  /*End Batch Update*/
  useEffect(() => {
    if (watch("rbActivityCompletion") == undefined) {
      setValue("ddlAppearance", (props.EditData?.Appearance == undefined || props.EditData?.Appearance == "" || props.EditData?.Appearance == null) ? "" : props.EditData?.Appearance)
      setValue("txtScormDuration", props.EditData?.ActivityDuration == null || props.EditData?.ActivityDuration == "null" ? "" : props.EditData?.ActivityDuration);
      setValue("txtMaxGrade", ((props.EditData?.MaximumGrade == null || props.EditData?.MaximumGrade == "null" || props.EditData?.MaximumGrade == undefined) ? "" : props.EditData?.MaximumGrade));
      setValue("txtPassGrade", props.EditData?.PassingGrade);
      setValue("ddlMaxAtmpt", props.EditData?.MaximumAttempt == null ? "" : props.EditData?.MaximumAttempt);
      setValue("ddlGrdMethod", props.EditData?.GradingMethod == null ? "" : props.EditData?.GradingMethod);
      setValue("ddlAllowAtmpt", props.EditData?.AllowMaximumAttempts);
      setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion?.toString() == null || props.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : props.EditData?.IsActivityCompletion?.toString());
      setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
      setValue("chkCompleteTheActivity", props.EditData?.IsCompleteTheActivity);
      setValue("chkSubmitTheActivity", props.EditData?.IsSubmitTheActivity);
      setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
      setValue("chkPassed", props.EditData?.IsPassedTheActivity);
      setValue("chkCompleted", props.EditData?.IsSubmitTheActivity);
      setValue("ChkUserCreateReplies", props.EditData?.IsUserMustCreate);
      setValue("chkStartDateEnable", props.EditData?.IsStartDateEnable == null ? true : props.EditData?.IsStartDateEnable);
      setValue("txtstdate", props.EditData?.StartDate != undefined ? DateCoversion(props.EditData?.StartDate) : undefined);
      setValue("chkEndDateEnable", props.EditData?.IsEndDateEnable);
      setValue("txtEnddate", props.EditData?.EndDate != undefined ? DateCoversion(props.EditData?.EndDate) : undefined);
      if (props?.EditData?.AttachFiles != null && JSON.parse(props?.EditData?.AttachFiles).length > 0) {
        setFileValues([...JSON.parse(props?.EditData?.AttachFiles)])
      }
    }
  }, [props, DateCoversion, setValue, watch, setFileValues]);

  const submitHandler = async (data) => {

    setValue("submit", true);
    let pk, sk;

    if (props.mode == "ModuleDirect") {
      pk = "TENANT#" + props.TenantInfo.TenantID;
      sk = props.EditData.SK
    } else if (props.mode == "Edit") {
      pk = "TENANT#" + props.TenantInfo.TenantID;
      sk = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
    }
    let setUploadURL = process.env.APIGATEWAY_URL_SCORMFILEUPlOAD;
    let sub = props?.user?.attributes["sub"];

    let isFileChanges = fileValues.filter((x) => x.PathChanged == true);
    let oldData = props.EditData;
    delete oldData["FileProcessing"];
    let tempUpData = {
      input: {
        PK: pk,
        SK: sk,
        TenantID: props.TenantInfo.TenantID,
        FileProcessing: (isFileChanges?.length > 0) ? 1 : 0,
        ActivityDuration: data.txtScormDuration,
        Appearance: data?.ddlAppearance,
        MaximumAttempt: data.ddlMaxAtmpt,
        PassingGrade: data.txtPassGrade,
        MaximumGrade: data.txtMaxGrade,
        StartDate: data.txtstdate != undefined ? data.txtstdate : undefined,
        EndDate: data.txtEnddate,
        GradingMethod: data.ddlGrdMethod,
        AllowMaximumAttempts: data.ddlAllowAtmpt,
        IsStartDateEnable: watch("chkStartDateEnable"),
        IsEndDateEnable: watch("chkEndDateEnable"),
        IsActivityCompletion: data.rbActivityCompletion == null ? false : data.rbActivityCompletion,
        IsViewTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkViewTheActivity,
        IsMarkTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkMarkTheActivity,
        IsCompleteTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkCompleteTheActivity,
        IsPassedTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkPassed,
        IsSubmitTheActivity: watch("rbActivityCompletion") == "false" ? false : data.chkCompleted,
        Keywords: JSON.stringify(tags)
      },

    };
    /*Batch Update*/
    let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
    for (let i = 1; i <= props.EditData.Shard; i++) {
      UpdateBatch({
        inn: { ...oldData, ...tempUpData.input },
        props: props,
        pk: "TENANT#" + props.EditData.TenantID + "#" + i,
        query: queryBatch,
        UpdateData: props.EditData,
      });
    }
    /*Batch Update*/
    await AppsyncDBconnection(query, tempUpData, props.user.signInUserSession.accessToken.jwtToken);

    let scormVariables =
      '{' +
      '"TenantId": "' + props.TenantInfo.TenantID
      + '","PK": "' + pk
      + '","SK": "' + sk
      + '","UserSub":"' + sub
      + '","ModifiedBy": "' + props.user.username
      + '","ModifiedDate": "' + new Date()
      + '","AttachFiles": ' + JSON.stringify(reLanguage())
      + ',"BucketName": "' + props.TenantInfo.BucketName
      + '","RootFolder": "' + props.TenantInfo.RootFolder
      + '","ActivityDuration": "' + data.txtScormDuration
      + '","Type" :"Activity","ActivityType":"'
      + props.ActivityType + '","ActivityID":"' + props.ActivityID +
      '" }';
    let stateMachineArn = process.env.STEP_FUNCTION_ARN_SCORM;
    let headers = {
      method: "POST",
      headers: {
        authorizationtoken:
          props.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: "ActivityManagement",
        menuid: "500005",
        statemachinearn: stateMachineArn,

      },
      body: scormVariables,
    };

    let finalStatus = (await APIGatewayPostRequest(setUploadURL, headers)).Status;
    FinalResponse(finalStatus);
    setValue("submit", false);
  };

  const reLanguage = () => {
    let tempData = [];
    fileValues.map((e, index) => {
      tempData = [...tempData, {
        FileName: e.FileName,
        FilePath: e.FilePath,
        Language: document.getElementById("ddlFileScorm" + index)?.options[document.getElementById("ddlFileScorm" + index)?.selectedIndex]?.value,
        path: e.path,
        PathChanged: e.PathChanged
      }]
    })
    return tempData;
  }
  return (
    <section>
      <form>
        <div id="ScormPackage" className={props.EditData?.FileProcessing == 1 ? "pointer-events-none" : ""}>
          {props.EditData?.FileProcessing == 1 && <NVLWarning Header={"In Processing!..."} Content={"Scorm file is processing, it will take some times"}></NVLWarning>}
          <div className="container px-0 sm:px-12 mx-auto grid gap-8 ">
            <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name:  ${props.EditData.ActivityName}`}></NVLlabel>
            <NVLlabel text={`Activity Type :  ${CurrentDiv == "ScormPackage" ? "SCORM Package" : ""}`}></NVLlabel>
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel text="Attach File" className="nvl-Def-Label w-52 ">
                <span className="text-red-500 text-lg">*</span>
              </NVLlabel>
              <div>
                <NVLDynamicLanguageFile ActivityType={props.ActivityType} ActivityID={props.ActivityID} EditData={props.EditData} TenantInfo={props.TenantInfo} CurrentDiv={CurrentDiv} FileValues={fileValues} setFileValues={setFileValues} setValue={setValue} SelectFieldOptions={LanguageType} id="getFile" ddlId="ddlFileScorm" ValidateError={errors?.File?.message} LoaderId="loader" watch={watch} errors={errors} register={register} FileError={watch("dynamicError")} HelpInfo="File size should be 1GB<br>Acceptable file format: zip (scorm)" />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4 ">
              <NVLlabel className="nvl-Def-Label w-52" text="Activity Duration(min)"></NVLlabel>
              <NVLTextbox id="txtScormDuration" type="text" title={"Duration"} className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register} required />
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <NVLlabel text="Display Option" className="nvl-Def-Label w-52"></NVLlabel>
              <div className="">
                <NVLSelectField id="ddlAppearance" options={appearanceOptions} className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register}></NVLSelectField>
                {/* 
                <div className="flex gap-4">
                  <div>
                    <NVLlabel text="Pop-up width(in pixels)" className="nvl-Def-Label w-52"></NVLlabel>
                    <NVLTextbox title="Pixels" id="txtWidth" className="w-36 nvl-non-mandatory" type="number" pattern="[0-9]" maxLength={"3"} errors={errors} register={register}></NVLTextbox>
                  </div>
                  <div>
                    <NVLlabel text="Pop-up height(in pixels)" className="nvl-Def-Label w-52"></NVLlabel>
                    <NVLTextbox title="Pixels" id="txtHeight" className="w-36 nvl-non-mandatory" type="number" pattern="[0-9]" maxLength={"3"} errors={errors} register={register}></NVLTextbox>
                  </div>
                </div>
                */}
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4 ">
              <NVLlabel className="nvl-Def-Label w-52" text="Availability" />
              <div>
                <DateTime register={register} errors={errors} watch={watch} setValue={setValue} reset={reset} />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel text="Grade" className="nvl-Def-Label w-52"></NVLlabel>
              <div>
                <Grade ActivityType={props.ActivityType} errors={errors} register={register} Attempt={Attempt} watch={watch} GradeMethod={GradeMethod} AllowAttempts={AllowAttempts} AllowAttempt={false} />
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <NVLlabel text="Activity Completion" className="pt-3 nvl-Def-Label w-52"></NVLlabel>
              <div>
                <ActivityCompletion register={register} errors={errors} watch={watch} />
                <CheckboxesInput register={register} errors={errors} watch={watch} IsViewTheActivity={true} IsPassed={true} IsCompleted={true} IsMarkTheActivity={true} IsCompleteTheActivity={true} setValue={setValue} CustomMessage={CustomMessage} />
                <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"}>
                  <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation">
                    {watch("activitycompletionError")}
                  </div>
                </div>
              </div>
            </div>
            {/* <div className="mb-2 mx-10 px-40"> */}
            {/* </div> */}
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52" />
              <div>
                <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} props={props} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
              </div>
            </div>
          </div>
        </div>
      </form>
    </section>
  );
};
export default ScormPackageActivity;