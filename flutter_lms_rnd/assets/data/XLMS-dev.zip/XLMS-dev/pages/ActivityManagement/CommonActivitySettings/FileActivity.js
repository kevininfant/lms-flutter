import NVLDynamicLanguageFile from "@components/Controls/NVLDynamicLanguageFile";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRadio from "@components/Controls/NVLRadio";
import { yupResolver } from "@hookform/resolvers/yup";
import { DynamicFileLanguageValidation } from "@Pages/ActivityManagement/CommonActivitySettings/CommonFunction";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsActivityManagementShardingInfo, createXlmsCourseManagementShardingInfo } from "src/graphql/mutations";
import * as Yup from "yup";
import { ActivityCompletion, CheckboxesInput, ReactTagsButton } from "./ActivityComponents";
export const FileActivity = ({ CurrentDiv, CustomMessage, UnSavedtoSaved, LanguageType, delimiters,
  FinalResponse, query, props, router }) => {

  let initialValue = [{ Language: "", FileName: "Select File", FilePath: "", path: "", PathChanged: false,}]
  const [fileValues, setFileValues] = useState(initialValue);
  const [tags, setTags] = useState(props.EditData?.Keywords != undefined ? JSON?.parse(props.EditData?.Keywords) : []);

  /* ----------  Validation   ------ */
  const validationSchema = Yup.object().shape({
    /* Dynamic Language */
    FileLang: Yup.string()
      .test("file_Error", "", (e, { createError }) => {
        let message = DynamicFileLanguageValidation(e, "ddlFile", fileValues);
        if (message != "") {
          setValue("dynamicError", message)
          return createError({ message: message });
        } else {
          setValue("dynamicError", undefined)
          return true;
        }
      }).nullable(),

    /* Activity Download */
    rbFileDownload: Yup.string().nullable(),
    /* Activity Completion */
    rbActivityCompletion: Yup.string()
      .required("Activity completion is required")
      .nullable()
      .test("error", "", (e, { createError }) => {
        if (e == "true") {
          let array = ["chkViewTheActivity", "chkMarkTheActivity"];
          let result = [];
          array.map((item) => {
            result.push(watch(item));
          });
          if (result.indexOf(true) == -1) {
            setValue("activitycompletionError", "At least one is required.")
            return createError({ message: "At least one is required." });
          } else {
            setValue("activitycompletionError", undefined)
            return true;
          }
        } else {
          setValue("chkViewTheActivity", null)
          setValue("chkMarkTheActivity", null)
          setValue("activitycompletionError", undefined)
        }
        return true;
      })
      .nullable(),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), nativeValidation: false };
  const { register, handleSubmit, setValue, watch, formState, reset } = useForm(formOptions);
  const { errors } = formState;

  const handleDelete = useCallback(
    (i) => {
      setTags(tags.filter((tag, index) => index !== i));
      setValue("ReactTags", "Delete", { shouldValidate: true });
    },
    [setTags, setValue, tags]
  );

  const handleAddition = useCallback(
    (tag) => {
      setTags([...tags, tag]);
      setValue("ReactTags", "Add", { shouldValidate: true });
    },
    [setTags, setValue, tags]
  );

  const handleDrag = useCallback(
    (tag, currPos, newPos) => {
      const newTags = tags.slice();
      newTags.splice(currPos, 1);
      newTags.splice(newPos, 0, tag);
      setTags(newTags);
    },
    [tags, setTags]
  );

  useEffect(() => {

    if (watch("rbFileDownload") == undefined) {
      setValue("rbFileDownload", (props.EditData?.IsDownload == null || props.EditData?.IsDownload == undefined ? "false" : props.EditData?.IsDownload?.toString()));
      setValue("rbActivityCompletion", (props.EditData?.IsActivityCompletion?.toString() == null || props.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : props.EditData?.IsActivityCompletion?.toString()));
      setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
      setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
      if (props?.EditData?.AttachFiles != null && JSON.parse(props?.EditData?.AttachFiles).length > 0) {
        setFileValues([...JSON.parse(props?.EditData?.AttachFiles)])
      }
    }
  }, [props, setValue, watch])

  const submitHandler = async (data) => {
    setValue("submit", true);
    let pk, sk;
    if (props.mode == "ModuleDirect") {
      pk = "TENANT#" + props.TenantInfo.TenantID;
      sk = props.EditData.SK
    } else if (props.mode == "Edit") {
      pk = "TENANT#" + props.TenantInfo.TenantID;
      sk = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
    }
    let multilangFiles = await UnSavedtoSaved(fileValues);

    if (multilangFiles != null || multilangFiles != undefined) {
      let fileVariables = {
        input: {
          PK: pk,
          SK: sk,
          AttachFiles: JSON.stringify(multilangFiles),
          TenantID: props.TenantInfo.TenantID,
          TenantName: props.TenantDisplayName,
          IsDownload: data.rbFileDownload,
          IsActivityCompletion: data.rbActivityCompletion,
          IsMarkTheActivity: data.chkMarkTheActivity,
          IsViewTheActivity: data.chkViewTheActivity,
          Keywords: JSON.stringify(tags),
          ModifiedBy: props.user.username,
          ModifiedDate: new Date(),
        },
      };
      let queryBatch = (props.mode == "ModuleDirect" || props.mode == "ModuleEdit") ? createXlmsCourseManagementShardingInfo : createXlmsActivityManagementShardingInfo;
      /*Batch Update*/
      for (let i = 1; i <= props.EditData.Shard; i++) {
        UpdateBatch({ UpdateData: props.EditData, inn:{...props.EditData,... fileVariables.input}, props: props, pk: "TENANT#" + props.EditData.TenantID + "#" + i, query: queryBatch, });
      }
      /*Batch Update*/
      let finalStatus = (await AppsyncDBconnection(query, fileVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
      FinalResponse(finalStatus);
      setValue("submit", false);
    }
  };
  return (
    <section>
      <form>
        <div id="divFile" className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}>
          <div className="container px-12 mx-auto grid gap-8">
            <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name: ${props.EditData.ActivityName}`}></NVLlabel>
            <NVLlabel className="nvl-Def-Label " text={`Activity Type: ${CurrentDiv}`}></NVLlabel>
            <div className="flex flex-col sm:flex-row  gap-4">
              <NVLlabel text="Attach File" className="nvl-Def-Label w-52" ><span className="text-red-500 text-lg">*</span></NVLlabel>
              <NVLDynamicLanguageFile
                ActivityType={props.ActivityType}
                ActivityID={props.ActivityID}
                mode={props.mode}
                EditData={props.EditData}
                TenantInfo={props.TenantInfo}
                CurrentDiv={CurrentDiv}
                FileValues={fileValues}
                setFileValues={setFileValues}
                setValue={setValue}
                SelectFieldOptions={LanguageType}
                id="getFile"
                ddlId="ddlFile"
                ValidateError={errors?.File?.message}
                LoaderId="loader"
                watch={watch}
                errors={errors}
                register={register}
                FileError={watch("dynamicError")}
                HelpInfo="File size should be 1GB<br>Acceptable file format: docx, doc, zip, pdf, csv, jpg, jpeg, png, avi, mov,xls, xlsx, mp4 " />
            </div>

            <div className="flex flex-col sm:flex-row  gap-4 ">
              <NVLlabel className="nvl-Def-Label w-52" text="Download"></NVLlabel>
              <div className="grid">
                <div className="flex gap-9">
                  <NVLRadio text="Yes" value={"true"} id="rbFileDownload" name="rbFileDownload" errors={errors} register={register} />
                  <NVLRadio text="No" value={"false"} id="rbFileDownload" name="rbFileDownload" errors={errors} register={register} />
                </div>
                <div className={"{invalid-feedback} text-red-500 text-sm "}> {errors?.rbFileDownload?.message}
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4">
              <NVLlabel id="lblActivityCompletion" text="Activity Completion" className="nvl-Def-Label w-52" />
              <div>
                <ActivityCompletion errors={errors} register={register} watch={watch} />
                <CheckboxesInput register={register} errors={errors} watch={watch} IsViewTheActivity={true} IsMarkTheActivity={true} CustomMessage={CustomMessage} setValue={setValue} />
                <div className={"text-red-500 text-sm pt-2"} id={"divCustomError"} >
                  <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation"> {watch("activitycompletionError")}</div>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row  gap-4  ">
              <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52" />
              <div>
                <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} props={props} tags={tags} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
              </div>
            </div>
          </div>
        </div>
      </form>
    </section>
  );
}
export default FileActivity;
