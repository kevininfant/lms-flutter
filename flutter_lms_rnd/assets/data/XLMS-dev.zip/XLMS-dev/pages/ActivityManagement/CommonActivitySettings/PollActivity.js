import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { ActivityCompletion, CheckboxesInput, DateTime, Options, ReactTagsButton } from "./ActivityComponents";

export const PollActivity = ({ Attempt,AllowAttempts, GradeMethod, UnSavedtoSaved, LanguageType, setFileValues, FileValues, FinalResponse, query, register, props, tags, setValue, ButtonClassName, ButtonText, errors, watch, delimiters, handleAddition, handleDelete, handleDrag, handleSubmit, router }) => {
   
    //const validationSchema = Yup.object().shape({
        // /*File And Language Error */
        // FileLang:
        //   ActivityType == "File" || ActivityType == "Video" || ActivityType == "ScormPackage" || ActivityType == "Assignment" || ActivityType == "LearningBytes" || ActivityType == "Survey" || ActivityType == "Page"
        //     ? Yup.string()
        //       .test("file_Error", "", (e, { createError }) => {
        //         let errorName = "",
        //           id = "",
        //           message = "";
        //         if (ActivityType == "File" || ActivityType == "ScormPackage" || ActivityType == "Assignment") {
        //           id = ActivityType == "File" ? "ddlFile" : ActivityType == "Video" ? "ddlVideo" : ActivityType == "Survey" ? "ddlFileSurvey" : ActivityType == "ScormPackage" ? "ddlFileScorm" : "ddlAssignment";
        //           errorName = DynamicFileLanguageValidation(e, id);
        //         }
        //         if (document.getElementById("rbIsURL")?.value == "URL" && document.getElementById("rbIsURL")?.checked) {
        //           let textid = ActivityType == "Video" ? "textVideoUrl" : ActivityType == "Survey" ? "textSurveyUrl" : "";
        //           let ddlid = ActivityType == "Video" ? "ddlVideoUrl" : ActivityType == "Survey" ? "ddlSurveyUrl" : "";
    
        //           errorName = DynamicTextLanguageValidation(e, textid, ddlid);
        //         } else {
        //           if (ActivityType == "Page") {
        //             errorName = DynamicPageLanguageValidation(pageRef, "ddlLanguagePage")
        //           }
        //           else {
        //             id = ActivityType == "File" ? "ddlFile" : ActivityType == "Video" ? "ddlVideo" : ActivityType == "Survey" ? "ddlFileSurvey" : ActivityType == "ScormPackage" ? "ddlFileScorm" : "ddlAssignment";
        //             errorName = DynamicFileLanguageValidation(e, id);
        //           }
    
        //         }
        //         if (errorName == "LANGEXISTS") {
        //           message = "Language is already exists.";
        //         } else if (errorName == "FILE") {
        //           message = "File is required to upload correct format.";
        //         } else if (errorName == "FILELANG") {
        //           message = "Language and File is required.";
        //         } else if (errorName == "LANG") {
        //           message = "Language is required.";
        //         } else if (errorName == "ERROR") {
        //           message = "File not uploaded.";
        //         } else if (errorName == "TEXT") {
        //           message = "URL is required.";
        //         } else if (errorName == "LANGTEXT") {
        //           message = "Language and URL is required.";
        //         } else if (errorName == "INVALIDURL") {
        //           message = "Url is invalid.";
        //         } else if (errorName == "INVALIDFILE") {
        //           message = "File Format Is Invalid.";
        //         } else if (errorName == "INVALIDFILE") {
        //           message = "File size upto 1GB.";
        //         } else if (errorName == "LANGINVALIDURL") {
        //           message = "Language is required and URL  is invalid.";
        //         }
        //         if (message != "") {
        //           SetDynamicError(message);
        //           document.getElementById("fileErrorMessage")?.classList?.remove("hidden");
    
        //           return createError({ message: message });
        //         } else {
        //           SetDynamicError(message);
        //           if (!document.getElementById("fileErrorMessage")?.classList?.contains("hidden")) {
        //             document.getElementById("fileErrorMessage")?.classList?.add("hidden");
        //           }
        //           return true;
        //         }
        //       }).nullable()
        //     : Yup.string().nullable(),
    
        // /* CheckBox Input */
        // chkViewTheActivity: Yup.bool().default(false).nullable(),
        // chkCompleteTheActivity: Yup.bool().default(false).nullable(),
        // chkMarkTheActivity: Yup.bool().default(false).nullable(),
        // chkSubmitTheActivity: Yup.bool().default(false).nullable(),
        // ChkUserCreateReplies: Yup.bool().default(false).nullable(),
        // chkdisplay: Yup.bool().default(false).nullable(),
        // chkcopyright: Yup.bool().default(false).nullable(),
        // /*Enable Host Validation*/
        // txtalternativehost: Yup.string()
        //   .nullable()
        //   .when("chkmeetingoption", {
        //     is: true,
        //     then: Yup.string().required("Alternative Host is required").nullable(true),
        //   }),
    
        // /* TemplateName Validation*/
        // txtTemplateName: Yup.string().when("rbTemplateVisible", {
        //   is: "true",
        //   then: Yup.string()
        //     .typeError("Template Name is required")
        //     .required("Template Name is required")
        //     .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Enter a valid Template Name")
        //     .max(250, "Maximum character does not exceed 250")
        //     .test("", "Template Name is required", () => {
        //       if (document.getElementById("txtTemplateName")?.value == "") {
        //         return false;
        //       }
        //       return true;
        //     })
        //     .nullable(),
        // }),
    
        // txtCompletionMsg: Yup.string().nullable().max(500, "Maximum character does not exceed 500"),
    
        // /*Date time Validation*/
    
        // txtstdate: Yup.date()
        //   .nullable()
        //   .when("chkStartDateEnable", {
        //     is: true,
        //     then: Yup.date("Start Date is Required")
        //       .required("Start Date is Required")
        //       .nullable(true)
        //       .typeError("Activity can be created only for present and future date")
        //       .test("check", "Activity can be created only for present and future date", (e) => {
        //         let dateTime = new Date(e);
        //         if (dateTime < new Date()) {
        //           return false;
        //         }
        //         return true;
        //       }),
        //   }),
    
        // txtEnddate: Yup.date()
        //   .when("chkEndDateEnable", {
        //     is: true,
        //     then: Yup.date().min(Yup.ref("txtstdate"), "End Date must be greater than or equal to the start date").required("End Date is Required").typeError("End Date is invalid Value").nullable(),
        //   })
        //   .nullable(),
    
        // txtCutdate:
        //   ActivityType == "Assignment" &&
        //   Yup.date()
        //     .when("chkCutDateEnable", {
        //       is: true,
        //       then: Yup.date().min(Yup.ref("txtstdate"), "End Date must be greater than or equal to the start date").required("End Date is Required").typeError("End Date is invalid Value").nullable(),
        //     }
        //     ).nullable(),
    
        // txtCutdate:
        //   ActivityType == "Assignment" &&
        //   Yup.date()
        //     .when("chkCutDateEnable", {
        //       is: true,
        //       then: Yup.date().required("Cut of Date is Required").min(Yup.ref("txtEnddate"), "Cut-Off Date Must Be Greater than or equal to End Date").typeError("Cut-Off Date is invalid Value").nullable(),
        //     })
    
        //     .nullable(),
    
        // /* Activity Completion */
        // rbActivityCompletion: Yup.string()
        //   .required("Activity completion is required")
        //   .nullable()
        //   .test("error", "", (e, { createError }) => {
        //     if (e == "true" && ActivityCompletionRef.current == "true") {
        //       let array = ["chkViewTheActivity", "chkCompleteTheActivity", "chkMarkTheActivity", "chkSubmitTheActivity", "ChkUserCreateReplies", "chkdisplay", "chkcopyright", "chkShowAnswers", "chkShowScores", "chkShowBothAnswers", "chkHideQuestions", "chkSubmitTheFeedback", "chkPassed", "chkCompleted"];
        //       let result = [];
        //       array.map((item, idx) => {
        //         result.push(document.getElementById(item)?.checked);
        //       });
        //       if (result.indexOf(true) == -1) {
        //         setCustomMessage("At least one field is required");
        //         document.getElementById("divCustomError")?.classList?.remove("hidden");
        //         return false;
        //       } else {
        //         setCustomMessage("");
        //         document.getElementById("divCustomError")?.classList?.add("hidden");
        //         return true;
        //       }
        //     } else {
        //       if (e == "true") {
        //         ActivityCompletionRef.current = "true";
        //         document.getElementById("divCustomError")?.classList?.add("hidden");
        //         return false;
        //       }
        //       ActivityCompletionRef.current = "false";
        //       ResetData();
        //       setCustomMessage("");
        //       document.getElementById("divCustomError")?.classList?.add("hidden");
        //     }
        //     return true;
        //   })
        //   .nullable(),
        // /* Tags */
        // ReactTags: Yup.string()
        //   .test("testReactTags", "Keywords is Requried", (e) => {
        //     return true;
        //     if (e == "Add") {
        //       return true;
        //     } else if (e == "Delete" && tags.length == 1 && props?.EditData?.Keywords == null) {
        //       return false;
        //     }
        //     if (props?.EditData?.Keywords == null || tags.length == 0) {
        //       return false;
        //     } else {
        //       return true;
        //     }
        //   })
        //   .nullable(),
    
        // /*Page */
        // txtUrl: ActivityType == "Url" ? Yup.string().required("Url is required").matches(Regex("Url"), "Url is invalid").nullable() : Yup.string().nullable(),
        // txtWidth: ActivityType == "Url" ? Yup.string().nullable().max(4, "Max length exceed 4") : Yup.string().nullable(),
        // txtHeight: ActivityType == "Url" ? Yup.string().max(4, "Max length exceed 4").nullable() : Yup.string().nullable(),
        // /* File */
        // rbFileDownload: ActivityType == "File" ? Yup.string().required("File download is required").nullable() : Yup.string().nullable(),
        // /* Video && Zoom && GoogleMeet */
        // txtDuration:
        //   ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams"
        //     ? Yup.string()
        //       .transform((o, c) => (o === "" ? null : c))
        //       .matches(Regex("AllowZeroasSecondary"), "Numbers only allowed")
        //       .nullable()
        //       .required("Duration is required")
        //       .test("len", "Must be 2 digits", (val, { createError }) => {
        //         let LimitedTime = ActivityType == "GoogleMeet" ? 60 : "" || ActivityType == "Zoom" ? 40 : "" || ActivityType == "MSTeams" ? 1800 : "";
        //         if (val > LimitedTime) {
        //           return createError({
        //             message: `Duration should be less than or Equal to ${LimitedTime} Minutes`,
        //           });
        //         } else {
        //           return true;
        //         }
        //       })
        //     : ActivityType == "Video"
        //       ? Yup.string()
        //         .nullable()
        //         .transform((o, c) => (o === "" ? null : c))
        //         .max(9, "Video Duration should not Exceed more than 9 values")
        //         .matches(Regex("AllowZeroasSecondary"), "Enter Valid Value")
        //       : Yup.string().nullable(),
        // /* Video && Survey*/
        // rbIsURL: ActivityType == "Video" || ActivityType == "Survey" ? Yup.string().required("Attach type is requried").nullable().test("", "", (e) => {
        //   ResetLanguage();
        //   return true;
        // }) : Yup.string().nullable(),
        // /* Discussion */
        // txtMaxAttachmentSize:
        //   ActivityType == "Discussion"
        //     ? Yup.string()
        //       .typeError("Max attachment size is required")
        //       .required("Max attachment size is required")
        //       .matches(Regex("AllowOnlyNumbers"), "File size should not exceed more than 1024MB")
        //       .transform((o, c) => (o === "" ? null : c))
        //       .test("error", "", (val, { createError }) => {
        //         if (parseInt(val) >= 1024) {
        //           return createError({ message: "Attachment file size should be between 1-1024 MB" });
        //         } else if (parseInt(val) == 0) {
        //           return createError({ message: "Attachment file size should be between 1-1024 MB" });
        //         }
        //         return true;
        //       })
        //       .nullable()
        //     : Yup.string().nullable(),
    
        // /*Validation For Record UserName*/
        // rbRecordUserName: ActivityType == "Discussion" || ActivityType == "Survey" ? Yup.string().required("Record user name is required").nullable() : Yup.string().nullable(true).notRequired(),
    
        // //  Assignment */
        // txtAssgmntDuration: Yup.string()
        //   .nullable()
        //   .transform((o, c) => (o === "" ? null : c))
        //   .max(3, "Maximum Activity Duration must be at most 3 characters")
        //   .test("Enter the valid value", "Enter the valid value", (e) => {
        //     if (parseInt(e) == 0) {
        //       return false;
        //     }
        //     return true;
        //   }),
    
        // //  Feedback*/
        // rbTemplateVisible:
        //   ActivityType == "Feedback"
        //     ? Yup.string()
        //       .nullable()
        //       .test("", "", (e) => {
        //         if (e == "false") {
        //           document.getElementById("txtTemplateName") ? (document.getElementById("txtTemplateName").value = "") : "";
        //         }
        //         return true;
        //       })
        //     : Yup.string().nullable(),
    
        // rbMultipleSubmission: ActivityType == "Feedback" ? Yup.string().required("Multiple submissions is required").nullable() : Yup.string().nullable(),
        // rbEnableSubmission: ActivityType == "Feedback" ? Yup.string().required("Enable notification of submissions is required").nullable() : Yup.string().nullable(),
        // rbRecordUser: ActivityType == "Feedback" ? Yup.string().required("Record user name is required").nullable() : Yup.string().nullable(),
        // rbShowAnalysis: ActivityType == "Feedback" ? Yup.string().required("Show analysis page is required").nullable() : Yup.string().nullable(),
    
        // // Zoom & GoogleMeet
        // rbIsRecurringWebinar: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Any one required").nullable() : Yup.string().nullable(),
        // txtPassword:
        //   ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams"
        //     ? Yup.string()
        //       .typeError("Password is required")
        //       .nullable()
        //       .required("Password is Required")
        //       .test("validateStrength", "", (e, { createError }) => {
        //         let strength = 0,
        //           message = "Password Should Have ";
        //         if (!e?.match(/\d+/g)) {
        //           strength++;
        //           message = message + "A Number";
        //         }
    
        //         if (!e?.match(/[A-Z]+/g)) {
        //           strength++;
        //           if (strength > 1) {
        //             message = message + ", ";
        //           }
        //           message = message + "A Captial Letter";
        //         }
        //         if (!e?.match(/[a-z]+/g)) {
        //           strength++;
        //           if (strength > 1) {
        //             message = message + ", ";
        //           }
        //           message = message + "A Small Letter";
        //         }
        //         if (e?.length < 8) {
        //           strength++;
        //           if (strength > 1) {
        //             message = message + ", ";
        //           }
        //           message = message + "Minimun Of Length 8";
        //         }
        //         if (strength > 0) {
        //           return createError({ message: message });
        //         }
        //         return true;
        //       })
        //     : Yup.string().nullable(),
        // rbHostVisible: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Host Option is required").nullable() : Yup.string().nullable(),
        // rbParticipantsVideo: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Participants Video is required").nullable() : Yup.string().nullable(),
        // rbPreAssessment: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Pre Assessment is required").nullable() : Yup.string().nullable(),
        // rbPostAssessment: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Post Assessment is required").nullable() : Yup.string().nullable(),
        // rbFeedback: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Feedback is required").nullable() : Yup.string().nullable(),
        // rbCertificate: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Certificate is required").nullable() : Yup.string().nullable(),
        // rbaudiooption: ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "MSTeams" ? Yup.string().required("Audio Option is required").nullable() : Yup.string().nullable(),
        // /*Grade Validation*/
        // txtMaxGrade:
        //   ActivityType == "LearningBytes" || ActivityType == "ScormPackage" || ActivityType == "Quiz" || ActivityType == "GoogleMeet" || ActivityType == "Zoom" || ActivityType == "Assignment" || ActivityType == "MSTeams"
        //     ? Yup.string()
        //       .nullable()
        //       .transform((o, c) => (o === "" ? null : c))
        //       .test("100", "Maximum grade should be less than or equal to 100.00", (val, { createError }) => {
        //         if (parseInt(val) == 0) {
        //           return createError({ message: "Enter the valid value" });
        //         }
        //         if (val != null && parseFloat(val) > "100.00") {
        //           return createError({ message: "Maximum grade should be less than or equal to 100.00" });
        //         }
    
        //         if (document.getElementById("txtPassGrade") != null && parseFloat(document.getElementById("txtPassGrade").value) > parseFloat(val)) {
        //           return createError({ message: "Maximum grade should be greater than passing grade" });
        //         }
        //         if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
        //           return false;
        //         }
        //         if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
        //           return false;
        //         }
        //         if (!(val == "100") && val?.length > 6 && val?.includes(".")) {
        //           return false;
        //         }
        //         return true;
        //       })
        //     : Yup.string().nullable(),
    
        // ddlAllowAtmpt: ActivityType == "Quiz" ? Yup.string().required("Please Choose an item in the list").nullable() : Yup.string().nullable(),
        // txtPassGrade: Yup.string()
        //   .transform((o, c) => (o === "" ? null : c))
        //   .test("error", "Passing grade will allow only 3 digit. (Eg:100.00)", (val, { createError }) => {
        //     if (val == null || val == undefined || val == "") {
        //       return true;
        //     }
        //     if (parseInt(val) == 0) {
        //       return createError({ message: "Enter the valid value" });
        //     }
        //     if (document.getElementById("txtMaxGrade") != null && parseFloat(document.getElementById("txtMaxGrade").value) < parseFloat(val)) {
        //       return createError({ message: "Passing Grade Must be less than Maximum Grade" });
        //     }
        //     if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
        //       return false;
        //     }
        //     if (!(val == "100") && val?.length >= 3 && !val?.includes(".")) {
        //       return false;
        //     }
        //     if (!(val == "100") && val?.length > 6 && val?.includes(".")) {
        //       return false;
        //     }
        //     return true;
        //   })
        //   .nullable(),
        // txtMaximum: Yup.string()
        //   .nullable()
        //   .transform((o, c) => (o === "" ? null : c))
        //   .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
        //   .test("error", "", (val, { createError }) => {
        //     if ((val != "" || val != undefined) && (parseInt(val) > 1024 || parseInt(val) <= 0)) {
        //       return createError({ message: "File size  should be between 1-1024 MB" });
        //     }
        //     return true;
        //   }),
        // txtNoofAttachment: Yup.string()
        //   .nullable()
        //   .transform((o, c) => (o === "" ? null : c))
        //   .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
        //   .test("error", "", (val, { createError }) => {
        //     if ((val != "" || val != undefined) && (parseInt(val) > 20 || parseInt(val) <= 0)) {
        //       return createError({ message: "Attachment should be between 1-20" });
        //     }
        //     return true;
        //   }),
        // ddlAllowAtmpt: ActivityType == "Quiz" || ActivityType == "Assignment" ? Yup.string().nullable() : Yup.string().nullable(),
        // ddlMaxAtmpt:
        //   ActivityType == "Quiz"
        //     ? Yup.string()
        //       .nullable()
        //       .when("ddlAllowAtmpt", {
        //         is: "",
        //         then: Yup.string().nullable(true),
        //         otherwise: Yup.string().nullable(),
        //       })
        //     : Yup.string().nullable(),
        // ddlGrdMethod: Yup.string().nullable(),
        // /*ScormPackage*/
        // txtScormDuration: Yup.string()
        //   .nullable()
        //   .transform((o, c) => (o === "" ? null : c))
        //   .max(4, "Scorm Duration should not Exceed more than 4 values")
        //   .matches(Regex("AllowZeroasSecondary"), "Enter Valid Value"),
        // /*Quiz*/
        // txtSettime: ActivityType == "Quiz" ? Yup.string().typeError("Value is required").matches(Regex("AllowZeroasSecondary"), "Invlid Value").min(1).max(3, "Set Time should be atmost 3 characters") : Yup.string().nullable(),
        // txtEnforcefirstAttempt:
        //   ActivityType == "Quiz"
        //     ? Yup.number()
        //       .typeError("Invalid Value")
        //       .nullable()
        //       .when("chkEnforcefirstEnable", {
        //         is: true,
        //         then: Yup.number().typeError("Invalid Value").required("Value is required").min(1).max(999, "Maximum character exceeds").nullable(true),
        //       })
        //     : Yup.number().nullable(true),
    
        // txtGradeBoundary:
        //   ActivityType == "Quiz"
        //     ? Yup.number()
        //       .typeError("Invalid Value")
        //       .nullable()
    
        //       .max(4, "Grade Boundary should not exceed more than 3 characters")
    
        //       .test("error", "", (val, { createError }) => {
        //         if (val < 1) {
        //           return createError({ message: "Grade Boundary should not be less than 1" });
        //         }
        //         return true;
        //       })
        //       .nullable(true)
        //     : Yup.number().nullable(),
    
        // // txtGradeboundary: Yup.string()
        // //   .notRequired().nullable()
        // //   .test("number", "Enter a valid number", (e) => {
        // //     if (e != "" && e?.length != 5) {
        // //       return false;
        // //     }
        // //     if (e == "") {
        // //       return true;
        // //     }
        // //     const rejax = new RegExp(/^[0-9]$/);
        // //     if (!rejax.test(e)) {
        // //       return false;
        // //     }
        // //     return true;
        // //   }),
    
        // txtQuizLimit:
        //   ActivityType == "Quiz"
        //     ? Yup.number()
        //       .typeError("Invalid Value")
        //       .nullable()
        //       .when("chkQuizTime", {
        //         is: true,
        //         then: Yup.number()
        //           .typeError("Invalid Value")
        //           .required("Quiz Time Limit is required")
        //           .max(999, "Quiz Time Limit should not exceed more than 3 characters")
        //           .nullable(true)
        //           .test("error", "", (val, { createError }) => {
        //             if (val < 1) {
        //               return createError({ message: "Time should not be less than 1" });
        //             }
        //             return true;
        //           })
        //           .nullable(true),
        //       })
        //     : Yup.number().nullable(),
        // txtSettime:
        //   ActivityType == "Quiz"
        //     ? Yup.number()
        //       .typeError("Invalid Value")
        //       .nullable()
        //       .when("chkSetTime", {
        //         is: true,
        //         then: Yup.number()
        //           .typeError("Invalid Value")
        //           .required("Time for each question is required")
        //           .max(999, "Maximum character exceeded")
        //           .test("error", "", (val, { createError }) => {
        //             if (val < 1) {
        //               return createError({ message: "Time should not be less than 1" });
        //             }
        //             return true;
        //           })
        //           .nullable(true),
        //       })
        //     : Yup.number().nullable(),
        // /* LearningBytes*/
        // ddlRecordContentName: ActivityType == "LearningBytes" ? Yup.string().required("Choose a Validity").nullable() : Yup.string().nullable(),
        // hkcopyright: ActivityType == "LearningBytes" ? Yup.bool().default(false).nullable() : Yup.string().nullable(),
        // /*Poll*/
        // txtOptionStaticLimit1:
        //   ActivityType == "Poll"
        //     ? Yup.string()
        //       .when("rbAllowTheChoice", {
        //         is: "true",
        //         then: Yup.string().required("Choice limit is required").nullable().matches(Regex("AllowOnlyNumbers"), "Invalid Choice limit").max(3, "Max length exceed"),
        //         otherwise: Yup.string()
        //           .test("NoValid", "NoValid", () => {
        //             setValue("txtOptionStaticLimit1", "");
        //             return true;
        //           })
        //           .nullable(),
        //       })
        //       .nullable()
        //     : Yup.string().nullable(),
        // txtOptionStaticLimit2:
        //   ActivityType == "Poll"
        //     ? Yup.string()
        //       .when("rbLimitTheResponse", {
        //         is: "true",
        //         then: Yup.string().required("Respsonse limit is required").nullable().matches(Regex("AllowOnlyNumbers"), "Invalid Respsonse limit ").max(3, "Max length exceed 3"),
        //         otherwise: Yup.string()
        //           .test("NoValid", "NoValid", () => {
        //             setValue("txtOptionStaticLimit2", "");
        //             return true;
        //           })
        //           .nullable(),
        //       })
        //       .nullable()
        //     : Yup.string().nullable(),
     // });
    
    //   const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema),nativeValidation: false };
    //   const { register, handleSubmit, setValue, watch, formState, reset } = useForm(formOptions);
    //   const { errors } = formState;
    
    
   
   
    useEffect(() => {
        setValue(
            "rbAllowTheChoice",
            props.EditData?.AllowTheChoice != null &&
              props.EditData?.AllowTheChoice != ""
              ? "true"
              : "false"
          );
          setValue(
            "rbLimitTheResponse",
            props.EditData?.LimitTheResponse != null &&
              props.EditData?.LimitTheResponse != ""
              ? "true"
              : "false"
          );
          setValue("chkStartDateEnable", props.EditData?.IsStartDateEnable);
          setValue("chkEndDateEnable", props.EditData?.IsEndDateEnable);
          setValue("txtOptionStaticLimit1", props.EditData?.AllowTheChoice);
          setValue("txtOptionStaticLimit2", props.EditData?.LimitTheResponse);
          setValue(
            "ddlResults",
            props.EditData?.PublishResult == null
              ? "0"
              : props.EditData?.PublishResult
          );
                  setValue("rbActivityCompletion", props.EditData?.IsActivityCompletion?.toString() == null || props.EditData?.IsActivityCompletion?.toString() == undefined ? "false" : props.EditData?.IsActivityCompletion?.toString());

          setValue("chkViewTheActivity", props.EditData?.IsViewTheActivity);
          setValue("chkMarkTheActivity", props.EditData?.IsMarkTheActivity);
          let optionsData = props.EditData?.Options && Object.values(JSON.parse(props.EditData?.Options))?.[0];
    
          if (optionsData?.Options != null) {
            Object.keys(optionsData.Options).map((option) => {
              setValue(option, optionsData.Options?.[option]);
            });
            Object.keys(optionsData.OptionsLimit).map((option) => {
              setValue(option, optionsData.OptionsLimit?.[option]);
            });
          }
          setValue("txtEnddate", DateCoversion(props.EditData?.EndDate));
          setValue("txtstdate", DateCoversion(props.EditData?.StartDate));
    },[props.EditData?.AllowTheChoice, props.EditData?.EndDate,props.EditData?.IsActivityCompletion, props.EditData?.IsEndDateEnable, props.EditData?.IsMarkTheActivity, props.EditData?.IsStartDateEnable, props.EditData?.IsViewTheActivity, props.EditData?.LimitTheResponse, props.EditData?.Options, props.EditData?.PublishResult, props.EditData?.StartDate, setValue])
    const submitHandler = async (data) => {
        let pk, sk;
        if (props.mode == "ModuleDirect") {
            pk = "TENANT#" + props.TenantInfo.TenantID;
            sk=props.EditData.SK
        } else if (props.mode == "Edit") {
            pk = "TENANT#" + props.TenantInfo.TenantID;
            sk = "ACTIVITYTYPE#" + props.ActivityType + "#ACTIVITYID#" + props.ActivityID;
        }
        let pollvariables = {
            input: {
                PK: pk,
                SK: sk,
                AllowTheChoice:
                    data.rbAllowTheChoice == "true" ? data.txtOptionStaticLimit1 : "",
                LimitTheResponse:
                    data.rbLimitTheResponse == "true" ? data.txtOptionStaticLimit2 : "",
                StartDate: data.txtstdate,
                EndDate: data.txtEnddate,
                IsStartDateEnable: data.chkStartDateEnable,
                IsEndDateEnable: data.chkEndDateEnable,
                PublishResult: data.ddlResults,
                IsActivityCompletion: data.rbActivityCompletion,
                IsViewTheActivity: data.chkViewTheActivity,
                IsMarkTheActivity: data.chkMarkTheActivity,
                Options: JSON.stringify(Options),
                Keywords: JSON.stringify(tags),
                ModifiedBy: props.user.username,
                ModifiedDate: new Date(),
            },
        };
        FinalStatus = (await AppsyncDBconnection(query, pollvariables,props.user.signInUserSession.accessToken.jwtToken)).Status;
        FinalResponse(FinalStatus);

    };
    return (
        <>
            <section>
                <form>
                    <div
                        id="divPoll"
                        className={CurrentDiv == "Poll" ? `${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}` : "hidden"}
                    >
                        <div className="container px-0 sm:px-12 mx-auto grid gap-8  ">
                            <NVLlabel className="nvl-Def-Label" showFull text={`Activity Name: ${props.EditData.ActivityName}`}></NVLlabel>
                            <NVLlabel
                                className="nvl-Def-Label "
                                id="lblActivityType"
                                text={`Activity Type: ${CurrentDiv}`}
                            ></NVLlabel>
                            <div className="flex flex-col sm:flex-row gap-4 ">
                                <NVLlabel
                                    className="nvl-Def-Label w-52"
                                    text="Option"
                                ></NVLlabel>
                                <div className="gap-16">
                                    <div className="grid">
                                        <div>
                                            <NVLlabel
                                                text="Allow more than one choice to be selected"
                                                className="nvl-Def-Label w-52"
                                            ></NVLlabel>
                                            <div className="flex gap-10">
                                                <div>
                                                    <div className="flex gap-10">
                                                        <NVLRadio
                                                            text="Yes"
                                                            value={"true"}
                                                            name="rbAllowTheChoice"
                                                            id="rbAllowTheChoice"
                                                            errors={errors}
                                                            register={register}
                                                        ></NVLRadio>
                                                        <NVLRadio
                                                            text="No"
                                                            value={"false"}
                                                            name="rbAllowTheChoice"
                                                            id="rbAllowTheChoice"
                                                            errors={errors}
                                                            register={register}
                                                        ></NVLRadio>
                                                    </div>
                                                    <div
                                                        className={
                                                            " Center-Aligned-Items {invalid-Poll} text-red-500 text-sm "
                                                        }
                                                    >
                                                        {errors?.rbAllowTheChoice?.message}
                                                    </div>
                                                </div>
                                                <div>
                                                    <NVLTextbox
                                                        title=""
                                                        id="txtOptionStaticLimit1"
                                                        className={`nvl-Def-Label w-14 ${watch("rbAllowTheChoice") == "true"
                                                            ? ""
                                                            : "Disabled"
                                                            }`}
                                                        required
                                                        type="Text"
                                                        pattern="[0-9]{1,3}"
                                                        errors={errors}
                                                        register={register}
                                                    ></NVLTextbox>
                                                </div>
                                            </div>
                                            <NVLlabel
                                                text="Limit the number of responses allowed"
                                                className="nvl-Def-Label w-52"
                                            ></NVLlabel>
                                            <div className="flex gap-10">
                                                <div>
                                                    <div className="flex gap-10">
                                                        <NVLRadio
                                                            text="Yes"
                                                            value={"true"}
                                                            name="rbLimitTheResponse"
                                                            id="rbLimitTheResponse"
                                                            errors={errors}
                                                            register={register}
                                                        ></NVLRadio>
                                                        <NVLRadio
                                                            text="No"
                                                            value={"false"}
                                                            name="rbLimitTheResponse"
                                                            id="rbLimitTheResponse"
                                                            errors={errors}
                                                            register={register}
                                                        ></NVLRadio>
                                                    </div>
                                                    <div
                                                        className={
                                                            " Center-Aligned-Items {invalid-Poll} text-red-500 text-sm "
                                                        }
                                                    >
                                                        {errors?.rbLimitTheResponse?.message}
                                                    </div>
                                                </div>
                                                <NVLTextbox
                                                    title=""
                                                    id="txtOptionStaticLimit2"
                                                    className={`nvl-Def-Label w-14 ${watch("rbLimitTheResponse") == "true"
                                                        ? ""
                                                        : "Disabled"
                                                        }`}
                                                    required
                                                    type="Text"
                                                    pattern="[0-9]{1,3}"
                                                    errors={errors}
                                                    register={register}
                                                ></NVLTextbox>
                                            </div>
                                            <Options />
                                            <div className="flex flex-col sm:flex-row gap-4 ">
                                                <NVLButton
                                                    id="btnSubmit"
                                                    type="button"
                                                    text={"Add more option fields"}
                                                    className={
                                                        "w-48 nvl-button bg-primary text-white "
                                                    }
                                                    onClick={() => setState(state + 1)}
                                                ></NVLButton>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-4">
                                <NVLlabel
                                    text="Availablitiy"
                                    className="nvl-Def-Label w-52"
                                ></NVLlabel>
                                <DateTime register={register} errors={errors} watch={watch} />
                            </div>
                            <div className="flex flex-col sm:flex-row gap-4 ">
                                <NVLlabel
                                    className="nvl-Def-Label w-52"
                                    text="Results"
                                ></NVLlabel>
                                <div className="gap-16">
                                    <div className="grid">
                                        <NVLlabel
                                            className="nvl-Def-Label w-52"
                                            text="Publish results"
                                        ></NVLlabel>
                                        <NVLSelectField
                                            id="ddlResults"
                                            options={PublishResult}
                                            className="nvl-non-mandatory nvl-Def-Input"
                                            errors={errors}
                                            register={register}
                                        ></NVLSelectField>
                                    </div>
                                </div>
                            </div>
                            <div className="flex flex-col sm:flex-row gap-4 ">
                                <NVLlabel
                                    className="nvl-Def-Label w-52"
                                    id="lblgrade"
                                    text="Activity Completion"
                                ></NVLlabel>
                                <div className="">
                                    <ActivityCompletion register={register} errors={errors} watch={watch} />
                                    <CheckboxesInput
                                    register={register} errors={errors} watch={watch}
                                        IsViewTheActivity={true}
                                        IsMarkTheActivity={true}
                                        setValue={setValue}
                                    />
                                <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} tags={tags} props={props} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </section>
        </>
    );
}
export default PollActivity;