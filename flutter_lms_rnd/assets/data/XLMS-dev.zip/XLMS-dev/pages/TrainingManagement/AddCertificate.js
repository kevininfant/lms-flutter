import Container from '@components/Container/Container';
import { getXlmsTrainingBadgeCertificate, listXlmsCustomCertificate } from '@graphql/graphql/queries';
import Certificate from '@Pages/ActivityManagement/Certificate';
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';

export default function AddCertificate(props) {
    const router = useRouter();
    const [updatedCertificate, setUpdatedCertificate] = useState()

    useEffect(() => {

        const fetchCertificateInfo = (async () => {
            let Mode = decodeURIComponent(String(router.query["Mode"]));
            let TrainingId = decodeURIComponent(String(router.query["TrainingID"]));
            let TrainingName = decodeURIComponent(String(router.query["TrainingName"]));
            let TenantID = props?.user.attributes["custom:tenantid"];
            const isUpdateData = await AppsyncDBconnection(getXlmsTrainingBadgeCertificate,
                {
                    PK: "TENANT#" + TenantID,
                    SK: "TRAININGCERTIFICATE#" + TrainingId
                }
                , props?.user?.signInUserSession?.accessToken?.jwtToken);
                const certificateList = await AppsyncDBconnection(listXlmsCustomCertificate, { PK: "TENANT#" + TenantID, SK: "CUSTOMCERTIFICATE#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
                setUpdatedCertificate({
                TraningId: TrainingId,
                TrainingName: TrainingName,
                mode: Mode,
                TenantID: TenantID,
                Editdata: isUpdateData?.res?.getXlmsTrainingBadgeCertificate,
                user: props.user,
                TenantInfo: props?.TenantInfo,
                CertificateData: certificateList?.res?.listXlmsCustomCertificate?.items,
            })
        })
        fetchCertificateInfo()
        // return (e) => setUpdatedCertificate({})
    }, [props?.TenantInfo, props.user, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query])

    return (
        <Container loader={updatedCertificate == undefined}>
            <Certificate {...updatedCertificate} />
        </Container>)
}