import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { createXlmsBatchExternalTrainerInfo, deleteXlmsEmailAndMobileNumber } from "@graphql/graphql/mutations";
import { listXlmsExternalTrainerInfo } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useRef, useState } from "react";

export default function ExternalTrainerList(props) {
    const router = useRouter()
    const roleData = useRef(props?.RoleData)
    const [popupValues, setPopupValues] = useState({ PK: "", SK: "", Content: "", Type: "", UpdateData: {}, loader: false })
    const [search, setSearch] = useState("")
    const [isRefreshing, setIsRefreshing] = useState(true)
    const PageRoutes = useMemo(() => {
        return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: "/TrainingManagement/TrainingLocationList", breadcrumb: "Training Location List" },
        { path: "", breadcrumb: "External Trainer List" }]
    }, [])

    const headerColumn = [
        { HeaderName: "External Trainer Name", Columnvalue: "ExternalTrainerName", HeaderCss: "!w-4/12", },
        { HeaderName: "External Trainer MailID", Columnvalue: "ExternalTrainerMailID", HeaderCss: "!w-4/12", },
        { HeaderName: "External Trainer Contact Number", Columnvalue: "ExternalTrainerPhoneNo", HeaderCss: "!w-4/12", },
        {HeaderName: "Created Date", Columnvalue: "CreatedDate", HeaderCss: "!w-2/12", },
        { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-2/12", },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-1/12", },
    ]

    const variable = useMemo(() => { return { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#", IsDeleted: false } }, [props.TenantInfo.TenantID])

    const headerHandler = (e, url) => { e.preventDefault(); router.push(url); };

    const searchBoxVal = (e) => {
        setSearch(e);
        // setIsRefreshing((count) => {
        //     return count + 1;
        // });
    }

    const refreshGrid = useCallback(() => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    }, []);

    const cancelEvent = (e) => {
        e.preventDefault()
        resetPopup()
    }

    function popup(PK, SK, Content, Type, getItem) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: Type, UpdateData: getItem, loader: false })
    }
    function resetPopup() {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" })
    }

    async function updateField(e) {
        setPopupValues((temp) => { return { ...temp, loader: true } });
        document.getElementById("tableSearch") ? (document.getElementById("tableSearch").value = "") : ""
        e.preventDefault();// Default action that the event will not happened
        let isSuspend = false;
        let isDelete = false;
        let date = new Date().toISOString().substring(0, 19);
        if (popupValues?.Type == "Suspend") { isSuspend = true }
        if (popupValues?.Type == "Delete") { isDelete = true }
        if (popupValues?.Type == "Delete") {
            const existEmail = await AppsyncDBconnection(deleteXlmsEmailAndMobileNumber, { input: { PK: "XLMS#EMAIL", SK: "EMAILID#" + popupValues?.UpdateData?.ExternalTrainerMailID } }, props?.user.signInUserSession.accessToken.jwtToken)
            const existPhone = await AppsyncDBconnection(deleteXlmsEmailAndMobileNumber, { input: { PK: "XLMS#MOBILENO", SK: "MOBILENO#" + popupValues?.UpdateData?.ExternalTrainerPhoneNo } }, props?.user.signInUserSession.accessToken.jwtToken)
        }
        let variables = {
            input: [
                { ...popupValues?.UpdateData, IsDeleted: true },
                { ...popupValues?.UpdateData, SK: "EXTERNALTRAINERINFO#" + popupValues?.UpdateData?.ExternalTrainerID, LastModifiedDate: date, IsSuspend: isSuspend, IsDeleted: isDelete },
                { ...popupValues?.UpdateData, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#" + date + "#EXTERNALTRAINERID#" + popupValues?.UpdateData?.ExternalTrainerID, LastModifiedDate: date, IsSuspend: isSuspend, IsDeleted: isDelete }
            ]
        }
        const finalResponse = await AppsyncDBconnection(createXlmsBatchExternalTrainerInfo, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)
        if (finalResponse.Status == "Success") {
            refreshGrid()
        }
        resetPopup();
        setPopupValues((temp) => { return { ...temp, loader: false } });

    }

    const actionRestriction = useCallback((getItem) => {
        let actionInputList = [];
        if (roleData.current?.EditExternalTrainer && !getItem.IsSuspend) {
            actionInputList.push(
                {
                    id: 1,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Edit External Trainer",
                    action: () => { router.push(`/TrainingManagement/ExternalTrainer?&Mode=Edit&ExtTrainerID=${getItem.ExternalTrainerID}`) }
                }
            )
        }
        if (roleData.current?.ShowExternalTrainer && getItem.IsSuspend) {
            actionInputList.push(
                {
                    id: 2,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                    name: "Show External Trainer",
                    action: () => {
                        popup(
                            getItem.PK,
                            getItem.SK,
                            "Are you sure to show the external trainer?",
                            "",
                            getItem
                        )
                    }
                }
            )
        }
        if (roleData.current?.HideExternalTrainer && !getItem.IsSuspend) {
            actionInputList.push(
                {
                    id: 3,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                    name: "Hide External Trainer",
                    action: () => {
                        popup(
                            getItem.PK,
                            getItem.SK,
                            `${getItem?.MappedTraining != null && JSON.parse(getItem?.MappedTraining).length != 0 ? `External trainer have been mapped to ${JSON.parse(getItem?.MappedTraining).length} training session. Are you sure to hide the external trainer?` : "Are you sure to hide the external trainer?"}`,
                            "Suspend",
                            getItem
                        )
                    }
                }
            )
        }
        if (roleData.current?.DeleteExternalTrainer && getItem.IsSuspend) {
            actionInputList.push(
                {
                    id: 4,
                    Color: "text-rose-700",
                    Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                    name: "Delete External Trainer",
                    action: () => {
                        popup(
                            getItem.PK,
                            getItem.SK,
                            `${getItem?.MappedTraining != null && JSON.parse(getItem?.MappedTraining).length != 0 ? `External trainer have been mapped to ${JSON.parse(getItem?.MappedTraining).length} training session. Are you sure to delete the external trainer?` : "Are you sure to delete the external trainer?"}`,
                            "Delete",
                            getItem
                        )
                    }
                }
            )
        }
        return actionInputList;
    }, [router])

    function getDateFormat(CreatedDt) {
        return (new Date(CreatedDt).toDateString().substring(4))
      }

    const gridDataBind = useCallback(
        (viewData) => {
            const rowGrid = [];
            viewData && viewData.map((getItem, index) => {
                let actionList = [];
                actionList = actionRestriction(getItem)
                rowGrid.push({
                    PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
                    SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />),
                    ExternalTrainerName: (<NVLlabel id={"lblExternalTrainerName" + (index + 1)} name="ExternalTrainerName" text={getItem.ExternalTrainerName} />),
                    ExternalTrainerMailID: (<NVLlabel id={"lblExternalTrainerMailID" + (index + 1)} name="ExternalTrainerMailID" text={getItem.ExternalTrainerMailID} />),
                    ExternalTrainerPhoneNo: (<NVLlabel id={"lblExternalTrainerContactNumber" + (index + 1)} name="ExternalTrainerPhoneNo" text={getItem.ExternalTrainerPhoneNo} />),
                    CreatedDate: <NVLlabel id={"txtdate"+(index+1)} text={getDateFormat(getItem.CreatedDate)}/>,
                    Status: (
                        <>
                            <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                                <div className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"}	`} />
                                <NVLlabel className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2	`} text={!getItem.IsSuspend ? "Active" : "Inactive"} />
                            </div>
                        </>
                    ),
                    Action: (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionList} index={(index + 1) > 10 ? (index + 1) % 10 : index + 1} />),
                });
            });
            return rowGrid;
        }, [actionRestriction]
    );
    return (
        <>
            <Container title="External trainer list" PageRoutes={PageRoutes}>
                <NVLHeader className={"!w-4/7"} TabRouting={props?.GeneralRoleData?.AllowNewTab} IsSearch={props.RoleData?.ExternalTrainerKeywordSeTenanth ? true : false} ButtonID5="btnExternalTrainer" LinkName5="+ Add External Trainer" className5={roleData.current?.AddExternalTrainer ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectHome={"/"} RedirectAction5={(e) => headerHandler(e, "/TrainingManagement/ExternalTrainer?Mode=Create")} href5="/TrainingManagement/ExternalTrainer?Mode=Create" placeholder={"Search by Trainer name"} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshGrid} RedirectAction4={() => refreshGrid()} IsNestedHeader />
                <div className="max-w-full w-full justify-center">
                    <NVLGridTable HeaderColumn={headerColumn} GridDataBind={gridDataBind} Search={search} id="tblExternalTrainerList" refershPage={isRefreshing} user={props.user}
                        query={listXlmsExternalTrainerInfo}
                        querryName={"listXlmsExternalTrainerInfo"}
                        variable={variable}
                    />
                </div>
                <NVLModalPopup ButtonYestext="Yes" loader={popupValues.loader} SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopup()} Content={popupValues.Content} />
            </Container>
        </>
    )
}
