import NVLCheckbox from '@components/Controls/NVLCheckBox';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLMultilineTxtbox from '@components/Controls/NVLMultilineTxtBox';
import NVLRadio from '@components/Controls/NVLRadio';
import NVLSelectField from '@components/Controls/NVLSelectField';
import { getXlmsTrainingManagement } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from 'next/router';
import { useCallback, useEffect, useState } from 'react';

import Container from '@components/Container/Container';
import { yupResolver } from "@hookform/resolvers/yup";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

export default function TrainingTemplatePreview(props) {

    const router = useRouter();
    const [previewTemplate, setPreviewTemplate] = useState()

    const validationSchema = Yup.object().shape({})
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true, };
    const { register, handleSubmit, reset, formState, setFocus, watch, setValue } = useForm(formOptions);
    const { errors } = formState;
    const sortusingpostion = useCallback((QuesAns) => {
        if (QuesAns && Object.values(QuesAns).length > 0) {
            var sorted = Object.values(QuesAns).sort(function (a, b) {
                return a.Position - b.Position;
            });
            return sorted;
        }
        return [];
    }, []);
    useEffect(() => {
        async function fetchPreviewTemplate() {
            let trainingID = decodeURIComponent(String(router.query["TrainingID"]));
            let templateID = decodeURIComponent(String(router.query["TemplateID"]));
            let activityType = decodeURIComponent(String(router.query["ActivityType"]));
            let assessmentType = decodeURIComponent(String(router.query["AssessmentType"]));
            const trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAININGINFO#" + trainingID }, props?.user.signInUserSession.accessToken.jwtToken)

            setPreviewTemplate(assessmentType != undefined ? {
                Name: trainingData?.res?.getXlmsTrainingManagement?.TrainingName, Template: trainingData?.res?.getXlmsTrainingManagement &&
                    JSON.parse(trainingData?.res?.getXlmsTrainingManagement?.QuestionandOptions)?.[activityType]?.Template
            } : {
                Name: trainingData?.res?.getXlmsTrainingManagement?.TrainingName, Template: trainingData?.res?.getXlmsTrainingManagement &&
                    JSON.parse(trainingData?.res?.getXlmsTrainingManagement?.QuestionandOptions)?.[assessmentType]?.Template
            })
        }
        fetchPreviewTemplate()

    }, [props?.TenantInfo?.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query])

    const getOptionData = useCallback((Options) => {
        let optionsData = [];
        for (let i = 0; i < Options?.length; i++) {
            optionsData?.push({ value: Options[i], text: Options[i] });
        }
        return optionsData;
    }, []);
    const PageRoutes = [
        { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${decodeURIComponent(String(router.query["TrainingID"]))}&TrainingName=${previewTemplate?.name}`, breadcrumb: "Training Template List" },
        { path: "", breadcrumb: "Training Template Preview" }
    ];
    return (

        previewTemplate?.Template != undefined &&
        <Container title="Template Preview" PageRoutes={PageRoutes}>
            <div className="m-2">
                {Array.from(sortusingpostion(previewTemplate?.Template)).map((item, index) => {
                    return (
                        <>
                            <div key={index} className="">
                                <div className="p-2 w-full">
                                    <div className="pt-2 grid gap-4">
                                        <div className="w-full break-all flex gap-4">
                                            {item?.Question != undefined && (
                                                <NVLlabel showFull text={index + 1 + "  " + item.Label + " " + item?.Question?.replace(/(<([^>]+)>)/gi, "")} />
                                            )}
                                        </div>
                                        <div className="flex gap-4">
                                            <div className={`${item?.Adjustment == "Horizontal" ? "flex gap-4" : ""} `} key={index}>
                                                {item?.OptionType == "Multiple Answer" ? (
                                                    item?.Options.map((item, index) => {
                                                        return (
                                                            <>
                                                                <div className="gap-3">
                                                                    <NVLCheckbox id={"chkoption" + index} text={item} value={"Multiple Answer"} errors={props.errors} register={register}></NVLCheckbox>
                                                                </div>
                                                            </>
                                                        );
                                                    })
                                                ) : item?.OptionType == "Single Answer" ? (
                                                    item?.Options.map((radioItem, index) => {
                                                        return (
                                                            <>
                                                                <div className="gap-3" key={index}>
                                                                    <NVLRadio id={"rboption" + index} text={radioItem} name={"rbOptions" + item?.Question} value={item} errors={props.errors} register={register}></NVLRadio>
                                                                </div>
                                                            </>
                                                        );
                                                    })
                                                ) : item?.OptionType == "Dropdown" ? (
                                                    <>
                                                        <div className="gap-3" key={index}>
                                                            <NVLSelectField id={"ddloption" + index} options={getOptionData(item.Options)} className="nvl-Def-Input" errors={props.errors} register={register} />
                                                        </div>
                                                    </>
                                                ) : item?.AddQuestionType == "Short Answer" ? (
                                                    <>
                                                        <div className="gap-3" key={index}>
                                                            <NVLMultilineTxtbox id={"txtShortOption" + index} className="nvl-Def-Input resize-y" errors={props.errors} register={register} />
                                                        </div>
                                                    </>
                                                ) : item?.AddQuestionType == "Information" ? (
                                                    <>
                                                        <div className="gap-3" key={index}>
                                                            <NVLlabel id={"lblInfoType" + index} text={item.InformationType} className="font-bold" />
                                                        </div>
                                                    </>
                                                ) : (
                                                    <></>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>
                    );
                })}
            </div>
        </Container >
    )
}
