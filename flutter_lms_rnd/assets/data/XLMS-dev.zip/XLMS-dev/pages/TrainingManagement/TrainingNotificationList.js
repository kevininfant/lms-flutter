import SendNotificationList from "@Pages/ActivityManagement/SendNotificationList";
import { useRouter } from "next/router";

function TrainingNotficationList(props) {
    const router = useRouter();
    
    return (
        <div>
            <SendNotificationList user={props.user} 
                TenantInfo={props.TenantInfo} 
                TrainingID={router.query["TrainingID"]}
                GeneralRoleData={props.GeneralRoleData} 
                RoleData={props.RoleData} 
                props={props}/>
        </div>
    );
}

export default TrainingNotficationList;
