import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { createXlmsBatchInventoryInfo, createXlmsBatchTrainingLocationInfo } from "@graphql/graphql/mutations";
import { listXlmsInventoryInfo, listXlmsTrainingLocationInfo } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";


function LocationList(props){
    const router = useRouter()
    const [popupValues,setPopupValues] = useState({PK: "", SK: "", Content: "", Type: "",UpdateData:{},loader:false})
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("")

    const PageRoutes = useMemo(() => {
        return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management"},
            { path: "", breadcrumb: "Training Location List"}]
    }, [])
    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
      };
    
    const headerColumn = [
        {HeaderName: "Training Location", Columnvalue: "Location", HeaderCss: "!w-3/12", },
        {HeaderName: "Training Venue", Columnvalue: "Venue", HeaderCss: "!w-3/12", },
        {HeaderName: "Training Hall Capacity", Columnvalue: "Capacity", HeaderCss: "!w-2/12", },
        {HeaderName: "Created Date", Columnvalue: "CreatedDate", HeaderCss: "!w-2/12", },
        {HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-1/12", },
        {HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-1/12", }
    ]  

    const popup = (Type,PK,SK,Content,getItem)=>{
        setPopupValues({PK:PK,SK:SK,Type:Type,Content:Content,UpdateData:getItem,loader:false})
    }

    const resetPopUp = () =>{
        setPopupValues({PK:"",SK:"",Type:"",Content:"",UpdateData:{},loader:false})
        document.getElementById("tableSearch").value = "";
    } 

    const searchBoxVal = (e) => {
      setSearch(e);
      setIsRefreshing((count) => {
        return count + 1;
      });
    }
  
    const refreshGrid = useCallback(() => {
      setSearch("");
      setIsRefreshing((count) => {
        return count + 1;
      });
    },[]);

    async function updateField(e) {
      setPopupValues((temp) => { return { ...temp, loader: true } });
        e.preventDefault() 
        let isSus = false;
        let isDelete= false;
        if (popupValues.Type == "isSuspend") {
            isSus = true ;
        } else if(popupValues.Type == "isDelete"){
            isDelete =true;
        }
        let LocationID = popupValues.SK?.substring(popupValues.SK?.lastIndexOf("#")+1)
        let locationVariable= {input:[{...popupValues.UpdateData, IsDeleted : true , AutoDelete : Date.now()/1000 + 24*60 |0 },
            {...popupValues.UpdateData, SK:"TRAININGLOCATIONINFO#" + LocationID, LastModifiedDate:new Date().toISOString() ,IsSuspend: isSus , IsDeleted : isDelete},
            {...popupValues.UpdateData,SK:"TRAININGLOCATIONINFO#LASTMODIFIED#"+ new Date().toISOString() +"#LOCATIONID#"+ LocationID ,LastModifiedDate:new Date().toISOString(),IsSuspend: isSus , IsDeleted : isDelete} 
        ]}
    
        let finalStatus = await AppsyncDBconnection(createXlmsBatchTrainingLocationInfo,locationVariable, props?.user.signInUserSession.accessToken.jwtToken)
          
            if (popupValues.Type == "isDelete" && finalStatus.Status == "Success") {
            let inventoryList = await AppsyncDBconnection(listXlmsInventoryInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "INVENTORYINFO#LASTMODIFIEDDATE#",InventoryType:"InventoryList", IsDeleted:false}, props?.user.signInUserSession.accessToken.jwtToken)
            let MappedInventories,unSelectedVariables=[];
            MappedInventories = inventoryList.res?.listXlmsInventoryInfo.items.filter((getItem)=>{
              return ( JSON.parse(popupValues.UpdateData.Inventory).some((data)=>{return data.value == getItem.InventoryId}))
            })
            MappedInventories.map((inventory)=>{
              let Unselected = inventory.MappedLocationID != null ? JSON.parse(inventory?.MappedLocationID)?.filter((getItem)=>{ return getItem.LocationID != popupValues.UpdateData.LocationID }) : []
              unSelectedVariables = [...unSelectedVariables,{ ...inventory, MappedLocationID : JSON.stringify(Unselected)},
                  { ...inventory,SK:"INVENTORYINFO#"+inventory.InventoryId, MappedLocationID : JSON.stringify(Unselected)}]
          })
          await AppsyncDBconnection(createXlmsBatchInventoryInfo,{ input : unSelectedVariables}, props?.user?.signInUserSession?.accessToken?.jwtToken)
        }

        refreshGrid()
        setPopupValues((temp) => { return { ...temp, loader: true } });
        resetPopUp()
    }

    const ActionRestriction = useCallback((getItem)=>{
        let actionList = [];
        if ( props?.RoleData?.ShowTrainingLocation && getItem.IsSuspend) {
            actionList.push(
              {
                id: 1,
                Color: "text-yellow-600",
                Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                name: "Show Training Location",
                action: () => popup("",getItem.PK,getItem.SK,"Are you sure to show the training location?",getItem),
              }
            )
          } 
          if (props?.RoleData?.DeleteTrainingLocation && getItem.IsSuspend) {
            actionList.push(
              {
                id: 2, 
                Color: "text-rose-700",
                Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                name: "Delete Training Location",
                action: () => popup("isDelete",getItem.PK,getItem.SK,
                `${getItem?.MappedTraining != null && JSON.parse(getItem?.MappedTraining).length != 0  ? 
                  `Training location have been mapped to ${JSON.parse(getItem?.MappedTraining).length} training program . Are you sure to delete the training location?` :  "Are you sure to delete the training location?" }`,
                getItem),
              }
            )
          }
          if (props?.RoleData?.EditTrainingLocation && !getItem.IsSuspend) {
            actionList.push(
              {
                id: 3,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit Training Location",
                action: () => router.push(`/TrainingManagement/TrainingLocation?LocationID=${getItem.LocationID}`),
              }
            )
          }
          if (props?.RoleData?.HideTrainingLocation && !getItem.IsSuspend) {
            actionList.push(
              {
                id: 4,
                Color: "text-yellow-600",
                Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                name: "Hide Training Location",
                action: () => popup("isSuspend",getItem.PK,getItem.SK,
                `${getItem?.MappedTraining != null && JSON.parse(getItem?.MappedTraining).length != 0  ? 
                  `Training location have been mapped to ${JSON.parse(getItem?.MappedTraining).length} training program . Are you sure to hide the training location?` :  "Are you sure to hide the training location?" }`,
                getItem),
              }
            )
          }
          return actionList;
    },[props?.RoleData?.DeleteTrainingLocation, props?.RoleData?.EditTrainingLocation, props?.RoleData?.HideTrainingLocation, props?.RoleData?.ShowTrainingLocation, router])

    function getDateFormat(CreatedDt) {
      return (new Date(CreatedDt).toDateString().substring(4))
    }

    const gridDataBind = useCallback((viewData)=>{
          const rowGrid = []
          viewData && viewData.map((getItem,index)=>{
            rowGrid.push({
               PK:<NVLlabel id={"txtPK"+(index+1)} text={getItem.PK}/>,
               SK:<NVLlabel id={"txtSK"+(index+1)} text={getItem.SK}/>,
               LocationID:<NVLlabel id={"txtLocationID"+(index+1)} text={getItem.LocationID}/>,
               Location: <NVLlabel id={"txtLocation"+(index+1)} text={getItem.TrainingLocation}/>,
               Venue:<NVLlabel id={"txtVenue"+(index+1)} text={getItem.TrainingVenue}/>,
               Capacity:<NVLlabel id={"txtCapacity"+(index+1)} className="px-14" text={getItem.TrainingHallCapacity}/>,
               CreatedDate: <NVLlabel id={"txtdate"+(index+1)} text={getDateFormat(getItem.CreatedDate)}/>,
               Status: <>
               <div className="flex my-auto w-full"> 
               <div className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"}` }></div>
               <NVLlabel id={"status"+ (index+1)} text={getItem.IsSuspend ? "Inactive" : "Active"} className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2`}/>
               </div> 
               </>,
               Action: <NVLRapidModal id={"action"+(index+1)} ActionList={ActionRestriction(getItem)}/>,
            })
          })
          
          return rowGrid;
    },[ActionRestriction])
    const variable = useMemo(() => { return {PK:"TENANT#"+props.TenantInfo.TenantID, SK:"TRAININGLOCATIONINFO#LASTMODIFIED#", IsDeleted:false}},[props.TenantInfo.TenantID])

    const cancelClick =(e)=>{
      e.preventDefault()
      resetPopUp()
      refreshGrid()
    }

return (
    <>
    <Container title="Training location list" PageRoutes={PageRoutes}>
    <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} IsSearch={props?.RoleData?.LocationKeywordSeTenanth ? true : false} RedirectHome={"/"} placeholder={"Search by Training location"} IsNestedHeader SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshGrid} RedirectAction2={()=>refreshGrid()}
    ButtonID5="btnTrainingLocation" LinkName5="+ Add Training Location" className5={props?.RoleData.AddTrainingLocation ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectAction5={(e) => headerHandler(e, "/TrainingManagement/TrainingLocation")} href5="/TrainingManagement/TrainingLocation?Mode=Create" 
    ButtonID4="btnInventoryList" LinkName4="Inventory Type List" className4={props?.RoleData.InventoryTypeList ?(props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectAction4={(e) => headerHandler(e, "/TrainingManagement/InventoryTypeList")} href4="/TrainingManagement/InventoryTypeList" 
    ButtonID3="btnTrainerList" LinkName3="External Trainer List" className3={props?.RoleData.ExternalTrainerList ?(props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectAction3={(e) => headerHandler(e, "/TrainingManagement/ExternalTrainerList")} href3="/TrainingManagement/ExternalTrainerList"/>
     <div className="max-w-full w-full justify-center">
      <NVLGridTable user={props.user}
            refershPage={isRefreshing}
            id="tblInventoryList" Search={search}
            HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsTrainingLocationInfo}
            querryName={"listXlmsTrainingLocationInfo"}
            variable={variable}/>
            </div>
        <NVLModalPopup ButtonYestext="Yes" loader={popupValues.loader} SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelClick(e)} ButtonNotext="No"  CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />

    </Container>
    </>
)
}
export default LocationList;