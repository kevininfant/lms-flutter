import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLMultiSelect from "@components/Controls/NVLMultiSelect";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsBatchInventoryInfo, createXlmsBatchTrainingLocationInfo } from "@graphql/graphql/mutations";
import { getXlmsTrainingLocationInfo, listXlmsInventoryInfo } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import NVLlabel from "../../components/Controls/NVLlabel";

function TrainingLocation(props) {
  const [multiselected, setMultiSelected] = useState([]);
    const router = useRouter()
    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/TrainingManagement/TrainingLocationList")
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);
    const [pageData,setPageData] = useState()

   useEffect(()=>{
    async function getData(){
        let inventoryList = await AppsyncDBconnection(listXlmsInventoryInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "INVENTORYINFO#LASTMODIFIEDDATE#",InventoryType: "InventoryActiveList", IsDeleted: false,IsSuspend:false }, props?.user.signInUserSession.accessToken.jwtToken)
        let editData = await AppsyncDBconnection(getXlmsTrainingLocationInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGLOCATIONINFO#" + router.query["LocationID"] }, props?.user.signInUserSession.accessToken.jwtToken)
        setPageData({
        InventoryList : inventoryList.res?.listXlmsInventoryInfo.items,
        locationData:editData.res?.getXlmsTrainingLocationInfo,
        Mode: editData.res?.getXlmsTrainingLocationInfo != null && editData.res?.getXlmsTrainingLocationInfo != undefined ? "Edit" :"Create",
      })
    }
    getData()
   },[props.TenantInfo.TenantID, props?.user.signInUserSession.accessToken.jwtToken, router.query])

    const validationSchema = Yup.object().shape({
        txtLocationName: Yup.string().required("Training location is required").min(3,"Required minimum of 3 characters")
        .matches(Regex("AlphaNumWithAllowedSpecialChar"),"Training location is invalid").max(250,"Maximum limit exceeds").nullable() ,
        txtVenue:Yup.string().required("Training venue is required").min(3,"Required minimum of 3 characters")
        .matches(Regex("AlphaNumWithAllowedSpecialChar"),"Training venue is invalid").max(250,"Maximum limit exceeds").nullable(),
        txtVenueAddress:Yup.string().required("Training venue address is required").min(3,"Required minimum of 3 characters").max(250,"Maximum limit exceeds").nullable(),
        txtHallName:Yup.string().required("Training hall name is required").min(3,"Required minimum of 3 characters")
        .matches(Regex("AlphaNumWithAllowedSpecialChar"),"Training hall name is invalid").max(250,"Maximum limit exceeds").nullable(),
        txtHallCapacity:Yup.string().required("Training hall capacity is required")
        .matches(Regex("AllowOnlyNumbers"),"Training hall capacity is invalid").max(3,"Maximum limit exceeds").test("","",(e,{createError})=>{
          if (e!= "") {
            if (parseInt(e) == 0) return createError({message : "Training hall capacity should be greater than zero"})
          }
          if (pageData.Mode == "Edit"){
              if ((pageData?.locationData?.MappedTraining !="" || pageData?.locationData?.MappedTraining != null) && (JSON.parse(pageData?.locationData?.MappedTraining))?.length > 0 && parseInt(e) != pageData?.locationData?.TrainingHallCapacity) {
                return createError({message : `The hall capacity cannot be changed. ${(JSON.parse(pageData?.locationData?.MappedTraining))?.length} training program(s) has been mapped to this location.
                If necessary edit the batch size.`})
              }
          } 
          return true
        }).nullable(),
    })

    const finalResponse = useCallback((finalStatus) => {
         if (finalStatus != "Success") {
             setModalValues({
                 ModalInfo: "Danger",
                 ModalTopMessage: "Error",
                 ModalBottomMessage: finalStatus,
             });
             ModalOpen();
             return;
         } else {
             setValue("submit", true);
             setModalValues({
                 ModalInfo: "Success",
                 ModalOnClickEvent: () => {
                     router.push("/TrainingManagement/TrainingLocationList")
                 },
             });
             ModalOpen();
         }
    }, [router, setValue]);

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, formState, clearErrors } = useForm(formOptions);
    const { errors } = formState;
    const submitHandler = async (data) => {
        document?.activeElement?.blur();
        setValue("submit", true)
        const PK = "TENANT#" + props.TenantInfo.TenantID
        const LocationID = pageData?.Mode != "Edit" ? crypto.randomUUID().toString(25).substring(2, 12) : pageData?.locationData?.LocationID
        const query = createXlmsBatchTrainingLocationInfo
        const date = new Date().toISOString();

        const inventoryList = await AppsyncDBconnection(listXlmsInventoryInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "INVENTORYINFO#LASTMODIFIEDDATE#",InventoryType: "InventoryList", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
        const allInventory = inventoryList.res?.listXlmsInventoryInfo.items 
        const inventorySelected = allInventory?.filter((getItem)=>{
            return (multiselected.some((data)=>{
                return data.value == getItem.InventoryId
             }))
            })
        const inventoryUnSelected = allInventory?.filter((getItem)=>{
            return (!multiselected.some((data)=>{
                return data.value == getItem.InventoryId
             }))
            })   

        let selectedVariables =[] , unSelectedVariables = [] ,finalResult;
        
        const createVariables = {
            input: [
                {PK: PK,SK: "TRAININGLOCATIONINFO#"+ LocationID ,LocationID: LocationID,TrainingLocation:data.txtLocationName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenue: data.txtVenue?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenueAddress: data.txtVenueAddress?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallName: data.txtHallName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallCapacity: parseInt(data.txtHallCapacity),Inventory: JSON.stringify(multiselected),IsSuspend: false,IsDeleted: false,CreatedBy: props.user?.username,CreatedDate: date,LastModifiedBy: props.user?.username,LastModifiedDate: date},
                {PK: PK,SK: "TRAININGLOCATIONINFO#LASTMODIFIED#"+ date+"#LOCATIONID#"+LocationID, LocationID: LocationID,TrainingLocation:data.txtLocationName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenue: data.txtVenue?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenueAddress: data.txtVenueAddress?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallName: data.txtHallName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallCapacity: parseInt(data.txtHallCapacity),Inventory: JSON.stringify(multiselected),IsSuspend: false,IsDeleted: false,CreatedBy: props.user?.username,CreatedDate: date,LastModifiedBy: props.user?.username,LastModifiedDate: date}
            ]
        }

        const updateVariables = {
            input: [
                {...pageData?.locationData,SK: "TRAININGLOCATIONINFO#LASTMODIFIED#"+ pageData?.locationData?.LastModifiedDate +"#LOCATIONID#"+ LocationID,IsDeleted: true , AutoDelete : Date.now()/1000 + 24*60 |0 },
                {...pageData?.locationData,TrainingLocation:data.txtLocationName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenue: data.txtVenue?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenueAddress: data.txtVenueAddress?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallName: data.txtHallName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallCapacity: parseInt(data.txtHallCapacity),Inventory: JSON.stringify(multiselected),IsSuspend: false,IsDeleted: false,LastModifiedBy: props.user?.username,LastModifiedDate: date},
                {...pageData?.locationData,SK:"TRAININGLOCATIONINFO#LASTMODIFIED#"+ date +"#LOCATIONID#"+LocationID ,TrainingLocation:data.txtLocationName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenue: data.txtVenue?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingVenueAddress: data.txtVenueAddress?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallName: data.txtHallName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),TrainingHallCapacity: parseInt(data.txtHallCapacity),Inventory: JSON.stringify(multiselected),IsSuspend: false,IsDeleted: false,LastModifiedBy: props.user?.username,LastModifiedDate: date}
            ]
        }
        const variables = pageData?.Mode != "Edit" ? createVariables : updateVariables
        finalResult = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status
        
        if (finalResult == "Success" && pageData.InventoryList.length > 0) {
            async function updateInventory(variables) { 
               finalResult = (await AppsyncDBconnection(createXlmsBatchInventoryInfo,{ input : variables}, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status
            }
            
            inventoryUnSelected.map((inventory)=>{
                let Unselected = inventory.MappedLocationID != null ? JSON.parse(inventory?.MappedLocationID)?.filter((getItem)=>{ return getItem.LocationID != LocationID }) : []
                unSelectedVariables = [...unSelectedVariables,{ ...inventory, MappedLocationID : JSON.stringify(Unselected)},
                    { ...inventory,SK:"INVENTORYINFO#"+inventory.InventoryId, MappedLocationID : JSON.stringify(Unselected)}]
            })
            if (unSelectedVariables.length != 0) {
                updateInventory(unSelectedVariables)
            } 
            inventorySelected.map((inventory)=>{
                let newVar = inventory.MappedLocationID != null ? [...JSON.parse(inventory?.MappedLocationID),{TrainingLocation : data.txtLocationName?.replace(/\s{2,}(?!\s)/g, ' ').trim() , LocationID: LocationID }] : [{TrainingLocation : data.txtLocationName?.replace(/\s{2,}(?!\s)/g, ' ').trim() , LocationID: LocationID }]
                let UniqueListSelected = [...new Map(newVar.map(item => [item["LocationID"], item])).values()]
                selectedVariables = [...selectedVariables,{ ...inventory, MappedLocationID : JSON.stringify(UniqueListSelected)},
            { ...inventory, SK : "INVENTORYINFO#"+ inventory.InventoryId, MappedLocationID : JSON.stringify(UniqueListSelected)}]
                }) 
            if (selectedVariables.length != 0) {
                updateInventory(selectedVariables)
            }   
        }
        finalResponse(finalResult)
        setValue("submit", false)
    }
    const PageRoutes = useMemo(() => {
        return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: "/TrainingManagement/TrainingLocationList", breadcrumb: "Training Location List" },
        { path: "", breadcrumb: pageData?.Mode != "Edit" ?  "Add Training Location" : "Edit Training Location" }]
    }, [pageData?.Mode])

    const MultiSelectList = useMemo(()=>{
        const inventory = [];
        pageData?.InventoryList.length > 0 &&
        pageData?.InventoryList.map((data)=>{
            inventory.push({value:data.InventoryId,label:data.InventoryName})
        })
        return inventory;
    },[pageData?.InventoryList])
    
    useEffect(()=>{
        if(pageData?.Mode == "Edit") {
            setValue("txtLocationName", pageData?.locationData?.TrainingLocation)
            setValue("txtVenue", pageData?.locationData?.TrainingVenue)
            setValue("txtVenueAddress", pageData?.locationData?.TrainingVenueAddress)
            setValue("txtHallName", pageData?.locationData?.TrainingHallName)
            setValue("txtHallCapacity",pageData?.locationData?.TrainingHallCapacity)
            let editData = JSON.parse(pageData?.locationData?.Inventory).filter((getItem)=>{
               return (pageData?.InventoryList.some((data)=>{
                    return data.InventoryId == getItem.value
                }))
            })
            setMultiSelected(editData)
        }
    },[pageData?.InventoryList, pageData?.Mode, pageData?.locationData?.Inventory, pageData?.locationData?.TrainingHallCapacity, pageData?.locationData?.TrainingHallName, pageData?.locationData?.TrainingLocation, pageData?.locationData?.TrainingVenue, pageData?.locationData?.TrainingVenueAddress, setValue])

    const clearField = useCallback(() => {
        setValue("txtLocationName", "")
        setValue("txtVenue", "")
        setValue("txtVenueAddress", "")
        setValue("txtHallName", "")
        setValue("txtHallCapacity", "")
        clearErrors()
        setMultiSelected([])
    }, [clearErrors, setValue])

    const overrideStrings = useMemo(() => {
        return {
            "allItemsAreSelected":  "All Inventories are selected" ,
            "noOptions": "No Inventory found",
            "selectSomeItems": "Select Inventory",
        }
    }, [])

    return (
        <>
            <Container title={pageData?.Mode != "Edit" ? "Add Training Location" : "Edit Training Location"} loader={pageData!= undefined ? false : true} PageRoutes={PageRoutes}>
                <form onSubmit={handleSubmit(submitHandler)} id="divLocation">
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className={watch("submit")? "nvl-FormContent pointer-events-none" : "nvl-FormContent"}>
                        <NVLTextbox id="txtLocationName" labelText="Training location" labelClassName="nvl-Def-Label pb-1" title="Training location" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <NVLTextbox id="txtVenue" labelText="Training venue" labelClassName="nvl-Def-Label pb-1" title="Training venue" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <NVLTextbox id="txtVenueAddress" labelText="Training venue address" labelClassName="nvl-Def-Label pb-1" title="Training venue address" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <NVLTextbox id="txtHallName" labelText="Training hall name" labelClassName="nvl-Def-Label pb-1" title="Training hall name" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <NVLTextbox id="txtHallCapacity" labelText="Training hall capacity" labelClassName="nvl-Def-Label pb-1" title="Training hall capacity" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <NVLlabel text="Inventory" className="nvl-Def-Label pb-1"/>
                        <NVLMultiSelect id="ddlInventory" overrideStrings={overrideStrings} className="nvl-Def-Input " options={MultiSelectList} value={multiselected} onChange={(event) => { setMultiSelected(event)} } />
                        <div className="flex justify-center gap-2 pt-4">
                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Save" : ""} type="submit" className={"w-32 nvl-button bg-primary text-white"}>
                                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                            </NVLButton>
                            <NVLButton id="btnCancel" text={pageData?.Mode != "Edit" ? "Clear" : "Cancel"} type="button" className="nvl-button w-28" onClick={() => pageData?.Mode != "Edit" ? clearField() : router.push("/TrainingManagement/TrainingLocationList")}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    )
}

export default TrainingLocation