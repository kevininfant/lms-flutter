import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsBatchExternalTrainerInfo, createXlmsBatchTrainingLocationInfo, createXlmsBatchTrainingManagement, createXlmsBatchTrainingSessionInfo, createXlmsTrainingManagementActivityInfo, deleteXlmsTrainingManagementActivityInfoInput, updateXlmsTrainingManagementActivityInfo } from "@graphql/graphql/mutations";
import { getXlmsTrainingManagement, getXlmsTrainingTemplate, listXlmsExternalTrainerInfo, listXlmsTrainingLocationInfo, listXlmsTrainingManagement, listXlmsTrainingManagementActivityInfos, listXlmsTrainingSessionInfos, listXlmsTrainingTemplateInfos, listXlmsUserListInfos } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";

function CreateTraining(props) {
  const [message, setMessage] = useState("");
  const router = useRouter()
  const [trainingPage, setTrainingPage] = useState({})
  const stDate = useRef();
  const trainingType = useRef("")
  const trainerType = useRef("")
  const sessionStart = useRef(false)
  const radioButtonRequired = useRef({ Survey: "No", Feedback: "No" })
  const [editValue, setEditValue] = useState(false)
  const locations = useRef([])

  const initialModalState = {
    ModalType: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      router.push("/TrainingManagement/TrainingManagementList")
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);
  useEffect(() => {
    async function dataFetch() {
      const locationList = await AppsyncDBconnection(listXlmsTrainingLocationInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGLOCATIONINFO#LASTMODIFIED#", TrainingLocationType: "LocationActiveList", IsDeleted: false, IsSuspend: false }, props?.user.signInUserSession.accessToken.jwtToken)
      const userList = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "#USERINFO#", IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
      const internalTrainers = userList?.res?.listXlmsUserListInfos?.items?.filter((data) => { return data.RoleName == "Trainer" })
      const externalTrainers = await AppsyncDBconnection(listXlmsExternalTrainerInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#", ExternalType: "ExternalTypeActiveList", IsDeleted: false, IsSuspend: false }, props?.user.signInUserSession.accessToken.jwtToken)
      const trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGINFO#" + router.query["TrainingID"] }, props?.user.signInUserSession.accessToken.jwtToken)
      const trainingList = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGINFO#LASTMODIFIEDDATE#", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
      const surveyTemplatesList = await AppsyncDBconnection(listXlmsTrainingTemplateInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGQUESTIONNAIRETEMPLATE#", IsDeleted: false, TemplateType: "Survey" }, props?.user.signInUserSession.accessToken.jwtToken)
      const feedbackTemplatesList = await AppsyncDBconnection(listXlmsTrainingTemplateInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGQUESTIONNAIRETEMPLATE#", IsDeleted: false, TemplateType: "Feedback" }, props?.user.signInUserSession.accessToken.jwtToken)

      const tempFeed = feedbackTemplatesList?.res?.listXlmsTrainingTemplateInfos?.items ? feedbackTemplatesList?.res?.listXlmsTrainingTemplateInfos?.items : [];
      setTrainingPage({
        Mode: trainingData.res?.getXlmsTrainingManagement != null && trainingData.res?.getXlmsTrainingManagement != undefined ? "Edit" : "Create",
        LocationList: locationList.res?.listXlmsTrainingLocationInfo?.items,
        InternalTrainer: internalTrainers,
        ExternalTrainer: externalTrainers.res?.listXlmsExternalTrainerInfo?.items,
        TrainingData: trainingData.res?.getXlmsTrainingManagement,
        TrainingList: trainingList.res?.listXlmsTrainingManagement?.items,
        SurveyTemplates: surveyTemplatesList.res?.listXlmsTrainingTemplateInfos?.items,
        FeedbackTemplatesList: tempFeed,
      })
    }
    dataFetch()
  }, [props.TenantInfo.TenantID, props?.user.signInUserSession.accessToken.jwtToken, router.query])

  const setField = (e) => {
    setValue("txtWaitingList", "")
    if (e == "Open") {
      setValue("chkApproval", true)
    } else {
      setValue("chkApproval", false)
    }
  }

  const validationSchema = Yup.object().shape({
    txtProgramName: Yup.string().required("Program name is required").matches(Regex("AlphanumSpecialCharModified"), "Program name is invalid")
      .max(250, "Maximum limit exceeds")
      .test("", "Program name already exists", (e) => {
        let programList = trainingPage?.TrainingList
        let nameExist = programList && programList.some((program) => program?.TrainingName?.toLocaleLowerCase() == e?.toLocaleLowerCase())
        if (nameExist && (trainingPage?.Mode == "Edit" || trainingPage?.Mode == "Create") && e?.toLowerCase() != trainingPage?.TrainingData?.TrainingName?.toLowerCase()) {
          if (e?.toLowerCase() != trainingPage?.TrainingData?.TrainingName?.toLowerCase()) {
            return false;
          }
        }
        return true
      })
      .nullable(),
    ddlProgramType: Yup.string().required("Program type is required")
      .test("", "", (e) => {
        if (e != trainingType.current && trainingType.current != undefined) {
          trainingType.current = e;
          setField(e)
        }
        return true
      })
      .nullable(),
    txtSession: Yup.string().required("Session name is required").min(3, "Session name should be more than 2 characters")
      .matches(Regex("AlphanumSpecialCharModified"), "Session name is invalid").max(250, "Maximum limit exceeds").nullable(),
    ddlTrainerType: Yup.string().required("Trainer type is required").nullable()
      .test("", "", (e) => {
        if (e != trainerType.current && trainerType.current != undefined) {
          trainerType.current = e;
          setValue("ddlTrainer", "")
          clearErrors(["ddlTrainer"])
        }
        return true
      }),
    ddlTrainer: Yup.string().required("Trainer name is required").nullable(),
    txtstdate: Yup.string()
      .required("Start date is required").typeError("Start date is invalid value")
      .test("Check", "Training session can be created only for present and future date time", (e) => {
        if (new Date(e) >= new Date(watch("txtEnddate"))) {
          setError("txtEnddate", { message: "End date must be greater than the start date" })
        }
        if (new Date(e) < new Date(watch("txtEnddate"))) {
          setError("txtEnddate", { message: "" })
        }
        if (new Date(e) > new Date(watch("txtCutOffdate")) && (new Date(watch("txtCutOffdate")) >= new Date(new Date().setMinutes(new Date().getMinutes() - 1)))) {
          setError("txtCutOffdate", { message: "" })
        }
        if (new Date(e) < new Date(watch("txtCutOffdate"))) {
          setError("txtCutOffdate", { message: "Nomination cutoff date must be lesser than the start date" })
        }

        if (e == "" || e == undefined || e == null) {
          return true;
        }
        else {
          if (new Date(e) > new Date(new Date().setMinutes(new Date().getMinutes() - 1))) {
            if ((stDate.current != e) && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
              stDate.current = e;
              setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
            }
            return true;
          }
          else {
            return false
          }
        }
      }).nullable(true),

    txtEnddate: Yup.string()
      .required("End date is required").typeError("End Date is invalid value")
      .test("Check", "End date must be greater than the start date", (e, { createError }) => {
        if (new Date(e) < new Date(watch("txtstdate"))) {
          return false;
        }
        var diff = new Date(e).getTime() - new Date(watch("txtstdate")).getTime();
        var daydiff = diff / (1000 * 60 * 60);
        if (new Date(e).toDateString() == new Date(watch("txtstdate")).toDateString() && daydiff < 1) {
          return createError({ message: "Training program should be created for minimum 1 hour" })
        }
        return true
      }).typeError("End Date is invalid value").nullable(),
    txtCutOffdate: Yup.string().typeError("Nomination cutoff date is invalid value")
      .test("Check", "Nomination cutoff date must be lesser than the start date", (e, { createError }) => {
        if (e != "") {
          if (new Date(e) <= new Date(new Date().setMinutes(new Date().getMinutes() - 1))) {
            return createError({ message: "Nomination cutoff date should not be lesser than current date" });
          }
          if (new Date(e) < new Date(watch("txtstdate"))) {
            return true;
          }
          else {
            return false
          }
        }
        return true
      }).typeError("Nomination cutoff date is invalid value").nullable(),

    txtBatchSize: Yup.string().required("Batch size is required").matches(Regex("AllowOnlyNumbers"), "Batch size is invalid").test("", "", (e, { createError }) => {
      if (e != "") {
        if (parseInt(e) == 0) return createError({ message: "Batch size should be greater than zero" })
      }
      if (e == "") {
        setValue("ddlLocation", "")
        clearErrors(["ddlLocation"])
      }
      return true
    }).max(3, "Maximum limit exceeds").nullable(),
    txtWaitingList: Yup.string().notRequired().test("", "", (e, { createError }) => {
      if (e != "") {
        if (parseInt(e) == 0) { return createError({ message: "Waiting list should be greater than zero" }) }
        if (!e?.match(Regex("AllowOnlyNumbers")) && e != undefined) {
          return createError({ message: "Waiting list is invalid" })
        }
        if (e == undefined) {
          clearErrors(["txtWaitingList"])
        }
      }
      return true
    }).max(3, "Maximum limit exceeds").nullable(),
    ddlLocation: Yup.string()
      .when("txtBatchSize", {
        is: (e) => e != "",
        then: Yup.string().required("Location is required")
      }
      ).nullable(),
    otherwise: Yup.string()
      .when("txtBatchSize", {
        is: (e) => e == "",
        then: Yup.string().notRequired()
      }).nullable(true),
    rbFeedback: Yup.string().test("", "", (e) => {
      if (e != radioButtonRequired.current.Feedback && radioButtonRequired.current.Feedback != undefined) {
        radioButtonRequired.current.Feedback = e;
        setValue("ddlFeedback", "")
        setValue("txtTimeLimit", "")
        clearErrors(["txtTimeLimit", "ddlFeedback"])
      }
      return true
    }).nullable(),
    ddlFeedback: Yup.string()
      .when("rbFeedback", {
        is: (e) => e == "Yes",
        then: Yup.string().required("Feedback template is required")
      }
      ).nullable(),
    otherwise: Yup.string()
      .when("rbFeedback", {
        is: (e) => e == "No",
        then: Yup.string().notRequired()
      }).nullable(true),
    rbSurvey: Yup.string().test("", "", (e) => {
      if (e != radioButtonRequired.current.Survey && radioButtonRequired.current.Survey != undefined) {
        radioButtonRequired.current.Survey = e;
        setValue("ddlSurvey", "")
        setValue("txtTimeLimit", "")
        clearErrors(["txtTimeLimit", "ddlSurvey"])
      }
      return true
    }).nullable(),
    ddlSurvey: Yup.string()
      .when("rbSurvey", {
        is: (e) => e == "Yes",
        then: Yup.string().required("Effectiveness survey template is required")
      }
      ).nullable(),
    otherwise: Yup.string()
      .when("rbSurvey", {
        is: (e) => e == "No",
        then: Yup.string().notRequired()
      }).nullable(true),
    ddlEnableTest: Yup.string().required("Enable test is required").nullable(),
    txtTimeLimit: Yup.string().notRequired().test("", "", (e, { createError }) => {
      if (e != "") {
        if (parseInt(e) == 0) { return createError({ message: "Time limit should be greater than zero" }) }
        if (!e?.match(Regex("AllowOnlyNumbers"))) {
          return createError({ message: "Time limit is invalid" })
        }
      }
      return true
    }).max(3, "Maximum limit exceeds").nullable(),

  })


  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, watch, reset, formState, clearErrors, setError } = useForm(formOptions);
  const { errors } = formState;
  const finalResponse = useCallback((finalStatus) => {
    if (finalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: finalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", true);
      setModalValues({
        ModalInfo: "Success",
        ModalOnClickEvent: () => {
          router.push("/TrainingManagement/TrainingManagementList")
        },
      });
      ModalOpen();
    }
  }, [router, setValue]);

  const ProgramType = useMemo(() => {
    return [{ value: "", text: "Select" }, { value: "Open", text: "Open" }, { value: "Mandatory", text: "Mandatory" }]
  }, [])

  const TypeOfTrainer = useMemo(() => {
    return [{ value: "", text: "Select" }, { value: "Internal", text: "Internal Trainer" }, { value: "External", text: "External Trainer" }]
  }, [])

  const EnableTest = useMemo(() => {
    return [{ value: "", text: "Select" }, { value: "Both", text: "Both" }, { value: "Pre-Assessment", text: "Pre-Assessment" }, { value: "Post-Assessment", text: "Post-Assessment" }, { value: "N/A", text: "N/A" }]
  }, [])
  const TrainerList = useCallback(() => {
    let trainers = [{ value: "", text: "Select" }]
    if (watch("ddlTrainerType") == "Internal") {
      trainingPage?.InternalTrainer?.map((data) => { trainers.push({ value: data.UserSub, text: data.FirstName + " " + data.LastName }) })
    } else if (watch("ddlTrainerType") == "External") {
      trainingPage?.ExternalTrainer?.map((data) => { trainers.push({ value: data.ExternalTrainerID, text: data.ExternalTrainerName }) })
    }
    return trainers;
  }, [trainingPage?.ExternalTrainer, trainingPage?.InternalTrainer, watch])

  const LocationList = useCallback(() => {
    let List = [{ value: "", text: "Select" }]
    let batchBased = trainingPage?.LocationList?.filter((data) => { return data.TrainingHallCapacity >= watch("txtBatchSize") })
    batchBased?.map((data) => {
      List.push({ value: data.LocationID, text: data.TrainingLocation })
    })
    locations.current = List;
    return List;
  }, [trainingPage?.LocationList, watch])

  const SurveyTemplates = useMemo(() => {
    let surveyList = [{ value: "", text: "Select" }, { value: "Create", text: "Create a new survey template" }]
    trainingPage?.SurveyTemplates && trainingPage?.SurveyTemplates?.map((data) => {
      surveyList.push({ value: data.TrainingSurveyTemplateID, text: data.TrainingSurveyTemplateName })
    })
    return surveyList;
  }, [trainingPage?.SurveyTemplates])

  const FeedbackTemplates = useMemo(() => {
    let feedbackList = [{ value: "", text: "Select" }, { value: "Create", text: "Create a new feedback template" }]
    trainingPage?.FeedbackTemplatesList && trainingPage?.FeedbackTemplatesList?.map((data) => {
      feedbackList.push({ value: data.TrainingFeedbackTemplateID, text: data.TrainingFeedbackTemplateName })
    })
    return feedbackList;
  }, [trainingPage?.FeedbackTemplatesList])

  const timeConvert = useCallback((passeddate)=>{
    return new Date(passeddate)?.getFullYear() + "-" + (new Date(passeddate)?.getMonth() + 1 >= 10 ? new Date(passeddate)?.getMonth() + 1 : "0" + (new Date(passeddate)?.getMonth() + 1)) + "-" + (new Date(passeddate)?.getDate() < 9 ? "0" + new Date(passeddate)?.getDate() : new Date(passeddate)?.getDate()) + "T" + (new Date(passeddate)?.getHours() > 9 ? new Date(passeddate)?.getHours() :"0"+ new Date(passeddate)?.getHours()) + ":" + (new Date(passeddate)?.getMinutes() > 9 ? new Date(passeddate)?.getMinutes() : "0" + new Date(passeddate)?.getMinutes())
  },[])

  useEffect(() => {
    if (trainingPage?.Mode == "Create") {
      setValue("rbFeedback", "No");
      setValue("rbSurvey", "No");
    } else if (trainingPage?.Mode == "Edit") {
      trainingType.current = trainingPage?.TrainingData?.TrainingType
      trainerType.current = trainingPage?.TrainingData?.TrainerType
      radioButtonRequired.current.Survey = trainingPage?.TrainingData?.SurveyActionEnable
      radioButtonRequired.current.Feedback = trainingPage?.TrainingData?.FeedbackActionEnable
      if (!(new Date(trainingPage?.TrainingData?.StartDate) >= new Date() && (trainingPage?.TrainingData?.IsTrainingEnrolled == false && trainingPage?.TrainingData?.IsSelfEnrolled == false))) {
        setEditValue(true)
        sessionStart.current = true;
      }
      let trainers = watch("ddlTrainerType") == "External" ? trainingPage?.ExternalTrainer : trainingPage?.InternalTrainer
      const isInternalTrainer = trainers?.length != undefined && (trainers?.some((x) => x.UserSub == trainingPage?.TrainingData?.TrainerID)) ? true : false
      const isExternalTrainer = trainers?.length != undefined && (trainers?.some((x) => x.ExternalTrainerID == trainingPage?.TrainingData?.TrainerID)) ? true : false
      const isTrainerAvailable = watch("ddlTrainerType") == "External" ? isExternalTrainer : isInternalTrainer
      const LocationFilter = trainingPage?.LocationList?.filter((data) => { return data.TrainingHallCapacity >= trainingPage?.TrainingData?.BatchSize })
      const isLocationAvailable = ((LocationFilter?.length != undefined && LocationFilter?.some((x) => x.LocationID == trainingPage?.TrainingData?.LocationID)) ? true : false);
      const isSurveyTemplate = trainingPage?.SurveyTemplates != undefined && (trainingPage?.SurveyTemplates?.some((x) => x?.TrainingSurveyTemplateID == trainingPage?.TrainingData?.TrainingSurveyTemplateID)) ? true : false
      const isFeedbackTemplate = trainingPage?.FeedbackTemplatesList != undefined && (trainingPage?.FeedbackTemplatesList?.some((x) => x?.TrainingFeedbackTemplateID == trainingPage?.TrainingData?.TrainingFeedbackTemplateID)) ? true : false

      setValue("txtProgramName", trainingPage?.TrainingData?.TrainingName)
      setValue("ddlProgramType", trainingPage?.TrainingData?.TrainingType)
      setValue("chkApproval", trainingPage?.TrainingData?.IsManagerApproval)
      setValue("txtSession", trainingPage?.TrainingData?.SessionName)
      setValue("ddlTrainerType", trainingPage?.TrainingData?.TrainerType)
      setValue("txtstdate", timeConvert(trainingPage?.TrainingData?.StartDate))
      setValue("txtEnddate", timeConvert(trainingPage?.TrainingData?.EndDate))
      setValue("txtCutOffdate", trainingPage?.TrainingData?.CutOffDate != "" ? timeConvert(trainingPage?.TrainingData?.CutOffDate) : "")
      setValue("txtBatchSize", trainingPage?.TrainingData?.BatchSize)
      setValue("txtWaitingList", trainingPage?.TrainingData?.WaitingList == 0 ? "" : trainingPage?.TrainingData?.WaitingList)
      setValue("ddlEnableTest", trainingPage?.TrainingData?.AssessmentType)
      setValue("txtTimeLimit", trainingPage?.TrainingData?.TimeLimit == 0 ? "" : trainingPage?.TrainingData?.TimeLimit)
      setValue("rbFeedback", trainingPage?.TrainingData?.FeedbackActionEnable)
      setValue("rbSurvey", trainingPage?.TrainingData?.SurveyActionEnable)
      setValue("ddlTrainer", isTrainerAvailable ? trainingPage?.TrainingData?.TrainerID : "")
      setValue("ddlLocation", isLocationAvailable ? trainingPage?.TrainingData?.LocationID : "")
      setValue("ddlSurvey", trainingPage?.TrainingData?.TrainingSurveyTemplateID == "Create" ? trainingPage?.TrainingData?.TrainingSurveyTemplateID : (isSurveyTemplate ? trainingPage?.TrainingData?.TrainingSurveyTemplateID : ""))
      setValue("ddlFeedback", trainingPage?.TrainingData?.TrainingFeedbackTemplateID == "Create" ? trainingPage?.TrainingData?.TrainingFeedbackTemplateID : (isFeedbackTemplate ? trainingPage?.TrainingData?.TrainingFeedbackTemplateID : ""))

      if (message != "") {
        setHTMLContents(trainingPage?.TrainingData?.TrainingDescription, message);
        message?.history?.clear();
      }
    }
  }, [message, setValue, timeConvert, trainingPage?.ExternalTrainer, trainingPage?.FeedbackTemplatesList, trainingPage?.InternalTrainer, trainingPage?.LocationList, trainingPage?.Mode, trainingPage?.SurveyTemplates, trainingPage?.TrainingData, trainingPage?.TrainingData?.AssessmentType, trainingPage?.TrainingData?.BatchSize, trainingPage?.TrainingData?.CutOffDate, trainingPage?.TrainingData?.EndDate, trainingPage?.TrainingData?.FeedbackActionEnable, trainingPage?.TrainingData?.IsManagerApproval, trainingPage?.TrainingData?.LocationID, trainingPage?.TrainingData?.SessionName, trainingPage?.TrainingData?.StartDate, trainingPage?.TrainingData?.SurveyActionEnable, trainingPage?.TrainingData?.TimeLimit, trainingPage?.TrainingData?.TrainerID, trainingPage?.TrainingData?.TrainerType, trainingPage?.TrainingData?.TrainingDescription, trainingPage?.TrainingData?.TrainingFeedbackTemplateID, trainingPage?.TrainingData?.TrainingName, trainingPage?.TrainingData?.TrainingSurveyTemplateID, trainingPage?.TrainingData?.TrainingType, trainingPage?.TrainingData?.WaitingList, watch])

  const submitHandler = async (data) => {
    if (locations.current.length == 1) {
      setValue("ddlLocation", "", { shouldValidate: true })
      return false
    }
    document.activeElement?.blur();
    setValue("submit", true)
    const PK = "TENANT#" + props.TenantInfo.TenantID;
    const TrainingID = trainingPage?.Mode == "Create" ? crypto.randomUUID().toString(25).substring(2, 12) : trainingPage?.TrainingData?.TrainingID;
    const date = new Date().toISOString();
    let Description;

    if (!message?.editor.delta.ops[0]["insert"].image) {
      Description = getContents(message)?.replace(/(<([^>]+)>)/gi, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ") == "" ? "" : getContents(message)
    } else {
      Description = message?.editor.delta.ops[0]["insert"].image?.replaceAll(/<img[^>]+>/g, "re")?.trim().length == 0 || getContents(message)?.replaceAll(/<img[^>]+>/g, "")?.length == 0 ? "" : getContents(message)
    }

    let inputLocationArray = [], inputTrainerArray = []

    if (trainingPage?.TrainingData?.TrainerID != data.ddlTrainer) {
      const trainernames = await AppsyncDBconnection(listXlmsExternalTrainerInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
      const mappedTrainer = trainernames?.res?.listXlmsExternalTrainerInfo?.items.filter((trainer) => { return trainer.ExternalTrainerID == data.ddlTrainer })
      const unMappedTrainer = trainernames?.res?.listXlmsExternalTrainerInfo?.items.filter((trainer) => { return trainer.ExternalTrainerID == trainingPage?.TrainingData?.TrainerID })

      if (trainingPage?.Mode == "Edit") {
        unMappedTrainer && unMappedTrainer?.map((unmap) => {
          let Unselected = unmap.MappedTraining != null ? JSON.parse(unmap?.MappedTraining)?.filter((getItem) => { return getItem.TrainingID != TrainingID }) : []
          inputTrainerArray = [...inputTrainerArray, { ...unmap, MappedTraining: JSON.stringify(Unselected) }, { ...unmap, SK: "EXTERNALTRAINERINFO#" + unmap.ExternalTrainerID, MappedTraining: JSON.stringify(Unselected) }]
        })
      }
      if (data.ddlTrainerType == "External") {
        mappedTrainer && mappedTrainer?.map((trainer) => {
          let newVar = trainer.MappedTraining != null ? [...JSON.parse(trainer?.MappedTraining), { TrainingID: TrainingID, TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim() }] : [{ TrainingID: TrainingID, TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim() }]
          let UniqueListSelected = [...new Map(newVar.map(item => [item["TrainingID"], item])).values()]
          inputTrainerArray = [...inputTrainerArray, { ...trainer, MappedTraining: JSON.stringify(UniqueListSelected) }, { ...trainer, SK: "EXTERNALTRAINERINFO#" + trainer.ExternalTrainerID, MappedTraining: JSON.stringify(UniqueListSelected) }]
        })
      }
    }

    if (trainingPage?.TrainingData?.LocationID != data.ddlLocation) {
      const locationList = await AppsyncDBconnection(listXlmsTrainingLocationInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGLOCATIONINFO#LASTMODIFIED#", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
      const mappedLocation = locationList?.res?.listXlmsTrainingLocationInfo?.items.filter((location) => { return location.LocationID == data.ddlLocation })
      const unMappedLocation = locationList?.res?.listXlmsTrainingLocationInfo?.items.filter((location) => { return location.LocationID == trainingPage?.TrainingData?.LocationID })
      if (trainingPage.Mode == "Edit") {
        unMappedLocation && unMappedLocation?.map((unmap) => {
          let Unselected = unmap.MappedTraining != null ? JSON.parse(unmap?.MappedTraining)?.filter((getItem) => { return getItem.TrainingID != TrainingID }) : []
          inputLocationArray = [...inputLocationArray, { ...unmap, MappedTraining: JSON.stringify(Unselected) }, { ...unmap, SK: "TRAININGLOCATIONINFO#" + unmap.LocationID, MappedTraining: JSON.stringify(Unselected) }]
        })
      }
      mappedLocation && mappedLocation?.map((location) => {
        let newVar = location.MappedTraining != null ? [...JSON.parse(location?.MappedTraining), { TrainingID: TrainingID, TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim() }] : [{ TrainingID: TrainingID, TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim() }]
        let UniqueListSelected = [...new Map(newVar.map(item => [item["TrainingID"], item])).values()]
        inputLocationArray = [...inputLocationArray, { ...location, MappedTraining: JSON.stringify(UniqueListSelected) }, { ...location, SK: "TRAININGLOCATIONINFO#" + location.LocationID, MappedTraining: JSON.stringify(UniqueListSelected) }]
      })
    }
    //Pre & Post Assessment Template
    const assessmentEditData = await AppsyncDBconnection(listXlmsTrainingManagementActivityInfos, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#Quiz" }, props.user.signInUserSession.accessToken.jwtToken);
    let assessmentData = assessmentEditData?.res?.listXlmsTrainingManagementActivityInfos?.items
    let assessment = trainingPage?.TrainingData?.QuestionandOptions && JSON.parse(trainingPage?.TrainingData?.QuestionandOptions);
    let filteredAssessment;
    if ((data?.ddlEnableTest != trainingPage?.TrainingData?.AssessmentType) && trainingPage?.TrainingData?.AssessmentType != undefined) {
      if (data?.ddlEnableTest == "N/A") {
        if (trainingPage?.TrainingData?.AssessmentType == "Both" || trainingPage?.TrainingData?.AssessmentType == "Pre-Assessment" || trainingPage?.TrainingData?.AssessmentType == "Post-Assessment") {
          assessmentData && assessmentData?.map(async (getItem) => {
            await AppsyncDBconnection(deleteXlmsTrainingManagementActivityInfoInput, { input: { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#Quiz#" + "ACTIVITYID#" + getItem?.ActivityID } }, props.user.signInUserSession.accessToken.jwtToken)
            delete assessment?.[getItem?.AssessmentType]
          })
        }
      }
      if (data?.ddlEnableTest == "Pre-Assessment") {
        assessmentData && assessmentData?.map(async (getItem) => {
          if (getItem?.AssessmentType == "Post-Assessment") {
            await AppsyncDBconnection(deleteXlmsTrainingManagementActivityInfoInput, { input: { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#Quiz#" + "ACTIVITYID#" + getItem?.ActivityID } }, props.user.signInUserSession.accessToken.jwtToken)
            delete assessment?.[getItem?.AssessmentType]
          }
        })
      }
      if (data?.ddlEnableTest == "Post-Assessment") {
        assessmentData && assessmentData?.map(async (getItem) => {
          if (getItem?.AssessmentType == "Pre-Assessment") {
            await AppsyncDBconnection(deleteXlmsTrainingManagementActivityInfoInput, { input: { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#Quiz#" + "ACTIVITYID#" + getItem?.ActivityID } }, props.user.signInUserSession.accessToken.jwtToken)
            delete assessment?.[getItem?.AssessmentType]
          }
        })
      }
    }
    // Feedback template
    const feedGetEditdata = await AppsyncDBconnection(listXlmsTrainingManagementActivityInfos, {
      PK: "TENANT#" + props?.TenantInfo?.TenantID,
      SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#Feedback"
    }, props.user.signInUserSession.accessToken.jwtToken);
    let feeExistData = feedGetEditdata?.res?.listXlmsTrainingManagementActivityInfos?.items?.[0];

    let feedtId, feedtName, feedquestionAndOptions;
    if ((data.ddlFeedback == trainingPage?.TrainingData?.TrainingFeedbackTemplateID || data.rbFeedback == "No") && (feeExistData?.ActivityID == undefined || feeExistData?.ActivityID == null)) {
      feedtId = data.ddlFeedback;
      feedtName = document.getElementById("ddlFeedback")?.options[document.getElementById("ddlFeedback")?.selectedIndex]?.text;
      feedquestionAndOptions = data.rbFeedback == "No" ? {} : JSON.parse(trainingPage?.TrainingData?.QuestionandOptions);
    } else {
      if (data.ddlFeedback == "Create" || data.rbFeedback == "No") {
        if (data.rbFeedback == "No") {
          feedtId = data.ddlFeedback; feedtName = document.getElementById("ddlFeedback")?.options[document.getElementById("ddlFeedback")?.selectedIndex]?.text;
          feedquestionAndOptions = trainingPage?.TrainingData && Object.keys(delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Feedback))?.length > 0 ? delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Feedback) : {}
        } else {
          feedtId = "Create";
          feedtName = "Create a new feedback template";
          feedquestionAndOptions = trainingPage?.TrainingData && Object.keys(delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Feedback))?.length > 0 ? delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Feedback) : {}
        }
        if (feeExistData?.ActivityID) {
          const DeleteUserResponse = await AppsyncDBconnection(deleteXlmsTrainingManagementActivityInfoInput,
            {
              input: {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "TRAINING#" + feeExistData?.TrainingID + "#ACTIVITYTYPE#" + feeExistData?.ActivityType + "#ACTIVITYID#" + feeExistData?.ActivityID,
              }
            },
            props?.user.signInUserSession.accessToken.jwtToken);
        }
      } else {
        let findData = trainingPage?.FeedbackTemplatesList.filter((item) => {
          return item?.TrainingFeedbackTemplateID == data?.ddlFeedback;
        })

        if (findData?.[0]) {
          feedtId = findData?.[0]?.TrainingFeedbackTemplateID;
          feedtName = findData?.[0]?.TrainingFeedbackTemplateName;
          if (feeExistData?.ActivityID == null || feeExistData?.ActivityID == undefined || feeExistData?.ActivityID == "" || !feeExistData?.ActivityID) {
            let actIds = crypto.randomUUID().toString(25).substring(2, 12), DateTime = new Date();
            let trainingVariables = {
              input: {
                PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#" + "Feedback" + "#ACTIVITYID#" + actIds,
                ActivityID: actIds, ActivityName: data?.txtProgramName + "-" + "Feedback",
                ActivityNameLowerCase: data?.txtProgramName + "-" + "Feedback"?.toLowerCase()?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                ActivityType: "Feedback", TenantID: props?.TenantInfo?.TenantID, IsDeleted: false, IsSuspend: false,
                CreatedBy: props?.user?.username, IsShowOnCoursePage: false, CreatedDate: DateTime, LastModifiedBy: props?.user?.username,
                LastModifiedDate: DateTime, TrainingID: TrainingID, TrainingName: data?.txtProgramName,
                QuestionandOptions: findData?.[0]?.TemplateOption
              },
            };
            let finalStatus = (await AppsyncDBconnection(createXlmsTrainingManagementActivityInfo, trainingVariables, props.user.signInUserSession.accessToken.jwtToken));
            let newActy = finalStatus?.res?.createXlmsTrainingManagementActivityInfo;
            feedquestionAndOptions = {
              Feedback: {
                ActivityID: newActy?.ActivityID, ActivityName: "Feedback", ActivityType: "Feedback", TrainingID: newActy?.TrainingID,
                TemplateID: feedtId, TemplateName: feedtName, Template: JSON.parse(findData?.[0]?.TemplateOption), IsSuspend: false
              }
            }
          } else {
            feedquestionAndOptions = {
              Feedback: {
                ActivityID: feeExistData?.ActivityID, ActivityName: "Feedback", ActivityType: "Feedback", TrainingID: feeExistData?.TrainingID,
                TemplateID: feedtId, TemplateName: feedtName, Template: JSON.parse(findData?.[0]?.TemplateOption), IsSuspend: false
              }
            }
            let mergedQuestionVariables = { input: { PK: feeExistData?.PK, SK: feeExistData?.SK, QuestionandOptions: findData?.[0]?.TemplateOption }, }
            await AppsyncDBconnection(updateXlmsTrainingManagementActivityInfo, mergedQuestionVariables, props?.user.signInUserSession.accessToken.jwtToken);
          }
        }
      }
    }
    // Effectiveness survey template
    const surveyGetEditdata = await AppsyncDBconnection(listXlmsTrainingManagementActivityInfos, {
      PK: "TENANT#" + props?.TenantInfo?.TenantID,
      SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#Survey"
    }, props.user.signInUserSession.accessToken.jwtToken);
    let existData = surveyGetEditdata?.res?.listXlmsTrainingManagementActivityInfos?.items?.[0];

    let tId, tName, questionAndOptions;
    if ((data.ddlSurvey == trainingPage?.TrainingData?.TrainingSurveyTemplateID || data.rbSurvey == "No") && (existData?.ActivityID == undefined || existData?.ActivityID == null)) {
      tId = data.ddlSurvey;
      tName = document.getElementById("ddlSurvey")?.options[document.getElementById("ddlSurvey")?.selectedIndex]?.text;
      questionAndOptions = data.rbSurvey == "No" ? {} : JSON.parse(trainingPage?.TrainingData?.QuestionandOptions);
    } else {
      if (data.ddlSurvey == "Create" || data.rbSurvey == "No") {
        if (data.rbSurvey == "No") {
          tId = data.ddlSurvey; tName = document.getElementById("ddlSurvey")?.options[document.getElementById("ddlSurvey")?.selectedIndex]?.text;
          questionAndOptions = trainingPage?.TrainingData && Object.keys(delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Survey))?.length > 0 ? delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Survey) : {}
        } else {
          tId = "Create"; tName = "Create a new survey template";
          questionAndOptions = trainingPage?.TrainingData && Object.keys(delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Survey))?.length > 0 ? delete (JSON.parse(trainingPage?.TrainingData?.QuestionandOptions)?.Survey) : {}
        }
        if (existData?.ActivityID) {
          const DeleteUserResponse = await AppsyncDBconnection(deleteXlmsTrainingManagementActivityInfoInput,
            {
              input: {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "TRAINING#" + existData?.TrainingID + "#ACTIVITYTYPE#" + existData?.ActivityType + "#ACTIVITYID#" + existData?.ActivityID,
              }
            },
            props?.user.signInUserSession.accessToken.jwtToken);
        }
      } else {
        let tVariables = { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAININGQUESTIONNAIRETEMPLATE#" + data?.ddlSurvey }
        let FinalStatus = (await AppsyncDBconnection(getXlmsTrainingTemplate, tVariables, props?.user?.signInUserSession?.accessToken?.jwtToken));
        if (FinalStatus?.Status == "Success") {
          tId = FinalStatus?.res?.getXlmsTrainingTemplate?.TrainingSurveyTemplateID;
          tName = FinalStatus?.res?.getXlmsTrainingTemplate?.TrainingSurveyTemplateName;
          if (existData?.ActivityID == null || existData?.ActivityID == undefined || existData?.ActivityID == "" || !existData?.ActivityID) {
            let actIds = crypto.randomUUID().toString(25).substring(2, 12), DateTime = new Date();
            let trainingVariables = {
              input: {
                PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAINING#" + TrainingID + "#ACTIVITYTYPE#" + "Survey" + "#ACTIVITYID#" + actIds, ActivityID: actIds, ActivityName: data?.txtProgramName + "-" + "Effectiveness Survey", ActivityNameLowerCase: data?.txtProgramName + "-" + "Effectiveness Survey"?.toLowerCase()?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ActivityType: "Survey", TenantID: props?.TenantInfo?.TenantID, IsDeleted: false, IsSuspend: false, CreatedBy: props?.user?.username, IsShowOnCoursePage: false, CreatedDate: DateTime, LastModifiedBy: props?.user?.username, LastModifiedDate: DateTime, TrainingID: TrainingID, TrainingName: data?.txtProgramName, QuestionandOptions: FinalStatus?.res?.getXlmsTrainingTemplate?.TemplateOption
              },
            };
            let finalStatus = (await AppsyncDBconnection(createXlmsTrainingManagementActivityInfo, trainingVariables, props.user.signInUserSession.accessToken.jwtToken));
            let newActy = finalStatus?.res?.createXlmsTrainingManagementActivityInfo;
            questionAndOptions = {
              Survey: {
                ActivityID: newActy?.ActivityID, ActivityName: "Effectiveness Survey", ActivityType: "Survey", TrainingID: newActy?.TrainingID,
                TemplateID: tId, TemplateName: tName, Template: JSON.parse(FinalStatus?.res?.getXlmsTrainingTemplate?.TemplateOption), IsSuspend: false
              }
            }
          } else {
            questionAndOptions = {
              Survey: {
                ActivityID: existData?.ActivityID, ActivityName: "Effectiveness Survey", ActivityType: "Survey", TrainingID: existData?.TrainingID,
                TemplateID: tId, TemplateName: tName, Template: JSON.parse(FinalStatus?.res?.getXlmsTrainingTemplate?.TemplateOption), IsSuspend: false
              }
            }
            let mergedQuestionVariables = { input: { PK: existData?.PK, SK: existData?.SK, QuestionandOptions: FinalStatus?.res?.getXlmsTrainingTemplate?.TemplateOption }, }
            await AppsyncDBconnection(updateXlmsTrainingManagementActivityInfo, mergedQuestionVariables, props?.user.signInUserSession.accessToken.jwtToken);
          }
        }
      }
    }



    let mergeTemplates = { ...assessment, Feedback: feedquestionAndOptions?.Feedback, Survey: questionAndOptions?.Survey }


    const RemoveNull = (obj) => {
      let tempjson = {};
      obj && Object.keys(obj).forEach((k) => {
        if (obj?.[k] != undefined) {
          tempjson = { ...tempjson, [k]: obj?.[k] }
        }
      });
      return tempjson;
    };

    let temp = RemoveNull(trainingPage?.TrainingData);

    let sessionCount;
    if (trainingPage.Mode == "Create" || (((new Date(data.txtstdate)).toISOString() != new Date(trainingPage?.TrainingData?.StartDate).toISOString()) || ((new Date(data.txtEnddate)).toISOString() != new Date(trainingPage?.TrainingData?.EndDate).toISOString()))) {
      let SessionList;
      if (trainingPage.Mode == "Edit") {
        let Session = await AppsyncDBconnection(listXlmsTrainingSessionInfos, { PK: "TENANT#" + props.TenantInfo.TenantID + "#TRAINING#" + TrainingID, SK: "SESSION#STARTDATE#", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
        SessionList = Session.res?.listXlmsTrainingSessionInfos?.items ? Session.res?.listXlmsTrainingSessionInfos?.items : []
      }

      function getDatesBetween(startDate, endDate) {
        const currentDate = new Date(startDate.getTime());
        const EndDate = new Date(startDate.getTime())
        let i = 0;
        const dates = [];
        function dateDiff(FirstDate, SecondDate) {
          let diff = FirstDate.getTime() - SecondDate.getTime();
          let daydiff = diff / (1000 * 60 * 60);
          return daydiff
        }
        function DateAdjustment(StartDate, EndDate, index) {
          const finalArray = [];
          const startDate = new Date(StartDate);
          const endDate = new Date(EndDate);

          const timeDiffHours = (endDate - startDate) / (1000 * 60 * 60);


          if (timeDiffHours >= 1) {
            if (endDate.toDateString() != startDate.toDateString() && endDate.getHours() < startDate.getHours()) {
              endDate.setHours(23, 59);
              endDate.setDate(startDate.getDate());
            }

            if (endDate.getDate() == new Date(data.txtEnddate).getDate()) {
              endDate.setHours(new Date(data.txtEnddate).getHours());
              endDate.setMinutes(new Date(data.txtEnddate).getMinutes());
            }
          }
          return endDate.toISOString()
        }

        while (currentDate <= endDate) {

          let SessionID = crypto.randomUUID().toString(25)
          dateDiff(new Date(data.txtEnddate), new Date(currentDate)) >= 1 &&
            dates.push({
              PK: "TENANT#" + props.TenantInfo.TenantID + "#TRAINING#" + TrainingID,
              SK: "SESSION#" + SessionID,
              TrainingID: TrainingID,
              TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
              SessionName: data.txtSession?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
              SessionID: SessionID,
              IsDeleted: false,
              CreatedBy: props.user?.username,
              CreatedDate: date,
              LastModifiedBy: props.user?.username,
              LastModifiedDate: date,
              TenantID: props.TenantInfo.TenantID,
              StartDate: new Date(currentDate).toISOString(),
              EndDate: DateAdjustment(new Date(currentDate).toISOString(), new Date(EndDate.setTime(currentDate.getTime() + 8 * 60 * 60 * 1000)).toISOString(), i)
            });
          currentDate.setDate(currentDate.getDate() + 1);
          i++
        }
        return dates;
      }

      const date1 = new Date(data.txtstdate);
      const date2 = new Date(data.txtEnddate);

      let allDates = getDatesBetween(date1, date2);

      let NewArray = [...allDates]
      if (trainingPage?.Mode == "Edit") {
        while (NewArray.length > 25) {
          let tempArray = NewArray.splice(0, 25);
          AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, { input: tempArray }, props.user.signInUserSession.accessToken.jwtToken);
        }
        for (let i = 0; i < SessionList?.length; i++) {
          let dataDelete = RemoveNull(SessionList[i]);
          NewArray = [...NewArray, { ...dataDelete, IsDeleted: true, AutoDelete: Date.now() / 1000 + 24 * 60 | 0 }, { ...dataDelete, SK: "SESSION#" + dataDelete.SessionID, IsDeleted: true, }];
          if (NewArray.length > 25 || i == SessionList?.length - 1) {
            let tempArray = NewArray.splice(0, 25);
            AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, { input: tempArray }, props.user.signInUserSession.accessToken.jwtToken);
          }
        }
      }
      else {
        while (NewArray.length > 0) {
          let finalVariables = NewArray.splice(0, 25);
          AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, { input: finalVariables }, props.user.signInUserSession.accessToken.jwtToken)
        }
      }
      for (let i = 0; i < allDates?.length; i++) {
        NewArray = [...NewArray, { ...allDates[i], SK: "SESSION#STARTDATE#" + allDates[i]?.StartDate + "#SESSIONID#" + allDates[i]?.SessionID }]
        if (i % 25 == 0 || i == allDates.length - 1) {
          AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, { input: NewArray }, props.user.signInUserSession.accessToken.jwtToken);
          NewArray = [];
        }
      }
      sessionCount = allDates.length
    }
    const createVariables = {
      input: [
        {
          PK: PK,
          SK: "TRAININGINFO#" + TrainingID,
          TrainingID: TrainingID,
          TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          TrainingDescription: Description,
          TrainingType: data.ddlProgramType,
          IsManagerApproval: data.chkApproval,
          SessionName: data.txtSession?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          SessionCount: sessionCount,
          TrainerType: data.ddlTrainerType,
          TrainerName: document.getElementById("ddlTrainer")?.options[document.getElementById("ddlTrainer")?.selectedIndex]?.text,
          TrainerID: data.ddlTrainer,
          StartDate: new Date(data.txtstdate)?.toISOString(),
          EndDate: new Date(data.txtEnddate)?.toISOString(),
          CutOffDate: data.txtCutOffdate != "" ? new Date(data.txtCutOffdate)?.toISOString() : data.txtCutOffdate,
          BatchSize: ~~data.txtBatchSize,
          WaitingList: ~~data.txtWaitingList,
          TrainingLocation: document.getElementById("ddlLocation")?.options[document.getElementById("ddlLocation")?.selectedIndex]?.text,
          LocationID: data.ddlLocation,
          AssessmentType: data.ddlEnableTest,
          SurveyActionEnable: data.rbSurvey,
          TrainingSurveyTemplateID: tId,
          TrainingSurveyTemplateName: tName,
          FeedbackActionEnable: data.rbFeedback,
          TrainingFeedbackTemplateID: feedtId,
          TrainingFeedbackTemplateName: feedtName,
          TimeLimit: ~~data.txtTimeLimit,
          IsSuspend: false,
          IsDeleted: false,
          CreatedBy: props.user?.username,
          CreatedDate: date,
          LastModifiedBy: props.user?.username,
          LastModifiedDate: date,
          QuestionandOptions: Object.keys(mergeTemplates)?.length > 0 ? JSON.stringify(mergeTemplates) : null,
          IsTrainingEnrolled: false,
          IsSelfEnrolled: false
        },
        {
          PK: PK,
          SK: "TRAININGINFO#LASTMODIFIEDDATE#" + date + "#TRAININGID#" + TrainingID,
          TrainingID: TrainingID,
          TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          TrainingDescription: Description,
          TrainingType: data.ddlProgramType,
          IsManagerApproval: data.chkApproval,
          SessionName: data.txtSession?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          SessionCount: sessionCount,
          TrainerType: data.ddlTrainerType,
          TrainerName: document.getElementById("ddlTrainer")?.options[document.getElementById("ddlTrainer")?.selectedIndex]?.text,
          TrainerID: data.ddlTrainer,
          StartDate: new Date(data.txtstdate)?.toISOString(),
          EndDate: new Date(data.txtEnddate)?.toISOString(),
          CutOffDate: data.txtCutOffdate != "" ? new Date(data.txtCutOffdate)?.toISOString() : data.txtCutOffdate,
          BatchSize: ~~data.txtBatchSize,
          WaitingList: ~~data.txtWaitingList,
          TrainingLocation: document.getElementById("ddlLocation")?.options[document.getElementById("ddlLocation")?.selectedIndex]?.text,
          LocationID: data.ddlLocation,
          AssessmentType: data.ddlEnableTest,
          SurveyActionEnable: data.rbSurvey,
          TrainingSurveyTemplateID: tId,
          TrainingSurveyTemplateName: tName,
          FeedbackActionEnable: data.rbFeedback,
          TrainingFeedbackTemplateID: feedtId,
          TrainingFeedbackTemplateName: feedtName,
          TimeLimit: ~~data.txtTimeLimit,
          IsSuspend: false,
          IsDeleted: false,
          CreatedBy: props.user?.username,
          CreatedDate: date,
          LastModifiedBy: props.user?.username,
          LastModifiedDate: date,
          QuestionandOptions: Object.keys(mergeTemplates)?.length > 0 ? JSON.stringify(mergeTemplates) : null,
          IsTrainingEnrolled: false,
          IsSelfEnrolled: false
        }]
    }

    const updateVariables = {
      input: [
        {
          ...temp,
          SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingPage?.TrainingData?.LastModifiedDate + "#TRAININGID#" + TrainingID,
          IsDeleted: true,
          AutoDelete: Date.now() / 1000 + 24 * 60 | 0
        },
        {
          ...temp,
          TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          TrainingDescription: Description,
          TrainingType: data.ddlProgramType,
          IsManagerApproval: data.chkApproval,
          SessionName: data.txtSession?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          SessionCount: sessionCount,
          TrainerType: data.ddlTrainerType,
          TrainerName: document.getElementById("ddlTrainer")?.options[document.getElementById("ddlTrainer")?.selectedIndex]?.text,
          TrainerID: data.ddlTrainer,
          StartDate: new Date(data.txtstdate)?.toISOString(),
          EndDate: new Date(data.txtEnddate)?.toISOString(),
          CutOffDate: data.txtCutOffdate != "" ? new Date(data.txtCutOffdate)?.toISOString() : data.txtCutOffdate,
          BatchSize: ~~data.txtBatchSize,
          WaitingList: ~~data.txtWaitingList,
          TrainingLocation: document.getElementById("ddlLocation")?.options[document.getElementById("ddlLocation")?.selectedIndex]?.text,
          LocationID: data.ddlLocation,
          AssessmentType: data.ddlEnableTest,
          SurveyActionEnable: data.rbSurvey,
          TrainingSurveyTemplateID: tId,
          TrainingSurveyTemplateName: tName,
          FeedbackActionEnable: data.rbFeedback,
          TrainingFeedbackTemplateID: feedtId,
          TrainingFeedbackTemplateName: feedtName,
          TimeLimit: ~~data.txtTimeLimit,
          LastModifiedBy: props.user?.username,
          LastModifiedDate: date,
          QuestionandOptions: Object.keys(mergeTemplates)?.length > 0 ? JSON.stringify(mergeTemplates) : null
        },
        {
          ...temp,
          SK: "TRAININGINFO#LASTMODIFIEDDATE#" + date + "#TRAININGID#" + TrainingID,
          TrainingName: data.txtProgramName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          TrainingDescription: Description,
          TrainingType: data.ddlProgramType,
          IsManagerApproval: data.chkApproval,
          SessionName: data.txtSession?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
          SessionCount: sessionCount,
          TrainerType: data.ddlTrainerType,
          TrainerName: document.getElementById("ddlTrainer")?.options[document.getElementById("ddlTrainer")?.selectedIndex]?.text,
          TrainerID: data.ddlTrainer,
          StartDate: new Date(data.txtstdate)?.toISOString(),
          EndDate: new Date(data.txtEnddate)?.toISOString(),
          CutOffDate: data.txtCutOffdate != "" ? new Date(data.txtCutOffdate)?.toISOString() : data.txtCutOffdate,
          BatchSize: ~~data.txtBatchSize,
          WaitingList: ~~data.txtWaitingList,
          TrainingLocation: document.getElementById("ddlLocation")?.options[document.getElementById("ddlLocation")?.selectedIndex]?.text,
          LocationID: data.ddlLocation,
          AssessmentType: data.ddlEnableTest,
          SurveyActionEnable: data.rbSurvey,
          TrainingSurveyTemplateID: tId,
          TrainingSurveyTemplateName: tName,
          FeedbackActionEnable: data.rbFeedback,
          TrainingFeedbackTemplateID: feedtId,
          TrainingFeedbackTemplateName: feedtName,
          TimeLimit: ~~data.txtTimeLimit,
          LastModifiedBy: props.user?.username,
          LastModifiedDate: date,
          QuestionandOptions: Object.keys(mergeTemplates)?.length > 0 ? JSON.stringify(mergeTemplates) : null
        }]
    }

    const TrainingVariables = trainingPage?.Mode == "Create" ? createVariables : updateVariables
    const finalResult = await AppsyncDBconnection(createXlmsBatchTrainingManagement, TrainingVariables, props?.user.signInUserSession.accessToken.jwtToken)

    if (finalResult.Status == "Success") {
      if (inputLocationArray.length > 0) {
        (await AppsyncDBconnection(createXlmsBatchTrainingLocationInfo, { input: inputLocationArray }, props?.user.signInUserSession.accessToken.jwtToken))
      }
      if (inputTrainerArray.length > 0) {
        (await AppsyncDBconnection(createXlmsBatchExternalTrainerInfo, { input: inputTrainerArray }, props?.user.signInUserSession.accessToken.jwtToken))
      }
    }

    finalResponse(finalResult.Status)
    setValue("submit", false)
  }

  const DateTimeControl = () => {
    let today = new Date();
    let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T" + today.getHours() + ":" + (today.getMinutes() > 9 ? today.getMinutes() : "0" + today.getMinutes());

    return (
      <>
        <div className="grid ">
          <div>
            <div className="flex">
              <NVLlabel text="Start Date" className="nvl-Def-Label pb-1 "><span className="text-red-500 text-lg">*</span></NVLlabel>
              <NVLlabel className="nvl-Def-Label pt-2" HelpInfo={`${"Based on the start date and end date of the program, sessions are created."}`} HelpInfoIcon={"fa fa-solid fa-circle-question"}></NVLlabel></div>
            <NVLTextbox id="txtstdate" title="Start Date" type="datetime-local" tabIndex={"1"} className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} setValue={setValue} errors={errors} register={register}></NVLTextbox>
          </div>
          <div>
            <NVLlabel text="End Date" className="nvl-Def-Label pb-1"><span className="text-red-500 text-lg">*</span></NVLlabel>
            <NVLTextbox title="End Date" id="txtEnddate" type="datetime-local" tabIndex={"1"} className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} setValue={setValue}></NVLTextbox>
          </div>
          <div>
            <NVLlabel text="Nomination Cutoff Date" className="nvl-Def-Label pb-1"><span className="invisible text-lg">*</span></NVLlabel>
            <NVLTextbox title="Nomination Cutoff Date" id="txtCutOffdate" type="datetime-local" tabIndex={"1"} className={`nvl-non-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} setValue={setValue}></NVLTextbox>
          </div>
        </div>
      </>
    );
  }
  const pageRoutes = useMemo(() => {
    return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
    { path: "", breadcrumb: trainingPage?.Mode != "Edit" ? "Create Training" : (editValue == true ? "Preview Training" : "Edit Training") }]
  }, [editValue, trainingPage?.Mode])


  const clearField = () => {


    const clearData = [{ FieldID: "txtProgramName", FieldValue: "" }, { FieldID: "ddlProgramType", FieldValue: "" }, { FieldID: "txtSession", FieldValue: "" }, { FieldID: "ddlTrainerType", FieldValue: "" }, { FieldID: "ddlTrainer", FieldValue: "" },
    { FieldID: "txtstdate", FieldValue: "" }, { FieldID: "txtEnddate", FieldValue: "" }, { FieldID: "txtCutOffdate", FieldValue: "" }, { FieldID: "txtBatchSize", FieldValue: "" }, { FieldID: "txtWaitingList", FieldValue: "" },
    { FieldID: "ddlLocation", FieldValue: "" }, { FieldID: "ddlSurvey", FieldValue: "" }, { FieldID: "ddlEnableTest", FieldValue: "" }, { FieldID: "rbFeedback", FieldValue: "No" }, { FieldID: "rbSurvey", FieldValue: "No" }, { FieldID: "ddlFeedback", FieldValue: "" }, { FieldID: "txtTimeLimit", FieldValue: "" }];
    clearData.map((data) => {
      setValue(data.FieldID, data.FieldValue)
    })
    setHTMLContents("", message);
    clearErrors()
  }

  const onClickCall = () => {
    document.activeElement?.blur();
  }

  return (
    <>
      <Container title={trainingPage?.Mode != "Edit" ? "Create Training" : (sessionStart.current ? "Preview Training" : "Edit Training")} loader={trainingPage?.Mode != undefined ? false : true} PageRoutes={pageRoutes}>
        <form onSubmit={handleSubmit(submitHandler)} id="divUpload" noValidate>
          <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
          <div className={watch("submit") ? "nvl-FormContent pointer-events-none" : "nvl-FormContent"}>
            <div className={sessionStart.current == true ? "pointer-events-none" : ""}>
              <NVLTextbox id="txtProgramName" labelText="Program Name" labelClassName="nvl-Def-Label pb-1" title="Program Name" className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} />
              <NVLlabel text="Program Description" className="nvl-Def-Label pb-1" />
              <NVLRichTextBox id="txtProgramDescription" className={`isResizable nvl-non-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} setState={setMessage} />
              <NVLSelectField id="ddlProgramType" options={ProgramType} disabled={trainingPage?.TrainingData?.TrainingType != undefined ? true : false} labelText="Program Type" labelClassName="nvl-Def-Label pb-1" className={`nvl-mandatory nvl-Def-Input ${(sessionStart.current == true || trainingPage?.TrainingData?.TrainingType != undefined) && "Disabled"}`} errors={errors} register={register} />
              <div>
                <NVLCheckbox id="chkApproval" disabled={trainingPage?.TrainingData?.TrainingType != undefined ? true : false} className={`${watch("ddlProgramType") != "Open" ? "hidden" : (sessionStart.current == true ? "checked:text-gray-400" : "")}`} text={"Manager approval required"} name={"chkApproval"} errors={errors} register={register} />
              </div>
              <NVLTextbox id="txtSession" labelText="Session Name" labelClassName="nvl-Def-Label pb-1" title="Session Name" className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} />
              <NVLSelectField id="ddlTrainerType" options={TypeOfTrainer} labelText="Trainer Type" labelClassName="nvl-Def-Label pb-1" className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} />
              <NVLlabel text={"Trainer Name"} className="nvl-Def-Label pb-2" HelpInfo={`${"Based on the trainer type, trainers are listed."}`} HelpInfoIcon={"fa fa-solid fa-circle-question"}><span className="text-red-600 text-sm">*</span></NVLlabel>
              <NVLSelectField id="ddlTrainer" options={TrainerList()} className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} />
              <DateTimeControl setValue={setValue} register={register} errors={errors} watch={watch} reset={reset} />
              <NVLTextbox id="txtBatchSize" labelText="Batch Size" labelClassName="nvl-Def-Label pb-1 " title="Batch Size" className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} />
              <NVLTextbox id="txtWaitingList" labelText="Waiting List" labelClassName="nvl-Def-Label pb-1 " title="Waiting List" className={`nvl-non-mandatory nvl-Def-Input  ${(sessionStart.current == true || watch("ddlProgramType") != "Open") ? "Disabled" : ""}`} errors={errors} register={register} disabled={(sessionStart.current == true || watch("ddlProgramType") != "Open") ? true : false} />
              <NVLlabel text={"Location"} className="nvl-Def-Label pb-1" HelpInfo={`${"Based on the batch size, locations are listed."}`} HelpInfoIcon={"fa fa-solid fa-circle-question"}><span className="text-red-600 text-sm">*</span></NVLlabel>
              <NVLSelectField id="ddlLocation" options={LocationList()} disabled={watch("txtBatchSize") != "" ? false : true} className={`nvl-mandatory nvl-Def-Input ${(watch("txtBatchSize") == "" || sessionStart.current == true) && "Disabled"}`} errors={errors} register={register} />
              <NVLSelectField id="ddlEnableTest" options={EnableTest} labelText="Enable Test" labelClassName="nvl-Def-Label pb-1" disabled={trainingPage?.TrainingData?.StartDate != new Date().toISOString() ? false : true} className={(trainingPage?.TrainingData?.StartDate == new Date().toISOString() || sessionStart.current == true) ? "Disabled nvl-mandatory nvl-Def-Input " : "nvl-mandatory nvl-Def-Input "} errors={errors} register={register} />
              <NVLlabel text="Feedback Template" className="nvl-Def-Label pb-1 pt-2" />
              <div className="flex gap-16 pt-2"> <NVLRadio id="rbFeedback" name="rbFeedback" text="Yes" register={register} errors={errors} value="Yes" className={sessionStart.current == true ? "checked:text-gray-400" : ""} />
                <NVLRadio id="rbFeedback" name="rbFeedback" text="No" register={register} errors={errors} value="No" className={sessionStart.current == true ? "checked:text-gray-400" : ""} /></div>
              <div className={watch("rbFeedback") == "No" ? "hidden" : "pt-1"}>
                <NVLSelectField id="ddlFeedback" options={FeedbackTemplates} labelText="Feedback template" labelClassName="nvl-Def-Label pb-1" className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} />
              </div>
              <NVLlabel text="Effectiveness Survey" className="nvl-Def-Label pb-1 pt-2" />
              <div className="flex gap-16 pt-2"> <NVLRadio id="rbSurvey" name="rbSurvey" text="Yes" className={sessionStart.current == true ? "checked:text-gray-400" : ""} register={register} errors={errors} value="Yes" />
                <NVLRadio id="rbSurvey" name="rbSurvey" text="No" register={register} errors={errors} className={sessionStart.current == true ? "checked:text-gray-400" : ""} value="No" /></div>
              <div className={watch("rbSurvey") == "No" ? "hidden" : "pt-1"}>
                <NVLSelectField id="ddlSurvey" options={SurveyTemplates} labelText="Effectiveness survey template" labelClassName="nvl-Def-Label pb-1" className={`nvl-mandatory nvl-Def-Input ${sessionStart.current == true && "Disabled"}`} errors={errors} register={register} />
              </div>
              <div className="pt-3">
                <NVLlabel text={"Time Limit(days)"} className="nvl-Def-Label pb-1 " HelpInfo={`${"Based on the effectiveness survey, time limit should be given."}`} HelpInfoIcon={"fa fa-solid fa-circle-question"}></NVLlabel>
                <NVLTextbox id="txtTimeLimit" title="Time Limit(days)" disabled={watch("rbSurvey") == "No" ? true : false} className={(watch("rbSurvey") == "No" || sessionStart.current == true) ? "Disabled nvl-non-mandatory nvl-Def-Input " : "nvl-non-mandatory nvl-Def-Input "} errors={errors} register={register} />
              </div>
            </div>
            <div className="flex justify-center gap-2 pt-4">
              <NVLButton id="btnSubmit" text={!watch("submit") ? "Save" : ""} type="submit" onClick={(e) => { onClickCall(e) }} className={sessionStart.current == true ? "pointer-events-none w-32 nvl-button-light bg-primary text-white" : "w-32 nvl-button bg-primary text-white "}>
                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
              </NVLButton>
              <NVLButton id="btnCancel" text={trainingPage?.Mode != "Edit" ? "Clear" : "Cancel"} type="button" className="nvl-button w-28 " onClick={() => trainingPage?.Mode != "Edit" ? clearField() : router.push("/TrainingManagement/TrainingManagementList")}></NVLButton>
            </div>
          </div>
        </form>
      </Container>
    </>
  )
}
export default CreateTraining