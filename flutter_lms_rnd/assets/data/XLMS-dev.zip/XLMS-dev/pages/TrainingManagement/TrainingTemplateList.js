import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from '@components/Controls/NVLAlert';
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { createXlmsBatchTrainingManagement, deleteXlmsTrainingManagementActivityInfoInput, updateXlmsTrainingManagementActivityInfo } from "@graphql/graphql/mutations";
import { getXlmsTrainingManagement, getXlmsTrainingManagementActivityInfo, listXlmsTrainingManagement } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";

export default function TrainingTemplateList(props) {
  const router = useRouter();
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [popupValues, setPopupValues] = useState({});
  const [modalValues, setModalValues] = useState({});
  const [traininingState, setTraining] = useState()

  const HeaderColumn = [
    { HeaderName: "Template Name", Columnvalue: "TemplateName", HeaderCss: "!w-4/12", },
    { HeaderName: "Template Type", Columnvalue: "Activity", HeaderCss: "!w-4/12", },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-3/12", },
    { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-1/12", },
  ];
  const finalResponse = useCallback((response) => {
    if (response != "Success") {
      setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: response, });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Success", ModalTopMessage: "Sucesss", ModalBottomMessage: "Template Deleted Successfully.", ModalOnClickEvent: () => {
          router.push(`/TrainingManagement/TrainingManagementList`);
        }
      });
      ModalOpen();
    }
  }, [router])

  useEffect(() => {
    async function getTrainingData() {
      const currentData = await AppsyncDBconnection(getXlmsTrainingManagement, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGINFO#" + router.query["TrainingID"] }, props?.user.signInUserSession.accessToken.jwtToken)
      setTraining(currentData.res?.getXlmsTrainingManagement);
    }
    getTrainingData()
    return (() => setTraining((temp) => { return { ...temp } }))
  }, [props.TenantInfo.TenantID, props?.user.signInUserSession.accessToken.jwtToken, router.query])


  const updateTrainingData = useCallback(async (existTemplate, existData, State, e) => {
    document?.activeElement?.blur();
    e.preventDefault()
    let tempTemplate = JSON.parse(existData?.QuestionandOptions);
    let updateVariables, findActy = existTemplate?.AssessmentType == "Pre-Assessment" ? "Pre-Assessment" : existTemplate?.AssessmentType == "Post-Assessment" ? "Post-Assessment" : existTemplate?.ActivityName == "Effectiveness Survey" ? "Survey" : "Feedback";

    if (State == "Delete") {
      delete tempTemplate?.[findActy];
    } else {
      tempTemplate = {
        ...JSON.parse(existData?.QuestionandOptions),
        [findActy]: {
          ...existTemplate,
          IsSuspend: State == "Hide" ? true : false,
        }
      }
    }

    let changedActy = {};
    if (findActy == "Survey") {
      changedActy = {
        SurveyActionEnable: State == "Delete" ? "No" : existData?.SurveyActionEnable,
        TrainingSurveyTemplateID: State == "Delete" ? null : existData?.TrainingSurveyTemplateID,
        TrainingSurveyTemplateName: State == "Delete" ? null : existData?.TrainingSurveyTemplateName,
        TimeLimit: State == "Delete" ? 0 : existData?.TimeLimit
      }
    }
    else if ((findActy == "Post-Assessment" && existData?.AssessmentType == "Pre-Assessment") || (findActy == "Pre-Assessment" && existData?.AssessmentType == "Both")) {
      changedActy = {
        AssessmentType: (State == "Delete" && existData?.AssessmentType == "Pre-Assessment") ? "" : (State == "Delete" && existData?.AssessmentType == "Both") ? "Post-Assessment" : existData?.AssessmentType
      }
    }
    else if ((findActy == "Post-Assessment" && existData?.AssessmentType == "Post-Assessment") || (findActy == "Post-Assessment" && existData?.AssessmentType == "Both")) {
      changedActy = {
        AssessmentType: (State == "Delete" && existData?.AssessmentType == "Post-Assessment") ? "" : (State == "Delete" && existData?.AssessmentType == "Both") ? "Pre-Assessment" : existData?.AssessmentType
      }
    }
    else {
      changedActy = { FeedbackActionEnable: State == "Delete" ? "No" : existData?.FeedbackActionEnable, TrainingFeedbackTemplateID: State == "Delete" ? null : existData?.TrainingFeedbackTemplateID, TrainingFeedbackTemplateName: State == "Delete" ? null : existData?.TrainingFeedbackTemplateName, }
    }
    updateVariables = {
      input: [
        {
          ...existData, ...changedActy,
          QuestionandOptions: Object.keys(tempTemplate)?.length > 0 ? JSON.stringify(tempTemplate) : null,
        },
        {
          ...existData, ...changedActy,
          SK: "TRAININGINFO#LASTMODIFIEDDATE#" + existData?.LastModifiedDate + "#TRAININGID#" + existData?.TrainingID,
          QuestionandOptions: Object.keys(tempTemplate)?.length > 0 ? JSON.stringify(tempTemplate) : null,
        }]
    }
    const finalResult = (await AppsyncDBconnection(createXlmsBatchTrainingManagement,
      updateVariables, props?.user.signInUserSession.accessToken.jwtToken))
    if (findActy == "Post-Assessment" || findActy == "Pre-Assessment") {
      let exTemp = JSON.parse(existData?.QuestionandOptions)?.[findActy];
      const getActivityData = await AppsyncDBconnection(getXlmsTrainingManagementActivityInfo, { PK: "TENANT#" + props?.user?.attributes["custom:tenantid"], SK: "TRAINING#" + exTemp?.TrainingID + "#ACTIVITYTYPE#" + exTemp?.ActivityType + "#ACTIVITYID#" + exTemp?.ActivityID }, props?.user.signInUserSession.accessToken.jwtToken);
      const updateHideResponse = await AppsyncDBconnection(updateXlmsTrainingManagementActivityInfo,
        {
          input: {
            ...getActivityData?.res?.getXlmsTrainingManagementActivityInfo,
            PK: "TENANT#" + props?.user?.attributes["custom:tenantid"],
            SK: "TRAINING#" + exTemp?.TrainingID + "#ACTIVITYTYPE#" + exTemp?.ActivityType + "#ACTIVITYID#" + exTemp?.ActivityID,
            IsSuspend: State == "Hide" ? true : false
          }
        },
        props?.user.signInUserSession.accessToken.jwtToken);

    }
    if (State == "Delete") {
      let exTemp = JSON.parse(existData?.QuestionandOptions)?.[findActy];
      const DeleteUserResponse = await AppsyncDBconnection(deleteXlmsTrainingManagementActivityInfoInput,
        {
          input: {
            PK: "TENANT#" + props?.user?.attributes["custom:tenantid"],
            SK: "TRAINING#" + exTemp?.TrainingID + "#ACTIVITYTYPE#" + exTemp?.ActivityType + "#ACTIVITYID#" + exTemp?.ActivityID,
          }
        },
        props?.user.signInUserSession.accessToken.jwtToken);
    }

    if (finalResult?.Status == "Success") {
      setPopupValues({ Content: "", DataUpdate: "" })
      if (!Object.keys(tempTemplate)?.length > 0) finalResponse(finalResult?.Status)
      setIsRefreshing((count) => {
        return count + 1;
      });
    }

  }, [finalResponse, props?.user?.attributes, props?.user.signInUserSession.accessToken.jwtToken])

  const ActionRestriction = useCallback((getItem, Data, router, setPopupValues,) => {
    let ActionList = [];
    if (!getItem?.IsSuspend && (new Date(Data?.StartDate) > new Date())) {
      ActionList.push(
        {
          id: 4,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit Template",
          action: () => {
            if (getItem?.AssessmentType == "Pre-Assessment" || getItem?.AssessmentType == "Post-Assessment") { router.push(`/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${Data.TrainingID}&TrainingName=${Data.TrainingName}&AssessmentType=${getItem.AssessmentType}&Settings=QuizList&ActivityType=${getItem?.ActivityType}&Root=TemplateList`) }
            else {
              router.push(`/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${Data.TrainingID}&TrainingName=${Data.TrainingName}&ActivityType=${getItem?.ActivityType}&Root=TemplateList`)
            }
          }
        }
      )
    }
    if (getItem?.IsSuspend) {
      ActionList.push(
        {
          id: 1,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
          name: "Show Template",
          action: () => setPopupValues({ Content: "Are you sure to show the template?", DataUpdate: [getItem, Data, "Show"] })
        }
      )
    }
    if (!getItem?.IsDeleted && getItem?.IsSuspend && (new Date(Data?.StartDate) > new Date())) {
      ActionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete Template",
          action: () => setPopupValues({ Content: "Are you sure to delete the template?", DataUpdate: [getItem, Data, "Delete"] })
        }
      )
    }

    if (!getItem?.IsSuspend && (new Date(Data?.StartDate) > new Date())) {
      ActionList.push(
        {
          id: 10,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
          name: "Hide Template",
          action: () => setPopupValues({ Content: "Are you sure to hide the template?", DataUpdate: [getItem, Data, "Hide"] })
        }
      )
    }
    if (!getItem?.IsSuspend) {
      ActionList.push(
        {
          id: 10,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-magnifying-glass text-blue-600 bg-blue-100  w-6",
          name: "Preview",
          action: () => {
            if (getItem?.AssessmentType == "Pre-Assessment" || getItem?.AssessmentType == "Post-Assessment") { router.push(`/TrainingManagement/QuizPreviewTemplate?Mode=TrainingDirect&TrainingID=${Data.TrainingID}&TrainingName=${Data.TrainingName}&AssessmentType=${getItem.AssessmentType}&ActivityType=${getItem?.ActivityType}&ActivityID=${getItem?.ActivityID}`) }
            else { router.push(`/TrainingManagement/TrainingTemplatePreview?&TrainingID=${Data.TrainingID}&TemplateID=${getItem?.TemplateID}&ActivityType=${getItem?.ActivityType}`) }
          }
        }
      )
    }
    return ActionList;
  }, [])

  const GridDataBind = useCallback((viewData) => {
    let questionTemp = JSON.parse(viewData?.[0]?.QuestionandOptions);
    const RowGrid = [];
    for (const property in questionTemp) {
      if (!questionTemp[property]?.IsDeleted) {
        let ActionList = [];
        ActionList = ActionRestriction(questionTemp[property], viewData?.[0], router, setPopupValues)
        RowGrid.push({
          TemplateName: (
            <NVLlabel id={"lblPKID"} name="PK" text={questionTemp[property]?.TemplateName} />
          ),
          Activity: (
            <NVLlabel id={"lblTemplateType"} name="PK" text={questionTemp[property]?.ActivityType == "Quiz" ? questionTemp[property]?.AssessmentType : questionTemp[property]?.ActivityType} />
          ),
          Status: (
            <div className="flex m-auto w-full" title={questionTemp[property]?.IsSuspend ? "Inactive" : "Active"}>
              <div className={`rounded-full my-auto h-3 w-3 ${questionTemp[property]?.IsSuspend ? "bg-red-500" : "bg-green-600"}	`}></div>
              <NVLlabel className={`${questionTemp[property]?.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2	`} text={!questionTemp[property]?.IsSuspend ? "Active" : "Inactive"}></NVLlabel>
            </div>),
          Action: (
            <NVLRapidModal id={"RapidModal"} ActionList={ActionList}></NVLRapidModal>
          ),
        });
      }
    }
    return RowGrid;
  }, [ActionRestriction, router]
  );
  const cancelEvent = (e) => {
    e.preventDefault()
    setPopupValues({ Content: "", DataUpdate: "" })
  }
  const variable = useMemo(() => { return { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGINFO#" + router.query["TrainingID"], IsDeleted: false } }, [props.TenantInfo.TenantID, router.query])
  const PageRoutes = [
    { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
    { path: "", breadcrumb: "Training Template List" }
  ];
  return (
    <>
      <Container title="Template List" PageRoutes={PageRoutes} loader={traininingState == undefined}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} />
        <div className="max-w-full w-full justify-center">
          <NVLGridTable user={props.user}
            refershPage={isRefreshing}
            id="tblActivityList" HeaderColumn={HeaderColumn}
            GridDataBind={GridDataBind} query={listXlmsTrainingManagement}
            querryName={"listXlmsTrainingManagement"} variable={variable} />
        </div>
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateTrainingData(...popupValues?.DataUpdate, e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => cancelEvent(e)} Content={popupValues?.Content} />
      </Container>
    </>
  )
}