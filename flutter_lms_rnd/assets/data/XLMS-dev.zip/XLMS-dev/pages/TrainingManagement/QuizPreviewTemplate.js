import Container from "@components/Container/Container";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { listXlmsTrainingQuizTemplateInfos } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

export default function QuizPreviewTemplate(props) {
    const [quizQuestion, getQuizQuestion] = useState();
    const router = useRouter();
    useEffect(() => {
        const getQuestion = async () => {
            let trainingID = router.query["TrainingID"];
            let tenantID = props.user.attributes["custom:tenantid"];
            let getQuestionData = await AppsyncDBconnection(listXlmsTrainingQuizTemplateInfos, { PK: "TENANT#" + tenantID, SK: "TRAINING#" + trainingID + "#ACTIVITYID#" + router.query["ActivityID"], TemplateType: "Consume", IsDeleted: false, IsConsume: true }, props.user.signInUserSession.accessToken.jwtToken);
            getQuizQuestion({ QuestionData: getQuestionData?.res?.listXlmsTrainingQuizTemplateInfos?.items, TrainingID: trainingID })
        }; getQuestion()
    }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router])
    const validationSchema = Yup.object().shape({

    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, watch, formState } = useForm(formOptions);

    const PageRoutes = [
        { path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: `/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${quizQuestion?.TrainingID}`, breadcrumb: "Training Template List" },
        { path: "", breadcrumb: "Training Template Preview" }
    ];
    const getOptionData = useCallback((Options) => {
        let optionsData = [];
        for (let i = 0; i < Options?.length; i++) {
            optionsData?.push({ value: Options[i].Option, text: Options[i].Option });
        }
        return optionsData;
    }, []);
    return (
        <>
            <Container title="Quiz Template Preview" PageRoutes={PageRoutes}>
                {quizQuestion?.QuestionData?.map((getQuestion, index) => {
                    return (
                        <>
                            {

                                getQuestion?.QuestionType == "MultipleChoice" &&
                                <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50 p-4 rounded-md grid gap-2">
                                    <div className='flex justify-between'>
                                        <p className="text-sm font-semibold">
                                            {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                                        </p>
                                    </div>
                                    {getQuestion?.ChoiceType == "MultipleAnswer" ? (
                                        getQuestion?.Options?.map((QestinOption, indexOf) => {
                                            return (
                                                <>
                                                    <NVLCheckbox id={"chkMultipleAnswer" + (index) + "-" + (indexOf)} name={"chkMultipleAnswer" + (index) + "-" + (indexOf)} text={QestinOption?.Option?.trim()} value={QestinOption.Option} register={register} showFull={true} disabled={true}></NVLCheckbox>
                                                </>
                                            );
                                        })
                                    )
                                        : getQuestion?.ChoiceType == "SingleAnswer" ? (
                                            JSON.parse(getQuestion?.Options)?.map((QestinOption) => {
                                                return (
                                                    <>
                                                        <NVLRadio id={"SingleAnswer" + index} name={"SingleAnswer" + index} value={QestinOption?.Option} type="radio" text={QestinOption?.Option?.trim()} register={register} showFull={true} disabled={true} />
                                                    </>
                                                );
                                            })) : getQuestion?.ChoiceType == "Dropdown" ? (
                                                <>
                                                    <NVLSelectField options={getOptionData(JSON.parse(getQuestion?.Options))} name={"multiChoiceSelect" + index} id={"multiChoiceSelect" + index} className={"nvl-Def-Input"} register={register} ></NVLSelectField>
                                                </>
                                            ) :
                                            (<></>)}
                                </div>

                            }
                            {
                                getQuestion?.QuestionType == "Ordering" &&

                                <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50  p-4 rounded-md grid gap-2">
                                    <div className='flex justify-between'>
                                        <p className="text-sm font-semibold">
                                            {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                                        </p>
                                    </div>
                                    <div className="grid gap-4">
                                        {JSON.parse(getQuestion?.Options)?.map((e, indexOf) => {
                                            return (
                                                <>
                                                    <div id={indexOf} className="h-8 bg-white shadow-md rounded flex justify-between p-2 ">
                                                        {e}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                                    </div>
                                                </>
                                            );
                                        })}
                                    </div>
                                </div>


                            }
                            {
                                getQuestion?.QuestionType == "Description" &&
                                <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50  p-4 rounded-md grid gap-2">
                                    <div className='flex justify-between'>
                                        <p className="text-sm font-semibold">
                                            {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                                        </p>
                                    </div>
                                    <div className="grid gap-4">
                                        <NVLMultilineTxtbox id={"txtQuestionForQuiz" + index} title="Add Answer" register={register} className="nvl-non-mandatory nvl-Def-Input" disabled={true} />
                                    </div>

                                </div>
                            }
                            {
                                getQuestion?.QuestionType == "Match" &&

                                <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50 p-4 rounded-md grid gap-2 text-xs">
                                    <div className='flex justify-between'>
                                        <p className="text-sm font-semibold">
                                            {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                                        </p>
                                    </div>
                                    <div className="flex gap-4 justify-center">
                                        <div className='grid gap-4'>
                                            {JSON.parse(getQuestion?.Options)?.map((e) => {
                                                return (
                                                    <>
                                                        <div
                                                            className="h-8 bg-white shadow-md rounded flex justify-between p-2 "
                                                        >
                                                            {e[0]}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                                        </div>
                                                    </>
                                                );
                                            })}
                                        </div>
                                        <div className='grid gap-4'>

                                            {JSON.parse(getQuestion?.Options)?.map((e) => {
                                                return (
                                                    <>
                                                        <div draggable onDragOver={(e) => e.preventDefault()} className="h-8  bg-white shadow-md rounded flex justify-between p-2">
                                                            {e[1]}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                                        </div>
                                                    </>
                                                );
                                            })}
                                        </div>
                                    </div>
                                </div>
                            }

                            {
                                getQuestion?.QuestionType == "FillInTheBlank" &&

                                <div key={index} id={"FillInTheBlank" + index} className="bg-lime-50  p-4 rounded-md grid gap-2 ">
                                    <div className='flex justify-between'>
                                        <p className="text-sm font-semibold">
                                            {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                                        </p>
                                    </div>
                                </div>
                            }
                        </>
                    )
                })}
            </Container>
        </>);
};
