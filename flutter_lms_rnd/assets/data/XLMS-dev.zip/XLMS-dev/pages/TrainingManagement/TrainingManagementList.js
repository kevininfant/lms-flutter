import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { createXlmsBatchExternalTrainerInfo, createXlmsBatchTrainingLocationInfo, createXlmsBatchTrainingManagement, deleteXlmsTrainingManagementActivityInfoInput } from "@graphql/graphql/mutations";
import { getXlmsExternalTrainerInfo, getXlmsTrainingLocationInfo, listXlmsTrainingManagement, listXlmsTrainingManagementActivityInfos } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { BatchPut } from "BatchPutItem/BatchPut";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";


function TrainigList(props) {
  const router = useRouter()
  const [popupValues, setPopupValues] = useState({ PK: "", SK: "", Type: "", Content: "", isload: false })
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [search, setSearch] = useState("")
  const filterType = useRef("Select")

  const PageRoutes = useMemo(() => {
    return [{ path: "", breadcrumb: "Training Management" }]
  }, [])

  const headerColumn = useMemo(() => {
    return [
      { HeaderName: "Program Name", Columnvalue: "ProgramName", HeaderCss: "!w-2/12", },
      { HeaderName: "Trainer Name", Columnvalue: "TrainerName", HeaderCss: "!w-2/12", },
      { HeaderName: "Program Type", Columnvalue: "ProgramType", HeaderCss: "!w-2/12", },
      { HeaderName: "Start Date", Columnvalue: "StartDate", HeaderCss: "!w-2/12", },
      { HeaderName: "End Date", Columnvalue: "EndDate", HeaderCss: "!w-2/12", },
      { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-1/12", },
      { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-1/12", },
    ]
  }, [])
  const popup = (Type, PK, SK, Content, getItem) => {
    setPopupValues({ PK: PK, SK: SK, Type: Type, Content: Content, UpdateData: getItem, loader: false })
  }

  const resetPopUp = useCallback(() => {
    setPopupValues({ PK: "", SK: "", Type: "", Content: "", UpdateData: {}, loader: false })
    document.getElementById("tableSearch").value = "";
  }, [])

  const searchBoxVal = (e) => {
    setSearch(e);
    setIsRefreshing((count) => {
      return count + 1;
    });
  }

  const validationSchema = Yup.object().shape({
    ddlSearch: Yup.string().test("", "", (e) => {
      if (e != filterType.current && filterType.current != undefined) {
        filterType.current = e
        refreshGrid()
        document.getElementById("tableSearch").value = "";
      }
    })
  });

  const refreshGrid = useCallback(() => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  }, []);

  const headerHandler = (e, url) => {
    e.preventDefault();
    router.push(url);
  };



  const updateField = useCallback(async (e) => {
    setPopupValues((temp) => { return { ...temp, isload: true } });
    e.preventDefault()
    let isSus = false;
    let isDelete = false;
    if (popupValues.Type == "isSuspend") {
      isSus = true;
    } else if (popupValues.Type == "isDelete") {
      isDelete = true;
    }
    const RemoveNull = (obj) => {
      let tempjson = {};
      obj && Object.keys(obj).forEach((k) => {
        if (obj?.[k] != undefined) {
          tempjson = { ...tempjson, [k]: obj?.[k] }
        }
      });
      return tempjson;
    };
    let temp = RemoveNull(popupValues?.UpdateData);
    if (popupValues?.UpdateData?.Shard != undefined) {
      BatchPut({ Values: temp, Shard: popupValues?.UpdateData?.Shard, query: createXlmsBatchTrainingManagement, UpdateData: { IsSuspend: isSus, IsDeleted: isDelete, LastModifiedDate: new Date() }, user: props.user.signInUserSession.accessToken.jwtToken });
    }
    const TrainingID = temp.TrainingID
    let trainingVariable = {
      input: [{ ...temp, IsDeleted: true, AutoDelete: Date.now() / 1000 + 24 * 60 | 0 },
      { ...temp, SK: "TRAININGINFO#" + TrainingID, LastModifiedDate: new Date().toISOString(), IsSuspend: isSus, IsDeleted: isDelete },
      { ...temp, SK: "TRAININGINFO#LASTMODIFIEDDATE#" + new Date().toISOString() + "#TRAININGID#" + TrainingID, LastModifiedDate: new Date().toISOString(), IsSuspend: isSus, IsDeleted: isDelete }
      ]
    }

    let finalStatus = await AppsyncDBconnection(createXlmsBatchTrainingManagement, trainingVariable, props?.user.signInUserSession.accessToken.jwtToken)
    const quizData = await AppsyncDBconnection(listXlmsTrainingManagementActivityInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAINING#" + props.TenantInfo.TenantID + "#ACTIVITYTYPE#QUIZ#ACTIVITYID#", IsSuspend: false, IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
    if (popupValues.Type == "isDelete" && finalStatus.Status == "Success") {
      quizData?.res?.listXlmsTrainingManagementActivityInfos?.items && quizData?.res?.listXlmsTrainingManagementActivityInfos?.items.map(async (item) => {
        await AppsyncDBconnection(deleteXlmsTrainingManagementActivityInfoInput, { input: { PK: "", SK: "TRAINING#" + props.TenantInfo.TenantID + "#ACTIVITYTYPE#QUIZ#ACTIVITYID#" + item?.ActivityID } }, props?.user.signInUserSession.accessToken.jwtToken)
      })
      const unSelectedVariables = [], unSelectedTrainerVariables = []
      const locationData = await AppsyncDBconnection(getXlmsTrainingLocationInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGLOCATIONINFO#" + popupValues.UpdateData.LocationID }, props?.user.signInUserSession.accessToken.jwtToken)
      const location = locationData?.res.getXlmsTrainingLocationInfo
      let UnselectedLocation = location?.MappedTraining != null ? JSON.parse(location?.MappedTraining)?.filter((getItem) => { return getItem.TrainingID != TrainingID }) : []
      unSelectedVariables = [...unSelectedVariables, { ...location, MappedTraining: JSON.stringify(UnselectedLocation) },
      { ...location, SK: "TRAININGLOCATIONINFO#LASTMODIFIED#" + location.LastModifiedDate + "#LOCATIONID#" + location.LocationID, MappedTraining: JSON.stringify(UnselectedLocation) }]
      finalStatus = await AppsyncDBconnection(createXlmsBatchTrainingLocationInfo, { input: unSelectedVariables }, props?.user?.signInUserSession?.accessToken?.jwtToken)

      if (popupValues.UpdateData.TrainerType == "External") {
        const externalTrainerResponse = await AppsyncDBconnection(getXlmsExternalTrainerInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "EXTERNALTRAINERINFO#" + popupValues.UpdateData.TrainerID }, props.user?.signInUserSession?.accessToken?.jwtToken)
        const trainer = externalTrainerResponse?.res.getXlmsExternalTrainerInfo
        let UnselectedTrainer = trainer?.MappedTraining != null ? JSON.parse(trainer?.MappedTraining)?.filter((getItem) => { return getItem.TrainingID != TrainingID }) : []
        unSelectedTrainerVariables = [...unSelectedTrainerVariables, { ...trainer, MappedTraining: JSON.stringify(UnselectedTrainer) },
        { ...trainer, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#" + trainer.LastModifiedDate + "#EXTERNALTRAINERID#" + trainer.ExternalTrainerID, MappedTraining: JSON.stringify(UnselectedTrainer) }]
        finalStatus = await AppsyncDBconnection(createXlmsBatchExternalTrainerInfo, { input: unSelectedTrainerVariables }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      }
    }

    if (finalStatus.Status == "Success") {
      refreshGrid()
    }
    setPopupValues((temp) => { return { ...temp, isload: true } });
    resetPopUp()
  }, [popupValues, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, refreshGrid, resetPopUp])

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
  const { register, setValue, formState, watch } = useForm(formOptions);
  const { errors } = formState;

  useEffect(() => {
    setValue("ddlSearch", "Select")
  }, [setValue])

  const convertDate = useCallback((date) => {
    const timeOfHour = new Date(date).getHours() >= 12 ? " pm" : " am";
    const hour = new Date(date).getHours() % 12 >= 10 ? new Date(date).getHours() % 12 : "0" + new Date(date).getHours() % 12;
    const minute = new Date(date).getMinutes() >= 10 ? new Date(date).getMinutes() : "0" + new Date(date).getMinutes();
    return new Date(date).toDateString().substring(4) + " , " + (hour == "00" ? "12" : hour) + ":" + minute + timeOfHour
  }, [])

  const questionVal = useCallback((item, Assessment) => {
    if (item && JSON.parse(item).hasOwnProperty(Assessment)) {
      return false
    }
    else {
      return true
    }
  }, [])
  const ActionRestriction = useCallback((getItem) => {
    let actionList = [];
    
    if (props?.RoleData?.ShowTraining && getItem.IsSuspend) {
      actionList.push(
        {
          id: 1,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
          name: "Show Training",
          action: () => popup("", getItem.PK, getItem.SK, "Are you sure to show the training?", getItem),
        }
      )
    }
    if (props?.RoleData?.DeleteTraining && getItem.IsSuspend) {
      actionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete Training",
          action: () => popup("isDelete", getItem.PK, getItem.SK, "Are you sure to delete the training?", getItem),
        }
      )
    }
    if (props?.RoleData?.EditTraining && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 3,
          Color: "text-green-700",
          Icon: new Date(getItem?.StartDate) >= new Date() ? "fa-solid fa-pencil text-green-700  bg-green-100 w-6" : "fa-solid fa-magnifying-glass text-blue-600 bg-blue-100  w-6",
          name: new Date(getItem?.StartDate) >= new Date() && (getItem?.IsTrainingEnrolled == false && getItem?.IsSelfEnrolled == false) ? "Edit Training" : "Preview Training",
          action: () => router.push(`/TrainingManagement/CreateTraining?TrainingID=${getItem.TrainingID}`),
        }
      )
    }
    if (props?.RoleData?.EnrollUserTraining && !getItem.IsSuspend && (getItem.TrainingType == "Mandatory") && new Date(getItem?.StartDate) >= new Date()) {
      actionList.push(
        {
          id: 3,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Assign to user",
          action: () => router.push(`/TrainingManagement/TrainingEnrollUser?TrainingID=${getItem.TrainingID}`),
        }
      )
    }
    if ((props?.RoleData?.AddTrainingPreAssessment && !getItem.IsSuspend && (getItem.AssessmentType == "Both" || getItem.AssessmentType == "Pre-Assessment") && questionVal(getItem?.QuestionandOptions, "Pre-Assessment") && new Date(getItem?.StartDate) >= new Date())) {
      actionList.push(
        {
          id: 4,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-pencil text-blue-600 w-6",
          name: "Add Pre-Assessment",
          action: () => router.push(`/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${getItem.TrainingID}&TrainingName=${getItem.TrainingName}&ActivityType=Quiz&AssessmentType=Pre-Assessment`)
        }
      )
    }
    if ((props?.RoleData?.AddTrainingPostAssessment && !getItem.IsSuspend && (getItem.AssessmentType == "Both" || getItem.AssessmentType == "Post-Assessment") && questionVal(getItem?.QuestionandOptions, "Post-Assessment") && new Date(getItem?.StartDate) >= new Date())) {
      actionList.push(
        {
          id: 4,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-pencil text-blue-600 w-6",
          name: "Add Post-Assessment",
          action: () => router.push(`/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${getItem.TrainingID}&TrainingName=${getItem.TrainingName}&ActivityType=Quiz&AssessmentType=Post-Assessment`)
        }
      )
    }
    if (props?.RoleData?.TrainingEffectivenessSurvey &&
      !getItem.IsSuspend && getItem.SurveyActionEnable == "Yes" && getItem?.TrainingSurveyTemplateID == "Create") {
      actionList.push(
        {
          id: 5,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-square-poll-vertical text-blue-700  bg-blue-100 w-6",
          name: "Training Effectiveness Survey",
          action: () => router.push(`/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${getItem.TrainingID}&TrainingName=${getItem.TrainingName}&ActivityType=Survey`)
        }
      )
    }
    if (props?.RoleData?.TrainingFeedback && !getItem.IsSuspend && getItem.FeedbackActionEnable == "Yes" && getItem?.TrainingFeedbackTemplateID == "Create") {
      actionList.push(
        {
          id: 6,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-message text-green-700  bg-green-100 w-6",
          name: "Add Feedback",
          action: () => router.push(`/TrainingManagement/TrainingCreateActivity?Mode=TrainingDirect&TrainingID=${getItem.TrainingID}&TrainingName=${getItem.TrainingName}&ActivityType=Feedback`)
        }
      )
    }
    if (props?.RoleData?.AddTrainingBadge && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 7,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-ribbon bg-red-100 text-red-500 w-6",
          name: "Add Badge",
          action: () => router.push(`/TrainingManagement/AddBadge?Mode=TrainingDirect&TrainingID=${getItem.TrainingID}&TrainingName=${getItem.TrainerName}`)
        }
      )
    }

    if (props?.RoleData?.AddTrainingCertificate && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 8,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-certificate text-blue-700  bg-blue-100 w-6",
          name: "Add Certificate",
          action: () => router.push(`/TrainingManagement/AddCertificate?Mode=TrainingDirect&TrainingID=${getItem.TrainingID}&TrainingName=${getItem.TrainingName}`)
        }
      )
    }
    if (props?.RoleData?.TrainingAttendanceManagement && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 8,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-clipboard-user text-blue-700  bg-blue-100 w-6",
          name: "Attendance Management",
          action: () => router.push(``)
        }
      )
    }
    if (props?.RoleData?.TrainingSendNotification && !getItem.IsSuspend && new Date(getItem?.EndDate) >= new Date()) {
      actionList.push(
        {
          id: 8,
          Color: "text-yellow-600",
          Icon: "fa-regular fa-envelope text-green-700  bg-green-100 w-6",
          name: "Send Notification",
          action: () => router.push(`/TrainingManagement/TrainingNotificationList?TrainingID=${getItem.TrainingID}`)
        }
      )
    }
    if (props?.RoleData?.Unenrollment && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 8,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Unenrolment",
          action: () => router.push(``)
        }
      )
    }
    if (props?.RoleData?.Gotosession && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 8,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-certificate text-blue-700  bg-blue-100 w-6",
          name: "Go to session",
          action: () => router.push(`/TrainingManagement/TrainingSession?TrainingID=${getItem.TrainingID}`)
        }
      )
    }
    if (props?.RoleData?.HideTraining && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 9,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
          name: "Hide Training",
          action: () => popup("isSuspend", getItem.PK, getItem.SK, "Are you sure to hide the training?", getItem),
        }
      )
    }
    return actionList;
  }, [props?.RoleData?.AddTrainingBadge, props?.RoleData?.AddTrainingCertificate, props?.RoleData?.AddTrainingPostAssessment, props?.RoleData?.AddTrainingPreAssessment, props?.RoleData?.DeleteTraining, props?.RoleData?.EditTraining, props?.RoleData?.EnrollUserTraining, props?.RoleData?.Gotosession, props?.RoleData?.HideTraining, props?.RoleData?.ShowTraining, props?.RoleData?.TrainingAttendanceManagement, props?.RoleData?.TrainingEffectivenessSurvey, props?.RoleData?.TrainingFeedback, props?.RoleData?.TrainingSendNotification, props?.RoleData?.Unenrollment, questionVal, router])

  const getTemplate = useCallback((Items, index) => {

    let tempNum = JSON.parse(Items?.QuestionandOptions) ? Object.keys(JSON.parse(Items?.QuestionandOptions))?.length : 0;
    let finalItem;
    if ((Items.SurveyActionEnable == "Yes" && tempNum > 0) || (Items.FeedbackActionEnable == "Yes" && tempNum > 0) || ((Items.AssessmentType == "Pre-Assessment" || Items.AssessmentType == "Post-Assessment" || Items.AssessmentType == "Both") && tempNum > 0)) {
      finalItem = <NVLLink classNameLink="!hover:bg-#" text={Items.TrainingName} className="break-all text-xs " onClick={() => router.push(`/TrainingManagement/TrainingTemplateList?Mode=TemplateEdit&TrainingID=${Items.TrainingID}&TrainingName=${Items.TrainingName}`)}></NVLLink>;
    } else {
      finalItem = <NVLlabel id={"txtTrainingName" + (index + 1)} text={Items.TrainingName} />;
    }
    return finalItem;
  },
    [router],
  )
  const gridDataBind = useCallback((viewData) => {
    const rowGrid = [];
    viewData && viewData.map((getItem, index) => {
      rowGrid.push({
        PK: <NVLlabel id={"txtPK" + (index + 1)} />,
        SK: <NVLlabel id={"txtSK" + (index + 1)} />,
        TrainingID: <NVLlabel id={"txtID" + (index + 1)} text={getItem.TrainingID} />,
        ProgramName: getTemplate(getItem, index),
        TrainerName: <NVLlabel id={"txtTrainingName" + (index + 1)} text={getItem.TrainerName} />,
        ProgramType: <NVLlabel id={"txtType" + (index + 1)} text={getItem.TrainingType} />,
        StartDate: <NVLlabel id={"txtDate" + (index + 1)} text={convertDate(getItem.StartDate)} />,
        EndDate: <NVLlabel id={"txtEnd" + (index + 1)} text={convertDate(getItem.EndDate)} />,
        Status: <>
          <div className="flex my-auto w-full">
            <div className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"}`}></div>
            <NVLlabel id={"status" + (index + 1)} text={getItem.IsSuspend ? "Inactive" : "Active"} className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2`} />
          </div>
        </>,
        Action: <NVLRapidModal id={"action" + (index + 1)} ActionList={ActionRestriction(getItem)} />
      })
    })
    return rowGrid;
  }, [ActionRestriction, convertDate, getTemplate])

  const cancelClick = (e) => {
    e.preventDefault()
    resetPopUp()
    // refreshGrid()
  }

  const FilterOptions = useMemo(() => {
    return [{ value: "Select", text: "Select" }, { value: "Ongoing", text: "Ongoing" }, { value: "Upcoming", text: "Upcoming" }, { value: "Past", text: "Past" }]
  }, [])

  // const currentDate = useCallback(() => {
  //   return new Date().getFullYear() + "-" + (new Date().getMonth() + 1 >= 10 ? new Date().getMonth() + 1 : "0" + (new Date().getMonth() + 1)) + "-" + (new Date().getDate() < 9 ? "0" + new Date().getDate() : new Date().getDate()) + "T" + new Date().getHours() + ":" + (new Date().getMinutes() > 9 ? new Date().getMinutes() : "0" + new Date().getMinutes())
  // }, [])



  const variable = useCallback(() => {
    return { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGINFO#LASTMODIFIEDDATE#", TrainingType: filterType.current, CurrentDate: new Date().toISOString(), IsDeleted: false }
  }, [props.TenantInfo.TenantID])

  return (
    <>
      <Container title="Training list" PageRoutes={PageRoutes}>
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} IsSearch={props.RoleData?.SeTenanthTraining ? true : false} IsDropdown={true} DropdownData={FilterOptions} DropdownRequired={true} register={register} errors={errors} ButtonID5="btnCreateTraining" LinkName5="+ Create Training" className5={props.RoleData.CreateTraining ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectAction5={(e) => headerHandler(e, "/TrainingManagement/CreateTraining")} href5="/TrainingManagement/CreateTraining"
          ButtonID4="btnTrainingData" LinkName4="Training Data" className4={props.RoleData.TrainingData ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectAction4={(e) => headerHandler(e, "/TrainingManagement/TrainingLocationList")} href4="/TrainingManagement/TrainingLocationList" RedirectHome={"/"}
          placeholder={"Search by Training name"}
          SearchonChange={(e) => searchBoxVal(e)}
          onClick1={refreshGrid}
          RedirectAction3={() => refreshGrid()}
          IsNestedHeader
        />
        <div className="max-w-full w-full justify-center pt-2">
          <NVLGridTable user={props.user}
            refershPage={isRefreshing}
            id="tblTrainingList" Search={search}
            HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsTrainingManagement}
            querryName={"listXlmsTrainingManagement"}
            variable={variable()} />
        </div>
        <NVLModalPopup ButtonYestext="Yes" loader={popupValues.isload} SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelClick(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
      </Container>
    </>
  )
}
export default TrainigList;