import AddBadge from "@Pages/ActivityManagement/AddBadge";
import { useRouter } from "next/router";

function AddTrainingBadge(props) {
    const router = useRouter();
    return (
        <>
            <AddBadge user={props.user}
                props={props}
                trainerID={router.query["TrainingID"]}
                trainerName={router.query["TrainingName"]}
                mode={router.query["Mode"]}
                TenantInfo={props.TenantInfo}
            />
        </>
    );
}
export default AddTrainingBadge;