import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsBatchInventoryInfo } from "@graphql/graphql/mutations";
import { getXlmsInventoryInfo, listXlmsInventoryInfo } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";



function InventoryType(props) {
    const [message, setMessage] = useState("");
    const router = useRouter()
    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/TrainingManagement/InventoryTypeList")
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);
    const [fetchData, setFetchData] = useState()

    useEffect(() => {
        async function inventoryData() {
            let editInventory = await AppsyncDBconnection(getXlmsInventoryInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "INVENTORYINFO#" + router.query["InventoryID"] }, props?.user.signInUserSession.accessToken.jwtToken)
            let inventoryList = await AppsyncDBconnection(listXlmsInventoryInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "INVENTORYINFO#LASTMODIFIEDDATE#",InventoryType: "InventoryList", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
            setFetchData({
                EditData: editInventory.res.getXlmsInventoryInfo != undefined ? editInventory.res.getXlmsInventoryInfo : {},
                InventoryList: inventoryList.res.listXlmsInventoryInfo?.items
            })
        }
        inventoryData()
        return setFetchData((data) => { return { ...data } })
    }, [props.TenantInfo.TenantID, props?.user.signInUserSession.accessToken.jwtToken, router.query])

    const validationSchema = Yup.object().shape({
        txtInventoryName: Yup.string().required("Inventory name is required").min(3, "Required minimum of 3 characters")
            .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Inventory name is invalid").max(150, "Maximum limit exceeds").nullable()
            .test("", "Inventory name already exists", (e) => {
                const existingInventoryName = fetchData?.InventoryList;
                const InventoryNameFound = existingInventoryName && existingInventoryName?.some((data) => data.InventoryName?.toLowerCase() == e?.toLowerCase());
                if (InventoryNameFound && (router.query["Mode"] == "Edit" || router.query["Mode"] == "Create") && e?.toLowerCase() != fetchData?.EditData?.InventoryName?.toLowerCase()) {
                    if (e?.toLowerCase() != fetchData?.EditData?.InventoryName?.toLowerCase()) {
                        return false;
                    }
                }
                return true
            })
    })

    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: finalStatus,
            });
            ModalOpen();
            return;
        } else {
            setValue("submit", true);
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    router.push("/TrainingManagement/InventoryTypeList")
                },
            });
            ModalOpen();
        }
    }, [router, setValue]);

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, reset, formState, clearErrors } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        if (router.query["Mode"] == "Edit") {
            setValue('txtInventoryName', fetchData?.EditData?.InventoryName)
            if (message != "") {
                setHTMLContents(fetchData?.EditData?.InventoryDescription, message);
                message?.history?.clear();
            }
        }
    }, [fetchData?.EditData?.InventoryDescription, fetchData?.EditData?.InventoryName, message, router.query, setValue])

    const submitHandler = async (data) => {
        document?.activeElement?.blur();
        setValue("submit", true)
        const PK = router.query["Mode"] != "Edit" ? "TENANT#" + props.TenantInfo.TenantID : fetchData.EditData.PK
        const date = new Date().toISOString();
        const InventoryID = router.query["Mode"] != "Edit" ? Math.random().toString(25).substring(2, 12) : fetchData.EditData.InventoryId
        const inventoryName = data.txtInventoryName?.replace(/\s{2,}(?!\s)/g, ' ').trim()
        let Description;
        
       if (!message?.editor.delta.ops[0]["insert"].image) {
            Description = getContents(message)?.replace(/(<([^>]+)>)/gi, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ")  == "" ? "" : getContents(message)
         } else {
            Description =  message?.editor.delta.ops[0]["insert"].image?.replaceAll(/<img[^>]+>/g, "re")?.trim().length == 0 ||getContents(message)?.replaceAll(/<img[^>]+>/g, "")?.length == 0 ? "" : getContents(message)
         }

        let finalResult;
        if (router.query["Mode"] != "Edit") {
            const SK = "INVENTORYINFO#LASTMODIFIEDDATE#" + date + "#INVENTORYID#" + InventoryID;

            const batchVariables = {
                input: [
                    { PK: PK, SK: SK, InventoryId: InventoryID, InventoryName: inventoryName, InventoryNameLowerCase: inventoryName?.toLowerCase, LastModifiedDate: date, CreatedDate: date, InventoryDescription: Description, IsSuspend: false, IsDeleted: false, CreatedBy: props.user?.username, LastModifiedBy: props.user?.username, },
                    { PK: PK, SK: "INVENTORYINFO#" + InventoryID, InventoryId: InventoryID, InventoryName: inventoryName, InventoryNameLowerCase: inventoryName?.toLowerCase, LastModifiedDate: date, CreatedDate: date, InventoryDescription: Description, IsSuspend: false, IsDeleted: false, CreatedBy: props.user?.username, LastModifiedBy: props.user?.username, }
                ]
            }
            finalResult = (await AppsyncDBconnection(createXlmsBatchInventoryInfo, batchVariables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status
        }

        if (router.query["Mode"] == "Edit") {

            const updatevariables = {
                input: [
                    { ...fetchData.EditData, SK: "INVENTORYINFO#LASTMODIFIEDDATE#" + fetchData?.EditData?.LastModifiedDate + "#INVENTORYID#" + InventoryID, IsDeleted: true },
                    { ...fetchData.EditData, InventoryName: inventoryName, InventoryNameLowerCase: inventoryName?.toLowerCase, InventoryDescription: Description, LastModifiedBy: props.user?.username, LastModifiedDate: date },
                    { ...fetchData.EditData, InventoryName: inventoryName, InventoryNameLowerCase: inventoryName?.toLowerCase, InventoryDescription: Description, LastModifiedBy: props.user?.username, LastModifiedDate: date, SK: "INVENTORYINFO#LASTMODIFIEDDATE#" + date + "#INVENTORYID#" + InventoryID }
                ]
            }
            finalResult = (await AppsyncDBconnection(createXlmsBatchInventoryInfo, updatevariables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status
        }
        finalResponse(finalResult)
        setValue("submit", false)
    }
    const PageRoutes = useMemo(() => {
        return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
        { path: "/TrainingManagement/TrainingLocationList", breadcrumb: "Training Location List" },
        { path: "/TrainingManagement/InventoryTypeList", breadcrumb: "Inventory Type List" },
        { path: "", breadcrumb: router.query["Mode"] != "Edit" ? "Add Inventory Type" : "Edit Inventory Type" }]
    }, [router.query])

    const clearField = useCallback(() => {
        setValue("txtInventoryName", "")
        setHTMLContents("", message);
        clearErrors()
    }, [clearErrors, message, setValue])

    return (
        <>
            <Container loader={fetchData?.EditData == undefined ? true : false} title={router.query["Mode"] != "Edit" ? "Add Inventory Type" : "Edit Inventory Type" } PageRoutes={PageRoutes}>
                <form onSubmit={handleSubmit(submitHandler)} id="divInventory">
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className={watch("submit") ? "pointer-events-none nvl-FormContent":"nvl-FormContent"}>
                        <NVLTextbox id="txtInventoryName" labelText="Inventory name" labelClassName="nvl-Def-Label pb-1" title="Inventory name" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <NVLlabel text="Inventory description" className="nvl-Def-Label pb-1" />
                        <NVLRichTextBox id="txtInventoryDescription" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} />
                        <div className="flex justify-center gap-2 pt-4">
                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Save" : ""} type="submit" className={"w-32 nvl-button bg-primary text-white"}>
                                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                            </NVLButton>
                            <NVLButton id="btnCancel" text={router.query["Mode"] != "Edit" ? "Clear" : "Cancel"} type="button" className="nvl-button w-28" onClick={() => router.query["Mode"] != "Edit" ? clearField() : router.push("/TrainingManagement/InventoryTypeList")}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    )
}

export default InventoryType
