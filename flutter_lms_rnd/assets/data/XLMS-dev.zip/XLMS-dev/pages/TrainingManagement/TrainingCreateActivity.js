import ActivityInfo from '@Pages/ActivityManagement/ActivityInfo';
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { getXlmsCourseActivityConfig, listXlmsTrainingManagementActivityInfos } from "src/graphql/queries";

export default function TrainingCreateActivity(props) {
  const router = useRouter();
  const [csrFetchedData, setCsrFetchedData] = useState({});

  useEffect(() => {
    async function fetchData() {
      let Mode = decodeURIComponent(String(router.query["Mode"]));
      let TrainingId = decodeURIComponent(String(router.query["TrainingID"]));
      let TrainingName = decodeURIComponent(String(router.query["TrainingName"]));
      let ActivityType = decodeURIComponent(String(router.query["ActivityType"]));
      let assessmentType = decodeURIComponent(String(router.query["AssessmentType"]));
      let root = decodeURIComponent(String(router.query["Root"]));
      let TenantID = props?.user.attributes["custom:tenantid"];
      const activityData = await AppsyncDBconnection(getXlmsCourseActivityConfig, {
        PK: "XLMS#ACTIVITY",
        SK: "ACTIVITY#ACTIVITYTYPE",
      }, props.user.signInUserSession.accessToken.jwtToken);
      const getQuizData = await AppsyncDBconnection(listXlmsTrainingManagementActivityInfos, {
        PK: "TENANT#" + TenantID,
        SK: "TRAINING#" + TrainingId + "#ACTIVITYTYPE#" + ActivityType,
        IsDeleted: false,
        Type: "Assessment",
        AssessmentType: assessmentType
      }, props.user.signInUserSession.accessToken.jwtToken)
      const getEditdata = await AppsyncDBconnection(listXlmsTrainingManagementActivityInfos, {
        PK: "TENANT#" + TenantID,
        SK: "TRAINING#" + TrainingId + "#ACTIVITYTYPE#" + ActivityType
      }, props.user.signInUserSession.accessToken.jwtToken);
     
      let ids = (assessmentType == "Pre-Assessment" || assessmentType == "Post-Assessment") ? getQuizData?.res?.listXlmsTrainingManagementActivityInfos?.items?.[0]?.ActivityID : getEditdata?.res?.listXlmsTrainingManagementActivityInfos?.items?.[0]?.ActivityID;

      const temp = {
        Root:root,
        EditData: (assessmentType == "Pre-Assessment" || assessmentType == "Post-Assessment") ? getQuizData?.res?.listXlmsTrainingManagementActivityInfos?.items?.[0] : getEditdata?.res?.listXlmsTrainingManagementActivityInfos?.items?.[0],
        TenantID: TenantID,
        TrainingId: TrainingId,
        TrainingName: TrainingName,
        AssessmentType: assessmentType,
        ActivityID: ids ? ids : crypto.randomUUID().toString(25).substring(2, 12),
        mode: Mode,
        ActivityType: ActivityType,
        user: props.user,
        TenantInfo: props?.TenantInfo,
        ActivityData: activityData.res?.getXlmsCourseActivityConfig
      }
      setCsrFetchedData(temp);
    }
    fetchData();
  }, [props?.TenantInfo, props.user, props.user.signInUserSession.accessToken.jwtToken, router.query])
  return (
    <div>
      {csrFetchedData?.ActivityData && <ActivityInfo {...csrFetchedData} />}
    </div>
  )
}