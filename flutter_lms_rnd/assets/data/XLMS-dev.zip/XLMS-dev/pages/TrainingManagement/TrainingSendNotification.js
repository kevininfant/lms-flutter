import Notification from "@Pages/ActivityManagement/Notification";
import { useRouter } from "next/router";

function TrainingSendNotification(props) {
    const router = useRouter();
    
    return (
        <div>
            <Notification user={props.user} 
                TenantInfo={props.TenantInfo} 
                TrainingID={router.query["TrainingID"]}
                GeneralRoleData={props.GeneralRoleData} 
                RoleData={props.RoleData} 
                props={props}/>
        </div>
    );
}

export default TrainingSendNotification;

