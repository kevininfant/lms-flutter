import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { createXlmsBatchInventoryInfo } from "@graphql/graphql/mutations";
import { listXlmsInventoryInfo } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";

function InventoryTypeList(props){
    const router = useRouter()
    const [popupValues,setPopupValues] = useState({PK: "", SK: "", Content: "", Type: "",UpdateData:{},loader:false})
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("")
    const headerColumn = [
        {HeaderName: "Inventory Name", Columnvalue: "InventoryName", HeaderCss: "!w-3/12", },
        {HeaderName: "Inventory Description", Columnvalue: "InventoryDescription", HeaderCss: "!w-4/12", },
        {HeaderName: "Created Date", Columnvalue: "CreatedDate", HeaderCss: "!w-2/12", },
        {HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-2/12", },
        {HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-1/12", },
    ]

    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
          return count + 1;
        });
      }
    
      const refreshGrid = useCallback(() => {
        setSearch("");
        setIsRefreshing((count) => {
          return count + 1;
        });
      },[]);

      function resetPopUp() {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "",UpdateData:{},loader:false });
        document.getElementById("tableSearch").value = "";
      }
      
      function popup(type, PK, SK, Content,getItem) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type,UpdateData:getItem,loader: false  });
      }

      async function updateField(e){
        setPopupValues((temp) => { return { ...temp, loader: true } });
        e.preventDefault();
        let isSus = false;
        let isDelete = false;
        if (popupValues.Type == "isSuspend") {
          isSus = true;
        } else if (popupValues.Type == "isDelete") {
          isDelete = true;
        } 
        
        let InventoryID =  popupValues.SK?.substring(popupValues.SK?.lastIndexOf("#")+1)
         
        let variable =  {input : [{...popupValues.UpdateData, IsDeleted : true},
          {...popupValues.UpdateData,SK:"INVENTORYINFO#LASTMODIFIEDDATE#" + new Date().toISOString() + "#INVENTORYID#" + InventoryID , LastModifiedDate:new Date().toISOString() ,IsSuspend: isSus , IsDeleted : isDelete},
          {...popupValues.UpdateData,SK:"INVENTORYINFO#"+InventoryID, LastModifiedDate:new Date().toISOString() ,IsSuspend: isSus , IsDeleted : isDelete} ]}
        const finalResponse = await AppsyncDBconnection(createXlmsBatchInventoryInfo,variable, props?.user.signInUserSession.accessToken.jwtToken)
      
        if (finalResponse.Status == "Success") {
          refreshGrid()
        }
        setPopupValues((temp) => { return { ...temp, loader: false } });
        resetPopUp();
      }

    const PageRoutes = useMemo(() => {
        return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management"},
                { path: "/TrainingManagement/TrainingLocationList", breadcrumb: "Training Location List"},
                { path: "", breadcrumb: "Inventory Type List"}]
    }, [])
    
    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
      };

    const ActionRestriction = useCallback((getItem)=>{
        let actionList = [];
        if (props.RoleData?.ShowInventoryType && getItem.IsSuspend) {
            actionList.push(
              {
                id: 1,
                Color: "text-yellow-600",
                Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                name: "Show Inventory",
                action: () =>
                  popup(
                    "",
                    getItem.PK,
                    getItem.SK,
                    "Are you sure to Show Inventory Type?",
                    getItem
                  ),
              }
            )
          } 
          if (props.RoleData?.DeleteInventoryType && getItem.IsSuspend) {
            actionList.push(
              {
                id: 2,
                Color: "text-rose-700",
                Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                name: "Delete Inventory",
                action: () =>
                  popup(
                    "isDelete",
                    getItem.PK,
                    getItem.SK,
                    `${getItem?.MappedLocationID != null && JSON.parse(getItem?.MappedLocationID).length != 0  ? `Inventory type have been mapped to ${JSON.parse(getItem?.MappedLocationID).length} Training locations. Are you sure to Delete Inventory Type?` :  "Are you sure to Delete Inventory Type?" }`,
                    getItem
                    ),
              }
            )
          }
          if (props.RoleData?.EditInventoryType && !getItem.IsSuspend) {
            actionList.push(
              {
                id: 3,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit Inventory",
                action: () =>
                  router.push(
                    `/TrainingManagement/InventoryType?Mode=Edit&InventoryID=${getItem.InventoryId}`
                  ),
              }
            )
          }
          if (props.RoleData?.HideInventoryType && !getItem.IsSuspend) {
            actionList.push(
              {
                id: 4,
                Color: "text-yellow-600",
                Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                name: "Hide Inventory",
                action: () =>
                  popup(
                    "isSuspend",
                    getItem.PK,
                    getItem.SK,
                    `${getItem?.MappedLocationID != null && JSON.parse(getItem?.MappedLocationID).length !=0 ? `Inventory type have been mapped to ${JSON.parse(getItem?.MappedLocationID).length} Training locations. Are you sure to Hide Inventory Type?` : "Are you sure to Hide Inventory Type?" }`,
                    getItem
                  ),
              }
            )
          }
          return actionList;
    },[props.RoleData?.DeleteInventoryType, props.RoleData?.EditInventoryType, props.RoleData?.HideInventoryType, props.RoleData?.ShowInventoryType, router])  

    function getDateFormat(CreatedDt) {
      return (new Date(CreatedDt).toDateString().substring(4))
    }

    const gridDataBind = useCallback((viewData) =>{
        const rowGrid = []
        viewData.map((getItem,index)=>{
            let regex = /(<([^>]+)>)/gi,
            body = getItem.InventoryDescription,
            result = body?.replace(regex, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ")
            rowGrid.push({
                PK: <NVLlabel id={"txtPK"+(index+1)} text={getItem.PK}/>,
                SK: <NVLlabel id={"txtSK"+(index+1)} text={getItem.SK}/>,
                InventoryID: <NVLlabel id={"txtInventoryID"+(index+1)} text={getItem.InventoryID}/>,
                InventoryName: <NVLlabel id={"txtName"+(index+1)} text={getItem.InventoryName}/>,
                InventoryDescription: <NVLlabel id={"txtDescription"+(index+1)} text={result}/>,
                CreatedDate: <NVLlabel id={"txtdate"+(index+1)} text={getDateFormat(getItem.CreatedDate)}/>,
                Status: (
                    <>
                      <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                        <div
                          className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"
                            }	`}
                        ></div>
                        <NVLlabel
                          className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"
                            } my-auto ml-2	`}
                          text={!getItem.IsSuspend ? "Active" : "Inactive"}
                        ></NVLlabel>
                      </div>
                    </>
                  ),
                  Action: (
                    <NVLRapidModal
                      id={"RapidModal" + (index + 1)}
                      ActionList={ActionRestriction(getItem)}
                      index={(index+1) > 10 ? (index+1)%10 : index+1}
                    ></NVLRapidModal>
                  ),
            })
        })
        return rowGrid
    } ,[ActionRestriction])

    const cancelEvent = (e) =>{
        e.preventDefault()
        resetPopUp()
        refreshGrid()
    }
    const variable = useMemo(()=>{return {PK: "TENANT#" + props.TenantInfo.TenantID , SK:"INVENTORYINFO#LASTMODIFIEDDATE#",InventoryType:"InventoryList", IsDeleted:false }},[props.TenantInfo.TenantID]) 
return (
    <>
    <Container title="Inventory Type List" PageRoutes={PageRoutes}>
    <NVLHeader 
    TabRouting={props?.GeneralRoleData?.AllowNewTab} 
    IsSearch={props.RoleData?.InventoryKeywordSeTenanth ? true : false} 
    ButtonID5="btnInventoryType" LinkName5="+ Add Inventory Type" className5={props.RoleData?.AddInventoryType ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectAction5={(e) => headerHandler(e, "/TrainingManagement/InventoryType?Mode=Create")} href5="/TrainingManagement/InventoryType?Mode=Create" 
    RedirectHome={"/"} 
    placeholder={"Search by Inventory name"} 
    SearchonChange={(e) => searchBoxVal(e)} 
    onClick1={refreshGrid} 
    RedirectAction4={() => refreshGrid()} 
    IsNestedHeader />
     <div className="max-w-full w-full justify-center">
    <NVLGridTable user={props.user}
            refershPage={isRefreshing}
            id="tblInventoryList" Search={search}
            HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsInventoryInfo}
            querryName={"listXlmsInventoryInfo"}
            variable={variable}/>
            </div>
        <NVLModalPopup ButtonYestext="Yes" loader={popupValues.loader} SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No"  CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
    </Container>
    </>
)
}
export default InventoryTypeList;