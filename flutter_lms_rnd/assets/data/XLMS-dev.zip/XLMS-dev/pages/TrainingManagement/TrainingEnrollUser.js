import EnrollUser from "@Pages/ActivityManagement/EnrollUser";
import { useRouter } from "next/router";

function TrainingEnrollUser(props) {
    const router = useRouter()
  return (
    <div>
      <EnrollUser props={props} user={props?.user} TenantInfo={props?.TenantInfo} TrainingID={router.query["TrainingID"]} />
    </div>
  )
}

export default TrainingEnrollUser