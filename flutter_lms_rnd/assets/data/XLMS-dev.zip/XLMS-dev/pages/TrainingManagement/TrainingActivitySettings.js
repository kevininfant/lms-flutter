import Container from "@components/Container/Container";
import { getXlmsTrainingManagement, getXlmsTrainingManagementActivityInfo } from "@graphql/graphql/queries";
import EditActivitySettings from "@Pages/ActivityManagement/EditActivitySettings";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

export default function TrainingActivitySettings(props) {
    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState();
    useEffect(() => {
        async function fetchEditSettingsData() {
            let mode = decodeURIComponent(String(router.query["Mode"]));
            let activityId = decodeURIComponent(String(router.query["ActivityID"]));
            let activityType = decodeURIComponent(String(router.query["ActivityType"]));
            let assessmentType = decodeURIComponent(String(router.query["AssessmentType"]));
            let trainingName = decodeURIComponent(String(router.query["TrainingName"]));
            let trainingId = decodeURIComponent(String(router.query["TrainingID"]));
            let root = decodeURIComponent(String(router.query["Root"]));
            let TenantID = props?.user.attributes["custom:tenantid"];
            const getEditdata = await AppsyncDBconnection(getXlmsTrainingManagementActivityInfo, {
                PK: "TENANT#" + TenantID,
                SK: "TRAINING#" + trainingId + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId,
            }, props.user.signInUserSession.accessToken.jwtToken);
            const trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
                PK: "TENANT#" + TenantID,
                SK: "TRAININGINFO#" + trainingId 
            }, props.user.signInUserSession.accessToken.jwtToken);
            setCsrFetchedData({
                Root:root,
                ActivityID: activityId,
                ActivityType: (activityType == "Feedback" || activityType == "Survey") ? "Feedback" : activityType,
                mode: mode,
                TrainingName: trainingName,
                AssessmentType: assessmentType, 
                EditData: getEditdata.res?.getXlmsTrainingManagementActivityInfo,
                user: props.user,
                TenantInfo: props?.TenantInfo,
                TrainingID: trainingId,
                TrainingName: getEditdata.res?.getXlmsTrainingManagementActivityInfo?.TrainingName,
                TrainingData :trainingData.res?.getXlmsTrainingManagement,
            })
        }
        fetchEditSettingsData()
    }, [props, router.query])
    return (
        <Container loader={csrFetchedData == undefined}>
            <EditActivitySettings {...csrFetchedData} />
        </Container>


    )
}
