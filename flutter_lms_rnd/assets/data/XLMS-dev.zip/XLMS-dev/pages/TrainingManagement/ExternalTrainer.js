import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLTextbox from "@components/Controls/NVLTextBox";
import Container from "@Container/Container";
import { createXlmsBatchExternalTrainerInfo, createXlmsEmailAndMobileNumber, deleteXlmsEmailAndMobileNumber } from "@graphql/graphql/mutations";
import { getXlmsEmailIdExistsOrNot, getXlmsExternalTrainerInfo, getXlmsMobileNoExistsOrNot } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";

export default function ExternalTrainer(props) {
  const router = useRouter()
  const [setExtTrainerData, getExtTrainerData] = useState([])
  const initialModalState = {
    ModalType: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      router.push("/TrainingManagement/ExternalTrainerList")
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);

  useEffect(() => {
    async function extTrainerInfo() {
      const externalTrainerResponse = await AppsyncDBconnection(getXlmsExternalTrainerInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "EXTERNALTRAINERINFO#" + router.query["ExtTrainerID"] }, props.user?.signInUserSession?.accessToken?.jwtToken)
      getExtTrainerData({
        ExternalTrainerData: externalTrainerResponse?.res?.getXlmsExternalTrainerInfo,
        Mode: router.query["Mode"]
      })
    } extTrainerInfo()
  }, [props.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue])

  useEffect(() => {
    if (setExtTrainerData.Mode == "Edit") {
      setValue("txtTrainerName", setExtTrainerData?.ExternalTrainerData?.ExternalTrainerName)
      setValue("txtMail", setExtTrainerData?.ExternalTrainerData?.ExternalTrainerMailID)
      setValue("txtTrainerNumber", setExtTrainerData?.ExternalTrainerData?.ExternalTrainerPhoneNo)
      setValue("txtConsultancyName", setExtTrainerData?.ExternalTrainerData?.ConsultancyName)
      setValue("txtConsultancyNumber", setExtTrainerData?.ExternalTrainerData?.ConsultancyNumber)
    }
  }, [router.query, setExtTrainerData?.ExternalTrainerData?.ConsultancyName, setExtTrainerData?.ExternalTrainerData?.ConsultancyNumber, setExtTrainerData?.ExternalTrainerData?.ExternalTrainerPhoneNo, setExtTrainerData?.ExternalTrainerData?.ExternalTrainerMailID, setExtTrainerData?.ExternalTrainerData?.ExternalTrainerName, setValue, setExtTrainerData.Mode])

  const validationSchema = Yup.object().shape({
    txtTrainerName: Yup.string().required("External trainer name is required").min(3, "Required minimum of 3 character")
      .matches(Regex("AlphabetsAndSpaceWithDot"), "External trainer name is invalid").max(200, "Maximum limit exceeds").nullable(),
    txtMail: Yup.string().required("EmailId is required").min(3, "Required minimum of 3 character")
      .matches(Regex("Email"), "Invaild Email").max(128, "Maximum limit exceeds").test("", "Email already exists", async (e) => {
        const isEmailExists = await AppsyncDBconnection(getXlmsEmailIdExistsOrNot, { PK: "XLMS#EMAIL", SK: "EMAILID#" + e.toLowerCase() }, props.user.signInUserSession.accessToken.jwtToken);
        if (setExtTrainerData?.ExternalTrainerData?.ExternalTrainerMailID != e) {
          if (isEmailExists.res.getXlmsEmailIdExistsOrNot != null) {
            return false;
          }
          else {
            return true;
          }
        }
        else {
          return true;
        }
      }).nullable(),
    txtTrainerNumber: Yup.string().required("Contact number is required").min(10, "Invalid contact number")
      .matches(Regex("PhoneNumber"), "Invalid contact number").max(10, "Invalid contact number").test("", "Contact number already exists", async (e) => {
        const ismobilnoexistsornot = await AppsyncDBconnection(getXlmsMobileNoExistsOrNot, { PK: "XLMS#MOBILENO", SK: "MOBILENO#" + e }, props.user.signInUserSession.accessToken.jwtToken);
        if (setExtTrainerData?.ExternalTrainerData?.ExternalTrainerPhoneNo != e) {
          if (ismobilnoexistsornot?.res?.getXlmsMobileNoExistsOrNot != null) {
            return false
          }
          else {
            return true
          }
        }
        else {
          return true
        }
      }).nullable(),
    txtConsultancyName: Yup.string().transform((o, c) => (o === "" ? null : c)).max(250, "Maximum limit exceeds").min(3, "Required minimum of 3 character")
      .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Consultancy name is invalid").nullable(),
    txtConsultancyNumber: Yup.string().transform((o, c) => (o === "" ? null : c)).max(10, "Invalid contact number").min(10, "Invalid contact number")
      .matches(Regex("PhoneNumber"), "Invalid contact number").nullable(),
  })

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, watch, formState, clearErrors } = useForm(formOptions);
  const { errors } = formState;

  const finalResponse = useCallback((finalStatus) => {
    document?.activeElement?.blur()
    setValue("submit", true)
    if (finalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: finalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", true);
      setModalValues({
        ModalInfo: "Success",
        ModalOnClickEvent: () => {
          router.push("/TrainingManagement/ExternalTrainerList")
        },
      });
      ModalOpen();
    }
  }, [router, setValue]);

  const submitHandler = async (data) => {
    setValue("submit", true)
    const pK = "TENANT#" + props.TenantInfo.TenantID
    const date = new Date().toISOString().substring(0, 19);
    const externalTrainerID = router.query["Mode"] != "Edit" ? crypto.randomUUID().toString(25).substring(2, 12) : ""
    const variables = (router.query["Mode"] == "Create") ? {
      input: [
        { PK: pK, SK: "EXTERNALTRAINERINFO#" + externalTrainerID, TenantID: props?.TenantInfo?.TenantID, ExternalTrainerID: externalTrainerID, ExternalTrainerName: data.txtTrainerName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ExternalTrainerMailID: data.txtMail, ExternalTrainerPhoneNo: data.txtTrainerNumber, ConsultancyName: data?.txtConsultancyName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ConsultancyNumber: data?.txtConsultancyNumber, IsSuspend: false, IsDeleted: false, CreatedBy: props.user?.username, CreatedDate: date, LastModifiedBy: props.user?.username, LastModifiedDate: date },
        { PK: pK, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#" + date + "#EXTERNALTRAINERID#" + externalTrainerID, TenantID: props?.TenantInfo?.TenantID, ExternalTrainerID: externalTrainerID, ExternalTrainerName: data.txtTrainerName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ExternalTrainerMailID: data.txtMail, ExternalTrainerPhoneNo: data.txtTrainerNumber, ConsultancyName: data?.txtConsultancyName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ConsultancyNumber: data?.txtConsultancyNumber, IsSuspend: false, IsDeleted: false, CreatedBy: props.user?.username, CreatedDate: date, LastModifiedBy: props.user?.username, LastModifiedDate: date }
      ]
    } : {
      input: [
        { ...setExtTrainerData?.ExternalTrainerData, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#" + setExtTrainerData?.ExternalTrainerData?.LastModifiedDate + "#EXTERNALTRAINERID#" + setExtTrainerData?.ExternalTrainerData?.ExternalTrainerID, IsDeleted: true },
        { ...setExtTrainerData?.ExternalTrainerData, ExternalTrainerName: data.txtTrainerName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ExternalTrainerMailID: data.txtMail, ExternalTrainerPhoneNo: data.txtTrainerNumber, ConsultancyName: data?.txtConsultancyName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ConsultancyNumber: data?.txtConsultancyNumber, IsSuspend: false, IsDeleted: false, LastModifiedBy: props.user?.username, LastModifiedDate: date },
        { ...setExtTrainerData?.ExternalTrainerData, SK: "EXTERNALTRAINERINFO#LASTMODIFIEDDATE#" + date + "#EXTERNALTRAINERID#" + setExtTrainerData?.ExternalTrainerData?.ExternalTrainerID, ExternalTrainerName: data.txtTrainerName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ExternalTrainerMailID: data.txtMail, ExternalTrainerPhoneNo: data.txtTrainerNumber, ConsultancyName: data?.txtConsultancyName?.replace(/\s{2,}(?!\s)/g, ' ').trim(), ConsultancyNumber: data?.txtConsultancyNumber, IsSuspend: false, IsDeleted: false, LastModifiedBy: props.user?.username, LastModifiedDate: date }
      ]
    }
    const finalResult = (await AppsyncDBconnection(createXlmsBatchExternalTrainerInfo, variables, props?.user?.signInUserSession?.accessToken?.jwtToken))
    if (finalResult.Status == "Success") {
      if (router.query["Mode"] == "Create" || data.txtMail != setExtTrainerData?.ExternalTrainerData?.ExternalTrainerMailID) {
        finalResult = await AppsyncDBconnection(createXlmsEmailAndMobileNumber, { input: { PK: "XLMS#EMAIL", SK: "EMAILID#" + data.txtMail.toLowerCase() } }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        if (router.query["Mode"] == "Edit" && data.txtMail != setExtTrainerData?.ExternalTrainerData?.ExternalTrainerMailID) {
          finalResult = await AppsyncDBconnection(deleteXlmsEmailAndMobileNumber, { input: { PK: "XLMS#EMAIL", SK: "EMAILID#" + setExtTrainerData?.ExternalTrainerData?.ExternalTrainerMailID } }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        }
      }
      if (router.query["Mode"] == "Create" || data.txtTrainerNumber != setExtTrainerData?.ExternalTrainerData?.ExternalTrainerPhoneNo) {
        finalResult = (await AppsyncDBconnection(createXlmsEmailAndMobileNumber, { input: { PK: "XLMS#MOBILENO", SK: "MOBILENO#" + data.txtTrainerNumber } }, props?.user?.signInUserSession?.accessToken?.jwtToken))
        if (router.query["Mode"] == "Edit" && data.txtTrainerNumber != setExtTrainerData?.ExternalTrainerData?.ExternalTrainerPhoneNo) {
          finalResult = await AppsyncDBconnection(deleteXlmsEmailAndMobileNumber, { input: { PK: "XLMS#MOBILENO", SK: "MOBILENO#" + setExtTrainerData?.ExternalTrainerData?.ExternalTrainerPhoneNo } }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        }
      }
    }
    finalResponse(finalResult.Status)
    if (finalResult.Status != "Success") {
      setValue("submit", false)
    }
  }

  const pageRoutes = useMemo(() => {
    return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training Management" },
    { path: "/TrainingManagement/TrainingLocationList", breadcrumb: "Training Location List" },
    { path: "/TrainingManagement/ExternalTrainerList", breadcrumb: "External Trainer List" },
    { path: "", breadcrumb: router.query["Mode"] != "Edit" ? "Add External Trainer" : "Edit External Trainer" },
    ]
  }, [router.query])
  const restAction = useCallback(() => {
    document?.activeElement?.blur()
  }, [])

  const clearField = useCallback(() => {
    const clearData = ["txtTrainerName", "txtMail", "txtTrainerNumber", "txtConsultancyName", "txtConsultancyNumber"];
    clearData.map((id) => {
      setValue(id, "")
    })
    clearErrors()
  }, [clearErrors, setValue])
  return (
    <>
      <Container title={router.query["Mode"] != "Edit" ? "Add External Trainer" : "Edit External Trainer"} PageRoutes={pageRoutes} loader={setExtTrainerData.Mode == undefined}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(submitHandler)} id="divTrainer" className={`${watch("submit") ? "pointer-events-none" : ""}`}>
          <div className="nvl-FormContent">
            <NVLTextbox id="txtTrainerName" labelText="External trainer name" labelClassName="nvl-Def-Label pb-1" title="Trainer name" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
            <NVLTextbox id="txtMail" labelText="External trainer mail id" labelClassName="nvl-Def-Label pb-1" title="Trainer mail id" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
            <NVLTextbox id="txtTrainerNumber" labelText="External trainer contact number" labelClassName="nvl-Def-Label pb-1" title="Trainer contact number" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
            <NVLTextbox id="txtConsultancyName" labelText="Consultancy name" labelClassName="nvl-Def-Label pb-1" title="Consultancy name" className={"nvl-Def-Input"} errors={errors} register={register} />
            <NVLTextbox id="txtConsultancyNumber" labelText="Consultancy contact number" labelClassName="nvl-Def-Label pb-1" title="Consultancy contact number" className={"nvl-Def-Input"} errors={errors} register={register} />
            <div className="flex justify-center gap-2 pt-4">
              <NVLButton id="btnSubmit" onClick={restAction} text={!watch("submit") ? "Save" : ""} disabled={watch("submit") ? true : false} type="submit" className={`${watch("submit") ? "w-32 nvl-button bg-primary text-white pointer-events-none" : "w-32 nvl-button bg-primary text-white"}`}>
                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
              </NVLButton>
              <NVLButton id="btnCancel" text={router.query["Mode"] != "Edit" ? "Clear" : "Cancel"} type="button" className="nvl-button w-28" onClick={() => router.query["Mode"] != "Edit" ? clearField() : router.push("/TrainingManagement/ExternalTrainerList")}></NVLButton>
            </div>
          </div>
        </form>
      </Container>
    </>

  )
}
