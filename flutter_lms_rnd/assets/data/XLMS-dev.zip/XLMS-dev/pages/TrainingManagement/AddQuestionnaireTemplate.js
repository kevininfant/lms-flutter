import Container from "@components/Container/Container";
import FeedbackActivityOverview from "@Pages/ActivityManagement/FeedbackActivityOverView";

export default function AddQuestionnaireTemplate(props) {

  return (
    <Container loader={props==undefined}>
    <FeedbackActivityOverview {...props} />
    </Container>
  )
}
