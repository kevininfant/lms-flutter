import AddQuestion from '@Pages/ActivityManagement/CommonActivitySettings/AddQuestion';
import QuestionBank from '@Pages/ActivityManagement/CommonActivitySettings/QuestionBank';
import QuestionList from '@Pages/ActivityManagement/CommonActivitySettings/QuestionList';
import RandomQuestions from '@Pages/ActivityManagement/CommonActivitySettings/RandomQuestions';
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from 'next/router';
import { useEffect, useState } from 'react';
import { getXlmsCourseActivityConfig, getXlmsTrainingManagement, getXlmsTrainingManagementActivityInfo } from "src/graphql/queries";

export default function TrainingCreateActivity(props) {
    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    useEffect(() => {
        async function fetchData() {
            let mode = decodeURIComponent(String(router.query["Mode"]));
            let trainingId = decodeURIComponent(String(router.query["TrainingID"]));
            let activityID = decodeURIComponent(String(router.query["ActivityID"]));
            let activityType = decodeURIComponent(String(router.query["ActivityType"]));
            let trainingName = decodeURIComponent(String(router.query["TrainingName"]));
            let assessmentType = decodeURIComponent(String(router.query["AssessmentType"]));
            let settings = decodeURIComponent(String(router.query["Settings"]));
            let tenantID = props?.user.attributes["custom:tenantid"];
            const activityData = await AppsyncDBconnection(getXlmsCourseActivityConfig, {
                PK: "XLMS#ACTIVITY",
                SK: "ACTIVITY#ACTIVITYTYPE",
            }, props.user.signInUserSession.accessToken.jwtToken);
            const getEditdata = await AppsyncDBconnection(getXlmsTrainingManagementActivityInfo, {
                PK: "TENANT#" + tenantID,
                SK: "TRAINING#" + trainingId + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityID
            }, props.user.signInUserSession.accessToken.jwtToken);
            const editTrainingdata = await AppsyncDBconnection(getXlmsTrainingManagement, {
                PK: "TENANT#" + tenantID,
                SK: "TRAININGINFO#" + trainingId
            }, props.user.signInUserSession.accessToken.jwtToken);
            const temp = {
                TrainingData: editTrainingdata?.res?.getXlmsTrainingManagement,
                EditData: getEditdata?.res?.getXlmsTrainingManagementActivityInfo,
                TenantID: tenantID,
                TrainingId: trainingId,
                ActivityID: activityID,
                TrainingName: trainingName,
                AssessmentType: assessmentType,
                Settings: settings,
                mode: mode,
                ActivityType: activityType,
                user: props.user,
                TenantInfo: props?.TenantInfo,
                ActivityData: activityData.res?.getXlmsCourseActivityConfig
            }
            setCsrFetchedData(temp);
        }
        fetchData();
    }, [props?.TenantInfo, props.user, props.user.signInUserSession.accessToken.jwtToken, router.query])
    return (
        <div>
            {(csrFetchedData?.Settings == "QuizList") && <QuestionList {...csrFetchedData} />}
            {(csrFetchedData?.Settings == "AddQuestion") && <AddQuestion {...csrFetchedData} />}
            {(csrFetchedData?.Settings == "QuestionBank") && <QuestionBank {...csrFetchedData} />}
            {(csrFetchedData?.Settings == "RandomQuestion") && <RandomQuestions {...csrFetchedData} />}
        </div>
    )
}