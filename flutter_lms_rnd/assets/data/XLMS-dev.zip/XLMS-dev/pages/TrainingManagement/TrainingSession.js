import Container from "@components/Container/Container";
import NVLAlert, { ModalClose, ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { getXlmsTrainingManagement, listXlmsTrainingSessionInfos } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
import { GetDateFormat } from "../../components/Common/DateFormat";
import { createXlmsBatchTrainingManagement, createXlmsBatchTrainingSessionInfo } from "../../src/graphql/mutations";

function TrainingSession(props) {
  const router = useRouter()
  const trainingID = useMemo(() => { return router.query["TrainingID"] }, [router.query])
  const [sessionDetails, setsessionDetails] = useState({})
  const [rowData, setRowData] = useState({ Edit: false, Add: false })
  const [getIndex, setIndex] = useState()
  const [popupValues, setPopupValues] = useState({ Content: "", UpdateData: {}, isload: false })
  const [startdate, setstartdate] = useState({ StartTime: "", EndTime: "" })
  const [sessionAction, setSessionAction] = useState({ IsShowMore: true, InitialCount: 10 });
  const [open, setOpen] = useState(false);
  const sessionStart = useRef(false)
  const enrollCount = useRef(0)
  const initialModalState = {
    ModalType: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      router.push("/TrainingManagement/TrainingManagementList")
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);

  useEffect(() => {
    async function pageData() {
      const trainingDetails = await AppsyncDBconnection(getXlmsTrainingManagement, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "TRAININGINFO#" + trainingID }, props?.user.signInUserSession.accessToken.jwtToken)
      const trainingData = trainingDetails.res?.getXlmsTrainingManagement
      const sessionList = await AppsyncDBconnection(listXlmsTrainingSessionInfos, { PK: "TENANT#" + props.TenantInfo.TenantID + "#TRAINING#" + trainingID, SK: "SESSION#STARTDATE#", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
      const QuesOption = trainingData && JSON.parse(trainingData?.QuestionandOptions)
      let SampObject = {}
      SampObject = { ...SampObject, ["Session"]: { Type: "Session", Name: trainingData?.TrainingName, StartDate: trainingData?.StartDate, EndDate: trainingData?.EndDate } }
      // QuesOption && Object.values(QuesOption).map((data) => {
      //   SampObject = { ...SampObject, [data?.ActivityType == "Quiz" ? data?.AssessmentType : data?.ActivityType]: { Type: data?.ActivityType == "Quiz" ? data?.AssessmentType : data?.ActivityType, Name: data?.TemplateName, StartDate: "", EndDate: "" } }
      // })
      sessionStart.current = new Date(trainingData?.StartDate) < new Date() ? true : false
      enrollCount.current = trainingData?.EnrollCount
       setsessionDetails({
        trainingData: SampObject ? SampObject : {},
        sessionData: sessionList.res?.listXlmsTrainingSessionInfos?.items,
        currentTraining: trainingData ? trainingData : {}
      })
    }
    pageData()
    return (
      setsessionDetails((data) => { return data })
    )
  }, [props.TenantInfo.TenantID, props?.user.signInUserSession.accessToken.jwtToken, trainingID])

  const finalResponse = useCallback((finalStatus) => {
    if (finalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: finalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", true);
      setModalValues({
        ModalInfo: "Success",
        ModalOnClickEvent: () => {
          ModalClose()
        },
      });
      ModalOpen();
    }
  }, [setValue]);

  const clearingError = (field, index) => {
    if (field == "end") {
      clearErrors(["txtEndTime" + index])
    } else if (field == "start") {
      clearErrors(["txtstTime" + index])
    } else if (field == "Sessionend") {
      clearErrors(["newEndDate"])
    } else {
      clearErrors(["newStartDate"])
    }
  }

  let dynamicYupfields = {}
  for (let i = 0; i < sessionDetails?.sessionData?.length; i++) {
    function timeFormat(passedDate) {
      return (passedDate.getHours() > "9" ? passedDate.getHours() : "0" + passedDate.getHours()) + ":" + (passedDate.getMinutes() > "9" ? passedDate.getMinutes() : "0" + passedDate.getMinutes())
    }

    dynamicYupfields = {
      ...dynamicYupfields,
      ["newStartDate"]: Yup.string().test("", "", (e, { createError }) => {
        let DateExist = sessionDetails?.sessionData.some((data) => { return new Date(data.StartDate).toDateString() == new Date(watch("newStartDate")).toDateString() })
        if (DateExist) {
          return createError({ message: "Session already exists in the given date" })
        }
        if (new Date(watch("newStartDate")) > new Date(sessionDetails?.currentTraining?.EndDate) || new Date(watch("newStartDate")) < new Date(sessionDetails?.currentTraining?.StartDate)) {
          return createError({ message: "Session should be created within the program start and end date" })
        }

        // if(new Date(watch("newStartDate")).toDateString() != new Date(watch("newEndDate")).toDateString() ){
        //   return createError({message:"Start and end date should be same"})
        // }
        const time1 = watch("newEndDate") != undefined ? timeFormat(new Date(watch("newEndDate"))) : "00:00";
        const time2 = watch("newStartDate") != undefined ? timeFormat(new Date(watch("newStartDate"))) : "00:00";

        const [hours1, minutes1] = time1.split(":").map(Number);
        const [hours2, minutes2] = time2?.split(":").map(Number);
        const totalMinutes1 = hours1 * 60 + minutes1;
        const totalMinutes2 = hours2 * 60 + minutes2;
        const timeDifferenceMinutes = totalMinutes1 - totalMinutes2;

        const hoursDifference = Math.floor(timeDifferenceMinutes / 60);
        const minutesDifference = timeDifferenceMinutes % 60;

        if (hoursDifference < 1) {
          return createError({ message: "Session can be created for minimum 1 hour." })
        }  else {
          if(errors?.["newEndDate"]?.message != undefined && errors?.["newEndDate"]?.message == "Session can be created for minimum 1 hour."){
            clearingError("Sessionend",i) 
         }
        }
         if (hoursDifference > 8) {
          return createError({ message: "Session can be created for maximum 8 hour." })
        } else {
          if(errors?.["newEndDate"]?.message != undefined && errors?.["newEndDate"]?.message == "Session can be created for maximum 8 hour."){
            clearingError("Sessionend",i) 
         }
        }
        if (new Date(watch("newStartDate")).toDateString() != new Date(watch("newEndDate")).toDateString()) {
          return createError({ message: "Start and end date should be same" })
        } else {
          if(errors?.["newEndDate"]?.message != undefined && errors?.["newEndDate"]?.message == "Start and end date should be same"){
            clearingError("Sessionend",i) 
         }
        }
        if (e == "Empty") {
          return createError({ message: "Start date is required" });
        }
        return true
      }).nullable(),
      ["newEndDate"]: Yup.string().test("", "", (e, { createError }) => {
        let DateExist = sessionDetails?.sessionData.some((data) => { return new Date(data.StartDate).toDateString() == new Date(watch("newStartDate")).toDateString() })
        if (DateExist) {
          return createError({ message: "Session already exists in the given date" })
        }
        if (new Date(watch("newStartDate")) > new Date(sessionDetails?.currentTraining?.EndDate) || new Date(watch("newStartDate")) < new Date(sessionDetails?.currentTraining?.StartDate)) {
          return createError({ message: "Session should be created within the program start and end date" })
        }

        if (new Date(watch("newStartDate")).toDateString() != new Date(watch("newEndDate")).toDateString()) {
          return createError({ message: "Start and end date should be same" })
        } else {
          if(errors?.["newStartDate"]?.message != undefined && errors?.["newStartDate"]?.message == "Start and end date should be same"){
            clearingError("Sessionstart",i) 
         }
        }
        const time1 = watch("newEndDate") != undefined ? timeFormat(new Date(watch("newEndDate"))) : "00:00";
        const time2 = watch("newStartDate") != undefined ? timeFormat(new Date(watch("newStartDate"))) : "00:00";

        const [hours1, minutes1] = time1.split(":").map(Number);
        const [hours2, minutes2] = time2?.split(":").map(Number);
        const totalMinutes1 = hours1 * 60 + minutes1;
        const totalMinutes2 = hours2 * 60 + minutes2;
        const timeDifferenceMinutes = totalMinutes1 - totalMinutes2;

        const hoursDifference = Math.floor(timeDifferenceMinutes / 60);
        const minutesDifference = timeDifferenceMinutes % 60;
        if (hoursDifference < 1) {
          return createError({ message: "Session can be created for minimum 1 hour." })
        } else {
           if(errors?.["newStartDate"]?.message != undefined && errors?.["newStartDate"]?.message == "Session can be created for minimum 1 hour."){
              clearingError("Sessionstart",i) 
           }
        }
        
         if (hoursDifference > 8) {
          return createError({ message: "Session can be created for maximum 8 hour." })
        }  else {
          if(errors?.["newStartDate"]?.message != undefined && errors?.["newStartDate"]?.message == "Session can be created for maximum 8 hour."){
            clearingError("Sessionstart",i) 
         }
        }
        if (e == "Empty") {
          return createError({ message: "End date is required" });
        }
        return true

      }).nullable(),
      ["txtstTime" + i]: Yup.string().test("", "", (e, { createError }) => {
        // if (errors?.["txtstTime"+i]?.message != undefined && errors?.["txtEndTime"+i]?.message != undefined && (errors?.["txtEndTime"+i]?.message == errors?.["txtstTime"+i]?.message)){
        //   clearingError("end",i)
        //  }
        if (new Date(watch("txtstdate" + i)).toDateString() == new Date(sessionDetails?.currentTraining?.StartDate).toDateString() && e < (timeFormat(startdate.StartTime)) && rowData.Edit) {
          return createError({ message: "Start time should not be less than program start time" })
        }
        if (watch("txtEndTime" + i) != "" && (watch("txtstTime" + i) > watch("txtEndTime" + i))) {
          return createError({ message: "Start time should be lesser than the end time" })
        } else {
           if(errors?.["txtEndTime"+i]?.message != undefined && errors?.["txtEndTime"+i]?.message == "End time should be greater than the start time"){
              clearingError("end",i) 
           }
        }

        if (watch("txtstTime" + i) != "" && watch("txtEndTime" + i) == "") {
          setError("txtEndTime" + i, { message: "End time is required" });
        }
        const time1 = watch("txtEndTime" + i) != undefined ? watch("txtEndTime" + i) : "00:00";
        const time2 = watch("txtstTime" + i) != undefined ? watch("txtstTime" + i) : "00:00";

        const [hours1, minutes1] = time1.split(":").map(Number);
        const [hours2, minutes2] = time2?.split(":").map(Number);
        const totalMinutes1 = hours1 * 60 + minutes1;
        const totalMinutes2 = hours2 * 60 + minutes2;
        const timeDifferenceMinutes = totalMinutes1 - totalMinutes2;

        const hoursDifference = Math.floor(timeDifferenceMinutes / 60);
        const minutesDifference = timeDifferenceMinutes % 60;

        if (hoursDifference < 1) {
          return createError({ message: "Session can be created for minimum 1 hour." })
        } else {
           if(errors?.["txtEndTime"+i]?.message != undefined && errors?.["txtEndTime"+i]?.message == "Session can be created for minimum 1 hour."){
              clearingError("end",i) 
           }
        }
        
        if (hoursDifference > 8) {
          return createError({ message: "Session can be created for maximum 8 hour." })
        } else {
           if(errors?.["txtEndTime"+i]?.message != undefined && errors?.["txtEndTime"+i]?.message == "Session can be created for maximum 8 hour."){
              clearingError("end",i) 
           }
        }

        if (rowData.Add && (watch("txtstTime" + i) > timeFormat(startdate.StartTime) && watch("txtstTime" + i) < timeFormat(startdate.EndTime))) {
          return createError({ message: "Session cannot be created  within existing hour" })
        }

        if (rowData.Add && new Date(sessionDetails?.currentTraining?.EndDate).toDateString() == new Date(watch("txtstdate" + i)).toDateString() &&
          ((watch("txtstTime" + i)) < timeFormat(startdate.StartTime) && (watch("txtstTime" + i)) < timeFormat(startdate.EndTime)) || ((watch("txtstTime" + i)) > timeFormat(startdate.StartTime) && (watch("txtstTime" + i)) > timeFormat(startdate.EndTime))) {
          return createError({ message: "Session time does not match program start and end time " })
        } 

        return true
      }),

      ["txtEndTime" + i]: Yup.string().test("", "", (e, { createError }) => {
        const time1 = watch("txtEndTime" + i) != undefined ? watch("txtEndTime" + i) : "00:00";
        const time2 = watch("txtstTime" + i) != undefined ? watch("txtstTime" + i) : "00:00";

        const [hours1, minutes1] = time1.split(":").map(Number);
        const [hours2, minutes2] = time2?.split(":").map(Number);
        const totalMinutes1 = hours1 * 60 + minutes1;
        const totalMinutes2 = hours2 * 60 + minutes2;
        const timeDifferenceMinutes = totalMinutes1 - totalMinutes2;

        const hoursDifference = Math.floor(timeDifferenceMinutes / 60);
        const minutesDifference = timeDifferenceMinutes % 60;

        // if (errors?.["txtstTime" + i]?.message == undefined) { clearingError("start", i) }
        if (hoursDifference < 1) {
          return createError({ message: "Session can be created for minimum 1 hour." })
        } else {
           if(errors?.["txtstTime"+i]?.message != undefined && errors?.["txtstTime"+i]?.message == "Session can be created for minimum 1 hour."){
              clearingError("start",i) 
           }
        }
        
        if (hoursDifference > 8) {
          return createError({ message: "Session can be created for maximum 8 hour." })
        } else {
           if(errors?.["txtstTime"+i]?.message != undefined && errors?.["txtstTime"+i]?.message == "Session can be created for maximum 8 hour."){
              clearingError("start",i) 
           }
        }
        
        if (watch("txtstTime" + i) > watch("txtEndTime" + i)) {
          return createError({ message: "End time should be greater than the start time" })
        } else {
          if(errors?.["txtstTime"+i]?.message != undefined && errors?.["txtstTime"+i]?.message == "Start time should be lesser than the end time"){
              clearingError("start",i) 
           } 
        }

        if (watch("txtEndTime" + i) != "" && watch("txtstTime" + i) == "") {
          setError("txtstTime" + i, { message: "Start time is required" })
        }
        if (rowData.Add && (watch("txtEndTime" + i) > timeFormat(startdate.StartTime) && watch("txtEndTime" + i) < timeFormat(startdate.EndTime))) {
          return createError({ message: "Session cannot be created  within existing hour" })
        }

        if (rowData.Add && new Date(sessionDetails?.currentTraining?.EndDate).toDateString() == new Date(watch("txtEndTime" + i)).toDateString() &&
          ((watch("txtEndTime" + i)) < timeFormat(startdate.StartTime) && (watch("txtEndTime" + i)) < timeFormat(startdate.EndTime)) || ((watch("txtEndTime" + i)) > timeFormat(startdate.StartTime) && (watch("txtEndTime" + i)) > timeFormat(startdate.EndTime))) {
          return createError({ message: "Session time does not match program start and end time " })
        } 
        return true
      }),

    };
  }
  const validationSchema = Yup.object().shape(dynamicYupfields);
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
  const { register, setValue, formState, watch, clearErrors, setError } = useForm(formOptions);
  const { errors } = formState;
  const PageRoutes = useMemo(() => {
    return [{ path: "/TrainingManagement/TrainingManagementList", breadcrumb: "Training List" }, { path: "", breadcrumb: "Session" }]
  }, [])


  const RemoveNull = useCallback((obj) => {
    let tempjson = {};
    obj && Object.keys(obj).forEach((k) => {
      if (obj?.[k] != undefined) {
        tempjson = { ...tempjson, [k]: obj?.[k] }
      }
    });
    return tempjson;
  }, [])
  const editSession = useCallback(async (type, getItem, index) => {
    function timeFormat(passedDate) {
      return (passedDate.getHours() > "9" ? passedDate.getHours() : "0" + passedDate.getHours()) + ":" + (passedDate.getMinutes() > "9" ? passedDate.getMinutes() : "0" + passedDate.getMinutes())
    }
    setValue("txtstdate" + index, GetDateFormat(getItem.StartDate, "yyyy-mm-dd"))
    setstartdate({ StartTime: (new Date(getItem.StartDate)), EndTime: (new Date(getItem.EndDate)) })
    if (type != "submit") {
      setValue("txtstTime" + index, timeFormat(new Date(getItem.StartDate)))
      setValue("txtEndTime" + index, timeFormat(new Date(getItem.EndDate)))
      clearErrors(["txtstTime" + index, "txtEndTime" + index])
    }
    if (type == "submit" && (errors == undefined || Object?.entries(errors).length == 0) && (watch("txtstdate" + index) != "" && watch("txtstTime" + index) != "")) {

      let sessionDate = watch("txtstdate" + index)
      let startDateTime = new Date((new Date(new Date(sessionDate).setHours(watch("txtstTime" + index)?.split(":")[0]))).setMinutes(watch("txtstTime" + index)?.split(":")[1]))
      let endDateTime = new Date((new Date(new Date(sessionDate).setHours(watch("txtEndTime" + index)?.split(":")[0]))).setMinutes(watch("txtEndTime" + index)?.split(":")[1]))

      let temp = RemoveNull(getItem);


      const updateVariable = startDateTime.toISOString() == getItem.StartDate ? {
        input: [

          {
            ...temp,
            StartDate: startDateTime.toISOString(),
            EndDate: endDateTime.toISOString(),
            LastModifiedDate: new Date().toISOString()
          },
          {
            ...temp,
            SK: "SESSION#" + getItem.SessionID,
            StartDate: startDateTime.toISOString(),
            EndDate: endDateTime.toISOString(),
            LastModifiedDate: new Date().toISOString()
          }
        ]
      } :
        {
          input: [
            {
              ...temp,
              IsDeleted: true,
              AutoDelete: Date.now() / 1000 + 24 * 60 | 0
            },
            {
              ...temp,
              SK: "SESSION#STARTDATE#" + startDateTime.toISOString() + "#SESSIONID#" + getItem.SessionID,
              StartDate: startDateTime.toISOString(),
              EndDate: endDateTime.toISOString(),
              LastModifiedDate: new Date().toISOString()
            },
            {
              ...temp,
              SK: "SESSION#" + getItem.SessionID,
              StartDate: startDateTime.toISOString(),
              EndDate: endDateTime.toISOString(),
              LastModifiedDate: new Date().toISOString()
            }
          ]
        }

      if (startDateTime.toISOString() != getItem.StartDate || endDateTime.toISOString() != getItem.EndDate) {
        let finalResult = (await AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, updateVariable, props.user.signInUserSession.accessToken.jwtToken)).Status
        finalResponse(finalResult)
        sessionRefresh()
      }
    }
    if ((errors == undefined || Object?.entries(errors).length == 0)) {
      setRowData((data) => { return { Edit: !data.Edit, Add: data.Add } })
    } else {
      setRowData((data) => { return data })
    }
  }, [RemoveNull, clearErrors, errors, finalResponse, props.user.signInUserSession.accessToken.jwtToken, sessionRefresh, setValue, watch])

  const addSession = useCallback(async (type, getItem, index) => {
    function timeFormat(passedDate) {
      return passedDate.getHours() + ":" + passedDate.getMinutes()
    }

    setValue("txtstdate" + index, GetDateFormat(getItem.StartDate, "yyyy-mm-dd"))
    setstartdate({ StartTime: (new Date(getItem.StartDate)), EndTime: (new Date(getItem.EndDate)) })
    if (type != "submit") {
      setValue("txtstTime" + index, "")
      setValue("txtEndTime" + index, "")
      clearErrors(["txtstTime" + index, "txtEndTime" + index])
    }

    if (type == "submit" && (watch("txtstdate" + index) != "" && watch("txtstTime" + index) != "") && (errors == undefined || Object?.entries(errors).length == 0)) {
      document.activeElement?.blur();
      setValue("submitsession", true)
      let sessionDate = watch("txtstdate" + index)
      let startDateTime = new Date((new Date(new Date(sessionDate).setHours(watch("txtstTime" + index)?.split(":")[0]))).setMinutes(watch("txtstTime" + index)?.split(":")[1]))
      let endDateTime = new Date((new Date(new Date(sessionDate).setHours(watch("txtEndTime" + index)?.split(":")[0]))).setMinutes(watch("txtEndTime" + index)?.split(":")[1]))

      // const forenoonSessionStart = new Date(sessionDate);
      // forenoonSessionStart.setHours(new Date(getItem.StartDate).getHours());
      // forenoonSessionStart.setMinutes(new Date(getItem.StartDate).getMinutes())

      // const forenoonSessionEnd = new Date(startDateTime);
      // forenoonSessionEnd.setHours(0, 0, 0, 0);
      // forenoonSessionEnd.setHours(startDateTime.getHours());
      // forenoonSessionEnd.setMinutes(startDateTime.getMinutes());

      // const ExistingSessionDifference = forenoonSessionEnd.getTime() - forenoonSessionStart.getTime()
      // const timeOfExisting = ExistingSessionDifference / (1000 * 60 * 60)
      // const updateExisting = timeOfExisting >= 1 ?
      //   [{ ...temp, EndDate: forenoonSessionEnd.toISOString() }, { ...temp, SK: "SESSION#" + temp?.SessionID, EndDate: forenoonSessionEnd.toISOString(), }] :
      //   [{ ...temp, IsDeleted: true, AutoDelete: Date.now() / 1000 + 24 * 60 | 0 }, { ...temp, SK: "SESSION#" + temp?.SessionID, IsDeleted: true }]

      const SessionID = crypto.randomUUID().toString(25)

      let temp = RemoveNull(getItem);
      const createVariables = {
        input: [
          {
            ...temp,
            SK: "SESSION#STARTDATE#" + startDateTime?.toISOString() + "#SESSIONID#" + SessionID,
            StartDate: startDateTime.toISOString(),
            SessionID: SessionID,
            CreatedBy: props.user?.username,
            CreatedDate: new Date().toISOString(),
            LastModifiedBy: props.user?.username,
            EndDate: endDateTime.toISOString(),
            LastModifiedDate: new Date().toISOString()
          },
          {
            ...temp,
            SK: "SESSION#" + SessionID,
            StartDate: startDateTime.toISOString(),
            SessionID: SessionID,
            CreatedBy: props.user?.username,
            CreatedDate: new Date().toISOString(),
            LastModifiedBy: props.user?.username,
            EndDate: endDateTime.toISOString(),
            LastModifiedDate: new Date().toISOString()
          }
        ]
      }

      const trainingVariables = {
        input: [{ ...sessionDetails?.currentTraining, SessionCount: (sessionDetails?.currentTraining.SessionCount) + 1 },
        { ...sessionDetails?.currentTraining, SK: "TRAININGINFO#LASTMODIFIEDDATE#" + sessionDetails?.currentTraining?.LastModifiedDate + "#TRAININGID#" + sessionDetails?.currentTraining?.TrainingID, SessionCount: (sessionDetails?.currentTraining.SessionCount) + 1 }
        ]
      }
      let finalResult = (await AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, createVariables, props.user.signInUserSession.accessToken.jwtToken)).Status
      await AppsyncDBconnection(createXlmsBatchTrainingManagement, trainingVariables, props.user.signInUserSession.accessToken.jwtToken)
      finalResponse(finalResult)
      sessionRefresh()
      setValue("submitsession", false)
    }
    if ((errors == undefined || Object?.entries(errors).length == 0)) {
      setRowData((data) => { return { Edit: data.Edit, Add: !data.Add } })
    } else {
      setRowData((data) => { return data })
    }
  }, [RemoveNull, clearErrors, errors, finalResponse, props.user.signInUserSession.accessToken.jwtToken, props.user?.username, sessionDetails?.currentTraining, sessionRefresh, setValue, watch])

  const sessionRefresh = useCallback(async () => {
    const sessionList = await AppsyncDBconnection(listXlmsTrainingSessionInfos, { PK: "TENANT#" + props.TenantInfo.TenantID + "#TRAINING#" + trainingID, SK: "SESSION#STARTDATE#", IsDeleted: false }, props?.user.signInUserSession.accessToken.jwtToken)
    setsessionDetails((data) => { return { ...data, sessionData: sessionList.res?.listXlmsTrainingSessionInfos?.items } })
  }, [props.TenantInfo.TenantID, props?.user.signInUserSession.accessToken.jwtToken, trainingID])


  const deleteSession = useCallback(async (e) => {
    e.preventDefault()
    setPopupValues((temp) => { return { ...temp, isload: true } });
    let session = RemoveNull(popupValues.UpdateData);
    // let samedaysessions = sessionDetails?.sessionData?.filter((data) => { return new Date(data.StartDate).toDateString() == (new Date(popupValues.UpdateData.StartDate).toDateString()) && data.SessionID != popupValues.UpdateData.SessionID })
    const newArray = []
    // const SessionID = crypto.randomUUID().toString(25)
    // samedaysessions && samedaysessions.map((getItem) => {
    //   if (new Date(popupValues.UpdateData.StartDate).getHours() == new Date(getItem.EndDate).getHours()) {
    //     let session = RemoveNull(getItem);
    //     newArray = [...newArray, { ...session, EndDate: new Date(popupValues.UpdateData.EndDate).toISOString() },
    //     { ...session, SK: "SESSION#" + session.SessionID, EndDate: new Date(popupValues.UpdateData.EndDate).toISOString() }]
    //   }
    //   if (new Date(popupValues.UpdateData.EndDate).getHours() == new Date(getItem.StartDate).getHours()) {
    //     let session = RemoveNull(getItem);
    //     newArray = [...newArray, { ...session, IsDeleted: true, AutoDelete: Date.now() / 1000 + 24 * 60 | 0 },
    //     { ...session, SK: "SESSION#" + session.SessionID, IsDeleted: true },
    //     { ...session, SK: "SESSION#STARTDATE#" + new Date(popupValues.UpdateData.StartDate).toISOString() + "#SESSIONID#" + SessionID, StartDate: new Date(popupValues.UpdateData.StartDate).toISOString() },
    //     { ...session, SK: "SESSION#" + SessionID, StartDate: new Date(popupValues.UpdateData.StartDate).toISOString() }]
    //   }
    // })
    const deleteVariables = {
      input: [
        {
          ...session,
          IsDeleted: true,
          LastModifiedDate: new Date().toISOString(),
        },
        {
          ...session,
          IsDeleted: true,
          SK: "SESSION#" + popupValues.UpdateData.SessionID,
          LastModifiedDate: new Date().toISOString()
        }
      ]
    }
    const trainingVariables = {
      input: [{ ...sessionDetails?.currentTraining, SessionCount: (sessionDetails?.currentTraining.SessionCount) - 1 },
      { ...sessionDetails?.currentTraining, SK: "TRAININGINFO#LASTMODIFIEDDATE#" + sessionDetails?.currentTraining?.LastModifiedDate + "#TRAININGID#" + sessionDetails?.currentTraining?.TrainingID, SessionCount: (sessionDetails?.currentTraining.SessionCount) - 1 }
      ]
    }

    let finalResult = (await AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, deleteVariables, props.user.signInUserSession.accessToken.jwtToken)).Status
    await AppsyncDBconnection(createXlmsBatchTrainingManagement, trainingVariables, props.user.signInUserSession.accessToken.jwtToken)
    finalResponse(finalResult)
    resetPopUp()
    sessionRefresh();
  }, [RemoveNull, finalResponse, popupValues.UpdateData, props.user.signInUserSession.accessToken.jwtToken, resetPopUp, sessionDetails?.currentTraining, sessionRefresh])

  const deletePopup = useCallback((getItem, existingData) => {
    setPopupValues({ Content: existingData <= 1 ? "Session cannot be deleted." : "Are you sure to delete the session?", UpdateData: getItem })
  }, [])

  const resetPopUp = useCallback(() => {
    setPopupValues({ Content: "", UpdateData: {}, isload: false })
  }, [])

  const cancelClick = (e) => {
    e.preventDefault()
    resetPopUp()
  }
  const convertDate = useCallback((date) => {
    const timeOfHour = new Date(date).getHours() >= 12 ? "pm" : "am";
    const hour = new Date(date).getHours() % 12 >= 10 ? new Date(date).getHours() % 12 : "0" + new Date(date).getHours() % 12;
    const minute = new Date(date).getMinutes() >= 10 ? new Date(date).getMinutes() : "0" + new Date(date).getMinutes();
    return `${GetDateFormat(date, "dd-mm-yyyy")} : ${hour == "00" ? "12" : hour} : ${minute} ${timeOfHour}`
  }, [])

  const SessionExistCheck = useCallback((startDate, index) => {
    let samedaysessions = sessionDetails?.sessionData?.filter((data) => { return new Date(data.StartDate).toDateString() == (new Date(startDate).toDateString()) })
    let Alter = samedaysessions.length >= 2 ? false : true
    return Alter;
  }, [sessionDetails?.sessionData])

  const showMoreOrLess = useCallback(() => {
    if (sessionDetails?.sessionData?.length > sessionAction.InitialCount) {
      setSessionAction((prev) => { return { ...prev, IsShowMore: true, InitialCount: prev.InitialCount + 10 } });
    }
    else {
      setSessionAction((prev) => { return { ...prev, IsShowMore: false, InitialCount: 10 } });
    }

  }, [sessionAction.InitialCount, sessionDetails?.sessionData?.length])
  const submithandler = useCallback(async (data) => {
    if (watch("newStartDate") == "") {
      setValue("newStartDate", "Empty", { shouldValidate: true })
    }
    if (watch("newEndDate") == "") {
      setValue("newEndDate", "Empty", { shouldValidate: true })
    }

    if (data == "Save" && watch("newStartDate") != "Empty" && watch("newEndDate") != "Empty" && (errors == undefined || Object?.entries(errors).length == 0)) {
      document.activeElement?.blur();
      setValue("sessionSubmit", true)
      const date = new Date().toISOString();
      const SessionID = crypto.randomUUID().toString(25)
      let variable = {
        PK: "TENANT#" + props.TenantInfo.TenantID + "#TRAINING#" + sessionDetails?.currentTraining?.TrainingID,
        SK: "SESSION#" + SessionID,
        TrainingID: sessionDetails?.currentTraining.TrainingID,
        TrainingName: sessionDetails?.currentTraining?.TrainingName,
        SessionName: sessionDetails?.currentTraining?.SessionName,
        SessionID: SessionID,
        IsDeleted: false,
        CreatedBy: props.user?.username,
        CreatedDate: date,
        LastModifiedBy: props.user?.username,
        LastModifiedDate: date,
        TenantID: props.TenantInfo.TenantID,
        StartDate: new Date(watch("newStartDate")).toISOString(),
        EndDate: new Date(watch("newEndDate")).toISOString()
      }
      let createSessionVariable = {
        input: [
          { ...variable },
          {
            ...variable,
            SK: "SESSION#STARTDATE#" + new Date(watch("newStartDate")).toISOString() + "#SESSIONID#" + SessionID
          }
        ]
      }
      const trainingVariables = {
        input: [{ ...sessionDetails?.currentTraining, SessionCount: (sessionDetails?.currentTraining.SessionCount) + 1 },
        { ...sessionDetails?.currentTraining, SK: "TRAININGINFO#LASTMODIFIEDDATE#" + sessionDetails?.currentTraining?.LastModifiedDate + "#TRAININGID#" + sessionDetails?.currentTraining?.TrainingID, SessionCount: (sessionDetails?.currentTraining.SessionCount) + 1 }
        ]
      }
      let finalResult = (await AppsyncDBconnection(createXlmsBatchTrainingSessionInfo, createSessionVariable, props.user.signInUserSession.accessToken.jwtToken)).Status
      await AppsyncDBconnection(createXlmsBatchTrainingManagement, trainingVariables, props.user.signInUserSession.accessToken.jwtToken)
      finalResponse(finalResult)
      setOpen((data) => { return !data })
      setValue("sessionSubmit", false)
      sessionRefresh()
    }

  }, [errors, finalResponse, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, props.user?.username, sessionDetails?.currentTraining, sessionRefresh, setValue, watch])

  const clearDateFields = useCallback((index) => {
    setValue("txtstTime" + index, "")
    setValue("txtEndTime" + index, "")
    clearErrors(["txtstTime" + index, "txtEndTime" + index])
  }, [clearErrors, setValue])


  const SessionSection = useCallback((trainingSession) => {
    let sessiondata = trainingSession?.sessionData
    return (
      <>
        <NVLSettingsCard className={"rounded-md  shadow-md  items-start "} >
          <div className={(enrollCount.current >0 || sessionStart.current )? "pointer-events-none rounded-md p-4 border-2" :"rounded-md p-4 border-2 "}>
            {/* <NVLlabel text={sessiondata.Type.toUpperCase()} className="nvl-Def-Label" /> */}
            <div className="flex justify-between"> <div><NVLlabel text={sessiondata?.TrainingName?.toUpperCase()} className={`nvl-Def-Label !text-primary`} />
              <NVLlabel text={`${Object.entries(sessiondata).length > 0 ? convertDate(sessiondata.StartDate) : ""} - ${Object.entries(sessiondata).length > 0 ? convertDate(sessiondata.EndDate) : ""}`} showFull className={"nvl-Def-Label pt-1 pb-1 "} /></div>
              <NVLButton id="btnaddnew" text="Add new session" className={(sessionStart.current  || (enrollCount.current >0 )) ? " Disabled nvl-button bg-gray-600 text-gray-800 " :"nvl-button bg-primary text-white "} onClick={() => {
                setOpen((open) => {
                  return open + 1;
                });
              }} /></div>
            <div className="rounded-md p-2 border-2 divide-y divide-dotted divide-gray-300/50">
              {sessionDetails?.sessionData?.length > 0 ?
                sessionDetails?.sessionData && sessionDetails?.sessionData.map((getItem, idx) => {
                  return (
                    <Fragment key={idx}>
                      {sessionAction.InitialCount > idx && <div key={idx} className="p-2 flex justify-between">
                        <div>
                          {/* <NVLlabel text={`${sessiondata.SessionName?.length > 35 ? (sessiondata.SessionName?.substring(0, 30) + "...") + " - " + (idx + 1) : sessiondata.SessionName + " - " + (idx + 1)} : ${convertDate(getItem.StartDate)} - ${convertDate(getItem.EndDate)}`} showFull className="nvl-Def-Label " /> */}
                          <NVLlabel text={`${sessiondata.SessionName?.length > 35 ? (sessiondata.SessionName?.substring(0, 30) + "...") + " - " + (idx + 1) : sessiondata.SessionName + " - " + (idx + 1)} `} showFull className="nvl-Def-Label !text-primary" />
                          <NVLlabel text={` ${convertDate(getItem.StartDate)} - ${convertDate(getItem.EndDate)}`} showFull className="nvl-Def-Label " />
                        </div>
                        {((rowData.Edit || rowData.Add) && getIndex == idx) &&
                          <div className="flex gap-2">
                            <div><NVLlabel text={"Date"} className="nvl-Def-Label " />
                              <NVLTextbox id={"txtstdate" + idx} title="Start Date" type="date" tabIndex={"1"} className={"!w-40 nvl-Def-Input Disabled"} disabled setValue={setValue} errors={errors} register={register}></NVLTextbox></div>

                            <div><NVLlabel text={"From"} className="nvl-Def-Label " />
                              <NVLTextbox id={"txtstTime" + idx} title="Start Time" type="time" tabIndex={"1"} className={"!w-36 nvl-Def-Input"} setValue={setValue} register={register}></NVLTextbox>
                              <div className="break-words w-44">
                                <div className={"{invalid-feedback}   text-red-500 text-sm break-all " + (props.icon ? " top-9 absolute" : "")}>
                                  {errors?.["txtstTime" + idx]?.message}</div>
                              </div>
                            </div>
                            <div> <NVLlabel text={"To"} className="nvl-Def-Label " />
                              <NVLTextbox id={"txtEndTime" + idx} title="End Time" type="time" tabIndex={"1"} className={"!w-36 nvl-Def-Input"} setValue={setValue} register={register}></NVLTextbox>
                              <div className="break-words w-44">
                                <div className={"{invalid-feedback}   text-red-500 text-sm break-all " + (props.icon ? " top-9 absolute" : "")}>
                                  {errors?.["txtEndTime" + idx]?.message}</div>
                              </div></div>
                          </div>}

                        <div className="flex gap-6 justify-end">
                          <i className={`${(rowData.Edit && getIndex == idx) ? "fa-solid fa-circle-check text-tiny text-emerald-600" : "fa-solid fa-pencil text-tiny text-emerald-600 "} ${(rowData.Add || (rowData.Edit && getIndex != idx)) || sessionStart.current  || (enrollCount.current >0 ) ? "pointer-events-none !text-gray-600" : ""}`} onClick={() => { setIndex(idx); editSession(rowData.Edit ? "submit" : "edit", getItem, idx) }} />
                          <i className={`fa fa-trash-o text-rose-700 text-tiny ${(rowData.Edit || rowData.Add) || sessionStart.current  || (enrollCount.current >0 ) ? "pointer-events-none !text-gray-600" : ""} `} onClick={() => deletePopup(getItem, sessionDetails?.sessionData?.length)} />
                          <i id="addbtn" className={`${(SessionExistCheck(getItem.StartDate)) ? "" : "pointer-events-none invisible"}${(rowData.Add && getIndex == idx) ? "fa-solid fa-circle-check text-tiny text-primary" : "fa-solid fa-circle-plus text-tiny text-emerald-600"}  ${(rowData.Edit || rowData.Add && getIndex != idx) || sessionStart.current  || (enrollCount.current >0 ) ? "pointer-events-none !text-gray-600" : ""}${watch("submitsession") ? "pointer-events-none" : ""}`} onClick={() => { setIndex(idx); addSession(rowData.Add ? "submit" : "add", getItem, idx) }} />
                          <i id="reset" className={`${(rowData.Edit || rowData.Add) && getIndex == idx ? "fa-solid fa-xmark text-rose-700" : "invisible"} "fa-solid fa-circle-check"}`} onClick={() => { clearDateFields(idx) }} />
                        </div>
                      </div>}
                    </Fragment>
                  )
                }) : <div className="flex justify-center">
                  <NVLlabel className="nvl-Def-Label" text="No Session found" />
                </div>
              }

            </div>
            {sessionDetails?.sessionData?.length > 10 && <NVLLink id={"lnkIsShowMore"} text={`${(sessionDetails?.sessionData?.length > sessionAction.InitialCount) ? "Show More " : "Show Less"}`} onClick={() => showMoreOrLess()} className="pt-2 text-xs"></NVLLink>}
          </div>
        </NVLSettingsCard>
      </>
    )
  }, [sessionDetails?.sessionData, convertDate, sessionAction.InitialCount, rowData.Edit, rowData.Add, getIndex, setValue, errors, register, props.icon, SessionExistCheck, watch, editSession, deletePopup, addSession, clearDateFields, showMoreOrLess])
  useEffect(() => {
    if (!open) {
      setValue("newStartDate", "")
      setValue("newEndDate", "")
      clearErrors(["newStartDate", "newEndDate"])
    }
  }, [clearErrors, open, setValue]);
  const GetComponent = useCallback(
    (PopupName) => {
      let ComponentData = {
        AddSession: (
          <>
            <div className={watch("sessionSubmit") ? "nvl-FormContent pointer-events-none" : "nvl-FormContent"}>
              <div>
                <NVLlabel text="Start Date" className="nvl-Def-Label pb-1"></NVLlabel>
                <NVLTextbox title="Start Date" id="newStartDate" type="datetime-local" tabIndex={"1"} className={`nvl-Def-Input nvl-mandatory`} errors={errors} register={register} setValue={setValue}></NVLTextbox>
              </div>
              <div>
                <NVLlabel text="End Date" className="nvl-Def-Label pb-1"></NVLlabel>
                <NVLTextbox title="End Date" id="newEndDate" type="datetime-local" tabIndex={"1"} className={`nvl-Def-Input nvl-mandatory`} errors={errors} register={register} setValue={setValue}></NVLTextbox>
              </div>
            </div>
            <div className="flex justify-center gap-2 pt-4">
              <NVLButton id="btnSubmit" text={!watch("sessionSubmit") ? "Save" : ""} type="submit" onClick={(e) => { submithandler("Save") }} className={watch("sessionSubmit") ? "pointer-events-none w-32 nvl-button bg-primary text-white" : "w-32 nvl-button bg-primary text-white "}>
                {watch("sessionSubmit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
              </NVLButton>
            </div>
          </>
        ),
      };
      return ComponentData[PopupName];
    },
    [errors, register, setValue, submithandler, watch]
  );
  return (
    <Container PageRoutes={PageRoutes} title="Session" loader={!sessionDetails?.trainingData ? true : false}>
      <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
      <NVLPageModalPopup
        ModalType="Page"
        ScreenName={`Add Session`}
        PageComponent={GetComponent("AddSession")}
        open={open}
        setOpen={setOpen}
        user={props?.user}
      />
      {/* <form id="sessionList"> */}
        <div className={(sessionStart.current  || enrollCount.current > 0) ? "pointer-events-none pt-1" :"pt-1"}>
          {/* border-2 border-gray-200 */}
          <SessionSection sessionData={sessionDetails?.currentTraining} />
        </div>
      {/* </form> */}
      {sessionDetails?.sessionData?.length <= 1 ? <NVLModalPopup ButtonYestext="OK" IsConfirmAlert loader={popupValues.isload} SubmitClick={(e) => cancelClick(e)} CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
        : <NVLModalPopup ButtonYestext="Yes" loader={popupValues.isload} SubmitClick={(e) => deleteSession(e)} CancelClick={(e) => cancelClick(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />}

    </Container>
  )
}

export default TrainingSession
