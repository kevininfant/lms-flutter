import Container from '@components/Container/Container'
import NVLAlert, { ModalOpen } from '@components/Controls/NVLAlert'
import NVLButton from '@components/Controls/NVLButton'
import NVLImage from '@components/Controls/NVLImage'
import NVLlabel from '@components/Controls/NVLlabel'
import NVLModalPopup from '@components/Controls/NVLModalPopup'
import NVLPageModalPopup from '@components/Controls/NVLPageModalPopup'
import NVLSelectField from '@components/Controls/NVLSelectField'
import { yupResolver } from "@hookform/resolvers/yup"
import { Auth } from 'aws-amplify'
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse'
import { useRouter } from 'next/router'
import 'quill/dist/quill.bubble.css'
import 'quill/dist/quill.snow.css'
import { useCallback, useEffect, useMemo, useState } from 'react'
import { useForm } from "react-hook-form"
import { createXlmsSelfEnrollUserBatch } from 'src/graphql/mutations'
import { getXlmsCourseManagementInfo, getXlmsSelfEnrollUser, listXlmsCourseBatchInfos, listXlmsCourseModuleCount } from 'src/graphql/queries'
import * as Yup from "yup"


function CourseCatalogueEnroll(props) {
    const router = useRouter();
    const [open, setOpen] = useState(false);
    const [fetchdata, setFetchdata] = useState({})
    let CourseID = useMemo(() => { return router.query["CourseID"] }, [router.query]);
    useEffect(() => {
        async function FetchData() {

            let ModuleActivityList = await AppsyncDBconnection(listXlmsCourseModuleCount, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + CourseID,
                SK: "COURSEMODULE#",
                IsDeleted: false,
                IsSuspend: false
            }, props.user?.signInUserSession?.accessToken?.jwtToken);
            let CourseDataList = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSEINFO#" + CourseID }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            setFetchdata({
                ModuleActivityList: ModuleActivityList?.res?.listXlmsCourseModuleCount?.items != undefined ? ModuleActivityList?.res?.listXlmsCourseModuleCount?.items : [],
                CourseData: CourseDataList?.res?.getXlmsCourseManagementInfo != undefined ? CourseDataList?.res?.getXlmsCourseManagementInfo : []
            })
        }
        FetchData()

        return (() => {
            setFetchdata((temp) => { return { ...temp } })
        })
    }, [CourseID, props?.TenantInfo?.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken])
    const [popupValues, setPopupValues] = useState({});
    const initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Your Course Nomination accepted  once approved you may accessing the course content.",
    };
    const [modalValues, setModalValues] = useState(initialModalState);

    const validationSchema = Yup.object().shape({ ddlBatch: Yup.string().required("Select a Batch Name").nullable(), })
    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: true,
    };

    const { register, watch, formState, reset, handleSubmit } = useForm(formOptions);
    const { errors } = formState;

    const ResetPopUp = useCallback(() => {

        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
        router.push("/BrowseCourseCatalog/CourseCatalog");
    }, [router])

    useEffect(() => {
        if(fetchdata?.CourseData!=undefined)
        document.getElementById("lblDescription").innerHTML = fetchdata?.CourseData?.CourseDescription != "undefined" ? fetchdata?.CourseData?.CourseDescription : "";
    }, [fetchdata?.CourseData])

    const EnrollHandler = useCallback(async (BatchID) => {

        let Variables = {
            input: {
                PK: "TENANT#" + props?.TenantInfo.TenantID,
                SK: "SELFENROLLUSER#COURSE#" + CourseID + "#BATCH#" + BatchID + "#USER#" + Auth?.user?.attributes["sub"],
                UserSub: Auth?.user?.attributes["sub"],
                UserName: Auth?.user?.username,
                EmailID: Auth?.user?.attributes["email"],
                UserName: props.user?.username,
                BatchID: BatchID,
                CourseID: CourseID,
                CourseName: fetchdata?.CourseData?.CourseName,
                StatusFlag: "Pending",
                LastModifiedBy: Auth?.user?.username,
                LastModifiedDate: new Date()
            }
        }
        let FinalStatus = await AppsyncDBconnection(createXlmsSelfEnrollUserBatch, Variables, props?.user?.signInUserSession?.accessToken?.jwtToken);
        FinalResponse(FinalStatus.Status);
    }, [CourseID, FinalResponse, fetchdata?.CourseData?.CourseName, props?.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, props.user?.username])

    const [RequestStatus, setRequestStatus] = useState("")

    const GetEnolComponent = useCallback(() => {

        async function getApprovaldata() {
            let Enrollrequest = await AppsyncDBconnection(getXlmsSelfEnrollUser, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "SELFENROLLUSER#COURSE#" + CourseID + "#BATCH#" + watch("ddlBatch") + "#USER#" + Auth?.user?.attributes["sub"], StatusFlag: "Pending" }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            let RequestData = Enrollrequest.res?.getXlmsSelfEnrollUser != undefined ? Enrollrequest.res?.getXlmsSelfEnrollUser : {};
            setRequestStatus(RequestData?.StatusFlag);
        }

        getApprovaldata()

        return (
            <>
                <form >
                    <div className="">
                        <NVLSelectField
                            id="ddlBatch"
                            labelText="Batch Name"
                            labelClassName="nvl-Def-Label"
                            className="nvl-mandatory nvl-Def-Input "
                            options={fetchdata?.CourseBatchData}
                            errors={errors}
                            register={register}
                        />
                    </div>
                    <div className="flex justify-between ">
                        <div className="flex">
                            {
                                (RequestStatus == "Rejected" || RequestStatus == undefined) ? <NVLButton type="submit" text="Enroll"
                                    onClick={handleSubmit((data) => EnrollHandler(data.ddlBatch))}
                                    className={"nvl-button bg-primary text-white"} />
                                    : RequestStatus == "Pending" ?
                                        <div className="{invalid-feedback} text-red-500 text-sm pt-2"> Enroll Request is pending </div>
                                        : RequestStatus == "Approved" ?
                                            <div className="{invalid-feedback} text-red-500 text-sm pt-2"> Course already enrolled </div> : ""
                            }
                        </div>
                    </div>

                </form>
            </>
        )
    }, [CourseID, EnrollHandler, RequestStatus, errors, fetchdata?.CourseBatchData, handleSubmit, props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, register, watch])
    const EnrolPopup = useCallback(async () => {
        let BatchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, {
            PK: "TENANT#" + props?.TenantInfo.TenantID + "#COURSEINFO#" + CourseID,
            SK: "COURSEBATCH#", IsDeleted: false
        },
            props?.user?.signInUserSession?.accessToken?.jwtToken
        );

        const CourseBatch = [{ value: "", text: "Select" }];

        BatchData.res?.listXlmsCourseBatchInfos?.items?.map((batch) => {
            CourseBatch.push({ value: batch.BatchID, text: batch.BatchName });
        });

        setFetchdata((data) => { return { ...data, CourseBatchData: CourseBatch } })
        setOpen((open) => {
            return !open;
        });
        reset();
    }, [CourseID, props?.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, reset])

    const FinalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
                ModalOnClickEvent: () => ResetPopUp("Submit")
            });
            ModalOpen();
            return;
        } else {
            setModalValues({
                ModalInfo: "Success",
                ModalTopMessage: FinalStatus,
                ModalBottomMessage: "Your Course Nomination accepted  once approved you may accessing the course content",
                ModalOnClickEvent: () => ResetPopUp("Submit")
            });
            ModalOpen();
        }
    }, [ResetPopUp])
    function toHoursAndMinutes(totalMinutes) {
        if (totalMinutes) {
            if (totalMinutes != "null") {
                const minutes = totalMinutes % 60;
                const hours = Math.floor(totalMinutes / 60);
                return `${padTo2Digits(hours)}:${padTo2Digits(minutes)}`;
            } else return `00:00`

        } else return `--:--`;

    }

    function padTo2Digits(num) {
        return num.toString().padStart(2, '0');
    }
    // Bread Crumbs
    let PageRoutes = [
        {
            path: "/BrowseCourseCatalog/CourseCatalog",
            breadcrumb: "Course Catalog"
        },
        { path: "", breadcrumb: fetchdata?.CourseData?.CourseName }
    ];

    return (
        <>
            <Container PageRoutes={PageRoutes} loader={fetchdata?.CourseData==undefined}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <NVLPageModalPopup ModalType="Page" ScreenName={`Self Enrollment`} PageComponent={GetEnolComponent()} open={open} setOpen={setOpen} />
                <NVLModalPopup ButtonYestext="Ok" SubmitClick={() => ResetPopUp()} CloseIconEvent={() => ResetPopUp()} Content={popupValues.Content} IsConfirmAlert ></NVLModalPopup>
                <div className={` border-gray-200 min-h-[200px] max-h-[400px] ml-5 bg-white md:flex  gap-4 `}>
                    <div className='w-10/12 border'>
                    <NVLImage className="w-[100%] h-[100%] object-fill" src={(fetchdata?.CourseData?.CourseThumbNail && fetchdata?.CourseData?.CourseThumbNail != "The specified key does not exist." && fetchdata?.CourseData?.CourseThumbNail != "null") ? fetchdata?.CourseData?.CourseThumbNail : "/CourseDefaultImage.jpg"} alt="Course" />
                    <div className={` border bg-white`}>
                    <div className='p-2'>
                        <span className='font-semibold'>Course Description:</span>
                        <div className='md:pl-24 m-2 break-all'>
                            <NVLlabel id="lblDescription" className="ql-editor"></NVLlabel>
                        </div>
                    </div>
                </div>
                </div>
                    <div className="w-full md:w-2/12 ">
                        <div className="pb-8 p-2  min-h-screen max-h-min pl-2 border">
                            <ul className="space-y-2">
                                <li>
                                    <NVLButton text="Self Enroll" disabled={fetchdata?.CourseData?.IsSelfDisable ? true : false} className={fetchdata?.CourseData?.IsSelfDisable ? "hidden cursor-not-allowed nvl-button text-gray-500 w-40" : "nvl-button bg-primary text-white w-40"} onClick={() =>
                                    EnrolPopup(CourseID, fetchdata?.CourseData?.CourseName)} />
                                </li>
                                <li>
                            {fetchdata?.CourseData?.TotalHours&& <div className="text-[10px] flex gap-1 my-auto "><span className='text-sm font-semibold'>Total hours</span> <i className="fa-solid fa-clock text-xs text-slate-600 my-auto"></i> <p className='my-auto'>: {toHoursAndMinutes(fetchdata?.CourseData?.TotalHours)}</p></div>}
                              </li>
                              <div className='text-sm text-primary font-semibold'>Module List</div>
                                <li className='grid gap-2'>
                                    {fetchdata?.ModuleActivityList&&fetchdata?.ModuleActivityList.map((item)=>{
                                    return  <div key={item} className="text-xs font-medium border-l-4 bg-blue-100  border-primary p-2" >{item?.ModuleName}</div>;
                                    })}
                                    {/* <NVLlabel text={`${fetchdata?.ModuleActivityList && Object.values(fetchdata?.ModuleActivityList).length} Modules`} className="font-bold text-tiny" /> */}
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                {/* <div className='pl-5 pt-2'>
                    <NVLlabel text={fetchdata?.CourseData?.CourseName} className="text-xl font-semibold" />
                    <div className="flex items-center invisible">
                        {["1", "2", "3", "4", "5"].map(() => {
                            return (
                                <div key={crypto.randomUUID()}>
                                    <i className="fa-solid fa-star text-gray-400 text-xl"></i>
                                </div>
                            )
                        })}
                    </div>
                </div> */}
                {/* Course Content Section */}
               
            </Container>
        </>
    )
}

export default CourseCatalogueEnroll
