import NVLAlert, { ModalOpen } from '@components/Controls/NVLAlert';
import NVLBreadCrumbs from '@components/Controls/NVLBreadCrumbs';
import NVLButton from '@components/Controls/NVLButton';
import NVLCheckbox from '@components/Controls/NVLCheckBox';
import NVLImage from '@components/Controls/NVLImage';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLLink from '@components/Controls/NVLLink';
import NVLPageModalPopup from '@components/Controls/NVLPageModalPopup';
import NVLSelectField from '@components/Controls/NVLSelectField';
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from 'aws-amplify';
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { createXlmsSelfEnrollUserBatch } from 'src/graphql/mutations';
import { getXlmsSelfEnrollUser, listXlmsCourseBatchInfos, listXlmsCourseManagementInfo, listXlmsCourseSubCategory, listXlmsEnrollUsercount, listXlmsLanguages } from 'src/graphql/queries';
import * as Yup from "yup";

function CourseCatalog(props) {

  const router = useRouter();
  const TenantId = useMemo(() => { return props.TenantInfo.TenantID }, [props.TenantInfo.TenantID])
  const PageUserSub = useMemo(() => { return props.user.attributes["sub"] }, [props.user.attributes])

  const GetAscendingOrder = useCallback((SortingCourseData) => {
    SortingCourseData.sort(function (a, b) {
      if (a.CourseName < b.CourseName) {
        return -1;
      }
      if (a.CourseName > b.CourseName) {
        return 1;
      }
      return 0;
    });
    return SortingCourseData;
  }, [])

  const [CatalogueData, setCatalogueData] = useState()
  const [CourseData, setCourseData] = useState(CatalogueData?.CourseData)


  useEffect(() => {
    async function CourseFetch() {
      let LanguageData = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME" }, props?.user?.signInUserSession?.accessToken?.jwtToken);

      let CategoryList = await AppsyncDBconnection(listXlmsCourseSubCategory, { PK: "TENANT#" + TenantId, SK: "COURSECATEGORY#", IsDeleted: false, }, props?.user?.signInUserSession?.accessToken?.jwtToken);

      let CourseDataList = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + TenantId, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);

      let EnrollCourseDataList = await AppsyncDBconnection(listXlmsEnrollUsercount, { PK: "TENANT#" + TenantId + "#COURSE#ENROLLUSER#" + PageUserSub, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);

      let Categorydata = CategoryList.res?.listXlmsCourseSubCategory?.items != undefined ? CategoryList.res?.listXlmsCourseSubCategory?.items : [];
      let SubCategoryFiltered = Categorydata.filter(
        (obj) => obj.SubCategoryName != null
      );
      let CategoryDataList = [...new Map(Categorydata?.map(item => [item["CategoryID"], item])).values()];
      setCatalogueData({
        LanguageData: LanguageData?.res?.listXlmsLanguages,
        CategoryList: Categorydata,
        CourseData: CourseDataList.res?.listXlmsCourseManagementInfo?.items != undefined ? CourseDataList.res?.listXlmsCourseManagementInfo?.items : [],
        EnrollCourseDataList: EnrollCourseDataList?.res?.listXlmsEnrollUsercount?.items != undefined ? EnrollCourseDataList?.res?.listXlmsEnrollUsercount?.items : [],
        SubCategoryData: SubCategoryFiltered,
        CategoryData: CategoryDataList
      })
      setCourseData(GetAscendingOrder(CourseDataList.res?.listXlmsCourseManagementInfo?.items != undefined ? CourseDataList.res?.listXlmsCourseManagementInfo?.items : []))
    }
    CourseFetch()
    return (() => {
      setCatalogueData((temp) => { return { ...temp } })
    })
  }, [GetAscendingOrder, PageUserSub, TenantId, props.TenantInfo.TenantID, props?.user.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken])

  const validationSchema = Yup.object().shape(
    {
      ddlBatch: Yup.string().required("Select a Batch Name").nullable(),
      ddlFilter: Yup.string().test("", "", (e) => {
        if (e != "") {
          CourseData.sort(function (a, b) {
            return new Date(b.CreatedDate) - new Date(a.CreatedDate);
          });
        } else {
          return CourseData
        }
      })
    })
  const [popupValues, setPopupValues] = useState({});
  const refSearchCourse = useRef("");
  const refSearchResult = useRef("");
  const [open, setOpen] = useState(false);
  const [CourseDetails, setCourseDetails] = useState({ CourseID: "", CourseName: "" });
  const [CourseBatchData, setCourseBatchData] = useState([]);
  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Your Course Nomination accepted  once approved you may accessing the course content.",
  };
  const [modalValues, setModalValues] = useState(initialModalState);
  const [IsShowCategoryMore, setIsShowCategoryMore] = useState(true);
  const [IsShowCourseMore, setIsShowCourseMore] = useState(true);

  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: true,
  };

  const { register, watch, formState, reset, handleSubmit } = useForm(formOptions);
  const { errors } = formState;

  const FilterContent = useMemo(() => {
    return [
      { value: "", text: "Sort by" },
      { value: "NewCourse", text: "New Course" },
      // { value: "MostViewed", text: "Most Viewed" }, 
      // { value: "HighestRated", text: "Highest Rated" }
    ];
  }, []);

  const Levels = useMemo(() => {
    return [
      { value: "Beginner", text: "Beginner" },
      { value: "Intermediate", text: "Intermediate" },
      { value: "Expert", text: "Expert" }
    ];
  }, []);

  let LanguageType = useMemo(() => {
    let type = []
    if (CatalogueData?.LanguageData != undefined) {
      if (Object.keys(JSON.parse(CatalogueData?.LanguageData?.items[0].LanguageName)) != undefined) {
        Object.entries(JSON.parse(CatalogueData?.LanguageData?.items[0].LanguageName)).forEach(([key, value]) => {
          type = [...type, { value: value, text: key }];
        });
      }
    }
    return type;
  }, [CatalogueData?.LanguageData])

  const VideoDuration = useMemo(() => {
    return [
      { value: "1", text: "0-1 Hour" },
      { value: "3", text: "1-3 Hour" },
      { value: "6", text: "3-6 Hour" },
      { value: "17", text: "6-17 Hour" },
      { value: "18", text: "17+ Hour" }
    ];
  }, []);

  // const Ratings = useMemo(() => {
  //   return [
  //     {
  //       value: "4.5", text: "4.5 & up",
  //       RatingComponent: <> <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //       </>
  //     },
  //     {
  //       value: "4", text: "4.0 & up", RatingComponent: <> <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-gray-400"></i>
  //       </>
  //     },
  //     {
  //       value: "3.5", text: "3.5 & up", RatingComponent: <> <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-gray-400"></i>
  //       </>
  //     },
  //     {
  //       value: "3", text: "3.0 & up", RatingComponent: <> <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-yellow-400"></i>
  //         <i className="fa-solid fa-star text-gray-400"></i>
  //         <i className="fa-solid fa-star text-gray-400"></i>
  //       </>
  //     }
  //   ];
  // }, []);


  function ResetPopUp(mode) {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    if (mode == "Submit") return window.location.reload();

  }

  //   function custom_sort(a, b) {
  //     return new Date(a.lastUpdated).getTime() - new Date(b.lastUpdated).getTime();
  // }
  // var your_array = [
  //     {lastUpdated: "2010/01/01"},
  //     {lastUpdated: "2009/01/01"},
  //     {lastUpdated: "2010/07/01"}
  // ];

  // your_array.sort(custom_sort);

  const EnrolPopup = useCallback(async (courseid, Coursename) => {
    setCourseDetails({ CourseID: courseid, CourseName: Coursename })
    let BatchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, {
      PK: "TENANT#" + props?.TenantInfo.TenantID + "#COURSEINFO#" + courseid,
      SK: "COURSEBATCH#", IsDeleted: false
    },
      props?.user?.signInUserSession?.accessToken?.jwtToken
    );

    const CourseBatch = [{ value: "", text: "Select" }];

    BatchData.res?.listXlmsCourseBatchInfos?.items?.map((batch) => {
      CourseBatch.push({ value: batch.BatchID, text: batch.BatchName });
    });
    setCourseBatchData(CourseBatch)
    setOpen((open) => {
      return !open;
    });
    reset();
  }, [props?.user?.signInUserSession?.accessToken?.jwtToken, props?.TenantInfo.TenantID, reset])

  const EnrollHandler = useCallback(async (BatchID) => {

    let Variables = {
      input: {
        PK: "TENANT#" + props?.TenantInfo.TenantID,
        SK: "SELFENROLLUSER#COURSE#" + CourseDetails?.CourseID + "#BATCH#" + BatchID + "#USER#" + Auth?.user?.attributes["sub"],
        UserSub: Auth?.user?.attributes["sub"],
        UserName: Auth?.user?.username,
        EmailID: Auth?.user?.attributes["email"],
        UserName: props.user?.username,
        BatchID: BatchID,
        CourseID: CourseDetails?.CourseID,
        CourseName: CourseDetails?.CourseName,
        StatusFlag: "Pending",
        LastModifiedBy: Auth?.user?.username,
        LastModifiedDate: new Date()
      }
    }
    let FinalStatus = await AppsyncDBconnection(createXlmsSelfEnrollUserBatch, Variables, props?.user?.signInUserSession?.accessToken?.jwtToken);

    FinalResponse(FinalStatus.Status);
    // let FinalStatus = await APIGatewayPostRequest(fetchURL, Headers);
    // setPopupValues({content:""});
    // if (FinalStatus.Status == "Success") {
    //   setPopupValues({ Content: "Your Course Nomination accepted  once approved you may accessing the course content" });
    // } else {
    //   setPopupValues({ Content: "Somthing went wrong while proceesing your data" });
    // }

    // let Variables = {
    //   input: {
    //     PK: "TENANT#" + props?.TenantInfo.TenantID,
    //     SK: "COURSEINFO#" + courseID,
    //   },
    // };

    // await AppsyncDBconnection(updateXlmsCourseManagementInfo, Variables, props?.user?.signInUserSession?.accessToken?.jwtToken)

  }, [props?.user?.signInUserSession?.accessToken?.jwtToken, CourseDetails?.CourseID, CourseDetails?.CourseName, FinalResponse, props?.TenantInfo.TenantID, props.user?.username])

  const FinalResponse = useCallback((FinalStatus) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
        ModalOnClickEvent: () => ResetPopUp("Submit")
      });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Success",
        ModalTopMessage: FinalStatus,
        ModalBottomMessage: "Your Course Nomination accepted  once approved you may accessing the course content",
        ModalOnClickEvent: () => ResetPopUp("Submit")
      });
      ModalOpen();
    }
  }, [])

  const SearchCourseHandler = useCallback(() => {
    reset();
    if (refSearchCourse?.current?.value == "") {
      refSearchResult.current.value = "";
      setCourseData(CatalogueData?.CourseData)
    } else {
      let CourseFilterData = CatalogueData?.CourseData?.filter((course) => {
        return course.CourseName.toLowerCase().includes(refSearchCourse?.current.value?.toLowerCase());
      })
      let CourseFilterDataLength = Object.values(CourseFilterData)?.length;
      refSearchResult.current.value = CourseFilterDataLength == 0 ? "We were not able to find the course you're looking for." : "Search Results Found (" + CourseFilterDataLength + ")";
      setCourseData(CourseFilterData)
    }
  }, [CatalogueData?.CourseData, reset])


  const GetCategoryCourseList = useCallback(async (CategoryID, index) => {

    const response = await AppsyncDBconnection(listXlmsCourseManagementInfo, {
      PK: "TENANT#" + props.TenantInfo.TenantID,
      SK: "COURSEINFO#",
      IsDeleted: false,
      IsSuspend: false,
    }, props?.user?.signInUserSession?.accessToken?.jwtToken);
    let Data = response?.res?.listXlmsCourseManagementInfo?.items;

    let Datafilter = Data?.filter((Course) => !Data[Course.CategoryID]);

    let courseList = Datafilter?.filter(
      (obj) => obj.CategoryID == CategoryID
    );
    let CourseFilterDataLength = courseList && Object.values(courseList)?.length;
    refSearchResult.current.value = CourseFilterDataLength == undefined ? "Course Found (0)" : "Course Found (" + CourseFilterDataLength + ")";

    setCourseData(courseList);

  }, [props?.user?.signInUserSession?.accessToken?.jwtToken, props.TenantInfo.TenantID])

  const GetSubCategoryCourseList = (async (SubCategoryID, index) => {
    const response = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#", IsDeleted: false, IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
    let Data = response?.res?.listXlmsCourseManagementInfo?.items;
    let Datafilter = Data?.filter((Course) => !Data[Course.SubCategoryID]);
    let courseList = Datafilter?.filter(
      (obj) => obj.SubCategoryID == SubCategoryID
    );

    let CourseFilterDataLength = courseList && Object.values(courseList)?.length;
    refSearchResult.current.value = CourseFilterDataLength == undefined ? "Course Found (0)" : "Course Found (" + CourseFilterDataLength + ")";
    setCourseData(courseList);

  }
  );
  const FilterCourseDurationCourseData = useCallback(() => {

    function isBetween(TotalHours, range) {
      for (let i = 0; i < range.length; i++)
        if (TotalHours >= range[i][0] && TotalHours <= range[i][1])
          return TotalHours >= range[i][0] && TotalHours <= range[i][1];
    }
    let CheckedDuration = [];
    VideoDuration.map((video) => {
      if (document.getElementById("ChkCourseDuration" + video?.value)?.checked) {
        CheckedDuration.push((video?.value == "1" ? [0, 1] : video?.value == "3" ? [1, 3] : video?.value == "6" ? [3, 6] :
          video?.value == "17" ? [6, 17] :
            video?.value == "18" ? [17, 999] : "0"
        ));
      }
    })

    if (CheckedDuration?.length == 0) {
      setCourseData(CatalogueData?.CourseData)
      return;
    }
    document.getElementById("txtSearchCourse").value = "";
    let FilterDurationData = CatalogueData?.CourseData.filter((Course) => {
      return isBetween((Course.TotalHours) / 60, eval(CheckedDuration))
    })
    setCourseData(FilterDurationData)
  }, [VideoDuration, CatalogueData?.CourseData])

  const FilterCourseHandler = useCallback((mode) => {
    let CheckedCourseData = [];
    document.getElementById("txtSearchCourse").value = "";
    CatalogueData?.CourseData.filter((Course) => {
      if (document.getElementById(Course.SK)?.checked) {
        CheckedCourseData.push(Course);
      }
      return CheckedCourseData
    })

    let CourseFilterDataLength = Object.values(CheckedCourseData)?.length;
    if (CheckedCourseData && Object.values(CheckedCourseData)?.length == 0) {
      refSearchResult.current.value = "";
      setCourseData(CatalogueData?.CourseData)
    } else {
      refSearchResult.current.value = CourseFilterDataLength == 0 ? `We were not able to find the course you're looking for.` : "Filter Results Found (" + CourseFilterDataLength + ")";
      setCourseData(CheckedCourseData)
    }
  }, [CatalogueData?.CourseData])


  const SubCategoryHandler = (index) => {
    document.getElementById("divsubName" + index)?.classList?.toggle("hidden");
    document.getElementById("divSubAction" + index)?.classList?.toggle("hidden");
    document.getElementById("ShowCatIcon" + index)?.classList?.toggle("hidden");
    document.getElementById("ShowSubIcon" + index)?.classList?.toggle("hidden");
  };

  const GetCourseCount = useCallback(() => {
    if (CourseData != undefined) {
      let CourseCount = CourseData?.filter((Course) => {
        return !Course?.IsSuspend
      })
      let CourseFinalCount = Object.values(CourseCount)?.length;
      return CourseFinalCount
    }
    else {
      return 0;
    }
  }, [CourseData])

  const [RequestStatus, setRequestStatus] = useState("")
  const GetEnolComponent = useCallback((CourseID) => {
    async function getApprovaldata() {
      let Enrollrequest = await AppsyncDBconnection(getXlmsSelfEnrollUser, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "SELFENROLLUSER#COURSE#" + CourseDetails?.CourseID + "#BATCH#" + watch("ddlBatch") + "#USER#" + Auth?.user?.attributes["sub"], StatusFlag: "Pending" }, props?.user?.signInUserSession?.accessToken?.jwtToken)
      let RequestData = Enrollrequest.res?.getXlmsSelfEnrollUser != undefined ? Enrollrequest.res?.getXlmsSelfEnrollUser : {};
      setRequestStatus(RequestData?.StatusFlag);
    }
    getApprovaldata()
    return (
      <>
        <form >
          <div className="">
            <NVLSelectField
              id="ddlBatch"
              labelText="Batch Name"
              labelClassName="nvl-Def-Label"
              className="nvl-mandatory nvl-Def-Input "
              options={CourseBatchData}
              errors={errors}
              register={register}
            />
          </div>
          <div className="flex justify-between ">
            <div className="flex">
              {
                (RequestStatus == "Rejected" || RequestStatus == undefined) ? <NVLButton type="submit" text="Enroll"
                  onClick={handleSubmit((data) => EnrollHandler(data.ddlBatch))}
                  className={"nvl-button bg-primary text-white"} />
                  : RequestStatus == "Pending" ?
                    <div className="{invalid-feedback} text-red-500 text-sm pt-2"> Enroll Request is pending </div>
                    : RequestStatus == "Approved" ?
                      <div className="{invalid-feedback} text-red-500 text-sm pt-2"> Course already enrolled </div> : ""
              }
            </div>
          </div>

        </form>
      </>
    )
  }, [props?.user?.signInUserSession?.accessToken?.jwtToken, CourseBatchData, CourseDetails?.CourseID, EnrollHandler, RequestStatus, errors, handleSubmit, props.TenantInfo.TenantID, register, watch])

  // Bread Crumbs
  let PageRoutes = [
    {
      path: "",
      breadcrumb: "Course Catalog"
    },
  ];
  const [openCategoryBar, setOpenCategoryBar] = useState(false)

  const isFetchSubCategories = useCallback((parentCategoryId) => {
    let newArray = CatalogueData?.SubCategoryData && CatalogueData?.SubCategoryData?.filter(function (el) {
      return el.CategoryID == parentCategoryId;
    });
    return newArray?.length;
  }, [CatalogueData?.SubCategoryData])

  return (
    <>
      <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
      <NVLBreadCrumbs Routes={PageRoutes}></NVLBreadCrumbs>
      <NVLPageModalPopup ModalType="Page" ScreenName={`Self Enrollment`} PageComponent={GetEnolComponent()} open={open} setOpen={setOpen} />
      <div className='lg:flex gap-4'>
        <main className=" w-full space-y-4">
          <div className='h-10 bg-slate-50 '>
            <div className="p-2 bg-[#f9fafc] flex justify-between">
              <div className='w-56 relative'>
                <input id="txtSearchCourse" ref={refSearchCourse} className="nvl-Dash-input !w-full !text-xs " type="search" name="search" placeholder="Search By Course Name" onChange={(e) => SearchCourseHandler(e)} />
                <button type="submit" className="absolute -right-4 bottom-2 ">
                  <i className="fa-solid fa-magnifying-glass h-4 w-4 absolute -bottom-0.5 right-6 text-gray-400" onClick={(e) => SearchCourseHandler(e)}></i>
                </button>
              </div>
              <div>
                <span className='text-xs px-2 font-semibold text-slate-600 ' id="lblResults" ref={refSearchResult}>{refSearchResult?.current?.value}</span>
                {!refSearchResult.current.value && <span className='text-xs px-2 text-gray-700 font-semibold my-auto'>Total Number Of Course : {GetCourseCount()}
                </span>
                }</div>
            </div>
          </div>

          {CourseData && <div className={`grid grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 ${!openCategoryBar ? " xl:grid-cols-3" : " xl:grid-cols-4"} gap-6 w-full  p-2`}>
            {CourseData.map((Course) => {
              if (!Course?.IsSuspend) {
                return (<div key={crypto.randomUUID()} className="bg-white rounded overflow-hidden shadow-lg hover:-translate-y-1 hover:shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] ease-in duration-150 cursor-pointer">
                  <div className='!h-28 relative overflow-hidden group'>
                    <NVLImage className="hover:bg-blend-saturation h-full w-full hover:scale-110 duration-500" src={(Course?.CourseThumbNail && Course?.CourseThumbNail != "The specified key does not exist.") ? Course?.CourseThumbNail : "/CourseDefaultImage.jpg"} alt="Course" />
                    <div className="bg-[rgba(0,0,0,0.34)] text-white absolute -top-[100%] h-[100%] w-[100%] ease-in duration-300 group-hover:top-0 text-center text-xs p-2">
                      <NVLButton text="View" onClick={() => router.push(`/BrowseCourseCatalog/CourseCatalogueEnroll?CourseID=${encodeURIComponent(Course.CourseID)}`)} className={`nvl-button bg-primary text-white !rounded-full mt-8`} />
                    </div>
                  </div>
                  <div className="p-2">
                    <NVLlabel showFull={true} className="text-slate-700 font-bold text-tiny cursor-pointer !break-all" text={Course.CourseName} onClick={() => router.push(`/BrowseCourseCatalog/CourseCatalogueEnroll?CourseID=${encodeURIComponent(Course.CourseID)}`)}>
                    </NVLlabel>
                    <div>
                      <div className='w-full bg-slate-100 flex justify-center my-2'><div className='w-8 h-1 bg-primary rounded-full'></div></div>
                      <div className="flex justify-between text-gray-600">
                        <div className='gap-4 text-xl flex justify-between my-auto'>
                          <i className="fa fa-id-card text-slate-700 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-slate-100" aria-hidden="true" title='Certificate'></i>
                          <i className="fa-sharp fa-solid fa-ribbon  text-slate-700 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-slate-100" aria-hidden="true" title='Badge'></i>
                        </div>
                        <NVLButton text="Enroll" disabled={Course?.IsSelfDisable ? true : false}
                          className={` !rounded-full px-2 !text-[10px] py-1 !h-8 w-20 ${Course?.IsSelfDisable ? "invisible cursor-not-allowed nvl-button text-gray-500" : "nvl-button bg-primary text-white"}`} onClick={() =>
                            EnrolPopup(Course?.CourseID, Course?.CourseName)} />
                      </div>
                    </div>
                  </div>
                </div>
                )
              }
            })
            }
          </div>}
        </main>
        <div className={`${!openCategoryBar && "hidden"} `}>
          <button onClick={() => setOpenCategoryBar(!openCategoryBar)} type="button" className={`  bg-primary text-white shadow-md duration-300 float-right left-4 py-2 h-10 w-5 rounded-l-lg  border-gray-200  px-2  text-xs`}>
            {openCategoryBar ? <i className="fa-solid fa-chevron-left"></i> : <i className="fa-solid fa-chevron-right"></i>}
          </button>
        </div>
        <div className={` ${openCategoryBar ? "hidden " : "relative block"} lg:w-[25%] flex flex-col bg-red-20 text-xs  `}>
          <div className={`${!openCategoryBar && "absolute -left-5"} `}>
            <button onClick={() => setOpenCategoryBar(!openCategoryBar)} type="button" className={`  bg-primary text-white shadow-md duration-300 float-right left-4 py-2 h-10 w-5 rounded-l-lg  border-gray-200  px-2  text-xs`}>
              {openCategoryBar ? <i className="fa-solid fa-chevron-left"></i> : <i className="fa-solid fa-chevron-right"></i>}
            </button>
          </div>
          <nav className="  w-full ">
            <div className=" w-full">
              {/* CategoryList */}
              <div className="space-y-3 min-h-screen max-h-min">
                <div className="bg-[#f9fafc]  p-3">
                  <NVLlabel text="Search by Category"
                    className="font-semibold !text-sm text-gray-700" />
                </div>
                <ul className="space-y-2 p-2 bg-[#f9fafc] ">
                  <li className='border bg-white '>
                    <a className=" bg-opacity-30 nvl-Def-Label py-1.5 rounded cursor-pointer " >
                      <span className="items-center">
                        {CatalogueData?.CategoryData && CatalogueData?.CategoryData?.map((getItem, index) => {
                          return (
                            <>
                              <div className={`pl-2 text-blue-600 ${(index > 10 && IsShowCategoryMore) ? "hidden" : ""} `}>
                                <div className="flex ">
                                  {(getItem.CategoryName && !getItem?.IsSuspend) && (
                                    <>
                                      {(isFetchSubCategories(getItem?.CategoryID) != 0) && <>
                                        <i className="fa fa-caret-right text-md cursor-pointer my-auto" id={"ShowCatIcon" + getItem?.CategoryID}
                                          onClick={() => SubCategoryHandler(getItem?.CategoryID)}>  </i>
                                        <i className="fa fa-caret-down text-md hidden cursor-pointer my-auto" id={"ShowSubIcon" + getItem?.CategoryID} onClick={() => SubCategoryHandler(getItem?.CategoryID)} ></i>
                                      </>}
                                      <NVLLink id={"txtName" + (index + 1)} title={getItem?.CategoryName} onClick={() => { SubCategoryHandler(getItem?.CategoryID); GetCategoryCourseList(getItem.CategoryID); }}
                                        text={getItem?.CategoryName}
                                        className="pl-1 cursor-pointer text-slate-700 !w-full"
                                      ></NVLLink>
                                    </>
                                  )}
                                </div>
                              </div>
                              <div id={"divsubName" + getItem?.CategoryID} className="hidden pl-4 break-all">

                                {CatalogueData?.SubCategoryData?.map((SubCategory, idx) => {
                                  return (
                                    <div key={idx}>
                                      <div>
                                        {(getItem?.CategoryID == SubCategory?.CategoryID && SubCategory?.SubCategoryName != null && !SubCategory?.IsSuspend) && (
                                          <>
                                            <div className="flex pl-1 text-tiny">
                                              <div id={idx}>
                                                <NVLLink id={"txtName" + (index + 1)} title={SubCategory?.SubCategoryName} text={
                                                  SubCategory?.SubCategoryName
                                                }
                                                  className="text-slate-700"
                                                  onClick={() =>
                                                    GetSubCategoryCourseList(
                                                      SubCategory.SubCategoryID
                                                    )
                                                  }
                                                ></NVLLink>
                                              </div>
                                            </div>
                                          </>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </>
                          )
                        })
                        }
                        <div className='p-2 bg-[#f9fafc] '>
                          {CatalogueData?.CategoryData?.length > 10 && <span className="text-blue-900 " onClick={() => setIsShowCategoryMore((prev) => !prev)}>
                            {IsShowCategoryMore ? <>More Category <i className="fa-solid fa-chevron-down"></i></> : <>Less Category <i className="fa-solid fa-chevron-up"></i></>}
                          </span>}
                        </div>
                      </span>
                    </a>
                  </li>

                  {/* Filter */}
                  <div className="flex gap-6 pl-1">
                    <NVLButton text="Filter" ButtonType="primary" className="w-40" onClick={() => FilterCourseHandler("Submit")} />
                    <NVLSelectField id={"ddlFilter"}
                      className="w-40 nvl-button pl-4" options={FilterContent} errors={errors} register={register} />
                  </div>

                  {/* Course */}
                  <li>
                    <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                      <span className="flex items-center space-x-2">
                        <details className='pl-2'>
                          <summary className="text-blue-600"><span className='text-gray-700'>Course</span></summary>
                          {CatalogueData?.CourseData && CatalogueData?.CourseData.map((course, index) => {
                            return (
                              <div key={crypto.randomUUID()}>
                                {!course?.IsSuspend && <div className={`flex justify-between ${(index > 10 && IsShowCourseMore) ? "hidden" : ""}`}>
                                  <ul className='pt-2 pb-2 pl-3'>
                                    <li>
                                      <NVLCheckbox
                                        id={course.SK}
                                        text={course.CourseName}
                                        value={course.SK}
                                        name={"CheckLanguage"}
                                        className={"text-gray-700"}
                                        errors={errors}
                                        register={register}
                                        onClick={() => FilterCourseHandler("Course")}
                                      ></NVLCheckbox>
                                    </li>
                                  </ul>
                                </div>}
                              </div>
                            )
                          })}
                          <div className='pt-2'>
                            {CatalogueData?.CourseData && Object.values(CatalogueData?.CourseData)?.length > 10 && <span className="text-amber-900" onClick={() => setIsShowCourseMore((prev) => !prev)}>
                              {`${IsShowCourseMore ? "More Course" : "Less Course"}`}
                            </span>}
                          </div>
                        </details>
                      </span>
                    </a>
                  </li>
                  {/* <li>
                    <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                      <span className="flex items-center space-x-2">
                        <details className='pl-2'>
                          <summary className={"text-blue-600"}>Level</summary>
                          {Levels.map((level) => {
                            return (
                              <div key={crypto.randomUUID()}>
                                <div className="flex justify-between">
                                  <ul className='pt-2 pb-1 text-tiny pl-3'>
                                    <li>
                                      <NVLCheckbox
                                        id={`chkLevel`}
                                        text={level.text}
                                        value={true}
                                        name={"CheckLevels"}
                                        className="text-xs text-blue-600"
                                        errors={errors}
                                        register={register}
                                      ></NVLCheckbox>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            )
                          })

                          }
                        </details>
                      </span>
                    </a>
                  </li> */}
                  {/* <li>
                    <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                      <span className="flex items-center space-x-2">
                        <details className='pl-2'>
                          <summary className={"text-blue-600"}>Language</summary>
                          {LanguageType && LanguageType.map((language) => {
                            return (
                              <div key={crypto.randomUUID()}>
                                <div className="flex justify-between">
                                  <ul className='pt-2 pb-4 pl-3'>
                                    <li>
                                      <NVLCheckbox
                                        id={`chkLanguage`}
                                        text={language.text}
                                        value={true}
                                        name={"CheckLanguage"}
                                        className="text-xs text-blue-600"
                                        errors={errors}
                                        register={register}
                                      ></NVLCheckbox>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            )
                          })}
                        </details>
                      </span>
                    </a>
                  </li> */}
                  {/* <li>
                    <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                      <span className="flex items-center space-x-2">
                        <details className='pl-2'>
                          <summary className={"text-blue-600"}>Price</summary>
                          <div className="flex justify-between">
                            <ul className='pt-2 pb-4 pl-3'>
                              <li className='text-gray-400'>
                                Comming soon
                              </li>
                            </ul>
                          </div>
                        </details>
                      </span>
                    </a>
                  </li> */}
                  <li>
                    <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                      <span className="flex items-center space-x-2">
                        <details className='pl-2'>
                          <summary className={"text-blue-600"}><span className='text-gray-700'>Course Duration</span></summary>
                          {
                            VideoDuration.map((video) => {
                              return (
                                <div key={crypto.randomUUID()}>
                                  <div className="flex justify-between">
                                    <ul className='pt-2 pb-4 pl-3'>
                                      <li>
                                        <NVLCheckbox
                                          id={"ChkCourseDuration" + video?.value}
                                          text={video.text}
                                          value={video?.value}
                                          name={"CheckCourseDuration"}
                                          className={"text-gray-700"}
                                          errors={errors}
                                          register={register}
                                          onClick={() => FilterCourseDurationCourseData()}
                                        ></NVLCheckbox>
                                      </li>
                                    </ul>

                                  </div>
                                </div>
                              )
                            })
                          }
                        </details>
                      </span>
                    </a>
                  </li>
                  {/* <li>
                    <a className=" bg-opacity-30 nvl-Def-Label flex items-center justify-between py-1.5 rounded cursor-pointer">
                      <span className="flex items-center space-x-2">
                        <details className='pl-2'>
                          <summary className={"text-blue-600"}>Rating</summary>
                          {Ratings.map((rating) => {
                            return (
                              <div key={crypto.randomUUID()}>
                                <div className="flex">
                                  <ul className='pt-2 pl-3'>
                                    <li className='flex '>
                                      <NVLRadio
                                        id={rating?.text}
                                        name={"Rating"}
                                        value={rating?.value}
                                        errors={errors}
                                        register={register}
                                      ></NVLRadio>
                                      <div key={crypto.randomUUID()}>

                                        {rating.RatingComponent}
                                      </div>
                                      <div className='pl-2'>
                                        <span className="text-tiny text-blue-600">{rating.text}</span>
                                      </div>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            )
                          })}
                        </details>
                      </span>
                    </a>
                  </li> */}
                </ul>
              </div>
            </div>
          </nav>

        </div>
      </div>
    </>
  )
}

export default CourseCatalog
