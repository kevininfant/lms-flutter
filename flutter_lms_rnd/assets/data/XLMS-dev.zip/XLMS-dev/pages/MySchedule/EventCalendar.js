import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingIndicator from "@components/Controls/NVLLoadingIndicator";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { deleteXlmsMyScheduleEvent } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import moment from 'moment';
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { FaTemperatureHigh } from "react-icons/fa";
import { Regex } from "RegularExpression/Regex";
import { getXlmsCourseEnrollUser, getXlmsEnrollUser, listXlmsCourseEnrollUser, listXlmsCourseManagementInfo, listXlmsEnrollUser, listXlmsMyScheduleEvent } from "src/graphql/queries";
import * as Yup from "yup";

const TuiCalendar = dynamic(() => import("@components/Controls/NVLCalander"), {
  ssr: false,
});

const CalendarComponent = React.forwardRef((props, ref) => (
  <TuiCalendar
    {...props}
    forwardedRef={ref}
  />
));

CalendarComponent.displayName = "CalendarComponent";

export default function CustomCalendar(props) {

  const router = useRouter()
  const [RowGridData, setRowGridData] = useState([]);
  const [PropsList, setPropsList] = useState({})
  const [isLoading, setisLoading] = useState(true)

  const validationSchema = Yup.object().shape({
    txtEventTitle: Yup.string()
      .required("Event Title")
      .matches(Regex("AlphabetsAndSpaceOnly"), "Invalid Event Title"),
    txtCourse: Yup.string()
      .required("Course Name")
      .matches(Regex("AlphabetsAndSpaceOnly"), "Invalid Course Name"),
    ddlFilter: Yup.string().test("", "", () => {
      handleReload();
      FilterEvents(PropsList)
    }),
  });

  const [open, setOpen] = useState(false);
  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };

  const { register, watch, formState, setValue } =
    useForm(formOptions);
  const { errors } = formState;


  useEffect(() => {
    async function CalendarData() {

      let Root = decodeURIComponent(router.query["Root"]);
      let TenantName = props.user.attributes["name"];
      let TenantID = props.user.attributes["custom:tenantid"];
      let UserSub = props.user.attributes["sub"];

      const Batchlist = [], Courselist = [], Activitylist = [], scheduleData = [];

      const allCoursesList = await AppsyncDBconnection(
        listXlmsCourseManagementInfo,
        {
          PK: "TENANT#" + TenantID ,
          SK: "COURSEINFO#",
          IsDeleted: false
        }, props.user.signInUserSession.accessToken.jwtToken
      );


      const Courseresponse = await AppsyncDBconnection(
        listXlmsCourseEnrollUser,
        {
          PK: "TENANT#" + TenantID + "#COURSE#ENROLLUSER#" + UserSub,
          SK: "COURSE#",
          IsSuspend: false
        }, props.user.signInUserSession.accessToken.jwtToken
      );

      Courseresponse?.res?.listXlmsCourseEnrollUser?.items?.map(async (getitem, index) => {
        const Coursedetail = await AppsyncDBconnection(
          getXlmsCourseEnrollUser,
          {
            PK: "TENANT#" + TenantID + "#" + getitem.Shard,
            SK: "COURSEINFO#" + getitem.CourseID,
          }, props.user.signInUserSession.accessToken.jwtToken)
        Courselist.push({...Coursedetail?.res?.getXlmsCourseEnrollUser,BatchID:getitem.BatchID})
        const Batchdetail = await AppsyncDBconnection(
          getXlmsCourseEnrollUser,
          {
            PK: "TENANT#" + TenantID + "#COURSEINFO#" + getitem.CourseID + "#" + getitem.Shard,
            SK: "COURSEBATCH#" + getitem.BatchID,
          }, props.user.signInUserSession.accessToken.jwtToken)
        if (Batchdetail?.res?.getXlmsCourseEnrollUser) Batchlist.push(Batchdetail?.res?.getXlmsCourseEnrollUser)
      })
      const Activityresponse = await AppsyncDBconnection(
        listXlmsEnrollUser,
        {
          PK: "TENANT#" + TenantID + "#ACTIVITY#ENROLLUSER#" + UserSub,
          SK: "ACTIVITYID#",
        }, props.user.signInUserSession.accessToken.jwtToken
      );
      Activityresponse?.res?.listXlmsEnrollUser?.items?.map(async (getitem, index) => {
        const Activitydetail = await AppsyncDBconnection(
          getXlmsEnrollUser,
          {
            PK: "TENANT#" + TenantID + "#" + getitem.Shard,
            SK: "ACTIVITYTYPE#" + getitem.ActivityType + "#ACTIVITYID#" + getitem.ActivityID,
          }, props.user.signInUserSession.accessToken.jwtToken)
        if (Activitydetail?.res?.getXlmsEnrollUser) Activitylist.push(Activitydetail?.res?.getXlmsEnrollUser)
      })
      const eventResponse = await AppsyncDBconnection(
        listXlmsMyScheduleEvent,
        {
          PK: "TENANT#" + TenantID,
          SK: "USERSUB#" + UserSub + "#EVENT#",
          IsDeleted: false
        }, props.user.signInUserSession.accessToken.jwtToken
      );
      eventResponse && eventResponse?.res?.listXlmsMyScheduleEvent?.items?.map((event, idx) => {
        scheduleData.push({
          calendarId: crypto.randomUUID() + "$" + JSON.parse(event?.EventDetails)?.start + "$" + JSON.parse(event?.EventDetails)?.end + "$" + event?.CourseID + "$" + event?.BatchID,
          category: "time",
          isVisible: true,
          title: JSON.parse(event?.EventDetails).title,
          id: JSON.parse(event?.EventDetails)?.eventType == undefined ? JSON.parse(event?.EventDetails)?.id + "#My Event" : JSON.parse(event?.EventDetails)?.id + "#" + JSON.parse(event?.EventDetails)?.eventType,
          body: JSON.parse(event?.EventDetails).body,
          start: JSON.parse(event?.EventDetails).start,
          end: JSON.parse(event?.EventDetails).end,
          isReadOnly: true,
          state: JSON.parse(event?.EventDetails).StartDate,
          backgroundColor: "violet",
          raw: JSON.parse(event?.EventDetails)?.EndDate,
          eventType: JSON.parse(event?.EventDetails)?.eventType
        })
      })

      setPropsList({
        RootMode: Root, ActivityData: Activitylist, CourseData: Courselist, BatchData: Batchlist, TenantName: TenantName, TenantID: TenantID, eventData: scheduleData,CoursesList:allCoursesList.res?.listXlmsCourseManagementInfo?.items
      })
    }
    CalendarData()

    return (() => {
      setPropsList((data) => {
        return data;
      })
    })

  }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const GridDataBind = useCallback((PropsList) => {
    function getIsoTimeFormat(originalTimestamp) {
      if (originalTimestamp) {
        const originalDate = new Date(originalTimestamp);
        originalDate.setDate(originalDate.getDate() + 1);
        const adjustedTimestamp = originalDate.toISOString()
        return adjustedTimestamp?.slice(0, 11) + "00:00"
      }
    }
    setTimeout(() => {
      const ActivityArr = [], CourseArr = [], EventsArr = [], RowGrid = [];
      if (PropsList?.ActivityData) {
        PropsList?.ActivityData?.map((getItem) => {
          (getItem?.StartDate != null && getItem.StartDate != "NaN-NaN-NaNTNaN:NaN" && getItem?.StartDate != "") ?
            new Date(getItem.StartDate)?.toDateString() != new Date(getItem.EndDate)?.toDateString() && (getItem.EndDate && getItem.EndDate != "") ?
              ActivityArr.push(
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                  category: "time",
                  isVisible: true,
                  title: getItem.ActivityName,
                  id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                  body: getItem.ActivityDescription,
                  start: getItem.StartDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: "",
                  isReadOnly: true,
                  backgroundColor: "aqua",
                },
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                  category: "time",
                  isVisible: true,
                  title: getItem.ActivityName,
                  id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                  body: getItem.ActivityDescription,
                  start: !getItem.EndDate?.includes("T00:00:00.000Z") ? getItem.EndDate?.toString() : getItem.EndDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: "",
                  isReadOnly: true,
                  backgroundColor: "aqua",
                })
              :
              ActivityArr.push(
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                  category: "time",
                  isVisible: true,
                  title: getItem.ActivityName,
                  id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                  body: getItem.ActivityDescription,
                  start: getItem.StartDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: "",
                  isReadOnly: true,
                  backgroundColor: "aqua",
                }
              )

            : "";
        });
      }

      function getCourseDescription(courseID) {
        let description;
        PropsList.CoursesList?.map((item) => {
          if (item?.CourseID == courseID) {
            description = item.CourseDescription;
          }
        })
        return description
      }
      if (PropsList?.CourseData) {
        PropsList?.CourseData?.map((getItem) => {
          (getItem?.DateTime != null && getItem?.DateTime != "NaN-NaN-NaNTNaN:NaN" && getItem?.DateTime != "") ?
            new Date(getItem.DateTime)?.toDateString() != new Date(getItem.EndDateTime)?.toDateString() && (getItem.EndDateTime && getItem.EndDateTime != "") ?
              CourseArr.push(
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getItem.EndDateTime,
                  category: "time",
                  isVisible: true,
                  title: getItem.CourseName,
                  id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
                  body: getCourseDescription(getItem.CourseID),
                  start: new Date(getItem.DateTime)?.toISOString()?.split("Z")?.[0]?.slice(0, 16)?.replace("18:30", "00:00"),
                  end: "",
                  isReadOnly: true,
                  state: getItem.EndDateTime,
                  backgroundColor: "lime",
                },
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getItem.EndDateTime,
                  category: "time",
                  isVisible: true,
                  title: getItem.CourseName,
                  id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
                  body: getCourseDescription(getItem.CourseID),
                  start: getIsoTimeFormat(getItem.EndDateTime),
                  end: "",
                  isReadOnly: true,
                  state: getItem.EndDateTime,
                  backgroundColor: "lime",
                }) :
              CourseArr.push({
                calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getItem.EndDateTime,
                category: "time",
                isVisible: true,
                title: getItem.CourseName,
                id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
                body: getCourseDescription(getItem.CourseID),
                start: new Date(getItem.DateTime)?.toISOString()?.split("Z")?.[0]?.slice(0, 16)?.replace("18:30", "00:00"),
                end: null,
                isReadOnly: true,
                state: getItem.EndDateTime,
                backgroundColor: "lime",
              })
            : "";
        });
      }
      PropsList.eventData?.map((getItem) => {

        new Date(getItem.start)?.toDateString() != new Date(getItem.end)?.toDateString() && (getItem.end && getItem.end != "") ?
          EventsArr.push(
            {
              calendarId: getItem?.calendarId,
              category: "time",
              isVisible: true,
              title: getItem.title,
              id: getItem?.id,
              body: getItem.body,
              start: getItem.start?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
              end: "",
              isReadOnly: true,
              state: getItem.StartDate,
              backgroundColor: "violet",
              raw: getItem?.EndDate
            }
            , {
              calendarId: getItem?.calendarId,
              category: "time",
              isVisible: true,
              title: getItem.title,
              id: getItem?.id,
              body: getItem.body,
              start: getItem.end?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
              end: "",
              isReadOnly: true,
              state: getItem.StartDate,
              backgroundColor: "violet",
              raw: getItem?.EndDate
            }
          ) : EventsArr.push({
            calendarId: getItem?.calendarId,
            category: "time",
            isVisible: true,
            title: getItem.title,
            id: getItem?.id,
            body: getItem.body,
            start: getItem.start?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
            end: null,
            isReadOnly: true,
            state: getItem.StartDate,
            backgroundColor: "violet",
            raw: getItem?.EndDate
          }

          )
      })
      if ((watch("ddlFilter") == "AllEvents")) {
        RowGrid = ActivityArr.concat(CourseArr, EventsArr)
      }
      else if ((watch("ddlFilter") == "MyEvents")) {
        RowGrid = EventsArr
      }
      else if ((watch("ddlFilter") == "LearnignEvents")) {
        RowGrid = ActivityArr.concat(CourseArr)
      }
      setRowGridData({ RowGrid });
      setisLoading(false)
    }, 1000);
  }, [watch]);

  useEffect(() => {
    GridDataBind(PropsList);
  }, [GridDataBind, PropsList]);

  const getEvents = useMemo(() => {
    return [
      { value: "AllEvents", text: "All Events" },
      { value: "MyEvents", text: "My Event" },
      { value: "LearnignEvents", text: "Learning Events" },
      { value: "OrganizationEvents", text: "Organization Events" },
    ]
  }, []);

  const cal = useRef(null);
  const month = useRef(null);

  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];


  const FilterEvents = useCallback((PropsList) => {
    function getIsoTimeFormat(originalTimestamp) {
      if (originalTimestamp) {
        const originalDate = new Date(originalTimestamp);
        originalDate.setDate(originalDate.getDate() + 1);
        const adjustedTimestamp = originalDate.toISOString()
        return adjustedTimestamp?.slice(0, 11) + "00:00"
      }
    }
    const ActivityArr = [], CourseArr = [], EventsArr = [], RowGrid = [];
    if (PropsList?.ActivityData) {
      PropsList?.ActivityData?.map((getItem) => {
        (getItem.StartDate != null && getItem.StartDate != "NaN-NaN-NaNTNaN:NaN") ?
          new Date(getItem.StartDate)?.toDateString() != new Date(getItem.EndDate)?.toDateString() && (getItem.EndDate && getItem.EndDate != "") ?
            ActivityArr.push(
              {
                calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                category: "time",
                isVisible: true,
                title: getItem.ActivityName,
                id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                body: getItem.ActivityDescription,
                start: getItem.StartDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                end: "",
                isReadOnly: true,
                backgroundColor: "aqua",
              },
              {
                calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                category: "time",
                isVisible: true,
                title: getItem.ActivityName,
                id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                body: getItem.ActivityDescription,
                start: !getItem.EndDate?.includes("T00:00:00.000Z") ? getItem.EndDate?.toString() : getItem.EndDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                end: "",
                isReadOnly: true,
                backgroundColor: "aqua",
              }) : ActivityArr.push(
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                  category: "time",
                  isVisible: true,
                  title: getItem.ActivityName,
                  id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                  body: getItem.ActivityDescription,
                  start: getItem.StartDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: "",
                  isReadOnly: true,
                  backgroundColor: "aqua",
                }
              )

          : "";
      });
    }

    function getCourseDescription(courseID) {
      let description;
      PropsList.CoursesList?.map((item) => {
        if (item?.CourseID == courseID) {
          description = item.CourseDescription;
        }
      })
      return description
    }
    if (PropsList?.CourseData) {
      PropsList?.CourseData?.map((getItem) => {
        (getItem?.DateTime != null && getItem?.DateTime != "NaN-NaN-NaNTNaN:NaN" && getItem?.DateTime != "") ?
          new Date(getItem.DateTime)?.toDateString() != new Date(getItem.EndDateTime)?.toDateString() && (getItem.EndDateTime && getItem.EndDateTime != "") ?
            CourseArr.push({
              calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getItem.EndDateTime,
              category: "time",
              isVisible: true,
              title: getItem.CourseName,
              id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
              body: getCourseDescription(getItem.CourseID),
              start: new Date(getItem.DateTime)?.toISOString()?.split("Z")?.[0]?.slice(0, 16)?.replace("18:30", "00:00"),
              end: "",
              isReadOnly: true,
              state: getItem.EndDateTime,
              backgroundColor: "lime",
            },
              {
                calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getItem.EndDateTime,
                category: "time",
                isVisible: true,
                title: getItem.CourseName,
                id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
                body: getCourseDescription(getItem.CourseID),
                start: getIsoTimeFormat(getItem.EndDateTime),
                end: "",
                isReadOnly: true,
                state: getItem.EndDateTime,
                backgroundColor: "lime",
              }) :
            CourseArr.push({
              calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getItem.EndDateTime,
              category: "time",
              isVisible: true,
              title: getItem.CourseName,
              id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
              body: getCourseDescription(getItem.CourseID),
              start: new Date(getItem.DateTime)?.toISOString()?.split("Z")?.[0]?.slice(0, 16)?.replace("18:30", "00:00"),
              end: null,
              isReadOnly: true,
              state: getItem.EndDateTime,
              backgroundColor: "lime",
            })
          : "";
      });
    }

    PropsList.eventData?.map((getItem) => {

      new Date(getItem.start)?.toDateString() != new Date(getItem.end)?.toDateString() && (getItem.end && getItem.end != "") ?
        EventsArr.push(
          {
            calendarId: getItem?.calendarId,
            category: "time",
            isVisible: true,
            title: getItem.title,
            id: getItem?.id,
            body: getItem.body,
            start: getItem.start?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
            end: "",
            isReadOnly: true,
            state: getItem.StartDate,
            backgroundColor: "violet",
            raw: getItem?.EndDate
          }
          , {
            calendarId: getItem?.calendarId,
            category: "time",
            isVisible: true,
            title: getItem.title,
            id: getItem?.id,
            body: getItem.body,
            start: getItem.end?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
            end: "",
            isReadOnly: true,
            state: getItem.StartDate,
            backgroundColor: "violet",
            raw: getItem?.EndDate
          }
        ) : EventsArr.push({
          calendarId: getItem?.calendarId,
          category: "time",
          isVisible: true,
          title: getItem.title,
          id: getItem?.id,
          body: getItem.body,
          start: getItem.start?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
          end: null,
          isReadOnly: true,
          state: getItem.StartDate,
          backgroundColor: "violet",
          raw: getItem?.EndDate
        }

        )
    })
    if ((watch("ddlFilter") == "AllEvents")) {
      RowGrid = ActivityArr.concat(CourseArr, EventsArr)
    }
    else if ((watch("ddlFilter") == "MyEvents")) {
      RowGrid = EventsArr
    }
    else if ((watch("ddlFilter") == "LearnignEvents")) {
      RowGrid = ActivityArr.concat(CourseArr)
    }
    setRowGridData({ RowGrid });
  }, [watch]);

  const getCalInstance = useCallback(() => cal.current?.getInstance?.(), []);

  const getMonth = () => {
    month.current.innerHTML =
      monthNames[getCalInstance()?.getDate().getMonth()];
  };

  var templates = {
    popupIsAllDay: function () {
      return "All Day";
    },
    popupStateFree: function () {
      return "Free";
    },
    popupStateBusy: function () {
      return "Busy";
    },
    titlePlaceholder: function () {
      return "Subject";
    },
    locationPlaceholder: function () {
      return "Location";
    },
    startDatePlaceholder: function () {
      return "Start date";
    },
    endDatePlaceholder: function () {
      return "End date";
    },
    popupSave: function () {
      return "Save";
    },
    popupUpdate: function () {
      return "Update";
    },
    popupDetailDate: function (isAllDay, start, end) {
      var isSameDate = moment(start).isSame(end);
      var endFormat = (isSameDate ? "" : "YYYY.MM.DD ") + "hh:mm a";

      if (isAllDay) {
        return (
          moment(start).format("YYYY.MM.DD") +
          (isSameDate ? "" : " - " + moment(end).format("YYYY.MM.DD"))
        );
      }

      return (
        moment(start).format("YYYY.MM.DD hh:mm a") +
        " - " +
        moment(end).format(endFormat)
      );
    },
    popupDetailLocation: function (schedule) {
      return "Location : " + schedule.location;
    },
    popupDetailUser: function (schedule) {
      return "User : " + (schedule.attendees || []).join(", ");
    },
    popupDetailState: function (schedule) {
      return "State : " + schedule.state || "Busy";
    },
    popupDetailRepeat: function (schedule) {
      return "Repeat : " + schedule.recurrenceRule;
    },
    popupDetailBody: function (schedule) {
      return "Body : " + schedule.body;
    },
    popupEdit: function () {

      return "Edit";
    },
    popupDelete: function () {
      return "Delete";
    },
  };

  const onBeforeCreateEvent = () => {

    getCalInstance().createEvents(PropsList?.eventResponse);
    setOpen(false);
  };

  const onAfterRenderEvent = (event) => {
  };

  const [viewEvent, setEvent] = useState("month");

  getCalInstance()?.on("myCustomEvent", (eventData) => {
    onBeforeCreateEvent(eventData);
  });

  const onClickDayName = (res) => {
  };

  getCalInstance()?.on({
    clickSchedule: function (e) {
    },
    beforeCreateSchedule: function (e) {
    },
    beforeUpdateSchedule: function (e) {
      e.schedule.start = e.start;
      e.schedule.end = e.end;
      cal.updateSchedule(e.schedule.id, e.schedule.calendarId, e.schedule);
    },
  });

  const [data, setData] = useState({ id: "", body: "", title: "", start: "", calendarId: "", end: "", state: "" })

  const getCoursedata = useCallback((e) => {
    const courseData = PropsList.CourseData?.filter((item) => {
      return e.event.id?.split("#")?.[0] == item?.CourseID
    })
    return courseData?.[0];
  }, [PropsList.CourseData])

  const onClickSchedule = useCallback((e) => {

    if (e.event.id?.includes("Course")) {
      const getCourseDetails = getCoursedata(e);
      if (getCourseDetails) {
        setData({
          ...data,
          id: e.event.id,
          type: "Course",
          body: getCourseDetails?.CourseDescription,
          title: getCourseDetails?.CourseName,
          start: e.event.calendarId?.split("$")?.[1],
          end: e.event.calendarId?.split("$")?.[2],
          calendarId: e.event.calendarId
        })
      }
    }
    if (e.event.id?.split("#")?.[2] == "ActStart") {
      setData({
        ...data,
        id: e.event.id,
        type: "Activity",
        body: e.event.body,
        title: e.event.title,
        start: e.event.calendarId?.split("$")?.[1],
        end: e.event.calendarId?.split("$")?.[2],
        calendarId: e.event.calendarId
      })
    }
    else {
      setData({
        ...data,
        id: e.event.id,
        type: e.event.id?.includes("Course") ? "Course" : e.event.id?.split("#")?.[2],
        body: e.event.body,
        title: e.event.title,
        start: e.event.calendarId?.split("$")?.[1],
        end: e.event.calendarId?.split("$")?.[2],
        calendarId: e.event.calendarId
      })
    }
    setOpen((open) => {
      return open + 1;
    });
  }, [data, getCoursedata]);

  useEffect(() => {
    if (open) {
      if (data?.id?.includes("EVENT#")) {
        description.current.innerHTML = `<div class='text-sm font-semibold w-full break-words'>Description:</div><div class="text-xs ">${data.body}</div>`;
      } else {
        if (description.current != undefined && data?.body != "" && data?.body != undefined) {
          description.current.innerHTML = "<div class='text-sm font-semibold w-full break-words'>Description:</div>" + data?.body;
        } else if (data?.body == "" && description.current != undefined) {
          description.current.innerHTML = "";
        }
      }
    }
  }, [data, open])
  // Bread Crumbs
  let PageRoutes = [];
  if (PropsList?.RootMode == "DashEvent") {
    PageRoutes = [{ path: "/Home/UserDashboard", breadcrumb: "User Dashboard" }, { path: "", breadcrumb: "My Schedule" }];
  } else {
    PageRoutes = [{ path: "", breadcrumb: "My Schedule" }];
  }
  const onBeforeDeleteSchedule = useCallback((res) => {
    const { id, calendarId } = res.schedule;

    cal.current.calendarInst.deleteSchedule(id, calendarId);
  }, []);

  const [calendarKey, setCalendarKey] = useState(0);

  const handleReload = () => {
    setCalendarKey((prevKey) => prevKey + 1);
  };

  const deleteEvent = useCallback(async () => {
    const eventInfo = "";
    const userSub = props.user.attributes["sub"];
    eventInfo = ({ PK: "TENANT#" + props.TenantInfo.TenantID, SK: "USERSUB#" + userSub + "#EVENT#" + data?.id?.split("#")?.[1] });

    const variables = {
      input: eventInfo
    };
    const finalResult = await AppsyncDBconnection(deleteXlmsMyScheduleEvent, variables, props.user.signInUserSession.accessToken.jwtToken);
    setOpen(false);
    setValue("ddlFilter", "AllEvents");
    location.reload();
  }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, props.TenantInfo.TenantID, data?.id, setValue])

  const description = useRef(null);
  const EventDescription = useCallback(() => {
    return (
      <>
        {<div>
          <div className="!w-full break-words" ref={description}>
          </div>
        </div>}
      </>
    );
  }, []);
  const GetComponent = useCallback((PopupName) => {
    let ComponentData = {
      Upload:
        <div className="flex gap-2">
          <div className="">
            <div className="flex gap-2 ">
              <NVLlabel text={`Type :`} className="font-semibold" />
              <NVLlabel text={`${data?.type}`} />
            </div>
            <div className="flex gap-3">
              <NVLlabel text={`Date:`} className="font-semibold" />
              <NVLlabel text={`${data?.start?.includes("T00:00:00.000Z") ? new Date(data?.start)?.toLocaleString('en-GB', {
                weekday: "short",
                month: "short",
                day: "numeric",
                year: "numeric",
              }) + " 00:00" : new Date(data?.start)?.toLocaleString('en-GB', {
                weekday: "short",
                month: "short",
                day: "numeric",
                year: "numeric",
                hour: "numeric",
                minute: "numeric",
              })}`} />
              {(data?.end && data?.end != "null" && data?.end != "") && (<>
                <NVLlabel text={`-`} className="font-semibold" />
                <NVLlabel text={`${data?.end?.includes("T00:00:00.000Z") ? new Date(data?.start)?.toLocaleString('en-GB', {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                }) + " 00:00" : new Date(data?.end)?.toLocaleString('en-GB', {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                  hour: "numeric",
                  minute: "numeric",
                })}`} />
              </>)}
            </div>
            <EventDescription content={data?.body} />
            {data?.type == "My Event" ?
              <div className="flex gap-1 pt-2 !translate-x-64">
                <NVLButton
                  id="btnDelete"
                  text={"Delete"}
                  type="button"
                  className="w-24 nvl-button bg-orange-500 text-white"
                  onClick={() => deleteEvent()}
                ></NVLButton>
                <NVLButton
                  id="btnUpdate"
                  text={"Edit"}
                  type="button"
                  className="w-24 nvl-button bg-orange-500 text-white"
                  onClick={() => router.push(`/MySchedule/AddEventInfo?Mode=Edit&EventID=${data?.id?.split("#")?.[1]}`)}
                >
                </NVLButton>
              </div> : data?.type != "Group" && <NVLButton
                id="btnlink"
                text={`Go to ${data?.type}`}
                type="button"
                className="w-36 nvl-button bg-orange-500 text-white !translate-x-80"
                onClick={() => (data?.id?.includes("#Course")) ?
                  data?.id?.split("#")?.[0] == "EVENT" ? router.push(`/MyLearning/CourseConsume?CourseID=${data?.calendarId?.split("$")?.[3]}&BatchId=${data?.calendarId?.split("$")?.[4]} `) :
                    router.push(`/MyLearning/CourseConsume?CourseID=${data?.id?.split("#Course#")?.[0]}&BatchId=${data?.id?.split("#Course#")?.[1]} `) :
                  router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${data?.id?.split("#")?.[0]}&ActivityType=${data?.id?.split("#")?.[1]}`)}>
              </NVLButton>}
          </div>
        </div>
    };
    return ComponentData[PopupName];
  },
    [data, deleteEvent, router]
  );

  return (
    <>
      <Container title="EventCalendar" loader={PropsList == undefined} PageRoutes={PageRoutes}>
        <NVLPageModalPopup
          ModalType="Page"
          PageComponent={GetComponent("Upload")}
          open={open}
          setOpen={setOpen}
          user={props?.user}
          CustomWidth={"md:w-[500px]"}
          CustomHeader={data?.title}
        />

        <div className="p-4 bg-gray-200">
          <div className="flex justify-between my-2 text-xs">
            <div className="flex gap-4">
              <button onClick={() => {
                setEvent("day");
                GridDataBind(PropsList);
              }} type="button" className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3">
                <div className="flex flex-row align-middle">
                  <span className="mr-2">Day</span>
                </div>
              </button>
              <button onClick={() => {
                setEvent("week");
                GridDataBind(PropsList);
              }} type="button" className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3" >
                <div className="flex flex-row align-middle">
                  <span className="mr-2">Week</span>
                </div>
              </button>
              <button onClick={() => setEvent("month")} type="button" className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3" >
                <div className="flex flex-row align-middle">
                  <span className="mr-2">Month</span>
                </div>
              </button>
            </div>
            <span ref={month} className="render-range font-semibold shadow-xl  text-gray-600 rounded p-2 border " >
              {new Date().toLocaleString('default', { month: 'short' })}
            </span>
            <div className="flex gap-4">
              <div className="pt-2">
                <NVLlabel text="Filter" /></div>
              <NVLSelectField id="ddlFilter" options={getEvents} labelClassName="font-semibold text-gray-500" disabled={false} errors={errors} title="Select Company" register={register} className="w-44"  ></NVLSelectField>
              <button
                onClick={() => {
                  getCalInstance().today();
                  getMonth();
                }}
                type="button"
                className="bg-gray-600 text-white py-2 rounded border-l border-gray-200 hover:bg-red-700 hover:text-white px-3"
              >
                <div className="flex flex-row align-middle">
                  <span className="mr-2">Today</span>
                </div>
              </button>
              <button
                onClick={() => {
                  getCalInstance().prev();
                  getMonth();
                }}
                type="button"
                className="bg-gray-600 text-white rounded-l-md border-r border-gray-100 py-2 hover:bg-red-700 hover:text-white px-3"
              >
                <div className="flex flex-row align-middle gap-2">
                  <i className="fa fa-solid fa-arrow-left-long fa-lg cente mt-2.5"></i>
                  <p className="">Prev</p>
                </div>
              </button>
              <button
                onClick={() => {
                  getCalInstance().next();
                  getMonth();
                }}
                type="button"
                className="bg-gray-600 text-white rounded-r-md py-2 border-l border-gray-200 hover:bg-red-700 hover:text-white px-3"
              >
                <div className="flex flex-row align-middle gap">
                  <span className="mr-2">Next</span>
                  <i className="fa fa-solid fa-arrow-right-long fa-lg cente mt-2.5"></i>
                </div>
              </button>
              <button
                onClick={() => router.push("/MySchedule/AddEventInfo?Mode=Create")}
                type="button"
                className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3"
              >
                <div className="flex flex-row align-middle gap-2">
                  <i className="fa-solid fa-plus mt-1"></i>Add Event
                </div>
              </button>
            </div>
          </div>
          <div className="shadow-xl relative ">
            {isLoading ?
              <NVLLoadingIndicator IsLoad={true} AlignLoader={"center"} />
              : <CalendarComponent
                key={calendarKey}
                height="500px"
                ref={cal}
                template={{
                  milestone(event) {
                    return `<span style="color: #fff; background-color: ${event.backgroundColor};">${event.title}</span>`;
                  },
                  allday(event) {
                    return `[All day] ${event.title}`;
                  },
                }}
                view={viewEvent}
                useFormPopup={false}
                useDetailPopup={false}
                useCreationPopup={false}
                events={RowGridData.RowGrid}
                usageStatistics={false}
                taskView={FaTemperatureHigh}
                templates={templates}
                onClickDayname={onClickDayName}
                beforeUpdateEvent={(event) => {
                }}
                onAfterRenderEvent={onAfterRenderEvent}
                onClick={onBeforeCreateEvent}
                onClickEvent={onClickSchedule}
                onClickSchedule={onClickSchedule}
                onBeforeDeleteSchedule={onBeforeDeleteSchedule}
              />}
          </div>
        </div>
      </Container>
    </>
  );
}