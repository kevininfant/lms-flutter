import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsMyScheduleEvent, updateXlmsMyScheduleEvent } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { getXlmsMyScheduleEvent, listXlmsCourseManagementInfo, listXlmsUserGroupInfos } from "src/graphql/queries";
import * as Yup from "yup";
function AddEventInfo(props) {
  let userData;
  if (props?.isComponent) userData = props?.props;
  else userData = props;

  const [propsList, setPropsList] = useState();
  const [getCourses, setgetCourses] = useState([]);
  const groupAndCourseData = useRef()
  let stDate = useRef();
  const router = useRouter();
  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      router.push("/UserManagement/UserList");
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);

  const setCourseOrGroupList = useCallback(async (Type, propsList, userData, setValue, Mode) => {
    if (Type == "Group") {
      let listGroup = [{ value: "", text: "Select group" }];
      if (groupAndCourseData?.current && groupAndCourseData?.current?.GroupData?.length > 0) {
        groupAndCourseData?.current?.GroupData?.map((item) => {
          listGroup.push({ value: item?.GroupID, text: item?.GroupName })
        })
      }
      setgetCourses(listGroup);
    } else {

      let listCourse = [{ value: "", text: "Select course" }];
      if (groupAndCourseData?.current && groupAndCourseData?.current?.CourseData?.length > 0) {
        groupAndCourseData?.current?.CourseData?.map((item) => {
          listCourse.push({ value: item?.CourseID, text: item?.CourseName })
        })
      }
      setgetCourses(listCourse);
    }

    if (Mode == "Edit" && userData?.TenantInfo?.UserGroup == "CompanyAdmin") {
      setValue("ddlTypeList", propsList?.Eventinfo?.eventType == "Group" ? propsList?.EventDetail?.GroupID : propsList?.EventDetail?.CourseID);
    }
  }, [])

  const GetDateComponent = useCallback(({ StartDate, EndDate, isMandatory, setValue, watch, errors, register }) => {
    let today = new Date();
    let dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T00:00:00";

    if (!watch("chkEndDateEnable")) {

      if (!(watch("txtEnddate") == undefined) || watch("txtEnddate") == "") {
        setValue("txtEnddate", undefined, { shouldValidate: true })
      }
    }

    return (<div className="grid">
      {StartDate == undefined && (
        <div className="flex">
          <div className="pb-4">
            <NVLlabel text="Start Date" className="nvl-Def-Label pt-2 pb-2 "><span className="text-red-500 text-lg">*</span></NVLlabel>
            <NVLTextbox id="txtstdate" title="Start Date" type="datetime-local"
              tabIndex={!watch("chkStartDateEnable") ? "1" : "0"}
              className={`nvl-Def-Input nvl-mandatory`} min={dateTime} setValue={setValue} errors={errors} register={register}></NVLTextbox>
          </div>
        </div>
      )}
      {EndDate == undefined && (
        <div className="flex">
          <div className="">
            <NVLlabel text="End Date"></NVLlabel>
            <NVLTextbox title="End Date" id="txtEnddate" type="datetime-local" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"} className={!watch("chkEndDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkEndDateEnable")} errors={errors} register={register} setValue={setValue}></NVLTextbox>
          </div>
          <div className="translate-y-8 translate-x-8">
            <NVLCheckbox
              text="Enable" id="chkEndDateEnable" errors={errors} register={register}></NVLCheckbox>
          </div>
        </div>
      )}
    </div>)
  },
    [],
  )
  useEffect(() => {
    async function EventData() {
      setValue("IsFetchingData", true);
      let mode = decodeURIComponent(router.query["Mode"]);
      let eventID = decodeURIComponent(router.query["EventID"]);
      let TenantID = userData.user.attributes["custom:tenantid"];
      let UserSub = userData.user.attributes["sub"];

      const Eventdetail = await AppsyncDBconnection(
        getXlmsMyScheduleEvent,
        {
          PK: "TENANT#" + TenantID,
          SK: "USERSUB#" + UserSub + "#EVENT#" + eventID,
        }, userData.user.signInUserSession.accessToken.jwtToken)

      if (userData?.TenantInfo?.UserGroup == "CompanyAdmin") {
        // setValue("ddlFilterEventtype", "Group")
        const eventGroupData = await AppsyncDBconnection(
          listXlmsUserGroupInfos,
          {
            PK: "TENANT#" + userData.user.attributes["custom:tenantid"],
            SK: "GROUPINFO#",
          }, userData?.user?.signInUserSession?.accessToken?.jwtToken)
        let tempGroup = eventGroupData?.res?.listXlmsUserGroupInfos?.items;

        const Courseresponse = await AppsyncDBconnection(
          listXlmsCourseManagementInfo,
          {
            PK: "TENANT#" + userData?.user?.attributes["custom:tenantid"],
            SK: "COURSEINFO#",
          }, userData?.user?.signInUserSession?.accessToken?.jwtToken
        );
        let tempCourse = Courseresponse?.res?.listXlmsCourseManagementInfo?.items;
        let groupInfo = [];
        tempGroup && tempGroup?.map((e) => {
          if (e?.TotalCount != 0 && e?.IsSuspend == false) {

            groupInfo?.push(e)
          }
        })
        groupAndCourseData.current = { GroupData: groupInfo, CourseData: tempCourse }
        setValue("ddlFilterEventtype", "MyEvent")
      }

      setPropsList({
        Mode: mode,
        EventDetail: Eventdetail?.res?.getXlmsMyScheduleEvent,
        Eventinfo: Eventdetail?.res?.getXlmsMyScheduleEvent?.EventDetails && JSON.parse(Eventdetail?.res?.getXlmsMyScheduleEvent?.EventDetails),
        TenantID: TenantID
      })
      setValue("IsFetchingData", false);
    }
    EventData()

    return (() => {
      setPropsList({})
    })

  }, [userData.user.attributes, userData.user.signInUserSession.accessToken.jwtToken, router.query, userData?.TenantInfo?.UserGroup, setValue])
  const filterEventType = useRef()

  const validationSchema = Yup.object().shape({
    txtEventTitle: Yup.string().required("Event title is required").max(150, "Maximum 150 characters reached")
      .test((e, { createError }) => {
        if (e != "" && e != undefined) {
          if (e != "" && e.length < 2) {
            return createError({ message: "Event name should not be less than 2 characters" })
          }
          const rejax = Regex("AlphanumWithAllSpecialChar")
          if (!rejax.test(e)) {
            return createError({ message: "Event name is invalid" })
          }
        }
        return true
      }).nullable(),

    txtEventDescription: Yup.string().max(500, "Maximum 500 characters Reached"),
    chkEndDateEnable: Yup.bool().nullable(true).test("e", "", e => {
      if (!e) {
        clearErrors(["txtEnddate"])
      }
      return true;
    }),
    txtstdate: Yup.string()
      .nullable(true)
      .required("Start Date is Required").test("Check", "Event can be created only for present and future date", (e, { createError }) => {
        if (e == "" || e == undefined || e == null) {
          return true;
        }
        else {
          if (new Date(e) > new Date(new Date().setMinutes(new Date().getMinutes() - 1))) {
            if ((stDate.current != e) && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
              stDate.current = e;
              setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
            } else if ((new Date(e) <= new Date(watch("txtEnddate")))) {
              clearErrors(["txtEnddate"])
            }
            return true;
          }
          else {
            return false
          }
        }
      }).nullable(true),

    txtEnddate: Yup.string()
      .when("chkEndDateEnable", {
        is: true,
        then: Yup.string().required("End Date is Required").typeError("End Date is invalid Value").nullable().test("error", "End Date must be greater than or equal to the start date", (e) => {

          if (new Date(e) > new Date(watch("txtstdate"))) {
            return true;
          }
          else {
            return false
          }
        }),
      })
      .nullable(true),

    ddlFilterEventtype: userData?.TenantInfo?.UserGroup == "CompanyAdmin" && Yup.string().required("Choose a activity")
      .test((e) => {
        if (filterEventType?.current != e) {
          filterEventType.current = e
          setCourseOrGroupList(e, propsList, userData, setValue, router.query["Mode"])
          clearErrors(["ddlTypeList"])
        }
        return true;
      }).nullable(true),
    ddlTypeList: Yup.string()
      .when("ddlFilterEventtype", {
        is: (e) => e == "Group" || e == "Course",
        then: Yup.string().required(document.querySelector("#ddlFilterEventtype")?.value + " is Required").nullable(),
        otherwise: Yup.string().nullable(true)
      })
      .nullable(true),
  })
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, setError, formState, watch, clearErrors } = useForm(formOptions);
  const { errors } = formState;
  const finalResponse = (FinalStatus) => {
 
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
      });
      ModalOpen();
      return;
    }
    setModalValues({
      ModalInfo: "Success",
      ModalTopMessage: "Success",
      ModalBottomMessage: "Details have been saved successfully.",
      ModalOnClickEvent: () => {
        if (userData?.TenantInfo?.UserGroup == "CompanyAdmin") {
          router.push("/Home/AdminViewEventCalendar");
        } else {
          router.push("/MySchedule/EventCalendar");
        }
      },
    });
    ModalOpen();

  };

  const PageRoutes = useMemo(() => {
    return [
      { path: userData?.TenantInfo?.UserGroup == "CompanyAdmin" ? "/Home/AdminViewEventCalendar" : "/MySchedule/EventCalendar", breadcrumb: "My Schedule" },
      { path: "", breadcrumb: (router.query["Mode"] != "Edit") ? "Add Event" : "Edit Event" },
    ];
  }, [router.query, userData?.TenantInfo?.UserGroup]);

  useEffect(() => {
    setValue("txtEvent", "User")
  }, [setValue])
  useEffect(() => {
    if (router.query["Mode"] == "Edit") {
      setValue("txtEventTitle", propsList?.Eventinfo?.title);
      setValue("txtEventDescription", propsList?.Eventinfo?.body);
      userData?.TenantInfo?.UserGroup == "CompanyAdmin" && setValue("ddlFilterEventtype", propsList?.Eventinfo?.eventType, { shouldValidate: true });
      setValue("txtstdate", propsList?.Eventinfo?.start);
      setValue("chkEndDateEnable", propsList?.EventDetail?.IsEndDateEnable);
      setValue("txtEnddate", propsList?.Eventinfo?.end);
    }
  }, [setValue, propsList?.Eventinfo, propsList?.EventDetail, router.query, propsList, userData?.TenantInfo?.UserGroup]);

  const submitHandler = async (data) => {

    setValue("submit", true);
    const eventid = Math.random().toString(25).substring(2, 12)
    const jsonData = {
      id: (propsList?.Mode == "Edit") ? "EVENT#" + propsList?.EventDetail?.EventID : "EVENT#" + eventid,
      title: data.txtEventTitle?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
      body: data.txtEventDescription,
      start: data.txtstdate,
      end: (data.txtEnddate == undefined || data.txtEnddate == null) ? data?.txtstdate?.split("T")?.[0] + "T23:59" : data.txtEnddate,
      category: data?.ddlFilterEventtype,
      eventType: data?.ddlFilterEventtype
    }
    let pk = "TENANT#" + userData?.TenantInfo?.TenantID;
    let sk = "USERSUB#" + Auth?.user?.attributes["sub"] + "#EVENT#" + eventid;
    let query = (propsList?.Mode == "Edit") ? updateXlmsMyScheduleEvent : createXlmsMyScheduleEvent;
    let eventVariables = {
      input: {
        PK: pk,
        SK: (propsList?.Mode == "Edit") ? propsList?.EventDetail?.SK : sk,
        EventID: (propsList?.Mode == "Edit") ? propsList?.EventDetail?.EventID : eventid,
        EventDetails: JSON.stringify(jsonData),
        IsEndDateEnable: true,
        CreatedDate: (propsList?.Mode == "Edit") ? propsList?.EventDetail?.CreatedDate : new Date(),
        CreatedBy: userData?.user?.username,
        ModifiedBy: userData?.user?.username,
        ModifiedDate: new Date(),
        CourseID: data?.ddlFilterEventtype == "Course" ? data?.ddlTypeList : "",
        GroupID: data?.ddlFilterEventtype == "Group" ? data?.ddlTypeList : "",
        IsDeleted: false
      },
    };
    let variables = eventVariables;
    let finalStatus = (await AppsyncDBconnection(query, variables, userData?.user?.signInUserSession?.accessToken?.jwtToken));

    if (userData?.TenantInfo?.UserGroup == "CompanyAdmin" && data?.ddlFilterEventtype != "MyEvent") {
      let fetchURL = process.env.ADD_EVENT_BASED_ON_GROUP_COURSE_API, stateMachineArn = process.env.STEP_FUNCTION_ARN_ADD_EVENT;
      let eventInfo = {
        EventID: (propsList?.Mode == "Edit") ? propsList?.EventDetail?.EventID : eventid,
        CreatedBy: userData?.user?.username,
        ModifiedBy: userData?.user?.username,
        ModifiedDate: new Date(),
        CreatedDate: (propsList?.Mode == "Edit") ? propsList?.EventDetail?.CreatedDate : new Date(),
        IsEndDateEnable: true,
        Title: data.txtEventTitle?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        Start: data.txtstdate,
        EventType: data?.ddlFilterEventtype,
        End: (data.txtEnddate == undefined || data.txtEnddate == null) ? data?.txtstdate?.split("T")?.[0] + "T23:59" : data.txtEnddate,
        Category: data?.ddlFilterEventtype,
        Body: data.txtEventDescription ? data.txtEventDescription : "",
        CourseID: data?.ddlFilterEventtype == "Course" ? data?.ddlTypeList : "",
        GroupID: data?.ddlFilterEventtype == "Group" ? data?.ddlTypeList : "",
        TenantID: userData?.TenantInfo?.TenantID,
        IsDeleted: false
      }
      let headers = {
        method: "POST",
        headers: {
          authorizationtoken: userData?.user?.signInUserSession?.accessToken?.jwtToken,
          defaultrole: userData?.TenantInfo?.UserGroup,
          groupmenuname: "UserManagement",
          menuid: "200104",
          statemachinearn: stateMachineArn,
        },
        body: JSON?.stringify(eventInfo),
      };
      let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
      
    }
    finalResponse(finalStatus?.Status)
    // }
    setValue("submit", false);
  };

  const getEventTypes = useMemo(() => {
    return [
      { value: "MyEvent", text: "My Event" },
      { value: "Group", text: "Group" },
      { value: "Course", text: "Course" }
    ]
  }, []);

  return (<>
    <Container title={(router.query["Mode"] != "Edit") ? "Add Event" : "Edit Event"} PageRoutes={PageRoutes} loader={watch("IsFetchingData")}>
      <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
      <div className={`nvl-FormContent ${watch("submit") ? "pointer-events-none" : ""} `}>
        <NVLTextbox labelClassName="nvl-Def-Label pt-2 pb-2" labelText="Event Title" id="txtEventTitle" title={"Event Title"} className="nvl-mandatory w-full" register={register} errors={errors} />
        <NVLlabel id="lblEventType" text={"Description"} className="text-xs nvl-Def-Label pt-2 pb-2" />
        <NVLMultilineTxtbox id={"txtEventDescription"} className="nvl-Def-Input resize-y" title={"Description"} errors={errors} register={register} />
        <NVLlabel id="lblEventType" text={"Type Of Event"} className="text-xs nvl-Def-Label pt-2 pb-2" >
          <span className="text-red-500 text-lg">*</span></NVLlabel>
        {userData?.TenantInfo?.UserGroup == "CompanyAdmin" ? (<>
          <div className="flex justify-between">
            <NVLSelectField id="ddlFilterEventtype" options={getEventTypes} labelClassName="font-semibold text-gray-500"
              disabled={false} errors={errors} title="Select Company" register={register} className={`nvl-mandatory  w-44 ${router.query["Mode"] == "Edit" ? " Disabled" : ""}`} ></NVLSelectField>
            {watch("ddlFilterEventtype") != "MyEvent" && <div><NVLSelectField id="ddlTypeList" options={getCourses} labelClassName="font-semibold text-gray-500"
              disabled={false} errors={errors} title="Select Company" register={register} className={`nvl-mandatory  w-44 ${router.query["Mode"] == "Edit" ? " Disabled" : ""}`}  ></NVLSelectField></div>}
          </div></>
        ) : (<><NVLTextbox labelClassName="nvl-Def-Label" id="txtEvent" title={"Event Title"} className="Disabled" register={register} errors={errors} /></>
        )}
        <GetDateComponent setValue={setValue} register={register} errors={errors} watch={watch} />
        <div className="justify-center flex gap-4 pt-4 ">
          <NVLButton id="btnSave" text={`${watch("submit") ? "" : "Save"}`} disabled={watch("submit")} type="submit" className={"w-32 nvl-button bg-primary text-white"}
            onClick={handleSubmit((data) => submitHandler(data, "SaveAndContinue"))}>
            {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
          <NVLButton id="btnCancel" text={"Cancel"} type="Cancel" className="nvl-button w-32" onClick={() => {
            if (userData?.TenantInfo?.UserGroup == "CompanyAdmin") {
              router.push("/Home/AdminViewEventCalendar")
            } else {
              router.push("/MySchedule/EventCalendar")
            }
          }} />
        </div>
      </div>
    </Container>
  </>)
}
export default AddEventInfo;