import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import router from 'next/router';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCourseManagementInfo, listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

function CourseModuleReport(props) {
  const [csrFetchedCourseData, setCsrFetchedCourseData] = useState({});
  const [getCompanyData, setCompanyData] = useState({});
  const [moudleData, setMoudle] = useState();
  const [headerNames, setHeader] = useState([]);
  const [filterDropdownData, setFilterDropdownData] = useState({ Course: [{ value: "", text: "Filter by Course" }], });
  const refReportData = useRef();
  const refWhereQuery = useRef();
  const refFilterControl = useRef();
  const refRecordStatus = useRef();
  const executionID = useRef();

  const setCourseModuleData = useCallback((lGetCourseReportDatas) => {
    setMoudle(() => {
      let x = [];
      function sortData(columnName, data, columnName2) {
        var sortedData = {};
        for (var i = 0; i < data.length; i++) {
          var object = data[i];

          if (columnName2 === undefined) {
            if (Object.keys(sortedData).indexOf(object[columnName]) === -1) {
              sortedData[object[columnName]] = [];
            }
            sortedData[object[columnName]].push(object);
          }
          else {
            if (Object.keys(sortedData).indexOf(`${object[columnName]}-${object[columnName2]}`) === -1) {
              sortedData[`${object[columnName]}-${object[columnName2]}`] = [];
            }
            sortedData[`${object[columnName]}-${object[columnName2]}`].push(object);
          }
        }
        return sortedData;
      }

      let sortDt = sortData("UserName", JSON.parse(JSON.parse(lGetCourseReportDatas)?.State), "batchid");
      for (let j = 0; j < Object.keys(sortData("UserName", JSON.parse(JSON.parse(lGetCourseReportDatas)?.State), "batchid"))?.length; j++) {
        let getItem = sortDt?.[Object.keys(sortDt)[j]];
        let local = []
        let isCheck = []
        for (let i = 0; i < getItem?.length; i++) {
          if (!isCheck.includes(`${getItem[i].modulename}-${getItem[i].batchid}`)) {
            local = { ...local, ...{ UserName: getItem[i].UserName, EmailID: getItem[i].EmailID, CourseEnrolledDate: getItem[i].CourseEnrolledDate, [getItem[i].modulename]: (getItem[i].Status), CourseCompleteDate: getItem[i].CourseCompleteDate } }
            isCheck.push(`${getItem[i].modulename}-${getItem[i].batchid}`)
          }
        }
        x.push(local)
      }
      return x;
    })
    setHeader(() => {
      let x = [{ HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/7", },
      { HeaderName: "Email", Columnvalue: "EmailID", HeaderCss: "w-1/7", },
      { HeaderName: "Course Enrolled Date", Columnvalue: "CourseEnrolledDate", HeaderCss: "w-1/7", },
      { HeaderName: "Course Complete Date", Columnvalue: "CourseCompleteDate", HeaderCss: "w-1/7", }];

      let y = []
      JSON.parse(JSON.parse(lGetCourseReportDatas)?.State).map((getItem) => {
        if (!y.includes(getItem.modulename)) {
          x.push({ HeaderName: getItem.modulename, Columnvalue: getItem.modulename, HeaderCss: "w-1/7", });
          y.push(getItem.modulename);
        }
      });
      return x;
    })

  }, [])

  useEffect(() => {
    const dataSource = async (i) => {

      let CourseId = decodeURIComponent(String(router.query["CourseId"]));
      let courseName = decodeURIComponent(String(router.query["CourseName"]));
      let tenantid = decodeURIComponent(String(router.query["TenantId"]));
      let condition = ` WHERE courseid='${CourseId}' AND tenantid ='${tenantid}'`;
      const tenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
      const lGetCourseReportData = await APIGatewayPostRequest(
        process.env.APIGATEWAY_REPORT_URL,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/text",
            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
            menuid: "115506",
            tenantid: tenantid,
          },
          body: condition,
        }
      );
      const lGetCourseReportDatas = await lGetCourseReportData?.res?.text();
      executionID.current = lGetCourseReportDatas && JSON.parse(lGetCourseReportDatas);
      setCsrFetchedCourseData({
        plistXlmsTenantInfo: tenantInfo.res?.listXlmsTenantInfos?.items != undefined ? tenantInfo.res?.listXlmsTenantInfos?.items : [],
        pGetCourseReportData: lGetCourseReportDatas,
        TenantId: tenantid
      });
      setCompanyData((e) => { return tenantid; })
      setCourseModuleData(lGetCourseReportDatas)
      lGetCourseReportDatas != undefined && Object.keys(JSON.parse(JSON.parse(lGetCourseReportDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
    };
    dataSource();
    return (() => {
      setCsrFetchedCourseData((temp) => { return { ...temp }; });
    });
  }, [props.user?.attributes, props.user.signInUserSession.accessToken.jwtToken, setCourseModuleData]);

  const getFilterDropdownData = useCallback(async () => {
    const ltdrpCourse = [{ value: "", text: "Filter by Course" }];
    const lctCustomFieldvalue = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + getCompanyData, SK: "CUSTOMFIELD#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
    const lGetCourseData = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + getCompanyData, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
    const courseData = lGetCourseData.res?.listXlmsCourseManagementInfo?.items;
    courseData?.map((getItem) => { if (getItem?.text?.toLowerCase() != "select") { ltdrpCourse.push({ value: getItem.CourseID, text: getItem.CourseName }); } setFilterDropdownData({ Course: ltdrpCourse }) })
  }, [props?.user?.signInUserSession?.accessToken?.jwtToken, getCompanyData]);

  useEffect(() => { getFilterDropdownData(""); }, [getFilterDropdownData]);

  const validationSchema = Yup.object().shape({

  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
  const { errors } = formState;

  const selectCompany = useMemo(() => {
    if (csrFetchedCourseData?.plistXlmsTenantInfo != undefined) {
      let ltDefultSelect = [{ value: "", text: "Select Company" }];



      if (csrFetchedCourseData?.TenantId != null || csrFetchedCourseData?.TenantId != undefined) {
        ltDefultSelect = [];
        const currentTenant = csrFetchedCourseData?.plistXlmsTenantInfo?.filter(function (Tenant) {
          return Tenant.TenantID == getCompanyData;
        });
        currentTenant.map((getItem) => {
          ltDefultSelect.push({
            value: getItem.TenantID,
            text: getItem.TenantDisplayName,
          });
        });
      }
      return ltDefultSelect;
    }
  }, [csrFetchedCourseData?.plistXlmsTenantInfo, csrFetchedCourseData?.TenantId, getCompanyData]);

  const fetchedCourse = useMemo(() => {
    let courseName = decodeURIComponent(String(router.query["CourseName"]));
    let courseId = decodeURIComponent(String(router.query["CourseId"]));
    let ltDefultCourse = [{ value: courseId, text: courseName }];
    return ltDefultCourse;
  }, []);

  const execID = useRef();

  const gridDataBind = useCallback(
    (lGetCourseReportDatas = null) => {
      if (moudleData != undefined) {
        try {
          let viewData = moudleData;
          refReportData.current = viewData;
          execID.current = moudleData;

          let xjd = [];
          Object.entries(moudleData).map((get) => {
            if (get[0] == "UserName") xjd.push(get[0])
          });
          let rowGrid = [];
          for (let i = 0; i < (moudleData?.length); i++) {
            let xx = [];
            Object.entries(moudleData[i]).map((get, index) => {
              xx = { ...xx, ...{ [get[0]]: <NVLlabel id={index + 1} text={get[1]} /> } }
            });
            rowGrid.push(xx);
          }
          return rowGrid;
        }
        catch (error) {
          return ("Failed to retreive the records", error);
        }
      }
    },
    [moudleData]
  );

  const lstrTenantID = props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : getCompanyData;

  const submitHandler = async (data) => {
    setValue("submit", true);
    setValue("fetch", true);

    let lqrywhere;
    const lstrCourse = data.ddlCourse;
    if (lstrCourse != "") { lqrywhere = ` WHERE courseid='${lstrCourse}' AND tenantid ='${lstrTenantID}' `; }
    if (watch("txtsearch") != "") {
      let Username = watch("txtsearch").toUpperCase();
      lqrywhere += ` AND UPPER(UserName) LIKE '%${Username}%'`;
    }
    refWhereQuery.current = lqrywhere;

    try {
      const lGetUserloginInfoData = await APIGatewayPostRequest(
        process.env.APIGATEWAY_REPORT_URL,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/text",
            menuid: "115506",
            tenantid: lstrTenantID,
            //authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
          },
          body: `${refWhereQuery.current}`,
        }
      );
      const lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
      // setCourseSummaryReportData(lGetUserloginInfoDatas);
      setCourseModuleData(lGetUserloginInfoDatas);
      lGetUserloginInfoDatas != undefined && Object.keys(JSON.parse(JSON.parse(lGetUserloginInfoDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";

    } catch (error) {
      return ("Failed to retreive the records", error);
    }
    setValue("submit", false);
    setValue("fetch", false);
  };

  const fileDownload = useCallback(
    async (e) => {
      setValue("download", true);
      try {
        if (e?.type == "click") {

        let lqrywhere;
       const lstrCourse = watch("ddlCourse");
       if (lstrCourse != "") { lqrywhere = ` WHERE courseid='${lstrCourse}' AND tenantid ='${lstrTenantID}' `; }
        if (watch("txtsearch") != "") {
      let Username = watch("txtsearch").toUpperCase();
      lqrywhere += ` AND UPPER(UserName) LIKE '%${Username}%'`;
       }
         refWhereQuery.current = lqrywhere;

          const lGetUserloginInfoData = await APIGatewayPostRequest(
            process.env.APIGATEWAY_REPORT_URL,
            {
              method: "POST",
              headers: {
                "Content-Type": "application/text",
                menuid: "115111",
                tenantid: lstrTenantID,
                //authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
              },
              body: `${refWhereQuery.current}`,
            }
          );
          const lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
          const ExecuteQueryID = lGetUserloginInfoDatas != undefined && JSON?.parse(lGetUserloginInfoDatas).QueryExecutionID;

          const lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
          const headers = {
              method: "POST",
              headers: {
                  "Content-Type": "text/csv",
                  authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                  bucketname: process.env.REPORT_BUCKET_NAME,
              },
              body: `processed-data/${lstrTenantID}/${ExecuteQueryID}.csv`,
          };
          const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
          var win = window.open(await lstrFileDownload.res?.text(), "_self");
      }

      } catch (error) {
        return ("Failed to generate report", error);
      }
      setValue("download", false);
    },
    [setValue, watch, lstrTenantID, props?.user?.signInUserSession?.accessToken?.jwtToken]
  );

  function getCourseName() {
    const courseNameList = [];
    filterDropdownData.Course.map((Course, idx) => {
      if (watch("ddlCourse") != "") {
        if (watch("ddlCourse") == Course.value) { courseNameList.push(Course.text); }
      }
      else if (Course.text != "Select" && Course.text != "Filter by Course" && idx < 9)
        return courseNameList.push(Course.text);
    });
    return courseNameList;
  }

  const FeatureActivityData = { labels: getCourseName(), };


  const pageRoutes = useMemo(() => {
    let temp = [
      { path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard", },
      { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
    ];
    if (props.TenantInfo.UserGroup == "SiteAdmin") {
      temp = [...temp, { path: `/Analytics&Reports/CourseSummaryReport?TenantId=${router.query["TenantId"]}`, breadcrumb: "Course Summary Report" }]
    }
    else {
      temp = [...temp, { path: `/Analytics&Reports/CourseSummaryReport`, breadcrumb: "Course Summary Report" }]
    }
    temp = [...temp, { path: "", breadcrumb: "Course Module Report" }]
    return temp;
  }, [props.TenantInfo.UserGroup]);

  return (
    <>
      <Container title="Course Summary Report" PageRoutes={pageRoutes} loader={csrFetchedCourseData?.plistXlmsTenantInfo == undefined}>
        <form onSubmit={handleSubmit(submitHandler)} className={`${watch("submit") || watch("download") || watch("fetch") ? "pointer-events-none px-2" : "px-2"}`}>
          <div className="px-3" id="divFilter">
            <div className="block rounded-lg ">
              <div className="py-3 pb-4">
                <div className="col-span-6 sm:col-span-3">
                  <NVLlabel htmlFor="Company-Name" className="block text-sm font-medium text-gray-600 py-1">  Company Name </NVLlabel>
                  <div className="grid grid-cols-12 grid-flow-col gap-2 pt-4">
                    <div className="col-span-6 sm:col-span-3">
                      <NVLSelectField id="ddlCompany" errors={errors} options={selectCompany} className={`Disabled mt-1 block w-64 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm`} register={register} ></NVLSelectField>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-12 grid-flow-col gap-2 pt-4">
                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1" > Course Name </NVLlabel>
                    <NVLSelectField id="ddlCourse" errors={errors} options={fetchedCourse} className="Disabled mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}  ></NVLSelectField>
                  </div>

                  <div className="col-span-6 sm:col-span-3">
                    <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1">  Search by User Name </NVLlabel>
                    <NVLTextbox id="txtsearch" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by User name" />
                  </div>
                  <div className="col-span-6 sm:col-span-3 pt-6 ">
                    <div className="flex items-center gap-2">
                      <NVLButton
                        id="btnSubmit"
                        text={!watch("submit") ? "Apply Filter" : ""}
                        disabled={
                          watch("submit") || watch("fetch") || watch("download")
                            ? true
                            : false
                        }
                        type="submit"
                        className={
                          watch("submit")
                            ? "w-28 nvl-button !bg-indigo-500 text-white !h-10"
                            : "w-28 nvl-button !bg-indigo-500 text-white !h-10"
                        }
                      >
                        {watch("submit") && (
                          <i className="fa fa-circle-notch fa-spin mr-2"></i>
                        )}
                      </NVLButton>
                      <NVLButton
                        id="btnSubmit"
                        disabled={
                          watch("submit") || watch("download") || watch("fetch") || refRecordStatus.current == "NoRecord"
                            ? true
                            : false
                        }
                        type={"button"}
                        className={
                          refRecordStatus.current == "NoRecord"
                            ? "nvl-button bg-indigo-500 Disabled !h-10"
                            : "nvl-button !bg-indigo-500 text-white !h-10"
                        }
                        onClick={(e) => fileDownload(e)}
                      >
                        <i
                          className={`${watch("download")
                            ? " fa fa-circle-notch fa-spin"
                            : " fa-solid fa-download"
                            }  `}
                        ></i>
                      </NVLButton>

                      <div className="pb-2 pl-1">
                        <NVLlabel CustomCss="-translate-x-72 pt-4" className="nvl-Def-Label pb-1" HelpInfo={"Additional report details can be downloaded here"} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"} />
                      </div>
                    </div>
                  </div>

                  <div></div>
                </div>
              </div>
            </div>
          </div>

          {!watch("fetch") && (
            <div className="pb-8">
              <NVLGridTable id="tblEnrollList" className="max-w-full" HeaderColumn={headerNames}
                RowGridDataPass={{ RowGrid: refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? [] : (gridDataBind()) }} />
            </div>
          )}
          <div>{watch("fetch") && <NVLLoadingSpinner />}</div>
        </form>
      </Container>
    </>
  );
}

export default CourseModuleReport;
