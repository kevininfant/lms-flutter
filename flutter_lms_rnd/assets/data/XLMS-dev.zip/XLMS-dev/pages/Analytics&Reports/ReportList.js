import Container from "@components/Container/Container";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLButton from "@components/Controls/NVLButton";
import { useRouter } from "next/router";
import { useMemo } from "react";

function ReportList() {
    const luserRouter = useRouter();
    const pageRoutes = useMemo(()=>{return[
        {path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Report Dashboard" },
        {path: "", breadcrumb: "Reports" }
    ];},[]);
    return (
        <>
            <Container title="Reports">
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <div className="mt-10 sm:mt-0 px-3">
                    <div className="md:grid md:grid-cols-4 md:gap-6">
                        <div className="mt-5 md:col-span-2 md:mt-0">
                            <form action="#" method="POST">
                                <div className="overflow-hidden shadow sm:rounded-md">
                                    <div className="space-y-6 bg-white px-4 py-5 sm:p-6">
                                        <fieldset>
                                            <div className="text-base font-bold text-gray-900" aria-hidden="true">
                        User Report
                                            </div>
                                            <div className="mt-4 space-y-4">
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-user"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton
                                                            text={"User Login Report"}
                                                            type={"button"}
                                                            className="font-medium text-gray-700"
                                                            onClick={() => {
                                                                luserRouter.push("/Analytics&Reports/UserLoginReport");
                                                            }}
                                                        />
                                                        {/* <p className="text-gray-400 py-1">It returns information on the login activities of all of user accounts.</p> */}
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-book"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"User Information Report"} type={"button"} className="font-medium text-gray-700" 
                                                            onClick={() => {
                                                                luserRouter.push("/Analytics&Reports/UserInformationReport");
                                                            }}
                                                        />
                                                        {/* <p className="text-gray-400">It provide a summary of user results.</p> */}
                                                    </div>
                                                </div>

                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-square-person-confined"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"User Course Summary"} type={"button"} className="font-medium text-gray-700" 
                                                            onClick={() => {
                                                                luserRouter.push("/Analytics&Reports/UserWiseCourseSummary");
                                                            }}
                                                        />
                                                        {/* <p className="text-gray-400">It provide a summary of courses.</p> */}
                                                    </div>
                                                </div>


                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-square-person-confined"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"User Activity Summary"} type={"button"} className="font-medium text-gray-700" 
                                                            onClick={() => {
                                                                luserRouter.push("/Analytics&Reports/UserWiseActivitySummary");

                                                            }}
                                                        />
                                                        {/* <p className="text-gray-400">It shows the all assigned activity to the user.</p> */}
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div className="mt-5 md:col-span-2 md:mt-0 invisible">
                            <form action="#" method="POST">
                                <div className="overflow-hidden shadow sm:rounded-md">
                                    <div className="space-y-6 bg-white px-4 py-5 sm:p-6">
                                        <fieldset>
                                            <div className="text-base font-bold text-gray-900" aria-hidden="true">
                        Learning Plan Report
                                            </div>
                                            <div className="mt-4 space-y-4">
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-user"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton
                                                            text={"Learning Plan Summary"}
                                                            type={"button"}
                                                            className="font-medium text-gray-700"
                                                            onClick={() => {
                                                                luserRouter.push("/Reports/UserLoginReport");
                                                            }}
                                                        />
                                                        {/* <p className="text-gray-400 py-1">It returns information on the login activities of all of user accounts.</p> */}
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-book"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"User Wise Summay"} type={"button"} className="font-medium text-gray-700" />
                                                        {/* <p className="text-gray-400 py-1">It returns information on the login activities of all of user accounts.</p> */}
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-square-person-confined"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"View Learning Plan Details Report"} type={"button"} className="font-medium text-gray-700" />
                                                        <p className="text-gray-400 py-1"></p>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div className="mt-5 md:col-span-2 md:mt-0">
                            <form action="#" method="POST">
                                <div className="overflow-hidden shadow sm:rounded-md">
                                    <div className="space-y-6 bg-white px-4 py-5 sm:p-6">
                                        <fieldset>
                                            <div className="text-base font-bold text-gray-900" aria-hidden="true">
                        Course Report
                                            </div>
                                            <div className="mt-4 space-y-4">
                                                {/* <div className="flex items-start hidden"> */}
                                                {/* <div className="items-start hidden"> */}
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-user"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton
                                                            text={"Course Summary Report"}
                                                            type={"button"}
                                                            className="font-medium text-gray-700"
                                                            onClick={() => {
                                                                luserRouter.push("/Analytics&Reports/CourseSummaryReport");
                                                            }}
                                                        />
                                                        {/* <p className="text-gray-500">--</p> */}
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-book"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"Course Completion Report"} type={"button"} className="font-medium text-gray-700" onClick={() => {
                                                            luserRouter.push("/Analytics&Reports/CourseCompletionReport");
                                                        }} />
                                                        {/* <p className="text-gray-500">--</p> */}
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-square-person-confined"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"Course Report - Module Wise"}
                                                            type={"button"}
                                                            className="font-medium text-gray-700"
                                                            onClick={ () => {
                                                                luserRouter.push("/Analytics&Reports/ModuleCompletionReport");
                                                            }}
                                                        />
                                                        {/* <p className="text-gray-500">--</p> */}
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-square-person-confined"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"Course Report - Activity Wise"} type={"button"} className="font-medium text-gray-700" 
                                                            onClick={() => {
                                                                luserRouter.push("/Analytics&Reports/ActivityWiseCourseReport");
                                                            }} />
                                                        {/* <p className="text-gray-500">--</p> */}
                                                    </div>
                                                </div> 
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div className="mt-5 md:col-span-2 md:mt-0 hidden">
                            <form action="#" method="POST">
                                <div className="overflow-hidden shadow sm:rounded-md">
                                    <div className="space-y-6 bg-white px-4 py-5 sm:p-6">
                                        <fieldset>
                                            <div className="text-base font-bold text-gray-900" aria-hidden="true">
                        Other Report
                                            </div>
                                            <div className="mt-4 space-y-4">
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-user"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton
                                                            text={"Schedule Report"}
                                                            type={"button"}
                                                            className="font-medium text-gray-700"
                                                            onClick={() => {
                                                                luserRouter.push("/Reports/UserLoginReport");
                                                            }}
                                                        />
                                                        <p className="text-gray-500">--</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-book"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"Skill Gap Analytics"} type={"button"} className="font-medium text-gray-700" />
                                                        <p className="text-gray-500">--</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-start">
                                                    <div className="flex h-5 items-center">
                                                        <i className="fa-solid fa-square-person-confined"></i>
                                                    </div>
                                                    <div className="ml-3 text-sm">
                                                        <NVLButton text={"Create Custom Report"} type={"button"} className="font-medium text-gray-700" />
                                                        <p className="text-gray-500">--</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </fieldset>
                                    </div>
                                </div>
                            </form>
                        </div> 
                    </div>
                </div>
            </Container>
        </>
    );
}

export default ReportList;
