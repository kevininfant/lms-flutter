import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import router from 'next/router';
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCourseManagementInfo, listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";
Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

function CourseSummaryReport(props) {
    const [getCompanyData, setCompanyData] = useState(() => {

        return props.TenantInfo.TenantID

    });
    const [filterDropdownData, setFilterDropdownData] = useState({ Course: [{ value: "", text: "Filter by Course" }], });
    const refReportData = useRef();
    const refWhereQuery = useRef();
    const refFilterControl = useRef();
    const refRecordStatus = useRef();
    const [csrFetchedCourseData, setCsrFetchedCourseData] = useState({});
    const [courseSummaryReportData, setCourseSummaryReportData] = useState();
    const ddlCompanyValue = useRef();
    const ddlCourse = useRef()

    const validationSchema = Yup.object().shape({
        ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" && Yup.string().required("Company is required").test("", "", (e) => {
            if (refFilterControl.current != e) {
                refFilterControl.current = e;
                if (e != ddlCompanyValue?.current && ((e != "") || (e == "" && ddlCompanyValue?.current != undefined))) {
                    ddlCompanyValue.current = e;
                    fetchData(e);
                    setValue("ddlCourse", "")
                }
                return true;
            }
        }),
        ddlCourse: Yup.string().test((e) => {
            if (e != ddlCourse?.current && ((e != "") || (e == "" && ddlCourse?.current != undefined))) {
            ddlCourse.current = e;
            fetchData();
         }
            return true;
         }),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        const dataSource = async (e) => {
            const tenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            let currentTenantDetail;

            if (props.TenantInfo.UserGroup == "SiteAdmin" || (router.query["TenantId"] != null || router.query["TenantId"] != undefined)) {
                currentTenantDetail = getCompanyData;
            }
            else {
                currentTenantDetail = props.user.attributes["custom:tenantid"];
            }

            if (currentTenantDetail != undefined || currentTenantDetail != "") {
                const lGetCourseReportData = await APIGatewayPostRequest(
                    process.env.APIGATEWAY_REPORT_URL,
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/text",
                            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                            menuid: "115501",
                            tenantid: currentTenantDetail,
                        },
                        body: "WHERE CourseStatus=false",
                    }
                );

                const lGetCourseReportDatas = await lGetCourseReportData?.res?.text();
                lGetCourseReportDatas != undefined && Object.keys(JSON.parse(JSON.parse(lGetCourseReportDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
                setCsrFetchedCourseData({
                    plistXlmsTenantInfo: tenantInfo.res?.listXlmsTenantInfos?.items != undefined ? tenantInfo.res?.listXlmsTenantInfos?.items : [],
                    pGetCourseReportData: lGetCourseReportDatas,
                });
                setCourseSummaryReportData((lGetCourseReportDatas));
            }
        };
        dataSource();
        return (() => {
            setCsrFetchedCourseData((temp) => { return { ...temp }; });
            setCourseSummaryReportData((temp) => { return { ...temp }; });
        });
    }, [getCompanyData, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, watch]);
   

    const getFilterDropdownData = useCallback(async () => {
        const lstrTenantID = props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData : props.user.attributes["custom:tenantid"];
        const ltdrpCourse = [{ value: "", text: "Filter by Course" }];
        const lctCustomFieldvalue = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + lstrTenantID, SK: "CUSTOMFIELD#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const lGetCourseData = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + lstrTenantID, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const courseData = lGetCourseData.res?.listXlmsCourseManagementInfo?.items;
        courseData?.map((getItem) => {
            if (getItem?.text?.toLowerCase() != "select") { ltdrpCourse.push({ value: getItem.CourseID, text: getItem.CourseName }); }
            setFilterDropdownData({ Course: ltdrpCourse })
        })
    }, [getCompanyData, props.TenantInfo.UserGroup, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken]);

    useEffect(() => {
        getFilterDropdownData();
    }, [ getFilterDropdownData]);

    const currentTenantId = currentTenantId = props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : watch("ddlCompany");

    const selectCompany = useMemo(() => {
        const lstrTenantID = props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData : props.user.attributes["custom:tenantid"];
        if (csrFetchedCourseData?.plistXlmsTenantInfo != undefined) {
            let ltDefultSelect = [{ value: "", text: "Select Company" }];
            if (csrFetchedCourseData?.plistXlmsTenantInfo?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin" && ltDefultSelect.length < 2) {
                csrFetchedCourseData?.plistXlmsTenantInfo.map((getItem) =>
                    ltDefultSelect.push({
                        value: getItem.TenantID,
                        text: getItem.TenantDisplayName,

                    }),
                );
                if (router.query?.["TenantId"] != undefined) {
                    setValue("ddlCompany", router.query?.["TenantId"], { shouldValidate: true })
                }

            } else if (props.TenantInfo.UserGroup != "SiteAdmin") {
                ltDefultSelect = [];
                let tenantid = lstrTenantID;
                const currentTenant = csrFetchedCourseData?.plistXlmsTenantInfo?.filter(function (Tenant) {
                    return Tenant.TenantID == tenantid;
                });
                currentTenant.map((getItem) => {
                    ltDefultSelect.push({
                        value: getItem.TenantID,
                        text: getItem.TenantDisplayName,
                    });
                });
            }

            return ltDefultSelect;
        }
    }, [props.TenantInfo.UserGroup, props.user.attributes, getCompanyData, csrFetchedCourseData?.plistXlmsTenantInfo, setValue]);



    const headerColumn = useMemo(() => {
        return [{ HeaderName: "Course Name", Columnvalue: "Course Name", HeaderCss: "w-1/6", },
        { HeaderName: "Enrolled Users", Columnvalue: "Enrolled Users", HeaderCss: "w-1/6", },
        { HeaderName: "Completed Users", Columnvalue: "Completed Users", HeaderCss: "w-1/6", },
        { HeaderName: "Pending Users", Columnvalue: "Pending Users", HeaderCss: "w-1/6", },
        { HeaderName: "Completion Percentage", Columnvalue: "Completion Percentage", HeaderCss: "w-1/6", },
        { HeaderName: "Module Completion Report", Columnvalue: "ModuleCompletion", HeaderCss: "w-1/6", },
        { HeaderName: "Activity Completion Report", Columnvalue: "ActivityCompletion", HeaderCss: "w-1/6", },
        ];
    }, []);

    const execID = useRef();

    const gridDataBind = useCallback(
        (lGetUserloginInfoDatas = null) => {
            if (courseSummaryReportData != undefined) {
                try {
                    const rowGrid = [];
                    let viewData = courseSummaryReportData != undefined && Object.values(JSON?.parse(courseSummaryReportData));
                    viewData = viewData && viewData != undefined && JSON.parse(viewData?.[1]);
                    refReportData.current = viewData;
                    const lstrTenantID = props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData : props.user.attributes["custom:tenantid"];
                    execID.current = courseSummaryReportData != undefined && JSON?.parse(courseSummaryReportData);

                    if (viewData && viewData?.length == 1 && Object.keys(viewData?.[0]).length == 0) {
                        return [];
                    } else {
                    viewData &&
                        viewData.map((getItem, index) => {
                            rowGrid.push({
                                ["Course Name"]: (<NVLlabel id={index + 1} text={getItem.CourseName} />),
                                ["Enrolled Users"]: (<NVLlabel id={index + 1} text={getItem.EnrollUser} />),
                                ["Completed Users"]: (<NVLlabel id={index + 1} text={getItem.CompletedUser} />),
                                ["Pending Users"]: (<NVLlabel id={index + 1} text={getItem.PendingUser} />),
                                ["Completion Percentage"]: (<NVLlabel id={index + 1} text={getItem["Completion Percentage"]} />),
                                ModuleCompletion: getItem &&
                                    Object.entries(getItem).length != 0 && (
                                        <NVLLink
                                            id={"txtActivity" + (index + 1)}
                                            title={"ModuleCompletion"}
                                            onClick={() => router.push(`/Analytics&Reports/CourseModuleReport?CourseId=${getItem.CourseId}&CourseName=${getItem.CourseName}&TenantId=${lstrTenantID}`)}
                                            text={"View Report"}
                                            className=" cursor-pointer"
                                        ></NVLLink>
                                    ),
                                ActivityCompletion: getItem &&
                                    Object.entries(getItem).length != 0 && (
                                        <NVLLink
                                            id={"txtActivity" + (index + 1)}
                                            title={"ActivityCompletion"}
                                            onClick={() => router.push(`/Analytics&Reports/CourseActivityReport?CourseId=${getItem.CourseId}&CourseName=${getItem.CourseName}&TenantId=${lstrTenantID}`)}
                                            text={"View Report"}
                                            className=" cursor-pointer"
                                        ></NVLLink>
                                    ),
                            });

                        });
                    }

                    return rowGrid;
                }
                catch (error) {
                    return ("Failed to retreive the records", error);
                }
            }
        },
        [courseSummaryReportData, getCompanyData, props.TenantInfo.UserGroup, props.user.attributes]
    );

    const fileDownload = useCallback(
        async (e, data) => {
            setValue("download", true);
            const lstrTenantID = props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData : props.user.attributes["custom:tenantid"];

            let ExecuteQueryID;
            let lqrywhere;
            //const lstrUserName = data.txtsearch;

            lqrywhere = `WHERE CourseStatus=false`;

            if (watch("ddlCourse") != "") {
                lqrywhere += ` AND courseid='${watch("ddlCourse")}'`;
            }
            refWhereQuery.current = lqrywhere;

            try {
                const lGetCourseReportData = await APIGatewayPostRequest(
                    process.env.APIGATEWAY_REPORT_URL,
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/text",
                            authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                            menuid: "115508",
                            tenantid: lstrTenantID,
                        },
                        body: refWhereQuery.current,
                    }
                );

                const lGetCourseReportDatas = await lGetCourseReportData?.res?.text();

                ExecuteQueryID = lGetCourseReportDatas != undefined && JSON?.parse(lGetCourseReportDatas);

                if (e?.type == "click") {
                    const lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
                    const headers = {
                        method: "POST",
                        headers: {
                            "Content-Type": "text/csv",
                            authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                            bucketname: process.env.REPORT_BUCKET_NAME,
                        },
                        body: `processed-data/${currentTenantId}/${ExecuteQueryID?.QueryExecutionID}.csv`,
                    };

                    const lstrFileDownload = await APIGatewayPostRequest(
                        lstrPresignedFileURL,
                        headers
                    );
                    window.open(await lstrFileDownload.res?.text(), "_self");
                }
            } catch (error) {
                return ("Failed to generate report", error);
            }
            setValue("download", false);
        },
        [setValue, props.TenantInfo.UserGroup, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, getCompanyData, watch, currentTenantId]
    );


    function getCourseName() {
        const courseNameList = [];
        filterDropdownData.Course.map((Course, idx) => {
            if (watch("ddlCourse") != "") {
                if (watch("ddlCourse") == Course.value) {
                    courseNameList.push(Course.text);
                }
            } else if (Course.text != "Select" && Course.text != "Filter by Course" && idx < 9)
                return courseNameList.push(Course.text);
        });
        return courseNameList;
    }

    const FeatureActivityData = {
        labels: getCourseName(),
        // datasets: getLinechartData(),
    };

    const fetchData = useCallback(
        async (e) => {
            setValue("fetch", true);
            let loginChange;
            if (e == undefined) {
                if (props.TenantInfo.UserGroup == "SiteAdmin") { loginChange = watch("ddlCompany") }
                else { loginChange = props.user.attributes["custom:tenantid"]; }
            }
            else { loginChange = e; }

            let lqrywhere = `WHERE CourseStatus=false`;
            
            if (watch("ddlCourse") != "") {
                lqrywhere += ` AND courseid='${watch("ddlCourse")}'`;
            }

            try {
                const response = await APIGatewayPostRequest(
                    process.env.APIGATEWAY_REPORT_URL,
                    {
                        method: "POST",
                        headers: { "Content-Type": "application/text", menuid: "115501", tenantid: loginChange, },
                        body: lqrywhere,
                    }
                );
                const data = await response?.res?.text();
                data != undefined && Object.keys(JSON.parse(JSON.parse(data)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
                setCourseSummaryReportData(data);
                setCompanyData(loginChange)
                setValue("fetch", false);
            } catch (error) { return error; }
        },
        [props.TenantInfo.UserGroup, props.user.attributes, setValue, watch]
    );

    function getCourseName() {
        const courseNameList = [];
        filterDropdownData.Course.map((Course, idx) => {
            if (watch("ddlCourse") != "") {
                if (watch("ddlCourse") == Course.value) {
                    courseNameList.push(Course.text);
                }
            } else if (Course.text != "Select" && Course.text != "Filter by Course" && idx < 9)
                return courseNameList.push(Course.text);
        });
        return courseNameList;
    }

    const pageRoutes = useMemo(() => {
        return [
            { path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard", },
            { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
            { path: "", breadcrumb: "Course Summary Report" },
        ];
    }, []);

    return (
        <>
            <Container title="Course Summary Report" PageRoutes={pageRoutes} loader={csrFetchedCourseData?.plistXlmsTenantInfo == undefined}>
                <form className={`${watch("submit") || watch("download") || watch("fetch") ? "pointer-events-none px-2" : "px-2"}`}>
                    <div className="px-3" id="divFilter">
                        <div className="block rounded-lg ">
                            <div className="py-3 pb-4">
                                <div className="col-span-6 sm:col-span-3">
                                    <NVLlabel htmlFor="Company-Name" className="block text-sm font-medium text-gray-600 py-1" > Company Name </NVLlabel>
                                    <div className="grid grid-cols-12 grid-flow-col gap-2 pt-4">
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLSelectField id="ddlCompany" errors={errors} options={selectCompany} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" : ""} mt-1 block w-64 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm`} disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} register={register} ></NVLSelectField>
                                        </div>
                                    </div>
                                </div>
                                <div className="grid grid-cols-12 grid-flow-col gap-2 pt-4">
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1" >  Course Name </NVLlabel>
                                        <NVLSelectField id="ddlCourse" errors={errors}
                                            options={filterDropdownData.Course} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} ></NVLSelectField>
                                    </div>
                                    <div className="col-span-6 sm:col-span-3 pt-6 ">
                                        <div className="flex items-center gap-2">
                                            <NVLButton id="btnDownload" disabled={watch("submit") || watch("download") || watch("fetch") || refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? true : false} type={"button"}
                                                className={refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? "nvl-button Disabled bg-indigo-500 !h-10" : "nvl-button !bg-indigo-500 text-white !h-10"} onClick={currentTenantId != undefined || currentTenantId != null ? (e) => fileDownload(e) : () => { return [] }} >
                                                <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `} ></i>
                                            </NVLButton>

                                            <div className="pb-2 pl-1">
                                                <NVLlabel CustomCss="-translate-x-72 pt-4" className="nvl-Def-Label pb-1" HelpInfo={"Additional report details can be downloaded here"} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"} />
                                            </div>
                                        </div>
                                    </div>

                                    <div></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {!watch("fetch") && (
                        <div className="pb-8">
                            <NVLGridTable id="tblEnrollList" className="max-w-full" HeaderColumn={headerColumn} RowGridDataPass={{ RowGrid:  gridDataBind() }} />
                        </div>
                    )}

                    <div className="pt-4">{watch("fetch") && <NVLLoadingSpinner />}</div>
                </form>
            </Container>
        </>
    );
}

export default CourseSummaryReport;




