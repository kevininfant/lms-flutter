import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCourseManagementInfo, listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

export default function ModuleCompletionReport(props) {
    const [getModuleReportData, setValuedata] = useState();
    const [getCompanyData, setCompanyData] = useState(props.TenantInfo.TenantID);
    const [getFilterDropdownData, setFilterDropdownData] = useState({ Department: [{ value: "", text: "Filter by Department" }], Designation: [{ value: "", text: "Filter by Designation" }], Course: [{ value: "", text: "Filter by Course" }] });
    const [getPageData, setPageData] = useState({});
    const ddlCompanyname = useRef();
    const dropDownField = useRef({});
    const [headerColumn, setHeaderColumn] = useState([]);
    const refRecordStatus = useRef()
    const refReportData = useRef();
    const [moduleData, setMoudle] = useState();
    const ddlC = useRef();

    const setCourseModuleData = useCallback((getModuleReportData) => {
        setMoudle(() => {
            let x = [];
            function sortData(columnName, data, columnName2) {
                var sortedData = {};
                for (var i = 0; i < data.length; i++) {
                    var object = data[i];

                    if (columnName2 === undefined) {
                        if (Object.keys(sortedData).indexOf(object[columnName]) === -1) {
                            sortedData[object[columnName]] = [];
                        }
                        sortedData[object[columnName]].push(object);
                    }
                    else {
                        if (Object.keys(sortedData).indexOf(`${object[columnName]}-${object[columnName2]}`) === -1) {
                            sortedData[`${object[columnName]}-${object[columnName2]}`] = [];
                        }
                        sortedData[`${object[columnName]}-${object[columnName2]}`].push(object);
                    }
                }
                return sortedData;
            }
            let sortDt = sortData("UserName", JSON.parse(JSON.parse(getModuleReportData)?.State), "batchname");
            for (let j = 0; j < Object.keys(sortData("UserName", JSON.parse(JSON.parse(getModuleReportData)?.State), "batchname"))?.length; j++) {
                let getItem = sortDt?.[Object.keys(sortDt)[j]];
                let local = [];
                let isCheck = [];
                for (let i = 0; i < getItem?.length; i++) {
                    if (!isCheck.includes(`${getItem[i].modulename}-${getItem[i].batchname}`)) {
                        local = { ...local, ...{ UserName: getItem[i].UserName, EmailID: getItem[i].EmailID, Department: getItem[i].department, Designation: getItem[i].designation, CourseEnrolledDate: getItem[i].CourseEnrolledDate, [getItem[i].modulename]: (getItem[i].Status), CompletionDate: getItem[i].completiondate } }
                        isCheck.push(`${getItem[i].modulename}-${getItem[i].batchname}`)
                    }
                }
                x.push(local)
            }
            return x;
        })
        setHeaderColumn(() => {
            let x = [
                { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/6" },
                { HeaderName: "Email", Columnvalue: "EmailID", HeaderCss: "w-1/6" },
                { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "w-1/6" },
                { HeaderName: "Designation", Columnvalue: "Designation", HeaderCss: "w-1/6" },
                { HeaderName: "Course Enroll Date", Columnvalue: "CourseEnrolledDate", HeaderCss: "w-1/6" },
                { HeaderName: "Course Completion Date", Columnvalue: "CompletionDate", HeaderCss: "w-1/6" },
            ];
            let y = []
            JSON.parse(JSON.parse(getModuleReportData)?.State).map((getItem, In) => {

                //    if()
                if ((watch("ddlCourse") == "" || watch("ddlCourse") == undefined)) {
                    if (In < 3) {
                        if (!y.includes(getItem.modulename)) {
                            x.push({ HeaderName: getItem.modulename, Columnvalue: getItem.modulename, HeaderCss: "w-1/7", });
                            y.push(getItem.modulename);
                        }
                    }
                } else {
                    if (!y.includes(getItem.modulename)) {
                        x.push({ HeaderName: getItem.modulename, Columnvalue: getItem.modulename, HeaderCss: "w-1/7", });
                        y.push(getItem.modulename);
                    }
                }

            });
            return x;
        })
    }, [watch])

    const validationSchema = Yup.object().shape({
        ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" &&
            Yup.string().required("Company is required")
                .test("", "", (e) => {
                    if (ddlCompanyname.current != e || ddlC.current != watch("ddlCourse")) {
                        ddlC.current = watch("ddlCourse");
                        ddlCompanyname.current = e;
                        if (e != "") {
                            setValue("fetch", true);
                        }
                        setValue("ddlCourse", "")
                        setValue("ddlDepartment", "")
                        setValue("ddlDesignation", "")
                        setValue("txtsearch", "")
                        afterfetchData(e);

                    }
                    return true;
                }),
        ddlCourse: Yup.string()
            .test("", "", (e) => {
                if (dropDownField.current.Course != e) {
                    dropDownField.current.Course = e;
                    afterfetchData();
                }
                return true;
            }),
        ddlDepartment: Yup.string()
            .test("", "", (e) => {
                if (dropDownField.current.Department != e) {
                    dropDownField.current.Department = e;
                    afterfetchData();
                }
                return true;
            }),
        ddlDesignation: Yup.string()
            .test("", "", (e) => {
                if (dropDownField?.current?.Designation != e) {
                    dropDownField.current.Designation = e;
                    afterfetchData();
                }
                return true;
            }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
    const { errors } = formState;
    const executionID = useRef();

    useEffect(() => {
        const fetchData = async () => {

            const fetchTenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            let currentTenantDetail;
            if (props.TenantInfo.UserGroup == "SiteAdmin") {
                currentTenantDetail = getCompanyData;
            }
            else {
                currentTenantDetail = props.user.attributes["custom:tenantid"];
            }
            if (currentTenantDetail != undefined || currentTenantDetail != "") {
                const fetchModuleReport = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                        menuid: "115503",
                        tenantid: currentTenantDetail,
                    },
                    body: `WHERE courseid!=''`,
                });

                const getModuleReportData = await fetchModuleReport?.res?.text();
                executionID.current = getModuleReportData && JSON.parse(getModuleReportData);
                setCourseModuleData(getModuleReportData);
                const temp = {
                    plistXlmsTenantInfo: fetchTenantInfo.res?.listXlmsTenantInfos?.items != undefined ? fetchTenantInfo.res?.listXlmsTenantInfos?.items : [],
                    pGetModuleReportData: getModuleReportData,
                    currentTenantId: currentTenantDetail,
                };
                getModuleReportData != undefined && Object.keys(JSON.parse(JSON.parse(getModuleReportData)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
                setPageData(temp);
                setValuedata(getModuleReportData);

            };
        }
        fetchData();
        return (() => {
            setPageData((temp) => { return { ...temp }; });
        });
    }, [getCompanyData, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, setCourseModuleData, watch]);

    const getDataFilterDropdown = useCallback(async () => {
        const lstrTenantID = props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData : props.user.attributes["custom:tenantid"];
        const ltdrpDepartment = [{ value: "", text: "Filter by Department" }];
        const ltdrpDesignation = [{ value: "", text: "Filter by Designation" }];
        const ltdrpCourse = [{ value: "", text: "Filter by Course" }];
        const lctCustomFieldvalue = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + lstrTenantID, SK: "CUSTOMFIELD#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const lGetCourseData = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + lstrTenantID, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const userData = lctCustomFieldvalue.res?.listXlmsCustomFields?.items;
        const courseData = lGetCourseData.res?.listXlmsCourseManagementInfo?.items;
        courseData?.map((getItem) => {
            if (getItem?.text?.toLowerCase() != "select") {
                ltdrpCourse.push({ value: getItem.CourseID, text: getItem.CourseName });
            }
        });
        userData && userData.filter((filterCustomValue) => {
            if (filterCustomValue?.ProfileFieldName == "Department") {
                JSON.parse(filterCustomValue?.FieldOptions)?.map((mDepartment) => {
                    if (mDepartment?.text?.toLowerCase() != "select") {
                        ltdrpDepartment.push({ value: mDepartment?.value, text: mDepartment?.text });
                    }
                });
            }
            if (filterCustomValue?.ProfileFieldName == "Designation") {
                JSON.parse(filterCustomValue?.FieldOptions)?.map((mDesignation) => {
                    if (mDesignation?.text?.toLowerCase() != "select") {
                        ltdrpDesignation.push({ value: mDesignation?.value, text: mDesignation?.text });
                    }
                });
            }
            setFilterDropdownData({ Department: ltdrpDepartment, Designation: ltdrpDesignation, Course: ltdrpCourse });
        });
    }, [getCompanyData, props.TenantInfo.UserGroup, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken]);

    useEffect(() => {
        getDataFilterDropdown("");
    }, [getDataFilterDropdown]);


    const selectCompany = useMemo(() => {
        let ltDefultSelect = [{ value: "", text: "Filter by Company" }];
        const lstrTenantID = props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData : props.user.attributes["custom:tenantid"];

        if (getPageData.plistXlmsTenantInfo?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin" && ltDefultSelect.length < 2) {
            getPageData.plistXlmsTenantInfo?.map((getItem) => ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));

        } else if (props.TenantInfo.UserGroup != "SiteAdmin") {
            ltDefultSelect = [];
            const currentTenant = getPageData.plistXlmsTenantInfo?.filter(function (Tenant) {
                return Tenant.TenantID == lstrTenantID;
            });
            currentTenant?.map((getItem) => {
                ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName });
            });
        }
        return ltDefultSelect;
    }, [props.TenantInfo.UserGroup, props.user.attributes, getCompanyData, getPageData.plistXlmsTenantInfo]);

    const execID = useRef();
    const gridDataBind = useCallback(() => {
        try {
            let viewData = moduleData;
            refReportData.current = viewData;
            execID.current = moduleData;
            let xjd = [];
            Object.entries(moduleData).map((get) => {
                if (get[0] == "UserName") xjd.push(get[0])
            });
            let rowGrid = [];
            for (let i = 0; i < (moduleData?.length); i++) {
                let xx = [];
                Object.entries(moduleData[i]).map((get, index) => {
                    xx = { ...xx, ...{ [get[0]]: <NVLlabel id={index + 1} text={get[1]} /> } }
                });
                rowGrid.push(xx);
            }
            return rowGrid;
        }
        catch (error) {
            return ("Failed to retreive the records", error);
        }
    }, [moduleData]);

    const currentTenantInfo = currentTenantInfo = props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : watch("ddlCompany");


    const submitHandler = async (data) => {
        setValue("submit", true);
        setValue("fetch", true);
        let lqrywhere;
        const lstrDesignation = data.ddlDesignation;
        const lstrDepartment = data.ddlDepartment;
        const lstrUserName = data?.txtsearch.toUpperCase();
        const lstrCourse = data.ddlCourse;

        lqrywhere = `WHERE courseid!='' `;
        if (lstrCourse != "") {

            lqrywhere += ` AND courseid='${lstrCourse}'`;
        }

        if (lstrDepartment != "") {
            lqrywhere += ` AND Department='${lstrDepartment}'`;
        }

        if (lstrDesignation != "") {
            lqrywhere += ` AND Designation='${lstrDesignation}'`;
        }

        if (lstrUserName != "") {
            lqrywhere += ` AND UPPER(UserName) LIKE '%${lstrUserName}%'`;
        }

        const lGetUserloginInfoData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/text",
                menuid: "115503",
                tenantid: currentTenantInfo,
            },
            body: `${lqrywhere}`,
        });
        const lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
        lGetUserloginInfoDatas != undefined && Object.keys(JSON.parse(JSON.parse(lGetUserloginInfoDatas)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
        setValuedata(lGetUserloginInfoDatas);
        setValue("submit", false);
        setValue("fetch", false);
    };
    const fileDownload = useCallback(async (e) => {
        setValue("download", true);
        try {
            if (e?.type == "click") {

                let lqrywhere;
                const lstrDesignation = watch("ddlDesignation");
                const lstrDepartment = watch("ddlDepartment");
                const lstrUserName = watch("txtsearch").toUpperCase();
                const lstrCourse = watch("ddlCourse");
        
                lqrywhere = `WHERE courseid!='' `;
                if (lstrCourse != "") {
        
                    lqrywhere += ` AND courseid='${lstrCourse}'`;
                }
        
                if (lstrDepartment != "") {
                    lqrywhere += ` AND Department='${lstrDepartment}'`;
                }
        
                if (lstrDesignation != "") {
                    lqrywhere += ` AND Designation='${lstrDesignation}'`;
                }
        
                if (lstrUserName != "") {
                    lqrywhere += ` AND UPPER(UserName) LIKE '%${lstrUserName}%'`;
                }


                const lGetUserloginInfoData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/text",
                        menuid: "115333",
                        tenantid: currentTenantInfo,
                    },
                    body: `${lqrywhere}`,
                });
                const lGetUserloginInfoDatas = await lGetUserloginInfoData?.res?.text();
               const ExecuteQueryID = lGetUserloginInfoDatas != undefined && JSON?.parse(lGetUserloginInfoDatas).QueryExecutionID;
                const lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
                const headers = {
                    method: "POST",
                    headers: {
                        "Content-Type": "text/csv",
                        authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                        bucketname: process.env.REPORT_BUCKET_NAME,
                    },
                    body: `processed-data/${currentTenantInfo}/${ExecuteQueryID}.csv`,
                };
                const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
                var win = window.open(await lstrFileDownload.res?.text(), "_self");
            }
        } catch (error) { return error }
        setValue("download", false);

    },
        [setValue, watch, currentTenantInfo, props?.user?.signInUserSession?.accessToken?.jwtToken]
    );

    //Line Chart

    const pageRoutes = useMemo(() => {
        return [
            { path: "/Analytics&Reports/ReportDashboard", breadcrumb: 'Reports Dashboard' },
            { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
            { path: "", breadcrumb: "Module Completion Report" }

        ];
    }, []);

    const afterfetchData = useCallback(async (e) => {
        let loginChange;
        if (e == undefined) {
            if (props.TenantInfo.UserGroup == "SiteAdmin") { loginChange = watch("ddlCompany") }
            else { loginChange = props.user.attributes["custom:tenantid"]; }
        }
        else { loginChange = e; }
        setValue("fetch", true)

        let lstrUserName = watch("txtsearch")?.toUpperCase()
        let lqrywhere = `WHERE courseid!=''`;

        if (watch("ddlCourse") != "") {
            lqrywhere += ` AND courseid='${watch("ddlCourse")}'`;
        }

        if (watch("ddlDepartment") != "") {
            lqrywhere += ` AND department='${watch("ddlDepartment")}'`;
        }

        if (watch("ddlDesignation") != "") {
            lqrywhere += ` AND designation='${watch("ddlDesignation")}'`;
        }

        if (lstrUserName != "") {
            lqrywhere += ` AND UPPER(UserName) LIKE '%${lstrUserName}%'`;
        }

        try {
            const response = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    menuid: "115503",
                    tenantid: loginChange,
                },
                body: lqrywhere,
            });
            const data = await response?.res?.text();
            data != undefined && Object.keys(JSON.parse(JSON.parse(data)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
            setCourseModuleData(data, true)
            setValuedata(data);
            setCompanyData(loginChange)
            setValue("fetch", false);

        } catch (error) { return error }
    }, [props.TenantInfo.UserGroup, props.user.attributes, setCourseModuleData, setValue, watch]);



    return (
        <>
            <Container title="Module Completion Report" PageRoutes={pageRoutes} loader={getPageData.plistXlmsTenantInfo == undefined}>
                <form onSubmit={handleSubmit(submitHandler)} className={`${(watch("submit") || watch("fetch")) || watch("download") ? "px-2 pointer-events-none" : "px-2"}`}>
                    <div className="px-3" id="divFilter">
                        <div className="block rounded-lg ">
                            <div className="py-3 pb-4">
                                <div className="col-span-6 sm:col-span-3">
                                    <NVLlabel htmlFor="Company-Name" className="block text-sm font-medium text-gray-600 py-1">
                                        Company Name
                                    </NVLlabel>
                                    <NVLSelectField id="ddlCompany" errors={errors} options={selectCompany} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled " : ""} mt-1 block w-64 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm`} disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} register={register}></NVLSelectField>
                                </div>
                                <div className="grid grid-cols-12 grid-flow-col gap-4 pt-4">
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1">
                                            Course Name
                                        </NVLlabel>
                                        <NVLSelectField id="ddlCourse" errors={errors} options={getFilterDropdownData.Course} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Department" className="block text-sm font-medium text-gray-600 py-1">
                                            Department
                                        </NVLlabel>
                                        <NVLSelectField id="ddlDepartment" className={"mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"} register={register} options={getFilterDropdownData.Department} errors={errors} />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Designation" className="block text-sm font-medium text-gray-600 py-1">
                                            Designation
                                        </NVLlabel>
                                        <NVLSelectField id="ddlDesignation" autoComplete="given-name" className={"mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"} register={register} errors={errors} options={getFilterDropdownData.Designation} />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="User-Name" className="block text-sm font-medium text-gray-600 py-1">
                                            Search by User Name
                                        </NVLlabel>
                                        <NVLTextbox id="txtsearch" className={"mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"} register={register} errors={errors} title="Filter by user name" />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3 pt-6">
                                        <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""}
                                            disabled={watch("submit") || watch("fetch") || watch("download") ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-primary text-white !h-10" : "w-28 nvl-button !bg-primary text-white !h-10"}>
                                            {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                                        </NVLButton>
                                    </div>

                                    <div className="col-span-6 sm:col-span-3 pt-6">
                                        <div className="flex items-center">
                                            <NVLButton id="btnSubmit" disabled={(watch("submit") || watch("fetch")) || refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? true : false} type={"button"}
                                                className={refRecordStatus.current == "NoRecord" || refRecordStatus.current == undefined ? "nvl-button bg-primary Disabled  !h-10" : "nvl-button !bg-primary text-white !h-10"}
                                                onClick={(e) => fileDownload(e)}
                                            >
                                                <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                            </NVLButton>

                                            <div className="pb-2 pl-2 ">
                                                <NVLlabel CustomCss="-translate-x-72 pt-4" className="nvl-Def-Label pb-1" HelpInfo={"Additional report details can be downloaded here"} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"} />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {!watch("fetch") && <div className="pb-8">
                        <NVLGridTable id="tblEnrollList" className="max-w-full"
                            HeaderColumn={headerColumn}
                            RowGridDataPass={{ RowGrid: gridDataBind() }} />
                    </div>}
                    <div>
                        {watch("fetch") && <NVLLoadingSpinner />}
                    </div>
                </form>
            </Container>
        </>
    );
}