import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

export default function UserLoginReport(props) {
  const [GridData, SetGridData] = useState({ Page: 0 });
  const getDesDepData = useRef({ Department: [{ value: "", text: "Filter by Department" }], Designation: [{ value: "", text: "Filter by Designation" }] });
  const [pageData, setPageData] = useState({});
  const ddlData = useRef({ TenantID: props.TenantInfo.TenantID, Department: "", Designation: "", UserName: "", Change: false });
  const router = useRouter();

  const userFiltration = useCallback((gridDataBind, Page) => {
    ddlData.current = { ...ddlData.current, Change: true };
    SetGridData((temp) => {
      if (temp.Page == 0 && ddlData.current.Change) {
        gridDataBind(Page, true);
        return temp;
      }
      else {
        return { ...temp, Page: 0 }
      }
    })
  }, []);
  
  const validationSchema = Yup.object().shape({
    ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" && Yup.string().required("Company is required").test("", "", (e) => {
      if (e != ddlData.current.TenantID && e != "" && e != undefined) {
        ddlData.current = { TenantID: e, Department: "", Designation: "", UserName: "" };
        setValue("ddlDepartment", ""); setValue("ddlDesignation", ""); setValue("txtUserName", ""); userFiltration(gridDataBind, GridData.Page);
        dropdownData();
      } return true;
    }),
    ddlDepartment: Yup.string().test("", "ChangeHandler", (e) => {
      if (e != ddlData.current.Department && e != "" && e != undefined) {
        ddlData.current = { ...ddlData.current, Department: e };
        userFiltration(gridDataBind, GridData.Page);
      }
      else {
        ddlData.current = { ...ddlData.current, Department: e };
      }
      return true;
    }),
    ddlDesignation: Yup.string().test("", "ChangeHandler", (e) => {
      if (e != ddlData.current.Designation && e != "" && e != undefined) {
        ddlData.current = { ...ddlData.current, Designation: e };
        userFiltration(gridDataBind, GridData.Page);
      }
      else {
        ddlData.current = { ...ddlData.current, Designation: e };
      }
      return true;
    }),
    txtUserName: Yup.string().test("", "ChangeHandler", (e) => {
      if (e != ddlData.current.UserName && e != "" && e != undefined) {
        ddlData.current = { ...ddlData.current, UserName: e };
        // userFiltration(gridDataBind, GridData.Page);
      }
      else {
        ddlData.current = { ...ddlData.current, UserName: e };
      }
      return true;
    }),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, formState, watch, setValue } = useForm(formOptions);
  const { errors } = formState;

  //get Current Page offset value
  const getOffsetInfo = useCallback((Page) => {
    const pageOffset = Page ? Page : 0;
    return `ORDER BY lastmodifieddate,UserName  ASC
                   OFFSET ${pageOffset * process.env.PAGEGRIDSIZE} ROWS
                   FETCH NEXT ${process.env.PAGEGRIDSIZE} ROWS ONLY`;
  }, []);

  const fetchGridData = useCallback(async (e) => {
    const tenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
    const temp = {
      listXlmsTenantInfo: tenantInfo?.res?.listXlmsTenantInfos?.items != undefined ? tenantInfo.res?.listXlmsTenantInfos?.items : [],
      tenantId: ddlData.current.TenantID,
    };

    setPageData(temp);
  }, [props.user.signInUserSession.accessToken.jwtToken]);

  useEffect(() => {
    fetchGridData();
    return () => {
      setPageData((temp) => {
        return { ...temp };
      });
    };
  }, [fetchGridData]);

  const dropdownData = useCallback(async () => {
    const ltdrpDepartment = [{ value: "", text: "Filter by Department" }];
    const ltdrpDesignation = [{ value: "", text: "Filter by Designation" }];
    const lctCustomFieldvalue = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + ddlData.current.TenantID, SK: "CUSTOMFIELD#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
    const userData = lctCustomFieldvalue.res?.listXlmsCustomFields?.items;
    userData &&
      userData.filter((filterCustomValue) => {
        if (filterCustomValue?.ProfileFieldName == "Department") {
          JSON.parse(filterCustomValue?.FieldOptions)?.map((mDepartment) => {
            if (mDepartment?.text?.toLowerCase() != "select") {
              ltdrpDepartment.push({ value: mDepartment?.value, text: mDepartment?.text });
            }
          });
        }
        if (filterCustomValue?.ProfileFieldName == "Designation") {
          JSON.parse(filterCustomValue?.FieldOptions)?.map((mDesignation) => {
            if (mDesignation?.text?.toLowerCase() != "select") {
              ltdrpDesignation.push({ value: mDesignation?.value, text: mDesignation?.text });
            }
          });
        }
        getDesDepData.current = { Department: ltdrpDepartment, Designation: ltdrpDesignation };
      });
  }, [props?.user?.signInUserSession?.accessToken?.jwtToken]);

  useEffect(() => {
    if (props.TenantInfo.UserGroup != "SiteAdmin")
      dropdownData();
  }, [dropdownData, props.TenantInfo.UserGroup]);
  const selectCompany = useMemo(() => {
    if (pageData?.listXlmsTenantInfo != undefined) {
      let ltDefultSelect = [{ value: "", text: "Select Company" }];
      if (pageData.listXlmsTenantInfo?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin" && ltDefultSelect.length < process.env.PAGEGRIDSIZE) {
        pageData.listXlmsTenantInfo?.map((getItem) => ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
      } else if (props.TenantInfo.UserGroup != "SiteAdmin") {
        ltDefultSelect = [];
        const currentTenant = pageData.listXlmsTenantInfo?.filter(function (Tenant) {
          return Tenant.TenantID == pageData.tenantId;
        });
        currentTenant?.map((getItem) => {
          ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName });
        });
      }
      return ltDefultSelect;
    }
  }, [pageData.listXlmsTenantInfo, pageData.tenantId, props.TenantInfo.UserGroup]);

  const headerColumn = useMemo(() => [{ HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/2" }, { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "w-1/2" }, { HeaderName: "Designation", Columnvalue: "Designation", HeaderCss: "w-1/2" }, { HeaderName: "First Access", Columnvalue: "FirstAccess", HeaderCss: "w-1/2" }, { HeaderName: "Last Access", Columnvalue: "LastAccess", HeaderCss: "w-1/2" }, { HeaderName: "Total Logins", Columnvalue: "TotalLogins", HeaderCss: "w-1/1" }, { HeaderName: "Status", Columnvalue: "status", HeaderCss: "w-1/1" },], []);

  const gridDataBind = useCallback(async (Page, Filter) => {

    let tempTrue = ddlData.current?.Change || Filter;
    ddlData.current = { ...ddlData.current, Change: false };
    setValue("fetch", true);

    const GetGridTableDetails = (filterLoginData) => {
      const rowGrid = [];
      let viewData = filterLoginData != undefined && Object.values(JSON?.parse(filterLoginData));
      viewData = viewData && JSON?.parse(viewData?.[1]);
      if (viewData && viewData?.length == 1 && Object.keys(viewData?.[0]).length == 0) {
        return [];
      } else {

        viewData &&
          viewData.map((getItem, index) => {
            rowGrid.push({
              UserName: <NVLlabel id={index + 1} text={getItem.UserName} />,
              Department: <NVLlabel id={index + 1} text={getItem.Department} />,
              Designation: <NVLlabel id={index + 1} text={getItem.Designation} />,
              FirstAccess: <NVLlabel id={index + 1} text={getItem.FirstAccess} />,
              LastAccess: <NVLlabel id={index + 1} text={getItem.LastAccess} />,
              TotalLogins: <NVLlabel id={index + 1} text={getItem.TotalLogins} />,
              status: <NVLlabel id={index + 1} text={getItem.status} />,
            });
          });
        return rowGrid;
      }
    };
    const lstrDepartment = ddlData?.current?.Department;
    const lstrDesignation = ddlData?.current?.Designation;
    let lqrywhere;
    lqrywhere = `WHERE tenantid='${ddlData?.current?.TenantID}'`;
    if (lstrDepartment != "") {
      lqrywhere += ` AND Department='${lstrDepartment}'`;
    }
    if (lstrDesignation != "") {
      lqrywhere += ` AND Designation='${lstrDesignation}'`;
    }
    if (ddlData.current.UserName != "") {
      lqrywhere += ` AND UPPER(UserName) LIKE UPPER('%${ddlData.current.UserName}%')`;
    }
    const fetchLoginData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/text",
        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
        menuid: "115102",
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: "Analytics&Report",
        tenantid: ddlData?.current?.TenantID,
      },
      body: `${lqrywhere} ${getOffsetInfo(Page)}`,
    });
    const setUserLoginData = await fetchLoginData?.res?.text();
    const rowGrid = GetGridTableDetails(setUserLoginData);
    if (tempTrue) {
      if (rowGrid?.length > 0) {
        SetGridData((temp) => {
          return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
        })
      }
      else {
        SetGridData((temp) => {
          return { ...temp, TotalCount: 0, rowGrid: [] };
        })
      }
    }
    else {
      if (rowGrid?.length > 0) {
        SetGridData((temp) => {
          if (temp?.rowGrid?.length > 0)
            return { ...temp, rowGrid: [...temp.rowGrid, ...rowGrid], TotalCount: parseInt((temp?.rowGrid?.length + rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
          else
            return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
        })
      }
      else {
        SetGridData((temp) => {
          if (temp?.rowGrid?.length > 0)
            return { ...temp, TotalCount: temp?.rowGrid?.length / process.env.PAGEGRIDSIZE, ShowContentAndReducePage: temp?.ShowContentAndReducePage != undefined ? temp.ShowContentAndReducePage + 1 : 1 };
          else
            return { ...temp, TotalCount: 0 };
        })
      }
    }
    setValue("fetch", false);
  }, [getOffsetInfo, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, setValue])

  const submitHandler = async (data) => {
    setValue("submit", true);
    userFiltration(gridDataBind, GridData.Page);
    setValue("submit", false);
  };

  const fileDownload = useCallback(async (e) => {
    setValue("download", true);
    let lqrywhere;
    const lstrDepartment = ddlData?.current?.Department;
    const lstrDesignation = ddlData?.current?.Designation;
    lqrywhere = `WHERE tenantid='${ddlData?.current?.TenantID}'`;
    if (lstrDepartment != "") {
      lqrywhere += ` AND Department='${lstrDepartment}'`;
    }
    if (lstrDesignation != "") {
      lqrywhere += ` AND Designation='${lstrDesignation}'`;
    }
    if (ddlData.current.UserName != "") {
      lqrywhere += ` AND UPPER(UserName) LIKE UPPER('%${ddlData.current.UserName}%')`;
    }
    if (e?.type == "click") {
      const lstrPresignedFileURL = process.env.APIGATEWAY_REPORT_URL+`?ReportType=Download`;
      const headers = {
          method: "POST",
          headers: {
              "Content-Type": "text/csv",
              authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
              tenantid: ddlData?.current?.TenantID,
              groupmenuname:"Analytics&Report",
              defaultrole:props?.TenantInfo.UserGroup,
              menuid: "115102"
          },
          body: `${lqrywhere}`,
      };
      const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
    if(lstrFileDownload?.Status=="Success"){
      setValue("popup",true)
    }else{
      setValue("popup",false)

    }
  }
    setValue("download", false);
  }, [props?.TenantInfo.UserGroup, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue]);
  const pageRoutes = useMemo(() => {
    return [
      { path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard" },
      { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
      { path: "", breadcrumb: "User Login Report" },
    ];
  }, []);

  const pageChangeCall = useCallback((currentPage) => {
    SetGridData((temp) => {
      if (temp.Page < currentPage) {
        gridDataBind(currentPage)
        return { ...temp, Page: currentPage };
      }
      else {
        return temp;
      }
    })
  }, [gridDataBind]);

  useEffect(() => {
    if (props.TenantInfo.UserGroup != "SiteAdmin")
      gridDataBind(0);
  }, [gridDataBind, props.TenantInfo.UserGroup])

  const GridTable = useCallback((props) => {
    if (!props.watch("fetch"))
      return (
        <div>
          <NVLGridTable id="tblEnrollList" className="max-w-full" HeaderColumn={props.headerColumn} RowGridDataPass={{ RowGrid: props.GridData.rowGrid != undefined ? props.GridData.rowGrid : [] }} pageChangeCall={props.pageChangeCall} TotalCount={props.GridData.TotalCount} pageSize={process.env.PAGEGRIDSIZE} ShowContentAndReducePage={props.GridData.ShowContentAndReducePage} DonotLoad={false} currentPageFront={props.GridData.Page} />
        </div>);
    else {
      return (
        <div className="pt-8">
          <NVLLoadingSpinner />
        </div>
      )
    }
  }, [])
  return (
    <>
      <Container title="User Login Report" PageRoutes={pageRoutes} loader={pageData.tenantId == undefined}>
        <div className={watch("submit") || watch("download") || watch("fetch") ? "pointer-events-none" : ""}>
          <form onSubmit={handleSubmit(submitHandler)} className="px-2">
            <div className="px-3" id="divFilter">
              <div className="block rounded-lg ">
                <div className="py-3">
                  <div className="grid grid-cols-12 grid-flow-col gap-4">
                    <div className="col-span-6 sm:col-span-3">
                      <NVLlabel text="Company Name" className="nvl-Def-Label"></NVLlabel>
                      <NVLSelectField id="ddlCompany" errors={errors} options={selectCompany} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" : ""} mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm`} disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} register={register}></NVLSelectField>
                    </div>
                    <div className="col-span-6 sm:col-span-3">
                      <NVLlabel text="Department" className="nvl-Def-Label"></NVLlabel>
                      <NVLSelectField id="ddlDepartment" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={getDesDepData?.current?.Department} errors={errors} />
                    </div>
                    <div className="col-span-6 sm:col-span-3">
                      <NVLlabel text="Designation" className="nvl-Def-Label"></NVLlabel>
                      <NVLSelectField id="ddlDesignation" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={getDesDepData?.current?.Designation} errors={errors} />
                    </div>
                    <div className="col-span-6 sm:col-span-3">
                      <NVLlabel text="Search by User Name" className="nvl-Def-Label"></NVLlabel>
                      <NVLTextbox id="txtUserName" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by user name" />
                    </div>
                    <div className="col-span-6 sm:col-span-3 pt-4">
                      <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""} disabled={watch("submit") ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-primary text-white !h-10" : "w-28 nvl-button !bg-primary text-white !h-10"} onClick={() => { }}>
                        {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                      </NVLButton>
                    </div>
                    <div className="col-span-6 sm:col-span-3 pt-4">
                      <div className="flex items-center">
                        <NVLButton type={"button"}
                         disabled={GridData?.rowGrid?.length==0||GridData?.rowGrid?.length==undefined ||watch("download")? true : false} 
                        className={GridData?.rowGrid?.length==0 ||GridData?.rowGrid?.length==undefined ||watch("download")? "inline-flex justify-center rounded-md border border-transparent Disabled bg-primary py-2 px-4 pt-3 text-sm font-medium" : "inline-flex justify-center rounded-md border border-transparent bg-primary py-2 px-4 pt-3 text-sm font-medium text-white shadow-sm hover:bg-primary focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"} 
                         onClick={(e) => fileDownload(e)}>
                          <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                        </NVLButton>
                        <div className="pb-2 pl-1">
                          <NVLlabel CustomCss="-translate-x-72 pt-4" className="nvl-Def-Label pb-1" HelpInfo={"Additional report details can be downloaded here"} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"} />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <GridTable watch={watch} GridData={GridData} headerColumn={headerColumn} pageChangeCall={pageChangeCall} />
          </form>
      {watch("popup")&&<NVLModalPopup CancelClick={()=>router.push("/Analytics&Reports/ReportList")} ButtonNotext="OK"  Content={"Download in progress ....You will be notified once the download is completed. The file can be downloaded from the notification"} />}  

        </div>
      </Container>
    </>
  );
}

