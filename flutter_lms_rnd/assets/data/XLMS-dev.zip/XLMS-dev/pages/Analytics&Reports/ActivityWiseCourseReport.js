import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCourseManagementInfo, listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

function ActivityWiseCourseReport(props) {
    const [lstrFilterCourseData, setValuedata] = useState([]);
    const [getCompanyData, setCompanyData] = useState(props?.TenantInfo?.TenantID);
    const [lstDesDepData, setValueDesDep] = useState({ Department: [{ value: "", text: "Filter by Department" }], Designation: [{ value: "", text: "Filter by Designation" }], Course: [{ value: "", text: "Filter by Course" }] });
    const dropDownChange = useRef({});
    const [fetchdata, setFetchdata] = useState({});
    const execID = useRef();
    const refRecordStatus = useRef(true);
    const ddlCompanyValue = useRef();

    const validationSchema = Yup.object().shape({
        ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" &&
            Yup.string().required("Company is required")
                .test("", "", (e) => {
                    if (e != ddlCompanyValue?.current && ((e != "") || (e == "" && ddlCompanyValue?.current != undefined))) {
                        ddlCompanyValue.current = e;
                        fetchData(e)
                        setValue("ddlDepartment", "")
                        setValue("ddlDesignation", "")
                        setValue("ddlCourse","")
                        setValue("txtsearch", "")
                    }
                    return true;
                }),
        ddlCourse: Yup.string()
            .test("", "ChangeHandle", (e) => {
                if (e != dropDownChange.current.Course && ((e != "") || (e == "" && dropDownChange.current.Course != undefined))) {
                    dropDownChange.current.Course = e
                    fetchData();
                }
                return true;
            }),
            ddlDepartment: Yup.string()
            .test("", "ChangeHandle", (e) => {
                if (e != dropDownChange.current.Department && ((e != "") || (e == "" && dropDownChange.current.Department != undefined)) ) {
                    dropDownChange.current.Department = e
                    fetchData();
                }
                return true;
            }),
            ddlDesignation: Yup.string()
            .test("", "ChangeHandle", (e) => {
                if (e != dropDownChange.current.Designation && ((e != "") || (e == "" && dropDownChange.current.Designation != undefined))) {
                    dropDownChange.current.Designation = e
                    fetchData();
                }
                return true;
            })

    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, formState, watch, setValue } = useForm(formOptions);
    const { errors } = formState;




    useEffect(() => {
        async function FetchData() {
            const lctTenantinfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            let currentTenantDetail;
            if (props.TenantInfo.UserGroup == "SiteAdmin") {
                currentTenantDetail = getCompanyData;
            }
            else {
                currentTenantDetail = props.user.attributes["custom:tenantid"];
            } 
          
            if(currentTenantDetail!=undefined||currentTenantDetail!=null){
           const fetchActivityReport = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/text",
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                menuid: "115504",
                tenantid: currentTenantDetail,
            }
        });

        const getActivityReportData = await fetchActivityReport?.res?.text();
        getActivityReportData!=undefined && Object.keys(JSON.parse(JSON.parse(getActivityReportData)?.State)?.[0]).length==0 ?refRecordStatus.current = true:refRecordStatus.current = false;
        setValuedata(getActivityReportData);
        setValue("submit", false);
        setValue("fetch", false); 
            setFetchdata({
                plistXlmsTenantInfo: lctTenantinfo.res?.listXlmsTenantInfos?.items != undefined ? lctTenantinfo.res?.listXlmsTenantInfos?.items : [],
            });
        }
    }
        FetchData();
        return (() => {
            setFetchdata((temp) => { return { ...temp }; });
        });

    }, [getCompanyData, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, setValue, watch]);
   
    const dropdownData = useCallback(async () => {
        const tenantId = props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData :props.user.attributes["custom:tenantid"] ;

        const ltdrpDepartment = [{ value: "", text: "Filter by Department" }];
        const ltdrpDesignation = [{ value: "", text: "Filter by Designation" }];
        const ltdrcourselist = [{ value: "", text: "Filter by Course" }];
        const lctCustomFieldvalue = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const userData = lctCustomFieldvalue.res?.listXlmsCustomFields?.items != undefined ? lctCustomFieldvalue.res?.listXlmsCustomFields?.items : [];
        const lcourseData = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const courseData = lcourseData.res?.listXlmsCourseManagementInfo?.items;

        courseData?.map((getItem) => {
            if (getItem?.text?.toLowerCase() != "select") {
                ltdrcourselist.push({ value: getItem.CourseID, text: getItem.CourseName });
            }
        });

        userData && userData.filter((filterCustomValue) => {
            if (filterCustomValue?.ProfileFieldName == "Department") {
                JSON.parse(filterCustomValue?.FieldOptions)?.map((mDepartment) => {
                    if (mDepartment?.text?.toLowerCase() != "select") {
                        ltdrpDepartment.push({ value: mDepartment?.value, text: mDepartment?.text });
                    }
                });
            }
            if (filterCustomValue?.ProfileFieldName == "Designation") {
                JSON.parse(filterCustomValue?.FieldOptions)?.map((mDesignation) => {
                    if (mDesignation?.text?.toLowerCase() != "select") {
                        ltdrpDesignation.push({ value: mDesignation?.value, text: mDesignation?.text });
                    }
                });
            }

            setValueDesDep({ Department: ltdrpDepartment, Designation: ltdrpDesignation, Course: ltdrcourselist });
        });
    }, [getCompanyData, props.TenantInfo.UserGroup, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken]);

    useEffect(() => {
        dropdownData();
    }, [dropdownData]);

    const headerColumn = [
        { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/12" },
        { HeaderName: "Email", Columnvalue: "Email", HeaderCss: "w-1/12" },
        { HeaderName: "Assigned Activity", Columnvalue: "Activity", HeaderCss: "w-1/12" },
        { HeaderName: "Enrolled Date", Columnvalue: "EnrolledDate", HeaderCss: "w-2/12" },
        { HeaderName: "Date of Completion", Columnvalue: "CompletionDate", HeaderCss: "w-1/12" },
        { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "w-1/12" },
        { HeaderName: "Designation", Columnvalue: "Designation", HeaderCss: "w-1/12" },
        { HeaderName: "No.of Attempts", Columnvalue: "Attempts", HeaderCss: "w-1/12" },
        { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-0/12" },
    ];


   

    const selectCompany = useMemo(() => {
        let ltDefultSelect = [{ value: "", text: "Select Company" }];
        if (fetchdata?.plistXlmsTenantInfo?.length != undefined) {
            if (fetchdata?.plistXlmsTenantInfo?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin" && ltDefultSelect.length < 2) {
                fetchdata?.plistXlmsTenantInfo?.map((getItem) => ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
            } else if (props.TenantInfo.UserGroup != "SiteAdmin") {
                ltDefultSelect = [];

                const currentTenant = fetchdata?.plistXlmsTenantInfo?.filter(function (Tenant) {

                    return Tenant.TenantID == props?.TenantInfo?.TenantID;
                });
                currentTenant?.map((getItem) => {
                    ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName });
                });
            }
            return ltDefultSelect;
        }
    }, [fetchdata, props.TenantInfo?.TenantID, props.TenantInfo.UserGroup]);

    const fetchData = useCallback(async (e) => {
        let loginChange;
        setValue("fetch", true);
        if (e == undefined) {
            if (props.TenantInfo.UserGroup == "SiteAdmin") { loginChange = watch("ddlCompany") }
            else { loginChange = props.user.attributes["custom:tenantid"]; }
        }
        else { loginChange = e; }
       
        const courseId = watch("ddlCourse");
        
        const lstrUserName =watch("txtsearch").toUpperCase(); 
        let lqrywhere;
        
        
        lqrywhere = `Where  tenantid='${loginChange}'`;
        
        if (courseId != ""){
            lqrywhere += ` AND courseid='${courseId}'`
        }
        
        if (watch("ddlDepartment") != "") {
            lqrywhere += ` AND Department='${watch("ddlDepartment")}'`;
        }

        if (watch("ddlDesignation") != "") {
            lqrywhere += ` AND Designation='${watch("ddlDesignation")}'`;
        }
        
        if (lstrUserName != "") {
            lqrywhere += ` AND UPPER(UserName) LIKE '%${lstrUserName}%'`;
        }
        setCompanyData(loginChange)
        
        try {
            const headers = {
                "Content-Type": "application/text",
                authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                menuid: "115504",
                tenantid: loginChange,
            };

            const getUserDatas = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: headers,
                body: lqrywhere,
            });
            const userDatas = await getUserDatas?.res?.text();
            userDatas!=undefined && Object.keys(JSON.parse(JSON.parse(userDatas)?.State)?.[0]).length==0 ?refRecordStatus.current = true:refRecordStatus.current = false;
            setValuedata(userDatas);
        } catch (error){
            setValue("fetch", false);
            setValue("submit",false)
        }
        
        setValue("fetch", false);
        setValue("submit",false)

    }, [setValue, watch, props.TenantInfo.UserGroup, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken]);

    const submitHandler = async (data) => {   
        setValue("submit", true);
        fetchData()
    };

   

    const fileDownload = useCallback(
        async (e) => {
            setValue("download", true);
            if (e?.type == "click") {
            const lstrTenantID =props.TenantInfo.UserGroup == "SiteAdmin" ? getCompanyData :props.user.attributes["custom:tenantid"] ;


                const lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
                const headers = {
                    method: "POST",
                    headers: {
                        "Content-Type": "text/csv",
                        authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                        bucketname: process.env.REPORT_BUCKET_NAME,
                    },
                    body: `processed-data/${lstrTenantID}/${execID.current.QueryExecutionID}.csv`,
                };
                const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
                var win = window.open(await lstrFileDownload.res?.text(), "_self");
            }
            setValue("download", false);
        },
        [setValue, props.TenantInfo.UserGroup, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, getCompanyData]
    );

    

    const gridDataBind = useCallback((data) => {
        const rowGrid = [];
        let viewData = lstrFilterCourseData != undefined && lstrFilterCourseData.length > 0 && Object.values(JSON?.parse(lstrFilterCourseData));
        viewData = viewData?.[1] && JSON.parse(viewData?.[1]);
        execID.current = lstrFilterCourseData != undefined && lstrFilterCourseData.length > 0 && JSON?.parse(lstrFilterCourseData);
        
        viewData &&
            viewData.map((getItem, index) => {
                rowGrid.push({
                    UserName: <NVLlabel id={"txtName" + (index + 1)} text={getItem.UserName} />,
                    Email: <NVLlabel id={"txtEmail" + (index + 1)} text={getItem.EmailID} />,
                    Department: <NVLlabel id={"txtDept" + (index + 1)} text={getItem.Department} />,
                    Designation: <NVLlabel id={"txtDesgn" + (index + 1)} text={getItem.Designation} />,
                    EnrolledDate: <NVLlabel id={"txtEnrollDate" + (index + 1)} text={getItem.EnrolledDate} />,
                    CompletionDate: <NVLlabel id={"txtCompletiondate" + (index + 1)} text={getItem["DateofCompletion"]} />,
                    Attempts: <NVLlabel id={"txtAttempts" + (index + 1)} text={getItem.NoOfAttempts} className="pl-10" />,
                    Activity: <NVLlabel id={"txtActivity" + (index + 1)} text={getItem["Assigned Activity"]} />,
                    Status: <NVLlabel id={"txtStatus" + (index + 1)} text={getItem.Status} />,
                });
            });
        return rowGrid;
    }, [lstrFilterCourseData]);

    const pageRoutes = useMemo(() => {
        return [
            { path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard" },
            { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
            { path: "", breadcrumb: "Activity Completion Report" },
        ];
    }, []);
    return (
        <>
            <Container title="Course Activity Report" PageRoutes={pageRoutes} loader={Object.keys(fetchdata) == 0}>
                <div className={watch("submit") || watch("download") || watch("fetch") ? "pointer-events-none" : ""}>
                    <form onSubmit={handleSubmit(submitHandler)} className="px-2">
                        <div className="px-3" id="divFilter">
                            <div className="block rounded-lg ">
                                <NVLlabel text="Company Name" className="nvl-Def-Label"></NVLlabel>
                                <NVLSelectField id="ddlCompany" errors={errors} options={selectCompany} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled mt-1 block w-64 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" : ""} mt-1 block w-64 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm`} disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} register={register}></NVLSelectField>
                                <div className="py-3">
                                    <div className="grid grid-cols-12 grid-flow-col gap-4">
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Course Name" className="nvl-Def-Label"></NVLlabel>
                                            <NVLSelectField id="ddlCourse" errors={errors} options={lstDesDepData.Course} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
                                        </div>
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Designation" className="nvl-Def-Label"></NVLlabel>
                                            <NVLSelectField id="ddlDesignation" className={ "mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"} register={register} options={lstDesDepData.Designation} errors={errors} />
                                        </div>
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Department" className="nvl-Def-Label"></NVLlabel>
                                            <NVLSelectField id="ddlDepartment" className={"mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm"} register={register} options={lstDesDepData.Department} errors={errors} />
                                        </div>                                    
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Search by User Name"  className="nvl-Def-Label"></NVLlabel>
                                            <NVLTextbox id="txtsearch" className={"mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"} register={register} errors={errors} title="Filter by user name" />
                                        </div>

                                        <div className="col-span-6 sm:col-span-3 pt-4">
                                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""} disabled={watch("submit")  ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-indigo-500 text-white !h-10" : "w-28 nvl-button !bg-indigo-500 text-white !h-10"}>
                                                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                                            </NVLButton>
                                        </div>
                                        <div className="col-span-6 sm:col-span-3 pt-4">
                                            <div className="flex items-center">
                                                <NVLButton type={"button"} 
                                                className={refRecordStatus.current ? "nvl-button bg-primary Disabled !h-10" : "nvl-button !h-10 inline-flex justify-center rounded-md border border-transparent bg-indigo-500 py-2 px-4  pt-3 text-sm font-medium text-white shadow-sm hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"}
                                                disabled={refRecordStatus.current ? true : false} onClick={(e) => fileDownload(e)}>
                                                    <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                                </NVLButton>
                                                <div className="pb-2 pl-1">
                                                    <NVLlabel CustomCss="-translate-x-72 pt-4" className="nvl-Def-Label pb-1" HelpInfo={"You can download more report details here"} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {!watch("fetch") && <div>
                            <NVLGridTable id="tblCourseActivityList" className="max-w-full" HeaderColumn={headerColumn} RowGridDataPass={{ RowGrid: refRecordStatus?.current ? [] : gridDataBind() }} />
                        </div>}
                        {watch("fetch") && <div className="pt-8">
                            <NVLLoadingSpinner />
                        </div>}
                    </form>
                </div>
            </Container>
        </>
    );
}

export default ActivityWiseCourseReport;
