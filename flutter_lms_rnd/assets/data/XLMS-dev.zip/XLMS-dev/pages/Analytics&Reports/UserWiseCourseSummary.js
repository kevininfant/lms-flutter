import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import UserWiseCourseMailing from "@Pages/Analytics&Reports/UserWiseCourseMailing";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";


function UserWiseCourseReport(props) {
    const router = useRouter();
    const [getCompanyData] = useState(props.TenantInfo.TenantID);
    const [userEmail, setUserEmail] = useState("");
    const [open, setOpen] = useState(false);
    const [popUpName, setPopupName] = useState("");
    const getDesDepData = useRef({ Department: [{ value: "", text: "Filter by Department" }], Designation: [{ value: "", text: "Filter by Designation" }] });
    const [pageData, setPageData] = useState({});
    const ddlData = useRef({ TenantID: props.TenantInfo.TenantID, Department: "", Designation: "", UserName: "", Change: false });
    const [griddata,SetGridData]=useState({ Page: 0 });


const newFilter=useCallback((gridDataBind, Page) => {
    ddlData.current = { ...ddlData.current, Change: true };
    SetGridData((temp) => {
      if (temp.Page == 0 && ddlData.current.Change) {
        gridDataBind(Page, true);
        return temp;
      }
      else {
        return { ...temp, Page: 0 }
      }
    })
  }, []);


    const validationSchema = Yup.object().shape({
        ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" && Yup.string().required("Company is required").test("", "", (e) => {
            if (e != ddlData.current.TenantID && e != "" && e != undefined) {
              ddlData.current = { TenantID: e, Department: "", Designation: "", UserName: "" };
              setValue("ddlDepartment", ""); setValue("ddlDesignation", ""); setValue("txtUserName", ""); newFilter(gridDataBind, griddata.Page);
              dropdownData();
            } return true;
          }),
         ddlDepartment:Yup.string()
         .test("", "changehandler", (e) => {
             if (e != ddlData?.current.Department&& ((e != "") || (e == "" && ddlData?.current.Department != undefined))) {
                ddlData.current.Department=e;
                newFilter(gridDataBind,griddata.Page)
             } 
             return true;
         }),
         ddlDesignation:Yup.string()
         .test("", "handler", (e) => {
             if (e != ddlData?.current.Designation && ((e != "") || (e == "" && ddlData?.current.Designation  != undefined)) ) {
                ddlData.current.Designation = e;
                newFilter(gridDataBind,griddata.Page)
             } 
             return true;
         }),
         txtsearch:Yup.string().test("", "ChangeHandler", (e) => {
            if (e != ddlData.current.UserName && e != "" && e != undefined) {
              ddlData.current = { ...ddlData.current, UserName: e };
            }
            else {
              ddlData.current = { ...ddlData.current, UserName: e };
            }
            return true;
          })
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, formState, watch, setValue } = useForm(formOptions);
    const { errors } = formState;

   

    const initialModalState = useMemo(() => {
        return {
            ModalInfo: "Success",
            ModalTopMessage: "Success",
            ModalBottomMessage: "Mail sent successfully.",
            ModalOnClickEvent: () => {
                router.push("/Analytics&Reports/UserWiseCourseSummary");
            }
        };
    }, [router]);

    const getOffsetInfo = useCallback((Page) => {
        const pageOffset = Page ? Page : 0;
        return `ORDER BY lastmodifieddate,UserName  ASC
                       OFFSET ${pageOffset * process.env.PAGEGRIDSIZE} ROWS
                       FETCH NEXT ${process.env.PAGEGRIDSIZE} ROWS ONLY`;
      }, []);

    const [modalValues, setModalValues] = useState(initialModalState);
    const headerColumn = [
        { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/2" },
        { HeaderName: "EmailId", Columnvalue: "EmailId", HeaderCss: "w-1/2" },
        { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "w-1/2" },
        { HeaderName: "Designation", Columnvalue: "Designation", HeaderCss: "w-1/2" },
        { HeaderName: "Courses Enrolled", Columnvalue: "CoursesEnrolled", HeaderCss: "w-1/2" },
        { HeaderName: "Courses Completed", Columnvalue: "CoursesCompleted", HeaderCss: "w-1/2" },
        { HeaderName: "Total Seat Time", Columnvalue: "SeatTime", HeaderCss: "w-1/2" },
        { HeaderName: "Notification", Columnvalue: "Notification", HeaderCss: "w-1/2" },
        { HeaderName: "Team", Columnvalue: "Team", HeaderCss: "w-1/2" },
    ];

    const fetchGridData = useCallback(async () => {
        const tenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
        const temp = {
          listXlmsTenantInfo: tenantInfo?.res?.listXlmsTenantInfos?.items != undefined ? tenantInfo.res?.listXlmsTenantInfos?.items : [],
          tenantId: ddlData.current.TenantID,
        };
        setPageData(temp);
      }, [props.user.signInUserSession.accessToken.jwtToken]);

      useEffect(() => {
        fetchGridData();
        return () => {
          setPageData((temp) => {
            return { ...temp };
          });
        };
      }, [fetchGridData]);

    const selectCompany = useMemo(() => {
        if (pageData?.listXlmsTenantInfo != undefined) {
          let ltDefultSelect = [{ value: "", text: "Select Company" }];
          if (pageData.listXlmsTenantInfo?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin" && ltDefultSelect.length < process.env.PAGEGRIDSIZE) {
            pageData.listXlmsTenantInfo?.map((getItem) => ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
          } else if (props.TenantInfo.UserGroup != "SiteAdmin") {
            ltDefultSelect = [];
            const currentTenant = pageData.listXlmsTenantInfo?.filter(function (Tenant) {
              return Tenant.TenantID == pageData.tenantId;
            });
            currentTenant?.map((getItem) => {
              ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName });
            });
          }
          return ltDefultSelect;
        }
      }, [pageData.listXlmsTenantInfo, pageData.tenantId, props.TenantInfo.UserGroup]);

    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: finalStatus,
            });
            ModalOpen();
            return;
        }
        setModalValues(initialModalState);
        ModalOpen();

    }, [initialModalState]);
    
    const pageChangeCall = useCallback((currentPage) => {
        SetGridData((temp) => {
          if (temp.Page < currentPage) {
            gridDataBind(currentPage)
            return { ...temp, Page: currentPage };
          }
          else {
            return temp;
          }
        })
      }, [gridDataBind]);

    const fileDownload = useCallback(async (e) => {
        setValue("download", true);
        let lqrywhere;
        const lstrDepartment = ddlData?.current?.Department;
        const lstrDesignation = ddlData?.current?.Designation;
        lqrywhere = `WHERE tenantid='${ddlData?.current?.TenantID}'`;
        if (lstrDepartment != "") {
          lqrywhere += ` AND Department='${lstrDepartment}'`;
        }
        if (lstrDesignation != "") {
          lqrywhere += ` AND Designation='${lstrDesignation}'`;
        }
        if (ddlData.current.UserName != "") {
          lqrywhere += ` AND UPPER(UserName) LIKE UPPER('%${ddlData.current.UserName}%')`;
        }
        if (e?.type == "click") {
          const lstrPresignedFileURL = process.env.APIGATEWAY_REPORT_URL+`?ReportType=Download`;
          const headers = {
              method: "POST",
              headers: {
                  "Content-Type": "text/csv",
                  authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                  tenantid: ddlData?.current?.TenantID,
                  groupmenuname:"Analytics&Report",
                  defaultrole:props?.TenantInfo.UserGroup,
                  menuid: "115400"
              },
              body: `${lqrywhere}`,
          };
          const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
        if(lstrFileDownload?.Status=="Success"){
          setValue("popup",true)
        }else{
          setValue("popup",false)
    
        }
      }
        setValue("download", false);
      },[props?.TenantInfo.UserGroup, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue])

    const getComponent = useCallback(
        (popUpName) => {
            const componentData = {
                Mail: (
                    <UserWiseCourseMailing
                        user={props?.user}
                        setOpen={setOpen}
                        open={open}
                        TenantInfo={props.TenantInfo}
                        Mode="Popup"
                        modalValues={modalValues}
                        FinalResponse={finalResponse}
                        UserEmail={userEmail}
                    />
                ),
            };
            return componentData[popUpName];
        },
        [finalResponse, userEmail, modalValues, open, props.TenantInfo, props?.user]
    );

    const dropdownData = useCallback(async () => {
        const ltdrpDepartment = [{ value: "", text: "Filter by Department" }];
        const ltdrpDesignation = [{ value: "", text: "Filter by Designation" }];
        const lctCustomFieldvalue = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + ddlData.current.TenantID, SK: "CUSTOMFIELD#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const userData = lctCustomFieldvalue.res?.listXlmsCustomFields?.items;
        userData &&
          userData.filter((filterCustomValue) => {
            if (filterCustomValue?.ProfileFieldName == "Department") {
              JSON.parse(filterCustomValue?.FieldOptions)?.map((mDepartment) => {
                if (mDepartment?.text?.toLowerCase() != "select") {
                  ltdrpDepartment.push({ value: mDepartment?.value, text: mDepartment?.text });
                }
              });
            }
            if (filterCustomValue?.ProfileFieldName == "Designation") {
              JSON.parse(filterCustomValue?.FieldOptions)?.map((mDesignation) => {
                if (mDesignation?.text?.toLowerCase() != "select") {
                  ltdrpDesignation.push({ value: mDesignation?.value, text: mDesignation?.text });
                }
              });
            }
            getDesDepData.current = { Department: ltdrpDepartment, Designation: ltdrpDesignation };
          });
      }, [props?.user?.signInUserSession?.accessToken?.jwtToken]);

    useEffect(() => {
        dropdownData("");
    }, [dropdownData]);
   

    const submitHandler = async (data) => {
        setValue("submit", true);
        newFilter(gridDataBind,griddata.Page)
        setValue("submit", false);
    };
    const gridDataBind = useCallback(async(Page,Filter) => {

    let tempTrue = ddlData.current?.Change || Filter;
    ddlData.current = { ...ddlData.current, Change: false };

    setValue("fetch", true);
    const GetGridTableDetails=(filterdata)=>
    {
        const rowGrid = [];
        const tmpViewData = filterdata != undefined && Object.values(JSON?.parse(filterdata));
        const viewData = tmpViewData?.[1] != undefined && JSON.parse(tmpViewData?.[1]);
        if (viewData && viewData?.length == 1 && Object.keys(viewData?.[0]).length == 0) {
            return [];
        } else {
            viewData && viewData.map((getItem, index) => {
                rowGrid.push({
                    UserName: <NVLlabel id={"txtName" + (index + 1)} text={getItem.UserName} />,
                    Department: <NVLlabel id={"txtdept" + (index + 1)} text={getItem.Department} />,
                    EmailId: <NVLlabel id={"txtemail" + (index + 1)} text={getItem.EmailId} />,
                    Designation: <NVLlabel id={"txtDesg" + (index + 1)} text={getItem.Designation} />,
                    CoursesEnrolled: <NVLlabel id={"txtEnrolled" + (index + 1)} text={getItem.CoursesEnrolled} className="pl-10" />,
                    CoursesCompleted: <NVLlabel id={"txtCompleted" + (index + 1)} text={getItem.CoursesCompleted} className="pl-10" />,
                    SeatTime: <NVLlabel id={"txtTime" + index + 1} text={getItem.TotalSeatTime} />,
                    Notification: getItem && Object.entries(getItem).length != 0 && <NVLLink id={"txtNotify" + (index + 1)} title={"Mail"} text={"Mail"} className="cursor-pointer"
                        onClick={() => {
                            setPopupName("Mail");
                            setUserEmail(getItem.EmailId);
                            setOpen((open) => {
                                return open + 1;
                            });
                        }}></NVLLink>,

                    Team: getItem && Object.entries(getItem).length != 0 && <NVLLink id={"txtTeam" + (index + 1)}
                        title={getItem?.TEAM} onClick={() => router.push(`/Home/UserTeam?EmailId=${getItem.EmailId}&UserName=${getItem.UserName}&TenantId=${getCompanyData}`)}
                        text={getItem?.TEAM} className="cursor-pointer" ></NVLLink>,
                })
            });
        } 
        return rowGrid;
    }
    const lstrDepartment = ddlData?.current?.Department;
    const lstrDesignation = ddlData?.current?.Designation;
    let lqrywhere=`where Status='Active'`;
    if (lstrDepartment != "") {
        lqrywhere += ` AND Department='${lstrDepartment}'`;
      }
      if (lstrDesignation != "") {
        lqrywhere += ` AND Designation='${lstrDesignation}'`;
      }
      if (ddlData.current.UserName != "") {
        lqrywhere += ` AND UPPER(UserName) LIKE UPPER('%${ddlData.current.UserName}%')`;
      }
      const fetchLoginData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL,{
        method: "POST",
        headers: {
            "Content-Type": "application/text",
            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
            menuid: "115400",
            tenantid: ddlData.current.TenantID,
            defaultrole: props.TenantInfo.UserGroup,
            groupmenuname: "Analytics&Report",
        },
        body: `${lqrywhere} ${getOffsetInfo(Page)}`
    });
    const setUserCourseData = await fetchLoginData?.res?.text();
    const rowGrid=GetGridTableDetails(setUserCourseData);
    if (tempTrue) {
        if (rowGrid?.length > 0) {
          SetGridData((temp) => {
            return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
          })
        }
        else {
          SetGridData((temp) => {
            return { ...temp, TotalCount: 0, rowGrid: [] };
          })
        }
      }
      else {
        if (rowGrid?.length > 0) {
          SetGridData((temp) => {
            if (temp?.rowGrid?.length > 0)
              return { ...temp, rowGrid: [...temp.rowGrid, ...rowGrid], TotalCount: parseInt((temp?.rowGrid?.length + rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
            else
              return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
          })
        }
        else {
          SetGridData((temp) => {
            if (temp?.rowGrid?.length > 0)
              return { ...temp, TotalCount: temp?.rowGrid?.length / process.env.PAGEGRIDSIZE, ShowContentAndReducePage: temp?.ShowContentAndReducePage != undefined ? temp.ShowContentAndReducePage + 1 : 1 };
            else
              return { ...temp, TotalCount: 0 };
          })
        }
      }
    setValue("fetch",false);
    }, [getCompanyData, getOffsetInfo, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, router, setValue]);

    useEffect(() => {
        if (props.TenantInfo.UserGroup != "SiteAdmin")
          gridDataBind(0);
      }, [gridDataBind, props.TenantInfo.UserGroup])

    const pageRoutes = useMemo(() => {
        return [
            { path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard" },
            { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
            { path: "", breadcrumb: "User Wise Course Summary" }

        ];
    }, []);

    return (
        <>
            <NVLPageModalPopup
                ModalType="Page"
                ScreenName={"Course Notification Mail"}
                PageComponent={getComponent(popUpName)}
                open={open}
                setOpen={setOpen}
                user={props?.user}
            />

            <Container title="User Course Summary Report" PageRoutes={pageRoutes}>
                <div className={watch("submit") || watch("download") || watch("fetch") ? "pointer-events-none" : ""}>
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <form onSubmit={handleSubmit(submitHandler)} className="px-2">
                        <div className="px-3" id="divFilter">
                            <div className="block rounded-lg ">
                                <div className="py-3">
                                    <div className="grid grid-cols-12 grid-flow-col gap-4">
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Company Name" className="nvl-Def-Label">
                                            </NVLlabel>
                                            <NVLSelectField id="ddlCompany" errors={errors} options={selectCompany} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" : ""} mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm`} disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} register={register}></NVLSelectField>
                                        </div>
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Department" className="nvl-Def-Label">

                                            </NVLlabel>
                                            <NVLSelectField id="ddlDepartment" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={getDesDepData?.current?.Department} errors={errors} />
                                        </div>
                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Designation" className="nvl-Def-Label">

                                            </NVLlabel>
                                            <NVLSelectField id="ddlDesignation" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={getDesDepData?.current?.Designation} errors={errors} />
                                        </div>

                                        <div className="col-span-6 sm:col-span-3">
                                            <NVLlabel text="Search by User Name" className="nvl-Def-Label">

                                            </NVLlabel>
                                            <NVLTextbox id="txtsearch" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by user name" />
                                        </div>
                                        <div className="col-span-6 sm:col-span-3 pt-4">
                                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""} disabled={watch("submit") ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-primary text-white !h-10" : "w-28 nvl-button !bg-primary text-white !h-10"}>
                                                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                                            </NVLButton>
                                        </div>
                                        <div className="col-span-6 sm:col-span-3 pt-4">
                                            <div className="flex items-center">
                                                <NVLButton type={"button"} 
                                                className={griddata?.rowGrid?.length==0||griddata?.rowGrid?.length==undefined ||watch("download")? "nvl-button bg-primary Disabled !h-10" : "nvl-button !bg-primary  text-white  shadow-sm hover:bg-primary focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 !h-10" }
                                                disabled={griddata?.rowGrid?.length==0||griddata?.rowGrid?.length==undefined ||watch("download")? true : false} 
                                                onClick={(e) => fileDownload(e)}>
                                                    <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                                </NVLButton>
                                                <div className="pb-2 pl-1">
                                                    <NVLlabel
                                                        CustomCss="-translate-x-72 pt-4"
                                                        className="nvl-Def-Label pb-1"
                                                        HelpInfo={"You can download more report details here"}
                                                        HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {!watch("fetch") && <div>
                            <NVLGridTable id="tblUserCourseList" className="max-w-full" HeaderColumn={headerColumn}
                                RowGridDataPass={{ RowGrid: griddata?.rowGrid!==undefined?griddata?.rowGrid:[]}}
                                pageSize={process.env.PAGEGRIDSIZE}
                                ShowContentAndReducePage={griddata.ShowContentAndReducePage}
                                TotalCount={griddata.TotalCount}
                                pageChangeCall={pageChangeCall}
                                DonotLoad={false} currentPageFront={griddata.Page}  />
                        </div>}
                        <div>
                            {watch("fetch") == true && <NVLLoadingSpinner />}
                        </div>
                    </form>
                </div>
                {watch("popup")&&<NVLModalPopup CancelClick={()=>router.push("/Analytics&Reports/ReportList")} ButtonNotext="OK"  Content={"Download in progress ....You will be notified once the download is completed. The file can be downloaded from the notification"} />}  
            </Container>
        </>

    );
}

export default UserWiseCourseReport;


