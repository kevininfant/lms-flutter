import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function UserWiseCourseMailing(props) {
    const [message, setMessage] = useState("");

    const validationSchema = Yup.object().shape({
        txtContent: Yup.string()
            .test("", "Content is required", () => {
                if (message?.editor.delta.ops[0]["insert"]?.replaceAll(/(<([^>]+)>)/gi, "re")?.trim().length == 0 || getContents(message)?.replaceAll(/(<([^>]+)>)/gi, "")?.length == 0) {
                    document.getElementById("content_errors")?.classList.remove("hidden");
                    return false;
                }
                document.getElementById("content_errors")?.classList.add("hidden");
                return true;

            }).nullable()
    });
    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };
    const { handleSubmit, setValue, watch, formState } =
        useForm(formOptions);
    const { errors } = formState;

    const clearForm = useCallback(() => {
        document.getElementById("content_errors")?.classList.add("hidden");
        if (message != "") {
            setHTMLContents("", message);
        }
    }, [message]);

    useEffect(() => {
        if (props.open == 1) {
            clearForm();
        }
    }, [message, clearForm, props.open]);



    useEffect(() => {
        if (message != "") {
            message?.on("text-change", () => {
                if (getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {
                    setValue("random", "Empty", { shouldValidate: true });
                } else {
                    setValue("random", "NotEmpty", { shouldValidate: true });
                }
            });
        }
    }, [message, setValue]);

    const submitHandler = async () => {
        setValue("submit", true);
        var messageTemp = getContents(message);
        if (messageTemp == "") {
            setValue("txtContent", "Empty", { shouldValidate: true });
        }

        var fetchURL = process.env.APIGATEWAY_USERWISE_COURSE_NOTIFICATION_URL;
        const emailId = props.UserEmail;

        /* // eslint-disable-next-line quotes*/
        const jsonSaveData = {MessageContent:messageTemp,EmailID:emailId };
        const headers = {
            method: "POST",
            headers: {
                Authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
                defaultrole: props?.TenantInfo.UserGroup,
                groupmenuname: "Analytics&Report",
                menuid: "115400",
            },
            body:JSON.stringify(jsonSaveData),
        };
        const finalStatus = await APIGatewayPostRequest(fetchURL, headers);
        props.FinalResponse(finalStatus.Status);
        setValue("submit", false);
        clearForm();
    };

    return (
        <>
            <Container title="Course Notification Mail">
                <form onSubmit={handleSubmit(submitHandler)}>
                    <div className="pl-28">
                        <NVLlabel text="Mail Content" className="nvl-Def-Label" />
                        <NVLRichTextBox id="txtModuleDescription" className="isResizable nvl-mandatory nvl-Def-Input" setState={setMessage} max={"250"} />
                        <div id="content_errors" className="{invalid-feedback} text-red-500 text-sm pt-2">
                            {errors?.txtContent?.message}
                        </div>
                        <div className="flex gap-1 pt-2 pl-28">
                            <NVLButton id="btnSend"
                                type="submit"
                                className={"w-28 nvl-button bg-primary text-white "}
                                text={!watch("submit") ? "Send" : ""} >
                                {
                                    watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
                                }
                            </NVLButton>
                            <NVLButton id="btnClear" disabled={watch("submit")} text={"Clear"} type="button" className="nvl-button w-28"
                                onClick={() => clearForm()}
                            />
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default UserWiseCourseMailing;
