import Container from "@components/Container/Container";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLButton from "@components/Controls/NVLButton";
import { useRouter } from "next/router";
import { useMemo } from "react";


export default function ReportDashboard() {
    const router = useRouter();
    const pageRoutes = useMemo(()=>{return[
        {path: "", breadcrumb: "Reports Dashboard" }
    ];},[]);

    return (
        <>
            <Container title="Analytics And Reports">
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <div className="flex gap-2 px-3">
                    <NVLButton id="btnCancel" text={"Analytics"} type="reset" className="nvl-button w-32 !font-semibold" onClick={() => router.push("/")} />
                    <NVLButton id="btnCancel" text={"Report"} type="reset" className="nvl-button w-32 !font-semibold" onClick={() => router.push("/Analytics&Reports/ReportList")} />
                </div>
            </Container>
        </>
    );
}
