import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingIndicator";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import { yupResolver } from "@hookform/resolvers/yup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { useForm } from "react-hook-form";
import { listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";


Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

function ActivityELearning(props) {

    const currentYear = useMemo(() => { return new Date().getFullYear(); }, []);
    const refLearningHours = useRef();
    const [GridData, SetGridData] = useState({ Page: 0 });
    const totalhrs=useRef();
    const ddlData = useRef({ TenantID: props?.TenantInfo?.TenantID, Year: currentYear, Change: false });
    const router = useRouter();
    const refCourseCount = useRef();
    const pageRoutes = useMemo(() => {
        let temp = [{ path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard" },
        { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" }]
        if (props.TenantInfo.UserGroup == "SiteAdmin") {
            temp = [...temp, { path: `/Analytics&Reports/UserWiseActivitySummary?TenantId=${router.query["TenantId"]}`, breadcrumb: "User Wise Activity Summary" }]
        }
        else {
            temp = [...temp, { path: "/Analytics&Reports/UserWiseActivitySummary", breadcrumb: "User Wise Activity Summary" }]
        }
        temp = [...temp, { path: "", breadcrumb: "Activity ELearning Report" }]
        return temp;
    }, [props.TenantInfo.UserGroup, router.query]);
    const userFiltration = useCallback((gridDataBind, Page) => {
        ddlData.current = { ...ddlData.current, Change: true };
        SetGridData((temp) => {
            if (temp.Page == 0 && ddlData.current.Change) {
                gridDataBind(Page, true);
                return temp;
            }
            else {
                return { ...temp, Page: 0 }
            }
        })
    }, []);

    const validationSchema = Yup.object().shape({

        ddlYear: Yup.string().test("", "ChangeHandler", (e) => {
            if (e != ddlData.current.Year && e != "" && e != undefined) {
                ddlData.current = { ...ddlData.current, Year: e };
                userFiltration(gridDataBind, GridData.Page);
            }
            else {
                ddlData.current = { ...ddlData.current, Year: e };
            }
            return true;
        }),


    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, formState, watch, setValue } = useForm(formOptions);
    const { errors } = formState;

    //get Current Page offset value
    const getOffsetInfo = useCallback((Page) => {
        const pageOffset = Page ? Page : 0;
        return `group by activityname,activitytype,completedstatus,enrolleddate,seattime order by UPPER(activitytype) asc,UPPER
                         (activityname) asc
                     OFFSET ${pageOffset * process.env.PAGEGRIDSIZE} ROWS
                     FETCH NEXT ${process.env.PAGEGRIDSIZE} ROWS ONLY`;
    }, []);

    const fetchGridData = useCallback(async (e) => {
        const tenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
        const temp = {
            listXlmsTenantInfo: tenantInfo?.res?.listXlmsTenantInfos?.items != undefined ? tenantInfo.res?.listXlmsTenantInfos?.items : [],
            tenantId: ddlData.current.TenantID,
        };

    }, [props.user.signInUserSession.accessToken.jwtToken]);

  

    
    const completedStatus = useMemo(() => {
        const yearData = [{ value: currentYear, text: currentYear }];
        for (let i = (currentYear - 1); i >= 1990; i--) {
            yearData.push({ value: i, text: i });
        }
        return yearData;

    }, [currentYear]);
    
  

        const headerColumn = [
        { HeaderName: "ActivityName", Columnvalue: "activityname", HeaderCss: "!w-4/12" },
        { HeaderName: "ActivityType", Columnvalue: "activitytype", HeaderCss: "!w-2/12" },
        { HeaderName: "Seat Time(HH:MM:SS)", Columnvalue: "seattime", HeaderCss: "!w-2/12" },
        { HeaderName: "% Completion", Columnvalue: "CompletionStatus", HeaderCss: "!w-2/12" },
        { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-2/12" },
    ];


    const gridDataBind = useCallback(async (Page, Filter) => {
        const courseEnrolledCount = [];
        let tempTrue = ddlData.current?.Change || Filter;
        ddlData.current = { ...ddlData.current, Change: false };
        setValue("fetch", true);

        const GetGridTableDetails = (filterLoginData) => {
            const rowGrid = [];
            let viewData = filterLoginData != undefined && Object.values(JSON?.parse(filterLoginData));
            viewData = viewData && JSON?.parse(viewData?.[1]);
            if (viewData && viewData?.length == 1 && Object.keys(viewData?.[0]).length == 0) {
                return [];
            } else {

                viewData &&
                    viewData.map((getItem, index) => {
                        if (getItem?.seattime != "") {
                            courseEnrolledCount.push(getItem?.seattime);
                        }
                        rowGrid.push({
                            activityname: <NVLlabel id={"txtName" + (index + 1)} text={getItem.activityname} className="py-2" />,
                            activitytype: <NVLlabel id={"txtdept" + (index + 1)} text={getItem.activitytype} />,
                            seattime: <NVLlabel id={"txtEnrolled" + (index + 1)} text={getItem.seattime} className="pl-10" />,
                            CompletionStatus: <NVLlabel id={"txt.Completed" + (index + 1)} text={getItem.completedstatus} className="pl-10" />,
                            Status: <NVLlabel id={"txtTime" + index + 1} text={getItem.Status} />,
                        });
                    });

                    let getTime=0;
                     const totalSeconds = courseEnrolledCount?.reduce((acc, val) => { 
                       const [hours, minutes, seconds] =val==undefined?[0,0,0]:(val?.split(':').map(Number));           
                       getTime+=((hours * 3600) + (minutes * 60) + seconds)
                       return getTime;
                     }, 0);        
                     
                     const hours = Math.floor(totalSeconds / 3600);
                     const minutes = Math.floor((totalSeconds - hours * 3600) / 60);
                     const seconds = totalSeconds % 60;
                     
                     const totalTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                     const [Hour,Min,Sec] = totalTime.split(":").slice(0,3)
            
                    refLearningHours.current = Hour +"."+ Min;
                    totalhrs.current=Hour+":"+Min+":"+Sec;
                return rowGrid;
            }
        };
       
        const lstrYear = ddlData?.current?.Year;
        let lqrywhere;
        lqrywhere = `WHERE enrolleddate like '%${lstrYear}%'`;
       


        const fetchData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/text",
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                menuid: "115405",
                defaultrole: props.TenantInfo.UserGroup,
                groupmenuname: "Analytics&Report",
                tenantid: ddlData?.current?.TenantID,
                usersub: router.query["UserSub"],
            },
            body: `${lqrywhere} ${getOffsetInfo(Page)}`,
        });
        const setUserActivityData = await fetchData?.res?.text();
        const rowGrid = GetGridTableDetails(setUserActivityData);
       
        if (tempTrue) {
            if (rowGrid?.length > 0) {
                SetGridData((temp) => {
                    return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
                })
            }
            else {
                SetGridData((temp) => {
                    return { ...temp, TotalCount: 0, rowGrid: [] };
                })
            }
        }
        else {
            if (rowGrid?.length > 0) {
                SetGridData((temp) => {
                    if (temp?.rowGrid?.length > 0)
                        return { ...temp, rowGrid: [...temp.rowGrid, ...rowGrid], TotalCount: parseInt((temp?.rowGrid?.length + rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
                    else
                        return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
                })
            }
            else {
                SetGridData((temp) => {
                    if (temp?.rowGrid?.length > 0)
                        return { ...temp, TotalCount: temp?.rowGrid?.length / process.env.PAGEGRIDSIZE, ShowContentAndReducePage: temp?.ShowContentAndReducePage != undefined ? temp.ShowContentAndReducePage + 1 : 1 };
                    else
                        return { ...temp, TotalCount: 0 };
                })
            }
        }
        setValue("fetch", false);
    }, [getOffsetInfo, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, router.query, setValue])

   

    const fileDownload = useCallback(async (e) => {
        setValue("download", true);
        let lqrywhere;
        const lstrYear = ddlData?.current?.Year;
        lqrywhere = `WHERE enrolleddate like '%${lstrYear}%'`;
       

        if (e?.type == "click") {
            const lstrPresignedFileURL = process.env.APIGATEWAY_REPORT_URL + `?ReportType=Download`;
            const headers = {
                method: "POST",
                headers: {
                    "Content-Type": "text/csv",
                    authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                    tenantid: ddlData?.current?.TenantID,
                    groupmenuname: "Analytics&Report",
                    defaultrole: props?.TenantInfo.UserGroup,
                    menuid: "115405",
                    usersub: router.query["UserSub"],
                },
                body: `${lqrywhere}`,
            };
            const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
            if (lstrFileDownload?.Status == "Success") {
                setValue("popup", true)
            } else {
                setValue("popup", false)

            }
        }
        setValue("download", false);
    }, [props?.TenantInfo.UserGroup, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue]);
    const pageChangeCall = useCallback((currentPage) => {
        SetGridData((temp) => {
            if (temp.Page < currentPage) {
                gridDataBind(currentPage)
                return { ...temp, Page: currentPage };
            }
            else {
                return temp;
            }
        })
    }, [gridDataBind]);

    useEffect(() => {
        fetchGridData();

        if (props.TenantInfo.UserGroup != "SiteAdmin")
            gridDataBind(0);
    }, [fetchGridData, gridDataBind, props.TenantInfo.UserGroup])

    const GridTable = useCallback((props) => {
        if (!props.watch("fetch"))
            return (
                <div>
                    <NVLGridTable id="tblEnrollList" className="max-w-full" HeaderColumn={props.headerColumn} RowGridDataPass={{ RowGrid: props.GridData.rowGrid != undefined ? props.GridData.rowGrid : [] }} pageChangeCall={props.pageChangeCall} TotalCount={props.GridData.TotalCount} pageSize={process.env.PAGEGRIDSIZE} ShowContentAndReducePage={props.GridData.ShowContentAndReducePage} DonotLoad={false} currentPageFront={props.GridData.Page} />
                </div>);
        else {
            return (
                <div className="pt-8">
                    <NVLLoadingSpinner />
                </div>
            )
        }
    }, [])
    const doughnutProgress = {

        datasets: [
            {
                data: [refLearningHours.current && refLearningHours.current, 100],
                backgroundColor: [
                    "yellow",
                    "gray"
                ],
            }
        ]
    };

    const doughnutOptions = {
        responsive: false,
        elements: {
            arc: {
                borderWidth: 0,
            },
        },
        plugins: {
            legend: {
                position: "right",
                display: true,
                labels: {
                    padding: 25,
                    boxWidth: 50,
                    usePointStyle: true,
                    font: {
                        family: "Montserrat, sans-serif",
                        size: 12,
                    },
                },
            },
        },
        cutout: "80%",
        maintainAspectRatio: false,
    };
    return (
        <>
            <Container title="User Activity Summary Report" PageRoutes={pageRoutes} loader={props?.TenantInfo?.TenantID == undefined}>
                <div className={watch("download") ? "pointer-events-none" : ""}>
                    {watch("fetch") ? <NVLLoadingSpinner /> : <div><form className="px-1">
                        <div className=" flex gap-4 col-span-6 sm:col-span-3 justify-center">
                            <NVLlabel htmlFor="Year" className="block text-sm font-medium text-gray-600 py-2">
                                Select Year :
                            </NVLlabel>
                            <NVLSelectField id="ddlYear" className="mt-1 block w-36 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={completedStatus} errors={errors} />
                        </div>
                        <div className="px-2 flex justify-center py-2" id="divFilter">
                            <div className="block rounded-lg py-4 ">
                                <div className="py-3 pb-4">
                                    <div className="grid place-content-center ">
                                        <NVLSettingsCard outerclass=" rounded-md px-4 w-full relative p-2 md:p-0">
                                            <Doughnut data={doughnutProgress} options={doughnutOptions} class="DoughnutClass" />
                                            <div className="absolute !top-10 !left-[31%] md:top-4  text-center text-xs font-semibold   rounded-full">
                                                <div>{(refCourseCount.current && Object.values(refCourseCount.current)?.length != 1) ? Object.values(refCourseCount.current)?.length : ""}</div>
                                                <div className=''>HH:MM:SS</div>
                                                <div className='font text-lg'>
                                                    { totalhrs.current}
                                                </div>
                                                <div className='text-blue-700'>Learning</div>
                                                <div className='text-blue-700'>Hours </div>

                                            </div>
                                        </NVLSettingsCard>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className=" pt-1">
                            <div className="px-8 flex justify-end">
                                <NVLButton type={"button"}
                                    disabled={GridData?.rowGrid?.length == 0 || GridData?.rowGrid?.length == undefined || watch("download") ? true : false}
                                    className={GridData?.rowGrid?.length == 0 || GridData?.rowGrid?.length == undefined || watch("download") ? "inline-flex justify-center rounded-md border border-transparent Disabled bg-primary py-2 px-4 pt-3 text-sm font-medium" : "inline-flex justify-center rounded-md border border-transparent bg-primary py-2 px-4 pt-3 text-sm font-medium text-white shadow-sm hover:bg-primary focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"}
                                    onClick={(e) => fileDownload(e)}>
                                    <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                </NVLButton>
                                <div className="pb-2 pl-1">
                                    <NVLlabel CustomCss="-translate-x-72 pt-4" className="nvl-Def-Label pb-1" HelpInfo={"Additional report details can be downloaded here"} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"} />
                                </div>
                            </div>
                        </div>
                       
                        <GridTable watch={watch} GridData={GridData} headerColumn={headerColumn} pageChangeCall={pageChangeCall} />

                    </form>
                    </div>}
                    {watch("popup") && <NVLModalPopup CancelClick={() => router.push("/Analytics&Reports/ReportList/UserWiseActivitySummary")} ButtonNotext="OK" Content={"Download in progress ....You will be notified once the download is completed. The file can be downloaded from the notification"} />}

                </div>
            </Container>
        </>
    );
}

export default ActivityELearning;
