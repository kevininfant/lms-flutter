
import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import * as htmlToImage from "html-to-image";
import { useRouter } from "next/router";
import "quill/dist/quill.bubble.css";
import "quill/dist/quill.snow.css";
import { useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsTenantInfo } from "src/graphql/queries";
import * as Yup from "yup";

function ViewCourseCertificate(props) {

    const router = useRouter();

    const refCertificatePath = useRef();

    const validationSchema = Yup.object().shape({});
    const [fetchdata, setFetchdata] = useState({});

    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };
    const { setValue, watch } = useForm(formOptions);
    useEffect(() => {

        async function fetchData() {

            const urlPk = router.query["PK"];

            const tenantInfo = await AppsyncDBconnection(getXlmsTenantInfo, {
                PK: "XLMS#TENANTINFO",
                SK: "#TENANT#" + urlPk,
            }, props.user.signInUserSession.accessToken.jwtToken);
            setFetchdata({
                CurrentTenantInfo: tenantInfo.res.getXlmsTenantInfo,

            });
        }
        fetchData();
        return (() => {
            setFetchdata((temp) => { return { ...temp }; });
        });
    }, [props.user.signInUserSession.accessToken.jwtToken, router.query]);
    useEffect(() => {
        async function temp() {
            let getCertificate;

            try {
                getCertificate = await fetch(process.env.APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE + "?ObjectUrl=" + router.query["TemplateUrlPath"] + "&S3BucketName=" + fetchdata?.CurrentTenantInfo?.BucketName +
          "&S3KeyName=" + fetchdata?.CurrentTenantInfo?.RootFolder + "/" +
          fetchdata?.CurrentTenantInfo?.TenantID,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                        defaultrole: props.user.signInUserSession.accessToken.payload["cognito:groups"][0],
                        menuid: "601302",
                        groupmenuname: "SiteConfiguration"
                    },
                }
                );
            } catch (error) {
                return error;
            }

            let Certificate = await getCertificate?.text();
            Certificate = Certificate?.replaceAll('class="panel rounded-md"', 'class="panel"');
            Certificate = Certificate?.replaceAll('<div class="top-left"></div><div class="top"></div><div class="top-right"></div><div class="right"></div><div class="right-bottom"></div><div class="bottom"></div><div class="bottom-left"></div><div class="left"></div>', "");
            Certificate = Certificate?.replaceAll('class="focus:outline-none rounded border-yellow-600 cursor-pointer"', 'class="rounded"');
            Certificate = Certificate?.replaceAll('<i class="fa fa-solid close-icon-pattern fa-minus text-red-600 h-6 w-6 grid place-content-center cursor-pointer rounded-full bg-red-100"></i>', "");
            Certificate = Certificate?.replaceAll('${UserName}', "Asaithambi");
            if (refCertificatePath.current != undefined)
                refCertificatePath.current.innerHTML = Certificate;
        }


        temp();
    }, [fetchdata?.CurrentTenantInfo?.RootFolder, fetchdata?.CurrentTenantInfo?.TenantID, fetchdata?.CurrentTenantInfo?.BucketName, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload, router.query]);

    const downloadCertificate = async () => {
        setValue("submit", true);
        const dataUrl = await htmlToImage.toPng(refCertificatePath.current);
        const link = document.createElement('a');
        link.download = "CourseCompletionCertificate.png";
        link.href = dataUrl;
        link.click();
        link.remove();
        setValue("submit", false);
    };
    // Bread Crumbs
    const pageRoutes =  useMemo(()=>{return[
        {path: "/Analytics&Reports/ReportDashboard",    breadcrumb: 'Reports Dashboard'},
        { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
        {path: "/Analytics&Reports/CourseCompletionReport", breadcrumb: 'Course Completion Report'},
        { path: "", breadcrumb: "Certificate" },
    ];},[]);


    return (
        <>
            <Container loader={Object.keys(fetchdata) == 0} PageRoutes={pageRoutes}>
                <section className="text-gray-600 body-font px-10 pt-10 flex gap-8 text-xs font-semibold shadow-xl py-4 bg-gray-200 rounded-md ">
                    <div className={`relative flex justify-center lg:w-9/12  sm:flex-row sm:items-center items-start mx-auto shadow-md border-white`} id="CustomeCert">
                        <div className={`h-[600px] !w-[850px] relative"`} ref={refCertificatePath}></div>
                    </div>
                </section>
                <div id="Hello" />
                <div className="justify-center flex gap-4 pt-4">
                    <NVLButton text="Back" type={"success"}
                        disabled={watch("submit") ? true : false}
                        className="nvl-button bg-primary text-white w-32 h-10 " onClick={() => router.push("/Analytics&Reports/CourseCompletionReport")}>
                    </NVLButton>

                    <NVLButton text={!watch("submit") ? "Download" : ""}
                        disabled={watch("submit") ? true : false}
                        type={"success"} className="nvl-button bg-primary text-white w-32 h-10 " onClick={downloadCertificate} >
                        {
                            watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
                        }

                    </NVLButton>

                </div>
            </Container>
        </>
    );
}

export default ViewCourseCertificate;
