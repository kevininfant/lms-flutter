import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Line } from "react-chartjs-2";
import { useForm } from "react-hook-form";
import { listXlmsCourseManagementInfo, listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LineController, LineElement, PieController, PointElement, PolarAreaController, RadarController, ScatterController, TimeSeriesScale, Title, Tooltip } from "chart.js";


Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

export default function CourseCompletionReport(props) {

    const [getDataCourseReport, setValuedata] = useState({ RowGrid: [], Data: [] });
    const [getCompanyData, setCompanyData] = useState(props.TenantInfo.TenantID);
    const [filterDropdownData, setFilterDropdownData] = useState({ Department: [{ value: "", text: "Filter by Department" }], Designation: [{ value: "", text: "Filter by Designation" }], Course: [{ value: "", text: "Filter by Course" }] });
    const refReportData = useRef();
    const refWhereQuery = useRef();
    const refFilterControl = useRef();
    const router = useRouter();
    const [getPageData, setPageData] = useState({});
    const Dropdowndata = useRef({ Course: "", Department: "", Designation: "" })
    const ddlData = useRef({ UserName: "", Change: false });
    const refRecordStatus = useRef()
    const [griddata, SetGridData] = useState({ Page: 0, Change: false });

    const newFilter = useCallback((fetchData, Page) => {
        ddlData.current.Change = true
        SetGridData((temp) => {
            if (temp.Page == 0 && ddlData.current.Change) {
                fetchData(Page, true)
                return temp
            }
            else {
                return { ...temp, Page: 0 }
            }
        })
    }, []);
    const validationSchema = Yup.object().shape({
        ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" &&
            Yup.string().required("Company is required")
                .test("", "", (e) => {
                    if (e != refFilterControl.current && ((e != "") || (e == "" && refFilterControl.current != undefined))) {
                        refFilterControl.current = e;
                        newFilter(fetchData, griddata.Page)
                        setValue("txtsearch", "")
                        setValue("ddlCourse", "")
                        setValue("ddlDepartment", "")
                        setValue("ddlDesignation", "")
                    }
                    return true;
                }),
        ddlCourse: Yup.string()
            .test("", "", (e) => {
                if (e != Dropdowndata.current.Course && ((e != "") || (e == "" && Dropdowndata.current.Course != undefined))) {
                    Dropdowndata.current.Course = e;
                    newFilter(fetchData, griddata.Page)
                }
                return true;
            }),
        ddlDepartment: Yup.string()
            .test("", "", (e) => {
                if (e != Dropdowndata.current.Department && ((e != "") || (e == "" && Dropdowndata.current.Department != undefined))) {
                    Dropdowndata.current.Department = e;
                    newFilter(fetchData, griddata.Page)
                }
                return true;
            }),
        ddlDesignation: Yup.string()
            .test("", "", (e) => {
                if (e != Dropdowndata.current.Designation && ((e != "") || (e == "" && Dropdowndata.current.Designation != undefined))) {
                    Dropdowndata.current.Designation = e;
                    newFilter(fetchData, griddata.Page)
                }
                return true;
            }),
        txtsearch: Yup.string().test("", "ChangeHandler", (e) => {
            if (e != ddlData.current.UserName && e != "" && e != undefined) {
                ddlData.current = { ...ddlData.current, UserName: e };
            }
            else {
                ddlData.current = { ...ddlData.current, UserName: e };
            }
            return true;
        })
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
    const { errors } = formState;
    useEffect(() => {
        if (ddlData.current.Change) {
            fetchData(griddata.Page, true);
        }
        else {
            fetchData(griddata.Page)
        }
        return (() => {
            setPageData((temp) => { return { ...temp }; });
        });
    }, [fetchData, griddata.Page]);

    const getFilterDropdownData = useCallback(async () => {
        const ltdrpDepartment = [{ value: "", text: "Filter by Department" }];
        const ltdrpDesignation = [{ value: "", text: "Filter by Designation" }];
        const ltdrpCourse = [{ value: "", text: "Filter by Course" }];
        const lctCustomFieldvalue = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + getCompanyData, SK: "CUSTOMFIELD#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const lGetCourseData = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + getCompanyData, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const userData = lctCustomFieldvalue.res?.listXlmsCustomFields?.items;
        const courseData = lGetCourseData.res?.listXlmsCourseManagementInfo?.items;
        courseData?.map((getItem) => {
            if (getItem?.text?.toLowerCase() != "select") {
                ltdrpCourse.push({ value: getItem.CourseID, text: getItem.CourseName });
            }
        });
        userData && userData.filter((filterCustomValue) => {
            if (filterCustomValue?.ProfileFieldName == "Department") {
                JSON.parse(filterCustomValue?.FieldOptions)?.map((mDepartment) => {
                    if (mDepartment?.text?.toLowerCase() != "select") {
                        ltdrpDepartment.push({ value: mDepartment?.value, text: mDepartment?.text });
                    }
                });
            }
            if (filterCustomValue?.ProfileFieldName == "Designation") {
                JSON.parse(filterCustomValue?.FieldOptions)?.map((mDesignation) => {
                    if (mDesignation?.text?.toLowerCase() != "select") {
                        ltdrpDesignation.push({ value: mDesignation?.value, text: mDesignation?.text });
                    }
                });
            }
            setFilterDropdownData({ Department: ltdrpDepartment, Designation: ltdrpDesignation, Course: ltdrpCourse });
        });
    }, [props?.user?.signInUserSession?.accessToken?.jwtToken, getCompanyData]);

    useEffect(() => {
        getFilterDropdownData("");
    }, [getFilterDropdownData]);

    const getOffsetInfo = useCallback((Page) => {
        const pageOffset = Page ? Page : 0;
        return `ORDER BY UPPER(UserName) asc,UPPER("Assigned Course")  ASC
                       OFFSET ${pageOffset * process.env.PAGEGRIDSIZE} ROWS
                       FETCH NEXT ${process.env.PAGEGRIDSIZE} ROWS ONLY`;
    }, []);

    const pageChangeCall = useCallback((currentPage) => {
        SetGridData((temp) => {
            if (temp.Page < currentPage) {
                return { ...temp, Page: currentPage };
            }
            else {
                return temp;
            }
        })
    }, []);

    const selectCompany = useMemo(() => {
        if (getPageData?.listXlmsTenantInfo != undefined) {
            let ltDefultSelect = [{ value: "", text: "Select Company" }];
            if (getPageData.listXlmsTenantInfo?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin" && ltDefultSelect.length < process.env.PAGEGRIDSIZE) {
                getPageData.listXlmsTenantInfo?.map((getItem) => ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
            } else if (props.TenantInfo.UserGroup != "SiteAdmin") {
                ltDefultSelect = [];
                const currentTenant = getPageData.listXlmsTenantInfo?.filter(function (Tenant) {
                    return Tenant.TenantID == getCompanyData;
                });
                currentTenant?.map((getItem) => {
                    ltDefultSelect.push({ value: getItem.TenantID, text: getItem.TenantDisplayName });
                });
            }
            return ltDefultSelect;
        }
    }, [getCompanyData, getPageData.listXlmsTenantInfo, props.TenantInfo.UserGroup]);

    const headerColumn = useMemo(() => {
        return [
            { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/6" },
            { HeaderName: "Course Name", Columnvalue: "CourseName", HeaderCss: "w-1/6" },
            { HeaderName: "Email", Columnvalue: "Email ID", HeaderCss: "w-1/6" },
            { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "w-1/6" },
            { HeaderName: "Designation", Columnvalue: "Designation", HeaderCss: "w-1/6" },
            { HeaderName: "Start Date", Columnvalue: "EnrolledDate", HeaderCss: "w-1/6" },
            { HeaderName: "Date Completion", Columnvalue: "Date Of Completion", HeaderCss: "w-1/6" },
            { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-1/6" },
            { HeaderName: "Certificate", Columnvalue: "Certificate", HeaderCss: "w-1/6" }
        ];
    }, []);

    const fetchGridData = useCallback(async (e) => {
        const tenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
        const temp = {
            listXlmsTenantInfo: tenantInfo?.res?.listXlmsTenantInfos?.items != undefined ? tenantInfo.res?.listXlmsTenantInfos?.items : [],
            tenantId: ddlData.current.TenantID,
        };
        setPageData(temp);
    }, [props.user.signInUserSession.accessToken.jwtToken]);

    useEffect(() => {
        fetchGridData();
        return () => {
            setPageData((temp) => {
                return { ...temp };
            });
        };
    }, [fetchGridData]);

    const execID = useRef();
    const submitHandler = async (data) => {
        setValue("submit", true);
        newFilter(fetchData, griddata.Page)
        setValue("submit", false);
    };

    const fileDownload = useCallback(async (e) => {
        setValue("download", true);
        let lqrywhere;
        const lstrCourseName = watch("ddlCourse");
        const lstrDepartment = watch("ddlDepartment");
        const lstrDesignation = watch("ddlDesignation");
        lqrywhere = `WHERE tenantid='${props.TenantInfo.TenantID}'`;
        if (lstrCourseName !== "") {
            lqrywhere += ` AND CourseName='${lstrCourseName}'`;
        }
        if (lstrDepartment != "") {
            lqrywhere += ` AND Department='${lstrDepartment}'`;
        }
        if (lstrDesignation != "") {
            lqrywhere += ` AND Designation='${lstrDesignation}'`;
        }
        if (Dropdowndata.current.Course != "") {
            lqrywhere += ` AND UPPER(CourseName) LIKE UPPER('%${Dropdowndata.current.Course}%')`;
        }
        if (e?.type == "click") {
            const lstrPresignedFileURL = process.env.APIGATEWAY_REPORT_URL + `?ReportType=Download`;
            const headers = {
                method: "POST",
                headers: {
                    "Content-Type": "text/csv",
                    authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                    tenantid: props.TenantInfo.TenantID,
                    groupmenuname: "Analytics&Report",
                    defaultrole: props?.TenantInfo.UserGroup,
                    menuid: "115502"
                },
                body: `${lqrywhere}`,
            };
            const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
            if (lstrFileDownload?.Status == "Success") {
                setValue("popup", true)
            } else {
                setValue("popup", false)

            }
        }
        setValue("download", false);
    }, [setValue, watch, props?.user?.signInUserSession?.accessToken?.jwtToken, props.TenantInfo.TenantID, props.TenantInfo.UserGroup]);
    //Line Chart

    const pageRoutes = useMemo(() => {
        return [
            { path: "/Analytics&Reports/ReportDashboard", breadcrumb: 'Reports Dashboard' },
            { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
            { path: "", breadcrumb: "Course Completion Report" }
        ];
    }, []);

    const featureActivityData = useCallback(() => {
        const courseNameList = [];
        filterDropdownData.Course.map((Course, idx) => {
            if (watch("ddlCourse") != "") {
                if (watch("ddlCourse") == Course.value) {
                    courseNameList.push(Course.text);
                }
            } else if ((Course.text != "Select" && Course.text != "Filter by Course") && idx < 9) return courseNameList.push(Course.text);
        });
        const linechartData = [];
        let CourseUserCount, SelectedCourseUserCount;
        if (watch("ddlCourse") == "") {
            CourseUserCount = refReportData.current && refReportData.current.reduce(function (prevCourse, CurrCourse) {

                if (CurrCourse["Assigned Course"]) {
                    prevCourse[CurrCourse["Assigned Course"]] = (prevCourse[CurrCourse["Assigned Course"]] || 0) + 1;
                }
                return prevCourse;
            }, {});

        } else {
            SelectedCourseUserCount = refReportData.current && refReportData.current?.filter((Course) => {
                return Course["Assigned Course"] == document?.getElementById("ddlCourse")?.options[document.getElementById("ddlCourse").selectedIndex]?.text;
            });
            SelectedCourseUserCount = SelectedCourseUserCount != undefined && Object.values(SelectedCourseUserCount)?.length;
        }

        const dataArray = CourseUserCount && Object.entries(CourseUserCount).map(([key, value]) => ({ key, value }));
        dataArray && dataArray.sort((a, b) => a.key.localeCompare(b.key));

        const sortedData = {}, sortedCourse = []
        dataArray && dataArray.forEach(({ key, value }) => {
            sortedData[key] = value;
            sortedCourse.push(key)
        });

        linechartData?.push({
            data: watch("ddlCourse") == "" ? sortedData : SelectedCourseUserCount?.toString(),
            label: "User Count",
            borderColor: "green",
            backgroundColor: "green",
            barPercentage: 0.5,
            barThickness: 20,
            borderWidth: 1,
        });
        return { labels: watch("ddlCourse") == "" ? sortedCourse : courseNameList, datasets: linechartData }
    }, [filterDropdownData.Course, watch]);

    const fetchData = useCallback(async (Page, Filter, e) => {
        let loginChange;
        let tempTrue = ddlData.current?.Change || Filter;
        ddlData.current.Change = false;
        if (e == undefined) {
            if (props.TenantInfo.UserGroup == "SiteAdmin") { loginChange = refFilterControl.current }
            else { loginChange = props.user.attributes["custom:tenantid"]; }
        }
        else { loginChange = e; }
        setValue("fetch", true);
        const gridDataBind = (getDataCourseReport, lstrTenantID, router) => {
            const rowGrid = [];
            let viewData = getDataCourseReport != undefined && Object.values(JSON?.parse(getDataCourseReport));
            viewData = (viewData && viewData != undefined) && JSON.parse(viewData?.[1]);
            execID.current = getDataCourseReport != undefined && JSON?.parse(getDataCourseReport);
            viewData &&
                viewData.map((getItem, index) => {
                    if (getItem?.UserName != undefined) {
                        rowGrid.push({
                            UserName: <NVLlabel id={index + 1} text={getItem.UserName} />,
                            ["Email ID"]: <NVLlabel id={index + 1} text={getItem["Email ID"]} />,
                            CourseName: <NVLlabel id={index + 1} text={getItem["Assigned Course"]} />,
                            // ["Email ID"]: <NVLlabel id={index + 1} text={getItem["Email ID"]} />,
                            Department: <NVLlabel id={index + 1} text={getItem.Department} />,
                            Designation: <NVLlabel id={index + 1} text={getItem.Designation} />,
                            EnrolledDate: <NVLlabel id={index + 1} text={getItem.EnrolledDate} />,
                            ["Date Of Completion"]: <NVLlabel id={index + 1} text={getItem["Date Of Completion"]} />,
                            Status: <NVLlabel id={index + 1} text={getItem.Status}
                                className={`${getItem.Status == "Yet to start" ? "text-red-500" : getItem.Status == "Inprogress" ? "text-fuchsia-500" : "text-green-600"}`} />,
                            // Grade: <NVLlabel id={index + 1} text={getItem.Grade} />,
                            Certificate: <>{

                                getItem.UserName &&
                                <NVLLink text={"View"}
                                    className={((getItem.Status != "Inprogress" || getItem.Status != "Yet to start") &&
                                        (getItem.certificatepath != null || getItem.certificatepath != undefined)) ?
                                        "text-blue-500" : "text-gray-500"}
                                    onClick={() => ((getItem.Status != "Inprogress" || getItem.Status != "Yet to start") &&
                                        (getItem.certificatepath != null || getItem.certificatepath != undefined)) &&
                                        router.push(`/Analytics&Reports/ViewCourseCertificate?TemplateUrlPath=${getItem.certificatepath}&PK=${lstrTenantID}`)} />}</>
                        });
                    }
                });
            return rowGrid;
        }

        let lqrywhere = `WHERE tenantid = '${loginChange}'`;

        if (Dropdowndata.current.Course != "") {
            lqrywhere += ` AND courseid='${Dropdowndata.current.Course}'`;
        }

        if (Dropdowndata.current.Department != "") {
            lqrywhere += ` AND Department='${Dropdowndata.current.Department}'`;
        }

        if (Dropdowndata.current.Designation != "") {
            lqrywhere += ` AND Designation='${Dropdowndata.current.Designation}'`;
        }

        if (ddlData.current.UserName != "") {
            lqrywhere += ` AND UPPER(UserName) LIKE UPPER('%${ddlData.current.UserName}%')`;
        }
        const response = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/text",
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                menuid: "115502",
                tenantid: loginChange,
                groupmenuname: "Analytics&Report",
                defaultrole: props?.TenantInfo.UserGroup,
            },
            body: `${props?.TenantInfo.UserGroup == "SiteAdmin" ? lqrywhere : lqrywhere} ${getOffsetInfo(Page)}`,
        });
        const data = await response?.res?.text();
        let getData = data != undefined && Object.values(JSON?.parse(data));
        refReportData.current = (getData && getData != undefined) && JSON.parse(getData?.[1]);
        data != undefined && Object.keys(JSON.parse(JSON.parse(data)?.State)?.[0]).length == 0 ? refRecordStatus.current = "NoRecord" : refRecordStatus.current = "Exists";
        setCompanyData(loginChange)
        const rowGrid = gridDataBind(data, loginChange, router);
        if (tempTrue) {
            if (rowGrid?.length > 0) {
                SetGridData((temp) => {
                    return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
                })
            }
            else {
                SetGridData((temp) => {
                    return { ...temp, TotalCount: 0, rowGrid: [] };
                })
            }
        }
        else {
            if (rowGrid?.length > 0) {
                SetGridData((temp) => {
                    if (temp?.rowGrid?.length > 0)
                        return { ...temp, rowGrid: [...temp.rowGrid, ...rowGrid], TotalCount: parseInt((temp?.rowGrid?.length + rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
                    else
                        return { ...temp, rowGrid: [...rowGrid], TotalCount: parseInt((rowGrid.length) / process.env.PAGEGRIDSIZE) + 1 };
                })
            }
            else {
                SetGridData((temp) => {
                    if (temp?.rowGrid?.length > 0)
                        return { ...temp, TotalCount: temp?.rowGrid?.length / process.env.PAGEGRIDSIZE, ShowContentAndReducePage: temp?.ShowContentAndReducePage != undefined ? temp.ShowContentAndReducePage + 1 : 1 };
                    else
                        return { ...temp, TotalCount: 0 };
                })
            }
        }
        setValue("fetch", false);
    }, [getOffsetInfo, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router, setValue]);

    return (
        <>
            <Container title="Course Completion Report" PageRoutes={pageRoutes} >
                <form onSubmit={handleSubmit(submitHandler)} className={watch("submit") || watch("download") || watch("fetch") ? "pointer-events-none px-2" : "px-2"}>
                    <div className="px-3" id="divFilter">
                        <div className="block rounded-lg ">
                            <div className="py-3 pb-4">
                                <div className="col-span-6 sm:col-span-3">
                                    <NVLlabel htmlFor="Company-Name" className="block text-sm font-medium text-gray-600 py-1">
                                        Company Name
                                    </NVLlabel>
                                    <NVLSelectField id="ddlCompany" errors={errors} options={selectCompany} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled " : ""} mt-1 block w-64 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm`} disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} register={register}></NVLSelectField>
                                </div>

                                {/* Line Chart */}
                                <div className="pt-2">
                                    <Line
                                        data={featureActivityData()}
                                        options={{
                                            cutoutPercentage: 100,
                                            responsive: true,
                                            aspectRatio: 4,
                                            plugins: {
                                                legend: {
                                                    display: false,
                                                },
                                            },
                                            scales: {
                                                y: {
                                                    max: 100,
                                                    min: 0,
                                                    ticks: {
                                                        stepSize: 25
                                                    }
                                                },
                                                x: {
                                                    grid: {
                                                        display: false,
                                                    },
                                                },
                                            },
                                        }}
                                    />
                                </div>
                                <div className="grid grid-cols-12 grid-flow-col gap-2 pt-4">
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Course-Name" className="block text-sm font-medium text-gray-600 py-1">
                                            Course Name
                                        </NVLlabel>
                                        <NVLSelectField id="ddlCourse" errors={errors} options={filterDropdownData.Course} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
                                    </div>

                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Department" className="block text-sm font-medium text-gray-600 py-1">
                                            Department
                                        </NVLlabel>
                                        <NVLSelectField id="ddlDepartment" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={filterDropdownData.Department} errors={errors} />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="Designation" className="block text-sm font-medium text-gray-600 py-1">
                                            Designation
                                        </NVLlabel>
                                        <NVLSelectField id="ddlDesignation" autoComplete="given-name" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} errors={errors} options={filterDropdownData.Designation} />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3">
                                        <NVLlabel htmlFor="User-Name" className="block text-sm font-medium text-gray-600 py-1">
                                            Search by User Name
                                        </NVLlabel>
                                        <NVLTextbox id="txtsearch" className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm" register={register} errors={errors} title="Filter by user name" />
                                    </div>
                                    <div className="col-span-6 sm:col-span-3 pt-6">
                                        <NVLButton id="btnSubmit" text={!watch("submit") ? "Apply Filter" : ""}
                                            disabled={watch("submit") || watch("fetch") || watch("download") ? true : false} type="submit" className={watch("submit") ? "w-28 nvl-button !bg-primary text-white !h-10" : "w-28 nvl-button !bg-primary text-white !h-10"}>
                                            {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                                        </NVLButton>
                                    </div>
                                    <div className="col-span-6 sm:col-span-3 pt-6">
                                        <div className="flex items-center">
                                            <NVLButton id="btnSubmit" disabled={griddata?.rowGrid?.length == 0 || griddata?.rowGrid?.length == undefined || watch("download") ? true : false} type={"button"}
                                                className={griddata?.rowGrid?.length == 0 || griddata?.rowGrid?.length == undefined || watch("download") ? "nvl-button bg-primary Disabled !h-10" : "nvl-button !bg-primary text-white !h-10"}
                                                onClick={(e) => fileDownload(e)}
                                            >
                                                <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                            </NVLButton>
                                            <div className="pb-2 pl-1">
                                                <NVLlabel
                                                    CustomCss="-translate-x-72 pt-4"
                                                    className="nvl-Def-Label pb-1"
                                                    HelpInfo={"Additional report details can be downloaded here"}
                                                    HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    <div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {!watch("fetch") && <div className="pb-8">
                        <NVLGridTable id="tblEnrollList" className="max-w-full"
                            HeaderColumn={headerColumn}
                            RowGridDataPass={{ RowGrid: griddata?.rowGrid !== undefined ? griddata?.rowGrid : [] }}
                            pageSize={process.env.PAGEGRIDSIZE}
                            ShowContentAndReducePage={griddata.ShowContentAndReducePage}
                            pageChangeCall={pageChangeCall}
                            TotalCount={griddata.TotalCount}
                            DonotLoad={false} currentPageFront={griddata.Page} />
                    </div>}
                    <div>
                        {watch("fetch") && <NVLLoadingSpinner />}
                    </div>
                </form>
                {watch("popup") && <NVLModalPopup CancelClick={() => router.push("/Analytics&Reports/ReportList")} ButtonNotext="OK" Content={"Download in progress ....You will be notified once the download is completed. The file can be downloaded from the notification"} />}
            </Container>
        </>
    );
}
