import Container from "@Container/Container";
import NVLHeader from "@Controls/NVLHeader";
import Stepper from "@Controls/NVLStepper";
import StepperControl from "@Controls/NVLStepperControl";
import { UseContextProvider } from "@Dashboard/StepperContext";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import { yupResolver } from '@hookform/resolvers/yup';
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { withSSRContext } from "aws-amplify";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useForm } from 'react-hook-form';
import { getXlmsTenantInfo, listXLMSPlanConfigs, listXLMSRoleConfigs } from "src/graphql/queries";
import * as Yup from 'yup';
import Payment from "./Payment";
import Plan from "./Plan";
import PlanDetail from "./PlanDetail";
import Preview from "./Preview";

export default function PlanInfo(props) {
  const router = useRouter();
  const [Data, setData] = useState([]);

  // const FetchPlanData= useCallback (()=>{

  // },[])

  useEffect(() => {
    const DataSource = async (i) => {
      let queryParam = router.query;
      queryParam = decodeURIComponent(String(router.query["TenantID"]));
      let tenantId;
      if (queryParam == "undefined") {
        tenantId = props.user.attributes["custom:tenantid"];
      }
      else {
        tenantId = queryParam;
      }
      const response = await AppsyncDBconnection(listXLMSPlanConfigs, { PK: "XLMS#PLAN", SK: "PLAN#", }, props.user.signInUserSession.accessToken.jwtToken);
      const responseTenantInfo = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + tenantId }, props.user.signInUserSession.accessToken.jwtToken);



      setData({
        PlanInfo: response?.res?.listXLMSPlanConfigs?.items,
        TenantId: tenantId,
        userName: "",
        TenantPlanInfo: responseTenantInfo?.res?.getXlmsTenantInfo,
      })
    }
    DataSource();
    return (() => {
      setData((temp) => { return { ...temp } })
    })
  }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const [PlanSelect, SetPlanSelect] = useState("");
  const [CurrentState, setCurrentState] = useState({});
  const [currentStep, setCurrentStep] = useState(1);
  const steps = ["Select Plan", "Plan Detail", "Preview Order", "Payment"];
  const [modalValues, setModalValues] = useState({});
  const validationSchema = Yup.object().shape({
    Type: currentStep == 2 ? Yup.string().nullable().required("Please fill the value")
      .test("validation", "No vAlid", (e, ctx) => {
        let tolamt = e == "Yearly" ? 12 : 1;
        let Yearly = e == "Yearly" ? true : false;
        const rejax = new RegExp(/^[0-9]{1,10}$/);
        let user = ctx.parent.txtNoofuser
        if (!rejax.test(user) || parseInt(user) == 0) {
          user = 0;
        }
        setCurrentState({ ...CurrentState, Yearly: Yearly, NoOfUser: user, TotalAmount: tolamt * user * CurrentState.PlanPricePerUser || 0 });
        return true;
      }) : Yup.string().nullable(),
    txtNoofuser: currentStep == 2 && PlanSelect != "Free" ? Yup.string().required("Please fill the value")
      .test("Test", "", (e, { createError }) => {
        const rejax = new RegExp(/^[0-9]{1,10}$/);
        if (!rejax.test(e) || parseInt(e) == 0) {
          return createError({ message: "Enter a valid number of Users" });
        }
        if (Data.TenantPlanInfo.TotalNoOfUsers != undefined && parseInt(e) < parseInt(Data.TenantPlanInfo.TotalNoOfUsers)) {
          return createError({ message: "Minimum number of users must be greater than " + Data.TenantPlanInfo.TotalNoOfUsers });
        } else if (parseInt(e) < parseInt(10)) {
          return createError({ message: "Minimum number of users must be greater than or equal to 10" });
        } else {
          return true;
        }
      })
      : Yup.string(),
  });


  const formOptions = { mode: 'onChange', resolver: yupResolver(validationSchema), reValidateMode: 'onChange', nativeValidation: false };
  const { register, handleSubmit, setValue, reset, formState, watch } = useForm(formOptions);
  const { errors } = formState;
  function redirect(PlanSelect) {
    reset();
    displayStep(2);
    let PlanInfomation = Data.PlanInfo;
    let PlanCode = PlanInfomation.filter(function (PlanInfomation) {
      return PlanInfomation.PlanCode == PlanSelect;
    });
    if (Data.TenantPlanInfo?.PlanCode == PlanSelect) {
      let a = Data.TenantPlanInfo.PlanFrequency.trim() == "Yearly" ? true : false;
      let b = a == true ? 12 : 1;
      setValue("txtNoofuser", Data.TenantPlanInfo.TotalNoOfUsers);
      setValue("Type", Data.TenantPlanInfo.PlanFrequency.trim());
      setCurrentState({ ...PlanCode[0], Yearly: a, NoOfUser: Data.TenantPlanInfo.TotalNoOfUsers, TotalAmount: b * Data.TenantPlanInfo.TotalNoOfUsers * PlanCode[0].PlanPricePerUser });
    } else if (Data.TenantPlanInfo?.PlanCode) {
      let a = Data.TenantPlanInfo.PlanFrequency.trim() == "Yearly" ? true : false;
      let b = a == true ? 12 : 1;
      setValue("txtNoofuser", Data.TenantPlanInfo.TotalNoOfUsers);
      setValue("Type", Data.TenantPlanInfo.PlanFrequency.trim());
      setCurrentState({ ...PlanCode[0], Yearly: a, NoOfUser: Data.TenantPlanInfo.TotalNoOfUsers, TotalAmount: b * Data.TenantPlanInfo.TotalNoOfUsers * PlanCode[0].PlanPricePerUser });
    } else if (PlanSelect == "Free") {
      setValue("txtNoofuser", 10);
      setValue("Type", "Monthly");
      setCurrentState({ ...PlanCode[0], Yearly: false, NoOfUser: 10, TotalAmount: 10 * PlanCode[0].PlanPricePerUser });
    } else {
      setValue("Type", "Monthly");
      setCurrentState({ ...PlanCode[0], Yearly: false, NoOfUser: 0, TotalAmount: 0 * PlanCode[0].PlanPricePerUser });
    }
    setCurrentStep(2);
  }
  const displayStep = (step) => {
    switch (step) {
      case 1:
        return (
          <Plan displayStep={(step) => { SetPlanSelect(step); redirect(step); }}
            OldPlanSelect={Data?.TenantPlanInfo?.PlanCode} PlanInfo={Data?.PlanInfo} User={props.user} />
        );
      case 2:
        return (
          <PlanDetail register={register} errors={errors} TotalAmount={CurrentState.TotalAmount} SelectedPlan={PlanSelect}
            PlanInfo={Data?.PlanInfo} />
        );
      case 3:
        return <Preview PlanSelect={PlanSelect} PlanStatevalue={CurrentState}></Preview>;
      case 4:
        return <Payment PlanSelect={PlanSelect} />;
      default:
    }
  };
  const submitHandler = async (data) => {
    await SavePlanDetails();
    setValue("submit", false);

  };

  const FinalResponse = (response) => {
    if (response != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: response,
      });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Info",
        ModalTopMessage: "Info",
        ModalBottomMessage: "Plan activation is under process and It will take 24Hours!...",
        ModalOnClickEvent: () => {
          props.signOut();
          router.push("/");
        }
      });
      ModalOpen();
    }
  };

  const handleClick = () => {
    let newStep = currentStep;
    newStep--;
    newStep > 0 && newStep <= steps.length && setCurrentStep(newStep);
  };


  async function SavePlanDetails() {
    setValue("submit", true);

    let today = new Date();
    let date = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();
    let time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    let dateTime = date + " " + time;

    function addDays(date, days) {
      const copy = new Date(Number(date));
      copy.setDate(date.getDate() + days);
      return copy;

    }

    const Currentdate = new Date();
    let DayToAdd = CurrentState.Yearly ? 365 : 30;
    const EndDate = addDays(Currentdate, DayToAdd);

    let date_1 = new Date(today);
    let date_2 = new Date(EndDate);

    const days = (date_1, date_2) => {
      let difference = date_1.getTime() - date_2.getTime();
      let TotalDays = Math.ceil(difference / (1000 * 3600 * 24));
      return Math.abs(TotalDays);
    };

    if (currentStep == 4) {
      const SSR = withSSRContext();
      const response = await AppsyncDBconnection(listXLMSRoleConfigs, { PK: "XLMS#ROLE", SK: "ROLE#" }, props.user.signInUserSession.accessToken.jwtToken);
      let RoleCount = (response.res.listXLMSRoleConfigs.items.length - 1);
      let RolesJson = "";
      response.res.listXLMSRoleConfigs.items.map((element, index) => {
        RolesJson += '{"TenantID":"' + Data.TenantId + '","RoleName": "' + element.RoleName + '", "RoleDescription": "' + element.Role + '","CreatedBy": "' + props.user.username + '","CreatedDate": "' + dateTime + '"}' + (index == RoleCount ? "" : ",");
      });
      let JsonSaveData = '{"CompanyInfo":{"TenantName":"' + Data.TenantPlanInfo.TenantDisplayName + '","TenantID":"' + Data.TenantId + '","PlanCode":"' + PlanSelect + '","TotalNoOfUsers":"' + CurrentState.NoOfUser + '","StartDate":"' + today.toLocaleDateString() + '","PlanFrequency":"' + (CurrentState.Yearly ? "Yearly" : "Monthly") + ' "},'
        + '"Subscription":{"TenantID":"' + props.TenantInfo.TenantID + '","TenantName":"' + Data.TenantPlanInfo.TenantDisplayName + '","ReceiptNo":"","ValidityDays":"' + days(date_1, date_2) + '","EndDate":"' + EndDate.toLocaleDateString() + '","PlanFrequency":"' + (CurrentState.Yearly ? "Yearly" : "Monthly") + '","TotalAmount":"' + Math.round(CurrentState.TotalAmount * 0.18 + CurrentState.TotalAmount) + '","PlanPricePerUser":"' + CurrentState.PlanPricePerUser + '","PlanCode":"' + PlanSelect + '","StartDate":"' + today.toLocaleDateString() + '","TotalNoOfUsers":"' + CurrentState.NoOfUser + '","Status":"","CreatedBy":"' + props.user.username + '","CreatedDate":"' + dateTime + '","UserSub":"' + Data?.TenantPlanInfo?.UserSub + '"},'
        + '"Role":[' + RolesJson + ']}';

      if (Data?.TenantPlanInfo?.FirstTimeLogin) {
        await fetch(process.env.APIGATEWAY_URL_CREATEPLANPROCESSOR, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
            defaultrole: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0],
            groupmenuname: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0] == "SiteAdmin" ? "SiteConfiguration" : "CompanyManagement",
            menuid: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0] == "SiteAdmin" ? "601500" : "100600",
            statemachinearn: process.env.STEP_FUNCTION_ARN_CREATEPLANPROCESSOR
          },
          body: JsonSaveData,
        }).then(async (response) => {
          const temp = await response.text();
          FinalResponse(temp?.split("|")[0]);
          setValue("submit", false);
        }).catch((err) => { FinalResponse("Server Error"); });
      } else {
        await fetch(process.env.APIGATEWAY_URL_CHANGE_PLAN_PROCESSOR, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
            defaultrole: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0],
            groupmenuname: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0] == "SiteAdmin" ? "SiteConfiguration" : "CompanyManagement",
            menuid: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0] == "SiteAdmin" ? "601500" : "100601",
          },
          body: JsonSaveData,
        }).then(async (response) => {
          const temp = await response.text();
          FinalResponse(temp);
          setValue("submit", false);
        }).catch((err) => { FinalResponse("Server Error"); });
      }
    } else {
      let newStep = currentStep;
      newStep++;
      newStep > 0 && newStep <= steps.length && setCurrentStep(newStep);
    }

  }
  let PageRoutes = [];
  if (Data?.TenantPlanInfo?.FirstTimeLogin) {
    PageRoutes = [
      { path: "", breadcrumb: "Plan" },
    ];
  } else {
    PageRoutes = [
      { path: props?.TenantInfo?.UserGroup == "CompanyAdmin" ? "/SiteConfiguration/SiteConfigSettings" : "/CompanyManagement/CompanyList", breadcrumb: props?.TenantInfo?.UserGroup == "CompanyAdmin" ? "Site Configuration" : "Company Management" },
      { path: (Data?.TenantPlanInfo?.PlanCode != undefined || props.TenantInfo.UserGroup == "SiteAdmin") ? `/CompanyManagement/CompanyDetails?TenantID=${Data.TenantId}` : `/`, breadcrumb: "Edit Company" },
      { path: "", breadcrumb: "Plan" },
    ];
  }


  return (
    <Container title="Plan" PageRoutes={PageRoutes} loader={Data.TenantId == undefined}>
      <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
      <NVLHeader RedirectHome={(Data?.TenantPlanInfo?.PlanCode != undefined || props.TenantInfo.UserGroup == "SiteAdmin") ? `/CompanyManagement/CompanyDetails?TenantID=${Data.TenantId}` : `/`} RedirectAction="/" IsSearch={false} />
      <div className="xl:grid Amountxl:grid-cols-6 lg:px-72 md:col-start-4 xl:gap-4 md:px-32 "></div>
      <div className="mx-auto text-center rounded-2xl pb-2">
        <form id="fmPlanInfo" onSubmit={handleSubmit(submitHandler)} className={`${ watch("submit") ? "pointer-events-none" : "px-2"}`}>
          <Stepper steps={steps} currentStep={currentStep} />
          <div className="my-16">
            <UseContextProvider>{displayStep(currentStep)}</UseContextProvider>
          </div>
          {currentStep > 1 && currentStep <= steps.length && <StepperControl handleClick={handleClick} currentStep={currentStep} steps={steps} Flag={watch("submit")} />}
        </form>
      </div>
    </Container>
  );
}


