import NVLPlanCard from "@components/Controls/NVLPlanCard";
import { useRef, useState } from "react";
const Plan = (props) => {
  const { displayStep, PlanInfo, OldPlanSelect, User } = props;
  const refPlanOrder= useRef();

  const [PlanCard, setPlanCard] = useState([]);

  if (PlanCard.length == 0) {
    PlanInfo?.sort(function (x, y) { return x["PlanOrder"] - y["PlanOrder"] });
    
    refPlanOrder.current = PlanInfo?.filter((item)=>{
       return item.PlanCode == OldPlanSelect;
    })
    
    PlanInfo && PlanInfo.map((element, idx) => {
     
      PlanCard.push(<div className="" key={element.PlanCode}>
        <NVLPlanCard isPlanHeader={false}
          disabled={idx < parseInt(refPlanOrder.current[0]?.PlanOrder)-1 ? true : false}
          PlanHeadertxt={element.PlanCode}
          PlanAlt={element.PlanCode} id={"PlanCard" + element.PlanCode} PlanText={element.PlanCode} PlanAmount={element.PlanPricePerUser} PlanUser={element.UserCountLimit + " User"} 
          Symbol={"IndianRupee"} displayStep={displayStep}
          headerStyle={element.PlanCode == OldPlanSelect ? " bg-blue-400 text-white border-blue-50 " : " bg-blue-50 text-gray-700 "} 
          activePlan="shadow-md" contentStyle="text-blue-400 bg-blue-50" priceStyle={element.PlanCode == OldPlanSelect ? "border-white bg-blue-400" : "border-blue-50 bg-white"} btnStyle={element.PlanCode == OldPlanSelect ? "bg-blue-500 text-white" : "bg-white text-blue-400"}
          IsDisabled={idx < parseInt(refPlanOrder.current[0]?.PlanOrder)-1 ? true : false}
        />
      </div>)
    })
  }
  return (
    <>
      <div className="nvl-Plan-Content ">
        <div className="nvl-Plan-Content-Cards ">
          {PlanCard}
        </div>
      </div>
    </>
  );
};

export default Plan;
