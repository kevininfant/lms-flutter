export default function Payment({PlanSelect}) { 
  return (
    <>
          <div className="nvl-FormContent">
            <i className="fa-solid fa-clipboard-check fa-2xl text-emerald-500 border border-emerald-500 py-6 px-4 rounded-full mr-6"></i>
            <span className="bg-green-100 text-green-800 text-sm font-medium mr-2 px-2.5 py-0.5  dark:bg-green-200 dark:text-green-900 rounded-lg">{PlanSelect=="Free"?"Free Confirm":"Confirm to Pay"}</span>

      </div>
    </>
  );
}