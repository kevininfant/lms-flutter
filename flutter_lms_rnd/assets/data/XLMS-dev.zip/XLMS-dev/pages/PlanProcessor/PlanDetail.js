import NVLlabel from "@components/Controls/NVLlabel";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLTextbox from "@components/Controls/NVLTextBox";

const PlanDetail = (props) => {
  return (
    <>
      <NVLlabel text={"Plan Selected : " + props.SelectedPlan} className="nvl-FormContent text-left font-bold max-w-2xl" />
      <div className="nvl-FormContent text-left">
        <NVLlabel text="Plan Frequency" className="nvl-Def-Label" />
        <div className="flex gap-4 text-xs font-medium pt-1">
          <NVLRadio
            name="Type"
            text="Yearly"
            value="Yearly"
            id="Type"
            register={props.register}
            errors={props.errors}
          ></NVLRadio>
          <NVLRadio
            name="Type"
            text="Monthly"
            value="Monthly"
            id="Type"
            register={props.register}
            errors={props.errors}
          ></NVLRadio>
        </div>
        <div className="{invalid-feedback} text-red-500 text-sm mt-2">
          {props?.errors?.Type?.message}
        </div>
        <NVLTextbox
          labelText="Number of users"
          labelClassName="nvl-Def-Label "
          title="Number of User"
          className={
            props.SelectedPlan == "Free"
              ? "nvl-Def-Input Disabled"
              : "nvl-Def-Input nvl-mandatory"
          }
          id="txtNoofuser"
          register={props.register}
          errors={props.errors}
        ></NVLTextbox>

        <div className=" pt-4 flex justify-between">
          <NVLlabel
            className="nvl-Def-Label"
            text={"Amount To Be Paid"}
          ></NVLlabel>
          <div className="pl-10 ">
            <span className="bg-gray-100 text-gray-800 text-xs font-semibold mr-2 px-2.5 py-1.5 rounded dark:bg-gray-700 dark:text-gray-300">
              {props.TotalAmount == 0
                ? "TotalAmount"
                : "Rs: " + props.TotalAmount}
            </span>
          </div>
        </div>
      </div>
    </>
  );
};
export default PlanDetail;
