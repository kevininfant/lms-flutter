import NVLlabel from "@components/Controls/NVLlabel";

const Preview = (props) => {
  const { PlanSelect, PlanStatevalue } = props;

  return (
    <>
      <div className="overflow-y-auto w-full py-3 xl:px-2 h-full sticky">
        <div className="w-64 md:w-96 mx-auto">
          <div className="Center-Aligned-Items">
            {PlanSelect != "Free" ? (<div className="grid grid-cols-15 col-span-3 gap-3">
              <div className="flex col-start-1">
                <NVLlabel className="nvl-Def-Label " text="Plan"></NVLlabel>
              </div>
              <div className="flex col-start-12">
                <NVLlabel className="nvl-Def-Label " text=":"></NVLlabel>
              </div>
              <div className="flex col-start-13">
                <NVLlabel className="nvl-Def-Label " id="lblPlanSelect" text={PlanSelect.toString()}></NVLlabel>
              </div>
              <div className="flex col-span-7 col-start-1">
                <NVLlabel className="nvl-Def-Label " text="Number of Users"></NVLlabel>
              </div>
              <div className="flex col-start-12">
                <NVLlabel className="nvl-Def-Label " text=":"></NVLlabel>
              </div>
              <div className="flex col-start-13">
                <NVLlabel className="nvl-Def-Label" id="lblNoOfUsers" text={PlanStatevalue.NoOfUser.toString()}></NVLlabel>
              </div>
              <div className="flex col-start-1 col-span-11">
                <NVLlabel className="nvl-Def-Label " text="Amount to be paid"></NVLlabel>
              </div>
              <div className="flex col-start-12">
                <NVLlabel className="nvl-Def-Label " text=":"></NVLlabel>
              </div>
              <div className="flex col-start-13">
                <NVLlabel className="nvl-Def-Label " id="lblAmtPaid" text={PlanStatevalue.TotalAmount.toString()}></NVLlabel>
              </div>
              <div className="flex col-start-1">
                <NVLlabel className="nvl-Def-Label " text="Tax"></NVLlabel>
              </div>
              <div className="flex col-start-12">
                <NVLlabel className="nvl-Def-Label" text=":"></NVLlabel>
              </div>
              <div className="flex">
                <NVLlabel className="nvl-Def-Label " id="lblTax" text={Math.round(PlanStatevalue.TotalAmount * 0.18) + " (18% Tax)"} ></NVLlabel>
              </div>
              <div className="flex col-start-1 col-span-7">
                <NVLlabel className="nvl-Def-Label " text="Total amount"></NVLlabel>
              </div>
              <div className="flex col-start-12">
                <NVLlabel className="nvl-Def-Label" text=":"></NVLlabel>
              </div>
              <div className="flex">
                <NVLlabel className="nvl-Def-Label" id="lblTotalAmount" text={Math.round(PlanStatevalue.TotalAmount * 0.18 + PlanStatevalue.TotalAmount).toString()}></NVLlabel>
              </div>
            </div>) : (
              <div className="">
                <i className="fa-solid fa-clipboard-check fa-2xl text-emerald-500  py-3 px-2 "></i>
                <span className="bg-green-100 text-green-800 text-sm font-medium  mr- 2  py-0.5  dark:bg-green-200 dark:text-green-900 rounded-lg">Free limited Feature only click on next to Confirm</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default Preview;
