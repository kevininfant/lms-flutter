
import Container from "@components/Container/Container";
import NVLAlert, { ModalClose, ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLMultilineTxtBox from "@components/Controls/NVLMultilineTxtBox";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { deleteXlmsUserGroupInfo, updateXlmsUserGroupInfo } from "src/graphql/mutations";
import { getXlmsUserGroupInfo, listXlmsUserGroupInfos, listXlmsUserListInfos } from "src/graphql/queries";
import * as Yup from "yup";

function EditGroup(props) {
    const router = useRouter();
    const totalCount = useRef(0);

    const [csrFetchedGroupData, setFetchedGroupData] = useState();
    const [modalValues, setModalValues] = useState({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Data Saved Sucessfully", });
    const [isRefreshing, setIsRefreshing] = useState(0);
    const [popupValues, setpopupValues] = useState({ PK: "", Content: "", SK: "", Search: "" });
    const [currentDiv, setCurrentDiv] = useState(false);
    const [textName, setTextName] = useState("Select File");


    useEffect(() => {
        async function fetchData() {
            const tenantId = router.query["TenantID"];
            const groupId = router.query["GroupID"];
            const mode = router.query["mode"];
            const groupResponse = await AppsyncDBconnection(getXlmsUserGroupInfo, { PK: "TENANT#" + tenantId, SK: "GROUPINFO#" + groupId }, props.user.signInUserSession.accessToken.jwtToken);
            const groupUserResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + tenantId + "#GROUPID#" + groupId, SK: "#USERINFO#" }, props.user.signInUserSession.accessToken.jwtToken);
            totalCount.current = groupResponse?.res?.getXlmsUserGroupInfo?.TotalCount != undefined ? groupResponse?.res?.getXlmsUserGroupInfo?.TotalCount : 0;

            setFetchedGroupData({
                groupData: groupResponse?.res?.getXlmsUserGroupInfo,
                groupUserData: groupUserResponse?.res?.listXlmsUserGroupInfos?.items,
                mode: mode,
                GroupID: groupId,
                TenantID: tenantId,
            });
        }
        fetchData();
        return (() => {
            setFetchedGroupData((temp) => { return { ...temp }; });
        });
    }, [props.user.signInUserSession.accessToken.jwtToken, router.query]);

    const headerColumn = useMemo(() => {
        const ltemp = [{ HeaderName: "User Name", Columnvalue: "EmailID", HeaderCss: "!w-1/2" },];
        if (csrFetchedGroupData?.groupData?.AssignmentMethod != "Automatic") {
            ltemp.push({ HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-6/12" },);
        }
        return ltemp;
    }, [csrFetchedGroupData?.groupData?.AssignmentMethod]);

    const resetPopup = useCallback(() => {
        setpopupValues({ PK: "", Content: "", SK: "", Search: "", loader: "" });
    }, []);

    const removeUser = async (e, pk, sk) => {
        setpopupValues((temp) => { return { ...temp, loader: true } });

        e.preventDefault();
        const query = deleteXlmsUserGroupInfo;
        const variables = {
            input: [{ PK: pk, SK: sk, },],
        };
        await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken).then((res) => {
            const query = updateXlmsUserGroupInfo, variable = {
                input: {
                    PK: csrFetchedGroupData?.groupData?.PK,
                    SK: csrFetchedGroupData?.groupData?.SK, TotalCount:
                        totalCount.current - 1,
                        LastModifiedDate: new Date()
                }
            };
            AppsyncDBconnection(query, variable, props.user.signInUserSession.accessToken.jwtToken);
            totalCount.current = totalCount.current - 1;
            setFetchedGroupData((data) => {
                let temp = data.groupUserData, tempgroupUserData = [];
                temp.map((tempuser) => {
                    if (tempuser.SK != sk) {
                        tempgroupUserData = [...tempgroupUserData, tempuser];
                    }
                });
                return { ...data, groupUserData: tempgroupUserData };
            });
            finalResponse(res);
            resetPopup();
            refreshGrid();
        })
            .catch((e) => {
                setpopupValues((temp) => { return { ...temp, loader: false } });
                return e;
            });
    };

    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus.Status != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus.Status, ModalOnClickEvent: () => { resetPopup("Submit"); ModalClose(); } });
            ModalOpen();
            return;
        }
        setModalValues({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Data Saved Sucessfully", });
        ModalOpen();

    }, [resetPopup]);

    const deleteHandler = useCallback(() => {
        const query = deleteXlmsUserGroupInfo;
        let variables = { input: [{ PK: csrFetchedGroupData?.groupData?.PK, SK: csrFetchedGroupData?.groupData?.SK },], };
        if (csrFetchedGroupData?.groupData?.AssignmentMethod == "Automatic") {
            variables = { input: [...variables.input, { PK: csrFetchedGroupData?.groupData?.PK, SK: `AUTOMATIC#${csrFetchedGroupData.groupData.AssignProfile}#${csrFetchedGroupData.groupData.ProfileSearch}` }], };
        }
        AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken).then(() => {
            setModalValues({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been Deleted successfully", ModalOnClickEvent: () => { router.push("/UserManagement/ManageGroupList"); }, });
            ModalOpen();
            // eslint-disable-next-line no-undef
            const pk = pkID + "#GROUPID#" + skID.split("#")[1];
            const fetchURL = `${process.env.APIGATEWAY_URL_DELETEUSERGROUP}?PK=${encodeURIComponent(pk)}&SK=${encodeURIComponent("#USERINFO#")}`;
            const headers = { method: "GET", headers: { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "UserManagement", menuid: "200003", }, };
            APIGatewayGetRequest(fetchURL, headers).then((res) => { res; });
        }).catch((e) => { return e; });
    }, [csrFetchedGroupData?.groupData?.AssignProfile, router, csrFetchedGroupData?.groupData?.AssignmentMethod, csrFetchedGroupData?.groupData?.PK, csrFetchedGroupData?.groupData?.ProfileSearch, csrFetchedGroupData?.groupData?.SK, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken]);

    function popUp(e, type, PK, SK, Content) {
        setpopupValues((data) => { return { ...data, Content: Content, PK: PK, SK: SK, loader: "" }; });
    }

    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        const viewDataTemp = viewData;
        viewDataTemp.map((getItem, index) => {
            const action = [];
            if (csrFetchedGroupData?.groupData?.AssignmentMethod != "Automatic") {
                action.push((<div className="">  <NVLLink id={"lnkRemoveUser" + (index + 1)} text={"Remove User"} type={"link"} onClick={(e) => popUp(e, "isDelete", getItem.PK, getItem.SK, "Are you sure want to remove the user?")} /></div>));
            }
            rowGrid.push({
                Sno: index + 1,
                PK: <NVLlabel id={"lblPKID" + (index + 1)} name="PK" showfull={"full"} text={getItem.PK} />,
                SK: <NVLlabel id={"lblSKID" + (index + 1)} name="SK" showfull={"full"} text={getItem.SK} />,
                EmailID: <NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.EmailID}></NVLlabel>,
                Action: action,
            });
        }, []);
        return rowGrid;
    }, [csrFetchedGroupData?.groupData?.AssignmentMethod]);


    const variable = useMemo(() => {
        return { PK: "TENANT#" + props.TenantInfo.TenantID + "#GROUPID#" + csrFetchedGroupData?.GroupID, SK: "#USERINFO#" };
    }, [csrFetchedGroupData?.GroupID, props.TenantInfo.TenantID]);

    const submitHandler = async (data) => {
        setValue("Submit", true);
        if (currentDiv) {
            upload();
            return;
        }
        const pk = "TENANT#" + router.query["TenantID"];
        const sk = "GROUPINFO#" + router.query["GroupID"];
        if (csrFetchedGroupData?.mode == "Delete") {
            deleteHandler(pk, sk);
            return;
        }
        if (csrFetchedGroupData?.mode == "Edit") {
            const query = updateXlmsUserGroupInfo;
            refreshGrid();
            const variables = {
                input: {
                    PK: pk, SK: sk, TenantID: router.query["TenantID"],
                    GroupDescr: data.txtGroupDesc, LastModifiedDate: new Date(),
                    LastModifiedBy: props.user.username, DeletedDate: "",
                    DeletedBy: "",
                }

            };
            AppsyncDBconnection(query, variables,
                props.user.signInUserSession.accessToken.jwtToken)
                .then(() => {
                    setModalValues({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Data Saved Successfully", ModalOnClickEvent: () => { router.push("/UserManagement/ManageGroupList"); } });
                    ModalOpen();
                    return;
                })
                .catch(() => {
                    setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", });
                    ModalOpen();
                    return;
                });
        }
    };

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };

    const enableBulk = (e) => {
        e.preventDefault();
        setCurrentDiv(true);
    };

    async function upload() {
        const setUploadURL = process.env.APIGATEWAY_URL_CREATEGROUP;
        if (textName == "Select File") {
            setValue("File", "Choose File", { shouldValidate: true });
            return false;
        }
        const dateTime = new Date();
        const statemachinearn = process.env.STEP_FUNCTION_ARN_UPLOADUSERGROUP;
        const randomId = crypto.randomUUID().toString(25).substring(2, 12);
        const key = props.TenantInfo.RootFolder + "/" + csrFetchedGroupData.TenantID + "/CSVBulkUserGroup/Input/" + textName;
        // eslint-disable-next-line no-undef
        const jsonSaveData = '{"TenantId": "' + props.TenantInfo.TenantID + '", "GroupName": "' + txtGroupName.value + '", "GroupDescr": "' + txtGroupDesc.value + '", "FileName":"' + textName + '", "CreatedDate": "' + dateTime + '", "CreatedBy": "' + props.user.username + '", "BucketName": "' + props.TenantInfo.BucketName + '","Key": "' + key + '","RandomID": "' + randomId + '","CompanySub": "' + Auth?.user?.attributes["sub"] + '", "RootFolder": "' + props.TenantInfo.RootFolder + '", "UploadType":"EDIT","GroupID":"' + csrFetchedGroupData?.GroupID + '" }';
        await fetch(setUploadURL + `?S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}`, {
            method: "POST",
            headers: { "Content-Type": "application/json", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "UserManagement", menuid: "200404", statemachinearn: statemachinearn },
            body: jsonSaveData,
        }).catch((e) => (e));
        setModalValues({ ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Data Saved Successfully", ModalOnClickEvent: () => { router.push("/UserManagement/ManageGroupList"); } });
        ModalOpen();
        return;
    }

    async function downloadCsvFile() {
        const userTemplate = [{ HeaderName: "UserSub", Action: "true" }, { HeaderName: "UserName", Action: "true" }, { HeaderName: "EmailID", Action: "true" }, { HeaderName: "Department", Action: "true" }, { HeaderName: "Designation", Action: "true" }, { HeaderName: "FirstName", Action: "true" }, { HeaderName: "LastName", Action: "true" },];
        const userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + router.query["TenantID"], SK: "#USERINFO#", IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
        const userListJson = userData.res.listXlmsUserListInfos.items;
        const rows = [];
        userTemplate.forEach((element) => { element.Action === "true" ? rows.push(element.HeaderName) : ""; });
        let csvContent = rows;
        csvContent += "\r\n";
        const userListData = userListJson.filter(({ EmailID: EmailId }) => !csrFetchedGroupData?.groupUserData.some(({ EmailID: EmailId1 }) => EmailId === EmailId1));
        userListData.forEach((element) => { csvContent += element.UserSub + "," + element.UserName + "," + element.EmailID + "," + element.Department + "," + element.Designation + "," + element.FirstName + "," + element.LastName; csvContent += "\n"; });
        const link = document.createElement("a");
        link.id = "download-csv";
        link.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(csvContent));
        link.setAttribute("download", "UserList.csv");
        link.click();
        link.remove();
    }

    const resetData = useCallback(() => {
        setTextName("Select File");
    }, []);

    const validationSchema = Yup.object().shape({
        txtGroupName: Yup.string(),
        File: Yup.string().test("", "", (e, { createError }) => {
            if (e == "Invalid") {
                return createError({ message: "Invalid Template" });
            }
            if (e == "Not Empty") {
                return createError({ message: "Invalid Template" });
            } else if (e == "Upload File") {
                return createError({ message: "Please Upload File" });
            } else if (e == "Empty Value") {
                return createError({ message: "Empty Values Please Fill them" });
            } else if (e == "Choose File") {
                return createError({ message: "Please Choose File" });
            }
            return true;
        })
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, setValue, handleSubmit, formState, watch } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        setValue("txtGroupName", csrFetchedGroupData?.groupData?.GroupName);
        setValue("txtGroupDesc", csrFetchedGroupData?.groupData?.GroupDescr);
    }, [csrFetchedGroupData?.groupData?.GroupDescr, setValue, csrFetchedGroupData?.groupData?.GroupName]);

    async function fileValidation(e) {
        const fileInput = e.target;
        const filePath = fileInput.value;
        const allowedExtensions = /(\.csv)$/i;
        if (!allowedExtensions.exec(filePath)) {
            setValue("File", "Invalid", { shouldValidate: true });
            setTextName("Select File");
            return false;
        }
        setTextName(fileInput ? fileInput.files[0].name : "");
        await uploadFile(fileInput);

    }
    async function uploadFile(fileInput) {
        const userTemplate = [{ HeaderName: "UserSub", Action: "true" }, { HeaderName: "UserName", Action: "true" }, { HeaderName: "EmailID", Action: "true" }, { HeaderName: "Department", Action: "true" }, { HeaderName: "Designation", Action: "true" }, { HeaderName: "FirstName", Action: "true" }, { HeaderName: "LastName", Action: "true" },];
        const file = fileInput.files[0];
        const csvReader = new FileReader();
        if (file == undefined) {
            setValue("File", "Upload File", { shouldValidate: true });
            resetData();
            return;
        }
        csvReader.onload = async function (e) {
            const text = e.target.result;
            const lines = text.split("\n");
            try {
                let values = lines[0].split(",");
                for (let i = 0; i < userTemplate.length - 1; i++) {
                    if (values[i] != userTemplate[i].HeaderName || values.length != userTemplate.length) {
                        setValue("File", "Invalid", { shouldValidate: true });
                        resetData();
                        return;
                    }
                }
                if (values[userTemplate.length - 1] == userTemplate[userTemplate.length - 1].HeaderName && lines.length == 2) {
                    setValue("File", "Empty Value", { shouldValidate: true });
                    resetData();
                    return;
                }
                values = lines[1].split(",");
                if (values[0] == "" || values[1] == "" || values[2] == "") {
                    setValue("File", "Empty Value", { shouldValidate: true });
                    resetData();
                    return;
                }
                const tempPresignedURL = process.env.APIGATEWAY_URL_CSVPRESIGNEDURL;
                const requestOptions = { method: "GET", headers: { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "UserManagement", menuid: "200306" } };
                try {
                    await fetch(tempPresignedURL + `?csvfile=${fileInput.files[0].name}&tenantid=${router.query["TenantID"]}&path=USERGROUP&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}`, requestOptions)
                        .then((response) => response.text())
                        .then(async (presignedUrl) => {
                            await fetch(presignedUrl, { method: "PUT", body: file, });
                            setValue("File", "Success", { shouldValidate: true });
                        })
                        .catch((error) => ("Error Occured. \n Error Details: " + error));
                } catch (err) {
                    ("Error");
                }
            } catch (error) {
                ("Error Occured. \n Error Details: " + error);
                resetData();
                return;
            }
        };
        csvReader.readAsText(file);
    }
    const searchBoxVal = (e) => {
        setpopupValues((data) => { return { ...data, Search: e }; });
    };

    const refreshGrid = async () => {
        setpopupValues((data) => { return { ...data, Search: "" }; });
        setIsRefreshing((count) => { return count + 1; });
    };


    const pageRoutes = useMemo(() => {
        return [
            { path: "/UserManagement/UserList", breadcrumb: "User Management" },
            { path: "/UserManagement/ManageGroupList", breadcrumb: "Manage Group" },
            { path: "", breadcrumb: csrFetchedGroupData?.mode == "Edit" ? "Edit Group" : "Delete Group" }
        ];
    }, [csrFetchedGroupData?.mode]);

    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedGroupData?.mode == undefined}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)} className={watch("submit") ? "pointer-events-none" : ""} >
                    <div className="nvl-FormContent">
                        <NVLTextbox labelText="Group Name" labelClassName="nvl-Def-Label" id="txtGroupName" register={register} errors={errors} disabled={csrFetchedGroupData?.mode == "Edit" && true} className={csrFetchedGroupData?.mode != "Create" ? "Disabled placeholder:px-0 nvl-mandatory nvl-Def-Input" : "placeholder:px-0 nvl-mandatory nvl-Def-Input"} placeholder="Group Name" ></NVLTextbox>
                        <div className={currentDiv ? "hidden" : ""}>
                            <NVLMultilineTxtBox labelText="Group Description" labelClassName="nvl-Def-Label" id="txtGroupDesc" register={register} errors={errors} className={csrFetchedGroupData?.mode == "Delete" ? "Disabled nvl-Def-Input" : "nvl-Def-Input nvl-non-mandatory"} placeholder="Group Description"></NVLMultilineTxtBox>
                        </div>
                        <div className={currentDiv ? "hidden" : " flex justify-center gap-1 nvl-Def-Input"}>
                            <NVLButton id="btnSubmit" type={"Submit"} text={!watch("submit") ? (csrFetchedGroupData?.mode == "Edit" ? "Submit" : "Delete") : ""} disabled={watch("submit") ? true : false} className={`w-28 nvl-button ${csrFetchedGroupData?.mode == "Edit" ? "bg-primary" : "bg-red-600"} text-white`} >{watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
                            <NVLButton id={"btnCancel"} type="button" text={"Cancel"} className="nvl-button w-28" onClick={() => router.push("/UserManagement/ManageGroupList")} />
                        </div>
                        <section id="divBulkUpload" className={currentDiv ? "" : "hidden"}>
                            <div className="pt-4">
                                <div className="flex xl:flex-wrap items-center">
                                    <div className="pt-1">
                                        <NVLlabel
                                            text="Upload File"
                                            className="nvl-Def-Label"
                                            HelpInfo={`${"Acceptable file format: .csv <br>File size should be 5MB"}`}
                                            HelpInfoIcon={"fa fa-solid fa-circle-question"}
                                        />
                                    </div>
                                    <div className="flex-none">
                                        <NVLFileUpload format=".csv" text={textName} className={"w-1/3"} onChange={(e) => fileValidation(e)} />
                                        <div className={"{invalid-feedback}   text-red-500 text-sm "}>{errors?.File?.message}</div>
                                    </div>
                                    <div className="pt-3 px-6 ">
                                        <NVLlabel text={"Download sample template"} className="nvl-Def-Label" />
                                    </div>
                                    <div className="pt-3 ">
                                        <NVLButton text={"Download"} type={"button"} className="bg-primary nvl-button rounded-2xl text-white" onClick={() => downloadCsvFile()} />
                                    </div>
                                </div>
                            </div>
                            <div className="flex justify-center pt-6">
                                <NVLButton text="Upload" type={"submit"} className="nvl-button bg-primary text-white w-40 h-10" />
                            </div>
                        </section>
                    </div>
                    <div className="nvl-FormContent">
                        <NVLlabel text={`Assignment Method : ${csrFetchedGroupData?.groupData?.AssignmentMethod}`} className="nvl-Def-Label" />
                        {csrFetchedGroupData?.groupData?.AssignmentMethod == "Automatic" &&
                            <>
                                <NVLlabel text={`Assign Profile : ${csrFetchedGroupData?.groupData?.AssignProfile}`} className="nvl-Def-Label" />
                                <NVLlabel text={`Assign Profile Value : ${csrFetchedGroupData?.groupData?.ProfileSearch}`} className="nvl-Def-Label" showFull />
                            </>
                        }
                    </div>
                    <div className="pt-8">
                        {csrFetchedGroupData?.groupData?.AssignmentMethod != "Automatic" && <NVLHeader placeholder={"Search by User Name"} onClick1={refreshGrid} IsSearch={true} SearchonChange={(e) => searchBoxVal(e)} LinkName2={"Add User"} type1={"button"} DisableButton2={csrFetchedGroupData?.mode == "Delete" ? true : false} variant={csrFetchedGroupData?.mode == "Delete" ? "light" : "success"} LinkName1={"Bulk Upload"} DisableButton1={csrFetchedGroupData?.mode == "Delete" ? true : false} RedirectAction1={(e) => enableBulk(e)} type2={"button"} RedirectAction2={(e) => headerHandler(e, `/UserManagement/AddUser?TenantID=${csrFetchedGroupData?.TenantID}&GroupName=${csrFetchedGroupData.GroupID}&mode=Edit`)} IsNestedHeader TableID={"tblUserDetails"} />}
                        {csrFetchedGroupData?.groupUserData && csrFetchedGroupData?.groupUserData?.length > 0 ? <div className="pt-3">{<NVLGridTable user={props.user} refershPage={isRefreshing} Search={popupValues.Search} id="tblUserList" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsUserGroupInfos} querryName={"listXlmsUserGroupInfos"} variable={variable} />}</div> : <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />}
                    </div>
                    <div id="divNoRecord" className="hidden">
                        <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />
                    </div>
                    <div id="isModaldiv" className="">
                        <NVLModalPopup ButtonYestext="Yes" ButtonNotext="No" CancelClick={() => resetPopup()} isModal={false} CloseIconEvent={() => resetPopup()} SubmitClick={(e) => removeUser(e, popupValues.PK, popupValues.SK)} Content={popupValues.Content} loader={popupValues.loader}></NVLModalPopup>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default EditGroup;
