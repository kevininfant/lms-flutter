import Container from "@Container/Container";
import NVLHeader from "@Controls/NVLHeader";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import NVLlabel from "@components/Controls/NVLlabel";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import PropTypes from "prop-types";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { updateXlmsUserInfo } from "src/graphql/mutations";
import { getXlmsLoginPolicy, getXlmsTenantInfo, listXlmsUserInfos } from "src/graphql/queries";
import ChangePassword from "./ChangePassword";

export default function UserList(props) {
    const router = useRouter();
    const variable = useMemo(() => ({ PK: "TENANT#" + props.TenantInfo.TenantID, SK: "#USERINFO#" }), [props.TenantInfo.TenantID]);
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [modalValues, setModalValues] = useState({});
    const [popupValues, setPopupValues] = useState({});
    const [getTenantData, setTenantData] = useState("");
    const PasswordChange = useRef();
    const [search, setSearch] = useState("");
    const [open, setOpen] = useState(false);

    const initialModalState = useMemo(()=>{
     return ({
     ModalInfo: "Success",
     ModalTopMessage: "Success",
     ModalBottomMessage: "Password changed successfully.",
     ModalOnClickEvent: () => {
       router.push("/UserManagement/UserList")
     }})
     
    },[router])

     const [successPopup, setSuccessPopup] = useState({});
      
      const finalResponse = useCallback((finalStatus) => {
        if (finalStatus != "Success") {
            setSuccessPopup({
            ModalInfo: "Danger",
            ModalTopMessage: "Error",
            ModalBottomMessage: finalStatus,
          });
          ModalOpen();
          return;
        } else {
          setSuccessPopup(initialModalState)
          setOpen((open) => {
                  return false;
                });
            
          ModalOpen();
        }
      }, [initialModalState]);

    useEffect(() => {
        async function fetchData() {
            const loginPolicy = await AppsyncDBconnection(getXlmsLoginPolicy, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "POLICY#LOGINPOLICY" }, props.user.signInUserSession.accessToken.jwtToken);
            PasswordChange.current = { ...PasswordChange.current, LoginPolicy: loginPolicy.res?.getXlmsLoginPolicy }
        }
        fetchData();
    }, [props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken])

    // Grid headers
    const headerColumn = useMemo(() => ([
        { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "!w-2/12" },
        { HeaderName: "Name", Columnvalue: "FirstName", HeaderCss: "!w-4/12" },
        { HeaderName: "Email", Columnvalue: "EmailID", HeaderCss: "!w-2/12" },
        { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "!w-2/12", },
        { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-2/12" },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-0/12" },
    ]), []);

    //Search box
    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    //Grid data refresh
    const refreshData = useCallback(() => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    }, [])

    // Resets the value in Alert
    function resetPopUp() {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "", UserName: "", loader: "" });
        setSearch("");
    }

    // Binds the value in Alert 
    function popUp(type, PK, SK, Content, UserName) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type, UserName: UserName, loader: "" });
    }

    async function updateField(e) {
        setPopupValues((temp) => { return { ...temp, loader: true } });
        e.preventDefault();
        let isSus = false;
        if (popupValues.Type == "isSuspend") isSus = true;
        const arn = isSus ? process.env.STEP_FUNCTION_ARN_SUSPENDUSER : process.env.STEP_FUNCTION_ARN_UNSUSPENDUSER;
        const api = isSus ? process.env.APIGATEWAY_URL_SUSPENDUSER : process.env.APIGATEWAY_URL_UNSUSPENDUSER;
        const jsonSaveData = '{' + '"TenantId": "' + props.TenantInfo.TenantID + '", "Username": "' + popupValues.UserName + '","IsSuspend": ' + isSus + ',  "UserSub": "' + popupValues.SK + '" }';
        const presignedHeader = { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "UserManagement", menuid: popupValues.Type == "isSuspend" ? "200201" : "200205", statemachinearn: arn }, body: jsonSaveData, };
        let finalStatus = await APIGatewayPostRequest(api, presignedHeader);
        if (finalStatus.Status == "Success") {
            let message = "";
            if (popupValues.Type == "isSuspend") {
                message = "Suspend is in progress";
            }
            else {
                message = "UnSuspend is in progress";
            }
            const variables = { input: { PK: popupValues.PK, SK: popupValues.SK, Status: message, LastModifiedDate: new Date() }, };
            finalStatus = (await AppsyncDBconnection(updateXlmsUserInfo, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
            if (finalStatus != "Success") {
                setModalValues({ ModalInfo: "Danger", ModalBottomMessage: finalStatus, });
                ModalOpen();
            } else {

                refreshData();
            }
        } else {
            setPopupValues((temp) => { return { ...temp, loader: false } });
            setModalValues({ ModalInfo: "Danger", });
            ModalOpen();
        }
        resetPopUp();
    }
    // To restrict user action based on their roles and permission
    const actionRestriction = useCallback((getItem) => {
        const actionList = [];
        if (props.RoleData?.EditUser && !(getItem.IsSuspend == "true")) {
            actionList.push(
                {
                    id: 1,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Edit",
                    action: () => router.push(`/UserManagement/UserDetails?Mode=Edit&UserSub=${getItem.UserSub}`),
                },
            );
            actionList.push(
                {
                    id: 4,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Change Password",
                    action: () => { PasswordChange.current = { ...PasswordChange.current, UserName: getItem.UserName, Name: getItem.FirstName + " " + getItem.LastName }; setOpen(true); },
                },
            );
        }
        if ((props.RoleData?.EditUser && !(getItem.IsSuspend == "true")) && (getItem?.RoleName != "CompanyAdmin" && getItem?.RoleName != "Trainer")) {
            actionList.push(
                {
                    id: 2,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-book bg-green-100 w-6",
                    name: "User Report",
                    action: () => router.push(`/UserManagement/UserPerformanceReport?UserSub=${getItem.UserSub}&UserName=${getItem.FirstName + " " + getItem.LastName}`),
                }

            );
        }
        if (props.RoleData?.SendNotificationUser && !(getItem.IsSuspend == "true")) {
            actionList.push(
                {
                    id: 1,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                    name: "Send Notfication",
                    action: () => router.push(`/UserManagement/Notification?Mode=User&UserSub=${getItem.UserSub}&UserID=${getItem.EmailID}`),
                },

            );
        }
        if (props.RoleData?.SuspendUser && !(getItem.IsSuspend == "true")) {
            actionList.push(
                {
                    id: 2,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                    name: "Suspend User",
                    className: "hidden",
                    action: () => popUp("isSuspend", getItem.PK, getItem.SK, "Are you sure Want to Suspend User?", getItem.UserName),
                },
            );
        }
        if (props.RoleData?.UnSuspendUser && (getItem.IsSuspend == "true")) {
            actionList.push({
                id: 1,
                Color: "text-yellow-600",
                Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                name: "Unsuspend User",
                action: () => popUp("isUnSuspend", getItem.PK, getItem.SK, "Are you sure Want to UnSuspend User?", getItem.UserName),
            },);
        }

        return actionList;
    }, [props.RoleData?.EditUser, props.RoleData?.SendNotificationUser, props.RoleData?.SuspendUser, props.RoleData?.UnSuspendUser, router]);

    const gridDataBind = useCallback(
        (viewData) => {
            const rowGrid = [];
            viewData.map((getItem, index) => {
                !getItem.IsDeleted && getItem.FirstName != null
                    ? rowGrid.push({
                        PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
                        SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="PK" text={getItem.SK} />),
                        UserName: (<NVLlabel id={"txtName" + (index + 1)} text={getItem.UserName?.toLowerCase()} />),
                        FirstName: (<NVLlabel id={"txtName" + (index + 1)} text={getItem.FirstName + " " + getItem.LastName} className="whitespace-nowrap" />),
                        EmailID: (<NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.EmailID} />),
                        Department: (<NVLlabel id={"txtDepartment" + (index + 1)} text={getItem.Department}></NVLlabel>),
                        Action: !(getItem.IsSuspend == "false") ?
                            (<div className={getItem.Status?.indexOf("progress") != -1 ? "pointer-events-none" : ""}><NVLRapidModal
                                id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal></div>)
                            : (<div className={getItem.Status?.indexOf("progress") != -1 ? "pointer-events-none" : ""}><NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal></div>),
                        Status: (<NVLlabel className={!(getItem.IsSuspend == "false") ? "text-red-500" : getItem?.Status?.includes("progress") ? "text-red-500" : "text-green-500"} text={getItem.Status != "InActive" ? getItem.Status : "Suspended"} />),
                    })
                    : "";
            });
            return rowGrid;
        }, [actionRestriction]);

    const headerHandler = async (e, url, mode) => {
        e.preventDefault();
        async function getActiveUserCount() {
            const tenantId = props?.user?.attributes["custom:tenantid"];
            const tenantData1 = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + tenantId, }, props?.user?.signInUserSession.accessToken.jwtToken)
            return tenantData1?.res?.getXlmsTenantInfo;
        }

        const activeUserCount = await getActiveUserCount();
        if (activeUserCount?.UserCount >= 10 && activeUserCount?.PlanCode == "Free" && mode == "Create") {
            setPopupValues({ Content: "The current subscribed plan's user count limit reached. Either increase the user count of the current plan or upgrade the plan to continue.", Type: "Exceed" });
            return false;
        }
        else {
            router.push(url);
        }
    }

    // cancelation of  alert box 
    const cancelEvent = (e) => {
        e.preventDefault();
        resetPopUp();
    };


    // Bread Crumbs
    const pageRoutes = useMemo(() => { return [{ path: "", breadcrumb: "User Management" }]; }, []);

    return (
        <>
            <Container title="User Management" PageRoutes={pageRoutes} loader={getTenantData == undefined}>
                <NVLPageModalPopup
                    ModalType="Page"
                    ScreenName={"Change Password"}
                    PageComponent={<ChangePassword user={props.user} setOpen={setOpen} refreshData={refreshData} finalResponse={finalResponse} PasswordChange={PasswordChange.current} />}
                    open={open}
                    setOpen={setOpen}
                />
               <NVLAlert ButtonYestext={"X"} MessageTop={successPopup.ModalTopMessage} MessageBottom={successPopup.ModalBottomMessage} ModalOnClick={successPopup.ModalOnClickEvent} ModalInfo={successPopup.ModalInfo} />

                <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab}
                    LinkName5="Manage Group"

                    className5={props.RoleData?.ManageGroup ? (props.TabRouting == true ? " " : "nvl-button-success") : "hidden"}
                    href5="/UserManagement/ManageGroupList"
                    RedirectAction5={(e) => headerHandler(e, "/UserManagement/ManageGroupList")} LinkName4="+ Create Group"
                    className4={props.RoleData?.CreateGroup ? (props.TabRouting == true ? " " : "nvl-button-success") : "hidden"}
                    href4={`/UserManagement/CreateGroup?mode=Create&TenantID=${props.TenantInfo.TenantID}`}
                    RedirectAction4={(e) => headerHandler(e, `/UserManagement/CreateGroup?mode=Create&TenantID=${props.TenantInfo.TenantID}`)}
                    LinkName3="Upload User" className3={props.RoleData?.UploadUser ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"}
                    RedirectAction3={(e) => headerHandler(e, "/UserManagement/UploadUser")} href3="/UserManagement/UploadUser"
                    LinkName2={"+ Create User"}
                    className2={(((getTenantData.ActiveUserCount) == 10) && getTenantData.PlanCode == "Free") ? "nvl-button-success" :
                        (props.RoleData?.CreateUser ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden")}
                    RedirectAction2={async (e) => headerHandler(e, "/UserManagement/UserDetails?Mode=Create", "Create")}
                    href2="/UserManagement/UserDetails?Mode=Create"
                    onClick1={refreshData} RedirectHome={"/"}
                    IsSearch={props.RoleData?.UserSeTenanth ? true : false} placeholder={"Search by Name/Email"}
                    SearchonChange={(e) => searchBoxVal(e)}
                    TableID={"tblUserList"} IsNestedHeader className={"lg:!grid-cols-5"} />
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <NVLGridTable user={props.user} refershPage={isRefreshing} id="tblUserList" Search={search} HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsUserInfos} querryName={"listXlmsUserInfos"} variable={variable} />
                <NVLModalPopup
                    ButtonYestext={`${popupValues.Type == "Exceed" ? "" : "Yes"}`} SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext={`${popupValues.Type == "Exceed" ? "Ok" : "No"}`} CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} loader={popupValues.loader} />

            </Container>
        </>
    );
}

UserList.defaultProps = {
    color: "light",
};

UserList.propTypes = {
    color: PropTypes.oneOf(["light", "dark"]),
};
