import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLMultiSelect from "@components/Controls/NVLMultiSelectDropdown";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsUserGroupInfo } from "src/graphql/mutations";
import { listXlmsAutomaticUserGroupListInfos, listXlmsCustomFields, listXlmsUserGroupInfos, listXlmsUserListInfos } from "src/graphql/queries";
import * as Yup from "yup";

function CreateGroup(props) {
  const router = useRouter();
  const initialModalState = {
    ModalType: props.mode === "Edit" ? "Success" : "Info",
    ModalTopMessage: props.mode === "Edit" ? "Success" : "In Progress",
    ModalBottomMessage: props.mode === "Edit" ? "Details have been saved successfully." : "Creation is in progress. Will contact you once the creation is over",
    ModalOnClickEvent: () => {
      router.push("/UserManagement/UserList");
    },
  };
  const previousState = useRef({ txtGroupName: {} });
  const [modalValues, setModalValues] = useState(initialModalState);
  const [currentDiv, setCurrentDiv] = useState("");
  const [selectedProfileData, setSelectedProfileData] = useState([{ value: "", text: "Select" }]);
  const [multiselected, setMultiSelected] = useState([]);
  const [textName, setTextName] = useState("Select File");
  const [automaticHandler, setAutomatichandler] = useState();

  const refDiv = useRef();
  const refSelectAll = useRef();
  const refMultiselect = useRef([]);
  const refReset = useRef(false);
  const refError = useRef("Validate");
 

  const validationSchema = Yup.object().shape({
    txtGroupName: Yup.string()
      .required("Group Name is Required")
      .matches(Regex("AlphaNumForTopicName"), "Invalid Group Name").max(250, "Maximum length exceeded 250")
      .test("check", ("Group Name Already exists"), async (e, { createError }) => {
        setValue("txtGroupName",e);
        if (e == "" || !Regex("AlphaNumForTopicName").exec(e)) {
          previousState.current = { ...previousState.current, txtGroupName: { previousVal: e, previousState: false } };
          return false;
        }
        if (previousState.current?.txtGroupName?.previousVal != undefined && e == previousState.current.txtGroupName?.previousVal) {
          return previousState.current.txtGroupName.previousState;
        }

        const query = listXlmsUserGroupInfos, variables = { PK: "TENANT#" + router.query["TenantID"], SK: "GROUPINFO#", TenantDisplayName: e.toUpperCase() };
        const finalResult = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession.accessToken.jwtToken));

        if (finalResult.Status == "Success") {

          if (finalResult.res?.listXlmsUserGroupInfos?.items.length > 0) {

            previousState.current = {
              ...previousState.current, txtGroupName: { previousVal: e, previousState: false }
            };
            const exitingGroupName = finalResult.res?.listXlmsUserGroupInfos?.items;
            const groupNameCheck = exitingGroupName?.some((items) =>
              items?.GroupName?.toLowerCase() == e?.toLowerCase());
            if (groupNameCheck) {
              return createError({ message: "Group Name Already exists" });
            }
          }
          previousState.current = { ...previousState.current, txtGroupName: { previousVal: e, previousState: true } };
          return true;
        }

      }),
    txtGroupDesc: Yup.string(),
    AssignMethod: Yup.string()
      .required()
      .test("novalid", "novalid", (e) => {
        setCurrentDiv(e);
        return true;
      }),
    ddlAssignProfile: Yup.string().when("AssignMethod", {
      is: "Automatic",
      then: Yup.string()
        .required("Assign By Profile is required")
        .test("noValid", "noValid", (e) => {
          setMultiSelected([]);
          reset({}, { keepValues: true, keepDirty: true });
          refMultiselect.current.resetSelectedValues();
          profileHandler(e);
          return true;
        }),
    }),
    file: Yup.string().when("AssignMethod", {
      is: "BulkUpload",
      then: Yup.string().test("Novalid", "", (e, { createError }) => {
        setValue("ddlAssignProfile", "");
        setMultiSelected([]);
        reset({}, { keepValues: true, keepDirty: true });
        refMultiselect.current.resetSelectedValues();
        if ((e == "Empty" || e == undefined) && textName) {
          return createError({ message: e == undefined ? "Please upload file" : "Please Fill Values in the File" });
        } else if (e == "Header") {
          return createError({
            message: "Please Check the Template for header values",
          });
        }
        return true;
      }),
    }),
    user: Yup.string().when("AssignMethod", {
      is: "Manual",
      then: Yup.string().test("Novalid", "", (e, { createError }) => {
        manualHandler();
        reset({}, { keepValues: true, keepDirty: true });
        if (refSelectAll.current) return true;
        let CustomError = multiselected?.length == 0 ? "Validate" : "No Validation";

        if ((e == "Empty" || e == undefined || CustomError == "Validate") && multiselected?.length == 0) {
          return createError({ message: "Please choose users from the list" });
        }
        return true;
      }),
    }),
    ddlSearch: Yup.string().when("ddlAssignProfile", {
      is: "",
      then: Yup.string(),
      otherwise: Yup.string().required("Search value is Required"),
    }),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, reset, watch, formState, setValue } = useForm(formOptions);
  const { errors } = formState;


  useEffect(() => {
    async function fetchData() {
      const tenantId = router.query["TenantID"];
      const customFieldList = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#", }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const response = customFieldList?.res?.listXlmsCustomFields?.items;
      const groupList = await AppsyncDBconnection(listXlmsAutomaticUserGroupListInfos, { PK: "TENANT#" + tenantId, SK: "GROUPINFO#", AssignmentMethod: "Automatic", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const responseGroupList = groupList?.res?.listXlmsAutomaticUserGroupListInfos?.items;

      let automaticHandler = {};
      response?.map((getItem) => {
        if (getItem.IsApplicableForGroup) {
          automaticHandler = { ...automaticHandler, [getItem.ProfileFieldNameLower]: getItem };
        }
        setAutomatichandler({ AutomaticHandler: automaticHandler, response: response, groupData: responseGroupList });
      });
    }
    fetchData();
    setValue("rbSelectMethod", "UserOrGroup");
    return (() => {
      setAutomatichandler((temp) => { return { ...temp }; });
    });

  }, [props?.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue])

  const assignProfile = useMemo(() => {
    let temp = [{ value: "", text: "Select Field" }];
    const keys = Object.keys(automaticHandler?.AutomaticHandler != undefined ? automaticHandler?.AutomaticHandler : {});
    if (keys?.length > 0)
      keys.map((keys) => {
        temp = [...temp, { value: keys, text: automaticHandler.AutomaticHandler?.[keys]?.ProfileFieldName }];
      });
    return temp;
  }, [automaticHandler?.AutomaticHandler]);

  const manualHandler = async () => {
    setValue("ddlAssignProfile", "");
    setValue("ddlSearch", "");
    setTextName("Select File");
    setCurrentDiv("Manual");
  };

  async function upload() {
    const setUploadURL = process.env.APIGATEWAY_URL_CREATEGROUP;
    const statemachinearn = process.env.STEP_FUNCTION_ARN_UPLOADUSERGROUP;
    const tenantId = router.query["TenantID"];
    const randomId = crypto.randomUUID().toString(25).substring(2, 12);
    const groupId = crypto.randomUUID().toString(25).substring(2, 12);
    const key = props.TenantInfo.RootFolder + "/" + tenantId + "/CSVBulkUserGroup/Input/" + textName;
    // eslint-disable-next-line no-undef
    const jsonSaveData = "{" + '"TenantId": "' + tenantId + '", "GroupName": "' + txtGroupName.value + '", "GroupDescr": "' + txtGroupDesc.value + '", "FileName":"' + textName + '", "BucketName": "' + props.TenantInfo.BucketName + '", "RootFolder": "' + props.TenantInfo.RootFolder + '", "CreatedDate": "' + new Date() + '", "CreatedBy": "' + props.user.username + '","Key": "' + key + '","RandomID": "' + randomId + '","GroupID": "' + groupId + '","CompanySub": "' + Auth?.user?.attributes["sub"] + '", "UploadType":"ADD"' + "}";

    await fetch(setUploadURL + `?S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: "UserManagement",
        menuid: "200404",
        statemachinearn: statemachinearn,
      },
      body: jsonSaveData,
    }).catch((e) => { return e; });
    resetData();
    setModalValues({
      ModalInfo: "Success",
      ModalOnClickEvent: () => {
        router.push("/UserManagement/ManageGroupList");
      },
    });
    ModalOpen();
  }

  const profileHandler = (e) => {
    setSelectedProfileData(() => {
      let temp = [{ value: "", text: "Select" }];
      if (automaticHandler?.AutomaticHandler?.[e]?.FieldOptions != undefined)
        temp = JSON.parse(automaticHandler?.AutomaticHandler?.[e].FieldOptions);

      automaticHandler?.groupData?.forEach(destination => {
        const matchedIndex = temp.findIndex(source => source.text.toLowerCase() === destination.ProfileSearch.toLowerCase());

        if (matchedIndex !== -1) {
          temp.splice(matchedIndex, 1);
        }
      });
      return temp;
    });
  };

  const submitHandler = async (data) => {
    if (multiselected?.length == 0 && data.AssignMethod == "Manual") {
      setValue("user", "Empty", { shouldValidate: true });
      return false;
    }
    setValue("submit", true);
    document.getElementById("btnSubmit").disabled = true;
    const pk = "TENANT#" + router.query["TenantID"];
    const groupId = crypto.randomUUID().toString(25).substring(2, 12);
    const sk = "GROUPINFO#" + groupId;

    if (data.AssignMethod == "BulkUpload") {
      upload();
      return;
    }
    try {
      setValue("submit", true);
      let userListJson = [];
      let FinalData = [];
      let userListKeys = [], UserSub = [];
      if (data.AssignMethod == "Automatic") {
        const fetchURL = process.env.GET_SINGLE_FILTER_LIST_ITEM + `?PK=${encodeURIComponent(pk)}&SK=${encodeURIComponent("#USERINFO#")}&CustomFieldName=${encodeURIComponent(ddlAssignProfile.options[ddlAssignProfile.selectedIndex].text)}&CustomFieldValue=${encodeURIComponent(data.ddlSearch)}`;
        const userRecords = await APIGatewayGetRequest(fetchURL, {
          method: "GET",
          headers: {
            "Content-Type": "application/text",
            authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
            defaultrole: props.TenantInfo.UserGroup,
            groupmenuname: "UserManagement",
            menuid: "200002",
          },
        });
        const usersDetails = JSON.parse(await userRecords?.res?.text());
        userListKeys = Object.keys(usersDetails);
        if (userListKeys.length > 0) {
          userListKeys.forEach((element) => {
            UserSub = [...UserSub, usersDetails?.[element].UserSub];
            FinalData = [...FinalData, {
              GsiPK: "#USERINFO#" + usersDetails?.[element].UserSub, GsiSK: usersDetails?.[element].PK + "#GROUPID#" + groupId, PK: usersDetails?.[element].PK + "#GROUPID#" + groupId, SK: "#USERINFO#" + usersDetails?.[element].UserSub, EmailID: usersDetails?.[element].EmailID, GroupName: data.txtGroupName, UserID: usersDetails?.[element].UserName, UserSub: usersDetails?.[element].UserSub, CreatedDate: new Date(), CreatedBy: props.user.username, LastModifiedBy: props.user.username, LastModifiedDate: new Date(), Department: usersDetails?.[element].Department
              , Designation: usersDetails?.[element].Designation
              , LastName: usersDetails?.[element].LastName
              , FirstName: usersDetails?.[element].FirstName
            }];
          });
          FinalData = [...FinalData, { PK: pk, SK: "AUTOMATIC#" + ddlAssignProfile.options[ddlAssignProfile.selectedIndex].text.replace(/\s/g, "") + "#" + data.ddlSearch.toLowerCase().replace(/\s/g, ""), AssignProfile: ddlAssignProfile.options[ddlAssignProfile.selectedIndex].text, ProfileSearch: data.ddlSearch, GroupID: groupId, GroupName: data.txtGroupName }];
        } else {
          setModalValues({
            ModalInfo: "Danger",
            ModalBottomMessage: "No Users Found",
          });
          ModalOpen();
          setValue("submit", false);
          return;
        }
      }
      if (data.AssignMethod == "Manual") {

        const usersDetails = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + router.query["TenantID"], SK: "#USERINFO#", IsSuspend: false }, props?.user.signInUserSession.accessToken.jwtToken);
        userListJson = usersDetails.res.listXlmsUserListInfos.items;
        for (let i = 0; i < multiselected.length; i++) {
          const userValue = userListJson.find((temp) => temp.SK == multiselected[i].value);
          UserSub = [...UserSub, userValue.UserSub];
          FinalData = [...FinalData, {
            GsiPK: "#USERINFO#" +
              userValue.UserSub, GsiSK: userValue.PK + "#GROUPID#" + groupId,
            PK: userValue.PK + "#GROUPID#" + groupId, SK: "#USERINFO#" + userValue.UserSub,
            EmailID: userValue.EmailID, UserID: userValue.UserName, GroupName: data.txtGroupName,
            UserSub: userValue.UserSub, CreatedDate: new Date(), CreatedBy: props.user.username,
            LastModifiedBy: props.user.username, LastModifiedDate: new Date(),
            Department: userValue.Department
            , Designation: userValue.Designation
            , LastName: userValue.LastName
            , FirstName: userValue.FirstName
          }];
        }
      }
      if (FinalData.length > 0) {
        AppsyncDBconnection(
          createXlmsUserGroupInfo,
          {
            input: [
              {
                PK: pk,
                SK: sk,
                TenantID: router.query["TenantID"],
                GroupName: data.txtGroupName,
                GroupNameLower: data.txtGroupName.toLowerCase(),
                GroupDescr: data.txtGroupDesc,
                AssignmentMethod: data.AssignMethod,
                AssignProfile: ddlAssignProfile.options[ddlAssignProfile.selectedIndex].text.replace(/\s/g, ""),
                ProfileSearch: data.ddlSearch,
                UserID: "",
                GroupID: groupId,
                UserSub: props.user.attributes.sub,
                Status: "Live",
                IsDeleted: false,
                IsSuspend: false,
                CreatedDate: new Date(),
                CreatedBy: props.user.username,
                LastModifiedDate: new Date(),
                DeletedDate: "",
                DeletedBy: "",
                TotalCount: data.AssignMethod == "Manual" ? multiselected.length : userListKeys.length,
              },
              ...FinalData,
            ],
          },
          props?.user.signInUserSession.accessToken.jwtToken
        )
          .then(() => {
            const fetchURL = process.env.APIGATEWAY_URL_USERGROUPNOTIFICATION;
            var jsonSaveData = {
              TenantID: router.query["TenantID"],
              GroupName: data.txtGroupName,
              CompanyName: props.TenantInfo.TenantName,
              UserSub: UserSub
            };
            const headers = {
              method: "POST",
              headers: {
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                menuid: "200004",
                groupmenuname: "UserManagement",
                defaultrole: props.TenantInfo.UserGroup,
              },
              body: JSON.stringify(jsonSaveData)
            };


            APIGatewayPostRequest(fetchURL, headers);

            setModalValues({
              ModalInfo: "Success",
              ModalOnClickEvent: () => {
                router.push("/UserManagement/ManageGroupList");
              },
            });
            ModalOpen();
          })
          .catch(() => {
            setModalValues({
              ModalInfo: "Danger",
            });
            ModalOpen();
          });
      } else {
        setModalValues({
          ModalInfo: "Danger",
          ModalBottomMessage: "No Users Found",
        });
        ModalOpen();
        setValue("submit", false);

        return;
      }
      
    } catch (e) {
      setModalValues({
        ModalInfo: "Danger",
        ModalBottomMessage: "Server Error",
      });
      ModalOpen();
      setValue("submit", false);
    }
  };

  function resetData() {
    setTextName("select file");
    document.getElementById("getFile").value = null;
  }

  async function fileValidation() {
    const fileInput = document.getElementById("getFile");
    const filePath = fileInput.value;
    const allowedExtensions = /(\.csv)$/i;
    if (!allowedExtensions.exec(filePath)) {
      alert("Invalid file type");
      fileInput.value = "";
      setTextName("select file");
      return false;
    }
    setTextName(document.getElementById("getFile") != null ? document.getElementById("getFile").files[0].name : "");
    checkFile();
  }

  const userTemplate = [
    { HeaderName: "UserSub", Action: "true" },
    { HeaderName: "UserName", Action: "true" },
    { HeaderName: "EmailID", Action: "true" },
    { HeaderName: "Department", Action: "true" },
    { HeaderName: "Designation", Action: "true" },
    { HeaderName: "FirstName", Action: "true" },
    { HeaderName: "LastName", Action: "true" },
  ];

  async function downloadCsvFile() {
    const userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + router.query["TenantID"], SK: "#USERINFO#", IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
    const userListJson = userData.res.listXlmsUserListInfos?.items;
    const rows = [];
    userTemplate.forEach((element) => {
      element.Action === "true" ? rows.push(element.HeaderName) : "";
    });
    let csvContent = rows;
    csvContent += "\r\n";
    userListJson?.forEach((element) => {
      csvContent += element.UserSub + "," + element.UserName + "," + element.EmailID + "," + element.Department + "," + element.Designation + "," + element.FirstName + "," + element.LastName;
      csvContent += "\n";
    });
    const link = document.createElement("a");
    link.id = "download-csv";
    link.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(csvContent));
    link.setAttribute("download", "UserList.csv");
    link.click();
    link.remove();
  }

  function checkFile() {
    const file = document.getElementById("getFile").files[0];
    const csvReader = new FileReader();
    csvReader.onload = async function (e) {
      const text = e.target.result;
      const lines = text.split("\n");
      let values = lines[0].split(",");
      for (let i = 0; i < userTemplate.length - 1; i++) {
        if (values[i] != userTemplate[i].HeaderName || values.length != userTemplate.length) {
          setValue("file", "Header", { shouldValidate: true });
          document.getElementById("getFile").value = null;

          resetData();
          return;
        }
      }
      if (values[userTemplate.length - 1] == userTemplate[userTemplate.length - 1].HeaderName && lines.length == 2) {
        setValue("file", "Header", { shouldValidate: true });
        resetData();
        return;
      }
      values = lines[1].split(",");
      if (values[0] == "" || values[1] == "" || values[2] == "") {
        setValue("file", "Header", { shouldValidate: true });
        resetData();
        return;
      }
      uploadFile();
    };
    csvReader.readAsText(file);
  }
  async function uploadFile() {
    const file = document.getElementById("getFile").files[0];
    const csvReader = new FileReader();
    csvReader.onload = async function () {
      try {
        const tempPresignedURL = process.env.APIGATEWAY_URL_CSVPRESIGNEDURL;
        const requestOptions = {
          method: "GET",
          headers: {
            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
            defaultrole: props.TenantInfo.UserGroup,
            groupmenuname: "UserManagement",
            menuid: "200306",
          },
        };
        try {
          await fetch(tempPresignedURL + `?csvfile=${document.getElementById("getFile").files[0].name}&tenantid=${router.query["TenantID"]}&path=USERGROUP&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}`, requestOptions)
            .then((response) => response.text())
            .then(async (presignedUrl) => {
              await fetch(presignedUrl, {
                method: "PUT",
                body: file,
              });
              setValue("file", "True", { shouldValidate: true });
            })
            .catch((error) => alert("Error Occured. \n Error Details: " + error));
        } catch (err) {
          setValue("file", "Empty", { shouldValidate: true });
          alert(err);
        }
      } catch (error) {
        setValue("file", "Empty", { shouldValidate: true });
        alert("Error Occured. \n Error Details: " + error);
        resetData();
        return;
      }
    };
    csvReader.readAsText(file);
  }

  const automaticSubmiter = useCallback(() => {
    refReset.current = true;
    refMultiselect.current.resetSelectedValues();
    reset();
    setValue("AssignMethod", "Automatic", { shouldValidate: true });
    setMultiSelected([]);
    setTextName("Select File");
  }, [reset, setValue]);
  useEffect(() => {
    setValue("AssignMethod", "Automatic", { shouldValidate: true });
    setValue("submit", false);
  }, [setValue]);

  // Bread Crumbs
  const pageRoutes = useMemo(() => {
    return [
      { path: "/UserManagement/UserList", breadcrumb: "User Management" },
      { path: "", breadcrumb: "Create Group" }
    ];
  }, []);

  const handleSelectAll = useCallback(async () => {
    setValue("user", "Not Empty", { shouldValidate: true });
    let manualList = [];
    refSelectAll.current = true;
    const userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + router.query["TenantID"], SK: "#USERINFO#", IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
    if (userData.res.listXlmsUserListInfos?.items && userData.res.listXlmsUserListInfos?.items.length > 0) {
      userData.res.listXlmsUserListInfos?.items.map((getItem) => {
        if (getItem.SK != null && getItem.EmailID != null) {
          manualList.push({ value: getItem.SK, label: getItem.EmailID });
        }
      });
      setMultiSelected(manualList);
    }
  }, [props.user.signInUserSession.accessToken.jwtToken, router.query, setValue]);

  const [refersh, setRefersh] = useState(1);
  const temp = () => {
    setRefersh((data) => { return data + 1 })
  }

  const SlectedUserHandler = useCallback(() => {
    setValue("user", "Empty", { shouldValidate: true });
    refMultiselect.current.resetSelectedValues();
    refDiv.current.style.display = "block";
    setMultiSelected([]);
    refSelectAll.current = false;
  }, [setValue])

  const SlectAllUserHandler = useCallback(() => {
    refDiv.current.style.display = "none";
    handleSelectAll();
  }, [handleSelectAll])

  const GetMultisSelect = useCallback(() => {
    return (
      <>
        <div className="flex gap-3 pt-4 flex-wrap pb-3">
          <NVLRadio id="rbSelectMethod" value="UserOrGroup" type="radio" text="Select User"
            register={register} errors={errors} name="SelectMethod" defaultChecked
            onClick={() => SlectedUserHandler()} />
          <NVLRadio id="rbSelectMethod" value="AllUser" type="radio" text="All User" register={register} errors={errors} name="SelectMethod"
            onClick={() => SlectAllUserHandler()} />
        </div>

        <div ref={refDiv}>
          <NVLMultiSelect
            reference={refMultiselect}
            type={"User"}
            id="ddlAssignGroup"
            className="nvl-mandatory"
            onSelect={(event) => {
              setMultiSelected(event);
              if (event?.length == undefined || event.length == 0) {
                setValue("user", "Empty", { shouldValidate: true });
              } else {
                refError.current = "No validate";
                reset({}, { keepValues: true, keepDirty: true });
                return true;
              }
            }}
            placeholder={"Search user"}
            user={props?.user}
            TenantInfo={props?.TenantInfo}
            temp={temp}
          />
        </div>

      </>
    )
  }, [SlectAllUserHandler, SlectedUserHandler, errors, props?.TenantInfo, props?.user, register, reset, setValue])

  return (
    <>
      <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
      <Container PageRoutes={pageRoutes}>
        <form onSubmit={handleSubmit(submitHandler)} className={watch("submit") ? "pointer-events-none" : ""} >
          <div className="nvl-FormContent !overflow-y-visible	">
            <NVLTextbox labelClassName="nvl-Def-Label" title="Group name" labelText="Group Name" id="txtGroupName" placeholder={"Group Name"} className="nvl-mandatory nvl-Def-Input" register={register} errors={errors} />
            <NVLMultilineTxtbox labelClassName="nvl-Def-Label" title="Group description" labelText="Group Description" id="txtGroupDesc" placeholder="Group Description" className="nvl-non-mandatory nvl-Def-Input" register={register} errors={errors} />
            {
              <>
                <div className="text-left pt-1">
                  <NVLlabel className="nvl-Def-Label" text="Assignment Method" />
                </div>
                <div className="flex gap-3 pt-2 flex-wrap">
                  <NVLRadio id="AssignMethod" value="Automatic" type="radio" text="Automatic" register={register} errors={errors} name="AssignMethod" />
                  <NVLRadio id="AssignMethod" value="Manual" type="radio" text="Manual" register={register} errors={errors} name="AssignMethod"
                    onClick={() => {
                      setValue("rbSelectMethod", "UserOrGroup");
                      refDiv.current.style.display = "block";
                    }} />
                  <NVLRadio id="AssignMethod" value="BulkUpload" type="radio" text="BulkUpload" register={register} errors={errors} name="AssignMethod" />
                </div>
                <section id="divAutomatic" className={currentDiv != "Automatic" ? "hidden" : "pt-2"}>
                  <NVLSelectField labelText="Assign by profile" labelClassName="nvl-Def-Label" id="ddlAssignProfile" options={assignProfile} className="nvl-mandatory nvl-Def-Input" register={register} errors={errors}></NVLSelectField>
                  <NVLSelectField labelClassName="nvl-Def-Label" labelText={`Search `} id="ddlSearch" className={`nvl-mandatory nvl-Def-Input ${watch("ddlAssignProfile") == 0 ? "Disabled" : ""}`} disabled={watch("ddlAssignProfile") == 0 ? true : false} options={selectedProfileData} register={register} errors={errors} />
                </section>
                <section id="divManual" className={currentDiv != "Manual" ? "hidden" : ""}>
                  {GetMultisSelect()}
                  <div className="block {invalid-feedback} text-red-500  text-sm"> {errors.user?.message}</div>
                </section>
                <section id="divBulkUpload" className={currentDiv != "BulkUpload" ? "hidden" : ""}>
                  <div className="pt-3">
                    <NVLlabel
                      text="Upload File"
                      className="nvl-Def-Label"
                      HelpInfo={`${"Acceptable file format: .csv <br>File size should be 5MB"}`}
                      HelpInfoIcon={"fa fa-solid fa-circle-question"}
                    />
                  </div>
                  <div className="flex nvl-Def-Input mt-3">

                    <div className="flex xl:flex-wrap items-center">
                      <NVLFileUpload format=".csv" text={textName} className={"w-1/3"} onChange={() => fileValidation()} />
                      <div className="pt-3 px-6 ">
                        <NVLlabel text={"Download sample template"} className="nvl-Def-Label" />
                      </div>
                      <div className="pt-3 ">
                        <NVLButton text={"Download"}
                          type={"button"}
                          className="bg-primary nvl-button rounded-2xl text-white" onClick={() => downloadCsvFile()} />
                      </div>
                    </div>
                  </div>
                  <div className="block {invalid-feedback} text-red-500  text-sm"> {errors.file?.message}</div>
                </section>
              </>
            }
            <div className=" flex flex-row gap-1 justify-center nvl-Def-Input mt-4">
              <NVLButton id="btnSubmit"
                text={!watch("submit") ? "Submit" : ""}
                type="submit"
                disabled={watch("submit") ? true : false}
                className={"w-32 nvl-button bg-primary text-white "}>
                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
              </NVLButton>
              <NVLButton id="btnCancel" text={"Clear"} type="button" disable={watch("submit") ? true : false} className="nvl-button w-28" onClick={() => {
                automaticSubmiter()
              }}></NVLButton>
            </div>
          </div>
        </form>
      </Container>
    </>
  );
}

export default CreateGroup;