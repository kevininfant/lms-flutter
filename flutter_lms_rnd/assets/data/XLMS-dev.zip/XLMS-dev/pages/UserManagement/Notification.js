import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLMultiSelect from "@components/Controls/NVLMultiSelectDropdown";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLRichTextBox, { getContents, setContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { getXlmsDefaultNotificationFields, listXlmsCustomFields, listXlmsUserGroupInfos, listXlmsUserInfos } from "src/graphql/queries";
import * as Yup from "yup";

function Notification(props) {
    const router = useRouter();
    const [defaultNotifyUsers, setNotifyUsers] = useState("All User");
    const [filePathChanged, setfilePathChanged] = useState(false);
    const [message, setMessage] = useState("");
    const [multiSelected, setMultiSelected] = useState([]);
    const [fileValues, setFileValues] = useState({ TextName: "Select File", FilePath: "", });
    const [notifyData, setNotifyData] = useState();
    const refMultiselect = useRef([]);

    // Initial ModalPopup/Alter box
    const initialModalState = { ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Notification sent successfully", ModalOnClickEvent: () => { (mode != "User") ? router.push("/UserManagement/ManageGroupList") : router.push("/UserManagement/UserList"); } };
    const [modalValues, setModalValues] = useState(initialModalState);

    const mode = useMemo(() => { return router.query["Mode"]; }, [router.query]);
    const userId = useMemo(() => { return (mode == "User" ? router.query["UserID"] : ""); }, [mode, router.query]);
    const userList = useMemo(() => {
        const ltemp = [];
        if (notifyData?.UserGroup && notifyData?.UserGroup.length > 0) {
            notifyData?.UserGroup.map((getItem) => {
                if (getItem.EmailID != null) {
                    ltemp.push({ value: getItem.UserSub, label: getItem.EmailID });
                }
            });
        }
        return ltemp;
    }, [notifyData?.UserGroup]);

    const notificationFields = useMemo(() => {
        if (notifyData?.NotificationData != undefined) {
            let delimeterData = JSON.parse(notifyData.NotificationData);

            let customFieldDataList = [];
            notifyData.CustomFieldData &&
                notifyData.CustomFieldData?.map((customField) => {
                    customFieldDataList.push(customField.ProfileFieldName);
                });

            let finalCustomFieldData = [];
            customFieldDataList.map((customField) => {
                finalCustomFieldData.push({ customField: customField });
            });

            let finalDelimetersData = {
                ...delimeterData?.CompanyDetails,
                ...delimeterData?.ActivityDetails,
                ...delimeterData?.UserDetails,
                ...delimeterData?.CourseDetails,
                ...customFieldDataList,
            };

            return Object.entries(finalDelimetersData);
        }
    }, [notifyData?.CustomFieldData, notifyData?.NotificationData]);

    useEffect(() => {
        async function fetchingData() {
            let UserData, UsergroupData;
            if (mode != "User") {
                const groupId = router.query["SK"];
                const groupUserResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + props.TenantInfo.TenantID + "#GROUPID#" + groupId, SK: "#USERINFO#" }, props.user.signInUserSession.accessToken.jwtToken);
                UsergroupData = groupUserResponse?.res?.listXlmsUserGroupInfos?.items != undefined ? groupUserResponse?.res?.listXlmsUserGroupInfos?.items : [];
            } else {
                const userdata = await AppsyncDBconnection(listXlmsUserInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "#USERINFO#" }, props.user.signInUserSession.accessToken.jwtToken);
                UserData = userdata?.res?.listXlmsUserInfos?.items != undefined ? userdata?.res?.listXlmsUserInfos?.items : [];
            }
            const notificationFields = await AppsyncDBconnection(getXlmsDefaultNotificationFields, { PK: "XLMS#DELIMETERFIELDS", SK: "NOTIFICATIONFIELDS#DELIMETER" }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const customFieldData = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "CUSTOMFIELD#" }, props.user?.signInUserSession?.accessToken?.jwtToken);
            setNotifyData({
                Users: UserData, UserGroup: UsergroupData, NotificationData: notificationFields.res?.getXlmsDefaultNotificationFields?.DefaultFields,
                CustomFieldData: customFieldData.res?.listXlmsCustomFields?.items,
            });
        }
        fetchingData();
        return (() => { setNotifyData((temp) => { return { ...temp }; }); });
    }, [props.TenantInfo.TenantID, mode, props.user.signInUserSession.accessToken.jwtToken, router.query]);

    useEffect(() => {
        if (message != "") {
            message?.on("text-change", () => {
                if (getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {
                    setValue("txtDescription", "Empty", { shouldValidate: true });
                } else {
                    setValue("txtDescription", "NotEmpty", { shouldValidate: true });
                }
                setValue("txtDescription", "NotEmpty", { shouldValidate: true });
            });
        }
    }, [message, setValue]);

    const resetData = useCallback(() => {
        setMultiSelected([]);
        setValue("txtSubject", "");
        setHTMLContents("", message);
        document.getElementsByClassName("ql-editor")[0].innerHTML = "";
        setFileValues({ TextName: "Select File", FilePath: "" });
        setValue("File", "", { shouldValidate: true });
    }, [message, setValue]);


    //Form validation rules
    const validationSchema = Yup.object().shape({
        rbUser: Yup.string().test("NOValid", "novalid", (e) => {
            if (e == "All User" && e != defaultNotifyUsers) {
                setNotifyUsers("All User");
                reset({}, { keepValues: true, keepDirty: true });
            } else if (e == "Custom" && e != defaultNotifyUsers) {
                setNotifyUsers("Custom");
                reset({}, { keepValues: true, keepDirty: true });
            }
            return true;
        }),
        txtSubject: Yup.string().required("Enter Subject").matches(Regex("AlphaNumWithAllowedSomeSpecialChar"), "Enter valid Subject").nullable(),
        txtDescription: Yup.string()
            .test("", " Description is required", () => {
                if (message?.editor.delta.ops[0]["insert"]?.replaceAll(/(<([^>]+)>)/gi, "re")?.trim().length == 0 || getContents(message)?.replaceAll(/(<([^>]+)>)/gi, "")?.length == 0) {
                    document.getElementById("desc_errors").classList.remove("hidden");
                    return false;
                }
                document.getElementById("desc_errors").classList.add("hidden");
                return true;

            })
            .nullable(),
        File: Yup.string().test("file_Error", "", (e, { createError }) => {
            if (e == "fileType") {
                setFileValues({ TextName: "Select File", FilePath: "" });
                return createError({ message: "Invalid file type" });
            }
            if (e == "filesize") {
                setFileValues({ TextName: "Select File", FilePath: "" });
                return createError({ message: " file size should be 2MB!" });
            }
            if (e == "Error") {
                return createError({ message: "Server Error Please Try Again" });
            }
            return true;
        }),
        ddlSelectUser: Yup.string()
            .test("MultiSlect_EmptyHandler", "", (e, { createError }) => {
                if (multiSelected?.length >= 1) return true;
                if ((e == "Empty" || e == undefined || multiSelected?.length == 0) && defaultNotifyUsers == "Custom") {
                    return createError({ message: "Please choose users from the list" });
                }
                if (e == "NoData") {
                    return createError({ message: "Please choose users from the list" });
                }
                return true;
            })
            .nullable(),
    });

    // Get functions to build form with useForm() hook
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, formState, reset } = useForm(formOptions);
    const { errors } = formState;

    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus == "Success") {
            setModalValues({ ModalInfo: "Success", ModalTopMessage: finalStatus, ModalBottomMessage: "Notification sent successfully", ModalOnClickEvent: () => { (mode != "User") ? router.push("/UserManagement/ManageGroupList") : router.push("/UserManagement/UserList"); }, });
            ModalOpen();
            return;
        }
        setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus, ModalOnClickEvent: () => { (mode != "User") ? router.push("/UserManagement/ManageGroupList") : router.push("/UserManagement/UserList"); }, });
        ModalOpen();

    }, [mode, router]);

    async function fileValidation(e) {
        if (e.target.files.length == 0) {
            return;
        }
        setValue("File", "Uploading");
        setfilePathChanged(true);
        var fileInput = document.getElementById("getFile");
        var filePath = fileInput.value;
        var allowedExtensions = /(\.csv|\.txt|\.doc|\.docx|\.pdf|\.jpg|\.jpeg|\.png|\.mp4|\.mpeg4|\.ppt|\.xlsx|\.xls|\.pptx)$/i;
        var fileSize = fileInput.files[0]?.size;
        if (fileSize > process.env.NOTIFICATION_UPLOAD_FILE_SIZE) {
            setValue("File", "filesize", { shouldValidate: true });
            fileInput.value = "";
            return false;
        }
        if (!allowedExtensions.exec(filePath) || fileInput == null) {
            fileInput.value = "";
            setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
            setValue("File", "fileType", { shouldValidate: true });
            setValue("File", "fileType", { shouldValidate: true });
            return false;
        }
        await uploadFile(e);

    }

    async function uploadFile(e) {
        const file = e.target.files[0];
        const csvReader = new FileReader();
        const name = e.target.files[0].name;
        const fileExtension = ["csv", "txt", "doc", "docx", "pdf", "ppt", "xlsx", "xls", "pptx"];
        const imageExtension = ["jpg", "jpeg", "png"];
        const videoExtension = ["mp4", "mpeg4"];
        var extension = e.target.value.substring(e.target.value.lastIndexOf(".") + 1).toLowerCase();
        const contentType = extension == "csv" ? "text/" + extension : imageExtension.indexOf(extension) >= 0 ? "image/" + extension : videoExtension.indexOf(extension) >= 0 ? "video/" + extension : fileExtension.indexOf(extension) >= 0 ? (extension == "xls" ? "application/vnd.ms-excel" : extension == "ppt" ? "application/vnd.ms-powerpoint" : extension == "pptx" ? "application/vnd.openxmlformats-officedocument.presentationml.presentation" : extension == "docx" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : extension == "doc" ? "application/msword" : extension == "xlsx" ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : extension == "txt" ? "text/html" : "application/" + extension) : "application/" + extension;
        csvReader.onload = async function (e) {
            if (e.target.result.length == 1) {
                setValue("File", "Empty", { shouldValidate: true });
                document.getElementById("getFile").value = null;
                return;
            }
            const fetchUrl = process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${file.name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&Type=UserNotification&ManagementType=UserManagement`;
            const groupMenuName = "UserManagement";
            const menuId = "200301";
            const headers = { method: "GET", headers: { authorizationtoken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, };
            const presignedHeader = {
                method: "PUT", headers: {
                    //   "x-amz-acl": "public-read", 
                    "content-type": contentType, defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId,
                }, body: file,
            };
            const finalStatus = await APIGatewayPutRequest(fetchUrl, headers, presignedHeader);
            if (finalStatus[0] != "Success") {
                setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
                setValue("File", "Error", { shouldValidate: true });
                return;
            }
            setValue("File", "exist", { shouldValidate: true });
            setFileValues({ ...fileValues, TextName: name, FilePath: finalStatus[1], });

        };
        csvReader.readAsText(file);
    }


    const submitHandler = async (data) => {
        setValue("submit", true);
        const description = getContents(message);
        if (getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {
            setValue("txtDescription", "Empty", { shouldValidate: true });
            return false;
        }
        let finalData = [];
        if (mode == "User") {
            const notifyUser = notifyData.Users.filter(({ EmailID: EmailId }) => EmailId == userId);
            notifyUser.map((getItem) => { finalData.push(getItem.UserSub); });
        }
        else {
            userList.map((user) => { finalData.push(user.value); });
        }
        if (defaultNotifyUsers == "Custom") {
            finalData = [];
            if (multiSelected && multiSelected.length > 0) {
                for (var i = 0; i < multiSelected.length; i++) {
                    for (var j = 0; j < notifyData?.UserGroup.length; j++) {
                        if (notifyData?.UserGroup[j].UserSub == multiSelected[i].value) {
                            finalData.push(notifyData?.UserGroup[j].UserSub);
                        }
                    }
                }
            }
        }
        if (defaultNotifyUsers == "Custom" && multiSelected.length == 0) {
            setValue("ddlSelectUser", "NoData", { shouldValidate: true });
            setValue("submit", false);
            return;
        }
        const fetchUrlToSave = process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${fileValues.TextName}&Type=UserNotification&TenantID=${props.TenantInfo.TenantID}&RootFolder=${props.TenantInfo.RootFolder}&BucketName=${props.TenantInfo.BucketName}&ManagementType=UserManagement`;
        const groupMenuName = "UserManagement";
        const menuId = "200301";
        const headersToSave = { method: "GET", headers: { authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, };
        const finalResult = filePathChanged && (await APIGatewayGetRequest(fetchUrlToSave, headersToSave));
        const attachFilePath = await finalResult?.res?.text();
        if (filePathChanged && attachFilePath == undefined) {
            finalResponse("Some error occured while upload");
        }
        var fetchUrlToSend = process.env.USER_SENDNOTIFICATION_EVENT_BRIDGE;
        var jsonSaveData = { TenantID: props.TenantInfo.TenantID, TargetPlatForms: "EMAIL", BucketName: props.TenantInfo.BucketName, UserDetails: finalData, NotificationAttachment: attachFilePath, Subject: data.txtSubject, Message: description, IsUser: true };
        const headersToSend = { method: "POST", headers: { "Content-Type": "application/json", authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()), defaultrole: props.TenantInfo.UserGroup, groupmenuname: groupMenuName, menuid: menuId, }, body: JSON.stringify(jsonSaveData), };
        const finalStatus = await APIGatewayPostRequest(fetchUrlToSend, headersToSend);
        finalResponse(finalStatus.Status);
        setValue("submit", false);
    };

    useEffect(() => {
        setValue("rbUser", "All User");
    }, [setValue]);

    useEffect(() => {
        setValue("txtSubject", "");
        if (defaultNotifyUsers == "AllUser") setValue("ddlSelectUser", []);
    }, [setValue, message, defaultNotifyUsers]);


    // Bread Crumbs


    let pageRoutes;
    if (mode == "User") {
        pageRoutes = [
            { path: "/UserManagement/UserList", breadcrumb: "User Management" },
            { path: "", breadcrumb: "User Notification" }
        ];
    } else {
        pageRoutes = [
            { path: "/UserManagement/UserList", breadcrumb: "User Management" },
            { path: "/UserManagement/ManageGroupList", breadcrumb: "Manage Group" },
            { path: "", breadcrumb: "Send Notification" }
        ]
    }

    const [refersh, setRefersh] = useState(1);
    const temp = () => {
        setRefersh((data) => { return data + 1 })
    }

    const GetMultisSelect = useCallback(() => {
        return (
            <>
                <NVLMultiSelect
                    reference={refMultiselect}
                    type={"User"}
                    id="ddlUser"
                    ScreenName="AssignCourse"
                    className="!w-96 nvl-mandatory"
                    onSelect={(event) => {
                        setMultiSelected(event);
                        if (event?.length == undefined || event.length == 0) {
                            setValue("ddlSelectUser", "Empty", {
                                shouldValidate: true,
                            });
                        } else {
                            reset({}, { keepValues: true, keepDirty: true });
                            return true;
                        }
                    }}
                    placeholder={"Search user"}
                    user={props?.user}
                    TenantInfo={props?.TenantInfo}
                    temp={temp}
                    GroupID={router.query["SK"]}
                    GroupUsers={true}
                />
            </>
        )
    }, [props?.TenantInfo, props?.user, reset, router.query, setValue])

    return (
        <>

            <Container title="Notification" loader={notifyData == undefined} PageRoutes={pageRoutes}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)} id="Formjs">
                    <div className=" justify-center flex gap-3 pt-5 md: px-20 py-10">
                        <div className="Center-Aligned-Items">
                            {mode != "User" && <div className="flex gap-20 text-xs font-medium">
                                <NVLRadio id="rbUser" type="radio" errors={errors} register={register} text="All User" name="rbUser" value={"All User"} onClick={() => resetData()} />
                                <NVLRadio id="rbUser" type="radio" errors={errors} register={register} text="Custom" name="rbUser" value={"Custom"} onClick={() => resetData()} />
                            </div>}
                        </div>
                    </div>
                    <div className="md: px-10">
                        <div className={watch("rbUser") == "All User" ? "hidden Disabled" : "w-96"}>
                            {GetMultisSelect()}
                            <div className="block {invalid-feedback} text-red-500  text-sm">{errors.ddlSelectUser?.message}</div>
                        </div>
                        <div>
                            <div className="pt-4 ">
                                <NVLTextbox id="txtSubject" title="Subject" errors={errors} register={register} className="w-full nvl-mandatory" />
                            </div>
                            <div className="pt-2">
                                <NVLRichTextBox id="txtDescription" className="isResizable nvl-mandatory" setState={setMessage} />
                                <div className="{invalid-feedback} text-red-500 text-sm pt-2" id="desc_errors">
                                    {errors?.txtDescription?.message}
                                </div>
                            </div>


                            <div className="pt-2 flex gap-6 font-semibold">
                                <div className="gap-4 flex flex-wrap text-2xl">
                                    {notificationFields &&
                                        Array.from(notificationFields)?.map((fieldsData) => {
                                            return (
                                                <>
                                                    <NVLlabel
                                                        id="lblUserName"
                                                        className="NotifyItems text-lg"
                                                        text={fieldsData?.[1]}
                                                        onClick={() => {
                                                            setContents(
                                                                "{" + fieldsData?.[0] > 0
                                                                    ? fieldsData?.[0]
                                                                    : "{" + fieldsData?.[1] + "}",
                                                                message
                                                            );
                                                        }}
                                                    />
                                                </>
                                            );
                                        })}
                                </div>
                            </div>

                            <div className="flex gap-2 my-auto pt-6">
                                <NVLlabel text="Attachment" className="pt-2 Def-Input-Label text-lg"></NVLlabel>
                                <NVLFileUpload id="getFile" text={fileValues.TextName == null ? "Select File" : fileValues.TextName} ButtonType="success" onChange={(e) => fileValidation(e)}></NVLFileUpload>
                                <div className="pt-3">
                                    <NVLlabel className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: .csv, .txt, .doc, .docx, .pdf, .jpg, .jpeg, .png ,.mp4,.mpeg4,.ppt,.pptx,.xls,.xlsx<br>File size should not exceed more than 2MB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                                </div>
                                <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "my-auto" : "hidden"}`} id="loader" />
                            </div>
                            <div className={"Center-Aligned-Items {invalid-feedback} text-red-500 text-sm "}>{errors?.File?.message}</div>
                        </div>
                    </div>
                    <div className=" justify-center flex gap-3 pt-7">
                        <NVLButton id="btnSend" disabled={watch("File") == "Uploading" || watch("submit") ? true : false} text={!watch("submit") ? "Send" : ""} type="submit" className={props.ButtonClassName ? props.ButtonClassName : `w-32 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`}>
                            {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"> </i>}
                        </NVLButton>
                        <NVLButton id="btnCancel" text={"Cancel"} type="reset" className="nvl-button w-28" onClick={() => mode != "User" ? (router.push("/UserManagement/ManageGroupList"), resetData()) : (router.push("/UserManagement/UserList"), resetData())} />
                    </div>
                </form>
            </Container>
        </>
    );
}

export default Notification;

