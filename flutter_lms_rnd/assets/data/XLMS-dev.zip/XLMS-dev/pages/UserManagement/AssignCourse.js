/* eslint-disable quotes */
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultiSelect from "@components/Controls/NVLMultiSelectDropdown";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsActiveCourseCategory, listXlmsActiveCourseManagementInfo, listXlmsCourseBatchInfos, listXlmsCourseManagementInfo, listXlmsUserGroupInfos, listXlmsUserInfos } from "src/graphql/queries";


import * as Yup from "yup";

function AssignCourse(props) {
    const router = useRouter();
    const routerRef = useRef();

    const [csrFetchedCourseData, setCsrFetchedCourseData] = useState([]);
    const [multiselected, setMultiSelected] = useState([]);
    const [courseListData, setCourseListData] = useState([{ value: "", text: "Select" }]);
    const [batchState, setBatchState] = useState([{ value: "", text: "Select" }]);
    const category = useRef();

    const refDiv = useRef();
    const refSelectAll = useRef();
    const refMultiselect = useRef([]);
    const refReset = useRef(false);

    //CSR-Initial data load using GraphQL 
    useEffect(() => {
        const dataSource = async () => {
            routerRef.current = { groupId: decodeURIComponent(String(router.query["GroupID"])), tenantId: props.user.attributes["custom:tenantid"] };
            const categoryData = await AppsyncDBconnection(listXlmsActiveCourseCategory, { PK: "TENANT#" + routerRef.current.tenantId, SK: "COURSECATEGORY#", IsDeleted: false, IsSuspend: false }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const courseDataList = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + routerRef.current.tenantId, SK: "COURSEINFO#", IsDeleted: false }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const userData = await AppsyncDBconnection(listXlmsUserInfos, { PK: "TENANT#" + routerRef.current.tenantId, SK: "#USERINFO#" }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const groupUserResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + routerRef.current.tenantId + "#GROUPID#" + routerRef.current.groupId, SK: "#USERINFO#" }, props.user?.signInUserSession?.accessToken?.jwtToken);

            setCsrFetchedCourseData({
                tenantId: routerRef.current.tenantId,
                CategoryData: categoryData.res?.listXlmsActiveCourseCategory?.items != undefined ? categoryData.res?.listXlmsActiveCourseCategory?.items : [],
                CourseData: courseDataList.res?.listXlmsCourseManagementInfo?.items != undefined ? courseDataList.res?.listXlmsCourseManagementInfo?.items : [],
                userData: userData.res?.listXlmsUserInfos?.items,
                groupUserData: groupUserResponse?.res?.listXlmsUserGroupInfos?.items,
            });
            category.current = ({
                CategoryData: categoryData.res?.listXlmsActiveCourseCategory?.items != undefined ? categoryData.res?.listXlmsActiveCourseCategory?.items : [],

            });
        };
        dataSource();
        setValue("rbSelectMethod", "UserOrGroup");
        return (() => { setCsrFetchedCourseData((ltemp) => { return { ...ltemp }; }); });
    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue]);


    //Initial ModalPopup/Alter box
    const initialModalState = { ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "User Enrolled Successfully.", ModalOnClickEvent: () => { router.push("/UserManagement/ManageGroupList"); }, };
    const [modalValues, setModalValues] = useState(initialModalState);

    //Binds userlist value
    const userList = useMemo(() => {
        const ltemp = [];
        if (csrFetchedCourseData?.groupUserData?.length > 0)
            csrFetchedCourseData.groupUserData?.map((getItem) => {
                ltemp.push({ value: getItem.UserSub, label: getItem.EmailID });
            });
        return ltemp;
    }, [csrFetchedCourseData.groupUserData]);


    //Form validation rules
    const validationSchema = Yup.object().shape({
        ddlCategory: Yup.string().required("Category is required").test("", "", (e) => {
            getCategoryCourseList(e);
            return true;
        }),
        ddlCourse: Yup.string().required("Course is required").nullable(),
        ddlBatch: Yup.string().required("Batch Name is required").test("", "", async () => {
            const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + watch("ddlCourse"), SK: "COURSEBATCH#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const initialBatch = [{ value: "", text: "Select" }];
            const batchFiltered = batchData?.res?.listXlmsCourseBatchInfos?.items?.filter((obj) => !initialBatch[obj.BatchID] && (initialBatch[obj.BatchID] = true));
            batchFiltered?.map((batch) => [initialBatch.push({ value: batch.BatchID, text: batch.BatchName })]);
            setBatchState(initialBatch);
            return true;
        }),
        ddlUser: Yup.string()
            .test("length", "", (e, { createError }) => {

                if (multiselected?.length >= 1) return true;
                if (refSelectAll.current) return true;
                if ((e == "Empty" || e == undefined) || multiselected?.length == 0) {
                    return createError({ message: "Please choose users from the list" });
                }
                return true;
            })
            .nullable(),
    });

    // Get functions to build form with useForm() hook
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, reset, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    //Form submit
    const submitHandler = async (data) => {
        setValue("submit", true);
        const finalData = [];
        multiselected.map((item) => {
            csrFetchedCourseData?.userData.map((user) => {

                if (item.value?.split("#")[2] == user.UserSub)
                    finalData.push({ UserSub: item.value?.split("#")[2], EmailID: item?.EmailID, UserName: item?.UserName, BatchID: data.ddlBatch, CourseID: data.ddlCourse, FirstName: user.FirstName, LastName: user.LastName, Department: (user.Department != undefined || user.Department != "") ? user.Department : "", Designation: (user.Designation != undefined || user.Designation != "") ? user.Designation : "" });
            })
        });

        const stateUrl = process.env.STEP_FUNCTION_ARN_COURSE_ENROLLUSER;
        const jsonInputData =
            '{ "Type":"User","TenantID":"' + props?.TenantInfo.TenantID + '","CourseName":"' + document.getElementById("ddlCourse").options[document.getElementById("ddlCourse").selectedIndex].text + '","UserDetails":' + JSON.stringify(finalData) + ',"CourseID":"' + data.ddlCourse + '","BatchID":"' + data.ddlBatch + '"}';
        const fetchURL = process.env.APIGATEWAY_URL_COURSE_ENROLLUSER;
        const headers = { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "CourseManagement", menuid: "300201", statemachinearn: stateUrl, }, body: jsonInputData, };

        const finalStatus = await APIGatewayPostRequest(fetchURL, headers);

        if (finalStatus.Status != "Success") {
            setValue("submit", false)
        }
        finalResponse(finalStatus.Status);

    };

    // Resets the value in Alert
    function resetPopUp(mode) {
        if (mode == "Submit") return window.location.reload();
    }

    const finalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: FinalStatus, ModalOnClickEvent: () => resetPopUp("Submit") });
            ModalOpen();
            return;
        }
        setModalValues({ ModalInfo: "Success", ModalTopMessage: FinalStatus, ModalBottomMessage: "Course Assigned Sucessfully", ModalOnClickEvent: () => router.push("/UserManagement/ManageGroupList") });
        ModalOpen();

    }, [router]);

    // Fetches category list 
    const getCategoryCourseList = async (CategoryID) => {
        const response = await AppsyncDBconnection(listXlmsActiveCourseManagementInfo, {
            PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#", IsDeleted: false, IsSuspend: false,
        }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const data = response?.res?.listXlmsActiveCourseManagementInfo?.items;
        const datafilter = data?.filter((Course) => !data[Course.CategoryID]);
        const courseList = datafilter?.filter(
            (obj) => obj.CategoryID == CategoryID
        );
        const courseData = [{ value: "", text: "Select" }];
        courseList?.map((getItem) => { courseData.push({ value: getItem.CourseID, text: getItem.CourseName }); });
        setCourseListData(courseData);
    };

    const categoryState = useMemo(() => {
        const category = [{ value: "", text: "Select" }];
        if (csrFetchedCourseData.CategoryData != undefined) {
            const categoryFiltered = csrFetchedCourseData.CategoryData?.filter((obj) => !category[obj.CategoryID] && (category[obj.CategoryID] = true && obj.SubCategoryID == undefined));
            categoryFiltered?.map((categoryData) => {
                category.push({ value: categoryData.CategoryID, text: categoryData.CategoryName, });
            });
        }
        return category;
    }, [csrFetchedCourseData.CategoryData]);

    const currentCourse = [];
    const ltemp = [{ value: "", text: "Select" }];
    currentCourse.map((getItem) => { ltemp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }); });


    const automaticHandler = () => {
        refReset.current = true;
        refMultiselect.current.resetSelectedValues();
        reset();
        setValue("ddlCourseCategory", "ddlCourse", { shouldValidate: true });
        setMultiSelected([]);
    };

    const handleSelectAll = useCallback(async () => {
        setValue("ddlUser", "Not Empty", { shouldValidate: true });
        let manualList = [];
        refSelectAll.current = true;
        if (csrFetchedCourseData?.groupUserData && csrFetchedCourseData?.groupUserData?.length > 0) {
            csrFetchedCourseData?.groupUserData?.map((getItem) => {
                if (getItem.SK != null && getItem.EmailID != null) {
                    manualList.push({ value: getItem.SK, label: getItem.EmailID });
                }
            });
            setMultiSelected(manualList);
        }
    }, [csrFetchedCourseData?.groupUserData, setValue]);

    const [refersh, setRefersh] = useState(1);
    const temp = () => {
        setRefersh((data) => { return data + 1 })
    }

    const SlectedUserHandler = useCallback(() => {
        setValue("ddlUser", "Empty", { shouldValidate: true });
        refMultiselect.current.resetSelectedValues();
        refDiv.current.style.display = "block";
        setMultiSelected([]);
        refSelectAll.current = false;
    }, [setValue])

    const SlectAllUserHandler = useCallback(() => {
        refDiv.current.style.display = "none";
        handleSelectAll();
    }, [handleSelectAll])

    const GetMultiSelect = useCallback(() => {
        return (
            <>
                <div className="flex gap-3 pt-4 flex-wrap pb-3">
                    <NVLRadio id="rbSelectMethod" value="UserOrGroup" type="radio" text={`Select User`}
                        register={register} errors={errors} name="SelectMethod" defaultChecked
                        onClick={() => SlectedUserHandler()} />
                    <NVLRadio id="rbSelectMethod" value="AllUser" type="radio" text={`${"All User"}`} register={register} errors={errors} name="SelectMethod"
                        onClick={() => SlectAllUserHandler()} />
                </div>

                <div ref={refDiv}>
                    <NVLMultiSelect
                        reference={refMultiselect}
                        type={"User"}
                        id="ddlUser"
                        ScreenName="AssignCourse"
                        onSelect={(event) => {
                            setMultiSelected(event);
                            if (event?.length == undefined || event.length == 0) {
                                setValue("ddlUser", "Empty", { shouldValidate: true });
                            } else {
                                reset({}, { keepValues: true, keepDirty: true });
                                return true;
                            }
                        }}
                        placeholder={"Search user"}
                        user={props?.user}
                        TenantInfo={props?.TenantInfo}
                        temp={temp}
                        GroupID={decodeURIComponent(String(router.query["GroupID"]))}
                        GroupUsers={true}
                    />
                </div>

            </>
        )
    }, [SlectAllUserHandler, SlectedUserHandler, errors, props?.TenantInfo, props?.user, register, reset, router.query, setValue])

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/UserManagement/UserList", breadcrumb: "User Management" },
            { path: "/UserManagement/ManageGroupList", breadcrumb: "Manage Group" },
            { path: "", breadcrumb: "Assign Course" }
        ];
    }, []);
    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedCourseData.tenantId == undefined}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)} className={watch("submit") ? "pointer-events-none" : ""}>
                    <div className="nvl-FormContent">
                        <div className="pb-4" >
                            <NVLSelectField id="ddlCategory" labelText="Select Category" labelClassName="nvl-Def-Label" errors={errors} register={register} options={categoryState} className={`w-96 nvl-mandatory`} />
                        </div>
                        <div className="pb-3">
                            <NVLSelectField id="ddlCourse" labelText="Select Course" labelClassName="nvl-Def-Label" errors={errors} register={register} options={courseListData} className={`w-96 nvl-mandatory`} />
                            <div className="block {invalid-feedback} text-red-500  text-sm">  {errors.user?.message}</div>
                        </div>
                        <NVLlabel text="Select User" className="nvl-Def-Label"></NVLlabel>
                        {GetMultiSelect()}
                        <div className="block {invalid-feedback} text-red-500  text-sm"> {errors.ddlUser?.message}</div>
                        <div className="pb-1 pt-4" >
                            <NVLSelectField id="ddlBatch" labelText="Batch Name" labelClassName="nvl-Def-Label" className="nvl-mandatory nvl-Def-Input" options={batchState} errors={errors} register={register} />
                        </div>
                        <div className=" flex flex-row gap-1 justify-center nvl-Def-Input mt-1">
                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Submit" : ""} type="submit" disabled={watch("submit") ? true : false} className={"w-32 nvl-button bg-primary text-white "}>{watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
                            <NVLButton id="btnCancel" text={"Clear"} type="button" disabled={watch("submit") ? true : false} className="nvl-button w-28" onClick={() => automaticHandler()}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}
export default AssignCourse;

