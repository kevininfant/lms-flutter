/* eslint-disable no-undef */
/* eslint-enable */
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultiSelect from "@components/Controls/NVLMultiSelectDropdown";
import NVLRadio from "@components/Controls/NVLRadio";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsUserGroupInfo, updateXlmsUserGroupInfo } from "src/graphql/mutations";
import { getXlmsUserGroupInfo, listXlmsUserGroupInfos, listXlmsUserListInfos } from "src/graphql/queries";
import * as Yup from "yup";

function AddUser(props) {

  const router = useRouter();
  const routerRef = useRef();

  const [csrFetchedUserData, setCsrFetchedUserData] = useState([]);
  const [value, setValue] = useState([]);
  const [multiSelected, setMultiSelected] = useState(value?.ddlUserName);
  const refDiv = useRef();
  const refSelectAll = useRef();
  const refMultiselect = useRef([]);
  const refReset = useRef(false);

  //CSR-Initial data load using GraphQL 

  useEffect(() => {
    const dataSource = async () => {
      routerRef.current = { tenantId: decodeURIComponent(String(router.query["TenantID"])), userSub: props.user.attributes.sub, groupName: decodeURIComponent(String(router.query["GroupName"])), mode: decodeURIComponent(String(router.query["mode"])), };
      const userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + routerRef.current.tenantId, SK: "#USERINFO#", IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
      const groupResponse = await AppsyncDBconnection(getXlmsUserGroupInfo, { PK: "TENANT#" + routerRef.current.tenantId, SK: "GROUPINFO#" + routerRef.current.groupName }, props.user.signInUserSession.accessToken.jwtToken);
      const groupUserResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + routerRef.current.tenantId + "#GROUPID#" + routerRef.current.groupName, SK: "#USERINFO#" }, props.user.signInUserSession.accessToken.jwtToken);

      setCsrFetchedUserData({
        userData: userData.res.listXlmsUserListInfos?.items,
        tenantId: routerRef.current.tenantId,
        groupName: routerRef.current.groupName,
        userSub: routerRef.current.userSub,
        mode: routerRef.current.mode,
        groupData: groupResponse.res.getXlmsUserGroupInfo,
        groupUserData: groupUserResponse?.res?.listXlmsUserGroupInfos?.items != undefined ? groupUserResponse?.res?.listXlmsUserGroupInfos?.items : [],
      });
    };
    dataSource();
    setValue("rbSelectMethod", "UserOrGroup");

    return (() => { setCsrFetchedUserData((ltemp) => { return { ...ltemp }; }); });

  }, [props.user.attributes.sub, props.user.signInUserSession.accessToken.jwtToken, router.query]);



  //Initial ModalPopup/Alter box
  const initialModalState = { ModalType: csrFetchedUserData.mode === "Edit" ? "Success" : "Info", ModalTopMessage: csrFetchedUserData.mode === "Edit" ? "Success" : "In Progress", ModalBottomMessage: csrFetchedUserData.mode === "Edit" ? "Details have been saved successfully." : "Creation is in progress. Will contact you once the creation is over", ModalOnClickEvent: () => { router.push("/UserManagement/UserList"); }, };
  const [modalValues, setModalValues] = useState(initialModalState);

  //Initial fetch of user list 
  const groupUserList = useMemo(() => {
    const lgrptemp = [];
    if (csrFetchedUserData.userData != undefined) {
      const userData = csrFetchedUserData.userData.filter(({ EmailID: EmailId }) => !csrFetchedUserData.groupUserData.some(({ EmailID: EmailId1 }) => EmailId === EmailId1));
      userData.map((getItem) => { lgrptemp.push({ value: getItem.SK, label: getItem.EmailID }); });
    }
    return lgrptemp;
  }, [csrFetchedUserData.userData, csrFetchedUserData.groupUserData]);


  // Setting multiple selected userlist
  const setMulti = useCallback((event) => {
    setMultiSelected(event);
    setValue(value);
  }, [value])

  // Form validation rules
  const validationSchema = Yup.object().shape({
    multiSelect: Yup.string()
      .test("length", "", (e, { createError }) => {
        
        if(multiSelected?.length >= 1)return true;
        if (refSelectAll.current) return true;
        if ((e == "Empty" || e == undefined) || multiSelected?.length == 0) {
          return createError({ message: "Please choose users from the list" });
        }
        return true;
      })
      .nullable(),
  });

  // Get functions to build form with useForm() hook
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { handleSubmit, formState, watch, register, reset } = useForm(formOptions);
  const { errors } = formState;


  //Form submit
  const submitHandler = async () => {
    if (multiSelected?.length == 0) {
      setValue("multiSelect", "Empty", { shouldValidate: true });
      return false;
    }
    setValue("submit", true);
    let finalData = [], userSub = [];
    for (let i = 0; i < multiSelected.length; i++) {
      const userValue = csrFetchedUserData.userData.find((temp) => temp.SK == multiSelected[i].value);
      userSub = [...userSub, userValue.UserSub];
      finalData = [...finalData, { GsiPK: "#USERINFO#" + 
      userValue.UserSub, GsiSK: userValue.PK + "#GROUPID#" + csrFetchedUserData.groupName,
      PK: userValue.PK + "#GROUPID#" + csrFetchedUserData.groupName,
       SK: "#USERINFO#" + userValue.UserSub,
       EmailID: userValue.EmailID, UserID: userValue.UserName,
        GroupName: csrFetchedUserData.groupData.GroupName, UserSub: userValue.UserSub,TenantID: userValue.TenantID,
         CreatedDate: new Date(), CreatedBy: props.user.username, LastModifiedBy: props.user.username,
          LastModifiedDate: new Date() }];
    }
    const totalCount = (csrFetchedUserData.groupData.TotalCount) + multiSelected.length;
    let variables = { input: { PK: csrFetchedUserData.groupData.PK,
       SK: csrFetchedUserData.groupData.SK,
        LastModifiedDate: new Date(), LastModifiedBy: props.user.username, TotalCount: totalCount } };
    AppsyncDBconnection(updateXlmsUserGroupInfo, variables, props.user.signInUserSession.accessToken.jwtToken);
    variables = { input: [...finalData] };
    AppsyncDBconnection(createXlmsUserGroupInfo, variables, props.user.signInUserSession.accessToken.jwtToken)
      .then(() => {
        const fetchURL = process.env.APIGATEWAY_URL_USERGROUPNOTIFICATION;
        const jsonSaveData = { TenantID: routerRef.current.tenantId, GroupName: csrFetchedUserData.groupData.GroupName, CompanyName: props.TenantInfo.TenantName, UserSub: userSub };
        const headers = { method: "POST", headers: { authorizationToken: props.user.signInUserSession.accessToken.jwtToken, menuId: "200004", groupMenuName: "UserManagement", defaultRole: props.TenantInfo.UserGroup, }, body: JSON.stringify(jsonSaveData) };
        APIGatewayPostRequest(fetchURL, headers);
        setModalValues({ ModalInfo: "Success", ModalOnClickEvent: () => { router.push(`/UserManagement/EditGroup?TenantID=${csrFetchedUserData.tenantId}&GroupID=${csrFetchedUserData.groupName}&mode=Edit`); }, });
        ModalOpen();
        setValue("submit", false);
      })
      .catch(() => {
        setModalValues({ ModalInfo: "Danger", });
        ModalOpen();
      });

    setValue("submit", false);
  };

  // Bread Crumbs
  const pageRoutes = useMemo(() => { return [{ path: "/UserManagement/UserList", breadcrumb: "User Management" }, { path: "/UserManagement/ManageGroupList", breadcrumb: "Manage Group" }, { path: `/UserManagement/EditGroup?TenantID=${csrFetchedUserData.tenantId}&GroupID=${csrFetchedUserData.groupName}&mode=Edit`, breadcrumb: "Edit Group" }, { path: "", breadcrumb: "Add User" }]; }, [csrFetchedUserData.groupName, csrFetchedUserData.tenantId]);

  const handleSelectAll = useCallback(async () => {
    setValue("multiSelect", "Not Empty", { shouldValidate: true });
    refSelectAll.current = true;
    const lgrptemp = [];
    if (csrFetchedUserData.userData != undefined) {
      const userData = csrFetchedUserData.userData.filter(({ EmailID: EmailId }) => !csrFetchedUserData.groupUserData.some(({ EmailID: EmailId1 }) => EmailId === EmailId1));
      userData.map((getItem) => { lgrptemp.push({ value: getItem.SK, label: getItem.EmailID }); });
    }
    setMultiSelected(lgrptemp);

  }, [csrFetchedUserData.groupUserData, csrFetchedUserData.userData]);

  const [refersh, setRefersh] = useState(1);
  const temp = () => {
    setRefersh((data) => { return data + 1 })
  }

  const SelectedUserHandler = useCallback(() => {
    setValue("multiSelect", "Empty", { shouldValidate: true });
    refDiv.current.style.display = "block";
    setMultiSelected([]);
    refSelectAll.current = false;
  }, [])

  const SlectAllUserHandler = useCallback(() => {
    reset({}, { keepValues: true, keepDirty: true });
    refMultiselect.current.resetSelectedValues();
    refDiv.current.style.display = "none";
    handleSelectAll();
  }, [handleSelectAll, reset])

  const GetMultiSelect = useCallback(() => {
    return (
      <>
        <div className="flex gap-3 pt-4 flex-wrap pb-3">
          <NVLRadio id="rbSelectMethod" value="UserOrGroup" type="radio" text={`Select User`}
            register={register} errors={errors} name="SelectMethod" defaultChecked
            onClick={() => SelectedUserHandler()} />
          <NVLRadio id="rbSelectMethod" value="AllUser" type="radio" text={`${"All User"}`} register={register} errors={errors} name="SelectMethod"
            onClick={() => SlectAllUserHandler()} />
        </div>

        <div ref={refDiv}>
          <NVLMultiSelect
            reference={refMultiselect}
            type={"User"}
            id="multiSelect"
            onSelect={(event) => {
              setMulti(event);
              if (event?.length == undefined || event.length == 0) {
                setValue("multiSelect", "Empty", { shouldValidate: true });
              } else {
                reset({}, { keepValues: true, keepDirty: true });
                return true;
              }
            }}
            placeholder={"Search user"}
            user={props?.user}
            TenantInfo={props?.TenantInfo}
            temp={temp}
            ScreenName={"AddUser"}
            
            GroupID={decodeURIComponent(String(router.query["GroupName"]))}
          />
        </div>

      </>
    )
  }, [SlectAllUserHandler, SelectedUserHandler, errors, props?.TenantInfo, props?.user, register, reset, router.query, setMulti])

  return (
    <>
      <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
      <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
      <form className={watch("submit")?"pointer-event-none":""}>
      <div className="nvl-FormContent" >
        <NVLlabel id="lblgroup" text={`Group: ${csrFetchedUserData?.groupData?.GroupName ?? ""}`} onChange={(event) => HandleChange("lblgroup", event.target.value)} />

        {GetMultiSelect()}

        <div className={"{invalid-feedback} text-red-500 text-sm"}>{errors?.multiSelect?.message}</div>
        <div className="gap-x-4 flex justify-center nvl-Def-Input pt-3">
          <NVLButton type={"submit"} text={!watch("submit") ? "Submit" : ""} onClick={handleSubmit(submitHandler)} disabled={watch("submit") ? true : false} className={!watch("submit") ? "nvl-button bg-green-500 text-white w-60 h-10" : "nvl-button bg-green-500 text-white w-60 h-10"}>
            {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}{" "}
          </NVLButton>
          <NVLButton text={"Cancel"} type="button" className="nvl-button w-60 h-10" onClick={() => history.back()} />
        </div>
      </div>
      </form>
    </>
  );
}

export default AddUser;

