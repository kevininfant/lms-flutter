import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLToolTip from "@components/Controls/NVLToolTip";
import NVLLoader from "@Controls/NVLLoader";
import { createXlmsUserBulkUpload } from "@graphql/graphql/mutations";
import { onUpdateXlmsUserBulkUploadInfo } from "@graphql/graphql/subscriptions";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCustomFields, listXlmsUserBulkUploadListInfos } from "src/graphql/queries";
import * as Yup from "yup";

export default function UploadUser(props) {
    const router = useRouter();
    const [csrFetchedCustomFields, setCsrFetchedCustomFields] = useState({});
    const [textName, setTextName] = useState("Select File");
    const [isRefreshing, setIsRefreshing] = useState(0);
    const [search, setSearch] = useState("");
    const refFilterControl = useRef();
    const refFilename = useRef();
    const [uploadExcelType, setuploadExcelType] = useState();

    //Search box
    const searchBoxVal = (e) => {
        setSearch(e);
    };

    //Grid data refresh
    const refreshData = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    // Initial ModalPopup/Alter box
    const initialModalState = { ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "User Upload is Under Process!..", ModalOnClickEvent: () => { router.push("/UserManagement/ManageGroupList"); }, };
    const [modalValues, setModalValues] = useState(initialModalState);


    // CSR-Initial data load using GraphQL 
    useEffect(() => {
        const fetchData = async () => {
            const tenantId = props?.user?.attributes["custom:tenantid"];
            const userSub = props?.user?.attributes["sub"];
            const customFieldsData = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#", }, props?.user?.signInUserSession.accessToken.jwtToken);
            const ltemp = { TenantId: tenantId, CustomFieldsData: customFieldsData, UserSub: userSub, };
            setCsrFetchedCustomFields(ltemp);
        };
        fetchData();
        return (() => {
            setCsrFetchedCustomFields((ltemp) => { return { ...ltemp }; });
        });
    }, [props?.user?.attributes, props?.user?.signInUserSession.accessToken.jwtToken]);

    // Form validation rules
    const validationSchema = Yup.object().shape({
        drpSelectType: Yup.string().required("Select Type is required").test("", "", (e) => {
            if (e != refFilterControl.current && ((e != "") || (e == "" && refFilterControl.current != undefined))) {
                refFilterControl.current = e;
                setuploadExcelType(e)
                resetData();
                return true;
            }
            return true;
        }),
        file: Yup.string().test("Novalid", "", (e, { createError }) => {
            if (e == "") {
                return createError({ message: "Select Type is required" });
            }
            if (e == "Empty" || e == undefined) {
                resetData();
                return createError({ message: e == undefined ? "Please upload file" : "Data not match the upload type" });
            }
            else if (e == "Header") {
                resetData();
                return createError({ message: "Please Check the Template for header values", });
            }
            else if (e == "Error") {
                resetData();
                return createError({ message: "Please Check the Email And Username", });
            }
            return true;
        }),
    });

    const uploadTye = useMemo(() => {
        return [{ value: "", text: "Select" }, { value: "ADD", text: "Add New User" }, { value: "UPDATE", text: "Update Existing User" },]
    }, []);

    const headerColumn = useCallback(() => {
        const headerData = [
            { HeaderName: "UserName", Action: "true", Mandatory: "True" },
            { HeaderName: "FirstName", Action: "true", Mandatory: "True" },
            { HeaderName: "LastName", Action: "true", Mandatory: "True" },
            { HeaderName: "Password", Action: "true", Mandatory: "True" },
            { HeaderName: "MobileNo", Action: "true", Mandatory: "True" },
            { HeaderName: "EmailID", Action: "true", Mandatory: "True" },
            { HeaderName: "RoleName", Action: "true", Mandatory: "True" },
            { HeaderName: "ReportManagerEmail", Action: "true", Mandatory: "True" },
        ];

        if (csrFetchedCustomFields?.CustomFieldsData?.res?.listXlmsCustomFields != null || csrFetchedCustomFields?.CustomFieldsData?.res?.listXlmsCustomFields?.items != 0) {
            csrFetchedCustomFields?.CustomFieldsData?.res.listXlmsCustomFields?.items.map((data) => {
                headerData.push({ HeaderName: data.ProfileFieldName, Action: "true", Mandatory: data.IsFieldRequired, });
            });
        }
        return headerData;
    }, [csrFetchedCustomFields?.CustomFieldsData]);

    const userTemplate = useMemo(() => {
        const HeaderData = headerColumn();
        const ExistTypeHeader = HeaderData.filter(item => item.HeaderName != "Password")
        return uploadExcelType == "ADD" ? headerColumn() : ExistTypeHeader;
    }, [headerColumn, uploadExcelType]);

    const gridHeaderColumn = useMemo(() => {
        return [
            { HeaderName: "Template Name", Columnvalue: "TemplateName", HeaderCss: "!w-3/12", },
            { HeaderName: "Uploaded Date ", Columnvalue: "UploadDate", HeaderCss: "!w-2/12" },
            { HeaderName: "Uploaded By", Columnvalue: "UploadedBy", HeaderCss: "!w-2/12", },
            { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "!w-2/12", },
            { HeaderName: "Download", Columnvalue: "Download", HeaderCss: "!w-1/12", },
        ];
    }, []);

    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        const viewDataTemp = viewData;
        viewDataTemp && viewDataTemp?.map((getItem, index) => {
            rowGrid.push({
                PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
                SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="PK" text={getItem.SK} />),
                SNo: (<NVLlabel id={"lblSNo" + (index + 1)} name="SNo" text={index + 1}></NVLlabel>),
                TemplateName: (<NVLlabel id={"txtTemplateName" + (index + 1)} text={getItem.TemplateName}></NVLlabel>),
                UploadDate: (<NVLlabel id={"txtModifiedDate" + (index + 1)} text={getDateFormat(getItem.LastModifiedDate)}></NVLlabel>),
                UploadedBy: (<NVLlabel id={"txtUploadedby" + (index + 1)} text={getItem.UploadedBy}></NVLlabel>),
                Status: (<NVLlabel id={"txtStatus" + (index + 1)} text={getItem.Status}></NVLlabel>),
                Download: (<NVLButton type={"button"} className="inline-flex justify-center  text-sm font-medium text-white shadow-sm hover:bg-slate-200 focus:outline-none focus:ring-2 focus:ring-slate-50 focus:ring-offset-2" onClick={(getItem.Status != "Inprogress") ? () => { DownloadFiles(getItem.DownloadFileUrl) } : () => { return [] }} >
                    <i className={(getItem.Status != "Inprogress") ? "fa-solid fa-download text-black fa-lg" : "fa-solid fa-download  fa-lg fa-fade text-slate-600"}  ></i></NVLButton>)
            })
        })
        return rowGrid;
    }, [DownloadFiles])


    const mandatoryFields = useMemo(() => {
        let mandatoryTemp = "Mandatory Fields: ";
        userTemplate.map((data) => {
            if (data.Mandatory == "True")
                mandatoryTemp = mandatoryTemp + data.HeaderName.replace(/([a-z])([A-Z])/g, '$1 $2').replace(/([A-Z])([a-z])/g, ' $1$2').replace(/\ +/g, ' ') + ", "
        });
        mandatoryTemp = mandatoryTemp.substring(0, mandatoryTemp.length - 2);
        mandatoryTemp = mandatoryTemp + ".";
        return mandatoryTemp;
    }, [userTemplate]);

    const resetData = useCallback(() => {
        setTextName("Select File");
        document.getElementById("getFile").value = null;
    }, []);

    function downloadCsvFile() {
        if (watch("drpSelectType") == "") {

            return setValue("drpSelectType", "", { shouldValidate: true });
        }
        const rows = [];
        userTemplate.forEach((element) => {
            element.Action === "true" ? rows.push(element.HeaderName) : "";
        });
        const filteredData = rows.filter(item => item != "Password")
        let csvContent = "data:text/csv;charset=utf-8,";
        csvContent += watch("drpSelectType") == "UPDATE" ? filteredData : rows + "\r\n";
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "UserDetails.csv");
        link.click();
        link.remove();
    }

    const DownloadFiles = useCallback(async (url) => {
        let fetchURL = process.env.APIGATEWAY_INVOKEURL;
        let headers = {
            method: "POST",
            headers: {
                "Content-Type": "text/csv",
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                bucketname: props.TenantInfo.BucketName,
            },
            body: url,
        };
        let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
        var win = window.open(await FinalStatus.res.text(), '_blank');
    }, [props.TenantInfo.BucketName, props.user.signInUserSession.accessToken.jwtToken])

    const setUploadURL = process.env.APIGATEWAY_URL_BULKUPLOADUSER;
    const statemachinearn = process.env.STEP_FUNCTION_ARN_UPLOADUSER;

    async function Upload(data) {
        if (document.getElementById("getFile").value == "") {
            return setValue("file", undefined, { shouldValidate: true });
        }
        setValue("submit", true);
        const RandomID = crypto.randomUUID();

        const jsonSaveData = '{' + '"TenantId": "' + csrFetchedCustomFields.TenantId + '","FileName":"' + refFilename.current + '", "UploadType":"' + (data.drpSelectType != "ADD" ? "Edit" : data.drpSelectType) + '", "CreatedDate": "' + new Date() + '", "CreatedBy": "' + props.user.username + '", "BucketName": "' + props.TenantInfo.BucketName + '", "RootFolder": "' + props.TenantInfo.RootFolder + '", "Sub": "' + csrFetchedCustomFields.UserSub + '", "Key": "' + props.TenantInfo.RootFolder + "/" + csrFetchedCustomFields.TenantId + "/" + "CSVBulkUser/Input/" + textName + '", "RandomID": "' + RandomID + '" }';
        let uploadData = (setUploadURL + `?S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}`);
        let headerData = {
            method: "POST",
            headers: { "Content-Type": "application/json", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "UserManagement", menuid: "200304", statemachinearn: statemachinearn }
            , body: jsonSaveData
        }

        const finalStatus = await APIGatewayPostRequest(uploadData, headerData);
        if (finalStatus.Status == "Success") {
            let inputdata = {
                input: {
                    PK: "TENANT#" + csrFetchedCustomFields.TenantId + "#BULKUPLOADTEMPLATE",
                    SK: "BULKUPLOADTEMPLATE#" + RandomID,
                    TemplateName: textName,
                    CreatedDate: new Date(),
                    LastModifiedDate: new Date(),
                    Status: "Inprogress",
                    UploadedBy: props.TenantInfo.UserGroup
                }
            }
            let userbulkupload = await AppsyncDBconnection(createXlmsUserBulkUpload, inputdata, props.user.signInUserSession.accessToken.jwtToken);
        }
        finalResponse(finalStatus.Status);
        refreshData();
        setValue("drpSelectType", "")
        resetData();
        reset();
        setValue("submit", false);

    }

    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus, });
            ModalOpen();
            return;
        }
        setModalValues({ ModalInfo: "Success", ModalTopMessage: finalStatus, ModalBottomMessage: "User Upload is Under Process!..", });
        ModalOpen();
    }, []);

    function getDateFormat(CreatedDt) {
        return (new Date(CreatedDt).toDateString().substring(4));
    }
    // Get functions to build form with useForm() hook
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    async function UploadFile() {
        if (watch("drpSelectType") == "") {
            setValue("drpSelectType", "", { shouldValidate: true });
            return;
        }
        const file = document.getElementById("getFile").files[0];
       
        refFilename.current = file.name;
        if (file == undefined) {
            return;
        }
        setValue("file", "Upload", { shouldValidate: true });
        const csvReader = new FileReader();
        csvReader.onload = async function (e) {
            try {
                const text = e.target.result;
                const lines = text.split("\n");
                const header = lines[0].split(",");
                for (let i = 0; i < userTemplate.length - 1; i++) {
                    if (watch("drpSelectType") == "UPDATE" && userTemplate[i].HeaderName == "Password") {
                        setValue("file", "Header", { shouldValidate: true });
                        return;
                    }
                    if (header[i] != userTemplate[i].HeaderName || header.length != userTemplate.length) {
                        setValue("file", "Header", { shouldValidate: true });
                        return;
                    }
                }
                let tempUser = {}, tempEmail = {};
                for (var i = 1; i < lines.length; i++) {
                    const values = lines[i].split(",");
                    if (lines.length <= 2 && values.length <= 1) {
                        setValue("file", "Empty", { shouldValidate: true });
                        return;
                    }
                    if (values[i] == "" && userTemplate[i].Mandatory == "True") {
                        setValue("file", "Empty", { shouldValidate: true });
                        return;
                    }
                    if (tempUser?.[values[0]] != undefined && values[0] != "") {
                        setValue("file", "Error", { shouldValidate: true });
                        return;
                    }
                    else if (values[0] != "") {
                        const userName = values[0];
                        tempUser = { ...tempUser, [userName]: "" };

                    }
                    if (tempEmail?.[values[5]] != undefined && values[5] != "") {
                        setValue("file", "Error", { shouldValidate: true });
                        return;
                    }
                    else if (values[5] != "") {
                        const userName = values[5];
                        tempEmail = { ...tempEmail, [userName]: "" };

                    }
                }
                const tempPresignedURL = process.env.APIGATEWAY_URL_CSVPRESIGNEDURL;
                const requestOptions = { method: "GET", headers: { "Content-Type": "application/json", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "UserManagement", menuid: "200306" }, };

                try {
                    await fetch(tempPresignedURL + `?csvfile=${refFilename.current}&tenantid=${csrFetchedCustomFields.TenantId}&path=USER&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&S3BucketName=${props.TenantInfo.BucketName}&S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}`, requestOptions)
                        .then((response) => response.text())
                        .then(async (presignedUrl) => {
                            await fetch(presignedUrl, { method: "PUT", body: file });
                            setTextName(document.getElementById("getFile").files[0].name);
                            setValue("file", "True", { shouldValidate: true });
                        })
                        .catch((error) => {
                            return error;
                        });
                } catch (err) {
                    return err;
                }
            } catch (error) {
                resetData();
                return;
            }
        };
        csvReader.readAsText(file);
    }

    const variable = useMemo(() => { return { PK: "TENANT#" + csrFetchedCustomFields.TenantId + "#BULKUPLOADTEMPLATE", SK: "" }; }, [csrFetchedCustomFields.TenantId]);
    // Bread Crumbs
    const pageRoutes = useMemo(() => { return [{ path: "/UserManagement/UserList", breadcrumb: "User Management" }, { path: "", breadcrumb: "Upload User" }]; }, []);

    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedCustomFields?.TenantId == undefined} title="Upload User">
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <div className={`${watch("submit") || watch("file") == "Upload" ? "!pointer-events-none" : ""}`}>
                    <form onSubmit={handleSubmit(Upload)}>
                        <div className="nvl-FormContent">
                            <NVLSelectField labelClassName="nvl-Def-Label" labelText="Select Type" className="nvl-Def-Input nvl-mandatory" id="drpSelectType" options={uploadTye} register={register} errors={errors} />
                            <div className="flex pb-2">
                                <NVLlabel className="nvl-Def-Label" text="File Upload"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            </div>
                            <div className="flex xl:flex-wrap items-center gap-1">
                                <div className="flex">
                                    <NVLFileUpload format=".csv" text={textName} className={"w-1/3 nvl-mandatory"} onChange={() => UploadFile()} />
                                    <div className="pt-2 pl-1">
                                        <NVLLoader className={`text-sm ${watch("file") == "Upload" ? "" : "hidden"}`} id="loader" />
                                    </div>
                                    <NVLToolTip top={"hide"} PopDetail={"1. Role - First letter should be capital letter.<br>2.First Name and last Name should be only alphabets.<br>3.Mobile number should be 10 digits.<br>4.While updating details for the existing user, ensure you have filled the user name.<br>5." + mandatoryFields} PopIcon={"m-auto pl-3 pt-2 fa fa-solid fa-circle-question"} />
                                </div>

                                <div className="pt-3">
                                    <NVLlabel text={"Download sample template"} className="nvl-Def-Label" />
                                </div>
                                <div className="pt-3 ">
                                    <NVLButton text={"Download"} type={"button"} className="bg-primary nvl-button rounded-2xl text-white" onClick={() => downloadCsvFile()} />
                                </div>
                                <div className="block {invalid-feedback} text-red-500  text-sm">
                                    {errors.file?.message}
                                </div>

                            </div>

                            <div className="grid justify-items-center mt-10">
                                <NVLButton disabled={watch("submit") || watch("file") == "Upload" ? true : false} className={watch("submit") ? "rounded text-sm py-1 px-2 bg-th-component-button-bg-color text-th-component-button-txt-color" : "w-32 nvl-button  bg-primary text-white"} text={!watch("submit") ? "Upload User" : ""} type={"submit"} ButtonType="primary" >{watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
                            </div>
                        </div>
                    </form>
                    <div className="pt-12">
                        <NVLHeader placeholder={"Search by Templatename/Status"} IsSearch={true} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshData} IsNestedHeader></NVLHeader>
                        <NVLGridTable SubscriptionVariable={{ PK: "TENANT#" + csrFetchedCustomFields.TenantId + "#BULKUPLOADTEMPLATE" }} UpdateSubscription={onUpdateXlmsUserBulkUploadInfo} UpdateSubscriptionName={"onUpdateXlmsUserBulkUploadInfo"} user={props.user} refershPage={isRefreshing} Search={search} query={listXlmsUserBulkUploadListInfos} GridDataBind={gridDataBind} querryName={"listXlmsUserBulkUploadListInfos"} variable={variable} HeaderColumn={gridHeaderColumn}></NVLGridTable>
                    </div>
                </div>
            </Container>
        </>
    );
}