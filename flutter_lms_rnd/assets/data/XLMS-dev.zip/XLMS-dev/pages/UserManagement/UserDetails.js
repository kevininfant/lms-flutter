import Container from "@Container/Container";
import Stepper from "@Controls/NVLStepper";
import StepperControl from "@Controls/NVLStepperControl";
import { UseContextProvider } from "@Dashboard/StepperContext";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayGetRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsCheckCustomField, getXlmsCustomField, getXlmsEmailIdExistsOrNot, getXlmsLoginPolicy, getXlmsMobileNoExistsOrNot, getXlmsUserInfo, listXlmsActiveCourseCategory, listXlmsActiveCourseManagementInfo, listXlmsCourseBatchInfos, listXlmsCustomFields, listXlmsTenantRoleInfos, listXlmsUserGroupAssignTypeInfos } from "src/graphql/queries";
import * as Yup from "yup";
import CompanyInfo from "./CompanyInfo";
import CourseInfo from "./CourseInfo";
import UserInfo from "./UserInfo";

export default function UserDetails(props) {
    const previousState = useRef({});
    const router = useRouter();
    const [fetchedData, setFetchedData] = useState();
    const [batchState, setBatchState] = useState([{ value: "", text: "Select" }]);
    const [prefix, setPrefix] = useState("Prefix");
    const [currentStep, setCurrentStep] = useState(1);
    const [courseListData, setCourseListData] = useState([{ value: "", text: "Select" }]);
    const [multiselected, setMultiselected] = useState([]);

    // Fetch mode of the page 
    const mode = useMemo(() => { return router.query["Mode"]; }, [router.query]);

    // Initial ModalPopup/Alert box
    const initialModalState = { ModalType: mode === "Edit" ? "Success" : "Info", ModalTopMessage: mode === "Edit" ? "Success" : "In Progress", ModalBottomMessage: mode === "Edit" ? "Details have been saved successfully." : "Creation is in progress. Will contact you once the creation is over", ModalOnClickEvent: () => { router.push("/UserManagement/UserList"); }, Content: "" };
    const [modalValues, setModalValues] = useState(initialModalState);

    // CSR-Initial data load using GraphQL 
    useEffect(() => {
        async function fetchData() {
            const tenantId = props.TenantInfo.TenantID;
            let UserList, roles, tempDesignation = [], tempDepartment = [];
            const existingData = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#" }, props.user.signInUserSession.accessToken.jwtToken);
            const roleConfig = await AppsyncDBconnection(listXlmsTenantRoleInfos, { PK: "TENANT#" + tenantId, SK: "ROLEINFO#" }, props.user.signInUserSession.accessToken.jwtToken);
            const department = await AppsyncDBconnection(getXlmsCustomField, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#DropdownMenu#FIELDID#DDLDepartment001", }, props.user.signInUserSession.accessToken.jwtToken);
            const designation = await AppsyncDBconnection(getXlmsCustomField, { PK: "TENANT#" + tenantId, SK: "CUSTOMFIELD#DropdownMenu#FIELDID#DDLDesignation001", }, props.user.signInUserSession.accessToken.jwtToken);
            const loginPolicy = await AppsyncDBconnection(getXlmsLoginPolicy, { PK: "TENANT#" + tenantId, SK: "POLICY#LOGINPOLICY" }, props.user.signInUserSession.accessToken.jwtToken);
            const categoryData = await AppsyncDBconnection(listXlmsActiveCourseCategory, { PK: "TENANT#" + tenantId, SK: "COURSECATEGORY#", IsDeleted: false, IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
            const groupData = await AppsyncDBconnection(listXlmsUserGroupAssignTypeInfos, { PK: "TENANT#" + tenantId, SK: "GROUPINFO#", IsSuspend: false, AssignmentMethod: "Automatic" }, props.user.signInUserSession.accessToken.jwtToken);
            const userDataResponse = await AppsyncDBconnection(getXlmsUserInfo, { PK: "TENANT#" + tenantId, SK: "#USERINFO#" + router.query["UserSub"] }, props.user.signInUserSession.accessToken.jwtToken);
            if (mode != "Create") {
                const userSub = router.query["UserSub"];
                const urlPk = "TENANT#" + tenantId;
                const urlSk = "#USERINFO#" + userSub;
                const contents_Promise = await fetch(process.env.GET_BATCH_ITEM + `?PK=${encodeURIComponent(urlPk)}&SK=${encodeURIComponent(urlSk)}`, { method: "GET", headers: { "Content-Type": "application/text", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.user.signInUserSession?.accessToken?.payload["cognito:groups"][0], groupmenuname: "UserManagement", menuid: "200002" }, });
                const contents = await contents_Promise.text();
                UserList = JSON?.parse(contents);
            } else {
                UserList = {};
            }


            // Binds default role and custom role
            if (roleConfig.res.listXlmsTenantRoleInfos?.items != null && roleConfig.res.listXlmsTenantRoleInfos?.items.length != 0) {
                roles = [{ value: "", text: "Select Role" }];
                roleConfig.res.listXlmsTenantRoleInfos?.items.map((element) => {
                    roles = [...roles, { value: element.RoleName, text: element.RoleName }];
                });
            }

            // Binds designation from custom field data
            if (designation.res.getXlmsCustomField != null) {
                tempDepartment = JSON.parse(designation.res.getXlmsCustomField.FieldOptions);
            }

            // Binds department from custom field data
            if (department.res.getXlmsCustomField != null) {
                tempDesignation = JSON.parse(department.res.getXlmsCustomField.FieldOptions);
            }

            setFetchedData({
                ExistingData: existingData.res?.listXlmsCustomFields?.items,
                RoleData: roles,
                DeptData: tempDepartment,
                DesgnData: tempDesignation,
                LoginPolicy: loginPolicy.res?.getXlmsLoginPolicy,
                CategoryData: categoryData.res?.listXlmsActiveCourseCategory?.items,
                GroupData: groupData.res?.listXlmsUserGroupAssignTypeInfos?.items,
                UserList: UserList,
                UserData: userDataResponse?.res?.getXlmsUserInfo
            });
        }
        fetchData();
        return (() => { setFetchedData((temp) => { return { ...temp }; }); });
    }, [mode, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken?.payload, router.query]);

    // Fetches category list 
    const categoryState = useMemo(() => {
        const category = [{ value: "", text: "Select" }];
        const categoryFiltered = fetchedData?.CategoryData?.filter((obj) => !category[obj.CategoryID] && (category[obj.CategoryID] = true && obj.SubCategoryID == undefined));
        categoryFiltered?.map((categoryData) => [category.push({ value: categoryData.CategoryID, text: categoryData.CategoryName, }),]);
        return category;
    }, [fetchedData?.CategoryData]);

    // Fetches Group list
    const group = useMemo(() => {
        const groupData = [{ value: "", text: "Select" }];
        fetchedData?.GroupData?.map((getItem) => { groupData.push({ value: getItem.GroupID, text: getItem.GroupName }); });
        return groupData;
    }, [fetchedData?.GroupData]);

    // Binds Course list
    const assignCourseList = useMemo(() => {
        return ([{ value: "1", label: "Course 1" }, { value: "2", label: "Course 2" }, { value: "3", label: "Course 3" }, { value: "4", label: "Course 4" }, { value: "5", label: "Course 5" }, { value: "6", label: "Course 6" }, { value: "7", label: "Course 7" }, { value: "8", label: "Course 8" }, { value: "9", label: "Course 9" }, { value: "10", label: "Course 10" },]);
    }, []);

    //Binds learning plan details
    const learningPlan = useMemo(() => {
        return ([{ value: "", text: "Assign Plan" }, { value: "1", text: "Learning Plan1" }, { value: "2", text: "Learning Plan2" }, { value: "3", text: "Learning Plan3" },]);
    }, []);

    //Binds custom fields options
    const customOption = useMemo(() => {
        let temp = { UserInfo: [], CompanyInfo: [], CourseInfo: [] };
        fetchedData?.ExistingData?.map((getItem) => {
            if (getItem.DisplayPage == "UserInfo") {
                temp = { ...temp, UserInfo: [...temp?.UserInfo, getItem] };
            }
            else if (getItem.DisplayPage == "CompanyInfo") {
                temp = { ...temp, CompanyInfo: [...temp?.CompanyInfo, getItem] };
            }
            else {
                temp = { ...temp, CourseInfo: [...temp?.CourseInfo, getItem] };
            }
        });

        return temp;
    }, [fetchedData?.ExistingData]);



    function createYupSchema(schema, config) {
        const { id, validationType, validations = [] } = config;
        if (!Yup[validationType]) {
            return schema;
        }
        let validator = Yup[validationType]();
        validations.forEach((validation) => {
            const { params, type } = validation;
            if (!validator[type]) {
                return;
            }
            validator = validator[type](...params);
        });
        schema[id] = validator;
        return schema;
    }

    const steps = useMemo(() => {
        return (["User Info", "Company Information", "Course Information"]);
    }, []);


    //Form validation rules
    const validationSchema = Yup.object().shape({
        ddlUserRole:
            currentStep == 1 && mode != "Edit"
                ? Yup.string()
                    .required().when("chkSetMail", {
                        is: false,
                        then: Yup.string().required("Role is required").test("NoValid", "NO Valid", async () => {
                            if (prefix == "Prefix" && fetchedData?.LoginPolicy?.UserIdRuleType != "EmpCode") {
                                const tenantId = props.TenantInfo.TenantID;
                                const pk = "TENANT#" + tenantId;
                                const code = await AppsyncDBconnection(getXlmsLoginPolicy, { PK: pk, SK: "POLICY#LOGINPOLICY" }, props.user.signInUserSession.accessToken.jwtToken);
                                const txtpr = code.res.getXlmsLoginPolicy?.PolicyPrefixCode == undefined ? "" : code.res.getXlmsLoginPolicy?.PolicyPrefixCode;
                                setPrefix(txtpr);
                            }
                            return true;
                        }),
                        otherwise: Yup.string().required("Role is required").test("NoValid", "NoValid", () => {
                            if (prefix != "Prefix") {
                                setValue("txtUserName", "");
                                setPrefix("Prefix");
                            }
                            return true;
                        }),
                    })
                : Yup.string(),
        txtUserName:
            currentStep == 1 && mode != "Edit" ? Yup.string().when("chkSetMail", {
                is: false,
                then: Yup.string().required((fetchedData?.LoginPolicy?.UserIdRuleType == "EmpCode" ? "Employee code is required" : "UserName is required")).matches(Regex("AllowAlphaNumeric"), (fetchedData?.LoginPolicy?.UserIdRuleType == "EmpCode" ? "Invalid Employee Code" : "Invalid username")).min(3, (fetchedData?.LoginPolicy?.UserIdRuleType == "EmpCode" ? "Employee should contain 3 characters" : "UserName should contain 3 characters")).max(20, "Maximum characters Reached").test("Novalid", (fetchedData?.LoginPolicy?.UserIdRuleType == "EmpCode" ? "Employee Already Exists" : "User Already Exists"), async (e) => {
                    if (previousState.current.UserNameValue == e) {
                        return previousState.current.UserNameState;
                    }
                    if (prefix != "Prefix") {
                        e = prefix + e;
                    }
                    if (e == "" || e == undefined) {
                        return false;
                    }
                    const isUserExists = await APIGatewayGetRequest(process.env.APIGATEWAY_URL_USEREXISTSORNOT + "?UserName=" + encodeURIComponent(e.toLowerCase()), { method: "GET", headers: { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "UserManagement", menuid: "200307" } });
                    const userName = await isUserExists?.res?.text();
                    if (userName == "User Already exist") {
                        previousState.current = { ...previousState.current, UserNameValue: e, UserNameState: false, };
                        return false;
                    }
                    previousState.current = { ...previousState.current, UserNameValue: e, UserNameState: true, };
                    return true;
                }),
            })
                : Yup.string(),
        chkSetMail: Yup.bool().test("novalid", "novalid", e => {
            if (e && watch("txtUserName") != undefined) {
                setValue("txtUserName", undefined, { shouldValidate: true });
            }
            return true;
        }),
        txtEmailID:
            currentStep == 1 && mode != "Edit" ? Yup.string().required("Email Id is required").matches(Regex("Email"), "Invalid Email").test("userValid", "Email Already Exists", async (e) => {
                if (Regex("Email").exec(e)) {
                    if (previousState.current.UserNameValue == e) {
                        return previousState.current.UserNameState;
                    }
                    const isEmailExists = await AppsyncDBconnection(getXlmsEmailIdExistsOrNot, { PK: "XLMS#EMAIL", SK: "EMAILID#" + e.toLowerCase() }, props.user.signInUserSession.accessToken.jwtToken);
                    if (isEmailExists.res.getXlmsEmailIdExistsOrNot != null) {
                        previousState.current = { ...previousState.current, UserNameValue: e, UserNameState: false, };
                        return false;
                    }
                    previousState.current = { ...previousState.current, UserNameValue: e, UserNameState: true, };
                    return true;
                }
                return false;

            })
                : Yup.string(),
        txtpassword:
            currentStep == 1 && mode == "Create" ? Yup.string().notRequired().test("validateStrength", "", (e, { createError }) => {
                if (e == "" || e == undefined)
                    return true;
                let strength = 0,
                    message = "Password Should Have ";
                if (!e.match(/\d+/g)) {
                    strength++;
                    message = message + "a number";
                }

                if (!e.match(/[A-Z]+/g)) {
                    strength++;
                    if (strength > 1) {
                        message = message + ", ";
                    }
                    message = message + "a capital letter";
                }
                if (!e.match(/[a-z]+/g)) {
                    strength++;
                    if (strength > 1) {
                        message = message + ", ";
                    }
                    message = message + "a Small Letter";
                }
                if (!e.match(/[!@#$%&*())]+/g)) {
                    strength++;
                    if (strength > 1) {
                        message = message + ", ";
                    }
                    message = message + "a special character";
                }
                if (e.length < parseInt(fetchedData?.LoginPolicy?.PasswordLength)) {
                    strength++;
                    if (strength > 1) {
                        message = message + ", ";
                    }
                    message = message + "minimum of length " + fetchedData?.LoginPolicy.PasswordLength;
                }
                if (strength > 0) {
                    return createError({ message: message });
                }
                return true;
            })
                : Yup.string(),
        chkPasswordChange: Yup.bool(),
        txtFirstName: currentStep == 1 ? Yup.string().required("First Name is required").matches(Regex("AlphabetsAndSpaceWithDot"), "Invalid First Name").max(300, "Maximum 300 characters Reached") : Yup.string(),
        txtLastName: currentStep == 1 ? Yup.string().required("Last Name is required").matches(Regex("AlphabetsAndSpaceWithDot"), "Invalid Last Name").max(300, "Maximum 300 characters Reached") : Yup.string(),
        txtPhoneNo: currentStep == 1 ? Yup.string().required("Phone Number is required").matches(Regex("PhoneNumber"), "Invalid Phone Number").test("", "Mobile Number already exists", async (e, { createError }) => {
            if (Regex("PhoneNumber").exec(e)) {
                if (fetchedData?.UserList.MobileNo == e) {
                    return true;
                }
                if (previousState.current.UserNameValue == e) {
                    return previousState.current.UserNameState;
                }

                const mobilnoexistsornot = await AppsyncDBconnection(getXlmsMobileNoExistsOrNot, { PK: "XLMS#MOBILENO", SK: "MOBILENO#" + e }, props.user.signInUserSession.accessToken.jwtToken);
                if (mobilnoexistsornot?.res?.getXlmsMobileNoExistsOrNot != null) {
                    previousState.current = { ...previousState.current, UserNameValue: e, UserNameState: false, };
                    return false;
                }
                previousState.current = { ...previousState.current, UserNameValue: e, UserNameState: true, };
                return true;

            }
            return createError({ message: "Mobile Number is invalid" })

        }) : Yup.string(),
        txtReportManagerEmail: currentStep == 2 ? Yup.string().required("Reporting Manager Email is required").matches(Regex("Email"), "Invalid Email") : Yup.string(),
        ddlGroupList: Yup.string().nullable(),
        ddlAssignPlan: Yup.string().nullable(),
        txtRole: Yup.string(),
        imageControl: Yup.string(),
        ddlCategory: currentStep == 3 ? Yup.string().test("", "", (e) => { getCategoryCourseList(e); return true; }) : Yup.string(),
        ddlBatch: currentStep == 3 ? Yup.string().test("", "", async () => {
            const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + watch("ddlCourse"), SK: "COURSEBATCH#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const batch = [{ value: "", text: "Select" }];
            const batchFiltered = batchData?.res?.listXlmsCourseBatchInfos?.items?.filter((obj) => !batch[obj.BatchID] && (batch[obj.BatchID] = true));
            batchFiltered?.map((tempbatch) => {
            if ((new Date(tempbatch.EndDate) >= new Date()) || tempbatch.EndDate == '')
            [batch.push({ value: tempbatch.BatchID, text: tempbatch.BatchName })]});
            setBatchState(batch);
            return true;
    }) : Yup.string(),
    });


    //Fetches Catergory and Subcategory list
    const getCategoryCourseList = useCallback(async (CategoryID) => {
        const response = await AppsyncDBconnection(listXlmsActiveCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#", IsDeleted: false, IsSuspend: false, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const courseData = response?.res?.listXlmsActiveCourseManagementInfo?.items;
        const courseDatafilter = courseData?.filter((Course) => !courseData[Course.CategoryID]);
        const courseList = courseDatafilter?.filter((obj) => obj.CategoryID == CategoryID);
        const courseValue = [{ value: "", text: "Select" }];
        courseList?.map((getItem) => {
            if (getItem.EndDateTime == '' || new Date(getItem.EndDateTime) >= new Date())
                courseValue.push({ value: getItem.CourseID, text: getItem.CourseName });
        });
        setCourseListData(courseValue);
    }, [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken]);

    const customSchema = useMemo(() => {
        const stepsValue = ["UserInfo", "CompanyInfo", "CourseInfo"];
        let temp = [];
        customOption?.[stepsValue[currentStep - 1]].map((getItem) => {
            let tempvalidation = {};
            tempvalidation = { id: getItem?.CustomFieldID, type: "text", validations: [], validationType: "string", };
            if (getItem.IsFieldRequired) {
                tempvalidation = { ...tempvalidation, validations: [...tempvalidation.validations, { type: "required", params: [getItem?.ProfileFieldName + " is required"] }] };
            }
            if (getItem.MinimumLength != "" && getItem.MinimumLength != undefined) {
                tempvalidation = {
                    ...tempvalidation, validations: [...tempvalidation.validations, {
                        type: "test", params: [parseInt(getItem.MinimumLength), "Invalid " + getItem?.ProfileFieldName, e => {
                            if (!getItem.IsFieldRequired && (e == "" || e == undefined)) {
                                return true;
                            }
                            if (e.length < parseInt(getItem.MinimumLength)) {
                                return false;
                            }

                            return true;

                        }]
                    }]
                };
            }
            if ((getItem.CustomRegex != "" && getItem.CustomRegex != null) && getItem.CustomFieldType == "DateOrTime") {
                tempvalidation = {
                    ...tempvalidation, validations: [...tempvalidation.validations, {
                        type: "test", params: ["DateValidation", "", async (e, { createError }) => {
                            if (e == "" || e == undefined || e == null) {
                                return true;
                            }
                            if (getItem.CustomRegex == "Past") {
                                if (new Date(e) > new Date(new Date().setDate(new Date().getDate() - 1))) {
                                    return createError({ message: [`${getItem?.ProfileFieldName + " should accept only past date"}`] });

                                }
                                return true;
                            }
                            if (getItem.CustomRegex == "Present&Future") {

                                if (new Date(e) < new Date(new Date().setDate(new Date().getDate() - 1))) {
                                    return createError({ message: [`${getItem?.ProfileFieldName + " should accept only present and future date"}`] });

                                }
                                return true;
                            }
                        }]
                    }]
                };
            }
            if (getItem.MaximumLength != "" && getItem.MaximumLength != undefined) {
                tempvalidation = {
                    ...tempvalidation, validations: [...tempvalidation.validations, {
                        type: "test", params: [parseInt(getItem.MaximumLength), "Invalid " + getItem?.ProfileFieldName, e => {
                            if (!getItem.IsFieldRequired && (e == "" || e == undefined)) {
                                return true;
                            }
                            if (e.length > parseInt(getItem.MaximumLength)) {
                                return false;
                            }

                            return true;

                        }]
                    }]
                };
            }
            if (getItem.Regex != "" && getItem.Regex != undefined && getItem.CustomFieldType != "DateOrTime") {
                tempvalidation = {
                    ...tempvalidation, validations: [...tempvalidation.validations, {
                        type: "test",
                        params: ["Regex", "Invalid " + getItem?.ProfileFieldName, (e) => {
                            if (!getItem.IsFieldRequired && (e == "" || e == undefined)) {
                                return true;
                            }
                            if (e?.match(new RegExp(getItem.Regex, 'g'))?.[0] == e) {
                                return true;
                            }
                            return false;
                        }]
                    }]
                };
            }
            if (getItem.IsFieldUniqueData) {
                tempvalidation = {
                    ...tempvalidation, validations: [...tempvalidation.validations, {
                        type: "test", params: ["UniqueData", "Value Already Exists", async (e) => {
                            if (getItem.IsFieldLock && mode === "Edit") {
                                return true;
                            }
                            if ((e == "" || e == undefined) && !getItem.IsFieldRequired) {
                                return true;
                            }
                            if (e == "" || e == undefined) {
                                previousState.current = ({ ...previousState.current, [getItem?.CustomFieldID]: { previousVal: e, previousState: false } });
                                return false;
                            }
                            if (e == fetchedData?.UserList?.[getItem?.ProfileFieldName] && fetchedData?.UserList?.[getItem?.ProfileFieldName] != undefined) {
                                return true;
                            }
                            if (previousState.current?.[getItem?.CustomFieldID]?.previousVal != undefined && e == previousState.current?.[getItem?.CustomFieldID]?.previousVal) {
                                return previousState.current?.[getItem?.CustomFieldID]?.previousState;
                            }
                            const query = getXlmsCheckCustomField, variables = { PK: "TENANT#" + props.TenantInfo.TenantID, SK: getItem?.CustomFieldID + "#" + e.toLowerCase().replace(/\s/g, '') };
                            const finalResponse = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken));
                            if (finalResponse.Status == "Success") {
                                if (finalResponse?.res?.getXlmsCheckCustomField != null || finalResponse?.res?.getXlmsCheckCustomField != undefined) {
                                    previousState.current = ({ ...previousState.current, [getItem?.CustomFieldID]: { previousVal: e, previousState: false } });
                                    return false;
                                }
                                previousState.current = ({ ...previousState.current, [getItem?.CustomFieldID]: { previousVal: e, previousState: true } });
                                return true;
                            }
                            return false;
                        }]
                    }]
                };
            }
            temp = [...temp, tempvalidation];
        });
        const yepSchema = temp.reduce(createYupSchema, {});
        return yepSchema;
    }, [customOption, currentStep, mode, fetchedData?.UserList, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, previousState]);

    // Get functions to build form with useForm() hook
    const finalValidationSchema = validationSchema.shape(customSchema);
    const formOptions = { mode: "onChange", resolver: yupResolver(finalValidationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, watch, setValue, formState } = useForm(formOptions);
    const { errors } = formState;


    const setValueCustomvalues = useCallback((temp) => {
        let tempArray = ["UserInfo", "CompanyInfo", "CourseInfo"];
        tempArray.map((data) => {
            customOption?.[data].map((getItem) => {
                let options;
                try {
                    options = JSON.parse(getItem.FieldOptions != undefined ? getItem.FieldOptions : `[{ value: "", text: "Select" }]`);
                }
                catch (e) {
                    options = [{ value: "", text: "Select" }];
                }
                if (options?.length > 1) {
                    options = options.filter((tempFilter) => { return tempFilter?.value == temp?.[getItem?.ProfileFieldName] })
                    if (temp?.[getItem?.ProfileFieldName] != undefined && options?.length > 0)
                        setValue(getItem?.CustomFieldID, temp?.[getItem?.ProfileFieldName]);
                    else if (temp?.[getItem?.ProfileFieldName] != undefined && options?.length == 0) {
                        setValue(getItem?.CustomFieldID, "");
                    }
                }
                else {
                    if (temp?.[getItem?.ProfileFieldName] != undefined)
                        setValue(getItem?.CustomFieldID, temp?.[getItem?.ProfileFieldName]);
                }
            });

        })
    }, [customOption, setValue]);

    const setDefaultValues = useCallback(() => {
        customOption?.UserInfo.map((getItem) => {
            if (getItem?.CustomFieldType == "DropdownMenu") {
                if (getItem?.FieldDefaultOptions != undefined) {
                    setValue(getItem?.CustomFieldID, getItem?.FieldDefaultOptions);
                }
                else {
                    setValue(getItem?.CustomFieldID, "");
                }
            }
        });
        customOption?.CompanyInfo.map((getItem) => {
            if (getItem?.CustomFieldType == "DropdownMenu") {
                if (getItem?.FieldDefaultOptions != undefined) {
                    setValue(getItem?.CustomFieldID, getItem?.FieldDefaultOptions);
                }
                else {
                    setValue(getItem?.CustomFieldID, "");
                }
            }
        });
        customOption?.CourseInfo.map((getItem) => {
            if (getItem?.CustomFieldType == "DropdownMenu") {
                if (getItem?.FieldDefaultOptions != undefined) {
                    setValue(getItem?.CustomFieldID, getItem?.FieldDefaultOptions);
                }
                else {
                    setValue(getItem?.CustomFieldID, "");
                }
            }
        });
    }, [customOption?.CompanyInfo, customOption?.CourseInfo, customOption?.UserInfo, setValue]);


    useEffect(() => {
        if (fetchedData?.LoginPolicy == undefined && fetchedData?.RoleData != undefined) {
            setModalValues((data) => {
                return { ...data, Content: "Login policy to be setup initially, to proceed with user creation" };
            });
        }
        if (mode == "Edit") {
            const userName = fetchedData?.UserList.UserName?.replace(fetchedData?.UserList.PrefixCode, "");
            setPrefix(fetchedData?.UserList.PrefixCode);
            setValue("ddlUserRole", fetchedData?.UserList.RoleName);
            setValue("chkSetMail", fetchedData?.UserList.IsSetUsername);
            setValue("txtUserName", fetchedData?.UserList.IsSetUsername ? userName : fetchedData?.UserList.UserName);
            setValue("txtFirstName", fetchedData?.UserList.FirstName);
            setValue("txtLastName", fetchedData?.UserList.LastName);
            setValue("txtPhoneNo", fetchedData?.UserList.MobileNo);
            setValue("txtEmailID", fetchedData?.UserList.EmailID);
            setValue("txtReportManagerEmail", fetchedData?.UserList.ReportManagerEmail);
            setValue("ddlAssignPlan", fetchedData?.UserList.AssignPlan);
            setValue("ddlGroupList", fetchedData?.UserList.Group);
            setValue("ddlAssignPlan", fetchedData?.UserList.AssignPlan);
            setValue("ProfileFileName", fetchedData?.UserList.ProfileURLPath, { shouldValidate: true });

            if (fetchedData?.UserList.ProfileURLPath) {
                setValue("imageControl", "Image");
            }

            if (!fetchedData?.UserList.IsSetUsername) setPrefix(fetchedData?.UserList.PrefixCode);
            setValueCustomvalues(fetchedData?.UserList);
        }
        else {
            setPrefix(fetchedData?.LoginPolicy?.PolicyPrefixCode != "" && fetchedData?.LoginPolicy?.PolicyPrefixCode != undefined ? fetchedData?.LoginPolicy?.PolicyPrefixCode : "Prefix");
            setDefaultValues();
        }
        if (fetchedData?.LoginPolicy?.UserIdRuleType == "EmailId")
            setValue("chkSetMail", true);
    }, [fetchedData, setValue, mode, router, customOption, setValueCustomvalues, setDefaultValues]);

    const [profile, setProfile] = useState({
        Profilefile: mode == "Edit" ? fetchedData?.UserList?.ProfileURLPath : null,
        ImgHeight: mode == "Edit" ? "" : "w-44 h-20",
        lblFile: "",
        uploadImage: "",
        UserImgURl: mode == "Edit" ? fetchedData?.UserList?.ProfileURLPath : null,
    });

    useEffect(() => {
        setProfile({
            Profilefile: mode == "Edit" ? fetchedData?.UserList?.ProfileURLPath : null,
            ImgHeight: mode == "Edit" ? "" : "w-44 h-20",
            lblFile: "",
            uploadImage: "",
            UserImgURl: mode == "Edit" ? fetchedData?.UserList?.ProfileURLPath : null,
        });
    }, [fetchedData?.UserList?.ProfileURLPath, mode]);

    const value = useCallback((temp) => {
        setValue("submit", temp);
    }, [setValue]);

    const submitHandler = useCallback(async (data) => {
        if (currentStep === 3) {
            value(true);
            try {
                function getCustomFieldValues() {
                    let CustomFieldsData = "";
                    customOption.UserInfo.map((getItem) => { CustomFieldsData = CustomFieldsData + '"' + [getItem.ProfileFieldName] + '":"' + (data?.[getItem.CustomFieldID] != undefined ? data?.[getItem.CustomFieldID] : "") + '",'; });
                    customOption.CompanyInfo.map((getItem) => { CustomFieldsData = CustomFieldsData + '"' + [getItem.ProfileFieldName] + '":"' + (data?.[getItem.CustomFieldID] != undefined ? data?.[getItem.CustomFieldID] : "") + '",'; });
                    customOption.CourseInfo.map((getItem) => { CustomFieldsData = CustomFieldsData + '"' + [getItem.ProfileFieldName] + '":"' + (data?.[getItem.CustomFieldID] != undefined ? data?.[getItem.CustomFieldID] : "") + '",'; });
                    return CustomFieldsData;
                }
                const setUploadURL = mode === "Create" ? process.env.APIGATEWAY_URL_USERCREATION : process.env.APIGATEWAY_URL_UPDATEUSER;
                const stateURL = mode === "Create" ? process.env.STEP_FUNCTION_ARN_USERCREATION : process.env.STEP_FUNCTION_ARN_UPDATEUSER;
                let CustomFields = "," + getCustomFieldValues();
                CustomFields = CustomFields.substring(0, CustomFields.length - 1);
                const jsonSaveData = '{"TenantID": "' + props.TenantInfo.TenantID +
                    '", "Password": "' + data.txtpassword +
                    '", "UserName": "' + (fetchedData.LoginPolicy?.UserIdRuleType == "EmpCode" ? (!data.chkSetMail ? data.txtUserName.toLowerCase() : data.txtEmailID.toLowerCase()) : (data.chkSetMail ? data.txtEmailID.toLowerCase() : (mode === "Edit" ? prefix + data.txtUserName?.toLowerCase() : data.txtUserName?.toLowerCase()))) +
                    '", "FirstName": "' + data.txtFirstName +
                    '", "LastName": "' + data.txtLastName +
                    '", "MobileNo": "' + data.txtPhoneNo +
                    '", "EmailID": "' + data.txtEmailID.toLowerCase() +
                    '", "RoleName": "' + (mode === "Edit" ? (fetchedData.UserList.RoleName ??= data.ddlUserRole) : data.ddlUserRole) +
                    '", "ReportManagerEmail": "' + data.txtReportManagerEmail +
                    '", "Group List": "' + data.ddlGroupList +
                    '", "AssignPlan": "' + data.ddlAssignPlan +
                    '", "EmpCode": "' + (fetchedData.LoginPolicy?.UserIdRuleType == "EmpCode" ? "true" : "false") +
                    '", "CreatedDate": "' + (mode == "Edit" ? fetchedData?.UserData?.CreatedDate : new Date().toISOString()) +
                    '", "IsSetUsername":"' + (data.chkSetMail) +
                    '", "ForcePassword":"' + (data.chkPasswordChange ??= "false") +
                    '", "CreatedBy":"' + "test" +
                    '", "NewRole":"' + data.ddlUserRole +
                    '", "UserSub":"' + (fetchedData?.UserList?.UserSub != undefined ? fetchedData?.UserList?.UserSub : "") +
                    '", "Sub":"' + props?.user.attributes.sub + "" +
                    '", "BucketName":"' + props.TenantInfo.BucketName +
                    '", "RootFolder":"' + props.TenantInfo.RootFolder +
                    '", "ProfileURLPath":"' + (data.ProfileFileName == undefined ? "" : data.ProfileFileName) +
                    '", "PrefixCode":"' + (data.chkSetMail == false ? prefix : "") +
                    '", "GroupID":"' + (data.ddlGroupList != undefined ? data.ddlGroupList : "") +
                    '", "CourseID":"' + (data.ddlCourse != undefined ? data.ddlCourse : "") +
                    '", "BatchID":"' + (data.ddlBatch != undefined ? data.ddlBatch : "") +
                    '"' + CustomFields +
                    ' }';

                const statemachinearn = mode == "Edit" ? process.env.STEP_FUNCTION_ARN_UPDATEUSER : process.env.STEP_FUNCTION_ARN_USERCREATION;
                const menuId = mode == "Edit" ? "200101" : "200300";
                await fetch(setUploadURL, { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: "CompanyAdmin", groupmenuname: "UserManagement", menuid: menuId, statemachinearn: stateURL }, body: jsonSaveData, })
                    .then((response) => response.text())
                    .then(() => {
                        setModalValues({ ModalInfo: mode === "Edit" ? "Success" : "Info", ModalOnClickEvent: () => { router.push("/UserManagement/UserList"); }, });
                        ModalOpen();
                    });
            }
            catch (e) {

                setModalValues({ ModalInfo: "Danger", });
                ModalOpen();
                value(false);
                return;
            }
        }
        else {
            let newStep = currentStep;
            newStep++;
            setCurrentStep(newStep);
        }
    }, [currentStep, value, mode, props.TenantInfo.TenantID, props.TenantInfo.BucketName, props.TenantInfo.RootFolder, props.user.attributes.sub, props.user.signInUserSession.accessToken.jwtToken, fetchedData?.LoginPolicy?.UserIdRuleType, fetchedData?.UserList, fetchedData?.UserData?.CreatedDate, prefix, customOption?.UserInfo, customOption?.CompanyInfo, customOption?.CourseInfo, router])


    const handleClick = useCallback(() => {
        setCurrentStep((data) => {
            if (data > 1) {
                setProfile((Profile) => {
                    return { ...Profile, lblFile: "" }
                });
                return data - 1;
            }
            return data;
        });
    }, []);

    // Bread Crumbs
    const pageRoutes = useMemo(() => { return [{ path: "/UserManagement/UserList", breadcrumb: "User Management" }, { path: "", breadcrumb: mode != "Edit" ? "Create User" : "Edit User" }]; }, [mode]);
    const DisplayStep = useCallback((props) => {
        switch (props.currentStep) {
            case 1:
                return (
                    <UserInfo watch={props.watch}
                        Profile={props.Profile}
                        setProfile={setProfile}
                        user={props.user}
                        Data={props.fetchedData?.UserList}
                        register={props.register}
                        setValue={props.setValue}
                        EmailPolicy={props.fetchedData?.LoginPolicy?.UserIdRuleType}
                        errors={props.errors} mode={props.mode} Role={props.fetchedData?.RoleData}
                        TenantId={props?.TenantInfo?.TenantID}
                        Prefix={props.Prefix}
                        CustomFields={props.customOption.UserInfo}
                        TenantInfo={props.TenantInfo}
                        ProfileURLPath={props.mode == "Edit" ? props.fetchedData?.UserList?.ProfileURLPath : ""}
                        IsUpload={props.value}
                    />
                );
            case 2:
                return (
                    <CompanyInfo Data={props.fetchedData?.UserList} register={props.register} setValue={props.setValue} errors={props.errors} mode={props.mode} CustomFields={props.customOption.CompanyInfo} />
                );
            case 3:
                return (
                    <CourseInfo Data={props.fetchedData?.UserList} register={props.register} setValue={props.setValue} Group={props.Group} LearningPlan={props.LearningPlan} AssignCourseList={props.AssignCourseList} errors={props.errors} mode={props.mode} setMulti={setMultiselected} Multiselected={props.Multiselected} CustomFields={props.customOption.CourseInfo} CategoryData={props.CategoryState} CourseData={props.courseListData} BatchData={props.BatchState} />
                );
            default:
        }
    }, []);

    const UserPage = useCallback((props) => {
        return (
            <div className="w-full sm:w-full sm:overflow-x-auto sm:overflow-y-auto md:w-full md:overflow lg:w-full lg:overflow-y-hidden xl:w-full xl:overflow-hidden flex-wrap">
                <div className="mx-auto rounded-2xl bg-white pb-2 shadow-xl md:w-full">
                    <form onSubmit={props.handleSubmit(props.submitHandler)} id="fmUser" className={`${props.watch("submit") ? "pointer-events-none" : ""}`}>
                        <div className="w-full ">
                            <Stepper steps={props.steps} currentStep={props.currentStep} />
                            <div className="my-10">
                                <UseContextProvider>
                                    <DisplayStep AssignCourseList={props.AssignCourseList} BatchState={props.BatchState} CategoryState={props.CategoryState} fetchedData={props.fetchedData} Group={props.Group} LearningPlan={props.LearningPlan} Multiselected={props.Multiselected} Prefix={props.Prefix} Profile={props.Profile} courseListData={props.courseListData} customOption={props.customOption} errors={props.errors} mode={props.mode} register={props.register} setValue={props.setValue} value={props.value} watch={props.watch} TenantInfo={props.TenantInfo} user={props.user} currentStep={props.currentStep} />
                                </UseContextProvider>
                            </div>
                        </div>
                        {props.currentStep > 0 && props.currentStep <= props.steps.length && (
                            <StepperControl handleClick={props.handleClick} currentStep={props.currentStep} steps={props.steps} Flag={props.watch("submit")} />
                        )}
                    </form>

                </div>
            </div>
        );
    }, []);

    return (
        <>
            <Container title="User Management" loader={fetchedData == undefined} PageRoutes={pageRoutes}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <UserPage AssignCourseList={assignCourseList} BatchState={batchState} CategoryState={categoryState} fetchedData={fetchedData} Group={group} LearningPlan={learningPlan} Multiselected={multiselected} Prefix={prefix} Profile={profile} courseListData={courseListData} customOption={customOption} errors={errors} mode={mode} register={register} setValue={setValue} value={value} currentStep={currentStep} handleClick={handleClick} handleSubmit={handleSubmit} submitHandler={submitHandler} watch={watch} TenantInfo={props.TenantInfo} user={props.user} steps={steps} />
                <NVLModalPopup ButtonYestext="Yes" IsConfirmAlert={true} SubmitClick={() => { router.push("/SiteConfiguration/LoginPolicy?start=0"); }} CloseIconEvent={() => { router.push("/SiteConfiguration/LoginPolicy?start=0"); }} Content={modalValues.Content} />
            </Container>
        </>
    );
}