import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";
import { updateXlmsUserGroupInfo } from "src/graphql/mutations";
import { listXlmsUserGroupInfos } from "src/graphql/queries";

function ManageGroupList(props) {
    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(0);
    const [search, setSearch] = useState("");
 
    const headerColumn = [
        { HeaderName: "Group Name", Columnvalue: "GroupName", HeaderCss: "w-6/12" },
        { HeaderName: "Description", Columnvalue: "Description", HeaderCss: "w-6/12", },
        { HeaderName: "No Of Users", Columnvalue: "Users", HeaderCss: "w-0/12" },
        { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-0/12" },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
    ];

    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    const refreshData = async () => {
        setSearch("");
        setIsRefreshing((count) => { return count + 1;});
    };

    const resetPopUp = useCallback(()=>{
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
        setSearch("");
    },[]);

    function popUp(type, PK, SK, Content) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
    }

    async function UpdateField(e) {
        e.preventDefault();
        let isSus = false;
        let isDelete = false;
        if (popupValues.Type == "isSuspend") {
            isSus = true;
        } else if (popupValues.Type == "isDelete") {
            isDelete = true;
        }
        await AppsyncDBconnection(updateXlmsUserGroupInfo, { input: { PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus, IsDeleted: isDelete, }, }, props.user.signInUserSession.accessToken.jwtToken)
            .then(() => {
                refreshData();
            })
            .catch((e) => {
             
                return e?.errors?.[0].message;
            });
        resetPopUp();
    }

    const actionRestriction = useCallback((getItem) => {
        const actionList = [];
        if (props.RoleData?.EditGroup && !getItem.IsSuspend) {
            actionList.push(
                {
                    id:5,
                    color: "text-green-700",
                    Icon : "fa-solid fa-pencil text-green-700 bg-green-100 w-6",
                    name: "Assign Course",
                    action :() => router.push(`/UserManagement/AssignCourse?GroupID=${getItem.SK.substring(getItem.SK.indexOf("#") + 1)}`),
                },
                {
                    id: 1,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Edit",
                    action: () => router.push(`/UserManagement/EditGroup?TenantID=${getItem.PK.substring(getItem.PK.indexOf("#") + 1)}&GroupID=${getItem.SK.substring(getItem.SK.indexOf("#") + 1)}&mode=Edit`),
                },
            );
        }
        if (props.RoleData?.SuspendGroup && !getItem.IsSuspend) {
            actionList.push(
                {
                    id: 2,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                    name: "Suspend",
                    action: () => popUp("isSuspend", getItem.PK, getItem.SK, "Are you sure Want to Suspend User Group"),
                },
            );
        }
        if (props.RoleData?.SendNotificationGroup && !getItem.IsSuspend) {
            actionList.push(
                {
                    id: 2,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                    name: "SendNotification",
                    action: () =>router.push(`/UserManagement/Notification?TenantID=${getItem.PK.substring(getItem.PK.indexOf("#") + 1)}&SK=${getItem.SK.substring(getItem.SK.indexOf("#") + 1)}`),
                },
            );
        }
    
        if (props.RoleData?.DeleteGroup && getItem.IsSuspend) {
            actionList.push(
                {
                    id: 3,
                    Color: "text-rose-700",
                    Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                    name: "Delete Group",
                    action: () =>router.push(`/UserManagement/EditGroup?TenantID=${getItem.PK.substring(getItem.PK.indexOf("#") + 1)}&GroupID=${getItem.SK.substring(getItem.SK.indexOf("#") + 1)}&mode=Delete`),
                },
            );
        }
        if (props.RoleData?.UnsuspendGroup && getItem.IsSuspend) {
            actionList.push(
                {
                    id: 4,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                    name: "Unsuspend",
                    action: () =>popUp("isUnSuspend", getItem.PK, getItem.SK, "Are you sure Want to UnSuspend User Group"),
                },
            );
        }
        return actionList;
    }, [router, props]);

    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData.map((getItem, index) => {
              !getItem.IsDeleted
                ? rowGrid.push({
                    GroupName: (<NVLlabel id={"lblgpname" + (index + 1)} text={getItem.GroupName}></NVLlabel>),
                    Description: (<NVLlabel id={"lbldesc" + (index + 1)} text={getItem.GroupDescr}></NVLlabel>),
                    Action: !getItem.IsSuspend ? (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal>) : (
                        <NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal>),
                    Status: (
                        <>
                            <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                                <div className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"}	`}></div>
                                <NVLlabel className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2	`} text={!getItem.IsSuspend ? "Active" : "Inactive"}></NVLlabel>
                            </div>
                        </>
                    ),
                    Users: getItem.TotalCount
           
          
                })
                : "";
        });
        return rowGrid;
    }, [actionRestriction]);

    const variable = useMemo(()=>{return{ PK: "TENANT#" + props.TenantInfo.TenantID, SK: "GROUPINFO#", };},[props.TenantInfo.TenantID]);
 
    // Bread Crumbs
    const pageRoutes = useMemo(()=>{return[
        {path: "/UserManagement/UserList", breadcrumb: "User Management"} ,
        {path: "", breadcrumb: "Manage Group" }
    ];},[]);
 
    return (
        <Container PageRoutes={pageRoutes}>
            <NVLHeader IsSearch={props.RoleData?.GroupSeTenanth ? true : false} 
            SearchonChange={(e) => searchBoxVal(e)} 
            onClick1={refreshData} 
            RedirectAction5={() => refreshData()} 
            TableID={"tblGroupData"} 
            IsNestedHeader 
            placeholder={"Search by Group Name"} />
            <NVLGridTable 
            user={props.user} 
            refershPage={isRefreshing} 
            Search={search} 
            id="tblUserList" 
            HeaderColumn={headerColumn} 
            GridDataBind={gridDataBind} 
            query={listXlmsUserGroupInfos} 
            querryName={"listXlmsUserGroupInfos"} 
            variable={variable} 
            />
            <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => UpdateField(e)} CancelClick={(e) => resetPopUp(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
        </Container>
    );
}

export default ManageGroupList;