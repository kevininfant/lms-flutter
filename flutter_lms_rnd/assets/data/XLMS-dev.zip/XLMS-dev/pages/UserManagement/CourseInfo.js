
import NVLMultiOptionField from "@components/Controls/NVLMultiOptionField";
import NVLSelectField from "@components/Controls/NVLSelectField";

const CourseInfo = (props) => {

    return (
        <>
            <div className="nvl-FormContent">
                {props.mode != "Edit" && <>
                    <NVLSelectField labelClassName="nvl-Def-Label" labelText="Add to Group" options={props.Group} className="nvl-non-mandatory nvl-Def-Input" id="ddlGroupList" placeholder="Group List" register={props.register} errors={props.errors} />
                    <div className="pb-4">

                        <NVLSelectField id="ddlCategory" labelText="Select Category" labelClassName="nvl-Def-Label" errors={props.errors} register={props.register} options={props?.CategoryData} className={`w-96 nvl-non-mandatory`} />
                    </div>
                    <div className="pb-3">
                        <NVLSelectField id="ddlCourse" labelText="Select Course" labelClassName="nvl-Def-Label" errors={props.errors} register={props.register} options={props?.CourseData} className={`w-96 nvl-non-mandatory`} />
                        <div className="block {invalid-feedback} text-red-500  text-sm">  {props?.errors.user?.message}</div>
                    </div>
                    <div className="pb-4" >
                        <NVLSelectField id="ddlBatch" labelText="Batch Name" labelClassName="nvl-Def-Label" className="nvl-non-mandatory nvl-Def-Input " options={props?.BatchData} errors={props.errors} register={props.register} />
                    </div>
                </>}
                <div className="hidden">
                <NVLSelectField labelClassName="nvl-Def-Label hidden" labelText="Assign learning Plan" options={props.LearningPlan} id="ddlAssignPlan" className=" hidden nvl-non-mandatory nvl-Def-Input " register={props.register} errors={props.errors} />
                </div>
                {props.CustomFields.map((item, index) => {
                    let options;
                    try {
                                        options = JSON.parse(item.FieldOptions != undefined ? item.FieldOptions : `[{ value: "", text: "Select" }]`);
                    }
                    catch (e) {
                        options = [{ value: "", text: "Select" }];
                    }
                    return (
                        <NVLMultiOptionField disabled={props.mode == "Edit" ? (item.IsFieldLock && item.IsFieldRequired ? (props?.Data?.[item.ProfileFieldName] == undefined ? false : item.IsFieldLock) : item.IsFieldLock) : false} key={index} setValue={props.setValue} ControlType={item.CustomFieldType} labelText={item.ProfileFieldName} id={item.CustomFieldID} Datecontrol={item.CustomRegex} ControlOptions={options} title={"Enter the " + item.ProfileFieldName} register={props.register} errors={props.errors} className={`nvl-Def-Input ${item.IsFieldRequired ? "nvl-mandatory" : "nvl-non-mandatory"}`} />
                    );
                })}
            </div>
        </>
    );
};
export default CourseInfo;
