import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLMultiOptionField from "@Controls/NVLMultiOptionField";

const CompanyInfo = (props) => {

    return (
        <>
            <div className="nvl-FormContent">
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="Reporting Manager Email" title="Reporting Manager Email ID" required className="nvl-mandatory nvl-Def-Input" register={props.register} errors={props.errors} id="txtReportManagerEmail" type="text" />
                {props.CustomFields.map((item, index) => {
                    let options;
                    try {
                        options = JSON.parse(item.FieldOptions != undefined ? item.FieldOptions : `[{ value: "", text: "Select" }]`);
                    }
                    catch (e) {
                        options = [{ value: "", text: "Select" }];
                    }
                    return (
                        <NVLMultiOptionField disabled={props.mode == "Edit" ? (item.IsFieldLock && item.IsFieldRequired ? (props?.Data?.[item.ProfileFieldName] == undefined ? false : item.IsFieldLock) : item.IsFieldLock) : false} key={index} setValue={props.setValue} ControlType={item.CustomFieldType} labelText={item.ProfileFieldName} id={item.CustomFieldID} Datecontrol={item.CustomRegex} ControlOptions={options} title={"Enter the " + item.ProfileFieldName} register={props.register} errors={props.errors} className={`nvl-Def-Input ${item.IsFieldRequired ? "nvl-mandatory" : "nvl-non-mandatory"}`} />
                    );
                })}
            </div>
        </>
    );
};

export default CompanyInfo;