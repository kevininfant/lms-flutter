import NVLCheckboxField from "@components/Controls/NVLCheckBox";
import NVLImageUpload from "@components/Controls/NVLImageUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultiOptionField from "@components/Controls/NVLMultiOptionField";
import NVLPassword from "@components/Controls/NVLPassword";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLToolTipTextBox from "@components/Controls/NVLToolTipTextBox";
import { APIGatewayPutRequest } from "DBConnection/ErrorResponse";

const UserInfo = (props) => {
    const { mode, Role } = props;


    // Upload profile image
    const uploadProfile = async (e) => {

        props.IsUpload(true);
        if (e.target.files.length == 0) {
            props.IsUpload(false);
            return;
        }
        props.setValue("imageControl", "Upload");
        let file = e.target.files[0];
        const tempPresignedURL = process.env.COMPANYLOGO_PRESIGNED_URL_S3_BUCKET;
        const fileExtension = e.target.files[0].name.substring(e.target.files[0].name.lastIndexOf(".") + 1).toLowerCase();

        let fileType;
        const reader = new FileReader();
        let temp = 0;

        reader.onloadend =async  function () {
            const arr = (new Uint8Array(reader.result)).subarray(0, 4);
            let header = '';
            for (let i = 0; i < arr.length; i++) {
                header += arr[i].toString(16);
            }
            switch (header) {
                case '89504e47':
                    fileType = 'image/png';
                    break;
                case '47494638':
                    fileType = 'image/gif';
                    break;
                case 'ffd8ffe0':
                case 'ffd8ffe1':
                case 'ffd8ffe2':
                    fileType = 'image/jpeg';
                    break;
                default:
                    temp = 1;
                    props.setProfile({ ...props.Profile, Profilefile: null, lblFile: "Profile file format seems to be changed!", });
                    props.setValue("imageControl", "Error");
                    props.IsUpload(false);
                    fileType = 'unknown';
                    break;
            }
            if (temp == 1) {
                return false;
            }
            if (process.env.USERPROFILE_EXTENTION.indexOf(fileExtension) <= -1) {
                props.setProfile({ ...props.Profile, Profilefile: null, lblFile: "Please upload only .jpg, .jpeg, .png file!", });
                props.setValue("imageControl", "Error");
                props.IsUpload(false);
                return false;
            } else if ((file.type.split("/").pop() != file.name.split(".").pop()) && !((file.name.split(".").pop() == "jpg" && file.type.split("/").pop() == "jpeg") || (file.name.split(".").pop() == "jpeg" && file.type.split("/").pop() == "jpg"))) {
                props.setProfile({ ...props.Profile, Profilefile: null, lblFile: "Profile file format seems to be changed!", });
                props.setValue("imageControl", "Error");
                props.IsUpload(false);
                return false;
            } else if (file.size > process.env.USERPROFILE_SIZE) {
                props.setProfile({ ...props.Profile, Profilefile: null, lblFile: "File size should be 50KB", });
                props.setValue("imageControl", "Error");
                props.IsUpload(false);
                return false;
            }
            // Creates  blobfile
            const createFile = (bits, name) => {
                try {
                    return new File(bits, name, { type: "image/" + name.split(".").pop(), lastModified: new Date() });
                } catch (e) {
                    var myBlob = new Blob(bits);
                    myBlob.lastModified = new Date();
                    myBlob.name = name;
                    return myBlob;
                }
            };
            let fileName = e.target.files[0].name;
            if (((file.name.split(".").pop() == "jpg" && file.type.split("/").pop() == "jpeg") || (file.name.split(".").pop() == "jpeg" && file.type.split("/").pop() == "jpg"))) {
                fileName = fileName.split(".")[0] + "." + file.type.split("/").pop();
                file = createFile([file], crypto.randomUUID() + "." + file.type.split("/").pop());
            }
            props.setProfile({ Profilefile: file, lblFile: "", ImgHeight: "w-44 h-20", uploadImage: file, UserImgURl: fileName });
            props.setValue("UploadImage", file);
            const requestOptions = { method: "GET", headers: { authorizationtoken: props?.user?.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "CompanyManagement", menuid: "100401", } };
            const presignedHeader = { method: "PUT", body: file, };
            const presignedUrl = tempPresignedURL + `?ProfileImgName=${fileName}&isUser=${"true"}&TenantID=${props.TenantId}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&S3KeyName=${props.TenantInfo.RootFolder}/${props.TenantInfo.TenantID}&S3BucketName=${props.TenantInfo.BucketName}&BucketName=${props.TenantInfo.BucketName}`;
            const finalStatus = await APIGatewayPutRequest(presignedUrl, requestOptions, presignedHeader);
            if (finalStatus[0] == "Success") {
                props.IsUpload(false);
                props.setValue("imageControl", "Image");
                props.setValue("ProfileFileName", fileName);
            }
        };
        reader.readAsArrayBuffer(file);
    };
    // Remove profile Image 
    const removeImg = () => {
        document.getElementById("fulogo").value = null;
        props.setProfile({ Profilefile: null, lblFile: "", ImgHeight: "", uploadImage: null, UserImgURl: null, });
        props.setValue("imageControl", "");
        props.setValue("ProfileFileName", null);
    };

    return (
        <>
            <div className="nvl-FormContent">
                <NVLSelectField labelClassName="nvl-Def-Label" labelText="Select Role" options={Role} id="ddlUserRole" className={mode == "Edit" ? "Disabled nvl-Def-Input nvl-mandatory" : "nvl-mandatory nvl-Def-Input"} register={props.register} errors={props.errors}></NVLSelectField>
                <div className={props.EmailPolicy == "EmailId" ? "hidden" : ""}>
                    <NVLlabel className="nvl-Def-Label" text={props.EmailPolicy == "EmpCode" ? "Employee Code" : "User Name"}   >
                        <span className="text-red-500 text-lg">*</span>
                    </NVLlabel>

                    <div className="grid grid-flow-col">
                        <div className={"flex rounded-md h-9 nvl-Def-Input shadow-sm relative"}>
                            <span id="txtPrefixcode" className={props.EmailPolicy == "EmpCode" ? "hidden" : " w-14 md:w-20 p-2 inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-xs"}>
                                {props.Prefix == "" ? "Prefix" : props.Prefix}
                            </span>
                            <NVLToolTipTextBox disabled={props.watch("chkSetMail") ? true : false} labelClassName="nvl-Def-Label" wfull="w-full" icon={true} HelpInfo={props.EmailPolicy == "EmpCode" ? "Employee code will be considered as the user name" : ""} HelpInfoIcon={props.EmailPolicy == "EmpCode" ? "fa fa-solid fa-circle-question" : ""} title={props.EmailPolicy == "EmpCode" ? "Employee Code" : "User Name"} id="txtUserName" className={`${mode == "Edit" || props.watch("chkSetMail") ? "Disabled nvl-Def-Input " : "nvl-mandatory "}${props.EmailPolicy == "EmpCode" ? "nvl-Def-Input" : "!w-full"}`} type={"text"} register={props.register} errors={props.errors} />
                        </div>
                    </div>
                </div>
                <div className={"{invalid-feedback}  text-red-500 text-sm "}>
                    {props.errors.txtUserName?.message}
                </div>
                <div className={props.EmailPolicy == "EmailId" || mode == "Edit" ? "hidden" : ""}>
                    <NVLCheckboxField className="text-xs " text="Set Email as User Name" id="chkSetMail" value={true} register={props.register} errors={props.errors} />
                </div>
                <NVLToolTipTextBox labelClassName="nvl-Def-Label" labelText="Email" HelpInfo={`${"Please enter a valid mail ID, your login credentials will be triggered to this mail."}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} title="Email" id="txtEmailID" className={mode == "Edit" ? "Disabled nvl-Def-Input nvl-mandatory" : "nvl-Def-Input nvl-mandatory"} type={"text"} register={props.register} errors={props.errors} />
                <div className={mode == "Edit" ? "hidden" : ""}>
                    <NVLPassword HelpInfo={"Enter the new password, else the system will create an auto generated password and share the same to the user through mail."} HelpInfoIcon={"m-auto pl-3 pt-2 fa fa-solid fa-circle-question"} title="Password" id="txtpassword" type="password" labelText="Password" labelClassName="nvl-Def-Label" className=" nvl-non-mandatory nvl-Def-Input !pr-8" register={props.register} errors={props.errors}></NVLPassword>
                </div>
                <div className={mode == "Edit" ? "hidden" : "Left-Aligned-Items"}>
                    <NVLCheckboxField id="chkPasswordChange" text="Force Password Change" register={props.register} errors={props.errors} disabled={mode == "Edit" ? true : false} />
                </div>
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="First Name " title="First Name" id="txtFirstName" className={" nvl-mandatory "} type="text" register={props.register} errors={props.errors} />
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="Last Name " title="Last Name" id="txtLastName" className="nvl-mandatory " type="text" register={props.register} errors={props.errors} />
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="Phone Number" title=" Phone Number" type="number" id="txtPhoneNo" 
                 className={" nvl-Def-Input n nvl-mandatory"} register={props.register} errors={props.errors} />

                {props.CustomFields.map((item, index) => {
                    let options;
                    try {
                        options = JSON.parse(item.FieldOptions != undefined ? item.FieldOptions : `[{ value: "", text: "Select" }]`);
                    }
                    catch (e) {
                        options = [{ value: "", text: "Select" }];
                    }
                    return (
                        <NVLMultiOptionField disabled={props.mode == "Edit" ? (item.IsFieldLock && item.IsFieldRequired ? (props?.Data?.[item.ProfileFieldName] == undefined ? false : item.IsFieldLock) : item.IsFieldLock) : false} key={index} setValue={props.setValue} ControlType={item.CustomFieldType} labelText={item.ProfileFieldName} id={item.CustomFieldID} Datecontrol={item.CustomRegex} ControlOptions={options} title={"Enter the " + item.ProfileFieldName} register={props.register} errors={props.errors} className={`nvl-Def-Input ${item.IsFieldRequired ? "nvl-mandatory" : "nvl-non-mandatory"}`} />
                    );
                })}
                <NVLlabel text="Upload User Profile" className="nvl-Def-Label" HelpInfo={"Acceptable file format: jpg, png, jpeg.<br>File size should not exceed more than 50KB"} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                <NVLlabel className="block text-sm font-medium text-gray-700" id="lblLogo" />
                <NVLImageUpload text="Upload Profile" accept={".jpg,.png,.jpeg"} watch={props.watch} UploadLogo={uploadProfile} control={"imageControl"} mode={props.mode} Logofile={props.Profile.Profilefile == "" ? null : props.Profile.Profilefile} uploadImage={props.Profile.uploadImage} ImgHeight={props.Profile.ImgHeight} removeImg={removeImg} lblFile={props.Profile.lblFile} />
            </div>

        </>
    );
};

export default UserInfo;