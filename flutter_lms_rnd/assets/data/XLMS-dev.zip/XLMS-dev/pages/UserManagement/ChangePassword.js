import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLPassword from "@components/Controls/NVLPassword";
import Container from "@Container/Container";
import { yupResolver } from "@hookform/resolvers/yup";
import { useMemo } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

export default function ChangePassword(props) {

    const validationSchema = Yup.object().shape({
        txtpassword: Yup.string().test("validateStrength", "", (e, { createError }) => {
            let strength = 0, message = "Password Should Have ";
            if (!e.match(/\d+/g)) {
                strength++;
                message = message + "a number";
            }
            if (!e.match(/[A-Z]+/g)) {
                strength++;
                if (strength > 1) {
                    message = message + ", ";
                }
                message = message + "a capital letter";
            }
            if (!e.match(/[a-z]+/g)) {
                strength++;
                if (strength > 1) {
                    message = message + ", ";
                }
                message = message + "a Small Letter";
            }
            if (!e.match(/[!@#$%&*())]+/g)) {
                strength++;
                if (strength > 1) {
                    message = message + ", ";
                }
                message = message + "a special character";
            }
            if (e.length < parseInt(props.PasswordChange?.LoginPolicy?.PasswordLength)) {
                strength++;
                if (strength > 1) {
                    message = message + ", ";
                }
                message = message + "minimum of length " + props.PasswordChange?.LoginPolicy.PasswordLength;
            }
            if (strength > 0) {
                return createError({ message: message });
            }
            return true;
        })
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, watch, setValue, formState } = useForm(formOptions);
    const { errors } = formState;
    const submitHandler = async (data) => {
        setValue("submit", true)
        const URL = process.env.APIGATEWAY_URL_CHANGEPASSWORD;
        const contentsPromise = await fetch(`${process.env.APIGATEWAY_URL_CHANGEPASSWORD}?UserName=${props.PasswordChange.UserName}&Password=${data.txtpassword}`,
            {
                method: "GET",
                headers: {
                    "Content-Type": "application/text",
                    authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    defaultrole: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0],
                    groupmenuname: "UserManagement",
                    menuid: "200455"
                },
            }
        );

        props.finalResponse(contentsPromise.status == 200 ? "Success" : "Error");
        setValue("submit", false)
    }

    const fieldAttributes = useMemo(() => {
        return [{ text: "Username", value: props.PasswordChange?.UserName }, { text: "Name", value: props.PasswordChange?.Name }]
    }, [props.PasswordChange?.Name, props.PasswordChange?.UserName])

    return (
        <>
            <Container title="User Management"  >
                <form onSubmit={handleSubmit(submitHandler)} className={`px-2 ${watch("submit") ? "pointer-events-none" : ""}`}>

                    {fieldAttributes.map((item) => {
                        return (
                            <>
                                <div className="flex gap-5">
                                    <div className="w-28 h-10">
                                        <NVLlabel showFull={true} className={"break-words nvl-Def-Label"} text={item.text} />
                                    </div>
                                    <NVLlabel className={" nvl-Def-Label"} text={":"} />
                                    <div>
                                        <NVLlabel showFull={true} className={"break-words nvl-Def-Label"} text={item.value} />
                                    </div>
                                </div>
                            </>
                        )
                    })}
                    <div className="flex gap-0">
                        <div className="flex gap-10 !w-44">
                            <NVLlabel showFull={true} className="nvl-Def-Label " text="New Password" ></NVLlabel>
                            <NVLlabel className={" nvl-Def-Label"} text={":"} />
                        </div>
                        <div className="!w-72 -ml-5">
                            <NVLPassword eyeIconStyle="left-[230px]" title="Password" id="txtpassword" type="password" className=" nvl-mandatory nvl-Def-Input !pr-3  !w-64" register={register} errors={errors} />
                        </div>
                        <div >
                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Change Password" : ""} type="submit" className={`w-44 nvl-button bg-primary text-white`}>
                                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                            </NVLButton>
                        </div>
                    </div>


                </form>
            </Container>
        </>
    );
}
