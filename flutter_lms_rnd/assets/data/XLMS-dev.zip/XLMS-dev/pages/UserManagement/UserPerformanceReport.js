import UserPerformance from "@Pages/Report/UserPerformance"
export default function UserPerformanceReport(props) {
    return <UserPerformance props={props}></UserPerformance>
}
