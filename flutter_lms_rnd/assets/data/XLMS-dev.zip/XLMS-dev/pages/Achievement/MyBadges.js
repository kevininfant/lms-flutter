import Container from "@components/Container/Container";
import NVLImage from "@components/Controls/NVLImage";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsActivityManagementInfos, listXlmsCourseBadgeInfos, listXlmsCourseEnrollUser, listXlmsEnrollUser, listXlmsUserCertificateInfos } from "src/graphql/queries";
import * as Yup from "yup";
export default function MyBadges(props) {
  const validationSchema = Yup.object().shape({
    ddlBadgeFilter: Yup.string().test("", "", async (e) => {
      FilterMyBAdgeList(e)
    }),

  })
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { setValue, formState, watch, register } = useForm(formOptions);
  const { errors } = formState;
  let FilterMyBadges = [{ value: "Filter by Badge", text: "Filter by Badge" },
  { value: "Available", text: "Available" },
  { value: "Issued", text: "Issued" }];
  const router = useRouter();
  const [ShowMyAllBadges, setShowMyAllBadges] = useState([]);
  const MyAvailableBadges = useRef([]);
  const CompletedBadgeList = useRef([]);

  
  const IssuedOrAvailable = (() => {
    let InCompleted = [];
    for (let index = 0; index < MyAvailableBadges?.current?.length; index++) {
      let IsIncompleted = 0;
      for (let i = 0; i < CompletedBadgeList?.current?.length; i++) {
        if (MyAvailableBadges?.current?.[index]?.BadgeName == CompletedBadgeList?.current?.[i]?.BadgeName) {
          IsIncompleted += 1;
        }
      }
      if (IsIncompleted == 0) {
        InCompleted.push(MyAvailableBadges?.current?.[index])
      }
    }
    return InCompleted;
  });
  const FilterMyBAdgeList = useCallback((FilterValue) => {
    if (FilterValue == "Filter by Badge") {
      let FinalB = IssuedOrAvailable();
      if(CompletedBadgeList?.current&&CompletedBadgeList?.current?.length!=0)
      setShowMyAllBadges([...FinalB, ...CompletedBadgeList?.current])
      else setShowMyAllBadges([...FinalB])
    } else if (FilterValue == "Issued") {
      setShowMyAllBadges([...CompletedBadgeList?.current])
    } else if (FilterValue == "Available") {
      setShowMyAllBadges([...IssuedOrAvailable()])
    }

  }, [],)

  useEffect(() => {
    async function MyBadges() {
      // Assigned all badges
      setValue("isLoadedBadges",true)
      const ActivityBadgeList = await AppsyncDBconnection(listXlmsEnrollUser,{  PK: "TENANT#" + props?.props?.TenantInfo?.TenantID + "#ACTIVITY#ENROLLUSER#" + props?.props?.user?.attributes?.["sub"],  SK: "ACTIVITYID#"},props?.props?.user?.signInUserSession?.accessToken?.jwtToken)
      if (ActivityBadgeList?.res?.listXlmsEnrollUser?.items ) {
        const activityList = (ActivityBadgeList?.res?.listXlmsEnrollUser?.items) ? (ActivityBadgeList?.res?.listXlmsEnrollUser?.items) :[]
        const actBadgeList = [];
        for (var i = 0; i < activityList.length; i++) {
          const BadgeInfo = await AppsyncDBconnection(
            listXlmsActivityManagementInfos,
            {
              PK: "TENANT#" + props?.props?.TenantInfo?.TenantID,
              SK: "ACTIVITYTYPE#" + activityList[i].ActivityType + "#ACTIVITYID#" + activityList[i].ActivityID
            },
            props?.props?.user?.signInUserSession?.accessToken?.jwtToken
          )
    
          if (BadgeInfo?.res?.listXlmsActivityManagementInfos?.items?.[0]) {
            actBadgeList.push(BadgeInfo?.res?.listXlmsActivityManagementInfos?.items?.[0])
          }
        }
        const filteredList = actBadgeList && actBadgeList.filter((data)=>{ return data.BadgeName!= null})
        MyAvailableBadges.current = [...MyAvailableBadges.current, ...filteredList]
      }
    
      const CourseBadgeList = await AppsyncDBconnection(listXlmsCourseEnrollUser,{  PK: "TENANT#" + props?.props?.TenantInfo?.TenantID + "#COURSE#ENROLLUSER#" + props?.props?.user?.attributes?.["sub"],  SK: "COURSE#"},props?.props?.user?.signInUserSession?.accessToken?.jwtToken)
      if (CourseBadgeList?.res?.listXlmsCourseEnrollUser?.items) {
        const courseList = CourseBadgeList?.res?.listXlmsCourseEnrollUser?.items ? CourseBadgeList?.res?.listXlmsCourseEnrollUser?.items :[]
        const CorseBadgeList = [];
        for (var i = 0; i < courseList?.length; i++) {
          const BadgeInfo = await AppsyncDBconnection(
            listXlmsCourseBadgeInfos,
            {
              PK: "TENANT#" + props?.props?.TenantInfo?.TenantID,
              SK: "COURSEBADGE#" + courseList[i]?.CourseID
            },
            props?.props?.user?.signInUserSession?.accessToken?.jwtToken
          )
          if (BadgeInfo?.res?.listXlmsCourseBadgeInfos?.items?.[0]) {
            CorseBadgeList.push(BadgeInfo?.res?.listXlmsCourseBadgeInfos?.items?.[0])
          }
        }
        MyAvailableBadges.current = [...MyAvailableBadges.current, ...CorseBadgeList]

      }
      // Completed Badges
      const BadgesForCompleted = await AppsyncDBconnection(
        listXlmsUserCertificateInfos,
        {
          PK: "TENANT#" + props?.props?.TenantInfo?.TenantID + "#USERSUB#" + props?.props?.user?.attributes?.["sub"],
          SK: "BADGE#"
        },
        props?.props?.user?.signInUserSession?.accessToken?.jwtToken
      )

      CompletedBadgeList.current = BadgesForCompleted?.res?.listXlmsUserCertificateInfos?.items ? BadgesForCompleted?.res?.listXlmsUserCertificateInfos?.items : undefined;

      FilterMyBAdgeList("Filter by Badge")
      setValue("isLoadedBadges",false)
    }
    MyBadges()
    //  completed Badges

  }, [FilterMyBAdgeList, props?.props?.TenantInfo?.TenantID, props?.props?.user?.attributes, props?.props?.user?.signInUserSession?.accessToken?.jwtToken, props.type, setValue])

  return (
    <>
      <Container title="Settings" loader={watch("isLoadedBadges")}>
        <div className="flex justify-end" >
          <NVLSelectField id="ddlBadgeFilter" errors={errors} options={FilterMyBadges} className=" block w-72 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
        </div>
        {ShowMyAllBadges.length ?
        <div className={`grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-4  `}>
          {ShowMyAllBadges &&
            ShowMyAllBadges?.map((getItem, index) => {
              return (
                <>
                  <div key={getItem} className={`text-center relative max-w-sm rounded-lg hover:-translate-y-1 ease-in duration-150 shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] hover:shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] bg-white border-b-4 ${getItem?.IsAvailable?"border-green-500":"border-[#dc3545] opacity-60"} overflow-hidden`}>
                    <div className="w-[150px] h-[150px] absolute top-[-5px] left-[-5px] overflow-hidden">
                      <span className={`text-xs absolute top-[30px] right-0 w-[225px] ${getItem?.IsAvailable ? "bg-green-500" : "bg-[#dc3545]"} text-white text-center shadow-md -rotate-45`}>{getItem?.IsAvailable ? "Completed" : "Incomplete"}</span>
                    </div>
                    <NVLImage alt="Novac Technology logo" className={`!h-28 ${getItem?.IsAvailable ?"w-full":""} `} src={getItem?.CertificateImagePath? getItem?.CertificateImagePath: "/Blank-Badge-PNG.png"} />
                    <div className="bg-gray-200 w-full flex justify-center rounded-b-lg">
                      <NVLlabel text={getItem?.BadgeName} className="nvl-Def-Label py-2" />
                    </div>
                  </div> 
                </>
              );
            })}
        </div>: <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />}
      </Container>
    </>
  );
}
