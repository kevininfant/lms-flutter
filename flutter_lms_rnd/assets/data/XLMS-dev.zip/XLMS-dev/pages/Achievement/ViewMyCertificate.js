import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLImage from "@components/Controls/NVLImage";
import { Auth } from "aws-amplify";
import { APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import * as htmlToImage from 'html-to-image';
import { useRouter } from "next/router";
import 'quill/dist/quill.bubble.css';
import 'quill/dist/quill.snow.css';
import { useEffect, useRef, useState } from "react";
import { updateXlmsUserCertificateInfo } from "src/graphql/mutations";
import { getXlmsUserCertificateInfo } from "src/graphql/queries";

export default function ViewMyCertificate(props) {
    const router = useRouter();
    const tess = useRef();
    const [PageData, setPageData] = useState({});

    useEffect(() => {
        async function getCertData(PageData) {
            let GetCertificate = await fetch(process.env.APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE + "?ObjectUrl=" + PageData?.EditData?.CertificatePath + "&S3BucketName=" + props?.TenantInfo?.BucketName +
                "&S3KeyName=" + props.TenantInfo?.RootFolder + "/" + props?.TenantInfo?.TenantID,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                        defaultrole: props.user.signInUserSession.accessToken.payload["cognito:groups"][0],
                        menuid: "601302",
                        groupmenuname: "SiteConfiguration"
                    },
                }
            );
            let Certificate = await GetCertificate.text();
            Certificate = Certificate.replaceAll('class="panel rounded-md"', 'class="panel"');
            Certificate = Certificate.replaceAll('<div class="top-left"></div><div class="top"></div><div class="top-right"></div><div class="right"></div><div class="right-bottom"></div><div class="bottom"></div><div class="bottom-left"></div><div class="left"></div>', "");
            Certificate = Certificate.replaceAll('class="focus:outline-none rounded border-yellow-600 cursor-pointer"', 'class="rounded"');
            Certificate = Certificate.replaceAll('<i class="fa fa-solid close-icon-pattern fa-minus text-red-600 h-6 w-6 grid place-content-center cursor-pointer rounded-full bg-red-100"></i>', "");
            setPageData((data) => ({ ...data, Loader: false }))

            if (tess.current != undefined) {
                tess.current.innerHTML = Certificate;

                const dataUrl = await htmlToImage.toPng(tess.current);
                const link = document.createElement('a');
                let tempfilename = props?.user?.attributes["sub"] + ".png";
                link.download = tempfilename;
                link.href = dataUrl;
                let file = await urltoFile(dataUrl, tempfilename).then(function (file) {
                    return file;
                })
                let updatedurl = PageData?.EditData?.CertificatePath.split('/').slice(0, -1).join('/') + '/' + link.download;
                let fetchURL = process.env.APIGATEWAY_URL_TO_DOWNLOAD_GENERATED_CERTIFICATE + `?BucketName=${props.TenantInfo?.BucketName}&RootFolder=${props.TenantInfo?.RootFolder}&TenantId=${props.TenantInfo?.TenantID}&CertificateName=${link.download}&CertificatePath=${updatedurl.substring(1)}`;
                const headers = {
                    method: "GET",
                    headers: {
                        authorizationToken: await Auth.currentSession().then((s) =>
                            s.getAccessToken().getJwtToken()
                        ),
                        defaultrole: props.TenantInfo.UserGroup,
                        groupmenuname: "ActivityManagement",
                        menuid: "500002",
                    },
                };
                let presignedHeader = {
                    method: "PUT",
                    headers: {
                        //"x-amz-acl": "public-read",
                        "content-type": "image/png",
                    },
                    body: file,
                };
                let FinalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);
                if (FinalStatus[0] == "Success") {
                    let UrlVariables = {
                        input: {
                            PK: PageData.EditData?.PK,
                            SK: PageData.EditData?.SK,
                            CertificateImagePath: updatedurl
                        },
                    };
                    let FinalStatus = (await AppsyncDBconnection(updateXlmsUserCertificateInfo, UrlVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
                }
            }
        }
        const fetchData = async (i) => {
            let URl_PK = router.query["TenantID"];
            let URl_SK = router.query["SK"];
            let UserSub = props.user.attributes["sub"];
            const CertificateResponse = await AppsyncDBconnection(getXlmsUserCertificateInfo, {
                PK: URl_PK + "#USERSUB#" + (props?.user?.attributes["sub"] != undefined ? props?.user?.attributes["sub"] : ""),
                SK: URl_SK
            }, props?.user.signInUserSession.accessToken.jwtToken);
            const temp = {
                UserSub: UserSub,
                EditData: CertificateResponse?.res?.getXlmsUserCertificateInfo != undefined ? CertificateResponse.res.getXlmsUserCertificateInfo : {},
            }
            setPageData(temp);
            if (temp?.EditData.CertificateImagePath == undefined) {
                getCertData(temp);
            }
        }
        fetchData();
        return (() => {
            setPageData((temp) => { return { ...temp } });
        })
    }, [props.TenantInfo?.BucketName, props.TenantInfo?.RootFolder, props.TenantInfo?.TenantID, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload, router.query]);


    function urltoFile(url, filename, mimeType) {
        mimeType = mimeType || (url.match(/^data:([^;]+);/) || '')[1];
        return (fetch(url)
            .then(function (res) { return res.arrayBuffer(); })
            .then(function (buf) { return new File([buf], filename, { type: mimeType }); })
        );
    }

    const PageRoutes = [
        { path: "/Achievement/AchievementDashBoard", breadcrumb: "Achievement" },
        { path: "", breadcrumb: "View My Certificate" }
    ];
    return (
        <>
            <Container PageRoutes={PageRoutes} loader={PageData?.UserSub == undefined} title="View My Certificate">
                <section className="text-gray-600 body-font px-10 pt-10 flex gap-8 text-xs font-semibold shadow-xl py-4 bg-gray-100 rounded-md ">
                    {PageData?.EditData?.CertificateImagePath == undefined ?
                        <div className={`relative overflow-auto max-w-screen-2xl m-auto`} id="CustomeCert" >
                            <Container loader={PageData?.Loader == undefined} >

                                <div className={` relative h-[600px] ${PageData.EditData?.TemplateType == "Landscape" ? "!w-[850px]" : "w-[600px]"}`} ref={tess} ></div>
                            </Container> </div> :
                        <NVLImage className={`relative flex justify-center lg:w-9/12  sm:flex-row sm:items-center items-start mx-auto shadow-md border-white`} src={PageData.EditData.CertificateImagePath != undefined ? PageData.EditData.CertificateImagePath : ""} alt="Image" title="Image" height={600} width={600} />}
                </section>
                <div className="p-4 rounded w-full mx-auto bg-gray-200 flex justify-center gap-20">
                    <NVLButton text="Back" type={"success"} className="nvl-button bg-primary text-white w-32 h-10 " onClick={() => router.push(`/Achievement/AchievementDashBoard?parameters=${router.query["Tab"]}`)} />
                    <NVLButton text="Print" type={"success"} className="nvl-button bg-primary text-white w-32 h-10 hidden" onClick={window.print} />
                </div>
            </Container>
        </>
    );
}