import Container from "@components/Container/Container";
import NVLCertificateCard from "@components/Controls/NVLCertificateCard";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsActivityManagementInfos, listXlmsCourseBadgeInfos, listXlmsCourseEnrollUser, listXlmsEnrollUser, listXlmsUserCertificateInfos } from "src/graphql/queries";
import * as Yup from "yup";

export default function MyCertificate(props) {
  const router = useRouter();
  const [loadedCertificates, setloadedCertificates] = useState(false);
  const [ShowMyAllCertificate, setShowMyAllCertificate] = useState([]);
  const MyAvailableCertificate = useRef([]);
  const CompletedCertificateList = useRef([]);

  const validationSchema = Yup.object().shape({
    ddlCertificateFilter: Yup.string().test("", "", async (e) => {
      FilterMyCertificateList(e)
    }),
  })

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { formState, register, watch } = useForm(formOptions);
  const { errors } = formState;

  const IssuedOrAvailable = useCallback(() => {
    let InCompleted = [];
    for (let index = 0; index < MyAvailableCertificate?.current?.length; index++) {
      let IsIncompleted = 0;
      for (let i = 0; i < CompletedCertificateList?.current?.length; i++) {
        if (MyAvailableCertificate?.current?.[index]?.CertificateName == CompletedCertificateList?.current?.[i]?.CertificateName) {
          IsIncompleted += 1;
        }
      }
      if (IsIncompleted == 0) {
        InCompleted.push(MyAvailableCertificate?.current?.[index])
      }
    }
    return InCompleted;
  }, []);

  const FilterMyCertificateList = useCallback((FilterValue) => {
    if (FilterValue == "Filter by Certificate") {
      let FinalB = IssuedOrAvailable();
      setShowMyAllCertificate([...FinalB, ...CompletedCertificateList?.current])
    } else if (FilterValue == "Issued") {
      setShowMyAllCertificate([...CompletedCertificateList?.current])
    } else if (FilterValue == "Available") {
      setShowMyAllCertificate([...IssuedOrAvailable()])
    }
  }, [IssuedOrAvailable],)

  useEffect(() => {
    async function MyCertificateData() {
      setloadedCertificates(true)
      const CertificateList = await AppsyncDBconnection(listXlmsCourseEnrollUser, { PK: "TENANT#" + props?.props?.TenantInfo?.TenantID + "#COURSE#ENROLLUSER#" + props?.props?.user?.attributes?.["sub"], SK: "COURSE#" }, props?.props?.user?.signInUserSession?.accessToken?.jwtToken)

      if (CertificateList?.res?.listXlmsCourseEnrollUser?.items) {
        const courseList = CertificateList?.res?.listXlmsCourseEnrollUser?.items ? CertificateList?.res?.listXlmsCourseEnrollUser?.items : []
        let CourseCertificateList = [];
        for (var i = 0; i < courseList.length; i++) {
          const CertificateInfo = await AppsyncDBconnection(listXlmsCourseBadgeInfos, { PK: "TENANT#" + props?.props?.TenantInfo?.TenantID, SK: "COURSECERTIFICATE#" + courseList[i]?.CourseID }, props?.props?.user?.signInUserSession?.accessToken?.jwtToken)
          if (CertificateInfo?.res?.listXlmsCourseBadgeInfos?.items?.[0]) {
            CourseCertificateList.push(CertificateInfo?.res?.listXlmsCourseBadgeInfos?.items?.[0])
          }
        }
        MyAvailableCertificate.current = [...MyAvailableCertificate.current, ...CourseCertificateList]
      }

      const ActivityCertificateList = await AppsyncDBconnection(listXlmsEnrollUser, { PK: "TENANT#" + props?.props?.TenantInfo?.TenantID + "#ACTIVITY#ENROLLUSER#" + props?.props?.user?.attributes?.["sub"], SK: "ACTIVITYID#" }, props?.props?.user?.signInUserSession?.accessToken?.jwtToken)
      if (ActivityCertificateList?.res?.listXlmsEnrollUser?.items) {
        const activityList = (ActivityCertificateList?.res?.listXlmsEnrollUser?.items)
        let actCertificateList = [];
        for (var i = 0; i < activityList.length; i++) {
          const CertificateInfo = await AppsyncDBconnection(
            listXlmsActivityManagementInfos,
            {
              PK: "TENANT#" + props?.props?.TenantInfo?.TenantID,
              SK: "ACTIVITYTYPE#" + activityList[i].ActivityType + "#ACTIVITYID#" + activityList[i].ActivityID
            },
            props?.props?.user?.signInUserSession?.accessToken?.jwtToken
          )

          if (CertificateInfo?.res?.listXlmsActivityManagementInfos?.items?.[0]) {
            actCertificateList.push(CertificateInfo?.res?.listXlmsActivityManagementInfos?.items?.[0])
          }
        }
        let filteredList = actCertificateList && actCertificateList.filter((data) => { return data.CertificateName != null })
        MyAvailableCertificate.current = [...MyAvailableCertificate.current, ...filteredList]
      }

      // Completed Certificate
      const CertificateForCompleted = await AppsyncDBconnection(listXlmsUserCertificateInfos, { PK: "TENANT#" + props?.props?.TenantInfo?.TenantID + "#USERSUB#" + props?.props?.user?.attributes?.["sub"], SK: "CERTIFICATE#" }, props?.props?.user?.signInUserSession?.accessToken?.jwtToken)

      CompletedCertificateList.current = CertificateForCompleted?.res?.listXlmsUserCertificateInfos?.items ? CertificateForCompleted?.res?.listXlmsUserCertificateInfos?.items : undefined;
      FilterMyCertificateList("Filter by Certificate")
      setloadedCertificates(false)
    }
    MyCertificateData()
  }, [FilterMyCertificateList, props?.props?.TenantInfo?.TenantID, props?.props?.user?.attributes, props?.props?.user?.signInUserSession?.accessToken?.jwtToken, props.type])

  const downloadCertificate = useCallback(async (input) => {
    let fetchURL = process.env.APIGATEWAY_INVOKEURL;
    let headers = {
      method: "POST",
      headers: {
        authorizationtoken: props?.props?.user?.signInUserSession?.accessToken?.jwtToken,
        bucketName: props?.props?.TenantInfo?.BucketName,
      },
      body: input.substring(1),
    };
    let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
    var win = window.open(await FinalStatus.res?.text(), '_blank');
  }, [props?.props?.user?.signInUserSession?.accessToken?.jwtToken, props?.props?.TenantInfo?.BucketName])

  let FilterMyCertificates = [
    { value: "Filter by Certificate", text: "Filter by Certificate" },
    { value: "Available", text: "Available" },
    { value: "Issued", text: "Issued" }
  ]


  return (
    <>
      <Container title="Acheivements" loader={loadedCertificates}>
        <div className="flex justify-end" >
          <NVLSelectField id="ddlCertificateFilter" errors={errors} options={FilterMyCertificates} className=" block w-72 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register}></NVLSelectField>
        </div>
        {ShowMyAllCertificate && ShowMyAllCertificate.length != 0 ?
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-4">
            {ShowMyAllCertificate &&
              ShowMyAllCertificate.map((getItem, index) => {
                return (
                  <div key={index} className="shadow-[0_3px_10px_rgb(0,0,0,0.2)]">
                    <NVLCertificateCard indexNo={index} CertificateData={ShowMyAllCertificate} IsAvailable={getItem.PK.includes("USERSUB") ? true : false} type={props.type} imagePath={getItem?.CertificateImagePath != undefined ? (getItem?.CertificateImagePath) : ""} DownloadCertificate={props.type == "Certificate" ? () => downloadCertificate(getItem.CertificateImagePath) : ""}
                    ViewCertificate={props.type == "Certificate" ? () => router.push(`/Achievement/ViewMyCertificate?TenantID=${encodeURIComponent("TENANT#" + props?.props?.TenantInfo?.TenantID)}&Tab=${3}&SK=${encodeURIComponent(getItem.SK)}`) : () => { }} />
                  </div>
                );
              })}
          </div> : ShowMyAllCertificate.length == 0 && <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />
        }
      </Container>
    </>
  );
}