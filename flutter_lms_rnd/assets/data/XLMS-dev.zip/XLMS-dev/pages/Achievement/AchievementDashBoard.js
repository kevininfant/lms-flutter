import Container from "@components/Container/Container";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { listXlmsUserCertificateInfos } from "src/graphql/queries";
import MyBadges from "./MyBadges";
import MyCertificate from "./MyCertificate";

export default function AchievementDashBoard(props) {  
  const router = useRouter();
  const [openTab, setOpenTab] = useState(((PageData?.TabID == undefined || PageData?.TabID == "undefined") ? "2" : PageData.TabID));
  const [PageData, setPageData] = useState({});
  useEffect(() => {
    const fetchData = async (i) => {
      let queryParam = router.query["parameters"];
      let UserSub = props.user.attributes["sub"];
      let TenantID = props.user.attributes["custom:tenantid"];
      const certificateList = await AppsyncDBconnection(
        listXlmsUserCertificateInfos,
        {
          PK: "TENANT#" + TenantID + "#USERSUB#" + UserSub,
          SK: "CERTIFICATE#"
        },
        props?.user?.signInUserSession?.accessToken?.jwtToken
      );
      const temp = {
        TenantId: TenantID,
        CertificateList: certificateList?.res?.listXlmsUserCertificateInfos?.items,
        TabID: queryParam
      }
      setPageData(temp);
      setOpenTab(queryParam);
    }
    fetchData();
    return (() => {
      setPageData((temp) => { return { ...temp } });
      setOpenTab("2");
    })
  }, [ props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

  // Bread Crumbs
  const PageRoutes = [{ path: "", breadcrumb: "Achievements" }];
  return (
    <>
      <Container PageRoutes={PageRoutes} loader={PageData?.TenantId == undefined} title="Achievement DashBoard">
        <div className="flex flex-wrap ">
          <div className="w-full">
            <ul className="grid sm:flex gap-4 sm:gap-0 justify-items-center justify-between" role="tablist">
              <div className="flex  sm:gap-4 p-2">
                <li className=" text-center">
                  {/* <a
                    className={"text-xs  sm:px-2 py-1 block leading-normal " + (openTab === "1" ? "text-primary font-semibold border-b-2 border-primary " : " bg-white ")}
                    onClick={(e) => {
                      e.preventDefault();
                      setOpenTab("1");
                    }}
                    data-toggle="tab" href="#link1" role="tablist">
                    Leaderboard
                  </a> */}
                </li>
                <li className=" text-center">
                  <a className={"text-xs  px-2 py-1 block leading-normal " + ((openTab === "2"||openTab === undefined) ? "text-primary font-semibold border-b-2 border-primary " : " bg-white ")}
                    onClick={(e) => {
                      e.preventDefault();
                      setOpenTab("2");                    
                    }} data-toggle="tab" href="#link1" role="tablist">
                    Badges
                  </a>
                </li>
                <li className=" text-center">
                  <a
                    className={"text-xs px-2 py-1 block leading-normal " + ((openTab === "3") ? "text-primary font-semibold border-b-2 border-primary " : " bg-white ")}
                    onClick={(e) => {
                      e.preventDefault();
                      setOpenTab("3");
                    }}
                    data-toggle="tab" href="#link2" role="tablist">
                    My Certificate
                  </a>
                </li>
              </div>

            </ul>
            <div className="flex-auto text-xs">
              <div className="tab-content tab-space ">
                {/* <div className={openTab === "1" ? "block " : "hidden "} id="link1">
                  Leaderboard
                </div> */}
                <div className={(openTab === "2"||openTab === undefined) ? "block " : "hidden "} id="link1">
                  <MyBadges props={props} type={"Badge"} Tab ={openTab}/>
                </div>
                <div className={(openTab === "3") ? "block" : "hidden"} id="link2">        
                  <MyCertificate props={props} type={"Certificate"} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>
    </>
  );
}
