import Container from "@components/Container/Container";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { useState } from "react";
import "react-calendar/dist/Calendar.css";
import AddEventCalender from "./DashboardEvents/AddEventCalender";
import LearningOverview from './DashboardEvents/LearningOverview';
import LiveUserFeatureAndActivity from './DashboardEvents/LiveUserFeatureAndActivity';
import LiveUserGraph from "./DashboardEvents/LiveUserGraph";
import MostVisitedCourses from "./DashboardEvents/MostVisitedCourses";
import TodayEventAndActivities from "./DashboardEvents/TodayEventAndActivities";

export default function AdminDashboard(props) {
  Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);
  
  const [ChangedDate, setChangedDate] = useState(new Date());
  // Bread Crumbs
  const PageRoutes = [ { path: "", breadcrumb: "Company Admin Dashboard" }];
  return (
    <>
      <Container title="Company Dashboard" PageRoutes={PageRoutes}>
        <div className="md:grid xl:grid-cols-3 space-y-2 md:space-y-0">
          <div className="lg:col-span-2 gap-4 space-y-2">
            <div className="grid lg:grid-flow-col gap-4 md:mb-4">
            <LiveUserGraph props={props}  AuthRole="CompanyAdmin"/>
            <LearningOverview props={props} />
            </div>
            <LiveUserFeatureAndActivity props={props}/>
          </div>
          <div className="lg:mx-4 space-y-4 ">
            <AddEventCalender setChangedDate={setChangedDate} ChangedDate={ChangedDate}  />
            <TodayEventAndActivities props={props} ChangedDate={ChangedDate} />    
          </div>
        </div>
         <MostVisitedCourses props={props} />
      </Container>
    </>
  );
}