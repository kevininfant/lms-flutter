import Container from '@components/Container/Container';
import NVLAlert, { ModalClose, ModalOpen } from '@components/Controls/NVLAlert';
import NVLButton from '@components/Controls/NVLButton';
import NVLGridTable from '@components/Controls/NVLGridTable';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLSelectField from '@components/Controls/NVLSelectField';
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayPostRequest, AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { createXlmsSelfEnrollUserBatch } from 'src/graphql/mutations';
import { listXlmsCategoryWiseCourseInfos, listXlmsCourseBatchInfos, listXlmsCourseCategory, listXlmsSelfEnrollUserInfos } from 'src/graphql/queries';
import * as Yup from "yup";

function CourseApproval(props) {
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [ApprovalData, setApprovalData] = useState({ Course: [], Batch: [], category: "", CategoryListData: [] })
  let CourseApprovalSelect = useRef();
  let CatApprovalSelect = useRef();
  let BatchApprovalSelect = useRef();

  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Course Nomination has been approved.",
  };
  const [modalValues, setModalValues] = useState(initialModalState);
  useEffect(() => {
    if (document.getElementById("ddlApproval") != undefined || document.getElementById("ddlApproval") != null) {
      document.getElementById("ddlApproval").value = "CourseApproval";
    }
    async function FetchData() {
      let category = await AppsyncDBconnection(listXlmsCourseCategory, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSECATEGORY#", IsDeleted: false }, props.user?.signInUserSession?.accessToken?.jwtToken);
      let CategoryData = category.res?.listXlmsCourseCategory?.items != undefined ? category.res?.listXlmsCourseCategory.items : [];
      setApprovalData((data) => { return { ...data, CategoryListData: CategoryData } })
    }
    FetchData()
    return (() => {
      setApprovalData((temp) => { return { ...temp } })
    })
  }, [CategoryList, props.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken])

  const refreshGrid = async () => {
    setIsRefreshing((count) => {
      return count + 1;
    });
  };

  const CategoryList = useMemo(() => {
    let List = [{ value: "", text: "Select" }]
    if (ApprovalData?.CategoryListData?.length != 0) {
      let CategoryFiltered = ApprovalData?.CategoryListData && ApprovalData?.CategoryListData?.filter((obj) => !List[obj.CategoryID] && (List[obj.CategoryID] = true));
      CategoryFiltered && CategoryFiltered?.map((category) => { List.push({ value: category?.CategoryID, text: category?.CategoryName, }) });
    }
    return List;
  }, [ApprovalData?.CategoryListData])

  const CourseList = useMemo(() => {
    let List = [{ value: "", text: "Select" }]
    ApprovalData.Course?.map((course) => { List.push({ value: course?.CourseID, text: course?.CourseName }) });
    return List;
  }, [ApprovalData.Course])

  const BatchList = useMemo(() => {
    let List = [{ value: "", text: "Select" }]
    ApprovalData.Batch?.map((batch) => { List.push({ value: batch?.BatchID, text: batch?.BatchName }) })
    return List;
  }, [ApprovalData.Batch])

  const validationSchema = Yup.object().shape({
    ddlCategory: Yup.string().test("", "", async (e) => {
      if (e != ApprovalData.category) {
        setApprovalData((data) => { return { ...data, category: e } })
        reset({ ddlCourse: "", ddlBatch: "" })
      }
      if (CatApprovalSelect.current != e) {
        CatApprovalSelect.current = e;
        let CourseData = await AppsyncDBconnection(listXlmsCategoryWiseCourseInfos, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#", CategoryID: e },
          props.user?.signInUserSession?.accessToken?.jwtToken);
        const CourseDt = CourseData.res?.listXlmsCategoryWiseCourseInfos?.items != undefined ? CourseData.res?.listXlmsCategoryWiseCourseInfos?.items : []
        setApprovalData((data) => { return { ...data, Course: CourseDt } })
        //ApprovedCourse()
      }
    }).nullable(),

    ddlCourse: Yup.string().test("", "", async (e) => {
      if (CourseApprovalSelect.current != e) {
        CourseApprovalSelect.current = e;
        setValue("ddlBatch", "")
        let Batchlist = await AppsyncDBconnection(
          listXlmsCourseBatchInfos,
          {
            PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + e,
            SK: "COURSEBATCH#", IsDeleted: false
          },
          props.user?.signInUserSession?.accessToken?.jwtToken
        );
        const BatchData = Batchlist.res?.listXlmsCourseBatchInfos?.items != undefined ? Batchlist.res?.listXlmsCourseBatchInfos?.items : []
        setApprovalData((data) => { return { ...data, Batch: BatchData } })
        ApprovedCourse()
        setIsRefreshing(false);
      }
      return true;
    })
      .nullable(),
    ddlBatch: Yup.string().test("", "", async (e) => {
      if (BatchApprovalSelect.current != e && e != "") {
        BatchApprovalSelect.current = e;
        ApprovedCourse()
        setIsRefreshing(false);
      }

    })
      .nullable()
  })
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
  const { errors } = formState;
  const HeaderColumn = [
    { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-3/12", },
    { HeaderName: "Email ID", Columnvalue: "EmailID", HeaderCss: "w-0/12", },
    { HeaderName: "Approval Status", Columnvalue: "Status", HeaderCss: "w-0/12" },
  ]

  const FinalResponse = useCallback((FinalStatus, UserStatus) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
        ModalOnClickEvent: () => { ModalClose() }
      });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Success",
        ModalTopMessage: FinalStatus,
        ModalBottomMessage: UserStatus == "Accept" ? "Course Nomination has been approved ." : "Course Nomination has been rejected.",
        ModalOnClickEvent: () => { ModalClose() }
      });
      ModalOpen();
    }
  }, [])
  const ApprovedCourse = useCallback((Parms) => {

    async function getApprovedUser() {
      let Approveddata = await AppsyncDBconnection(listXlmsSelfEnrollUserInfos, {
        PK: "TENANT#" + props?.TenantInfo.TenantID,
        SK: "SELFENROLLUSER#COURSE#" + watch("ddlCourse") + "#BATCH#" + watch("ddlBatch"), StatusFlag: "Approved"
      }, props.user?.signInUserSession?.accessToken?.jwtToken)
      let DataApproval = Approveddata.res?.listXlmsSelfEnrollUserInfos?.items?.length
      setValue("ApprovedUserCount", DataApproval)
    }
    getApprovedUser()
  }, [props?.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, setValue, watch])

  const ApproveUser = useCallback(async (user) => {
    let fetchURL = process.env.APIGATEWAY_URL_COURSE_ENROLLUSER;
    const FinalData = [];
    FinalData.push({
      UserSub: user.UserSub,
      EmailID: user.EmailID,
      UserName: user.UserName,
      BatchID: user.BatchID,
      CourseID: user.CourseID,
    });

    let JsonInputData = '{ "Type":"Self","TenantID":"' + props?.TenantInfo.TenantID + '","CourseName":"' + user.CourseName + '","UserDetails":' + JSON.stringify(FinalData) + "}"

    let Headers = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: "CourseManagement",
        menuid: "300201",
        stateMachineArn: process.env.STEP_FUNCTION_ARN_COURSE_ENROLLUSER,
      },
      body: JsonInputData,
    };
    let FinalStatus = await APIGatewayPostRequest(fetchURL, Headers);

    if (FinalStatus.Status == "Success") {
      let Variables = {
        input: {
          PK: user.PK,
          SK: user.SK,
          StatusFlag: "Approved",
          LastModifiedBy: Auth?.user?.username,
          LastModifiedDate: new Date()
        }
      }
      let Update = await AppsyncDBconnection(createXlmsSelfEnrollUserBatch, Variables, props.user?.signInUserSession?.accessToken?.jwtToken)

      if (Update.Status == "Success") {
        let MailStatus;
        let MailUrl = process.env.APIGATEWAY_COURSE_APPROVAL_NOTIFICATION;

        let JsonSaveData = '{"TenantID":  "' + props?.TenantInfo.TenantID + '","UserSub": "' + user.UserSub + '", "CourseID": "' + user.CourseID + '"}';
        let Headers = {
          method: "POST",
          headers: {
            authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
            groupmenuname: "DashBoard",
            menuid: "122201",
          },
          body: JsonSaveData,
        };
        MailStatus = await APIGatewayPostRequest(MailUrl, Headers);
      }
      ApprovedCourse()
      refreshGrid()
      FinalResponse(Update.Status, "Accept");
    }
  }, [ApprovedCourse, FinalResponse, props.TenantInfo.TenantID, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken])

  const RejectUser = useCallback(async (user) => {
    let Variables = {
      input: {
        PK: user.PK,
        SK: user.SK,
        StatusFlag: "Rejected",
        LastModifiedBy: Auth?.user?.username,
        LastModifiedDate: new Date()
      }
    }
    let Update = await AppsyncDBconnection(createXlmsSelfEnrollUserBatch, Variables, props.user?.signInUserSession?.accessToken?.jwtToken)

    if (Update.Status == "Success") {
      let MailStatus;
      let MailUrl = process.env.APIGATEWAY_COURSE_APPROVAL_NOTIFICATION;

      let JsonSaveData = '{"TenantID":  "' + props?.TenantInfo.TenantID + '","UserSub": "' + user.UserSub + '", "CourseID": "' + user.CourseID + '"}';
      let Headers = {
        method: "POST",
        headers: {
          authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
          groupmenuname: "DashBoard",
          menuid: "122202",
        },
        body: JsonSaveData,
      };
      MailStatus = await APIGatewayPostRequest(MailUrl, Headers);
    }
    refreshGrid()
    FinalResponse(Update.Status, "Reject")
  }, [FinalResponse, props?.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken])

  const GridDataBind = useCallback((viewData) => {
    setValue("EnrollUserCount", viewData?.length)
    const RowGrid = [];
    viewData?.map((getItem, index) => {
      RowGrid.push({
        UserName: (<NVLlabel id={"lblName" + (index + 1)} name="PK" text={getItem.UserName} className="p-2" />),
        EmailID: (<NVLlabel id={"lblEmail" + (index + 1)} name="PK" text={getItem.EmailID} />),
        Status: (<>
          <div className="flex">
            <NVLButton id={"txtApprove" + (index + 1)} text={"Approve"} className="pr-4  hover:text-teal-600" onClick={() => ApproveUser(getItem)} />
            <NVLButton id={"txtCourseName" + (index + 1)} text={"Reject"} className="pr-4  hover:text-teal-600" onClick={() => RejectUser(getItem)} />
          </div>
        </>),
      })
    })
    return RowGrid;
  }, [ApproveUser, RejectUser, setValue]
  );
  const variable = useMemo(() => {
    if (!isRefreshing)
      setIsRefreshing(true);
    return {
      PK: "TENANT#" + props.TenantInfo.TenantID,
      SK: "SELFENROLLUSER#COURSE#" + watch("ddlCourse") + "#BATCH#" + watch("ddlBatch"),
      StatusFlag: "Pending"
    }
  }, [props.TenantInfo.TenantID, watch, isRefreshing]);
  // Bread Crumbs
  const PageRoutes = useMemo(() => { return [{ path: "", breadcrumb: "Approval Request" }] }, []);

  return (
    <>
      <Container title="CourseApproval" loader={ApprovalData == undefined} PageRoutes={PageRoutes}>
        <NVLAlert
          ButtonYestext={"X"}
          MessageTop={modalValues.ModalTopMessage}
          MessageBottom={modalValues.ModalBottomMessage}
          ModalOnClick={modalValues.ModalOnClickEvent}
          ModalInfo={modalValues.ModalInfo}
        />
        <div className=" mx-auto grid gap-8 md:w-[500px] w-full">
          <div className="flex flex-col sm:flex-row  gap-4">
            <NVLlabel text="Course Category " className="nvl-Def-Label pt-2" />
            <NVLSelectField id="ddlCategory" errors={errors} register={register} options={CategoryList} className={`w-64 md:w-72`} />
          </div>
          <div className="flex flex-col sm:flex-row  gap-9">
            <NVLlabel text="Course Name" className="nvl-Def-Label pt-2" />
            <NVLSelectField disabled={watch("ddlCategory") == "" ? true : false} id="ddlCourse" errors={errors} register={register} options={CourseList} className={`w-64 md:w-72 `} />
          </div>
          <div className="flex flex-col sm:flex-row  gap-11">
            <NVLlabel text="Batch Name" className="nvl-Def-Label pt-2" />
            <NVLSelectField disabled={watch("ddlCourse") == "" ? true : false} id="ddlBatch" errors={errors} register={register} options={BatchList} className={`w-64 md:w-72`} />
          </div>
          <div className={`flex justify-between w-96 bg-red `}>
            <NVLlabel text={`Enrolled Users : `} className="nvl-Def-Label pt-2" />
            <span className=" bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
              {watch("EnrollUserCount") == undefined ? "0" : watch("EnrollUserCount")}</span>
            <NVLlabel text={`Approved Users : `} className="nvl-Def-Label pt-2" />
            <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
              {watch("ApprovedUserCount") == undefined ? "0" : watch("ApprovedUserCount")}</span>
          </div>
        </div>
        <div className="pt-4">
          <NVLGridTable
            refershPage={isRefreshing}
            // Search={Search}
            id="tblSelfEnroll"
            className="max-w-full"
            HeaderColumn={HeaderColumn}
            GridDataBind={GridDataBind}
            query={listXlmsSelfEnrollUserInfos}
            querryName={"listXlmsSelfEnrollUserInfos"}
            variable={variable}
            user={props?.user}
          />
        </div>
      </Container>
    </>
  )
}

export default CourseApproval;

