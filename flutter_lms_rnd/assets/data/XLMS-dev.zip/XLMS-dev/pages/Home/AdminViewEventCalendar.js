import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingIndicator from "@components/Controls/NVLLoadingIndicator";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { updateXlmsMyScheduleEvent } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { FaTemperatureHigh } from "react-icons/fa";
import { Regex } from "RegularExpression/Regex";
import { listXlmsActivityManagementInfos, listXlmsCourseManagementInfo, listXlmsMyScheduleEvent } from "src/graphql/queries";
import * as Yup from "yup";
import TodayEventCard from "./DashboardEvents/TodayEventCard";

const TuiCalendar = dynamic(() => import("@components/Controls/NVLCalander"), {
  ssr: false,
});

const CalendarComponent = React.forwardRef((props, ref) => (
  <TuiCalendar
    {...props}
    forwardedRef={ref}
  />
));

CalendarComponent.displayName = "CalendarComponent";

export default function AdminViewEventCalendar(props) {

  const router = useRouter()
  const [RowGridData, setRowGridData] = useState([]);
  const [PropsList, setPropsList] = useState({})
  const [isLoading, setisLoading] = useState(true)
  const [DailyDate, setDailyDate] = useState(new Date()?.toLocaleString('en-US', {
    weekday: "short",
    month: "short",
    day: "numeric",
    year: "numeric",
  }))
 
  const [deletedEvent, setDeleteEvent] = useState("Upload");
  const validationSchema = Yup.object().shape({
    txtEventTitle: Yup.string()
      .required("Event Title")
      .matches(Regex("AlphabetsAndSpaceOnly"), "Invalid Event Title"),
    txtCourse: Yup.string()
      .required("Course Name")
      .matches(Regex("AlphabetsAndSpaceOnly"), "Invalid Course Name"),
    ddlFilter: Yup.string().test("", "", (e) => {
      handleReload();
      setEvent(e);
      addDays(DailyDate, 0, "initial")
      GridDataBind(PropsList);
      getCalInstance()?.today();
      if (e != "day")
        getMonth();
    }),
  });
  const [open, setOpen] = useState(0);
  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };

  const { register, watch, formState, setValue } =
    useForm(formOptions);
  const { errors } = formState;
 
  useEffect(() => {
    async function CalendarData() {
      let Root = decodeURIComponent(router.query["Root"]);
      let TenantName = props.user.attributes["name"];
      let TenantID = props.user.attributes["custom:tenantid"];
      let UserSub = props.user.attributes["sub"];

      let Batchlist = [], Courselist = [], scheduleData = [];

      const Courseresponse = await AppsyncDBconnection(
        listXlmsCourseManagementInfo,
        {
          PK: "TENANT#" + TenantID,
          SK: "COURSEINFO#",
        }, props.user.signInUserSession.accessToken.jwtToken
      );

      const Activityresponse = await AppsyncDBconnection(
        listXlmsActivityManagementInfos,
        {
          PK: "TENANT#" + TenantID,
          SK: "ACTIVITYTYPE#",
        }, props.user.signInUserSession.accessToken.jwtToken
      );
      let Activitylist = Activityresponse && Activityresponse?.res?.listXlmsActivityManagementInfos?.items;
      // Added new events
      const eventResponse = await AppsyncDBconnection(
        listXlmsMyScheduleEvent,
        {
          PK: "TENANT#" + TenantID,
          SK: "USERSUB#" + UserSub + "#EVENT#",
          IsDeleted: false
        }, props.user.signInUserSession.accessToken.jwtToken
      );
      eventResponse && eventResponse?.res?.listXlmsMyScheduleEvent?.items?.map((event, idx) => {
        scheduleData.push({ ...JSON.parse(event?.EventDetails), CourseID: event?.CourseID, GroupID: event?.GroupID })
      })
      setPropsList({
        RootMode: Root,
        ActivityData: Activitylist,
        CourseData: Courseresponse?.res?.listXlmsCourseManagementInfo?.items,
        BatchData: Batchlist,
        eventData: scheduleData
      })
    }
    CalendarData()
    return (() => {
      setPropsList((data) => {
        return data;
      })
    })
  }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const GridDataBind = useCallback((PropsList) => {
    function getIsoTimeFormat(originalTimestamp) {
      if (originalTimestamp) {
        const originalDate = new Date(originalTimestamp);
        originalDate.setDate(originalDate.getDate() + 1);
        const adjustedTimestamp = originalDate.toISOString()
        return adjustedTimestamp?.slice(0, 11) + "00:00"
      }
    }

    setTimeout(() => {
      const ActivityArr = [], CourseArr = [], EventsArr = [], RowGrid = [];
      if (PropsList?.ActivityData) {
        PropsList?.ActivityData?.map((getItem) => {
          (getItem.StartDate != null && getItem.StartDate != "NaN-NaN-NaNTNaN:NaN" && getItem.StartDate != "") ?
            new Date(getItem.StartDate)?.toDateString() != new Date(getItem.EndDate)?.toDateString() && (getItem.EndDate && getItem.EndDate != "") ?
              ActivityArr.push(
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                  category: "time",
                  isVisible: true,
                  title: getItem.ActivityName,
                  id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                  body: getItem.ActivityDescription,
                  start: getItem.StartDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: "",
                  isReadOnly: true,
                  backgroundColor: "#e85d04",
                },
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                  category: "time",
                  isVisible: true,
                  title: getItem.ActivityName,
                  id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                  body: getItem.ActivityDescription,
                  start: !getItem.EndDate?.includes("T00:00:00.000Z") ? getItem.EndDate?.toString() : getItem.EndDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: "",
                  isReadOnly: true,
                  backgroundColor: "#e85d04",
                })
              :
              ActivityArr.push(
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.StartDate + "$" + getItem.EndDate,
                  category: "time",
                  isVisible: true,
                  title: getItem.ActivityName,
                  id: getItem.ActivityID + "#" + getItem.ActivityType + "#ActStart",
                  body: getItem.ActivityDescription,
                  start: getItem.StartDate?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: null,
                  isReadOnly: true,
                  backgroundColor: "#e85d04",
                }
              )

            : "";
        });
      }

      function getCourseDescription(courseID) {
        let description;
        PropsList.CourseData?.map((item) => {
          if (item?.CourseID == courseID) {
            description = item.CourseDescription;
          }
        })
        return description
      }
      // course binded
      if (PropsList?.CourseData) {
        PropsList?.CourseData?.map((getItem) => {
          (getItem?.DateTime != null && getItem?.DateTime != "NaN-NaN-NaNTNaN:NaN" && getItem?.DateTime != "") ?
            new Date(getItem.DateTime)?.toDateString() != new Date(getItem.EndDateTime)?.toDateString() && (getItem.EndDateTime && getItem.EndDateTime != "") ?
              CourseArr.push({
                calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getIsoTimeFormat(getItem.EndDateTime),
                category: "time",
                isVisible: true,
                title: getItem.CourseName,
                id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
                body: getCourseDescription(getItem.CourseID),
                start: new Date(getItem.DateTime)?.toISOString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                end: "",
                isReadOnly: true,
                backgroundColor: "#00b4d8",
              }, {
                calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getIsoTimeFormat(getItem.EndDateTime),
                category: "time",
                isVisible: true,
                title: getItem.CourseName,
                id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
                body: getCourseDescription(getItem.CourseID),
                start: getIsoTimeFormat(getItem.EndDateTime),
                end: "",
                isReadOnly: true,
                backgroundColor: "#00b4d8",
              })
              :
              CourseArr.push(
                {
                  calendarId: crypto.randomUUID() + "$" + getItem.DateTime + "$" + getIsoTimeFormat(getItem.EndDateTime),
                  category: "time",
                  isVisible: true,
                  title: getItem.CourseName,
                  id: getItem.CourseID + "#Course#" + getItem.BatchID + "#Start",
                  body: getCourseDescription(getItem.CourseID),
                  start: new Date(getItem.DateTime)?.toISOString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
                  end: "",
                  isReadOnly: true,
                  backgroundColor: "#00b4d8",
                }
              )
            : "";
        });
      }
      PropsList.eventData?.map((getItem) => {
        new Date(getItem.start)?.toDateString() != new Date(getItem.end)?.toDateString() && (getItem.end && getItem.end != "") ?
          EventsArr.push(
            {
              calendarId: crypto.randomUUID() + "$" + getItem.start + "$" + getItem.end + "$" + getItem?.eventType,
              category: "time",
              isVisible: true,
              title: getItem.title,
              id: getItem?.id,
              body: getItem.body,
              start: getItem.start?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
              end: "",
              isReadOnly: true,
              state: getItem.StartDate,
              backgroundColor: "#9AC5F4",
              raw: getItem?.EndDate
            }
            , {
              calendarId: crypto.randomUUID() + "$" + getItem.start + "$" + getItem.end + "$" + getItem?.eventType,
              category: "time",
              isVisible: true,
              title: getItem.title,
              id: getItem?.id,
              body: getItem.body,
              start: getItem.end?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
              end: "",
              isReadOnly: true,
              state: getItem.StartDate,
              backgroundColor: "#9AC5F4",
              raw: getItem?.EndDate
            }
          ) : EventsArr.push({
            calendarId: crypto.randomUUID() + "$" + getItem.start + "$" + getItem.end + "$" + getItem?.eventType,
            category: "time",
            isVisible: true,
            title: getItem.title,
            id: getItem?.id,
            body: getItem.body,
            start: getItem.start?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
            end: "",
            isReadOnly: true,
            state: getItem.StartDate,
            backgroundColor: "#9AC5F4",
            raw: getItem?.EndDate
          })
      })

      RowGrid = ActivityArr.concat(CourseArr, EventsArr)
      setRowGridData({ RowGrid });
      setisLoading(false)
    }, 1000);
  }, []);

  useEffect(() => {
    GridDataBind(PropsList);
  }, [GridDataBind, PropsList]);

  const getEvents = useMemo(() => {
    return [
      { value: "month", text: "Monthly" },
      { value: "week", text: "Weekly" },
      { value: "day", text: "Daily" }
    ]
  }, []);

  const cal = useRef(null);
  const month = useRef(null);
  const getCalInstance = useCallback(() => cal.current?.getInstance?.(), []);

  const getMonth = () => {
    let theDate = getCalInstance()?.getDate()?.d?.d;
    let date = theDate?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
    });
    month.current.innerHTML = date;
  };

  const [viewEvent, setEvent] = useState("month");

  const data = useRef({ id: "", body: "", title: "", start: "", calendarId: "", end: "" })

  const getCoursedata = useCallback((e) => {
    const courseData = PropsList.CourseData?.filter((item) => {
      return e.event.id?.split("#")?.[0] == item?.CourseID
    })
    return courseData?.[0];
  }, [PropsList.CourseData])

  const onClickSchedule = useCallback((e, type) => {
    getCalInstance()?.clearGridSelections();
    if (e.event?.id?.split("#")?.[1] == "Course") {
      const getCourseDetails = getCoursedata(e);
      if (getCourseDetails) {
        data.current = {
          ...data,
          id: e?.event?.id,
          type: "Course",
          body: getCourseDetails?.CourseDescription,
          title: getCourseDetails?.CourseName,
          start: e?.event?.calendarId?.split("$")?.[1],
          end: e?.event?.calendarId?.split("$")?.[2],
          calendarId: e?.event?.calendarId,
        }
      }
    }
    if (e.event?.id?.split("#")?.[2] == "ActStart") {

      data.current = {
        ...data,
        id: e?.event?.id,
        type: "Activity",
        body: e?.event?.body,
        title: e?.event?.title,
        start: e?.event?.calendarId?.split("$")?.[1],
        end: e?.event?.calendarId?.split("$")?.[2],
        calendarId: e?.event?.calendarId
      }
    }
    else if (e.event?.id?.split("#")?.[1] != "Course") {
      if (type == "Daily") {
        data.current = {
          ...data,
          id: e?.id,
          type: e?.eventType,
          body: e?.body,
          title: e?.title,
          start: e?.start,
          end: e?.end,
          calendarId: crypto.randomUUID() + "$" + e.start + "$" + e.end
        }
      } else {
        data.current = {
          ...data,
          id: e?.event?.id,
          type: e?.event?.calendarId?.split("$")?.[3],
          body: e?.event?.body,
          title: e?.event?.title,
          start: e?.event?.calendarId?.split("$")?.[1]?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
          end: e?.event?.calendarId?.split("$")?.[2]?.toString()?.split("Z")?.[0]?.slice(0, 16)?.replace("00:00", "00:00"),
          calendarId: e?.event?.calendarId
        }
      }
    }
    setOpen((open) => {
      return open + 1;
    });
  }, [data, getCoursedata, getCalInstance]);

  useEffect(() => {

    if (open) {
      if (data.current?.id?.includes("EVENT#")) {
        description.current.innerHTML = `<div class='text-sm font-semibold !w-full break-all'>Description:</div><div class="text-xs ">${data.current.body}</div>`;
      } else {
        if (description.current != undefined && data.current?.body != "" && data.current?.body != undefined) {
          description.current.innerHTML = "<div class='text-sm font-semibold w-full break-words'>Description:</div>" + data.current.body;
        } else if (data.current?.body == "" && description.current != undefined) {
          description.current.innerHTML = "";
        }
      }
    }
    setDeleteEvent("Upload")

  }, [open])
  // Bread Crumbs
  let PageRoutes = [];
  if (PropsList?.RootMode == "DashEvent") {
    PageRoutes = [{ path: "/Home/UserDashboard", breadcrumb: "User Dashboard" }, { path: "", breadcrumb: "My Schedule" }];
  } else {
    PageRoutes = [{ path: "", breadcrumb: "My Schedule" }];
  }
  const onBeforeDeleteSchedule = useCallback((res) => {
    const { id, calendarId } = res.schedule;

    cal.current.calendarInst.deleteSchedule(id, calendarId);
  }, []);

  const [calendarKey, setCalendarKey] = useState(0);
  const handleReload = () => {
    setCalendarKey((prevKey) => prevKey + 1);
  };
  const deleteEvent = useCallback(async () => {
setValue("IsDeleted",true)
    const eventInfo = "";
    const userSub = props.user.attributes["sub"];
    eventInfo = ({ PK: "TENANT#" + props.TenantInfo.TenantID, SK: "USERSUB#" + userSub + "#EVENT#" + data?.current.id?.split("#")?.[1], IsDeleted: true });
    const variables = {
      input: eventInfo
    };
    const finalResult = await AppsyncDBconnection(updateXlmsMyScheduleEvent, variables, props?.user?.signInUserSession.accessToken?.jwtToken);

    if (finalResult?.Status == "Success" && props?.TenantInfo?.UserGroup == "CompanyAdmin" && data?.current?.type != "MyEvent") {
      let deletedData = finalResult?.res?.updateXlmsMyScheduleEvent;
      let fetchURL = process.env.ADD_EVENT_BASED_ON_GROUP_COURSE_API, stateMachineArn = process.env.STEP_FUNCTION_ARN_ADD_EVENT;
      let eventInfo = {
        EventID: deletedData?.EventID,
        CreatedBy: deletedData?.CreatedBy,
        ModifiedBy: deletedData?.ModifiedBy,
        ModifiedDate: new Date(),
        CreatedDate: deletedData?.CreatedDate,
        IsEndDateEnable: deletedData?.IsEndDateEnable,
        Title: JSON.parse(deletedData?.EventDetails)?.title,
        Start: JSON.parse(deletedData?.EventDetails)?.start,
        EventType: JSON.parse(deletedData?.EventDetails)?.eventType,
        End: JSON.parse(deletedData?.EventDetails)?.end,
        Category: JSON.parse(deletedData?.EventDetails)?.category,
        Body: JSON.parse(deletedData?.EventDetails)?.body,
        CourseID: deletedData?.CourseID,
        GroupID: deletedData?.GroupID,
        TenantID: props?.TenantInfo?.TenantID,
        IsDeleted: true
      }
      let headers = {
        method: "POST",
        headers: {
          authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
          defaultrole: props?.TenantInfo?.UserGroup,
          groupmenuname: "UserManagement",
          menuid: "200104",
          statemachinearn: stateMachineArn,
        },
        body: JSON?.stringify(eventInfo),
      };
      let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
    }
    if (finalResult?.Status == "Success") {
      setPropsList((prev) => {
        let arrEvent = prev?.eventData;
        const removeData = arrEvent?.filter(item => item.id != data?.current.id);
        return {
          RootMode: prev?.RootMode,
          ActivityData: prev?.ActivityData,
          CourseData: prev?.CourseData,
          BatchData: prev?.BatchData,
          eventData: removeData
        }
      })
      handleReload();
    }
    setValue("IsDeleted",false)
    setOpen(false);
    setValue("ddlFilter", watch("ddlFilter"));
  }, [props.user.attributes, props.user?.signInUserSession.accessToken?.jwtToken, props.TenantInfo.TenantID, props.TenantInfo?.UserGroup, setValue, watch])


  const description = useRef(null);
  const EventDescription = useCallback(({ type }) => {
    return (
      <><div className="break-words py-2" ref={description}> </div> </>
    );
  }, []);

  const GetComponent = useCallback((PopupName) => {
    if (data.current?.id != "") {
      let ComponentData = {
        Upload:
          <div className={`flex gap-2 ${watch("IsDeleted") ? "pointer-events-none" : ""}`}>
            <div className="">
              <div className="flex gap-2 ">
                <NVLlabel text={`Type :`} className="font-semibold" />
                <NVLlabel text={`${data.current?.type}`} />
              </div>
              <div className="flex gap-3">
                <NVLlabel text={`Date:`} className="font-semibold" />
                <NVLlabel text={`${((new Date(data.current?.start)?.toISOString()?.includes("00:00:00.000") || data.current?.type == "Course")) && !data.current?.id?.includes("EVENT#") ?
                  new Date(data.current?.start)?.toLocaleString('en-US', {
                    weekday: "short",
                    month: "short",
                    day: "numeric", 
                    year: "numeric",

                  }) + " 00:00" : data.current?.start?.includes("T00:00")?new Date(data.current?.start)?.toLocaleString('en-US', {
                    weekday: "short",
                    month: "short",
                    day: "numeric", 
                    year: "numeric",

                  }) + " 00:00":new Date(data.current?.start)?.toLocaleString('en-US', {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                    year: "numeric",
                    hour: "numeric",
                    minute: "numeric",
                    hour12: false,
                  })} `} />
                {data.current?.end && data.current?.end != " " && data.current?.end != "undefined" &&data.current?.end != "null" &&<>
                  <NVLlabel text={`-`} className="font-semibold" />
                  <NVLlabel text={`${(new Date(data.current?.end)?.toISOString()?.includes("00:00:00.000") || data.current?.type == "Course")&&!data.current?.id?.includes("EVENT#") ? new Date(data.current?.end)?.toLocaleString('en-US',
                    {
                      weekday: "short", month: "short", day: "numeric",
                      year: "numeric",
                    }) + " 00:00" : new Date(data.current?.end)?.toLocaleString('en-US', {
                      weekday: "short",
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                      hour: "numeric",
                      minute: "numeric",
                      hour12: false,
                    })}`} />
                </>}
              </div>
              <EventDescription type={data.current?.type} />
              {data.current?.id?.includes("EVENT#") ?
                <div className="flex gap-1 pt-2 !translate-x-64">
                  <NVLButton
                    id="btnDelete"
                    text={"Delete"}
                    type="button"
                    className="w-24 nvl-button bg-orange-500 text-white"
                    onClick={() => setDeleteEvent("DeleteEvent")}
                  ></NVLButton>
                  <NVLButton
                    id="btnUpdate"
                    text={"Edit"}
                    type="button"
                    className="w-24 nvl-button bg-orange-500 text-white"
                    onClick={() => router.push(`/Home/DashboardEvents/AddEventAdminCalendar?Mode=Edit&EventID=${data.current?.id?.split("#")?.[1]}`)}
                  >
                  </NVLButton>
                </div> :
                <NVLButton
                  id="btnlink"
                  text={`Go to ${data?.current?.type}`}
                  type="button"
                  className="w-36 nvl-button bg-orange-500 text-white !translate-x-80"
                  onClick={() => (data.current?.id?.includes("#Course#")) ?
                    router.push(`/CourseManagement/CourseEditSettings?&Mode=Edit&CourseID=${data.current?.id?.split("#Course#")?.[0]}`) :
                    router.push(`/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${data.current?.id?.split("#")?.[0]}&ActivityType=${data.current?.id?.split("#")?.[1]}`)}>
                </NVLButton>}
            </div>
          </div>,
        DeleteEvent: <>
          <p className="text-xs font-semibold">Are you sure to delete this event?</p>
          <div className="flex gap-1 !translate-x-64">
            <NVLButton
              id="btnUpdate"
              text={`${watch("IsDeleted") ? "" : "Yes"}`}
              type="button"
              className="w-24 nvl-button bg-orange-500 text-white"
              onClick={() => deleteEvent()}
            >{watch("IsDeleted") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
            </NVLButton>
            <NVLButton
              id="btnDelete"
              text={"Cancel"}
              type="button"
              className="w-24 nvl-button bg-orange-500 text-white"
              onClick={() => setDeleteEvent("Upload")}
            ></NVLButton>
          </div>
        </>
      };
      return ComponentData[PopupName];
    }

  },
    [deleteEvent, router, watch]
  );

  function addDays(date, days, mode) {
    if (mode == "initial") {
      setDailyDate(new Date()?.toLocaleString('en-US', {
        weekday: "short", month: "short", day: "numeric", year: "numeric",
      }));
      return new Date()?.toLocaleString('en-US', {
        weekday: "short", month: "short", day: "numeric", year: "numeric",
      })
    } else {
      const copy = new Date(Number(new Date(date)));
      mode == "add" ? copy.setDate(new Date(date).getDate() + days) : copy.setDate(new Date(date).getDate() - days);
      setDailyDate(copy);
      return copy;
    }   
  }
  cal?.current?.containerElementRef?.current?.classList.remove("container")


  useEffect(() => {
    if (cal.current) {
      const calendarInstance = cal.current.getInstance();
      const updatedOptions = {
        week: {
          showMilestone: false
        }
      };
      calendarInstance.setOptions(updatedOptions);
    }
  }, []);
  const calendarOptions = {
    // Other calendar options...
    timezones: [
      {
        timezoneOffset: 0,
        displayLabel: 'Railway Time',
        tooltip: 'Railway Time',
      },
    ],
    renderTimeGrid: (date, grid) => {
      const hour = grid.hour < 10 ? '0' + grid.hour : grid.hour;
      const minutes = grid.minutes < 10 ? '0' + grid.minutes : grid.minutes;

      return (
        <div>
          {hour}:{minutes}
        </div>
      );
    },
  };

  return (
    <>
      <Container title="EventCalendar" loader={PropsList == undefined} PageRoutes={PageRoutes}>
        <NVLPageModalPopup
          ModalType="Page"
          PageComponent={GetComponent(deletedEvent)}
          open={open}
          setOpen={setOpen}
          user={props?.user}
          CustomWidth={"md:w-[500px]"}
          CustomHeader={data?.current?.title}
        />
        <div className="p-4 bg-gray-200">
          <div className="flex justify-between my-2 text-xs">
            <div className="flex justify-around gap-4  px-2 rounded bg-white w-56 text-black">
              <i onClick={() => {
                watch("ddlFilter") != "day" ? getCalInstance().prev() : addDays(DailyDate, 1, "subtract")
                getMonth();
              }} className="fa-solid fa-caret-left text-4xl cursor-pointer"></i>
              <span ref={month} className="  my-auto w-32 text-center text-sm font-semibold " >
                {watch("ddlFilter") == "day" ? DailyDate?.toLocaleString('en-US', {
                  weekday: "short",
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                }) : new Date().toLocaleString('default', { month: 'short' }) + " " + new Date().getFullYear()}
              </span>
              <i onClick={() => {
                watch("ddlFilter") != "day" ? getCalInstance().next() : addDays(DailyDate, 1, "add")
                getMonth();
              }} className="fa-solid fa-caret-right text-4xl cursor-pointer"></i>
            </div>
            <div className="flex gap-4">
            {/* <i onClick={() => getCalInstance()?.clearGridSelections()} className="my-auto text-lg fa-solid fa-arrows-rotate h-8 w-8 grid place-content-center  cursor-pointer rounded-full hover:bg-gray-200 bg-gray-100"></i> */}
              <NVLSelectField id="ddlFilter" options={getEvents} labelClassName="font-semibold text-gray-500" disabled={false} errors={errors} title="Select Company" register={register} className="w-44 border border-primary"  ></NVLSelectField>
              <button
                onClick={() => router.push("/Home/DashboardEvents/AddEventAdminCalendar?Mode=Create")}
                type="button"
                className="bg-primary text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3">
                <div className="flex flex-row align-middle gap-2">
                  <i className="fa-solid fa-plus mt-1"></i>Add Event
                </div>
              </button>
            </div>
          </div>
          <div className="relative ">
            {isLoading ?
              <NVLLoadingIndicator IsLoad={true} AlignLoader={"center"} />
              : viewEvent != "day" ? (<CalendarComponent
                key={calendarKey}
                height="500px"
                ref={cal}
                options={{
                  week: {
                    showMilestone: false
                  }
                }}
                view={viewEvent}
                useFormPopup={false}
                useDetailPopup={false}
                useCreationPopup={false}
                events={RowGridData.RowGrid}
                usageStatistics={false}
                taskView={FaTemperatureHigh}
                gridSelection={false}
                onClickEvent={onClickSchedule}
                onBeforeDeleteSchedule={onBeforeDeleteSchedule}
                id="EvntCalendar"
                {...calendarOptions}
              />) : <TodayEventCard DailyDate={DailyDate} eventData={PropsList.eventData} onClickSchedule={onClickSchedule}></TodayEventCard>}
          </div>
        </div>
      </Container>

    </>
  );
}