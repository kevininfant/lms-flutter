import { Image } from "@aws-amplify/ui-react";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLPasswordLogin from "@components/Controls/NVLPasswordLogin";
import NVLTextboxLogin from "@components/Controls/NVLTextboxLogin";
import Container from "@Container/Container";
import { yupResolver } from "@hookform/resolvers/yup";
import image from "@Public/Axle.png";
import { Auth } from 'aws-amplify';
import { APIGatewayGetRequest } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";
function Login(props) {
    const [organizationLogo, setOrganizationLogo] = useState(image?.src)
    const user = useRef({});
    const [loginPageInfo, setLoginPageInfo] = useState({ passwordUpdation: "", code: false, error: "", change: true });
    const router = useRouter();
    const passwordlength = useRef();
    const captchaRef = useRef();
    const CaptchaElemet = useRef();
    const intervalId = useRef();
    const fetchedData = useRef();
    const validatePassword = (password, ctx) => {
        let i = 0,
            message = "Password Should Have ";
        if (!password.match(/\d+/g)) {
            i++;
            message = message + "A Number";
        }
        if (!password.match(/[A-Z]+/g)) {
            i++;
            if (i > 1) {
                message = message + ", ";
            }
            message = message + "A Captial Letter";
        }
        if (!password.match(/[a-z]+/g)) {
            i++;
            if (i > 1) {
                message = message + ", ";
            }
            message = message + "A Small Letter";
        }
        if (!password.match(/[\W_]+/g)) {
            i++;
            if (i > 1) {
                message = message + ", ";
            }
            message = message + "A Special Character";
        }

        if (password.length < passwordlength.current) {
            i++;
            if (i > 1) {
                message = message + ", ";
            }
            message = message + "Minimun Of Length " + passwordlength.current;
        }
        message = message + ".";

        if (i > 0) {
            return message;
        }
        return true;
    };

    const validationSchema = Yup.object().shape({
        userName: loginPageInfo?.passwordUpdation == "" || loginPageInfo?.passwordUpdation == "ForgetPassword" ? Yup.string().required("username is required ") : Yup.string().nullable(),
        txtPassword: loginPageInfo?.passwordUpdation == "" ? Yup.string().required("password is required ") : Yup.string().nullable(),
        code: (loginPageInfo?.code) ? Yup.string()
            .required("Code is required ").matches(Regex("AllowOnlyNumbers"), "Code should be number")
            .test("", "", (val, { createError }) => {
                if (val?.length != 6) {
                    return createError({ message: "Code Length Should be 6" });
                }
                return true;
            }).nullable() : Yup.string().nullable(),

        newpassword: (loginPageInfo?.code) || loginPageInfo?.passwordUpdation == "NewPassword" ? Yup.string().required(" New password is required ")
            .test("", "", (e, { createError }) => {
                let length = validatePassword(e);
                if (length != true) {
                    return createError({ message: length });
                }
                else if (watch("confirmpassword") != e && watch("confirmpassword") != "" && watch("confirmpassword") != undefined) {
                    setError("confirmpassword", { type: "", message: "Password did not match" })
                    return true;
                }
                else if (watch("confirmpassword") != "" && watch("confirmpassword") != undefined) {
                    clearErrors(["confirmpassword"])
                }
                return true;
            }).nullable() : Yup.string().nullable(),

        confirmpassword: (loginPageInfo?.code) || loginPageInfo?.passwordUpdation == "NewPassword" ? Yup.string().required(" Confirm password is required ")
            .test("test", "testValid", (e, { createError }) => {
                if (watch("newpassword") != e) {
                    return createError({ message: "Password did not match" });
                }
                return true;
            }).nullable() : Yup.string().nullable(),
        txtCaptchaEnable: Yup.string().test("", "", (e) => {
            if (e != "" && watch("userName") && watch("txtPassword")) {
                setLoginPageInfo((data) => {
                    return { ...data, error: "" }
                });
                return true;
            }
            return true;
        })
    })

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, watch, reset, setValue, formState, clearErrors, setError } = useForm(formOptions);
    const { errors } = formState;

    const submitHandler = useCallback(async (data) => {
        setValue("loader", true);

        if (loginPageInfo?.passwordUpdation == "NewPassword") {
            Auth.completeNewPassword(user.current.user, data.newpassword)
                .then(async () => {
                    reset();
                    await Auth.signOut({ global: true });
                    router.push("/")
                    setLoginPageInfo((data) => {
                        return { ...data, error: "", passwordUpdation: "", code: !data.code, change: !data?.change }
                    });
                    setValue("loader", false);


                })
                .catch((err) => {
                    setLoginPageInfo((data) => {
                        return { ...data, error: err.message, change: !data?.change }
                    });
                    setValue("loader", false);

                });
        }
        else if (loginPageInfo?.passwordUpdation == "ForgetPassword") {
            if (loginPageInfo?.code) {
                Auth.forgotPasswordSubmit(data.userName, data.code, data.newpassword)
                    .then((data) => {
                        reset();
                        setLoginPageInfo((data) => {
                            return { ...data, error: "", passwordUpdation: "", change: !data?.change, code: !data.code }
                        });
                        setValue("loader", false);

                    })
                    .catch((err) => {
                        setLoginPageInfo((data) => {
                            return { ...data, error: err.message, change: !data?.change }
                        });
                        setValue("loader", false);
                    });

            }
            else {
                Auth.forgotPassword(data.userName)
                    .then(async (res) => {
                        let length = await APIGatewayGetRequest(process.env.APIGATEWAY_GetLoginPolicyForForgetPassword + "?UserName=" + data.userName, { method: "GET" });
                        let temlength = await length.res.text();
                        passwordlength.current = parseInt(temlength);

                        setLoginPageInfo((data) => {
                            return { ...data, code: true, error: "", change: !data?.change }
                        });
                        setValue("loader", false);
                    })
                    .catch((err) => {
                        if (err.message == "Username/client id combination not found.") {

                            setLoginPageInfo((data) => {
                                return { ...data, error: "Username does not exits.", change: !data?.change }
                            });
                            setValue("loader", false);
                        }
                        else {
                            setLoginPageInfo((data) => {
                                return { ...data, error: "Please Try Again After Some Time", change: !data?.change }
                            });
                            setValue("loader", false);
                        }
                    });
            }
        }
        else {
            try {
                if (validateCaptcha()) {
                    const currentuser = await Auth.signIn(data.userName?.trim(), data.txtPassword);
                    user.current = { user: currentuser, password: data.password };
                    if (currentuser.challengeName == "NEW_PASSWORD_REQUIRED") {
                        let length = await APIGatewayGetRequest(process.env.APIGATEWAY_GetLoginPolicyForForgetPassword + "?UserName=" + data.userName, { method: "GET" });
                        let temlength = await length.res.text();
                        passwordlength.current = parseInt(temlength);
                        reset();
                        setLoginPageInfo((data) => {
                            return { ...data, passwordUpdation: "NewPassword", change: !data?.change }
                        });
                    }
                }
                else {
                    setLoginPageInfo((data) => {
                        return { ...data, error: watch("txtCaptchaEnable") == "" ? "Captcha required" : "Enter Valid Captcha" }
                    });
                    setValue("loader", false);
                    setValue("txtCaptchaEnable", "")
                }
            } catch (err) {
                if (err.message == "User does not exist.") {
                    setLoginPageInfo((data) => {
                        return { ...data, error: "Incorrect username or password", change: !data?.change }
                    });
                    createCaptcha();
                    setValue("loader", false);
                    setValue("txtCaptchaEnable", "")
                }
                else if (err.message == "Your account has been disabled. Please contact the Administrator for more information.") {
                    setLoginPageInfo((data) => {
                        return { ...data, error: "Please Contact Your administrator.", change: !data?.change }
                    });
                    createCaptcha();
                    setValue("loader", false);
                    setValue("txtCaptchaEnable", "")
                }
                else if (err.message == "User is disabled.") {
                    setLoginPageInfo((data) => {
                        return { ...data, error: "Your account has been disabled, Please contact the Administrator for more information.", change: !data?.change }
                    });
                    createCaptcha();
                    setValue("loader", false);
                    setValue("txtCaptchaEnable", "")
                }
                else if (err.message.includes("userAlias") && err.message.includes("userName")) {
                    setLoginPageInfo((data) => {
                        return { ...data, error: "Incorrect username or password", change: !data?.change }
                    });
                    createCaptcha();
                    setValue("loader", false);
                    setValue("txtCaptchaEnable", "")
                }
                else {
                    setLoginPageInfo((data) => {
                        return { ...data, error: err.message }
                    });
                    createCaptcha();
                    setValue("loader", false);
                    setValue("txtCaptchaEnable", "")
                }
            }
        }
        setValue("loader", false);
    }, [setValue, loginPageInfo?.passwordUpdation, loginPageInfo?.code, reset, router, validateCaptcha, watch, createCaptcha])

    const createCaptcha = useCallback(() => {
        if (CaptchaElemet.current) {
            CaptchaElemet.current.innerHTML = "";
        }
        let charsArray = "0123456789abcdefghijklmnopqrstuvwxyz";
        let lengthOtp = 6;
        let captcha = [];
        for (let i = 0; i < lengthOtp; i++) {
            let index = Math.floor(Math.random() * charsArray.length);
            if (captcha.indexOf(charsArray[index]) == -1)
                captcha.push(charsArray[index]);
            else i--;
        }
        let canv = document.createElement("canvas");
        canv.id = "captcha";
        canv.width = 80;
        canv.height = 45;
        let ctx = canv.getContext("2d");
        ctx.font = "20px Georgia text-primary";
        ctx.textAlign = "left";
        ctx.strokeStyle = "#20548A";
        ctx.lineWidth = 1.5;
        ctx.strokeText(captcha.join(""), 0, 30);
        captchaRef.current = captcha.join("");
        if (CaptchaElemet.current) {
            CaptchaElemet.current.appendChild(canv);
        }
    }, [])

    const validateCaptcha = useCallback(() => {
        if (watch("txtCaptchaEnable") == captchaRef.current) {
            return true;
        } else {
            if (props?.error != "" && watch("txtCaptchaEnable") != "") {
                createCaptcha()
            }
            return false;
        }
    }, [createCaptcha, watch, props?.error])

    useEffect(() => {
        createCaptcha()
    }, [createCaptcha])

    useEffect(() => {
        intervalId.current = setInterval(() => {
            createCaptcha();
        }, 60000);
        return () => clearInterval(intervalId.current);
    }, [createCaptcha]);

    useEffect(() => {
        if (loginPageInfo?.change != undefined) {
            createCaptcha();
            clearInterval(intervalId.current);
            intervalId.current = setInterval(() => {
                createCaptcha();
            }, 60000);
        }
    }, [createCaptcha, loginPageInfo.change]);



    const Captcha = useCallback((props) => {
        if (CaptchaElemet?.current?.innerHTML == "") {
            props.createCaptcha();
        }
        return (
            <>
                <div className="">
                    <div className="flex gap-2">
                        <input {...props.register("txtCaptchaEnable", { shouldValidate: true })}
                            type={"text"}
                            id={"txtCaptchaEnable"} className="grow block px-4 pl-10 pb-2.5 pt-2 rounded-full 
                            h-9 w-[160px] text-sm text-gray-900 bg-transparent border-gray-300 appearance-none 
                            focus:outline-none focus:ring-0 focus:border-blue-600 focus:font-medium " placeholder="Enter Captcha" />
                        <div className="grow h-9 w-[136px] flex justify-center bg-[#EBF1FF] rounded-full">
                            <div ref={CaptchaElemet} id="captcha" className="relative bottom-1"></div>
                            <i className="fa fa-refresh text-center text-[#F47623] my-auto" onClick={() => setLoginPageInfo((data) => { setValue("txtCaptchaEnable", ""); return { ...data, change: !data?.change } })} aria-hidden="true"></i>
                        </div>
                    </div>
                    {props.error != undefined && props.error != "" && <NVLlabel showFull className='nvl-Def-Label w-full text-center !text-red-500 text-sm' text={props.error} />}
                </div >

            </>
        )
    }, [setValue])

    useEffect(()=>{
        setOrganizationLogo(image?.src)
    },[setValue])

    useEffect(() => {
        async function getData() {
            const pathName = window.location.host;
            const fetchURL = process.env.APIGATEWAY_URL_CUSTOM_LOGIN;
            const headers = { method: "GET", headers: { sk: "LOGIN#" + pathName }, };
            let result = await APIGatewayGetRequest(fetchURL, headers);
            let finalResponse = await result.res.text();
            let finalStatus = JSON.parse(finalResponse)
            fetchedData.current = finalStatus;
            setOrganizationLogo(fetchedData.current?.LogoUrl ?? image?.src)
        }
        getData();
    }, [setValue])

    const LoginPage = useCallback((props) => {

        if (props.passwordUpdation == "NewPassword") {
            return (
                <> <div className="grid place-items-center  ">
                    {/* Welcome to Novac Axles*/}
                    <i className="fa-solid fa-user text-[#0e4681] text-4xl bg-[#cae1fe] h-[70px] w-[70px] grid place-content-center rounded-full "></i>
                    <NVLlabel text="Force Password Change" className="nvl-Def-Label pt-2" />
                </div>
                    <div className="w-[300px] space-y-4">
                        <NVLPasswordLogin showErros={true} labelText="New password" id="newpassword" placeholder={"New Password"} type="password" register={props.register} errors={props.errors}></NVLPasswordLogin>
                        <NVLPasswordLogin showErros={true} labelText="Confirm password" id="confirmpassword" placeholder={"Confirm password"} type="password" register={props.register} errors={props.errors} ></NVLPasswordLogin>
                        {props.error != undefined && props.error != "" && <NVLlabel showFull className='nvl-Def-Label w-full text-center !text-red-500 text-sm' text={props.error} />}
                        <div className="grid place-content-center gap-4 "><NVLButton id="btnSave" text={props.watch("loader") ? "" : "Submit"} disabled={props.watch("loader")} type={"submit"} className={`h-9 w-40 text-sm bg-[#1D74FF] hover:bg-blue-500 text-white font-bold py-2 px-2 rounded-full `} onClick={handleSubmit((data) => submitHandler(data))}>{(props.watch("loader") != undefined && props.watch("loader")) ? <i className="fa fa-circle-notch fa-spin mr-2"></i> : ""}</NVLButton></div>
                    </div>
                </>
            )
        }
        if (props.passwordUpdation == "ForgetPassword") {
            return (
                <><div className="grid place-items-center   ">
                    {/* Welcome to Novac Axle*/}
                    <i className="fa-solid fa-user text-[#0e4681] text-4xl bg-[#cae1fe] h-[70px] w-[70px] grid place-content-center rounded-full "></i>
                    <NVLlabel text="Forgot Password" className="nvl-Def-Label pt-2" />
                </div>
                    <div className="w-[300px] space-y-4">
                        <NVLTextboxLogin className={(loginPageInfo?.code) ? "Disabled" : ""} disabled={loginPageInfo?.code ? true : false} labelText="User Name" id="userName" placeholder={"User Name"} type="text" register={props.register} errors={props.errors} ></NVLTextboxLogin>
                        {loginPageInfo?.code && <>
                            <NVLTextboxLogin labelClassIcon={<svg className="absolute top-3.5 left-4" id="code" width="16" height="7.999" viewBox="0 0 16 7.999">
                                <g id="Group_3353" data-name="Group 3353">
                                    <path id="Path_96" data-name="Path 96" d="M273.1,3.835a.892.892,0,0,1-.335.411.658.658,0,0,1-.669,0c-.234-.132-.466-.268-.726-.417,0,.283,0,.545,0,.807a.666.666,0,1,1-1.331.061c-.007-.281,0-.561,0-.868-.242.139-.47.267-.7.4a.666.666,0,1,1-.716-1.124c.238-.147.483-.281.742-.431-.257-.149-.5-.284-.737-.429a.658.658,0,0,1-.31-.724.672.672,0,0,1,.568-.508.654.654,0,0,1,.433.094l.715.411c0-.169,0-.315,0-.462,0-.13,0-.26,0-.39a.665.665,0,0,1,.639-.66.653.653,0,0,1,.682.594c.022.238.009.478.012.718,0,.057,0,.114,0,.2.206-.118.393-.224.58-.332.547-.316.882-.216,1.15.344V1.8a.65.65,0,0,1-.379.514l-.613.35c.209.114.411.237.619.351a.652.652,0,0,1,.373.535Z" transform="translate(-257.103 0)" fill="#1d74ff" />
                                    <path id="Path_97" data-name="Path 97" d="M276.176,160.542c-.043.016-.034.061-.048.092a.635.635,0,0,1-.606.413q-1.677.006-3.355,0a.661.661,0,0,1,0-1.323q1.677-.008,3.355,0a.673.673,0,0,1,.655.536Z" transform="translate(-260.176 -153.051)" fill="#1d74ff" />
                                    <path id="Path_98" data-name="Path 98" d="M3.066,1.519l.674-.39a.67.67,0,1,1,.666,1.155c-.215.126-.431.25-.668.388l.7.407a.654.654,0,0,1,.349.488.633.633,0,0,1-.277.651.624.624,0,0,1-.693.038c-.245-.133-.485-.276-.752-.429,0,.3,0,.585,0,.868a.653.653,0,0,1-.515.625.663.663,0,0,1-.722-.31.766.766,0,0,1-.094-.4q0-.359,0-.718a.362.362,0,0,0-.011-.051l-.684.394a.659.659,0,0,1-.669.033A.664.664,0,0,1,.327,3.1c.239-.145.483-.281.74-.429-.256-.149-.5-.284-.737-.429a.659.659,0,0,1-.315-.707.668.668,0,0,1,1.015-.425c.22.128.441.253.662.379,0,0,.01,0,.039,0,0-.222,0-.447,0-.672A1.228,1.228,0,0,1,1.759.491a.672.672,0,0,1,.7-.483.661.661,0,0,1,.606.626c.006.145,0,.291,0,.437s0,.278,0,.448" transform="translate(0 -0.004)" fill="#1d74ff" />
                                    <path id="Path_99" data-name="Path 99" d="M137.862,2.673c.244.142.47.27.693.4a.667.667,0,1,1-.672,1.149c-.225-.127-.448-.255-.7-.4,0,.315.008.6,0,.893a.655.655,0,0,1-.6.618.671.671,0,0,1-.71-.508,1.28,1.28,0,0,1-.016-.264c0-.234,0-.469,0-.7-.049-.028-.078.012-.111.03-.213.12-.421.248-.637.362a.664.664,0,0,1-.643-1.162c.235-.14.474-.275.721-.419-.254-.147-.494-.282-.73-.423a.651.651,0,0,1-.32-.7.659.659,0,0,1,.576-.535.646.646,0,0,1,.419.091c.2.113.4.224.593.344.1.06.138.068.133-.07-.008-.229-.005-.458,0-.687a.663.663,0,1,1,1.326,0c0,.239,0,.479,0,.719,0,.1.029.1.1.057q.3-.18.607-.351a.667.667,0,1,1,.665,1.154c-.228.135-.458.266-.7.407" transform="translate(-128.525 -0.005)" fill="#1d74ff" />
                                    <path id="Path_100" data-name="Path 100" d="M138.115,161.059c-.562,0-1.125.005-1.687,0a.639.639,0,0,1-.621-.535.661.661,0,0,1,.377-.731.678.678,0,0,1,.288-.057c1.1,0,2.208,0,3.312,0a.652.652,0,0,1,.67.591.667.667,0,0,1-.482.713.879.879,0,0,1-.248.022h-1.609Z" transform="translate(-130.125 -153.063)" fill="#1d74ff" />
                                    <path id="Path_101" data-name="Path 101" d="M2.379,159.724c.562,0,1.125-.005,1.687,0a.646.646,0,0,1,.632.561.659.659,0,0,1-.466.736.6.6,0,0,1-.168.026c-1.125,0-2.249,0-3.374,0a.647.647,0,0,1-.614-.448.666.666,0,0,1,.214-.732.7.7,0,0,1,.465-.146c.541,0,1.083,0,1.624,0h0" transform="translate(-0.039 -153.052)" fill="#1d74ff" />
                                </g>
                            </svg>} showErros={true} labelText="Code" id="code" placeholder={"Code"} type="text" register={props.register} errors={props.errors} ></NVLTextboxLogin>
                            <NVLPasswordLogin showErros={true} labelText="New Password" id="newpassword" placeholder={"Code"} type="password" register={props.register} errors={props.errors} ></NVLPasswordLogin>
                            <NVLPasswordLogin showErros={true} labelText="Confirm password" id="confirmpassword" placeholder={"Confirm password"} type="password" register={props.register} errors={props.errors} ></NVLPasswordLogin>
                        </>}
                        {props.error != undefined && props.error != "" && <NVLlabel showFull className='nvl-Def-Label w-full text-center !text-red-500 text-sm' text={props.error} />}

                        <div className="justify-center flex gap-4 pt-4 ">
                            <NVLButton id="btnSave" text={props.watch("loader") ? "" : (loginPageInfo?.code ? "Submit" : "Get Code")}
                                disabled={props.watch("loader")} type={"submit"} className={`h-9 w-40 text-sm bg-[#1D74FF] hover:bg-blue-500 text-white font-bold py-2 px-4 rounded-full`} onClick={
                                    handleSubmit((data) => submitHandler(data))
                                } >{(props.watch("loader") != undefined && props.watch("loader")) ? <i className="fa fa-circle-notch fa-spin mr-2"></i> : ""}</NVLButton>
                            <NVLButton id="btnback" text="Back" type={"success"} disabled={props.watch("loader")}
                                className={`h-9 w-40 text-sm bg-[#C9C9C9] hover:bg-[#cdcdcd] text-[#374151] font-bold py-2 px-4 rounded-full `} onClick={() => {
                                    props.reset();
                                    setLoginPageInfo((data) => { let temp = data?.change; if (temp == undefined) { temp = true } return { ...data, error: "", passwordUpdation: "", code: false, change: !temp } });
                                }} />
                        </div>
                    </div>
                </>
            )
        }
        else {
            return (
                <>
                    <div className="grid place-items-center text-[#1D74FF]  ">
                        {/* Welcome to Novac Axle*/}
                        <i className="fa-solid fa-user text-[#0e4681] text-4xl bg-[#cae1fe] h-[70px] w-[70px] grid place-content-center rounded-full "></i>
                        <NVLlabel text="Sign in to continue" className="nvl-Def-Label pt-2" />
                    </div>
                    <div className="w-[300px] space-y-4">
                        <NVLTextboxLogin labelText="User name" id="userName" placeholder={"User Name"} type="text" register={props.register} errors={props.errors} ></NVLTextboxLogin>
                        <NVLPasswordLogin id="txtPassword" type="password" labelText="Password" className="" register={props.register} errors={props.errors}></NVLPasswordLogin>
                        {/* {props.error != undefined && props.error != "" && <NVLlabel showFull className='nvl-Def-Label w-full text-center !text-red-500 text-sm' text={props.error} />} */}
                        <Captcha createCaptcha={props.createCaptcha} register={props.register} error={props.error} />
                        <div className="grid place-content-center gap-10 ">
                            <NVLButton id="btnSave" text={props.watch("loader") != undefined && props.watch("loader") ? "" : "Sign in"} disabled={props.watch("loader")} type={"submit"} className={`w-40 h-9 text-sm bg-[#1D74FF] hover:bg-blue-500 text-white font-bold py-2 px-4 rounded-full`} onClick={handleSubmit((data) => submitHandler(data))} >{(props.watch("loader") != undefined && props.watch("loader")) ? <i className="fa fa-circle-notch fa-spin mr-2"></i> : ""}</NVLButton>
                            <NVLButton id="forgetpassword" text={"Forgot password?"} disabled={props.watch("loader")} type={"button"} className={` hover-underline-animation text-sm !text-[#1D74FF] !font-semibold`} onClick={() => { props.reset(); setLoginPageInfo((data) => { return { ...data, error: "", passwordUpdation: "ForgetPassword" } }); }} />
                        </div>
                    </div>
                </>
            )
        }
    }, [handleSubmit, submitHandler, loginPageInfo?.code])
    return (
        <>
            <Container title="Login" className={`relative   ${(watch("loader")) ? "pointer-events-none" : "px-2"}`}>
                <div className=" bg-[url('/BG-Login-Page.png')] bg-no-repeat bg-[length:_100%]">
                    <form onSubmit={handleSubmit(submitHandler)}>
                        <div className="h-screen grid place-content-center gap-4 font-Montserrat">
                            <div className="grid place-content-center place-items-center gap-1` border-gray-200 p-2 h-full w-full md:h-[480px] md:w-[400px] shadow-[0_2px_20px_rgb(0,0,0,0.5)]">
                            <Image alt="Novac Technology logo" id={"organizationLogo"} src={organizationLogo} className="h-16 w-56 object-contain flex justify-center" />
                                <LoginPage organizationLogo={organizationLogo} createCaptcha={createCaptcha} error={loginPageInfo?.error} reset={reset} passwordUpdation={loginPageInfo?.passwordUpdation} register={register} errors={errors} watch={watch} />
                            </div>
                        </div>
                    </form>
                    <div className="absolute inset-x-0 bottom-2 flex flex-col xl:flex-row justify-center xl:gap-10 m-2 text-center ">
                        <div className="nvl-Def-Label" >Terms and Condition</div>
                        <div className="nvl-Def-Label" >© 2023 Novac Technology Solutions. All rights reserved.</div>
                        <div className="nvl-Def-Label" >Privacy Policy</div>
                    </div>
                    <div className="absolute bottom-4 right-6">
                        <div className="flex justify-center items-center gap-2 py-1 text-xs bg-[#1D74FF] hover:bg-blue-500 text-white font-semibold w-20 h-7 rounded-lg"><svg id="Help" width="20" height="17.578" viewBox="0 0 20 17.578">
                            <defs>
                                <clipPath id="clip-path">
                                    <rect id="Rectangle_41" data-name="Rectangle 41" width="20" height="17.578" fill="#fff" />
                                </clipPath>
                            </defs>
                            <g id="Group_3354" data-name="Group 3354">
                                <path id="Path_102" data-name="Path 102" d="M19.967,9.072a1.735,1.735,0,0,1-1.646,1.473c-.384.011-.768.009-1.152,0a.207.207,0,0,0-.227.148,7.529,7.529,0,0,1-5.043,4.3c-.109.03-.142.069-.143.181a5.635,5.635,0,0,1-.028.954A1.755,1.755,0,1,1,9.7,14.1c.411-.07.831-.03,1.243-.1a6.268,6.268,0,0,0,5.141-4.3A6.437,6.437,0,1,0,3.667,6.426a7.165,7.165,0,0,0,.379,3.756c.037.1.067.21.1.315,0,.011,0,.025-.007.055-.894-.029-1.8.072-2.685-.046A1.7,1.7,0,0,1,0,8.8Q-.006,7.622,0,6.441A1.755,1.755,0,0,1,1.758,4.691c.332,0,.664-.008,1,0a.274.274,0,0,0,.3-.189A7.473,7.473,0,0,1,8.3.2a7.546,7.546,0,0,1,8.617,4.283.3.3,0,0,0,.326.213,7.575,7.575,0,0,1,1.344.031,1.732,1.732,0,0,1,1.378,1.437c.035.064-.013.141.033.2v2.5c-.046.062,0,.14-.033.2" transform="translate(0 0)" fill="#fff" />
                                <path id="Path_103" data-name="Path 103" d="M382.4,118.273a.222.222,0,0,1-.033-.2.03.03,0,0,1,.033.008Z" transform="translate(-362.401 -111.905)" fill="#fff" />
                                <path id="Path_104" data-name="Path 104" d="M382.369,170.1a.221.221,0,0,1,.033-.2v.2l-.015.012Z" transform="translate(-362.402 -161.026)" fill="#fff" />
                                <path id="Path_105" data-name="Path 105" d="M100.968,49.106a5.264,5.264,0,0,0-9.115-2.668,5.216,5.216,0,0,0-.323,6.629.259.259,0,0,1,.032.313,1.148,1.148,0,0,1-.928.657c-.11.014-.136.045-.134.149.007.293.01.586,0,.878-.005.134.042.157.163.156.9,0,1.809,0,2.714,0h.156c.937-.018,1.876.057,2.81-.037a5.237,5.237,0,0,0,4.627-6.075m-7.056,1.427c-.319-.005-.637,0-.956,0-.081,0-.114-.017-.113-.106.005-.319,0-.637,0-.956,0-.081.017-.114.107-.113.319.005.637.006.956,0,.105,0,.115.044.112.128,0,.156,0,.312,0,.468s0,.312,0,.468c0,.082-.017.114-.107.112m2.318,0c-.306-.005-.611-.007-.917,0-.107,0-.129-.035-.127-.132.006-.306.007-.611,0-.917,0-.107.033-.129.133-.127.306.006.611.007.917,0,.108,0,.131.035.127.133-.007.156,0,.312,0,.468s-.007.3,0,.449c.007.109-.036.128-.133.126m2.368,0c-.319-.005-.637,0-.956,0-.081,0-.114-.017-.113-.106.005-.319,0-.637,0-.956,0-.081.017-.114.107-.113.319.005.637.006.956,0,.105,0,.115.044.112.128,0,.156,0,.312,0,.468s0,.312,0,.468c0,.082-.017.114-.107.112" transform="translate(-85.773 -42.326)" fill="#fff" />
                            </g>
                        </svg>Help</div>
                    </div>

                </div>
            </Container>
        </>
    );
}

export default Login;