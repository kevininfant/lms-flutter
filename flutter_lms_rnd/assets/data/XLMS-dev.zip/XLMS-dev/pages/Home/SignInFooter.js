import { Flex, Link, useAuthenticator } from "@aws-amplify/ui-react";

function SignInFooter() {
  const { toResetPassword } = useAuthenticator();
  return (
    <Flex justifyContent="center">
      <Link onClick={toResetPassword} className="hover-underline-animation text-gray-500 font-semibold relative right-1 pb-1 text-xs font-Montserrat">
        Forgot password?
      </Link>
    </Flex>
  );
}

export default SignInFooter;
