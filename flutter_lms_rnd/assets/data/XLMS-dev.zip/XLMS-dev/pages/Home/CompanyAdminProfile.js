import NVLImage from '@components/Controls/NVLImage';
import NVLlabel from '@components/Controls/NVLlabel';
import Jsondata from "@Constants/dropdowndata.json";
import { useMemo } from 'react';

export default function CompanyAdminProfile({ ProfileData, SavedImageRef, UploadLoder, PageData, UplodError, ProfileGoToUnsaved, ProfileUrlMoveUnsavedToSaved }) {
  const TenantCountry = useMemo(() => {
    let Country = Jsondata?.Country.filter(((CU) => {
      return CU?.value == ProfileData?.Country;
    }));
    return Country?.[0]?.text ? Country?.[0]?.text : "-";
  }, [ProfileData?.Country]);
  return (
    <>
      <div className='text-center bg-gray-700 py-6 shadow text-white'>
        <h1 className="text-2xl font-black ">My Profile!</h1>
        <p className="mb-6 ">Add information about yourself.</p>
      </div>
      <div className="grid grid-flow-col text-gray-800  gap-4">
        <div className="  px-8 py-4 text-gray-800 md:px-10  relative border-b-8 border-gray-700 rounded-b">
          <div className='space-y-12'>
            <div className='relative'>
              <div className="pointer-events-none  mx-auto rounded-full text-blue-500 flex justify-center">
                {SavedImageRef?.IncomingPath == undefined ? (<div className=" w-32 h-32 relative flex justify-center items-center 
                        rounded-full text-6xl bg-gray-400 text-white uppercase">
                  {ProfileData?.TenantDisplayName?.charAt(0)}
                </div>) : (
                  <NVLImage id={"myImg"} alt={SavedImageRef?.ProfileName} className="rounded-full overflow-hidden shadow-lg w-36 h-36"
                    src={SavedImageRef?.IncomingPath} title="Profile" />)}
              </div>
              <NVLlabel htmlFor="fulogo" className={`absolute right-[45%] cursor-pointer bg-white text-gray-600 font-semibold text-indigo-6 text-sm`}>
                {UploadLoder?.unsavedLoader ? <div className="UploadProfileloader absolute -right-2 bottom-2 "></div> : <><i className="shadow-lg bg-white absolute -right-2 bottom-2 fa-solid fa-pen-to-square text-green-600 h-8 w-8 grid place-content-center cursor-pointer rounded-full  border-2 border-green-600"></i>
                  <input id="fulogo" name="file-upload" type="file" onChange={(e) => {
                    ProfileGoToUnsaved(e)
                  }} className="sr-only " /></>}
              </NVLlabel>
            </div>
            {UplodError && (<div className='flex justify-center gap-2 text-yellow-600 text-xs '><i className="fa-solid fa-circle-exclamation my-auto"></i><span>{UplodError}</span></div>)}
            <div className='flex justify-center'>
              {UploadLoder?.savedLoader ? <div className="UploadProfileloader mx-auto" /> : (
                <button onClick={ProfileUrlMoveUnsavedToSaved} type="button"
                  className={`${!SavedImageRef?.IsUpload ? "Disabled" : ""} inline-flex items-center px-4 py-2 bg-white border border-gray-300  rounded-md font-semibold text-xs text-gray-700 uppercase tracking-widest shadow-sm hover:text-gray-500 focus:outline-none focus:border-blue-400 focus:shadow-outline-blue active:text-gray-800 active:bg-gray-50 transition ease-in-out duration-150 `}>
                  Upload Picture
                </button>)}
            </div>

          </div>
          <div>
            <div className="nvl-Cmny-OverView-Data  text-th-body-txt-color  rounded gap-2 text-sm break-all">
              <div className="flex gap-2  rounded-md break-all bg-white"><i className="fa-solid fa-building bg-gray-200 p-2 my-auto h-8 w-8 "></i><NVLlabel text="Company Name" className="  font-semibold my-auto " /></div>
              <span className="my-auto font-bold " >:</span>
              <div className="flex gap-2 rounded-md break-all bg-white "><NVLlabel text={ProfileData?.TenantDisplayName} className=" p-2"></NVLlabel></div>
              <div className="flex gap-2  rounded-md break-all bg-white"><i className="fa-solid fa-hashtag bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Company Code" className="  font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 g   rounded-md break-all bg-white"><NVLlabel showFull text={ProfileData?.CompanyCode} className="p-2"></NVLlabel></div>
              <div className="flex gap-2  rounded-md break-all bg-white"><i className="fa-solid fa-envelope bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Contact Email" className="  font-semibold my-auto " /></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 rounded-md break-all bg-white"> <NVLlabel showFull text={ProfileData?.EmailID} className="p-2"></NVLlabel></div>
              <div className="flex gap-2 rounded-md  break-all bg-white"><i className="fa-solid fa-phone bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Mobile Number" className="  font-semibold my-auto "></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 rounded-md break-all bg-white"><NVLlabel showFull text={ProfileData?.MobileNo} className="p-2"></NVLlabel></div>
              <div className="flex gap-2 rounded-md break-all bg-white"><i className="fa-solid fa-mobile-screen-button bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Alternate Mobile Number" className=" font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 rounded-md break-all bg-white"><NVLlabel showFull text={ProfileData?.AlterMobileNo} className="p-2"></NVLlabel></div>
              <div className="flex gap-2 rounded-md  break-all bg-white"><i className="fa-solid fa-location-dot bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Address 1" className="font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 rounded-md break-all bg-white"><NVLlabel text={ProfileData?.Address1} className="p-2"></NVLlabel></div>
              <div className="flex gap-2 rounded-md break-all bg-white"><i className="fa-solid fa-address-book bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Address 2" className="  font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 g   rounded-md break-all bg-white"><NVLlabel text={ProfileData?.Address2} className="p-2"></NVLlabel></div>
              <div className="flex gap-2 rounded-md break-all bg-white"><i className="fa-solid fa-earth-americas bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Country" className="  font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 g  rounded-md break-all bg-white"><NVLlabel showFull text={TenantCountry} className="p-2"></NVLlabel></div>
              <div className="flex gap-2 rounded-md break-all bg-white"><i className="fa-brands fa-usps bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="State" className="  font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 g   rounded-md break-all bg-white"><NVLlabel showFull text={ProfileData?.State} className="p-2"></NVLlabel></div>
              <div className="flex gap-2  rounded-md break-all bg-white"><i className="fa-solid fa-city bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="City" className="  font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 g   rounded-md break-all bg-white"><NVLlabel showFull text={ProfileData?.City} className="p-2"></NVLlabel></div>
              <div className="flex gap-2  rounded-md break-all bg-white"><i className="fa-solid fa-tag bg-gray-200 p-2 my-auto h-8 w-8"></i><NVLlabel text="Plan" className="  font-semibold my-auto"></NVLlabel></div>
              <span className="my-auto font-bold">:</span>
              <div className="flex gap-2 g   rounded-md break-all bg-white"><NVLlabel showFull text={ProfileData?.PlanCode} className="p-2"></NVLlabel></div>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}
