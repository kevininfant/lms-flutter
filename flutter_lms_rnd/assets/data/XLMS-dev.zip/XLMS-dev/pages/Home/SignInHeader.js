import { Image } from "@aws-amplify/ui-react";

function SignInHeader() {
  return (
    <>
      <div className="text-center pt-10">
        <Image alt="Novac Technology logo" className="h-10" src="/Novac_Axle_Logo.jpeg" />
      </div>
    </>
  );
}

export default SignInHeader;
