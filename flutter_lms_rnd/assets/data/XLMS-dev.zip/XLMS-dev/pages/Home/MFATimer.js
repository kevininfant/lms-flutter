import NVLlabel from "@components/Controls/NVLlabel";
import { useEffect, useState } from "react";

function ResetOTPTimer (props) {
   const [minutes, setMinutes] = useState(1);
    const [seconds, setSeconds] = useState(30);
    
    useEffect(() => {
        const interval = setInterval(() => {
          if (seconds > 0) {
            setSeconds(seconds - 1);
          }
      
          if (seconds === 0) {
            if (minutes === 0) {
              clearInterval(interval);
            } else {
              setSeconds(59);
              setMinutes(minutes - 1);
            }
          }
        }, 1000);
      
        return () => {
          clearInterval(interval);
        };
      }, [minutes, seconds]);
      

      const resendOTP = () => {
        setMinutes(1);
        setSeconds(30);
      };

    return (
      <div >
     
           <div className="flex">
            <button className="text-xs"
             disabled={seconds > 0 || minutes > 0} style={{   color: seconds > 0 || minutes > 0 ? "#DFE3E8" : "#FF5630", }}onClick={resendOTP} >Resend OTP </button>
              {seconds > 0 || minutes > 0 ? 
              (
              <NVLlabel className="pl-44"
               text ={` Time Remaining: ${minutes < 10 ?  0 + minutes : minutes}:${seconds < 10 ? 0+seconds: seconds}`}> </NVLlabel> ) : ( <NVLlabel  className=" text-sm pl-48" text="Didn't recieve code?" > </NVLlabel> )}
            </div>
           

      </div>
      
    );
  }
  
  export default ResetOTPTimer;