import NVLlabel from '@components/Controls/NVLlabel';
import Container from "@Container/Container";
import { RadioGroup } from "@headlessui/react";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from 'next/router';
import { useCallback, useEffect, useRef, useState } from "react";
import { updateXlmsInAppNotification } from "src/graphql/mutations";
import { getXlmsInAppNotification, listXlmsInAppNotification } from "src/graphql/queries";

function NotiFication(props) {

  const notificationMsg = useRef();
  const [Data, setData] = useState({})
  const router = useRouter();
  const [selected, setSelected] = useState(() => {
    return {};
  });
  useEffect(() => {
    const DataSource = async (i) => {
      var modetype = decodeURIComponent(String(router.query["modetype"]));
      let Url_pk = decodeURIComponent(String(router.query["PKid"]));
      let Url_sk = decodeURIComponent(String(router.query["SKid"]));
      let Url_SK = "PUSHEVENT#";
      let user = [];
      const ListRes = await AppsyncDBconnection(
        listXlmsInAppNotification,
        { PK: Url_pk, SK: Url_SK }, props.user.signInUserSession.accessToken.jwtToken
      );


      setData({
        ListData: ListRes.res.listXlmsInAppNotification.items,
        Modetype: modetype,
        NotifySK: Url_SK,
      })
      if (modetype == "get") {
        getMessage(Url_pk, Url_sk)
      }
      notificationMsg.current = ([...ListRes.res.listXlmsInAppNotification.items].reverse())
    }
    DataSource();
    return (() => {
      setData((temp) => { return { ...temp } })

    })

  }, [getMessage, notificationMsg, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const [value, setvalue] = useState(async () => {
    return ({
      Subject: "",
      Message: "",
      CreatedDate: "",
      AttachUrl: "",
      BucketName: "",
    });
  });

  const getMessage = useCallback(async (PK, SK) => {
    const response = await AppsyncDBconnection(
      getXlmsInAppNotification,
      { PK: PK, SK: SK }, props.user.signInUserSession.accessToken.jwtToken
    );

    setvalue({
      Subject: response.res.getXlmsInAppNotification?.Subject,
      Message: response.res.getXlmsInAppNotification?.Message,
      CreatedDate: response.res.getXlmsInAppNotification?.CreatedDate,
      AttachUrl: response.res.getXlmsInAppNotification?.AttachemntURL,
      BucketName: response.res.getXlmsInAppNotification?.BucketName,
    });
    if (response?.res?.getXlmsInAppNotification?.IsViewState) {
      const resp = await AppsyncDBconnection(
        updateXlmsInAppNotification, {
        input: { PK: PK, SK: SK, IsViewState: false },

      }, props.user.signInUserSession.accessToken.jwtToken
      );

      notificationMsg.current.map((e) => {
        if (e.PK == PK && e.SK == SK) {
          e.IsViewState = false
        }
      })
      props.ReduceNewData();
    }
  }, [props]);

  const date1 = new Date(Date.now() + (new Date().getTimezoneOffset() * 60000))
  function getDifferenceInDays(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / (1000 * 60 * 60 * 24);
  }

  function getDifferenceInHours(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / (1000 * 60 * 60);
  }

  function getDifferenceInMinutes(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / (1000 * 60);
  }

  function getDifferenceInSeconds(date1, date2) {
    const diffInMs = Math.abs(date2 - date1);
    return diffInMs / 1000;
  }
  const DownloadFiles = useCallback(async (url, BucketName) => {
    let fetchURL = process.env.APIGATEWAY_INVOKEURL;

    let headers = {
      method: "POST",
      headers: {
        "Content-Type": "text/csv",
        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
        bucketname: props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.BucketName : BucketName,
      },
      body: url,
    };
    let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
    var win = window.open(await FinalStatus.res.text(), '_blank');
  }, [props.TenantInfo.BucketName, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken])
  // Bread Crumbs
  const PageRoutes = [{ path: "", breadcrumb: "Notification" }];
  return (
    <>
      <Container title="Notification" PageRoutes={PageRoutes} loader={notificationMsg == undefined} >

        <span className="w-full tsext-xs font-semibold inline-block border border-gray-300 py-4 px-4 rounded text-gray-600 bg-gray-200 uppercase last:mr-0 mr-1">
          Notifications All
        </span>
        <section className="text-gray-600 body-font overflow-hidden">
          <div className="container py-5 border mx-auto">
            <div className="-my-8 divide-y-2 divide-gray-100">
              <div className="sm:flex flex-wrap md:flex-nowrap gap-6 ">

                <div className="md:w-72 md:mb-0 mb-6 flex-shrink-0 flex flex-col">

                  <RadioGroup value={selected} onChange={setSelected}>
                    <RadioGroup.Label className="sr-only">
                      Server size
                    </RadioGroup.Label>
                    <div className="py-10 shadow-xl border">
                      <div className="h-[400px] p-1 space-y-3 overflow-y-scroll px-2">

                        {notificationMsg.current?.map((plan) => (
                          (

                            <RadioGroup.Option
                              onClick={() => getMessage(plan.PK, plan.SK)}
                              key={plan.SK}
                              value={plan}
                              className={({ active, checked }) =>
                                `${active
                                  ? "ring-2 ring-white ring-opacity-60 ring-offset-2 ring-offset-blue-300"
                                  : ""
                                }  ${checked
                                  ? "bg-[#1D74FF] bg-opacity-75 text-white " :
                                  !plan.IsViewState ? " bg-gray-100 border border-gray-400" :
                                    "bg-green-100 text-green-400 border border-green-400"}
                                relative flex cursor-pointer rounded-lg px-5 py-2 shadow-md focus:outline-none h-14`
                              }
                            >

                              {({ active, checked }) => (
                                <>

                                  <i className="fa-solid fa-check-double right-2 top-2  absolute"></i>

                                  <div className="flex w-full items-center justify-between">
                                    <div className="flex items-center ">
                                      <div className="text-xs">
                                        <RadioGroup.Label
                                          as="span"
                                          className={`font-medium  ${checked ? "text-white" : "text-gray-900"
                                            }`}
                                        >
                                          <NVLlabel text={plan.Subject} />
                                        </RadioGroup.Label>
                                        <RadioGroup.Description
                                          as="span"
                                          className={`inline ${checked ? "text-sky-100" : "text-gray-500"
                                            }`}
                                        >
                                          <span aria-hidden="true"></span>
                                          <span>{getDifferenceInDays(date1, new Date(plan.CreatedDate?.replace("T", " "))) < 33 ? getDifferenceInHours(date1, new Date(plan.CreatedDate?.replace("T", " "))) < 24 ? getDifferenceInMinutes(date1, new Date(plan.CreatedDate?.replace("T", " "))) < 60 ? Math.floor(getDifferenceInSeconds(date1, new Date(plan.CreatedDate?.replace("T", " "))) / 60) + " minutes ago" : Math.floor(getDifferenceInMinutes(date1, new Date(plan.CreatedDate?.replace("T", " "))) / 60) + " hours ago" : Math.floor(getDifferenceInHours(date1, new Date(plan.CreatedDate?.replace("T", " "))) / 24) + " days ago" : getDifferenceInDays(date1, new Date(plan.CreatedDate?.replace("T", " "))) / 30 < 12 ? Math.floor(getDifferenceInDays(date1, new Date(plan.CreatedDate?.replace("T", " "))) / 30) + " months ago" : Math.floor(getDifferenceInDays(date1, new Date(plan.CreatedDate?.replace("T", " "))) / 30 / 12) + " years ago"}</span>
                                        </RadioGroup.Description>
                                      </div>
                                    </div>
                                  </div>
                                </>
                              )}
                            </RadioGroup.Option>)
                        ))}
                      </div>
                    </div>
                  </RadioGroup>
                </div>
                <div className="md:flex-grow w-full">
                  {/* msg content */}
                  {value.Subject != "" && value.CreatedDate != undefined ? <div className="app font-sans border h-full bg-grey-lighter  p-10 ">
                    <div className="p-2 border-b flex">
                      <i className="fa-solid fa-lightbulb pr-2"></i>
                      <div>
                        <p className="w-full break-all">{value.Subject}</p>
                        <p className="text-xs"> <span>{getDifferenceInDays(date1, new Date(value.CreatedDate?.replace("T", " "))) < 33 ? getDifferenceInHours(date1, new Date(value.CreatedDate?.replace("T", " "))) < 24 ? getDifferenceInMinutes(date1, new Date(value.CreatedDate?.replace("T", " "))) < 60 ? Math.floor(getDifferenceInSeconds(date1, new Date(value.CreatedDate?.replace("T", " "))) / 60) + " minutes ago" : Math.floor(getDifferenceInMinutes(date1, new Date(value.CreatedDate?.replace("T", " "))) / 60) + " hours ago" : Math.floor(getDifferenceInHours(date1, new Date(value.CreatedDate?.replace("T", " "))) / 24) + " days ago" : getDifferenceInDays(date1, new Date(value.CreatedDate?.replace("T", " "))) / 30 < 12 ? Math.floor(getDifferenceInDays(date1, new Date(value.CreatedDate?.replace("T", " "))) / 30) + " months ago" : Math.floor(getDifferenceInDays(date1, new Date(value.CreatedDate?.replace("T", " "))) / 30 / 12) + " years ago"}</span></p>
                      </div>
                    </div>
                    <div className="content__body  p-2 py-6 text-sm">
                      <div className="grid gap-5">
                        <div className="flex gap-3">
                          {/* <i className="fa-solid fa-circle-down pt-1 text-primary "></i> */}
                          <p className="w-full break-all">{value.Message}</p>
                        </div>
                        {value.AttachUrl != undefined && value.AttachUrl != "" && <div><div onClick={() => { DownloadFiles(value.AttachUrl, value.BucketName) }} href={value.AttachUrl} rel="noreferrer" target={"_blank"} className="w-full break-all" ><i className="fa fa-download"></i>{"Click here to dowload"}</div></div>}
                      </div>
                    </div>
                  </div> : ""}
                </div>
              </div>
            </div>
          </div>
        </section>
      </Container>
    </>
  );
}

export default NotiFication;

