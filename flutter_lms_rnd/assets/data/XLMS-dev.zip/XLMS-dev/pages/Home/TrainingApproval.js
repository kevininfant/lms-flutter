import Container from '@components/Container/Container';
import NVLAlert, { ModalClose, ModalOpen } from '@components/Controls/NVLAlert';
import NVLButton from '@components/Controls/NVLButton';
import NVLGridTable from '@components/Controls/NVLGridTable';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLSelectField from '@components/Controls/NVLSelectField';
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayPostRequest, AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { createXlmsBatchTrainingEnrollUser, createXlmsBatchTrainingManagement, createXlmsTrainingSelfEnrollUserBatch } from 'src/graphql/mutations';
import { getXlmsTrainingEnrollUser, getXlmsTrainingManagement, getXlmsUserInfo, listXlmsTrainingManagement, listXlmsTrainingSelfEnrollUserbyStatusFlag } from 'src/graphql/queries';
import * as Yup from "yup";

function TrainingApproval(props) {
  const router = useRouter();
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [approvalData, setApprovalData] = useState()
  const [isBeenCalled, setisBeenCalled] = useState(false)
  let trainingApprovalSelect = useRef();

  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Training Nomination has been approved.",
  };
  const [modalValues, setModalValues] = useState(initialModalState);

  const currentDate = useCallback(() => {
    return new Date().getFullYear() + "-" + (new Date().getMonth() + 1 >= 10 ? new Date().getMonth() + 1 : "0" + (new Date().getMonth() + 1)) + "-" + (new Date().getDate() < 9 ? "0" + new Date().getDate() : new Date().getDate()) + "T" + new Date().getHours() + ":" + (new Date().getMinutes() > 9 ? new Date().getMinutes() : "0" + new Date().getMinutes())
  }, [])

  useEffect(() => {
    if (document.getElementById("ddlApproval") != undefined || document.getElementById("ddlApproval") != null) {
      document.getElementById("ddlApproval").value = "TrainingApproval";
    }
    async function FetchData() {
      setCountTra()
      let finalTrainingData = [];
      let trainingResponseData = await AppsyncDBconnection(listXlmsTrainingManagement, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "TRAININGINFO#LASTMODIFIEDDATE#", TrainingType: "NotPast", CurrentDate: currentDate(), IsSuspend: false, IsDeleted: false }, props.user?.signInUserSession?.accessToken?.jwtToken);
      trainingResponseData && trainingResponseData?.res?.listXlmsTrainingManagement?.items.map((item) => {
        if ((item?.TrainingType == "Open")) {
          finalTrainingData.push(item)
        }
      })
      setApprovalData({ TrainingData: finalTrainingData })
    }
    FetchData()

  }, [approvedTraining, currentDate, props?.TenantInfo?.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, setCountTra, setValue, waitingTraining, watch])

  const refreshGrid = async () => {
    setIsRefreshing((count) => {
      return count + 1;
    });
  };

  const trainingList = useMemo(() => {
    let List = [{ value: "", text: "Select" }]
    approvalData?.TrainingData?.map((Training) => { List.push({ value: Training?.TrainingID, text: Training?.TrainingName }) });
    return List;
  }, [approvalData?.TrainingData])

  const validationSchema = Yup.object().shape({

    ddlTraining: Yup.string().test("", "", async (e) => {
      setCountTra()
      if (trainingApprovalSelect.current != e) {
        trainingApprovalSelect.current = e;
        setIsRefreshing(false);
      }
      return true;
    })
      .nullable(),
  })
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, setValue, watch, formState } = useForm(formOptions);
  const { errors } = formState;
  const HeaderColumn = [
    { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-3/12", },
    { HeaderName: "First Name", Columnvalue: "FirstName", HeaderCss: "w-6/12", },
    { HeaderName: "Last Name", Columnvalue: "LastName", HeaderCss: "w-6/12", },
    { HeaderName: "Email ID", Columnvalue: "EmailID", HeaderCss: "w-8/12", },
    { HeaderName: "Approval Status", Columnvalue: "Status", HeaderCss: "w-9/12" },
  ]

  const FinalResponse = useCallback((FinalStatus, UserStatus) => {
    if (FinalStatus != "Success") {
      setisBeenCalled(false)
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
        ModalOnClickEvent: () => { ModalClose() }
      });
      ModalOpen();
      return;
    } else {
      setModalValues({
        ModalInfo: "Success",
        ModalTopMessage: FinalStatus,
        ModalBottomMessage: UserStatus == "Accept" ? "Training Nomination has been approved ." : UserStatus == "Waiting" ? "Training Nomination has been moved to waiting list ." : "Training Nomination has been rejected.",
        ModalOnClickEvent: () => { router.push("/Home/TrainingApproval") }
      });
      ModalOpen();
    }
  }, [router])
  const [approvedUserCount, setApprovedUserCount] = useState();
  const approvedTraining = useCallback((Training) => {
    // async function getApprovedUser() {
    //   let trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
    //     PK: "TENANT#" + props?.TenantInfo.TenantID,
    //     SK: "TRAININGINFO#" + watch("ddlTraining")
    //   }, props.user?.signInUserSession?.accessToken?.jwtToken)
    let dataApproval = Training?.ApprovedCount != undefined ? Training?.ApprovedCount : 0
    let dataBatchSize = Training?.BatchSize != undefined ? Training?.BatchSize : 0
    setApprovedUserCount(dataApproval + "/" + dataBatchSize);
    avaliableCount(Training)
    // }
    // getApprovedUser()
  }, [avaliableCount])

  const [waitingUserCount, setWaitingUserCount] = useState();
  const waitingTraining = useCallback((Training) => {
    // async function getwaitingUser() {
    //   let trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
    //     PK: "TENANT#" + props?.TenantInfo.TenantID,
    //     SK: "TRAININGINFO#" + watch("ddlTraining")
    //   }, props.user?.signInUserSession?.accessToken?.jwtToken)
    let dataApproval = Training?.WaitingCount != undefined ? Training?.WaitingCount : 0
    let dataWaiting = Training?.WaitingList != undefined ? Training?.WaitingList : 0
    setWaitingUserCount(dataApproval + "/" + dataWaiting);
    avaliableCount(Training)
    // }
    // getwaitingUser()
  }, [avaliableCount])

  const [avaliableUserCount, setAvaliableUserCount] = useState();
  const avaliableCount = useCallback((training) => {
    let dataApproval = training?.BatchSize != undefined ? training?.BatchSize : 0
    // setAvaliableUserCount(dataApproval - training?.EnrollCount)
    setAvaliableUserCount(dataApproval - training?.ApprovedCount)
  }, [])


  const approveUser = useCallback(async (user) => {
    setisBeenCalled(true)
    let trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
      PK: "TENANT#" + props?.TenantInfo.TenantID,
      SK: "TRAININGINFO#" + watch("ddlTraining")
    }, props.user?.signInUserSession?.accessToken?.jwtToken)
    // let enrollCount = (trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != undefined || trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != null || trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != 0) ? trainingData?.res?.getXlmsTrainingManagement?.EnrollCount : 0
    let enrollCount = (trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount != undefined || trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != null || trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount != 0) ? trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount : 0
    let batchSize = (trainingData?.res?.getXlmsTrainingManagement?.BatchSize != undefined || trainingData?.res?.getXlmsTrainingManagement?.BatchSize != null || trainingData?.res?.getXlmsTrainingManagement?.BatchSize != 0) ? trainingData?.res?.getXlmsTrainingManagement?.BatchSize : 0
    if (enrollCount != batchSize) {
      if (user?.StatusFlag != "Approved" && user?.StatusFlag != "Rejected") {
        let fetchURL = process.env.APIGATEWAY_URL_TRAINING_ENROLL_UPLOADUSER;
        const finalData = [];
        finalData.push(
          user.UserSub,
        );

        let JsonInputData = '{ "NotificationSub":"","TrainingID":"' + user?.TrainingID + '","CreatedBy":"","CreatedDate":"","LastModifiedBy":"","LastModifiedDate":"","Type":"User","TenantID":"' + props?.TenantInfo.TenantID + '","UserDetails":' + JSON.stringify(finalData) + "}"

        let Headers = {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
            defaultrole: props?.TenantInfo.UserGroup,
            groupmenuname: "TrainingManagement",
            menuid: "400102",
            stateMachineArn: process.env.STEP_FUNCTION_ARN_TRAINING_ENROLL_UPLOADUSER,
          },
          body: JsonInputData,
        };
        let FinalStatus = await APIGatewayPostRequest(fetchURL, Headers);

        if (FinalStatus.Status == "Success") {
          let Variables = {
            input: {
              ...user,
              StatusFlag: "Approved",
              LastModifiedBy: Auth?.user?.username,
              LastModifiedDate: new Date()
            }
          }
          let Update = await AppsyncDBconnection(createXlmsTrainingSelfEnrollUserBatch, Variables, props.user?.signInUserSession?.accessToken?.jwtToken)

          if (user?.StatusFlag == "Rejected") {
            let rejectedCount = trainingData?.res?.getXlmsTrainingManagement?.RejectedCount < 0 ? 0 : trainingData?.res?.getXlmsTrainingManagement?.RejectedCount - 1;
            await AppsyncDBconnection(createXlmsBatchTrainingManagement,
              {
                input: [{
                  ...trainingData?.res?.getXlmsTrainingManagement,
                  RejectedCount: rejectedCount
                }, {
                  ...trainingData?.res?.getXlmsTrainingManagement,
                  SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
                  RejectedCount: rejectedCount
                }]
              },
              props.user?.signInUserSession?.accessToken?.jwtToken)
          }

          if (user?.StatusFlag == "Waiting") {
            let waitingCount = trainingData?.res?.getXlmsTrainingManagement?.WaitingCount < 0 ? 0 : trainingData?.res?.getXlmsTrainingManagement?.WaitingCount - 1;
            await AppsyncDBconnection(createXlmsBatchTrainingManagement,
              {
                input: [{
                  ...trainingData?.res?.getXlmsTrainingManagement,
                  WaitingCount: waitingCount
                }, {
                  ...trainingData?.res?.getXlmsTrainingManagement,
                  SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
                  WaitingCount: waitingCount
                }]
              },
              props.user?.signInUserSession?.accessToken?.jwtToken)
            waitingTraining(trainingData?.res?.getXlmsTrainingManagement)
          }

          /*To get updated count*/
          let trainingData1 = await AppsyncDBconnection(getXlmsTrainingManagement, {
            PK: "TENANT#" + props?.TenantInfo.TenantID,
            SK: "TRAININGINFO#" + watch("ddlTraining")
          }, props.user?.signInUserSession?.accessToken?.jwtToken)

          let approvedCount = (trainingData1?.res?.getXlmsTrainingManagement?.ApprovedCount == null || trainingData1?.res?.getXlmsTrainingManagement?.ApprovedCount == undefined || trainingData1?.res?.getXlmsTrainingManagement?.ApprovedCount == 0) ? 1 : trainingData1?.res?.getXlmsTrainingManagement?.ApprovedCount + 1;
          let variable = {
            input: [{
              ...trainingData1?.res?.getXlmsTrainingManagement,
              ApprovedCount: approvedCount
            }, {
              ...trainingData1?.res?.getXlmsTrainingManagement,
              SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData1?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
              ApprovedCount: approvedCount
            }]
          }
          await AppsyncDBconnection(createXlmsBatchTrainingManagement, variable, props.user?.signInUserSession?.accessToken?.jwtToken)

          // if (Update.Status == "Success") {
          //   let MailStatus;
          //   let MailUrl = process.env.APIGATEWAY_COURSE_APPROVAL_NOTIFICATION;

          //   let JsonSaveData = '{"TenantID":  "' + props?.TenantInfo.TenantID + '","UserSub": "' + user.UserSub + '", "CourseID": "' + user.CourseID + '"}';
          //   let Headers = {
          //     method: "POST",
          //     headers: {
          //       authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
          //       groupmenuname: "DashBoard",
          //       menuid: "122201",
          //     },
          //     body: JsonSaveData,
          //   };
          //   MailStatus = await APIGatewayPostRequest(MailUrl, Headers);
          // }
          approvedTraining(trainingData1?.res?.getXlmsTrainingManagement)
          refreshGrid()
          FinalResponse(Update.Status, "Accept");
        }
      }
    }
  }, [FinalResponse, approvedTraining, props?.TenantInfo.TenantID, props?.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, waitingTraining, watch])

  const [trainingData1, setTrainingData] = useState();
  const setCountTra = useCallback(() => {
    async function trainingData() {
      let trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
        PK: "TENANT#" + props?.TenantInfo.TenantID,
        SK: "TRAININGINFO#" + watch("ddlTraining")
      }, props.user?.signInUserSession?.accessToken?.jwtToken)
      if (watch("ddlTraining")) {
        waitingTraining(trainingData?.res?.getXlmsTrainingManagement)
        approvedTraining(trainingData?.res?.getXlmsTrainingManagement)
      }
      if (watch("ddlTraining") == "") {
        setAvaliableUserCount(0);
        setWaitingUserCount(0)
        setApprovedUserCount(0)
      }
      // let enrollCount = (trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != undefined || trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != null || trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != 0) ? trainingData?.res?.getXlmsTrainingManagement?.EnrollCount : 0
      let enrollCount = (trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount != undefined || trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount != null) ? trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount : 0
      let batchSize = (trainingData?.res?.getXlmsTrainingManagement?.BatchSize != undefined || trainingData?.res?.getXlmsTrainingManagement?.BatchSize != null || trainingData?.res?.getXlmsTrainingManagement?.BatchSize != 0) ? trainingData?.res?.getXlmsTrainingManagement?.BatchSize : 0
      let waitingList = (trainingData?.res?.getXlmsTrainingManagement?.WaitingList != undefined || trainingData?.res?.getXlmsTrainingManagement?.WaitingList != null) ? trainingData?.res?.getXlmsTrainingManagement?.WaitingList : 0
      let waitingCount = (trainingData?.res?.getXlmsTrainingManagement?.WaitingCount != undefined || trainingData?.res?.getXlmsTrainingManagement?.WaitingCount != null) ? trainingData?.res?.getXlmsTrainingManagement?.WaitingCount : 0
      setTrainingData({ EnrollCount: enrollCount, BatchSize: batchSize, WaitingList: waitingList, WaitingCount: waitingCount })
    } trainingData()
  }, [approvedTraining, props?.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, waitingTraining, watch])

  const RejectUser = useCallback(async (user) => {
    setisBeenCalled(true)
    if (user?.StatusFlag != "Rejected") {
      let Variables = {
        input: {
          ...user,
          StatusFlag: "Rejected",
          LastModifiedBy: Auth?.user?.username,
          LastModifiedDate: new Date()
        }
      }
      let Update = await AppsyncDBconnection(createXlmsTrainingSelfEnrollUserBatch, Variables, props.user?.signInUserSession?.accessToken?.jwtToken)

      if (user?.StatusFlag == "Approved") {
        let enrollData = await AppsyncDBconnection(getXlmsTrainingEnrollUser, {
          PK: "TENANT#" + props?.TenantInfo.TenantID + "#TRAININGID#" + watch("ddlTraining"),
          SK: "TRAINING#ENROLLUSER#USERSUB#" + user?.SK?.split("#USER#")[1]
        }, props.user?.signInUserSession?.accessToken?.jwtToken)
        let userDataResponse = await AppsyncDBconnection(getXlmsUserInfo, { PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "#USERINFO#" + user?.SK?.split("#USER#")[1] }, props.user?.signInUserSession?.accessToken?.jwtToken)
        let userData = userDataResponse?.res?.getXlmsUserInfo
        let variable1 = {
          input: [{
            ...enrollData?.res?.getXlmsTrainingEnrollUser,
            PK: "TENANT#" + props?.TenantInfo?.TenantID + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
            SK: "TRAININGID#" + watch("ddlTraining"),
            IsDeleted: true
          }, {
            ...enrollData?.res?.getXlmsTrainingEnrollUser,
            PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
            SK: "TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
            IsDeleted: true
          }, {
            ...enrollData?.res?.getXlmsTrainingEnrollUser,
            PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
            SK: "DEPARTMENT#" + userData?.Department + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
            IsDeleted: true
          }, {
            ...enrollData?.res?.getXlmsTrainingEnrollUser,
            PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
            SK: "DESIGNATION#" + userData?.Department + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
            IsDeleted: true
          }, {
            ...enrollData?.res?.getXlmsTrainingEnrollUser,
            PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
            SK: "TRAINING#ENROLLUSER#USERNAME#" + userData?.UserName,
            IsDeleted: true
          }, {
            ...enrollData?.res?.getXlmsTrainingEnrollUser,
            PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
            SK: "TRAINING#ENROLLUSER#EMAILID#" + userData?.EmailID,
            IsDeleted: true
          }, {
            ...enrollData?.res?.getXlmsTrainingEnrollUser,
            PK: "TENANT#" + props?.TenantInfo?.TenantID + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
            SK: "TRAINING#ENROLLUSER#CREATEDDATE#" + enrollData?.res?.getXlmsTrainingEnrollUser?.CreatedDate + "#" + watch("ddlTraining"),
            IsDeleted: true
          },]
        }
        await AppsyncDBconnection(createXlmsBatchTrainingEnrollUser, variable1, props.user?.signInUserSession?.accessToken?.jwtToken)
      }

      let trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
        PK: "TENANT#" + props?.TenantInfo.TenantID,
        SK: "TRAININGINFO#" + watch("ddlTraining")
      }, props.user?.signInUserSession?.accessToken?.jwtToken)
      const enrollCount = trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != undefined || trainingData?.res?.getXlmsTrainingManagement?.EnrollCount != null ? trainingData?.res?.getXlmsTrainingManagement?.EnrollCount - 1 : 0
      await AppsyncDBconnection(createXlmsBatchTrainingManagement,
        {
          input: [{
            ...trainingData?.res?.getXlmsTrainingManagement,
            EnrollCount: enrollCount
          }, {
            ...trainingData?.res?.getXlmsTrainingManagement,
            SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
            EnrollCount: enrollCount
          }]
        },
        props.user?.signInUserSession?.accessToken?.jwtToken)
      trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
        PK: "TENANT#" + props?.TenantInfo.TenantID,
        SK: "TRAININGINFO#" + watch("ddlTraining")
      }, props.user?.signInUserSession?.accessToken?.jwtToken)
      if (user?.StatusFlag == "Waiting") {
        let waitingCount = trainingData?.res?.getXlmsTrainingManagement?.WaitingCount < 0 ? 0 : trainingData?.res?.getXlmsTrainingManagement?.WaitingCount - 1;
        await AppsyncDBconnection(createXlmsBatchTrainingManagement,
          {
            input: [{
              ...trainingData?.res?.getXlmsTrainingManagement,
              WaitingCount: waitingCount
            }, {
              ...trainingData?.res?.getXlmsTrainingManagement,
              SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
              WaitingCount: waitingCount
            }]
          },
          props.user?.signInUserSession?.accessToken?.jwtToken)
        waitingTraining(trainingData?.res?.getXlmsTrainingManagement)
      }

      if (user?.StatusFlag == "Approved") {
        let approvedCount = trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount < 0 ? 0 : trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount - 1;
        await AppsyncDBconnection(createXlmsBatchTrainingManagement,
          {
            input: [{
              ...trainingData?.res?.getXlmsTrainingManagement,
              ApprovedCount: approvedCount
            }, {
              ...trainingData?.res?.getXlmsTrainingManagement,
              SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
              ApprovedCount: approvedCount
            }]
          },
          props.user?.signInUserSession?.accessToken?.jwtToken)
        approvedTraining(trainingData?.res?.getXlmsTrainingManagement)
      }

      /*To get updated count*/
      let trainingData1 = await AppsyncDBconnection(getXlmsTrainingManagement, {
        PK: "TENANT#" + props?.TenantInfo.TenantID,
        SK: "TRAININGINFO#" + watch("ddlTraining")
      }, props.user?.signInUserSession?.accessToken?.jwtToken)
      let rejectedCount = (trainingData1?.res?.getXlmsTrainingManagement?.RejectedCount == null || trainingData1?.res?.getXlmsTrainingManagement?.RejectedCount == undefined || trainingData1?.res?.getXlmsTrainingManagement?.RejectedCount == 0) ? 1 : trainingData1?.res?.getXlmsTrainingManagement?.RejectedCount + 1;
      let variable = {
        input: [{
          ...trainingData1?.res?.getXlmsTrainingManagement,
          RejectedCount: rejectedCount
        }, {
          ...trainingData1?.res?.getXlmsTrainingManagement,
          SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData1?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
          RejectedCount: rejectedCount
        }]
      }
      await AppsyncDBconnection(createXlmsBatchTrainingManagement, variable, props.user?.signInUserSession?.accessToken?.jwtToken)

      // if (Update.Status == "Success") {
      //   let MailStatus;
      //   let MailUrl = process.env.APIGATEWAY_COURSE_APPROVAL_NOTIFICATION;

      //   let JsonSaveData = '{"TenantID":  "' + props?.TenantInfo.TenantID + '","UserSub": "' + user.UserSub + '", "TrainingID": "' + user.TrainingID + '"}';
      //   let Headers = {
      //     method: "POST",
      //     headers: {
      //       authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
      //       groupmenuname: "DashBoard",
      //       menuid: "122202",
      //     },
      //     body: JsonSaveData,
      //   };
      //   MailStatus = await APIGatewayPostRequest(MailUrl, Headers);
      // }
      refreshGrid()
      FinalResponse(Update.Status, "Reject")
    }
  }, [FinalResponse, approvedTraining, props?.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, waitingTraining, watch])

  /*Waiting User List*/
  const waitingUser = useCallback(async (user) => {
    setisBeenCalled(true)
    let trainingData = await AppsyncDBconnection(getXlmsTrainingManagement, {
      PK: "TENANT#" + props?.TenantInfo.TenantID,
      SK: "TRAININGINFO#" + watch("ddlTraining")
    }, props.user?.signInUserSession?.accessToken?.jwtToken)
    let waitingList = (trainingData?.res?.getXlmsTrainingManagement?.WaitingList != undefined || trainingData?.res?.getXlmsTrainingManagement?.WaitingList != null || trainingData?.res?.getXlmsTrainingManagement?.WaitingList != 0) ? trainingData?.res?.getXlmsTrainingManagement?.WaitingList : 0
    let waitingCount = (trainingData?.res?.getXlmsTrainingManagement?.WaitingCount != undefined || trainingData?.res?.getXlmsTrainingManagement?.WaitingCount != null || trainingData?.res?.getXlmsTrainingManagement?.WaitingCount != 0) ? trainingData?.res?.getXlmsTrainingManagement?.WaitingCount : 0
    if (waitingList != waitingCount) {
      if (user?.StatusFlag != "Waiting" && user?.StatusFlag != "Rejected") {
        let Variables = {
          input: {
            ...user,
            StatusFlag: "Waiting",
            LastModifiedBy: Auth?.user?.username,
            LastModifiedDate: new Date()
          }
        }
        let Update = await AppsyncDBconnection(createXlmsTrainingSelfEnrollUserBatch, Variables, props.user?.signInUserSession?.accessToken?.jwtToken)

        if (user?.StatusFlag == "Approved") {
          let enrollData = await AppsyncDBconnection(getXlmsTrainingEnrollUser, {
            PK: "TENANT#" + props?.TenantInfo.TenantID + "#TRAININGID#" + watch("ddlTraining"),
            SK: "TRAINING#ENROLLUSER#USERSUB#" + user?.SK?.split("#USER#")[1]
          }, props.user?.signInUserSession?.accessToken?.jwtToken)
          let userDataResponse = await AppsyncDBconnection(getXlmsUserInfo, { PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "#USERINFO#" + user?.SK?.split("#USER#")[1] }, props.user?.signInUserSession?.accessToken?.jwtToken)
          let userData = userDataResponse?.res?.getXlmsUserInfo
          let variable1 = {
            input: [{
              ...enrollData?.res?.getXlmsTrainingEnrollUser,
              PK: "TENANT#" + props?.TenantInfo?.TenantID + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
              SK: "TRAININGID#" + watch("ddlTraining"),
              IsDeleted: true
            }, {
              ...enrollData?.res?.getXlmsTrainingEnrollUser,
              PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
              SK: "TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
              IsDeleted: true
            }, {
              ...enrollData?.res?.getXlmsTrainingEnrollUser,
              PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
              SK: "DEPARTMENT#" + userData?.Department + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
              IsDeleted: true
            }, {
              ...enrollData?.res?.getXlmsTrainingEnrollUser,
              PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
              SK: "DESIGNATION#" + userData?.Department + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
              IsDeleted: true
            }, {
              ...enrollData?.res?.getXlmsTrainingEnrollUser,
              PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
              SK: "TRAINING#ENROLLUSER#USERNAME#" + userData?.UserName,
              IsDeleted: true
            }, {
              ...enrollData?.res?.getXlmsTrainingEnrollUser,
              PK: "TENANT#" + props?.TenantInfo?.TenantID + " #TRAININGID#" + watch("ddlTraining"),
              SK: "TRAINING#ENROLLUSER#EMAILID#" + userData?.EmailID,
              IsDeleted: true
            }, {
              ...enrollData?.res?.getXlmsTrainingEnrollUser,
              PK: "TENANT#" + props?.TenantInfo?.TenantID + "#TRAINING#ENROLLUSER#" + user?.SK?.split("#USER#")[1],
              SK: "TRAINING#ENROLLUSER#CREATEDDATE#" + enrollData?.res?.getXlmsTrainingEnrollUser?.CreatedDate + "#" + watch("ddlTraining"),
              IsDeleted: true
            },]
          }
          await AppsyncDBconnection(createXlmsBatchTrainingEnrollUser, variable1, props.user?.signInUserSession?.accessToken?.jwtToken)
        }

        if (user?.StatusFlag == "Approved") {
          let approvedCount = trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount < 0 ? 0 : trainingData?.res?.getXlmsTrainingManagement?.ApprovedCount - 1;
          await AppsyncDBconnection(createXlmsBatchTrainingManagement,
            {
              input: [{
                ...trainingData?.res?.getXlmsTrainingManagement,
                ApprovedCount: approvedCount
              }, {
                ...trainingData?.res?.getXlmsTrainingManagement,
                SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
                ApprovedCount: approvedCount
              }]
            },
            props.user?.signInUserSession?.accessToken?.jwtToken)
          approvedTraining(trainingData?.res?.getXlmsTrainingManagement)
        }

        if (user?.StatusFlag == "Rejected") {
          let rejectedCount = trainingData?.res?.getXlmsTrainingManagement?.RejectedCount < 0 ? 0 : trainingData?.res?.getXlmsTrainingManagement?.RejectedCount - 1;
          await AppsyncDBconnection(createXlmsBatchTrainingManagement,
            {
              input: [{
                ...trainingData?.res?.getXlmsTrainingManagement,
                RejectedCount: rejectedCount
              }, {
                ...trainingData?.res?.getXlmsTrainingManagement,
                SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
                RejectedCount: rejectedCount
              }]
            },
            props.user?.signInUserSession?.accessToken?.jwtToken)
        }

        /*To get updated count*/
        let trainingData1 = await AppsyncDBconnection(getXlmsTrainingManagement, {
          PK: "TENANT#" + props?.TenantInfo.TenantID,
          SK: "TRAININGINFO#" + watch("ddlTraining")
        }, props.user?.signInUserSession?.accessToken?.jwtToken)
        let waitingCount = (trainingData1?.res?.getXlmsTrainingManagement?.WaitingCount == null || trainingData1?.res?.getXlmsTrainingManagement?.WaitingCount == undefined || trainingData1?.res?.getXlmsTrainingManagement?.WaitingCount == 0) ? 1 : trainingData1?.res?.getXlmsTrainingManagement?.WaitingCount + 1;
        let variable = {
          input: [{
            ...trainingData1?.res?.getXlmsTrainingManagement,
            WaitingCount: waitingCount
          }, {
            ...trainingData1?.res?.getXlmsTrainingManagement,
            SK: "TRAININGINFO#LASTMODIFIEDDATE#" + trainingData1?.res?.getXlmsTrainingManagement?.LastModifiedDate + "#TRAININGID#" + watch("ddlTraining"),
            WaitingCount: waitingCount
          }]
        }
        await AppsyncDBconnection(createXlmsBatchTrainingManagement, variable, props.user?.signInUserSession?.accessToken?.jwtToken)

        // if (Update.Status == "Success") {
        //   let MailStatus;
        //   let MailUrl = process.env.APIGATEWAY_COURSE_APPROVAL_NOTIFICATION;

        //   let JsonSaveData = '{"TenantID":  "' + props?.TenantInfo.TenantID + '","UserSub": "' + user.UserSub + '", "CourseID": "' + user.CourseID + '"}';
        //   let Headers = {
        //     method: "POST",
        //     headers: {
        //       authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
        //       groupmenuname: "DashBoard",
        //       menuid: "122202",
        //     },
        //     body: JsonSaveData,
        //   };
        //   MailStatus = await APIGatewayPostRequest(MailUrl, Headers);
        // }
        waitingTraining(trainingData1?.res?.getXlmsTrainingManagement)
        refreshGrid()
        FinalResponse(Update.Status, "Waiting")
      }
    }
  }, [FinalResponse, approvedTraining, props?.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, waitingTraining, watch])

  const GridDataBind = useCallback((viewData) => {
    setValue("EnrollUserCount", viewData?.length)
    const RowGrid = [];
    viewData?.map((getItem, index) => {
      const resrictDate = approvalData?.TrainingData?.some((item) => {
        return (getItem?.TrainingID == item?.TrainingID) ? (new Date(item?.StartDate) <= new Date()) : "";
      })
      RowGrid.push({
        UserName: (<NVLlabel id={"lblName" + (index + 1)} name="PK" text={getItem.UserName} className="p-2" />),
        FirstName: (<NVLlabel id={"lblFName" + (index + 1)} name="FName" text={getItem?.FirstName} className="p-2" />),
        LastName: (<NVLlabel id={"lblFName" + (index + 1)} name="FName" text={getItem?.LastName} className="p-2" />),
        EmailID: (<NVLlabel id={"lblEmail" + (index + 1)} name="PK" text={getItem.EmailID} />),
        Status: (<>
          <div className="flex">
            {isBeenCalled}
            <NVLButton id={"txtApprove" + (index + 1)} text={"Approve"} disabled={getItem?.StatusFlag == "Approved" || (trainingData1?.EnrollCount == trainingData1?.BatchSize) || (resrictDate) ? true : false} className={`${isBeenCalled ? "pointer-events-none !text-gray-500" : ""}  ${getItem?.StatusFlag == "Approved" ? "text-green-500" : ""} ${getItem?.StatusFlag == "Rejected" ? "invisible" : ""} pr-4  hover:text-teal-600`} onClick={() => approveUser(getItem)} />
            <NVLButton id={"txtReject" + (index + 1)} text={"Reject"} disabled={getItem?.StatusFlag == "Rejected" || (resrictDate) ? true : false} className={`${isBeenCalled ? "pointer-events-none !text-gray-500" : ""} ${getItem?.StatusFlag == "Rejected" ? "text-red-500" : ""} pr-4  hover:text-teal-600`} onClick={() => RejectUser(getItem)} />
            <NVLButton id={"txtWaitingList" + (index + 1)} text={"Waiting"} disabled={getItem?.StatusFlag == "Waiting" || (trainingData1?.WaitingCount == trainingData1?.WaitingList) || (resrictDate) ? true : false} className={`${isBeenCalled ? "pointer-events-none !text-gray-500" : ""} ${getItem?.StatusFlag == "Waiting" ? "text-yellow-500" : ""} ${getItem?.StatusFlag == "Rejected" ? "invisible" : ""} pr-4  hover:text-teal-600`} onClick={() => waitingUser(getItem)} />
          </div>
        </>),
      })
    })
    return RowGrid;
  }, [setValue, approvalData?.TrainingData, isBeenCalled, trainingData1?.EnrollCount, trainingData1?.BatchSize, trainingData1?.WaitingCount, trainingData1?.WaitingList, approveUser, RejectUser, waitingUser]
  );
  const variable = useMemo(() => {
    if (!isRefreshing)
      setIsRefreshing(true);
    let sk = watch("ddlTraining") != "" ? "SELFENROLLUSER#TRAINING#" + watch("ddlTraining") : ""
    return {
      PK: "TENANT#" + props.TenantInfo.TenantID,
      SK: sk,
      ReportManagerEmail: props?.user?.attributes?.email,
      ListType: "ReportingManager"
    }
  }, [isRefreshing, props.TenantInfo.TenantID, props?.user?.attributes?.email, watch]);

  // Bread Crumbs
  const PageRoutes = useMemo(() => { return [{ path: "", breadcrumb: "Approval Request" }] }, []);

  return (
    <>
      <Container title="TrainingApproval" loader={approvalData == undefined} PageRoutes={PageRoutes}>
        <NVLAlert
          ButtonYestext={"X"}
          MessageTop={modalValues.ModalTopMessage}
          MessageBottom={modalValues.ModalBottomMessage}
          ModalOnClick={modalValues.ModalOnClickEvent}
          ModalInfo={modalValues.ModalInfo}
        />
        <div className={`${isBeenCalled ? "pointer-events-none" : ""}`}>
          <div className=" mx-auto grid gap-8 md:w-[500px] w-full">
            <div className="flex flex-col sm:flex-row  gap-9">
              <NVLlabel text="Training Name" className="nvl-Def-Label pt-2" />
              <NVLSelectField disabled={watch("ddlCategory") == "" ? true : false} id="ddlTraining" errors={errors} register={register} options={trainingList} className={`w-64 md:w-72 `} />
            </div>
            <div className={`flex justify-between w-100 bg-red `}>
              <NVLlabel text={`Available Users : `} className="nvl-Def-Label pt-1" />
              <span className=" bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                {avaliableUserCount == undefined ? "0" : avaliableUserCount}</span>
              <NVLlabel text={`Approved Users : `} className="nvl-Def-Label pt-1" />
              <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                {approvedUserCount == undefined ? "0" : approvedUserCount}</span>
              <NVLlabel text={`Waiting User : `} className="nvl-Def-Label pt-1" />
              <span className="bg-blue-100 text-blue-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-blue-900 dark:text-blue-300">
                {waitingUserCount == undefined ? "0" : waitingUserCount}</span>
            </div>
          </div>
          <div className={`pt-4`}>
            <NVLGridTable
              refershPage={isRefreshing}
              id="tblSelfEnroll"
              className="max-w-full"
              HeaderColumn={HeaderColumn}
              GridDataBind={GridDataBind}
              query={listXlmsTrainingSelfEnrollUserbyStatusFlag}
              querryName={"listXlmsTrainingSelfEnrollUserbyStatusFlag"}
              variable={variable}
              user={props?.user}
            />
          </div>
        </div>
      </Container>
    </>
  )
}

export default TrainingApproval;



