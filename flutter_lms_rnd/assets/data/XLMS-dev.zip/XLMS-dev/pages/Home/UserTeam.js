import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Bar } from "react-chartjs-2";
import { useForm } from "react-hook-form";
import { listXlmsTenantInfos } from "src/graphql/queries";
import UserWiseCourseMailing from "../Analytics&Reports/UserWiseCourseMailing";
Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

function UserTeam(props) {
    const [data, setData] = useState();
    const router = useRouter();
    useEffect(() => {
        const dataSource = async () => {
            const userName = decodeURIComponent(String(router.query["UserName"]));
            const emailId = decodeURIComponent(String(router.query["EmailId"]));
            const tenantId = decodeURIComponent(String(router.query["TenantId"]));
            const fetchTenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            const fetchUserTeam = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    menuid: "114401",
                    tenantid: tenantId,
                    emailid: emailId,
                },
                body:"WHERE Status='Active'"
            });
            const fetchUserTeamData = await fetchUserTeam?.res?.text();
            setData({
                TenantList: fetchTenantInfo.res?.listXlmsTenantInfos?.items != undefined ? fetchTenantInfo.res?.listXlmsTenantInfos?.items : [],
                pTenantID: props.user.attributes["custom:tenantid"],
                UserTeamData: fetchUserTeamData,
                pEmailID: emailId,
                pUserName: userName,
                lstrFilterloginData: fetchUserTeamData
            });
        };
        dataSource();
        return (() => {
            setData((temp) => { return { ...temp }; });
        });
    }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query]);

    const formOptions = { mode: "onChange" };
    const { handleSubmit, setValue, watch } = useForm(formOptions);
    const execID = useRef();
    const refRecordStatus = useRef();
    const [info, setInfo] = useState({ PopupName: "", UserEmail: ""});
    const [popupName, setPopupName] = useState("");
    const [open, setOpen] = useState(false);

    const initialModalState = useMemo(() => {
        return {
            ModalInfo: "Success",
            ModalTopMessage: "Success",
            ModalBottomMessage: "Mail sent successfully.",
            ModalOnClickEvent: () => {
                props?.TenantInfo?.UserGroup=="Manager"? router.push(`/Home/UserTeam?EmailId=${(String(router.query["EmailId"]))}&UserName=${(String(router.query["UserName"]))}&TenantId=${(String(router.query["TenantId"]))}`) :router.push("/Analytics&Reports/UserWiseCourseSummary");
            }
        };
    }, [router,props?.TenantInfo?.UserGroup]);

    const [modalValues, setModalValues] = useState(initialModalState);

    const headerColumn = [
        { HeaderName: "User Name", Columnvalue: "UserName", HeaderCss: "w-1/2" },
        { HeaderName: "Department", Columnvalue: "Department", HeaderCss: "w-1/2" },
        { HeaderName: "Designation", Columnvalue: "Designation", HeaderCss: "w-1/2" },
        { HeaderName: "Courses Enrolled", Columnvalue: "CoursesEnrolled", HeaderCss: "w-1/2" },
        { HeaderName: "Courses Completed", Columnvalue: "CoursesCompleted", HeaderCss: "w-1/2" },
        { HeaderName: "Total Seat Time", Columnvalue: "TotalSeatTime", HeaderCss: "w-1/2" },
        { HeaderName: "Notification", Columnvalue: "Notification", HeaderCss: "w-1/2" },
        { HeaderName: "Team", Columnvalue: "Team", HeaderCss: "w-1/2" },
    ];

    const finalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        }
        setModalValues(initialModalState);
        ModalOpen();

    }, [initialModalState]);

    const fileDownload = useCallback(
        async (e) => {
            setValue("download", true);
            let ExecuteQueryID;
            const lstrTenantID =  decodeURIComponent(String(router.query["TenantId"]))

            try {
                const lGetUserTeamData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                        menuid: "114400",
                        tenantid: lstrTenantID,
                        emailid: data?.pEmailID,
                    },
                    body:"WHERE Status='Active'"
                });

                const fetchUserTeamData = await lGetUserTeamData?.res?.text();

                ExecuteQueryID = fetchUserTeamData != undefined ? JSON?.parse(fetchUserTeamData) : undefined;

                if (e?.type == "click" && fetchUserTeamData != undefined) {
                    const lstrPresignedFileURL = process.env.APIGATEWAY_INVOKEURL;
                    const headers = {
                        method: "POST",
                        headers: {
                            "Content-Type": "text/csv",
                            authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                            bucketname: process.env.REPORT_BUCKET_NAME,
                        },
                        body: `processed-data/${lstrTenantID}/${ExecuteQueryID?.QueryExecutionID}.csv`,
                    };
                    const lstrFileDownload = await APIGatewayPostRequest(lstrPresignedFileURL, headers);
                    var win = window.open(await lstrFileDownload.res?.text(), "_self");
                }
            } catch (error) { return error }
            setValue("download", false);
        },
        [setValue, router.query, props?.user?.signInUserSession?.accessToken?.jwtToken, data?.pEmailID]
    );

    const gridDataBind = useCallback(() => {

        if (data?.lstrFilterloginData != undefined) {
            const rowGrid = [];

            const tmpviewData = data.lstrFilterloginData != undefined && Object.values(JSON.parse(data.lstrFilterloginData));

            const viewData = tmpviewData?.[1] != undefined && JSON.parse(tmpviewData?.[1]);
            execID.current = data.lstrFilterloginData != undefined && JSON.parse(data.lstrFilterloginData);
            viewData &&
                viewData.map((getItem, index) => {
                    rowGrid.push({
                        UserName: getItem && Object.entries(getItem).length != 0 &&
                        <NVLLink id={"txtUser" + (index + 1)} title={data?.pUserName} onClick={() => router.push(`/Home/ELearningReport?UserName=${data?.pUserName}&EmailId=${data?.pEmailID}&UserSub=${getItem?.usersub}&TenantId=${decodeURIComponent(String(router.query["TenantId"]))}`)} text={getItem?.UserName} className=" cursor-pointer" ></NVLLink>,

                        Department: <NVLlabel id={"txtdept" + (index + 1)} text={getItem.Department} />,
                        Designation: <NVLlabel id={"txtDesg" + (index + 1)} text={getItem.Designation} />,
                        CoursesEnrolled: <NVLlabel id={"txtEnrolled" + (index + 1)} text={getItem.CoursesEnrolled} className="pl-10" />,
                        CoursesCompleted: <NVLlabel id={"txtCompleted" + (index + 1)} text={getItem.CoursesCompleted} className="pl-10" />,
                        TotalSeatTime: <NVLlabel id={"txtTime" + index + 1} text={getItem.TotalSeatTime} />,
                        Notification: getItem && Object.entries(getItem).length != 0 && <NVLLink id={"txtNotify" + (index + 1)} title={"Mail"} text={"Mail"} className="cursor-pointer"
                            onClick={() => {
                                setInfo((temp) => { return ({ ...temp, PopupName: "Mail", UserEmail: getItem.EmailId }) })
                                setOpen((open) => {
                                    return open + 1;
                                });
                            }}></NVLLink>,
                        Team: getItem && Object.entries(getItem).length != 0 &&(getItem?.TEAM=="-")?(<NVLlabel id={"txtUserTeam" + index + 1} text={getItem.TEAM} />):(<NVLLink id={"txtTeam" + (index + 1)}
                            title={getItem?.TEAM} onClick={() => router.push(`/Home/UserTeam?EmailId=${getItem.EmailId}&UserName=${getItem.UserName}&TenantId=${decodeURIComponent(String(router.query["TenantId"]))}`)}
                            text={getItem?.TEAM} className={getItem?.TEAM!="-"?"cursor-pointer":"cursor-not-allowed"} ></NVLLink>),

                    });
                    if (Object.entries(getItem).length == 0){
                        rowGrid=[]
                    }
                    refRecordStatus.current = getItem && Object.entries(getItem).length !=0 ? "Exist" : "NoRecord";
                });
            
            return rowGrid;
        }

    }, [data?.lstrFilterloginData, data?.pUserName, data?.pEmailID, router]);

    // Bar chart

    const getUsername = useCallback(() => {
        if (data?.UserTeamData != undefined) {
            const tmpviewData = data.lstrFilterloginData != undefined && Object.values(JSON?.parse(data.lstrFilterloginData));
            const viewData = tmpviewData?.[1] != undefined && JSON.parse(tmpviewData?.[1]);

            const usernameList = [];
            if (viewData != false) {
                viewData?.map((getItem) => {
                    usernameList.push(getItem.UserName);
                });
                return usernameList;
            }
        }
    }, [data?.UserTeamData, data?.lstrFilterloginData]);

    const getCourseEnrolledCount = useCallback(() => {
        if (data?.UserTeamData != undefined) {
            const tmpviewData = data.lstrFilterloginData != undefined && Object.values(JSON?.parse(data.lstrFilterloginData));
            const viewData = tmpviewData?.[1] != undefined && JSON.parse(tmpviewData?.[1]);
            let CourseUserCount = [];

            CourseUserCount = viewData && viewData.map((getItem) => {
                CourseUserCount.push(getItem.CoursesEnrolled);
                return CourseUserCount;
            }, {});
            return CourseUserCount[0];
        }
    }, [data?.UserTeamData, data?.lstrFilterloginData]);

    const getCourseCompletedCount = useCallback(() => {
        if (data?.UserTeamData != undefined) {
            const tmpviewData = data.lstrFilterloginData != undefined && Object.values(JSON?.parse(data.lstrFilterloginData));
            const viewData = tmpviewData?.[1] != undefined && JSON.parse(tmpviewData?.[1]);
            let CourseCompletedUserCount = [];

            CourseCompletedUserCount = viewData && viewData.map((getItem) => {
                CourseCompletedUserCount.push(getItem.CoursesCompleted);
                return CourseCompletedUserCount;
            }, {});
            return CourseCompletedUserCount[0];
        }
    }, [data?.UserTeamData, data?.lstrFilterloginData]);
    const newsdata2 = {
        labels: getUsername(),

        datasets: [
            {
                data: getCourseEnrolledCount(),
                backgroundColor: ["blue"],
                barThickness: 30,
                label: "Course Enrolled"
            },
            {
                data: getCourseCompletedCount(),
                backgroundColor: ["black"],
                barThickness: 30,
                label: "Course Completed"

            },
        ],
    };
    const pageRoutes = useMemo(() => {
        if(props?.TenantInfo?.UserGroup!="Manager"){
        return [
            { path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard" },
            { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
            { path: `/Analytics&Reports/UserWiseCourseSummary?TenantId=${decodeURIComponent(String(router.query["TenantId"]))}`, breadcrumb: "User Wise Course Summary" },
            { path: "", breadcrumb: "User Team" }
        ];
    }else{
        return [{ path: "", breadcrumb: "User Team" }];   
    }
    }, [router.query,props?.TenantInfo?.UserGroup]);

    const getComponent = useCallback(
        PopupName => {
            const componentData = {
                Mail: (
                    <UserWiseCourseMailing
                        user={props?.user}
                        open={open}
                        setOpen={setOpen}
                        TenantInfo={props.TenantInfo}
                        Mode="Popup"
                        modalValues={modalValues}
                        FinalResponse={finalResponse}
                        UserEmail={info.UserEmail}
                    />
                ),
            };
            return componentData[info["PopupName"]];
        },
        [finalResponse, info, modalValues, open, props.TenantInfo, props?.user]
    );


    return (
        <>
            <NVLPageModalPopup
                ModalType="Page"
                ScreenName={"Course Notification Mail"}
                PageComponent={getComponent(popupName)}
                open={open}
                setOpen={setOpen}
                user={props?.user}
            />
            <Container title="User Course Summary Report" PageRoutes={pageRoutes} loader={data?.TenantList == undefined}>

                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />

                <form className="px-2">
                    <div className='flex justify-between'>
                        <NVLlabel text={`Reporting Users Below : ${data?.pUserName}`} showFull
                            className="nvl-Def-Label pl-6 my-auto" />
                        <div className="col-span-6 sm:col-span-3 pt-4 px-4">
                            <div className="flex items-center">
                                <NVLButton type={"button"} 
                                className={refRecordStatus.current == "NoRecord" ? "nvl-button bg-primary Disabled !h-10" : "nvl-button !bg-primary  text-white  shadow-sm hover:bg-primary focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 !h-10" }
                                disabled={refRecordStatus.current == "NoRecord" ? true : false}
                                onClick={(e) => fileDownload(e)}>
                                    <i className={`${watch("download") ? " fa fa-circle-notch fa-spin" : " fa-solid fa-download"}  `}></i>
                                </NVLButton>
                                <div className="pb-2 pl-1">
                                    <NVLlabel
                                        CustomCss="-translate-x-72 pt-4"
                                        className="nvl-Def-Label pb-1"
                                        HelpInfo={"You can download more report details here"}
                                        HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <Bar
                        data={newsdata2}
                        options={{
                            cutoutPercentage: 90,
                            responsive: true,
                            aspectRatio: 4,
                            plugins: {
                                legend: {
                                    display: false,
                                },
                            },
                            scales: {
                                x: {
                                    grid: {
                                        display: false,
                                    },
                                },
                            },
                        }}
                    />
                    <br />
                    <NVLGridTable id="tblUserList" className="max-w-full" HeaderColumn={headerColumn}
                        RowGridDataPass={{ RowGrid: gridDataBind() }} />

                </form>

            </Container>
        </>
    );
}

export default UserTeam;
