import Container from '@components/Container/Container';
import { APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { getXlmsTenantInfo, getXlmsUserInfo, listXlmsCustomFields } from "src/graphql/queries";
import CompanyAdminProfile from './CompanyAdminProfile';
import UserProfile from './UserProfile';

export default function ViewProfile(props) {
    const router = useRouter();
    const [PageData, setPageData] = useState(props)
    const [UplodError, setUplodError] = useState("")
    const [ProfileData, setProfileData] = useState(PageData?.ProfileData)
    const SavedImageUrl = useRef({ CurrentPath: FetchProfileURL, IncomingPath: FetchProfileURL, ProfileName: "", IsUpload: false })
    const PageRoutes = useMemo(() => {
        return [{ path: "", breadcrumb: "My Profile" }];
    }, []);
    useEffect(() => {
        async function fetchData() {
            let user = props.user;
            let AuthorizedToken = user?.signInUserSession?.accessToken?.jwtToken;
            var TenantID = user.attributes["custom:tenantid"];
            var sub = user.attributes["sub"];
            let TenantData, UserType;
            const UserResponse = await AppsyncDBconnection(getXlmsUserInfo, { PK: "TENANT#" + TenantID, SK: "#USERINFO#" + sub, }, AuthorizedToken);
            if (UserResponse?.res?.getXlmsUserInfo == null) {
                const tenantResponse = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + TenantID, }, AuthorizedToken);
                TenantData = tenantResponse?.res?.getXlmsTenantInfo;
                UserType = "CompanyAdmin";
            } else {
                TenantData = UserResponse?.res?.getXlmsUserInfo;
                UserType = "User";
            }

            const CustomFieldsResponse = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + TenantID, SK: "CUSTOMFIELD#" }, AuthorizedToken);
            setPageData((data) => {
                return {
                    ...data,
                    UserType: UserType,
                    UserCustomFields: CustomFieldsResponse?.res?.listXlmsCustomFields?.items,
                    ProfileData: TenantData,
                }
            })
            setProfileData((data) => {
                return { ...TenantData }
            })
        }
        fetchData();
        return (() => {
            setPageData((data) => {
                return { ...data }
            })
        })
    }, [props.user, router.query])
    const FetchProfileURL = useMemo(() => {
        let TempURL = "/defaultphoto.jpg";
        if (PageData?.UserType == "User") {
            if (ProfileData?.ProfileURLPath) {
                TempURL = ProfileData?.ProfileURLPath;
                SavedImageUrl.current = { CurrentPath: TempURL, IncomingPath: TempURL, ProfileName: "", IsUpload: false }
                return TempURL;
            }
        } else {
            if (ProfileData?.LogoUrlPath) {
                TempURL = ProfileData?.LogoUrlPath;
                SavedImageUrl.current = { CurrentPath: TempURL, IncomingPath: TempURL, ProfileName: "", IsUpload: false }
                return TempURL;
            }
        }
    }, [PageData?.UserType, ProfileData?.LogoUrlPath, ProfileData?.ProfileURLPath])

    const [UploadLoder, setUploadLoder] = useState({ unsavedLoader: false, savedLoader: false })


    const ProfileGoToUnsaved = useCallback(async (e) => {
        if (e.target.files) {
            setUploadLoder((data) => {
                return { ...data, unsavedLoader: true }
            });
            let FileData = e.target.files[0];
            let Extension = FileData?.name.substring(FileData?.name.lastIndexOf(".") + 1).toLowerCase();
            if (process.env.USERPROFILE_EXTENTION.indexOf(Extension) <= -1) {
                setUplodError("Please upload only .jpg, .jpeg, .png file!");
                setUploadLoder((data) => {
                    return { ...data, unsavedLoader: false }
                });
            } else if (FileData.size > process.env.USERPROFILE_SIZE) {
                setUplodError("File size should be 50KB");
                setUploadLoder((data) => {
                    return { ...data, unsavedLoader: false }
                });
            } else {
                const createFile = (bits, name) => {
                    try {
                        return new File(bits, name, { type: "image/" + name.split(".").pop(), lastModified: new Date() });
                    } catch (e) {
                        var myBlob = new Blob(bits);
                        myBlob.lastModified = new Date();
                        myBlob.name = name;
                        return myBlob;
                    }
                };
                let FileName = FileData.name;
                if (((FileData.name.split(".").pop() == "jpg" && FileData.type.split("/").pop() == "jpeg") || (FileData.name.split(".").pop() == "jpeg" && FileData.type.split("/").pop() == "jpg"))) {
                    FileName = FileName.split(".")[0] + "." + FileData.type.split("/").pop();
                    FileData = createFile([FileData], crypto.randomUUID() + "." + FileData.type.split("/").pop());

                }
                setUplodError("");
                let tempPresignedURL = PageData?.UserType == "User" ? process.env.COMPANYLOGO_PRESIGNED_URL_S3_BUCKET : process.env.COMPANYLOGOEDIT_PRESIGNED_URL_S3_BUCKET;
                const requestOptions = {
                    method: "GET",
                    headers: {
                        authorizationtoken: PageData?.user?.signInUserSession?.accessToken?.jwtToken,
                        defaultrole: PageData?.UserType == "User" ? PageData?.TenantInfo?.UserGroup : "CompanyAdmin",
                        groupmenuname: "CompanyManagement",
                        menuid: PageData?.UserType == "User" ? "100401" : "100201",
                    }
                };
                let presignedHeader = {
                    method: "PUT",
                    body: FileData,
                };
                let Url;
                if (PageData?.UserType == "User") {
                    Url = tempPresignedURL + `?ProfileImgName=${FileData?.name}&isUser=${"true"}&TenantID=${props?.TenantInfo?.TenantID}&BucketName=${props?.TenantInfo?.BucketName}&RootFolder=${props?.TenantInfo?.RootFolder}&S3KeyName=${PageData?.TenantInfo?.RootFolder}/${props?.TenantInfo?.TenantID}&S3BucketName=${PageData?.TenantInfo?.BucketName}&BucketName=${PageData?.TenantInfo?.BucketName}`;
                } else {
                    Url = tempPresignedURL + `?logoname=${FileData?.name}&RootFolder=${props?.TenantInfo?.RootFolder}&S3KeyName=${props?.TenantInfo?.RootFolder}/${props?.TenantInfo?.TenantID}&S3BucketName=${props?.TenantInfo?.BucketName}&BucketName=${props?.TenantInfo?.BucketName}&tenantId=${props?.TenantInfo?.TenantID}`;
                }
                let FinalStatus = await APIGatewayPutRequest(Url, requestOptions, presignedHeader);
                if (FinalStatus?.[0] == "Success") {
                    SavedImageUrl.current = { ...SavedImageUrl?.current, IncomingPath: URL.createObjectURL(FileData), ProfileName: FileData?.name, IsUpload: true }
                    if (PageData?.UserType == "User") {
                        ProfileUrlMoveUnsavedToSaved()
                    }
                    setUploadLoder((data) => {
                        return { ...data, unsavedLoader: false }
                    });

                }
            }
        }
    }, [PageData, props,ProfileUrlMoveUnsavedToSaved])
    const ProfileUrlMoveUnsavedToSaved = useCallback(async (e) => {
        if (PageData?.UserType == "User") {
            setUploadLoder((data) => {
                return { ...data, savedLoader: true }
            });
            let setUploadURL = process.env.APIGATEWAY_URL_UPDATE_USER_PROFILE + `?FileName=${SavedImageUrl?.current?.ProfileName}&isUser=${"true"}&TenantID=${PageData?.TenantInfo?.TenantID}&BucketName=${PageData.TenantInfo.BucketName}&RootFolder=${PageData.TenantInfo.RootFolder}&S3KeyName=${PageData.TenantInfo.RootFolder}/${PageData.TenantInfo.TenantID}&S3BucketName=${PageData.TenantInfo.BucketName}`;
            await fetch(setUploadURL, {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                    authorizationtoken: PageData.user.signInUserSession.accessToken.jwtToken,
                    defaultrole: PageData?.ProfileData?.RoleName,
                    groupmenuname: "UserManagement",
                    menuid: "200101",
                    usersub: PageData?.user?.attributes?.["sub"]
                },
            })
                .then((response) => response.text())
                .then((res) => {
                    if (res == "Success") {
                        SavedImageUrl.current = { ...SavedImageUrl?.current, CurrentPath: SavedImageUrl?.current?.IncomingPath, IsUpload: false }
                        setUploadLoder((data) => {
                            return { ...data, savedLoader: false }
                        });
                    }
                });

        } else {
            setUploadLoder((data) => {
                return { ...data, savedLoader: true }
            });
            let stateURL = process.env.STEP_FUNCTION_ARN_COMPANYEDIT;
            let setUploadURL = process.env.APIGATEWAY_URL_COMPANYEDIT;
            let JsonSaveData =
                '{' +
                '"TenantId": "' + props?.TenantInfo?.TenantID +
                '","TenantName": "' + ProfileData?.TenantName +
                '","CompanyCode": "' + ProfileData?.CompanyCode +
                '", "EmailID": "' + ProfileData?.EmailID +
                '","UpdatedEmailID":"' + ProfileData?.EmailID +
                '", "MobileNo": "' + ProfileData?.MobileNo +
                '", "AlterMobileNo": "' + ProfileData?.AlterMobileNo +
                '", "Address1": "' + ProfileData?.Address1 +
                '", "Address2": "' + ProfileData?.Address2 +
                '", "City": "' + ProfileData?.City +
                '", "State": "' + ProfileData?.State +
                '", "Country": "' + ProfileData?.Country +
                '", "CreatedDate": "' + ProfileData?.CreatedDate +
                '", "CreatedBy": "' + ProfileData?.CreatedBy +
                '", "LogoUrlPath": "' + SavedImageUrl.current?.ProfileName +
                '", "Status":"Active", ' +
                '"FirstTimeLogin": "' + ProfileData?.FirstTimeLogin +
                '", "BucketName":"' + ProfileData?.BucketName +
                '", "RootFolder":"' + ProfileData?.RootFolder +
                '", "UserSub":"' + ProfileData?.UserSub +
                '" }';
            let headers = {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    authorizationtoken: PageData?.user?.signInUserSession?.accessToken?.jwtToken,
                    defaultrole: props?.TenantInfo?.UserGroup,
                    groupmenuname: "CompanyManagement",
                    menuid: "100400",
                    statemachinearn: stateURL
                },
                body: JsonSaveData,
            };
            let FinalStatus = await APIGatewayPostRequest(setUploadURL, headers);
            if (FinalStatus.Status == "Success") {
                SavedImageUrl.current = { ...SavedImageUrl?.current, CurrentPath: SavedImageUrl?.current?.IncomingPath, IsUpload: false }
                setUploadLoder((data) => {
                    return { ...data, savedLoader: false }
                });
            }
        }
    }, [PageData?.ProfileData?.RoleName, PageData?.TenantInfo?.BucketName, PageData?.TenantInfo?.RootFolder, PageData?.TenantInfo?.TenantID, PageData?.UserType, PageData?.user?.attributes, PageData?.user?.signInUserSession?.accessToken?.jwtToken, ProfileData?.Address1, ProfileData?.Address2, ProfileData?.AlterMobileNo, ProfileData?.BucketName, ProfileData?.City, ProfileData?.CompanyCode, ProfileData?.Country, ProfileData?.CreatedBy, ProfileData?.CreatedDate, ProfileData?.EmailID, ProfileData?.FirstTimeLogin, ProfileData?.MobileNo, ProfileData?.RootFolder, ProfileData?.State, ProfileData?.TenantName, ProfileData?.UserSub, props])

    return (
        <>
            <Container PageRoutes={PageRoutes} title="View Profile" loader={PageData?.UserType == undefined}>          
                    {PageData?.UserType == "User" ? (
                        <UserProfile ProfileUrlMoveUnsavedToSaved={ProfileUrlMoveUnsavedToSaved} PageData={PageData} UploadLoder={UploadLoder} UplodError={UplodError} SavedImageRef={SavedImageUrl?.current} ProfileGoToUnsaved={ProfileGoToUnsaved} ProfileData={ProfileData} />)
                        : (<CompanyAdminProfile ProfileUrlMoveUnsavedToSaved={ProfileUrlMoveUnsavedToSaved} ProfileGoToUnsaved={ProfileGoToUnsaved} UploadLoder={UploadLoder} UplodError={UplodError} SavedImageRef={SavedImageUrl?.current} ProfileData={ProfileData} PageData={PageData}></CompanyAdminProfile>)}
            </Container >

        </>
    )
}