import Container from '@components/Container/Container';
import NVLImage from '@components/Controls/NVLImage';
import NVLlabel from '@components/Controls/NVLlabel';
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from 'react';
import { useForm } from "react-hook-form";
import { getXlmsBatchCourseEnrollUser, listXlmsCourseEnrollUser, listXlmsUserGroupListIndexInfos } from "src/graphql/queries";
import * as Yup from "yup";
export default function UserProfile({ ProfileData, ProfileGoToUnsaved, SavedImageRef, UploadLoder, UplodError, PageData, ProfileUrlMoveUnsavedToSaved }) {
    const [openTab, setOpenTab] = useState(1);
    const [CustomProfile, setCustomProfile] = useState();
    const [CourseList, setCourseList] = useState();
    const [GroupList, setGroupList] = useState();
    const router = useRouter();
    const GetcustomOption = useCallback((CustomAnswer) => {
        let temp = { UserInfo: [], CompanyInfo: [], CourseInfo: [] };
        PageData?.UserCustomFields?.map((getItem) => {
            if (getItem?.IsDisplayUserProfile) {
                if (getItem.DisplayPage == "UserInfo") {
                    temp = { ...temp, UserInfo: [...temp?.UserInfo, { ...getItem, FieldAnswer: CustomAnswer?.[getItem?.ProfileFieldName] }] }
                }
                else if (getItem.DisplayPage == "CompanyInfo") {
                    temp = { ...temp, CompanyInfo: [...temp?.CompanyInfo, { ...getItem, FieldAnswer: CustomAnswer?.[getItem?.ProfileFieldName] }] }
                }
                else if (getItem.DisplayPage == "CourseInfo") {
                    temp = { ...temp, CourseInfo: [...temp?.CourseInfo, { ...getItem, FieldAnswer: CustomAnswer?.[getItem?.ProfileFieldName] }] }
                }
            }
        });
        return temp;
    }, [PageData?.UserCustomFields]);

    useEffect(() => {
        async function GetUserProfileDetails() {
            // Fetch custom fields
            let URl_PK = "TENANT#" + PageData?.TenantInfo?.TenantID;
            let URl_SK = "#USERINFO#" + PageData?.user?.attributes?.["sub"];
            let fetchURL = process.env.GET_BATCH_ITEM + `?PK=${encodeURIComponent(URl_PK)}&SK=${encodeURIComponent(URl_SK)}`;
            let headers = {
                method: "GET",
                headers: {
                    "Content-Type": "application/text",
                    authorizationtoken: PageData.user.signInUserSession.accessToken.jwtToken,
                    defaultrole: PageData.user.signInUserSession?.accessToken?.payload["cognito:groups"][0],
                    groupmenuname: "UserManagement",
                    menuid: "200002"
                },
            };
            let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
            let Contents = await FinalStatus?.res?.text();
            let UserList = Contents && JSON?.parse(Contents);
            if (UserList) {
                setCustomProfile(GetcustomOption(UserList));
            }
            // Fetch Course list
            const CourseListResponse = await AppsyncDBconnection(
                listXlmsCourseEnrollUser,
                {
                    PK: "TENANT#" + PageData?.user?.attributes["custom:tenantid"] + "#COURSE#ENROLLUSER#" + PageData?.user?.signInUserSession?.accessToken?.payload["sub"],
                    SK: "COURSE#",
                    IsDeleted: false,
                },
                PageData?.user?.signInUserSession?.accessToken?.jwtToken
            );
            let activityData = CourseListResponse?.res?.listXlmsCourseEnrollUser?.items;


            let rowGrid = [], variables = [], temp = [];
            for (let i = 0; i < activityData?.length; i++) {
                if (!temp.includes("TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID)) {
                    variables = [...variables, { PK: "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard, SK: "COURSEINFO#" + activityData[i].CourseID, }];
                    temp = [...temp, "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID];
                }

            }
            const editDatalisttemp = await AppsyncDBconnection(getXlmsBatchCourseEnrollUser, { input: variables }, PageData?.user?.signInUserSession?.accessToken?.jwtToken);
            let SK = {};
            for (let i = 0; i < editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser?.length; i++) {
                if (editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.SK != undefined && editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.IsSuspend == false) {
                    SK = { ...SK, [editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.PK + editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.SK]: { ...editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i] } }
                }
            }
            for (let i = 0; i < activityData?.length; i++) {
                let tempSK = "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID;
                if (SK?.[tempSK] != undefined) {
                    rowGrid.push({ ...editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser?.[i], BatchID: activityData?.[i]?.BatchID });
                }

            }
            setCourseList(rowGrid)
            const GroupResponse = await AppsyncDBconnection(listXlmsUserGroupListIndexInfos, {
                GsiPK: "#USERINFO#" + PageData.user.signInUserSession.accessToken?.payload["sub"],
                GsiSK: "TENANT#" + PageData?.TenantInfo?.TenantID + "#GROUPID#"
            }, PageData.user.signInUserSession.accessToken.jwtToken);
            setGroupList(GroupResponse?.res?.listXlmsUserGroupListIndexInfos?.items && GroupResponse?.res?.listXlmsUserGroupListIndexInfos?.items);
            setIsLoader(false)
        }
        GetUserProfileDetails()

        return (() => {
            setCustomProfile((temp) => { return { ...temp } });
        })
    }, [GetcustomOption, PageData?.TenantInfo?.TenantID, PageData.user?.attributes, PageData.user.signInUserSession.accessToken.jwtToken, PageData.user.signInUserSession.accessToken?.payload, ProfileData, ProfileData?.Department, ProfileData?.Designation, ProfileData?.ReportManagerEmail, ProfileData?.FirstName, ProfileData?.LastName, ProfileData?.MobileNo, ProfileData?.RoleName, ProfileData?.UserName, setValue, openTab])

    const validationSchema = Yup.object().shape({})
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true };
    const { register, handleSubmit, reset, watch, formState, setValue } = useForm(formOptions);
    const { errors } = formState;

    const [IsLoader, setIsLoader] = useState(true);
    return (
        <>
            <Container loader={IsLoader}>
                <div className="grid grid-cols-1 gap-6 m-2">
                    <div className=" flex-wrap rounded shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] ">
                        <div className="!text-[#0E4681] text-xs font-semibold px-4 py-2" >User Information</div>
                        <div className='h-72 grid grid-flow-col md:grid-cols-7 max-h-72'>
                            <div className='grid justify-center text-center  p-2 h-full col-span-2'>
                                <div className="space-y-4 text-blue-500 my-8 ">
                                    <div className='w-32 h-32 relative mx-auto'>
                                        {SavedImageRef?.CurrentPath == undefined ? (
                                            <div className="m-1 mr-2 w-full h-full relative flex justify-center items-center rounded-full text-5xl bg-gray-400 text-white uppercase">
                                                {ProfileData?.FirstName.charAt(0) + ProfileData?.LastName.charAt(0)}</div>) : (<NVLImage id={"myImg"} alt={SavedImageRef?.ProfileName}
                                                    className="rounded-full overflow-hidden shadow-lg w-full h-full" src={SavedImageRef?.IncomingPath}
                                                    title="Profile" />)}
                                        <NVLlabel htmlFor="fulogo" className={`absolute right-0 cursor-pointer bg-white text-gray-600 font-semibold text-indigo-6 text-sm`}>
                                            {(UploadLoder?.unsavedLoader || UploadLoder?.savedLoader) ? <div className="UploadProfileloader absolute -right-2 bottom-2 "></div> : <><i className="shadow-lg text-sm bg-primary absolute -right-2 bottom-0 fa-solid fa-pen-to-square text-white h-7 w-7 grid place-content-center cursor-pointer rounded-full "></i>
                                                <input id="fulogo" name="file-upload" type="file" onChange={(e) => ProfileGoToUnsaved(e)} className="sr-only " /></>}
                                        </NVLlabel>
                                    </div>
                                    {UplodError && (<div className='flex justify-center gap-2 text-yellow-600 text-xs  '><i className="fa-solid fa-circle-exclamation my-auto"></i><span>{UplodError}</span></div>)}
                                    <div className='grid place-content-center'>
                                        <NVLlabel text={ProfileData?.FirstName + "  " + ProfileData?.LastName} className="nvl-Def-Label !text-[16px]" />
                                    </div>
                                </div>

                            </div>
                            <div className='flex flex-col my-4 mr-8 border rounded-md col-span-5 overflow-auto'>
                                <div className='border-b grow grid grid-cols-12 gap-4'>
                                    <div className=' p-2 col-span-4 my-auto'> <NVLlabel text="Role" className="!text-[#919191] font-medium" /></div>
                                    <div className=' p-2 col-span-1 my-auto'>:</div>
                                    <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={ProfileData?.RoleName} className="nvl-Def-Label" /></div>
                                </div>
                                <div className='border-b grow  grid grid-cols-12 gap-4 '>
                                    <div className=' p-2 col-span-4 my-auto'> <NVLlabel text={`${ProfileData?.PrefixCode != "" ? "User Id" : "User Name"} `} className="!text-[#919191] font-medium" /></div>
                                    <div className=' p-2 col-span-1 my-auto'>:</div>
                                    <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={ProfileData?.UserName} className="nvl-Def-Label" /></div>
                                </div>
                                <div className='border-b grow  grid grid-cols-12 gap-4 '>
                                    <div className=' p-2 col-span-4 my-auto'> <NVLlabel text="Email" className="!text-[#919191] font-medium" /></div>
                                    <div className=' p-2 col-span-1 my-auto'>:</div>
                                    <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={ProfileData?.EmailID} className="nvl-Def-Label" /></div>
                                </div>
                                <div className='border-b grow  grid grid-cols-12 gap-4 '>
                                    <div className=' p-2 col-span-4 my-auto'> <NVLlabel text="First Name" className="!text-[#919191] font-medium" /></div>
                                    <div className=' p-2 col-span-1 my-auto'>:</div>
                                    <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={ProfileData?.FirstName} className="nvl-Def-Label" /></div>
                                </div>
                                <div className='border-b grow  grid grid-cols-12 gap-4 '>
                                    <div className=' p-2 col-span-4 my-auto'> <NVLlabel text="Last Name" className="!text-[#919191] font-medium" /></div>
                                    <div className=' p-2 col-span-1 my-auto'>:</div>
                                    <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={ProfileData?.LastName} className="nvl-Def-Label" /></div>
                                </div>
                                <div className='grow  grid grid-cols-12 gap-4 '>
                                    <div className=' p-2 col-span-4 my-auto'> <NVLlabel text="Phone Number" className="!text-[#919191] font-medium" /></div>
                                    <div className=' p-2 col-span-1 my-auto'>:</div>
                                    <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={ProfileData?.MobileNo} className="nvl-Def-Label" /></div>
                                </div>
                                {CustomProfile?.UserInfo?.map((item, index) => {
                                    return (<div key={item} className='grow border-t grid grid-cols-12 gap-4 '> <div className=' p-2 col-span-4 my-auto'> <NVLlabel text={item?.ProfileFieldName} className="!text-[#919191] font-medium" /></div> <div className=' p-2 col-span-1 my-auto'>:</div> <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={item?.FieldAnswer ? item?.FieldAnswer : "-"} className="nvl-Def-Label" /></div> </div>);
                                })}
                            </div>
                        </div>
                    </div>
                    <label htmlFor="accordion-1" className="relative flex flex-col rounded-md border shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] ">
                        <input className="peer hidden" type="checkbox" id="accordion-1" />
                        <svg className="absolute right-0 top-4 ml-auto mr-5 h-4 text-gray-500 transition peer-checked:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                        <div className="relative pl-4 cursor-pointer select-none items-center py-4 pr-12 border-b">
                            <div className="!text-[#0E4681] text-xs font-semibold px-2" >Company Information</div>
                        </div>
                        <div className="max-h-0 transition-all duration-500 peer-checked:max-h-72 overflow-auto">
                            <div className='flex flex-col my-4 mx-8 col-span-3 border rounded-md'>
                                <div className='border-b grow grid grid-cols-12 gap-4'>
                                    <div className=' p-2 col-span-4 my-auto'> <NVLlabel text="Reporting Manager Email" className="!text-[#919191] font-medium" /></div>
                                    <div className=' p-2 col-span-1 my-auto'>:</div>
                                    <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={ProfileData?.ReportManagerEmail} className="nvl-Def-Label" /></div>
                                </div>
                                {CustomProfile?.CompanyInfo?.map((item, index) => {
                                    return (<div key={item} className='grow grid grid-cols-12 gap-4 border-b'> <div className=' p-2 col-span-4 my-auto'> <NVLlabel text={item?.ProfileFieldName} className="!text-[#919191] font-medium" /></div> <div className=' p-2 col-span-1 my-auto'>:</div> <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={item?.FieldAnswer ? item?.FieldAnswer : "-"} className="nvl-Def-Label" /></div> </div>);
                                })}
                            </div>
                        </div>
                    </label>
                    <label htmlFor="accordion-2" className="relative flex flex-col rounded-md shadow-[0_0.5px_5px_rgb(0,0,0,0.2)]">
                        <input className="peer hidden" type="checkbox" id="accordion-2" />
                        <svg className="absolute right-0 top-4 ml-auto mr-5 h-4 text-gray-500 transition peer-checked:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                        <div className="relative pl-4 cursor-pointer select-none items-center py-4 pr-12 border-b">
                            <div className="!text-[#0E4681] text-xs font-semibold px-2" >Course Information</div>
                        </div>
                        <div className="max-h-0 transition-all duration-500 peer-checked:max-h-72 overflow-auto">
                            <div className='p-2 grid gap-2 m-4 '>
                                <NVLlabel text="Course" className="nvl-Def-Label !text-[#919191]" />
                                <div className='grid grid-cols-6 gap-4'>
                                    {CourseList != undefined &&
                                        CourseList?.map((item, index) => {
                                            if (item?.CourseName) {
                                                if (index < 6) {
                                                    return (
                                                        <label key={item} title={item?.CourseName} className='bg-[#EBF1FF] text-[11px] flex justify-center items-center p-2 rounded-full cursor-pointer break-all' onClick={() =>
                                                            router.push(`/MyLearning/CourseConsume?CourseID=${item?.CourseID}&BatchId=${item?.BatchID}`)}>
                                                            {item?.CourseName?.length > 30 ? (item?.CourseName?.substring(0, 30) + "...") : item?.CourseName}
                                                        </label>
                                                    )
                                                }
                                            }
                                        })}
                                </div>
                                {CourseList?.length > 6 && <div className='flex justify-end ont-medium text-[12px] text-[#1D74FF] dark:text-[#1D74FF] hover:underline'>
                                    <div onClick={() => router.push(`/MyLearning/LearningDashboard`)} className="font-medium underline cursor-pointer">View more {">>"}</div>
                                </div>}
                                <NVLlabel text="Group" className="nvl-Def-Label !text-[#919191]" />
                                <div className='grid grid-cols-6 gap-4'>
                                    {GroupList != undefined &&
                                        GroupList?.map((item, index) => {
                                            if (item?.GroupName)
                                                return (
                                                    <label key={item} title={item?.GroupName} className='bg-[#EBF1FF] text-[11px] flex items-center justify-center p-2 rounded-full break-all' >
                                                        {item?.GroupName?.length > 30 ? (item?.GroupName?.substring(0, 30) + "...") : item?.GroupName}
                                                    </label>
                                                )
                                        })}
                                </div>
                            </div>
                            <div className='flex flex-col my-4 mx-8 col-span-3 border rounded-md'>
                                {CustomProfile?.CourseInfo && CustomProfile?.CourseInfo?.map((item, index) => {
                                        return (<div key={item} className='grow grid grid-cols-12 gap-4  border-b'> <div className=' p-2 col-span-4 my-auto'> <NVLlabel text={item?.ProfileFieldName} className="!text-[#919191] font-light" /></div> <div className=' p-2 col-span-1 my-auto'>:</div> <div className=' p-2 col-span-7 my-auto'> <NVLlabel text={item?.FieldAnswer ? item?.FieldAnswer : "-"} className="nvl-Def-Label" /></div> </div>);
                                    })}
                            </div>
                        </div>
                    </label>
                </div>
            </Container>
        </>
    )
}
