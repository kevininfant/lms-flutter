import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import NVLImage from "@components/Controls/NVLImage";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";
import { listXlmsUserCertificateInfos } from "src/graphql/queries";
export default function UserCompletedCertificates({ props }) {
    const router = useRouter();
    const [CertificateList, setCertificateList] = useState([]);
    useEffect(() => {
        const FetchUserCertificates = (async () => {
            const certificateList = await AppsyncDBconnection(
                listXlmsUserCertificateInfos,
                {
                    PK: "TENANT#" + props?.user?.attributes["custom:tenantid"] + "#USERSUB#" + props?.user?.signInUserSession?.accessToken?.payload["sub"],
                    SK: "CERTIFICATE#"
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            )
            let myCertificateList = [];
            certificateList?.res?.listXlmsUserCertificateInfos?.items?.map((item, i) => {
                if (item?.CertificateName) {
                    myCertificateList.push(item)
                }
            })
            setCertificateList(certificateList?.res?.listXlmsUserCertificateInfos?.items != [] && certificateList?.res?.listXlmsUserCertificateInfos?.items)
        })
        FetchUserCertificates()
        return () => {
            setCertificateList([])
        }
    }, [props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, props?.user?.signInUserSession?.accessToken?.payload])

    const UserCertificateList = useCallback(() => {

        let RecentCertificate;
        if (CertificateList?.length == 0) {
            RecentCertificate = <>
                <div className="h-20 bg-yellow-100 text-yellow-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-yellow-900 dark:text-yellow-300">You are yet to earn a certificate. </div>
            </>
        } else {
            const myCertificate = CertificateList.slice(0, 1);
            RecentCertificate = myCertificate?.map((item, i) => {
                return (
                    <div key={"c-" + i} >
                        <div className="flex justify-center">
                            <NVLImage className={`rounded ${item?.CertificateImagePath ? "" : "blur-sm"}`} alt="My Certificate" width={90} height={50}  src={item?.CertificateImagePath} />
                        </div>
                        <div className="flex justify-center text-center">
                            <label title={item?.CertificateName} className="nvl-Def-Label !font-medium underline !w-28 whitespace-nowrap !text-[11px]" >{item?.CertificateName?.length > 15 ? (item?.CertificateName?.substring(0, 15) + "...") : item?.CertificateName}</label>

                        </div>
                    </div>
                );
            })
        }
        return RecentCertificate;
    }, [CertificateList]);
    return (
        <>
          {!CertificateList ? <div className=""><NVLFetchDataLoading height={"!h-20"} /></div> : (<>
            <div className="h-full grid place-content-center">
               {UserCertificateList()}
               </div>
            </>)}
        </>
    )
}
