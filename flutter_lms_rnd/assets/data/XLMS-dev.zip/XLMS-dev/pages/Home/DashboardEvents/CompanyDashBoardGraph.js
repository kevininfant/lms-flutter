import { GetDateFormat } from '@components/Common/DateFormat';
import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import NVLlabel from "@components/Controls/NVLlabel";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { getXlmsCourseActivityConfig, listXlmsActivityLiveCountInfos, listXlmsTenantInfos } from "src/graphql/queries";
export default function CompanyDashBoardGraph({ props }) {
    const [DashboardData, setDashboardData] = useState([]);
    useEffect(() => {
        const FetchCompanyData = (async () => {
            const TypesOfActivityResponse = await AppsyncDBconnection(
                getXlmsCourseActivityConfig,
                {
                    PK: "XLMS#ACTIVITY",
                    SK: "ACTIVITY#ACTIVITYTYPE",
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            const DateFormat = GetDateFormat(new Date(), "dd-mm-yyyy")
            const ActivityTimeSpan = await AppsyncDBconnection(
                listXlmsActivityLiveCountInfos,
                {
                    PK: "XLMS#LIVEACTIVITYUSER",
                    SK: "TIMESPAN#" + DateFormat + "#"
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            )
            const Tenantinfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props?.user?.signInUserSession.accessToken.jwtToken);
            setDashboardData({
                LiveActivityUser: ActivityTimeSpan?.res?.listXlmsActivityLiveCountInfos?.items != undefined ? ActivityTimeSpan?.res?.listXlmsActivityLiveCountInfos?.items : [],
                TypeOfActivity: TypesOfActivityResponse?.res?.getXlmsCourseActivityConfig?.ActivityType != undefined && JSON?.parse(TypesOfActivityResponse?.res?.getXlmsCourseActivityConfig?.ActivityType),
                TenantList: Tenantinfo?.res?.listXlmsTenantInfos?.items != undefined ? Tenantinfo.res?.listXlmsTenantInfos?.items : []
            })
        })
        FetchCompanyData()
        return () => {
            setDashboardData([])
        }
    }, [props?.user?.signInUserSession.accessToken.jwtToken])

    const getCompanyData = useCallback(() => {
        let UnSuspendedCompany, SuspendedCompany;
        SuspendedCompany = DashboardData.TenantList?.filter((Suspend) => { return Suspend?.IsSuspend == true })
        UnSuspendedCompany = DashboardData.TenantList?.filter((Suspend) => { return Suspend?.IsSuspend == false })
        return [UnSuspendedCompany?.length, SuspendedCompany?.length]


    }, [DashboardData.TenantList])
    const DoughnutProgress = useMemo(() => {
        let Temp = {
            labels: ["Active Company", "Inactive Company"],
            datasets: [
                {
                    data: getCompanyData(),
                    backgroundColor: ["#51B75C", "orange"],
                    hoverOffset: 4,
                },
            ],
        };
        return Temp;
    }
        , [getCompanyData])
    return (
        <div className="bg-[#F9FAFC] shadow">
            <NVLlabel text="Company Dashboard" className="nvl-Def-Label px-4" />
            <div className="grid place-content-center bg-[#F9FAFC] text-gray-700 py-2">
                {!DashboardData.TenantList ? <NVLFetchDataLoading /> : (<>
                    <div className=" rounded-md w-full relative ">
                        <Doughnut data={DoughnutProgress} options={{
                            hover: { mode: null },
                            responsive: false,
                            elements: {
                                arc: {
                                    borderWidth: 0,
                                },
                            },
                            plugins: {
                                legend: {
                                    position: "right",
                                    display: true,
                                    labels: {
                                        padding: 20,
                                        boxWidth: 50,
                                        usePointStyle: true,
                                        font: {
                                            family: "Montserrat, sans-serif",
                                            size: 12,
                                        },
                                    },
                                },
                            },
                            cutout: "80%",
                            maintainAspectRatio: false,
                        }} id="DoughnutClass" />
                        <div className="absolute top-6 left-9 md:top-10 md:left-8 text-center text-xs font-semibold pt-4 pl-2 rounded-full">
                            <div>{DashboardData?.TenantList?.length}</div>
                            <div>{DashboardData?.TenantList?.length <= 1 ? "Company" : "Companies"}</div>
                        </div>
                    </div>
                </>)}
            </div>
        </div>
    )
}
