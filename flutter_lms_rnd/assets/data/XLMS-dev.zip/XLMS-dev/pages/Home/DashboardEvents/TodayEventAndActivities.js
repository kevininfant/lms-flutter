import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLNoImage from "@components/Controls/NVLNoImage";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { getXlmsBatchCourseEnrollUser, getXlmsBatchEnrollUser, listXlmsActivityManagementInfos, listXlmsCourseEnrollUser, listXlmsCourseManagementInfo, listXlmsEnrollUser } from "src/graphql/queries";
export default function TodayEventAndActivities({ props, ChangedDate }) {
    const [ActivityList, setActivityList] = useState([]);
    const router = useRouter();
    const [CourseList, setCourseList] = useState([]);
    useEffect(() => {
        const FetchEventList = (async () => {
            if (props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin") {
                const CourseListResponse = await AppsyncDBconnection(
                    listXlmsCourseManagementInfo,
                    {
                        PK: "TENANT#" + props?.user?.attributes["custom:tenantid"],
                        SK: "COURSEINFO#",
                        IsDeleted: false,
                    },
                    props?.user?.signInUserSession?.accessToken?.jwtToken
                );
                setCourseList(CourseListResponse?.res?.listXlmsCourseManagementInfo?.items)
                const ActivityListResponse = await AppsyncDBconnection(
                    listXlmsActivityManagementInfos,
                    {
                        PK: "TENANT#" + props?.user?.attributes["custom:tenantid"],
                        SK: "ACTIVITYTYPE#",
                    },
                    props?.user?.signInUserSession?.accessToken?.jwtToken
                );
                setActivityList(ActivityListResponse?.res?.listXlmsActivityManagementInfos?.items)
            } else {
                const CourseListResponse = await AppsyncDBconnection(
                    listXlmsCourseEnrollUser,
                    {
                        PK: "TENANT#" + props?.user?.attributes["custom:tenantid"] + "#COURSE#ENROLLUSER#" + props?.user?.signInUserSession?.accessToken?.payload["sub"],
                        SK: "COURSE#",
                        IsDeleted: false,
                    },
                    props?.user?.signInUserSession?.accessToken?.jwtToken
                );
                let activityData = CourseListResponse?.res?.listXlmsCourseEnrollUser?.items;

                let rowGrid = [], variables = [], temp = [];
                for (let i = 0; i < activityData?.length; i++) {
                    if (!temp.includes("TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID)) {
                        variables = [...variables, { PK: "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard, SK: "COURSEINFO#" + activityData[i].CourseID, }];
                        temp = [...temp, "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID];
                    }
                }
                const editDatalisttemp = await AppsyncDBconnection(getXlmsBatchCourseEnrollUser, { input: variables }, props?.user?.signInUserSession?.accessToken?.jwtToken);
                let SK = {};
                for (let i = 0; i < editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser?.length; i++) {
                    if (editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.SK != undefined && editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.IsSuspend == false) {
                        SK = { ...SK, [editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.PK + editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.SK]: { ...editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i] } }
                    }
                }
                for (let i = 0; i < activityData?.length; i++) {
                    let tempSK = "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID;
                    if (SK?.[tempSK] != undefined) {
                        rowGrid.push({ ...editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser?.[i], BatchID: activityData?.[i]?.BatchID });
                    }
                }
                setCourseList(rowGrid)
                const ActivityListResponse = await AppsyncDBconnection(
                    listXlmsEnrollUser,
                    {
                        PK: "TENANT#" + props?.user?.attributes["custom:tenantid"] + "#ACTIVITY#ENROLLUSER#" + props?.user?.signInUserSession?.accessToken?.payload["sub"],
                        SK: "ACTIVITYID#",
                    },
                    props?.user?.signInUserSession?.accessToken?.jwtToken
                );
                let listOfEnrolledActivities = ActivityListResponse?.res?.listXlmsEnrollUser?.items;
                const ActivityVariables = [];
                for (let i = 0; i < listOfEnrolledActivities?.length; i++) {
                    ActivityVariables = [...ActivityVariables, { PK: "TENANT#" + listOfEnrolledActivities[i].TenantID + "#" + listOfEnrolledActivities[i].Shard, SK: "ACTIVITYTYPE#" + listOfEnrolledActivities[i].ActivityType + "#ACTIVITYID#" + listOfEnrolledActivities[i].ActivityID }]
                }
                const activityeditDatalisttemp = await AppsyncDBconnection(getXlmsBatchEnrollUser, { input: ActivityVariables }, props?.user?.signInUserSession?.accessToken?.jwtToken);
                setActivityList(activityeditDatalisttemp && activityeditDatalisttemp?.res?.getXlmsBatchEnrollUser)
            }
        })
        FetchEventList()
        return () => {
            setCourseList([])
        }
    }, [props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, props?.user?.signInUserSession?.accessToken?.payload])

    
    return (
        <div className={`p-2 space-y-2 ${!(CourseList&&ActivityList)?" !h-32":" h-52 overflow-auto"} `}>
            {!ActivityList || !CourseList ?!(CourseList&&ActivityList)?<NVLNoImage id="NoRecord" className="h-44" alignItem={"center"} />: <div className=""><NVLFetchDataLoading /></div> : <>
                {ActivityList?.map((getItem, index) => {
                    let IsShow = true, IsEndDate = true, actionURL;
                    if (props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin") {
                        actionURL = `/ActivityManagement/ActivityInfo?Mode=Edit&ActivityID=${getItem?.ActivityID}&ActivityType=${getItem?.ActivityType}`
                    } else {
                        actionURL = `/MyLearning/UserConsume?Mode=Start&ActivityID=${getItem?.ActivityID}&ActivityType=${getItem?.ActivityType}`;
                    }
                    if (getItem?.StartDate == "" || getItem?.StartDate == undefined || (new Date(getItem?.StartDate)) == null || (new Date(getItem?.StartDate)) == "NaN") {
                        IsShow = false;
                    }
                    if (getItem?.EndDate == "" || getItem?.EndDate == undefined || (new Date(getItem?.EndDate)) == null || (new Date(getItem?.EndDate)) == "NaN") {
                        IsEndDate = false;
                    }
                    let activityDescription = getItem?.ActivityDescription?.toString()?.replace(/(<([^>]+)>)/ig, '');
                    const IsShowEvents = () => {
                        return (
                            (new Date(getItem?.StartDate).getFullYear() + '-' + (new Date(getItem?.StartDate).getMonth() + 1) + '-' +
                                (new Date(getItem?.StartDate).getDate())) == (new Date(ChangedDate.toISOString()).getFullYear() + '-' +
                                    (new Date(ChangedDate.toISOString()).getMonth() + 1) + '-' + (new Date(ChangedDate.toISOString()).getDate())
                                )
                                || (new Date(getItem?.StartDate) < new Date(ChangedDate) &&
                                    (IsEndDate ? (new Date(getItem?.EndDate) > new Date(ChangedDate)) : true))

                                ? (getItem?.ActivityName && <><span className="gap-2 text-blue-600 text-xs font-medium rounded ">
                                    <div className="flex  gap-2 ">
                                        <i className="fa-solid fa-circle  text-[#F47623] mt-1"></i>
                                        <div>
                                            <NVLlabel onClick={() => { router.push(actionURL) }} text={getItem?.ActivityName} className={"!text-[#0E4681] !underline font-semibold cursor-pointer"} />
                                            {activityDescription && <label title={activityDescription}
                                                className={"!text-[#374151] font-light"} > {activityDescription?.length > 130 ? (activityDescription?.substring(0, 125) + "...") : activityDescription}</label>}

                                        </div>
                                    </div>
                                </span></>) : ""
                        )
                    }
                    return <div className="flex" key={"y" + index}>
                        {IsShow ? IsShowEvents() : getItem?.ActivityName && <><span className="text-center text-xs font-medium rounded ">
                            <div className="flex  gap-2 ">
                                <i className="fa-solid fa-circle  text-[#F47623] mt-1"></i>
                                <div>
                                    <NVLlabel onClick={() => { router.push(actionURL) }} text={getItem?.ActivityName} className={"!text-[#0E4681] !underline font-semibold cursor-pointer"} />
                                    {activityDescription && <label title={activityDescription}
                                        className={"!text-[#374151] font-light"} > {activityDescription?.length > 130 ? (activityDescription?.substring(0, 125) + "...") : activityDescription}</label>}

                                </div>
                            </div>
                        </span>
                        </>
                        }
                    </div>
                })}
                {CourseList?.map((getItem, index) => {
                    let IsShow = true, IsEndDateTime = true, actionURL;
                    if (props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin") {
                        actionURL = `/CourseManagement/CourseEditSettings?&Mode=Edit&CourseID=${getItem?.CourseID}`;
                    } else {
                        actionURL = `/MyLearning/CourseConsume?CourseID=${getItem?.CourseID}&BatchId=${getItem?.BatchID}`;
                    } if (getItem?.DateTime == "" || getItem?.DateTime == undefined || (new Date(getItem?.DateTime)) == null || (new Date(getItem?.DateTime)) == "NaN") {
                        IsShow = false;
                    }
                    if (getItem?.EndDateTime == "" || getItem?.EndDateTime == undefined || (new Date(getItem?.EndDateTime)) == null || (new Date(getItem?.EndDateTime)) == "NaN") {
                        IsEndDateTime = false;
                    }

                    let courseDescription = getItem?.CourseDescription?.toString()?.replace(/(<([^>]+)>)/ig, '');
                    const IsShowEvents = () => {
                        return (
                            (new Date(getItem?.DateTime).getFullYear() + '-' + (new Date(getItem?.DateTime).getMonth() + 1) + '-' +
                                (new Date(getItem?.DateTime).getDate())) == (new Date(ChangedDate.toISOString()).getFullYear() + '-' +
                                    (new Date(ChangedDate.toISOString()).getMonth() + 1) + '-' + (new Date(ChangedDate.toISOString()).getDate())
                                )
                                || (new Date(getItem?.DateTime) < new Date(ChangedDate) &&
                                    (IsEndDateTime ? (new Date(getItem?.EndDateTime) > new Date(ChangedDate)) : true))
                                ? (<div className="flex ">{getItem?.CourseName && <>
                                    <span className="text-xs font-medium rounded">
                                        <div className="flex gap-2">
                                            <i className="fa-solid fa-circle  text-[#F47623] mt-1"></i>
                                            <div>
                                                <NVLlabel onClick={() => { router.push(actionURL) }} text={getItem?.CourseName} className={"!text-[#0E4681] !underline font-semibold cursor-pointer"} />
                                                {courseDescription && <label title={courseDescription}
                                                    className={"!text-[#374151] font-light"} > {courseDescription?.length > 130 ? (courseDescription?.substring(0, 125) + "...") : courseDescription}</label>}
                                            </div>
                                        </div>
                                    </span></>}</div>) : ""
                        )
                    }
                    return (
                        <div className="flex" key={"x" + index}>{IsShow ? IsShowEvents() : getItem?.CourseName && <>
                            <span className=" text-xs font-medium rounded">
                                <div className="flex gap-2">
                                    <i className="fa-solid fa-circle text-[#F47623]"></i>
                                    <div>
                                        <NVLlabel onClick={() => { router.push(actionURL) }} text={getItem?.CourseName} className={"!text-[#0E4681] !underline font-semibold cursor-pointer"} />
                                        {courseDescription && <label title={courseDescription}
                                            className={"!text-[#374151] font-light"} > {courseDescription?.length > 130 ? (courseDescription?.substring(0, 125) + "...") : courseDescription}</label>}
                                    </div>
                                </div>
                            </span>
                        </>}</div>
                    )
                })}

            </>}
        </div>
    )
}