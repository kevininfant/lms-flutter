import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import NVLlabel from "@components/Controls/NVLlabel";
import { APIGatewayPostRequest } from "DBConnection/ErrorResponse";
import { useEffect, useMemo, useState } from "react";
import { Doughnut } from "react-chartjs-2";

export default function LearningHoursGraf({ props }) {


    const [getHourInfo, setHourInfo] = useState();
    useEffect(() => {
        const FetchLearningHours = (async () => {
            const usersub = props?.user?.attributes["sub"];
            const tenantid = props?.user?.attributes["custom:tenantid"];
            const condition = ` WHERE  usersub='${usersub}' AND  tenantid ='${tenantid}'`;
            const learningHourReportData = await APIGatewayPostRequest(
                process.env.APIGATEWAY_REPORT_URL,
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                        menuid: "116100",
                        tenantid: props?.user?.attributes["custom:tenantid"],
                        usersub: props?.user?.attributes["sub"],
                        defaultrole: props?.TenantInfo.UserGroup,
                        groupmenuname: "Analytics&Report",
                    },
                    body: condition,
                }
            );
            const FinalRes = await learningHourReportData?.res?.text();
            setHourInfo(FinalRes && JSON?.parse((JSON?.parse(FinalRes)?.State) != undefined) ? (JSON?.parse(JSON.parse(FinalRes)?.State)) : []);

        });
        FetchLearningHours();

    }, [props?.TenantInfo.UserGroup, props.user?.attributes, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload]);

    const LearningHoursData = useMemo(() => {

        const Temp = {
            labels: [(getHourInfo?.[0]?.CompletedTime ? toHoursAndMinutes(getHourInfo?.[0]?.CompletedTime) : "00:00") + " Completed", (getHourInfo?.[0]?.InCompletedTime ? toHoursAndMinutes(getHourInfo?.[0]?.InCompletedTime) : "00:00") + " Incompleted"],
            datasets: [
                {
                    data: [getHourInfo?.[0]?.CompletedTime ? getHourInfo?.[0]?.CompletedTime : 0,
                    getHourInfo?.[0]?.InCompletedTime ? getHourInfo?.[0]?.InCompletedTime : 0],
                    backgroundColor: ["#FFA808", "#D5D5D5"],
                    hoverOffset: 4,
                },
            ],
        };
        return Temp;
    }, [getHourInfo]);
    function toHoursAndMinutes(totalMinutes) {
        const hours = Math.floor(totalMinutes / 60);
        const minutes = totalMinutes % 60;
        return `${hours?.toString().padStart(2, '0')} h ${minutes?.toString().padStart(2, '0')} m`;
    }

    function toHoursAndMinutesFormat(totalMinutes) {
        if (totalMinutes) {
            if (totalMinutes != "null") { const minutes = totalMinutes % 60; const hours = Math.floor(totalMinutes / 60); return `${padTo2Digits(hours)}:${padTo2Digits(minutes)}`;} else return `00:00`
        } else return "00:00"
    }
    function padTo2Digits(num) {return num.toString().padStart(2, '0')}
    return (

        getHourInfo == undefined ? <div className="h-full"><NVLFetchDataLoading height={"!h-40"} /> </div> : (<>
            <NVLlabel text="Learning Hours" className="nvl-Def-Label absolute p-2" />
            <div className="w-44 mx-auto relative">
                <Doughnut
                    data={LearningHoursData}
                    options={{
                        hover: { mode: null },
                        cutoutPercentage: 75,
                        legend: {
                            display: false
                        },
                        elements: {
                            arc: {
                                borderWidth: 0,
                            },
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: (context) => {
                                        const dataIndex = context.dataIndex;
                                        const label = context.chart.data.labels[dataIndex];
                                        // const value = context.chart.data.datasets[0].data[dataIndex];
                                        return `${label}`;
                                    },
                                },
                            },
                            legend: {
                                display: false,

                                labels: {
                                    font: {
                                        family: "Montserrat, sans-serif",
                                        size: 15,
                                    },
                                }

                            },
                            datalabels: {
                                color: "red",
                            }
                        },
                        cutout: "65%",
                        rotation: -90,
                        circumference: 180,

                    }}
                />
                <div className="absolute top-6 left-4 md:top-[106px] md:left-12 text-center text-[10px] font-semibold text-[#374151] rounded-full w-20">
                    Total Hrs
                    <div className=" " >  {toHoursAndMinutesFormat(getHourInfo?.[0]?.Totaltimehours) }</div>
                  
                </div>
            </div>
        </>)
    );
}