import NVLlabel from "@components/Controls/NVLlabel";
import NVLNoImage from "@components/Controls/NVLNoImage";
import { useRouter } from "next/router";
export default function TodayEventCard({ eventData, onClickSchedule, DailyDate }) {
    const router = useRouter()
    let filterEvent = [], IsEndDate = true;
    eventData?.filter((getItem) => {
        if ((new Date(DailyDate).getFullYear() + '-' + (new Date(DailyDate).getMonth() + 1) + '-' +
            (new Date(DailyDate).getDate())) == (new Date(getItem?.start).getFullYear() + '-' +
                (new Date(getItem?.start).getMonth() + 1) + '-' + (new Date(getItem?.start).getDate())
            ) || (new Date(getItem?.start) < new Date(DailyDate) &&
                (!(getItem?.end == "" || getItem?.end == undefined || (new Date(getItem?.end)) == null || (new Date(getItem?.end)) == "NaN") ? (new Date(getItem?.end) >= new Date(DailyDate)) : false))) {   
            filterEvent.push(getItem)
        }
    })

    function addDays(date, days, mode) {
        const copy = new Date(Number(new Date(date)));
         copy.setDate(new Date(date).getDate() + days);
        return copy;
      }
    return (
        <>
            {filterEvent?.length == 0 ? <NVLNoImage id="NoRecord" className=" mx-auto  h-96" alignItem={""} />
                : <div className="grid grid-cols-6 gap-4 my-4">
                    {filterEvent?.map((Item, index) => {
                        return (
                            <>
                                <div className="space-y-6 block rounded-lg bg-white p-2 ">
                                    <div className="flex gap-4 justify-between">
                                        <NVLlabel text={Item?.title} className="font-semibold !text-sm !my-auto break-all" />
                                        <div className="flex gap-2">
                                            <i onClick={() => onClickSchedule(Item, "Daily")} className="fa-solid fa-ellipsis-vertical text-gray-700 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-gray-100"></i>
                                        </div>
                                    </div>
                                    <div >
                                        <NVLlabel text={(new Date(DailyDate).getFullYear() + '-' + (new Date(DailyDate).getMonth() + 1) + '-' +
                                            (new Date(DailyDate).getDate())) == (new Date().getFullYear() + '-' +
                                            (new Date().getMonth() + 1) + '-' + (new Date().getDate())
                                            ) ? "Today" :(new Date(DailyDate).getFullYear() + '-' + (new Date(DailyDate).getMonth() + 1) + '-' +
                                            (new Date(DailyDate).getDate())) == (addDays(new Date(),1).getFullYear() + '-' +
                                            (addDays(new Date(),1).getMonth() + 1) + '-' + (addDays(new Date(),1).getDate())
                                            )?"Tomorrow":new Date(DailyDate)?.toLocaleString('default', {weekday: 'long'})} 
                                            className="!text-sm  text-primary font-semibold" />
                                        <NVLlabel text={Item?.eventType} className=" !text-xs" />
                                    </div>
                                </div>
                            </>
                        )
                    })}
                </div>
            }</>
    )
}
