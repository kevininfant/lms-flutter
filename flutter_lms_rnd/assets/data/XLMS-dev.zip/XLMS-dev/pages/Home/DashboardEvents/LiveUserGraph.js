import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useEffect, useState } from 'react';
import { Doughnut } from 'react-chartjs-2';
import { listXlmsLoginLiveUserCountInfos } from "src/graphql/queries";
import NVLlabel from '../../../components/Controls/NVLlabel';

export default function NVLLiveUserChart({ props }) {
    const [CourseLiveUsers, setCourseLiveUsers] = useState({ WebUser: 0, MobileUser: 0, TotalUser: 0 });
    useEffect(() => {
        async function GetLiveUserData(e, index) {
            let LiveUsers = { WebUser: 0, MobileUser: 0, TotalUser: 0 };
            let today = Math.round(((new Date()).getTime()) / 1000);
            const ListLiveUserResponse = await AppsyncDBconnection(listXlmsLoginLiveUserCountInfos, { PK: "XLMS#LIVEUSER", SK: props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin" ? "TENANT#" + props?.user?.attributes["custom:tenantid"] + "#USERSUB#" : "TENANT#", AutoDelete: today }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const ListOfLiveUSers = ListLiveUserResponse?.res?.listXlmsLoginLiveUserCountInfos?.items && ListLiveUserResponse?.res?.listXlmsLoginLiveUserCountInfos?.items;
            ListOfLiveUSers?.map((getItem) => {
                if (props?.user?.attributes?.["sub"] != getItem?.UserSub) {
                    if (getItem?.DeviceName == "Web User") {
                        LiveUsers = { ...LiveUsers, WebUser: LiveUsers?.WebUser + 1, TotalUser: LiveUsers?.TotalUser + 1 };
                    } else if (getItem?.DeviceName == "Mobile User") {
                        LiveUsers = { ...LiveUsers, MobileUser: LiveUsers?.WebUser + 1, TotalUser: LiveUsers?.TotalUser + 1 }
                    }
                }
            })
            setCourseLiveUsers(LiveUsers)
        }
        GetLiveUserData()
        const interval = setInterval(GetLiveUserData, 30000); //30000
        return () => {
            setCourseLiveUsers({ WebUser: 0, MobileUser: 0, TotalUser: 0 })
            clearInterval(interval);
        };
    }, [props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken])
    return (
        <div className="bg-[#F9FAFC] shadow p-2">
            <div>
                {!CourseLiveUsers ? <div className="h-44"><NVLFetchDataLoading /></div> : (<>
                    <NVLlabel text="Live User" className="nvl-Def-Label px-4" />
                    <div className="grid place-content-center bg-[#F9FAFC] text-gray-700 ">
                        <div className=" rounded-md w-full relative p-2">
                            <Doughnut data={{
                                labels: ["Web User", "Mobile User"],
                                datasets: [
                                    {
                                        data: [CourseLiveUsers?.WebUser, CourseLiveUsers?.MobileUser],
                                        backgroundColor: ["orange", "#36A2EB"],
                                        hoverOffset: 4,
                                    },
                                ],
                            }}
                                options={{
                                    hover: { mode: null },
                                    responsive: false,
                                    elements: {
                                        arc: {
                                            borderWidth: 0,
                                        },
                                    },
                                    plugins: {
                                        legend: {
                                            position: "right",
                                            display: true,
                                            labels: {
                                                padding: 20,
                                                boxWidth: 50,
                                                usePointStyle: true,
                                                font: {
                                                    family: "Montserrat, sans-serif",
                                                    size: 12,
                                                },
                                            },
                                        },
                                    },
                                    cutout: "80%",
                                    maintainAspectRatio: false,
                                }}
                                id="DoughnutClass" />

                            <div className="absolute top-6 left-9 md:top-10 md:left-14 text-center text-xs font-semibold p-6 rounded-full">
                                <div>{CourseLiveUsers?.TotalUser}</div>
                                <div>Users</div>
                            </div>
                        </div>
                    </div>
                </>)}
            </div>
        </div>
    )
}
