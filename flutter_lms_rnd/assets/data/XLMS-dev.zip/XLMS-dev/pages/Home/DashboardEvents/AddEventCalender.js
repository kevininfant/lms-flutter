import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import { useRouter } from "next/router";
import { useCallback } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
export default function AddEventCalender({ props, ChangedDate, setChangedDate, AddEvent }) {
    const router = useRouter();
    const EventChange = useCallback((e) => {
        setChangedDate(e)
    }, [setChangedDate])
    return (
        <>
            <div className="">
                <div className="flex justify-between p-2">
                    <NVLlabel text="Calendar" className="nvl-Def-Label  px-4 py-2 " />
                    { AddEvent && <NVLButton onClick={() => router.push(
                        `/MySchedule/AddEventInfo?Mode=Create`
                    )} text={"Add New Event"} type={"button"} className="bg-primary nvl-button !rounded-xl text-white " />}
                </div>
                <div className=" rounded-md w-full p-2">
                    <Calendar onChange={EventChange} value={ChangedDate} />
                </div>
            </div>
        </>
    )
}