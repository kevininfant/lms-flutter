import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import NVLImage from "@components/Controls/NVLImage";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";
import { listXlmsUserCertificateInfos } from "src/graphql/queries";
export default function UserCompletedBadges({ props }) {
    const router = useRouter();
    const [badgeList, setBadgeList] = useState([]);
    useEffect(() => {
        const FetchUserBadge = (async () => {
            const badges = await AppsyncDBconnection(
                listXlmsUserCertificateInfos,
                {
                    PK: "TENANT#" + props?.user?.attributes["custom:tenantid"] + "#USERSUB#" + props?.user?.signInUserSession?.accessToken?.payload["sub"],
                    SK: "BADGE#",
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            )
            let myBadgeList = [];
            badges?.res?.listXlmsUserCertificateInfos?.items?.map((item, i) => {
                if (item?.BadgeName) {
                    myBadgeList.push(item)
                }
            })
            setBadgeList(myBadgeList != [] && myBadgeList)
        })
        FetchUserBadge();
        return () => {
            setBadgeList([])
        }
    }, [props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, props?.user?.signInUserSession?.accessToken?.payload])
    const UserBadgeList = useCallback(() => {
        let RecentBadge;
        if (badgeList?.length == 0) {
            RecentBadge = <>
                <div className="h-20 bg-yellow-100 text-yellow-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded dark:bg-yellow-900 dark:text-yellow-300">
                    You are yet to earn a badge. </div>
            </>
        } else {
            const myBadges = badgeList.slice(0, 1);
            RecentBadge = myBadges?.map((item, i) => {
                return (
                    <div key={"b-" + i}  onClick={()=>router.push(`/Achievement/AchievementDashBoard?parameters=2`)} className="cursor-pointer">
                        <div className="flex justify-center">
                            <NVLImage className="rounded" alt="My Badge" width={90} height={50} src={item?.CertificateImagePath} />
                        </div>
                        <div className="flex justify-center text-center">
                            <label title={item?.BadgeName} className="nvl-Def-Label !font-medium underline !w-28 whitespace-nowrap !text-[11px]" >{item?.BadgeName?.length > 15 ? (item?.BadgeName?.substring(0, 15) + "...") : item?.BadgeName}</label>
                        </div>
                    </div>
                );
            })
        }
        return RecentBadge;
    }, [badgeList, router]);
    return (
        <>
           {!badgeList ? <div className=""><NVLFetchDataLoading height={"!h-20"} /></div> : (
           <div className="h-full grid place-content-center">
               {UserBadgeList()}
            </div>)}
        </>
    )
}