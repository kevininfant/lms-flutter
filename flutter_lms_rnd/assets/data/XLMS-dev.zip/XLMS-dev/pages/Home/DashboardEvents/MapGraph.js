import { useMemo } from "react";
import MapChart from "react-google-charts";
export default function MapGraph() {
    const mapDataSiteAdmin = useMemo(() => {
        return ([["Country", "Popularity"], ["India", 1000], ["Germany", 200], ["United States", 300], ["Brazil", 400], ["Canada", 500], ["France", 600], ["RU", 700],
        ])
    }
        , [])
    return (
        <div className="md:flex md:mb-4 bg-[#F9FAFC] shadow">
            <div className="w-full">
                <div className="bg-[#F9FAFC] rounded w-full">
                    <h6 className="text-gray-500 pt-4 pl-4 text-sm font-bold ">Map</h6>
                    <div className="p-4 ">
                        <MapChart chartType="GeoChart" className="rounded-xl" data={mapDataSiteAdmin} />
                    </div>
                </div>
            </div>
        </div>
    )
}
