import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import { useEffect, useMemo, useState } from "react";
import { Doughnut } from "react-chartjs-2";

export default function CourseCompletionGraf({ props, CourseList }) {
    const [MyProgressCourse, setMyProgressCourse] = useState({});
    useEffect(() => {
        const FetchChartData = (async () => {
            let YetToStart = 0, ToatalOfInprogress = 0, ToatalOfCompleted = 0;
            if (CourseList?.length > 0) {
                CourseList.map((Item) => {
                    if (JSON.parse(Item?.CompletionStatus)) {
                        if (JSON.parse(Item?.CompletionStatus)?.progress == 100) {
                            ToatalOfCompleted += 1;
                        } else {
                            ToatalOfInprogress += 1;
                        }
                    } else {
                        YetToStart += 1;
                    }
                })
            }
            setMyProgressCourse({
                Completed: { TotalCompleted: ToatalOfCompleted, CompletedPer: CourseList?.length > 0 ? (ToatalOfCompleted / CourseList?.length) * 100 : 0 },
                Inprogress: { TotalInprogress: ToatalOfInprogress, InprogressPer: CourseList?.length > 0 ? (ToatalOfInprogress / CourseList?.length) * 100 : 0 },
                YetToStart: { TotalYetToStart: YetToStart, YetToStartPer: CourseList?.length > 0 ? (YetToStart / CourseList?.length) * 100 : 0 },
                TotalNumOfCourse: CourseList?.length > 0 ? CourseList?.length : 0
            })
        })
        FetchChartData()
        return () => {
            setMyProgressCourse({})
        }
    }, [CourseList, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload])

    const CourseCompletion = useMemo(() => {
        const Completion = {
            labels: [Math.round(MyProgressCourse?.Completed?.CompletedPer) + "% Completed", Math.round(MyProgressCourse?.Inprogress?.InprogressPer) + "% In Progress", Math.round(MyProgressCourse?.YetToStart?.YetToStartPer) + "% Yet to Start"],
            datasets: [
                {
                    data: [MyProgressCourse?.Completed?.TotalCompleted, MyProgressCourse?.Inprogress?.TotalInprogress, MyProgressCourse?.YetToStart?.TotalYetToStart],
                    backgroundColor: ["#51B75C", "orange", "#EA4E4E"],
                    hoverOffset: 4,
                },
            ],
        };
        return Completion;
    }
        , [MyProgressCourse?.Completed?.CompletedPer, MyProgressCourse?.Completed?.TotalCompleted, MyProgressCourse?.Inprogress?.InprogressPer, MyProgressCourse?.Inprogress?.TotalInprogress, MyProgressCourse?.YetToStart?.TotalYetToStart, MyProgressCourse?.YetToStart?.YetToStartPer])
    return (
        <>
         {MyProgressCourse?.TotalNumOfCourse == undefined? <NVLFetchDataLoading /> : (<div className="!w-48 relative">
                <Doughnut
                    data={CourseCompletion}
                    options={{
                        hover: { mode: null },
                        cutoutPercentage: 75,
                        legend: {
                            display: false
                        },
                        elements: {
                            arc: {
                                borderWidth: 0,
                            },
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: (context) => {
                                        const dataIndex = context.dataIndex;
                                        const label = context.chart.data.labels[dataIndex];
                                        // const value = context.chart.data.datasets[0].data[dataIndex];
                                        return `${label}`;
                                    },
                                },
                            },
                            legend: {
                                position: "right",
                                display: false,
                                labels: {
                                    padding: 25,
                                    boxWidth: 50,
                                    usePointStyle: true,
                                    font: {
                                        family: "Montserrat, sans-serif",
                                        size: 12,
                                    },
                                },
                            },
                            datalabels: {
                                color: "red",
                            }
                        },
                        cutout: "65%",

                    }}
                />
                <div className="absolute top-6 left-4 md:top-12 md:left-12 text-center text-xs font-semibold p-6 rounded-full">
                    <div>{MyProgressCourse?.TotalNumOfCourse}</div>
                    <div>Courses</div>
                </div>
            </div>)}
        </>
    )
}