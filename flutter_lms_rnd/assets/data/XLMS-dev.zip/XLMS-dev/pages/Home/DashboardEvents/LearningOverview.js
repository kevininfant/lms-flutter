import NVLFetchDataLoading from "@components/Controls/NVLFetchDataLoading";
import NVLlabel from "@components/Controls/NVLlabel";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useEffect, useState } from "react";
import { listXlmsActivityManagementInfos, listXlmsCourseManagementInfo } from "src/graphql/queries";
export default function LearningOverview({ props, DataLoading }) {
    const [ActivityList, setActivityList] = useState([]);
    const [CourseList, setCourseList] = useState([]);
    useEffect(() => {
        const FetchEventList = (async () => {
            const ActivityListResponse = await AppsyncDBconnection(
                listXlmsActivityManagementInfos,
                {
                    PK: "TENANT#" + props?.user?.attributes["custom:tenantid"],
                    SK: "ACTIVITYTYPE#",
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            setActivityList(ActivityListResponse?.res?.listXlmsActivityManagementInfos?.items)
            const CourseListResponse = await AppsyncDBconnection(
                listXlmsCourseManagementInfo,
                {
                    PK: "TENANT#" + props?.user?.attributes["custom:tenantid"],
                    SK: "COURSEINFO#",
                    IsDeleted: false,
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            setCourseList(CourseListResponse?.res?.listXlmsCourseManagementInfo?.items)
        })
        FetchEventList()
        return () => {
            setActivityList([])
        }
    }, [props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken])
    return (
        <div className="bg-[#F9FAFC] shadow p-2">
            {!ActivityList || !CourseList ? <div className="h-44"><NVLFetchDataLoading /></div> : (<>
                <NVLlabel text="Learning Overview" className="nvl-Def-Label px-4" />
                <div className=" bg-[#F9FAFC] ">
                    <div className="rounded-md w-full relative  py-4 ">
                        <div className="flex justify-evenly text-gray-700 mt-6">
                            <div className="w-24 mx-1 p-2  rounded-lg grid gap-4">
                                <NVLlabel text="Total Activity" className="nvl-Def-Label whitespace-nowrap" />
                                <div className="flex gap-2 text-3xl">
                                    <i className="fa-solid fa-book "></i>
                                    <div className="font-mono leading-none" >{ActivityList?.length}</div>
                                </div>
                            </div>
                            <div className="w-24 mx-1 p-2  rounded-lg grid gap-4">
                                <NVLlabel text="Total Course" className="nvl-Def-Label whitespace-nowrap" />
                                <div className="flex gap-2 text-3xl">
                                    <i className="fa-solid fa-graduation-cap"></i>
                                    <div className="font-mono leading-none" >{CourseList?.length}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> </>)}
        </div>

    )
}
