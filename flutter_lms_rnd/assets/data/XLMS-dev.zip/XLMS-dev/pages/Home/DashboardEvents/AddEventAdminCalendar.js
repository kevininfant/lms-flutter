import AddEventInfo from "@Pages/MySchedule/AddEventInfo";
export default function AddEventAdminCalendar(props) {
    return (
        <div>
            <AddEventInfo isComponent={true} props={props}></AddEventInfo>
        </div>
    )
}
