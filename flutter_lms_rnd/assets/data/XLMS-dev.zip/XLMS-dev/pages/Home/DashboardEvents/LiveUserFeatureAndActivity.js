import { GetDateFormat } from '@components/Common/DateFormat';
import NVLlabel from "@components/Controls/NVLlabel";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Bar } from 'react-chartjs-2';
import { getXlmsCourseActivityConfig, listXlmsActivityLiveCountInfos, listXlmsTenantInfos } from "src/graphql/queries";
export default function LiveUserFeatureAndActivity({ props }) {
    const [CompanyUserData, setCompanyUserData] = useState([]);
    const [SiteAdminUserData, setSiteAdminUserData] = useState([]);
    const UserCount = useRef()
    const ListOfActivity = useRef()

    useEffect(() => {
        const FetchLiveUserList = (async () => {
            const TypesOfActivityResponse = await AppsyncDBconnection(
                getXlmsCourseActivityConfig,
                {
                    PK: "XLMS#ACTIVITY",
                    SK: "ACTIVITY#ACTIVITYTYPE",
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            ListOfActivity.current = TypesOfActivityResponse?.res?.getXlmsCourseActivityConfig?.ActivityType != undefined && JSON.parse(TypesOfActivityResponse?.res?.getXlmsCourseActivityConfig?.ActivityType);

            if (props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin") {
                FetchFeatureActivityCompany();
            } else {
                FetchFeatureActivitySiteAdmin();
            }
        })
        FetchLiveUserList()

        // return () => {
        //     setCompanyUserData([])
        // }
    }, [FetchFeatureActivityCompany, FetchFeatureActivitySiteAdmin, props?.user?.attributes, props?.user.signInUserSession.accessToken.jwtToken])


    const FetchFeatureActivityCompany = useCallback(async () => {
        const CompanyUserList = await AppsyncDBconnection(
            listXlmsActivityLiveCountInfos,
            {
                PK: "XLMS#LIVEACTIVITYUSER",
                SK: props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin" ?
                    "TIMESPAN#" + DateFormat + "#TENANT#" + props?.user?.attributes["custom:tenantid"] + "#" :
                    "TIMESPAN#" + DateFormat + "#"
            },
            props?.user?.signInUserSession?.accessToken?.jwtToken
        )
        setCompanyUserData(CompanyUserList?.res?.listXlmsActivityLiveCountInfos?.items != undefined ?
            CompanyUserList?.res?.listXlmsActivityLiveCountInfos?.items : [])
    },[DateFormat, props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken],)

    const FetchFeatureActivitySiteAdmin = useCallback(async () => {
        const SiteUserList = await AppsyncDBconnection(
            listXlmsActivityLiveCountInfos,
            {
                PK: "XLMS#LIVEACTIVITYUSER",
                SK: "TIMESPAN#" + DateFormat + "#"
            },
            props?.user?.signInUserSession?.accessToken?.jwtToken
        )
        const Tenantinfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props?.user?.signInUserSession.accessToken.jwtToken);
        setSiteAdminUserData({
            LiveActivityUser: SiteUserList?.res?.listXlmsActivityLiveCountInfos?.items != undefined ? SiteUserList?.res?.listXlmsActivityLiveCountInfos?.items : [],
            TenantList: Tenantinfo?.res?.listXlmsTenantInfos?.items != undefined ? Tenantinfo.res?.listXlmsTenantInfos?.items : []
        })
    },
        [DateFormat, props?.user?.signInUserSession.accessToken.jwtToken],)

    const DateFormat = useMemo(() => {
        return GetDateFormat(new Date(), "dd-mm-yyyy")
    }, [])

    const FeatureActivityDataForCompany = useMemo(() => {
        let LinechartData = [], FilteredData;
        FilteredData = CompanyUserData.reduce(function (prevActivity, CurrActivity) {
            if (CurrActivity["ActivityType"]) { prevActivity[CurrActivity["ActivityType"]] = (prevActivity[CurrActivity["ActivityType"]] || 0) + 1; }
            return prevActivity;
        }, {})
        let SortedData = Object?.keys(FilteredData)?.sort().reduce((obj, key) => { obj[key] = FilteredData[key]; return obj; }, {});
        if (ListOfActivity?.current?.length > 0)
            ListOfActivity?.current?.map((data) => {
                if (SortedData?.[data] == undefined) {
                    SortedData = { ...SortedData, [data]: 0 }
                }
            })

        let SortedValue =SortedData && Object.values(SortedData).sort((a,b)=> {return a-b} )
        UserCount.current = SortedValue[SortedValue.length-1]

        LinechartData?.push({
            data: SortedData,
            label: "Users",
            borderColor: "green",
            backgroundColor: "green",
            barPercentage: 0.5,
            barThickness: 20,
            borderWidth: 1,
        })
        return { labels: ListOfActivity?.current, datasets: LinechartData }

    }, [CompanyUserData])

    const FeatureActivityDataForSiteAdmin = useMemo(() => {
        let FilteredData, Graphlabel, SortedData, data = [], AssignData = [];
        SiteAdminUserData.LiveActivityUser?.map((getItem) => {
            let TenantID = getItem.SK.split("#")[3], UserSub = getItem.SK.split("#")[6];
            if (getItem.TenantName != null) {
                AssignData.push({ ActivityType: getItem.ActivityType, UserSub: UserSub, TenantID: TenantID, TenantName: getItem.TenantName })
            }
        })
        const groupByTenantID = AssignData?.reduce((group, product) => {
            const { TenantName } = product; group[TenantName] = group[TenantName] ?? []; group[TenantName].push(product); return group;
        }, {});
        if (AssignData?.length != 0) {
            Object?.values(groupByTenantID)?.forEach((Items, index) => {
                Graphlabel = Object?.keys(groupByTenantID)[index]
                FilteredData = Items.reduce(function (prevActivity, CurrActivity) {
                    if (CurrActivity["ActivityType"]) {
                        prevActivity[CurrActivity["ActivityType"]] = (prevActivity[CurrActivity["ActivityType"]] || 0) + 1;
                    }
                    return prevActivity;
                }, {})
                SortedData = Object.keys(FilteredData).sort().reduce(
                    (obj, key) => { obj[key] = FilteredData[key]; return obj; },
                    {}
                );

                let SortedValue =SortedData && Object.values(SortedData).sort((a,b)=> {return a-b} )
                UserCount.current = SortedValue[SortedValue.length-1]

                data.push(
                    {
                        label: "Users", data: SortedData, backgroundColor: "rgba(51, 255, 255, 0.3)", fill: true, tension: 0.5, borderWidth: 1,
                    },
                )
            })
        } else {
            data.push(
                {
                    label: "Users", data: SortedData, backgroundColor: "rgba(51, 255, 255, 0.3)", fill: true, tension: 0.5, borderWidth: 1,
                },
            )
        }
        return { labels: ListOfActivity.current, datasets: data, }
    }, [SiteAdminUserData.LiveActivityUser])

    return (
        <div className="md:flex md:mb-4 bg-[#F9FAFC] shadow">
            {!props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin" ? FeatureActivityDataForCompany : FeatureActivityDataForSiteAdmin && (<>
                <div className="md:w-full flex justify-center">
                    <div className="rounded py-4 md:px-4 w-full">
                        <NVLlabel text="Live User Feature / Activity" className="nvl-Def-Label px-4" />
                        <div className=" bg-white rounded-lg py-2">
                            <Bar
                                data={props?.user?.attributes?.["custom:groupname"] == "CompanyAdmin" ? FeatureActivityDataForCompany : FeatureActivityDataForSiteAdmin}
                                options={{
                                    cutoutPercentage: 90,
                                    cutoutPercentage: 10,
                                    responsive: true,
                                    aspectRatio: 4,
                                    plugins: {
                                        legend: {
                                            display: false,
                                        },
                                    },
                                    scales: {
                                        y: {
                                            max: UserCount.current > 100 ? parseInt(UserCount.current) : 100,
                                            min: 0,
                                            ticks: {
                                                stepSize: UserCount.current > 100  ? 5  : 10
                                            }            
                                        },
                                        x: {
                                            grid: {
                                                display: false,
                                            },
                                        },
                                    },
                                }}
                            />
                            {/* <div className="flex justify-center">
            {watch("fetch") && <i className="fa fa-circle-notch fa-spin mr-2 text-3xl"></i>}</div> */}
                        </div>
                    </div>
                </div> </>)}
        </div>
    )
}
