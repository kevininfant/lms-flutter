import NVLlabel from "@components/Controls/NVLlabel";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Bar } from "react-chartjs-2";
import { listXlmsCourseManagementInfo } from "src/graphql/queries";
export default function MostVisitedCourses({ props }) {
    const [CourseList, setCourseList] = useState([]);
    const [maxCount,setMaxCount] = useState(0)

    useEffect(() => {
        const FetchMostVisited = (async () => {
            const CourseListResponse = await AppsyncDBconnection(
                listXlmsCourseManagementInfo,
                {
                    PK: "TENANT#" + props?.user?.attributes["custom:tenantid"],
                    SK: "COURSEINFO#",
                    IsDeleted: false,
                },
                props?.user?.signInUserSession?.accessToken?.jwtToken
            );      
            let VisitedList=CourseListResponse?.res?.listXlmsCourseManagementInfo?.items!=undefined&&CourseListResponse?.res?.listXlmsCourseManagementInfo?.items.sort((p1, p2) => (p1.VisitedCount < p2.VisitedCount) ? 1 : (p1.VisitedCount > p2.VisitedCount) ? -1 : 0);
            setCourseList(VisitedList)
        })
        FetchMostVisited()
        return () => { setCourseList([]) }
    }, [props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken])

    const GetVisitorCount = useCallback(() => {
        let VisitedCount = [];
        CourseList && CourseList.map((Course, idx) => { if (idx < 10) { VisitedCount.push(Course.VisitedCount) } });
        let SortedCountData = VisitedCount && VisitedCount?.sort((a,b)=>{
            return a-b;
        })
        setMaxCount(SortedCountData[SortedCountData.length -1])
        return VisitedCount;
    },
        [CourseList],
    )
    const GetCourseName = useCallback(() => {
        let CourseNameList = [];
        CourseList && CourseList.map((Course, idx) => { if (idx < 10) { CourseNameList.push(Course.CourseName) } });
        return CourseNameList;
    },
        [CourseList],
    )
    const MostVisitedCourseCount = useMemo(() => {
        let Temp = {
            labels: GetCourseName(),
            categories: ["Total", "Lower than 2.50"],
            datasets: [{ data: GetVisitorCount(),label: "Users", backgroundColor: ["#0CAAF5"], barThickness: 30, },],
        }
        return Temp;

        
        // LinechartData?.push({
        //     data: SortedData,
        //     label: "Users",
        //     borderColor: "green",
        //     backgroundColor: "green",
        //     barPercentage: 0.5,
        //     barThickness: 20,
        //     borderWidth: 1,
        // })



    }, [GetCourseName, GetVisitorCount])


    return (
        <div className="md:flex md:mb-4 bg-[#F9FAFC] shadow">
            <div className="md:w-full flex justify-center">
                <div className="rounded py-4 md:px-4 w-full">
                    <NVLlabel text="Most Visited Course" className="nvl-Def-Label px-4" />
                    <div className=" bg-white rounded-lg py-2">
                        <Bar
                            data={MostVisitedCourseCount}
                            options={{
                                cutoutPercentage: 90,
                                cutoutPercentage: 10,
                                responsive: true,
                                aspectRatio: 4,
                                plugins: {
                                    legend: {
                                        display: false,
                                    },
                                },
                                scales: {
                                    y: {
                                        max: maxCount && maxCount > 100 ? parseInt(maxCount)  : 100,
                                        min: 0,
                                        ticks: {
                                            stepSize: maxCount && maxCount > 100 ? 5  : 10
                                        }
                                    },
                                    x: {
                                        grid: {
                                            display: false,
                                        },
                                    },
                                },
                            }}
                        />
                    </div>
                </div>
            </div>
        </div>
    )
}
