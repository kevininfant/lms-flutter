
import Container from "@components/Container/Container";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import "react-calendar/dist/Calendar.css";
import CompanyDashBoardGraph from './DashboardEvents/CompanyDashBoardGraph';
import LiveUserFeatureAndActivity from './DashboardEvents/LiveUserFeatureAndActivity';
import LiveUserGraph from "./DashboardEvents/LiveUserGraph";
export default function AdminDashboard(props) {
  Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);
  const PageRoutes = [{ path: "", breadcrumb: "Site Admin Dashboard" }];
  const DataLoading = (Graph) => {
    return (
      <>
        <div className={`grid place-content-center py-3 relative h-44 w-96 ${Graph == "ActivityGraph" ? " mx-auto h-96 " : ""}`}>
          <NVLSettingsCard outerclass=" rounded-md w-full relative  ">
            <div className="Dash-loaders-shadow"></div>
            <div className="Dash-loader-box"></div>
          </NVLSettingsCard>
        </div>
      </>
    );
  };

  return (
    <Container title="Site Admin Dashboard" PageRoutes={PageRoutes}>
      <div className="lg:col-span-2 gap-4 space-y-2">
        <div className="grid lg:grid-flow-col gap-3 md:mb-4">
          <LiveUserGraph props={props} DataLoading={DataLoading} AuthRole="SiteAdmin" />
          <CompanyDashBoardGraph props={props} />
        </div>
        <LiveUserFeatureAndActivity props={props} />
        {/* <MapGraph /> */}
      </div>
    </Container>
  );
}