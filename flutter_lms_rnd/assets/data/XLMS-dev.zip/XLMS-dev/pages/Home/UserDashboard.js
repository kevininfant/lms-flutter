import Container from "@components/Container/Container";
import NVLlabel from "@components/Controls/NVLlabel";
import LearningDashboard from "@Pages/MyLearning/LearningDashboard";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import "react-calendar/dist/Calendar.css";
import { listXlmsCourseEnrollUser } from "src/graphql/queries";
import AddEventCalender from "./DashboardEvents/AddEventCalender";
import CourseCompletionGraf from "./DashboardEvents/CourseCompletionGraph";
import LearningHoursGraf from "./DashboardEvents/LearningHoursGraph";
import TodayEventAndActivities from "./DashboardEvents/TodayEventAndActivities";
import UserCompletedBadges from "./DashboardEvents/UserCompletedBadges";
import UserCompletedCertificates from "./DashboardEvents/UserCompletedCertificates";

export default function UserDashboard(props) {
  Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);
  const [ChangedDate, setChangedDate] = useState(new Date());
  const PageRoutes = [{ path: "", breadcrumb: "User Dashboard" }];
  const [CourseList, setCourseList] = useState([]);
  const router = useRouter();
  useEffect(() => {
    const FetchData = (async () => {
      const CourseListResponse = await AppsyncDBconnection(
        listXlmsCourseEnrollUser,
        {
          PK: "TENANT#" + props?.user?.attributes["custom:tenantid"] + "#COURSE#ENROLLUSER#" + props?.user?.signInUserSession?.accessToken?.payload["sub"],
          SK: "COURSE#",
          IsDeleted: false,
        },
        props?.user?.signInUserSession?.accessToken?.jwtToken
      );
      setCourseList(CourseListResponse?.res?.listXlmsCourseEnrollUser?.items)
    })
    FetchData()
    return () => { }
  }, [props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, props?.user?.signInUserSession?.accessToken?.payload])

  return (
    <>
      <Container title="User Dashboard" PageRoutes={PageRoutes}>
        <div className="md:grid md:grid-cols-2 lg:grid-cols-3 gap-4 md:mx-2 fixed bottom-0 top-24 overflow-auto p-1">
          <div className="shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] rounded-xl p-4">
            <div className="relative h-full grid place-content-center  cursor-pointer" onClick={() => router.push(`/Report/CourseProgressReport`)} >
              <NVLlabel text="My Progress" className="nvl-Def-Label absolute left-0 top-0" />
              <CourseCompletionGraf props={props} CourseList={CourseList != undefined ? CourseList : []} />
            </div>
          </div>
          <div className="flex flex-col gap-4">
            <div className="h-40 relative shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] rounded-xl  cursor-pointer" onClick={() => router.push(`/Report/LearningHours`)} >
              <LearningHoursGraf props={props}  />
            </div>
            <div className="flex gap-4 w-6/6 h-full">
              <div className="w-3/6 shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] rounded-xl p-2 cursor-pointer h-full relative" onClick={() => router.push(`/Achievement/AchievementDashBoard?parameters=2`)} >
                <NVLlabel text="Badge" className="nvl-Def-Label pb-1  absolute left-2 top-2" />
                  <UserCompletedBadges props={props} />
              </div>
              <div className="w-3/6 shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] rounded-xl p-2 cursor-pointer h-full relative" onClick={() => router.push(`/Achievement/AchievementDashBoard?parameters=3`)} >
                <NVLlabel text="Certificate" className="nvl-Def-Label pb-1 absolute left-2 top-2" />
                  <UserCompletedCertificates props={props} />
              </div>
            </div>
          </div>
          <div className="shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] rounded-xl p-1">
            <AddEventCalender setChangedDate={setChangedDate} ChangedDate={ChangedDate} AddEvent={true} />
          </div>
          <div className="h-full shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] p-1 col-span-2 rounded-xl">
            <LearningDashboard props={props} IsComponent={true} row={1} />
          </div>
          <div className="break-all shadow-[0_0.5px_5px_rgb(0,0,0,0.2)] rounded-xl">
            <NVLlabel text="Today Events & Activities" className="nvl-Def-Label whitespace p-2" />
              <TodayEventAndActivities props={props} ChangedDate={ChangedDate} />
          </div>
        </div>
      </Container>
    </>
  );
}



