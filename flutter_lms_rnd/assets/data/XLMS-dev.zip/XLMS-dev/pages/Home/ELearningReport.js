import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoadingSpinner from "@components/Controls/NVLLoadingSpinner";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import { yupResolver } from "@hookform/resolvers/yup";
import { ArcElement, BarController, BarElement, BubbleController, CategoryScale, Chart, Decimation, DoughnutController, Filler, Legend, LinearScale, LineController, LineElement, LogarithmicScale, PieController, PointElement, PolarAreaController, RadarController, RadialLinearScale, ScatterController, TimeScale, TimeSeriesScale, Title, Tooltip } from "chart.js";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Doughnut } from "react-chartjs-2";
import { useForm } from "react-hook-form";
import { listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";


Chart.register(ArcElement, LineElement, BarElement, PointElement, BarController, BubbleController, DoughnutController, LineController, PieController, PolarAreaController, RadarController, ScatterController, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale, Decimation, Filler, Legend, Title, Tooltip);

function ELearning(props) {

    const [getFilterLoginData, setValuedata] = useState();
    const [data, setData] = useState({});
    const validationSchema = Yup.object().shape({
        ddlYear: Yup.string()
            .test("", "", (e) => {
                if (e != "" && e != undefined) {
                    setValue("fetch", true);
                    fetchData(e);

                }
                return true;
            }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema) };
    const { setValue, formState, register ,watch} = useForm(formOptions);
    const { errors } = formState;
    const refLearningHours = useRef();
    const execID = useRef();
    const router = useRouter();
    const refCourseCount = useRef();
    const refRecordStatus = useRef();

    useEffect(() => {
        const dataSource = async () => {            
            const getTenantInfo = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            
            const fetchUserTeam = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/text",
                    authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    menuid: "115403",
                    tenantid: decodeURIComponent(String(router.query["TenantId"])),
                    usersub: router.query["UserSub"],
                },
                body: "Where CourseStatus=false",
            });

            const lGetUserTeamDatas = await fetchUserTeam?.res?.text();

            setData({
                TenantList: getTenantInfo.res?.listXlmsTenantInfos?.items != undefined ? getTenantInfo.res?.listXlmsTenantInfos?.items : [],
                pTenantID: props.user.attributes["custom:tenantid"],
                UserTeamData: lGetUserTeamDatas,
            });
            getLearningHours(lGetUserTeamDatas)
            setValuedata(lGetUserTeamDatas);

        };
        dataSource();
        return (() => {
            setData((temp) => { return { ...temp }; });
            setValuedata((temp) => { return { ...temp }; });
        });
    }, [getLearningHours, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query, setValue]);



    const fetchData = async (lstrYear) => {
        setValue("submit", true);
        setValue("fetch", true);

        let lqrywhere = `Where CourseStatus=false`;
        if (lstrYear != "") {
            lqrywhere += ` AND EnrolledDate LIKE '%${lstrYear}%'`;
        }
        const lGetUserData = await APIGatewayPostRequest(process.env.APIGATEWAY_REPORT_URL, {
            method: "POST",
            headers: {
                "Content-Type": "application/text",
                menuid: "115403",
                tenantid: decodeURIComponent(String(router.query["TenantId"])),
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                usersub: router.query["UserSub"],
            },
            body: lqrywhere,
        });

        const lGetUserDatas = await lGetUserData?.res?.text(); 
        getLearningHours(lGetUserDatas);       
        setValuedata(lGetUserDatas);
        setValue("submit", false);
        setValue("fetch", false);

    };

    const headerColumn = [
        { HeaderName: "Course", Columnvalue: "coursename", HeaderCss: "w-1/6" },
        { HeaderName: "Category", Columnvalue: "categoryname", HeaderCss: "w-1/6" },
        { HeaderName: "Seat Time(HH:MM:SS)", Columnvalue: "SeatTime(HH:MM:SS)", HeaderCss: "w-1/6" },
        { HeaderName: "% Completion", Columnvalue: "CompletionStatus", HeaderCss: "w-1/6" },
        { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-1/6" },
    ];

    const getLearningHours = useCallback((getFilterLoginData) => {
        const tmpviewData = getFilterLoginData != undefined && Object.values(JSON?.parse(getFilterLoginData));
        const viewData = tmpviewData?.[1] != undefined && JSON.parse(tmpviewData?.[1]);
        const courseEnrolledCount = [];

        viewData && viewData.map((item, index) => {
            if (item?.["SeatTime(HH:MM:SS)"] != "") {
                courseEnrolledCount.push(item?.["SeatTime(HH:MM:SS)"]);
            }
        });
       
         let getTime=0;
         const totalSeconds = courseEnrolledCount?.reduce((acc, val) => { 
           const [hours, minutes, seconds] =val==undefined?[0,0,0]:(val?.split(':').map(Number));           
           getTime+=((hours * 3600) + (minutes * 60) + seconds)
           return getTime;
         }, 0);        
     
         const hours = Math.floor(totalSeconds / 3600);
         const minutes = Math.floor((totalSeconds - hours * 3600) / 60);
         const seconds = totalSeconds % 60;
         
         const totalTime = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
         const [Hour,Min] = totalTime.split(":").slice(0,2)

        refLearningHours.current = Hour + ":" + Min;
    }, []);

    const doughnutProgress = {
        datasets: [
            {
                data: [refLearningHours.current && refLearningHours.current?.split(":")?.[0], 100],
                backgroundColor: [
                    "yellow",
                    "gray"
                ],
            }
        ]
    };

    const doughnutOptions = {
        responsive: false,
        elements: {
            arc: {
                borderWidth: 0,
            },
        },
        plugins: {
            legend: {
                position: "right",
                display: true,
                labels: {
                    padding: 25,
                    boxWidth: 50,
                    usePointStyle: true,
                    font: {
                        family: "Montserrat, sans-serif",
                        size: 12,
                    },
                },
            },
        },
        cutout: "80%",
        maintainAspectRatio: false,
    };

    const gridDataBind = useCallback((getFilterLoginData) => {

        const rowGrid = [];

        const tmpviewData = getFilterLoginData != undefined && Object?.values(JSON?.parse(getFilterLoginData));
        const viewData = tmpviewData?.[1] != undefined && JSON.parse(tmpviewData?.[1]);
        execID.current = getFilterLoginData != undefined && JSON?.parse(getFilterLoginData);

        viewData &&
            viewData.map((getItem, index) => {
                rowGrid.push({
                    coursename: <NVLlabel id={"txtName" + (index + 1)} text={getItem.coursename} className="py-2" />,
                    categoryname: <NVLlabel id={"txtdept" + (index + 1)} text={getItem.categoryname} />,
                    ["SeatTime(HH:MM:SS)"]: <NVLlabel id={"txtEnrolled" + (index + 1)} text={getItem["SeatTime(HH:MM:SS)"]} className="pl-10" />,
                    CompletionStatus: <NVLlabel id={"txtCompleted" + (index + 1)} text={getItem.CompletionStatus} className="pl-10" />,
                    Status: <NVLlabel id={"txtTime" + index + 1} text={getItem.Status} />,
                });
            });
            refRecordStatus.current = viewData && Object.values(viewData)?.length != 1 ? "Exist" : "NoRecord";
            if (refRecordStatus && refRecordStatus.current == "NoRecord") {
                rowGrid = []
               }
        
        return rowGrid;

    }, []);

    const completedStatus = useMemo(() => {
        const yearData = [{ value: "", text: "Filter by Year" }];
        for (let i = 1990; i <= parseInt(new Date().getFullYear()); i++) {
            yearData.push({ value: i, text: i });
        }
        return yearData;

    }, []);

    
    const pageRoutes = useMemo(() => {
        if(props?.TenantInfo?.UserGroup=="Manager"){
            return [
                { path: `/Home/UserTeam?EmailId=${router.query["EmailId"]}&UserName=${router.query["UserName"]}&TenantId=${decodeURIComponent(String(router.query["TenantId"]))}`, breadcrumb: "User Team" },
                { path: "", breadcrumb: "ELearning Report" }
            ];
        }else{
            return [
                { path: "/Analytics&Reports/ReportDashboard", breadcrumb: "Reports Dashboard" },
                { path: "/Analytics&Reports/ReportList", breadcrumb: "Reports" },
                { path: "/Analytics&Reports/UserWiseCourseSummary", breadcrumb: "User Wise Course Summary" },
                { path: `/Home/UserTeam?EmailId=${router.query["EmailId"]}&UserName=${router.query["UserName"]}&TenantId=${decodeURIComponent(String(router.query["TenantId"]))}`, breadcrumb: "User Team" },
                { path: "", breadcrumb: "ELearning Report" }
            ];
        }        
    }, [router.query,props?.TenantInfo?.UserGroup]);

    return (
        <>
            <Container title="User Course Summary Report" PageRoutes={pageRoutes} loader={data?.TenantList == undefined}>
                <form className="px-2">
                    {/* <NVLHeader isBackAction={true} Header="E-Learning Report" RedirectHome={"/Analytics&Reports/UserWiseCourseSummary"} /> */}
                    <div className=" flex gap-4 col-span-6 sm:col-span-3 justify-center">
                        <NVLlabel htmlFor="Year" className="block text-sm font-medium text-gray-600 py-2">
                            Select Year :
                        </NVLlabel>
                        <NVLSelectField id="ddlYear" className="mt-1 block w-36 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-sm" register={register} options={completedStatus} errors={errors} />
                    </div>
                    <div className="px-3 flex justify-center py-4" id="divFilter">
                        <div className="block rounded-lg py-4 ">
                            <div className="py-3 pb-4">
                                {/* <div className="bg-[#F9FAFC] w-full shadow flex justify-start p-4"> */}
                                {/* Doughnut chart */}
                                <div className="grid place-content-center ">
                                    <NVLSettingsCard outerclass=" rounded-md px-4 w-full relative p-2 md:p-0">
                                        <Doughnut data={doughnutProgress} options={doughnutOptions} class="DoughnutClass" />
                                        <div className="absolute top-6 left-4 md:top-8 md:left-7 text-center text-xs font-semibold p-6 float-left rounded-full">
                                            <div>{(refCourseCount.current && Object.values(refCourseCount.current)?.length != 1) ? Object.values(refCourseCount.current)?.length : ""}</div>
                                            <div className='text align-center px-14 absolute top-2'>HH:MM</div>
                                            <div className='font text-lg text align-center px-14 absolute top-6'>{refLearningHours.current && refLearningHours.current}</div>
                                            <div className='text-blue-500 text align-center px-14 absolute top-12 '>Learning</div>
                                            <div className='text-blue-500 text align-center px-14 absolute top-16'>Hours</div>
                                        </div>
                                    </NVLSettingsCard>
                                </div>
                            </div>
                        </div>
                    </div>
                    {!watch("fetch") && <div>
                    <NVLGridTable id="tblUserList" className="max-w-full" HeaderColumn={headerColumn}
                        RowGridDataPass={{ RowGrid: gridDataBind(getFilterLoginData) }} />
                       </div>}
                       {watch("fetch") &&  <div>
                            <NVLLoadingSpinner />
                        </div>}
                </form>

            </Container>
        </>
    );
}

export default ELearning;
