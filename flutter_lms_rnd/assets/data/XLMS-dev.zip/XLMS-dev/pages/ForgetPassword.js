import NVLButton from "@components/Controls/NVLButton";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayGetRequest } from "DBConnection/ErrorResponse";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";



function ForgetPassword(props) {
    const [currentStep, setCrrentStep] = useState(1);
    const validationSchema = Yup.object().shape({
        txtuserName: currentStep == 1 ? Yup.string().required("Enter a city") : Yup.string(),
        txtcode: currentStep == 2 ? Yup.string().required("Enter a state").matches(Regex("AllowAlphaNumWithSpace"), "Invalid State").max(50, "Maximum 50 characters Reached") : Yup.string(),
        txtpassword: currentStep == 2 ? Yup.string().required("Choose a country") : Yup.string(),
        txtconfirmpassword: currentStep == 2 ? Yup.string() : Yup.string(),
    });
    // Auth.forgotPasswordSubmit("asaithambi.s@novactech.in", "187611","Test@1")
    //     .then(data => console.log(data))
    //     .catch(err => console.log(err));
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true };
    const { register, handleSubmit, watch, formState } = useForm(formOptions);
    const { errors } = formState;
    const submitHandler = async (data) => {
        if (currentStep == 1) {
            let FinalStatus = await APIGatewayGetRequest(process.env.FORGET_PASSWORD + "?UserName=" + data.txtuserName, { method: "GET" });       
            // Auth.forgotPassword(data.txtuserName)
            //     .then(async (response) => {            

            //         console.log(response)
            //         setCrrentStep((currentStep) => {
            //             return currentStep++;
            //         })

            //     })
            //     .catch(err => {
            //     console.log(err)

            //     });

        }
        else if (currentStep == 2) {

        }
    }
    return (
        <>
            <form onSubmit={handleSubmit(submitHandler)} className="px-2">

                {currentStep == 1 &&
                    <NVLTextbox id="txtuserName" labelText="UserName" labelClassName="nvl-Def-Label" errors={errors} title="Enter Username" className="nvl-mandatory nvl-Def-Input" register={register} />
                }
                {currentStep == 2 &&
                    <>
                        <NVLTextbox id="txtcode" labelText="Code" labelClassName="nvl-Def-Label" errors={errors} title="Enter Username" className="nvl-mandatory nvl-Def-Input" register={register} />
                        <NVLTextbox id="txtpassword" labelText="Password" labelClassName="nvl-Def-Label" errors={errors} title="Enter Username" className="nvl-mandatory nvl-Def-Input" register={register} />
                        <NVLTextbox id="txtconfirmpassword" labelText="Confirm Password" labelClassName="nvl-Def-Label" errors={errors} title="Enter Username" className="nvl-mandatory nvl-Def-Input" register={register} />
                    </>
                }
                <NVLButton id="btnSubmit" text={currentStep == 1 ? "Send Code" : "Update Password"} type="submit" ></NVLButton>

            </form>

        </>
    );
}

export default ForgetPassword;