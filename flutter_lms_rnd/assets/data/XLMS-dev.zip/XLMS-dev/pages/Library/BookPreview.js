import Container from "@components/Container/Container";
import NVLFileViewer from "@components/Controls/NVLFileViewer";
import { getXlmsAssetInfo } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

export default function BookPreview(props){
    const router = useRouter()
    const [assetData,setAssetData] = useState()
    useEffect(()=>{
        async function getAssetData(){
            const Asset = await AppsyncDBconnection(getXlmsAssetInfo,{PK: "TENANT#"+encodeURIComponent(router.query["TenantID"]), SK: "KNOWLEDGEREPO#ASSET#"+encodeURIComponent(router.query["AssetID"]) },props?.user?.signInUserSession?.accessToken?.jwtToken )
            setAssetData(Asset.res?.getXlmsAssetInfo)
        }
        getAssetData()
    },[props?.user?.signInUserSession?.accessToken?.jwtToken, router.query])

    const PageRoutes = [
        {path: "/Library/LibraryList",breadcrumb: "Library"},
        {path: "",breadcrumb: "Preview"}]

    return (
        <>
        <Container PageRoutes={PageRoutes} title="Preview" >
         <NVLFileViewer token={props?.user?.signInUserSession?.accessToken?.jwtToken} src={assetData && assetData?.UploadFile} MpdUrlPath={assetData && assetData.FileType =="Video" ? assetData?.MpdUrlPath : ""} BucketName={props?.TenantInfo?.BucketName} IsDownload={assetData && assetData?.IsDownloadAccess}></NVLFileViewer>
         </Container>
        </>
    )

}