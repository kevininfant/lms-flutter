import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLImage from "@components/Controls/NVLImage";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import { listXlmsActiveAssetInfo, listXlmsActiveRepositoryCategory } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function LibraryList(props) {
    const [openCategoryBar, setOpenCategoryBar] = useState(false)
    const [listData, setlistData] = useState()
    const [assetData, setAssetData] = useState()
    const textDisplay = useRef()
    const refAssetName = useRef()
    const [IsShowCategoryMore, setIsShowCategoryMore] = useState(true);
    const router = useRouter()
    const [open, setOpen] = useState(true)
    const toggle = useCallback(() => {
        setOpen(!open)
    }, [open])
    const [getIndex, setIndex] = useState()
    const validationSchema = Yup.object().shape({})
    useEffect(() => {
        async function fetchData() {
            const CategoryList = await AppsyncDBconnection(listXlmsActiveRepositoryCategory, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#CATEGORY#", IsSuspend: false, IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            const AssetList = await AppsyncDBconnection(listXlmsActiveAssetInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#ASSET#", IsSuspend: false, IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)

            setAssetData(AssetList?.res?.listXlmsActiveAssetInfo?.items ? AssetList?.res?.listXlmsActiveAssetInfo?.items : [])
            setlistData({
                Category: CategoryList?.res?.listXlmsActiveRepositoryCategory?.items ? CategoryList?.res?.listXlmsActiveRepositoryCategory?.items : [],
                Assets: AssetList?.res?.listXlmsActiveAssetInfo?.items ? AssetList?.res?.listXlmsActiveAssetInfo?.items : []
            })

        }
        fetchData()
        return (() => {
            setlistData((temp) => { return { ...temp } })
            setAssetData((temp) => { return { ...temp } })
        })

    }, [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken])

    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: true,
    };


    const { register, watch, formState, reset, handleSubmit, setValue } = useForm(formOptions);
    const { errors } = formState;

    const PageRoutes = [{
        path: "",
        breadcrumb: "Library"
    }]

    const assetDisplay = useCallback((reset) => {
        if (!reset) {
            document.getElementById("txtSearchAsset").value = ""
        }
        const AssetType = ["e-book", "Video", "Audio", "Image", "Document", "URL"]
        if (reset) {
            AssetType && AssetType.map((typeName) => {
                setValue("chkAll", false)
                setValue(typeName, false)
                textDisplay.current = ""
            })
        } else {
            if (document.getElementById("chkAll").checked == true) {
                AssetType && AssetType.map((typeName) => {
                    setValue(typeName, true)
                    textDisplay.current = ""
                })
                setlistData((temp) => { return { ...temp, Assets: assetData } })
            } else {
                AssetType && AssetType.map((typeName) => {
                    setValue(typeName, false)
                    textDisplay.current = ""
                })
                setlistData((temp) => { return { ...temp, Assets: assetData } })
            }
        }
    }, [assetData, setValue])

    const filterAsset = useCallback((assetType) => {
        document.getElementById("txtSearchAsset").value = "";
        const filteredData = []
        const assetChecked = ["e-book", "Video", "Audio", "Image", "Document", "URL"]
        let result = [], check = 0;
        assetChecked.map((item, idx) => {
            result.push(document.getElementById(item)?.checked);
            if (!document.getElementById(item)?.checked) {
                check++;
            }
        });
        if (check == 0) {
            setValue("chkAll", true);
        } else {
            setValue("chkAll", false);
        }
        if (result.indexOf(true) == -1) {
            textDisplay.current = ""
            setlistData((temp) => { return { ...temp, Assets: assetData } })
        } else {
            if (assetType != undefined && assetType != "") {
                assetData.filter((getItem) => {
                    let FileType = getItem.FileType == "Document" && getItem.UploadFile?.split(".").pop() == "pdf" ? "e-book" : getItem.FileType == "Document" && getItem.UploadFile?.split(".").pop() != "pdf" ? "Document" : getItem.FileType
                    if (document.getElementById(FileType)?.checked) {
                        filteredData.push(getItem);
                    }
                })
            }
            if (filteredData.length == 0) {
                textDisplay.current = "No asset data found based on applied filter"
                setlistData((temp) => { return { ...temp, Assets: [] } })
            } else {
                textDisplay.current = "Filter result found"
                setlistData((temp) => { return { ...temp, Assets: filteredData } })
            }
        }
    }, [assetData, setValue])

    const filterCategoryAsset = useCallback((categoryID, assetID) => {
        document.getElementById("txtSearchAsset").value = "";
        assetDisplay("reset")
        const filteredData = []
        if (assetID != undefined) {
            assetData && assetData.filter((asset) => {
                if (asset.AssetID == assetID) {
                    filteredData.push(asset)
                }
            })
        } else if (assetID == undefined) {
            assetData && assetData.filter((getItem) => {
                if (getItem.CategoryID == categoryID) {
                    filteredData.push(getItem)
                }
            })
        }

        if (filteredData.length == 0) {
            textDisplay.current = "No asset data found based on applied filter"
            setlistData((temp) => { return { ...temp, Assets: [] } })
        } else {
            textDisplay.current = "Filter result found"
            setlistData((temp) => { return { ...temp, Assets: filteredData } })
        }
    }, [assetData, assetDisplay])

    const searchByAssetName = useCallback((e) => {
        assetDisplay("reset")
        const searchData = []
        if (refAssetName.current.value != "") {
            assetData && assetData.filter((asset) => {
                if (asset.AssetName.toLowerCase()?.includes(refAssetName.current.value.toLowerCase())) {
                    searchData.push(asset)
                }
            })
        }
        if (searchData.length == 0) {
            textDisplay.current = "We could not find the asset you're looking for. "
            setlistData((temp) => { return { ...temp, Assets: [] } })
        } else {
            textDisplay.current = "Search result found..."
            setlistData((temp) => { return { ...temp, Assets: searchData } })
        }

        if (refAssetName.current.value == "") {
            textDisplay.current = ""
            setlistData((temp) => { return { ...temp, Assets: assetData } })
        }

    }, [assetData, assetDisplay])

    const Checkboxes = useCallback(() => {
        const AssetType = ["e-book", "Video", "Audio", "Image", "Document", "URL"]
        return <>
            <div className="pt-2 !text-slate-700 font-bold">
                <NVLCheckbox id={"chkAll"} name={"chkAll"} text={"All"} errors={errors} register={register} onClick={() => { assetDisplay() }} className="cursor-pointer" />
            </div>
            {AssetType && AssetType.map((type, index) => {
                return (
                    <div key={index}>
                        <>
                            <div className="pt-2 !text-slate-700 ">
                                <NVLCheckbox id={type} name={type} text={type == "URL" ? "Web Link" : type} errors={errors} register={register} className=" cursor-pointer" onClick={(e) => { filterAsset(type) }} />
                            </div>
                        </>
                    </div>
                )
            })
            }

        </>
    }, [assetDisplay, errors, filterAsset, register])

    const SubDivHandler = (index) => {
        document.getElementById("divsubName" + index)?.classList?.toggle("hidden");
        document.getElementById("divSubAction" + index)?.classList?.toggle("hidden");
        document.getElementById("ShowCatIcon" + index)?.classList?.toggle("hidden");
        document.getElementById("ShowSubIcon" + index)?.classList?.toggle("hidden");
    };

    const onButtonClick = useCallback(async (File) => {
        setValue("id", true)
        let fetchURL = process.env.APIGATEWAY_INVOKEURL;

        let headers = {
            method: "POST",
            headers: {
                authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                bucketName: props?.TenantInfo?.BucketName,
            },
            body: File.substring(1),
        };
        let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);

        const handleDownload = (url) => {
            fetch(url).then(response => {
                response.blob().then(blob => {
                    const fileURL = window.URL.createObjectURL(blob);
                    let link = document.createElement('a');
                    let temp = File.split("/")
                    link.href = fileURL;
                    link.download = temp.at(-1);
                    link.click();
                    link.remove();
                })
            })
        };
        handleDownload(await FinalStatus.res?.text())
        setValue("id", false)

    }, [setValue, props?.user?.signInUserSession?.accessToken?.jwtToken, props?.TenantInfo?.BucketName])

    const openInNewTab = useCallback((url) => {
        const newWindow = window.open(url, "_blank", "noopener,noreferrer");
        if (newWindow) newWindow.opener = null;
    }, [])


    const isFetchSubCategories = useCallback((parentCategoryId) => {
        let newArray = assetData && assetData?.filter(function (el) {
            return el.CategoryID == parentCategoryId;
        });
        return newArray?.length;
    }, [assetData])
    return (
        <>
            <Container title="Library" PageRoutes={PageRoutes} loader={listData == undefined ? true : false}>
                <div className='lg:flex gap-4'>
                    <main className=" w-full space-y-4">
                        <div className='h-10 bg-slate-50 '>
                            <div className="p-2 bg-[#f9fafc] flex justify-between">
                                <div className='w-56 relative'>
                                    <input id="txtSearchAsset" ref={refAssetName} className="nvl-Dash-input !w-full !text-xs " type="search" name="search" placeholder="Search By Asset Name" onChange={(e) => searchByAssetName(e)} />
                                    <button type="submit" className="absolute -right-4 bottom-2 ">
                                        <i className="fa-solid fa-magnifying-glass h-4 w-4 absolute -bottom-0.5 right-6 text-gray-400" onClick={(e) => searchByAssetName(e)}></i>
                                    </button>
                                </div>
                                <div>
                                    <span className='text-xs px-2 font-semibold text-slate-600 ' id="lblResults" >{textDisplay.current}</span>
                                    {(textDisplay.current == "" || textDisplay.current == undefined) && <span className='text-xs px-2 text-gray-700 font-semibold my-auto'> Total number of assets : {listData?.Assets.length}
                                    </span>}
                                </div>
                            </div>
                        </div>
                        {listData && <div className={`grid grid-cols-1 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-3 ${!openCategoryBar ? " xl:grid-cols-3" : " xl:grid-cols-4"} gap-6 w-full  p-2`}>
                            {listData && listData?.Assets.map((asset, index) => {
                                if (!asset?.IsSuspend) {
                                    return (<div key={crypto.randomUUID()} className="bg-white rounded overflow-hidden shadow-lg hover:-translate-y-1 hover:shadow-[rgba(0,_0,_0,_0.24)_0px_3px_8px] ease-in duration-150 cursor-pointer">
                                        <div className='!h-28 relative overflow-hidden group'>
                                            <NVLImage className="hover:bg-blend-saturation h-full w-full duration-500" src={`${asset.ThumbNail ? asset.ThumbNail : "/books.jpg"}`} alt="Asset" onClick={() => {
                                                asset.FileType != "URL" ? router.push(`/Library/BookPreview?TenantID=${props?.TenantInfo.TenantID}&AssetID=${asset.AssetID}`) : openInNewTab(asset.AttachURL)
                                            }} />
                                            <div className="bg-[rgba(0,0,0,0.34)] text-white absolute -top-[100%] h-[100%] w-[100%] ease-in duration-300 group-hover:top-0 text-center text-xs p-2">
                                                <NVLButton text={`View`} onClick={() => { asset.FileType != "URL" ? router.push(`/Library/BookPreview?TenantID=${props?.TenantInfo.TenantID}&AssetID=${asset.AssetID}`) : openInNewTab(asset.AttachURL) }} className={`nvl-button bg-primary text-white !rounded-full mt-8`} />
                                            </div>
                                        </div>
                                        <div className="">
                                            <div className='w-full bg-slate-100 flex justify-center'><div className='w-8 h-1 bg-primary rounded-full'></div></div>
                                        </div>
                                        <div className="p-2">
                                            <div className="flex justify-between text-gray-600">
                                                <NVLlabel showFull={true} className="text-slate-700 font-bold !text-sm cursor-pointer !break-all my-auto"
                                                    text={asset.AssetName} onClick={() => { asset.FileType != "URL" ? router.push(`/Library/BookPreview?TenantID=${props?.TenantInfo.TenantID}&AssetID=${asset.AssetID}`) : openInNewTab(asset.AttachURL) }}> </NVLlabel>
                                                <i className={`${(asset.IsDownloadAccess) ? "" : "invisible "} fa-solid ${(watch("id") && getIndex == "btnDownload" + index) ? "fa-circle-notch fa-spin" : "fa-download"} text-slate-700 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-slate-100`} aria-hidden="true" title='Certificate' onClick={() => { onButtonClick(asset?.UploadFile); setIndex("btnDownload" + index) }} id={`btnDownload${index}`}></i>
                                            </div>
                                            <NVLlabel className="text-gray-700 pt-2 text-[10px]" text={`Type : ${asset?.FileType == "URL" ? "Web Link" : asset?.FileType == "Document" && asset?.UploadFile?.split(".").pop() == "pdf" ? "E-book" : asset.FileType}`} />
                                            <NVLlabel className={`${asset.Author != "" ? "text-gray-700 text-[10px] pt-1 break-all" : "text-gray-700 font-bold text-tiny pt-1 hidden"} `} text={`Author : ${asset.Author}`} />
                                        </div>
                                    </div>
                                    )
                                }
                            })
                            }
                        </div>}
                    </main>
                    <div className={`${!openCategoryBar && "hidden"} `}>
                        <button onClick={() => setOpenCategoryBar(!openCategoryBar)} type="button" className={`  bg-primary text-white shadow-md duration-300 float-right left-4 py-2 h-10 w-5 rounded-l-lg  border-gray-200  px-2  text-xs`}>
                            {openCategoryBar ? <i className="fa-solid fa-chevron-left"></i> : <i className="fa-solid fa-chevron-right"></i>}
                        </button>
                    </div>
                    <div className={` ${openCategoryBar ? "hidden " : "block relative"} w-full lg:w-[35%] flex flex-col bg-red-20 text-xs duration-700 `}>
                        <div className={`${!openCategoryBar && "absolute -left-5"} `}>
                            <button onClick={() => setOpenCategoryBar(!openCategoryBar)} type="button" className={`  bg-primary text-white shadow-md duration-300 float-right left-4 py-2 h-10 w-5 rounded-l-lg  border-gray-200  px-2  text-xs`}>
                                {openCategoryBar ? <i className="fa-solid fa-chevron-left"></i> : <i className="fa-solid fa-chevron-right"></i>}
                            </button>
                        </div>
                        <nav className="  w-full ">
                            <div className=" w-full">
                                {/* CategoryList */}
                                <div className="space-y-3 min-h-screen max-h-min">
                                    <div className="bg-[#f9fafc]  p-3">
                                        <NVLlabel text="Search by Category"
                                            className="font-semibold !text-sm text-gray-700" />
                                    </div>
                                    <ul className="space-y-2 p-2 bg-[#f9fafc] ">
                                        <li className='border bg-white '>
                                            <a className=" bg-opacity-30 nvl-Def-Label py-1.5 rounded cursor-pointer " >
                                                <span className="items-center">
                                                    {listData && listData?.Category?.map((getItem, index) => {
                                                        return (
                                                            <div key={index}>
                                                                <>
                                                                    <div >
                                                                        <div className={`pl-2 text-blue-500 ${(index > 10 && IsShowCategoryMore) ? "hidden" : ""}`}>
                                                                            <div className="flex px-2" >
                                                                                {(getItem.CategoryName && !getItem?.IsSuspend) && (
                                                                                    <>
                                                                                        {(isFetchSubCategories(getItem?.CategoryID) != 0) && <>
                                                                                            <i className="fa fa-caret-right text-md cursor-pointer my-auto" id={"ShowCatIcon" + getItem?.CategoryID}
                                                                                                onClick={() => SubDivHandler(getItem.CategoryID)}></i>
                                                                                            <i className="fa fa-caret-down text-md hidden cursor-pointer my-auto" id={"ShowSubIcon" + getItem?.CategoryID} onClick={() => { SubDivHandler(getItem.CategoryID) }}></i>
                                                                                        </>}
                                                                                        <NVLLink id={"txtCategoryName" + (index + 1)} title={getItem?.CategoryName}
                                                                                            text={getItem?.CategoryName} onClick={() => { SubDivHandler(getItem.CategoryID); props.RoleData.FilterbyRepositoryCategory && filterCategoryAsset(getItem.CategoryID) }}
                                                                                            className={" cursor-pointer text-slate-700"}
                                                                                        ></NVLLink>
                                                                                    </>
                                                                                )}
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div id={"divsubName" + getItem?.CategoryID} className="hidden pl-4 break-all">
                                                                        {assetData?.length > 0 && assetData?.map((Asset, idx) => {
                                                                            return (
                                                                                <div key={idx}>
                                                                                    <div>
                                                                                        {(getItem?.CategoryID == Asset?.CategoryID && Asset?.AssetName != null && !Asset?.IsSuspend) && (
                                                                                            <div>
                                                                                                <div className="flex pl-2 text-blue-500  ">
                                                                                                    <div  >
                                                                                                        <NVLLink id={"txtName" + (index + 1)} title={Asset?.AssetName} text={Asset?.AssetName}
                                                                                                            className="text-slate-700 cursor-pointer"
                                                                                                            onClick={() => props.RoleData.FilterbyRepositoryAssets && filterCategoryAsset(getItem.CategoryID, Asset.AssetID)}
                                                                                                        ></NVLLink>
                                                                                                    </div>
                                                                                                </div>
                                                                                            </div>
                                                                                        )}
                                                                                    </div>
                                                                                </div>
                                                                            );
                                                                        })}
                                                                    </div>
                                                                </>
                                                            </div>
                                                        )
                                                    })}
                                                    <div className='p-2 bg-[#f9fafc] '>
                                                        {listData && listData?.Category?.length > 10 && <span className="text-blue-900 " onClick={() => setIsShowCategoryMore((prev) => !prev)}>
                                                            {IsShowCategoryMore ? <>More Category <i className="fa-solid fa-chevron-down"></i></> : <>Less Category <i className="fa-solid fa-chevron-up"></i></>}
                                                        </span>}
                                                    </div>
                                                </span>
                                            </a>
                                        </li>
                                        <li>
                                            <NVLlabel text="Search by Asset type" className="text-slate-700 font-semibold px-1" />
                                            <div className="px-4 pt-2 ">
                                                {Checkboxes()}
                                            </div>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                        </nav>

                    </div>
                </div>
            </Container>
        </>
    )
}
export default LibraryList;