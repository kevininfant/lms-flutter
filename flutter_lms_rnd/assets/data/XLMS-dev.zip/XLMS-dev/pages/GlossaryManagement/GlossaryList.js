import Container from "@components/Container/Container";
import NVLCard from "@components/Controls/NVLCard";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import { updateXlmsGlossaryManagement } from "@graphql/graphql/mutations";
import { listXlmsGlossaryManagementInfo } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";

function GlossaryList(props) {
  const router = useRouter();
  const [search, setSearch] = useState("")
  const [popupValues, setPopupValues] = useState({});
  const [isRefreshing, setIsRefreshing] = useState(true);

  const [searchClick, setSearchClick] = useState({
    id: 0,
    search: false,
    letter: ""
  })

  const alphabets = useMemo(() => {
    let letters = ["Special", "All"]
    let a = 1
    for (let i = 65; i <= 90; i++) {
      letters.splice(a, 0, String.fromCharCode(i));
      a++;
    }
    return letters;
  }, []);
  const glossaryList = useMemo(() => {
    return {
      PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "GLOSSARY#CONCEPT#PATTERN#", IsDeleted: false, GlossaryType: searchClick.search == false || (searchClick.search == true && searchClick.letter == "All") ? "" : "Pattern", Pattern: searchClick.search == false || (searchClick.search == true && searchClick.letter == "All") ? "" : searchClick.letter
    }
  }, [props?.TenantInfo.TenantID, searchClick.letter, searchClick.search])
  const headerHandler = ((e, url) => {
    e.preventDefault()
    router.push(url)
  })


  const PageRoutes = useMemo(() => {
    return [{ path: "", breadcrumb: "Glossary Management" }]
  }, [])
  const headerColumn = useMemo(() => {
    return [{ HeaderName: "", Columnvalue: "Concept" }];
  }, []);


  //Search box
  const searchBoxVal = (e) => {
    setSearch(e);
    setIsRefreshing((count) => {
      return count + 1;
    });
  };

  //Grid data refresh
  const refreshData = useCallback(() => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  }, [])

  const deleteGlossaryData = useCallback(async (e) => {
    e.preventDefault();
    let updateData = { ...popupValues.updateData, IsDeleted: true }
    delete updateData.__typename
    const finalStatus = (await AppsyncDBconnection(updateXlmsGlossaryManagement, { input: { ...updateData } }, props?.user?.signInUserSession?.accessToken?.jwtToken))
    if (finalStatus.Status == "Success") {
      refreshData();
    }
    resetPopUp();

  }, [popupValues.updateData, props?.user?.signInUserSession?.accessToken?.jwtToken, refreshData])


  function popup(PK, SK, data) {

    setPopupValues({ PK: PK, SK: SK, Content: "Are you sure to delete the Concept?", updateData: data });
  }
  const gridDataBind = useCallback((glossaryData) => {
    let rowGrid = [];
    glossaryData.map((data, index) => {
      rowGrid.push({
        Concept: <NVLCard id={'card' + index + 1} data={data}
          editGlossaryData={() => router.push(`/GlossaryManagement/AddNewEntry?ConceptID=${data.ConceptID}&Pattern=${encodeURIComponent(data.ConceptName.charAt(0).toUpperCase())}`)
          } deleteData={() => popup(data.PK, data.SK, data)} />
      })
    })
    return rowGrid;
  }, [router])

  const searchWithAlphabets = (letter, index) => {

    refreshData()
    if (document.getElementById("tableSearch")) {
      document.getElementById("tableSearch").value = "";
    }
    setSearchClick({ id: index, search: true, letter: letter })
  }
  function resetPopUp() {

    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
  }
  const cancelEvent = (e) => {
    e.preventDefault();
    resetPopUp();
  };


  return (
    <>
      <Container title="Glossary Management" PageRoutes={PageRoutes}>
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab}
          IsSearch={props.RoleData?.SeTenanthGlossary ? true : false}
          ButtonID5="btnAddNewEntry"
          LinkName5="+ Add New Entry"
          className5={props.RoleData?.AddNewEntry ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"}
          RedirectHome={"/"} RedirectAction5={(e) => headerHandler(e, "/GlossaryManagement/AddNewEntry")}
          href5="/GlossaryManagement/AddNewEntry" ButttonID4="btnBulkUpload"
          LinkName4="Bulk Upload" className4={`hidden ${props.RoleData?.AddNewEntry ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"}`}
          RedirectAction4={(e) => headerHandler(e, "/GlossaryManagement/BulkUpload")}
          href4="/GlossaryManagement/BulkUpload" placeholder={"Search by Concept or Keyword "}
          SearchonChange={(e) => searchBoxVal(e)}  onClick1={refreshData} IsNestedHeader />
        <h1 className="p-3">Browse the glossary using this index</h1>
        <div className="h-14 border-b-gray-300 border-t-white border-x-white border-2">
          {alphabets.map((letters, index) => {
            return (
              <div className=" gap-2 inline-block" key={index}>
                <div>
                  <button className={`text-blue-600 font-semibold ${letters == "All" && searchClick.search == false ? "text-gray-700" : searchClick.search && index == searchClick.id ? "text-gray-700" : ""}`} onClick={() => searchWithAlphabets(letters, index)}>{letters} </button>  |
                </div>
              </div>
            )
          })}
        </div>

        <div className="px-10 pt-3">
          <NVLGridTable
            id="glossary"
            user={props?.user}
            HeaderColumn={headerColumn}
            GridDataBind={gridDataBind}
            query={listXlmsGlossaryManagementInfo}
            querryName={"listXlmsGlossaryManagementInfo"}
            variable={glossaryList}
            refershPage={isRefreshing}
            Search={search}
            glossary={true}
            DonotLoad={true}
          />
        </div>

        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => deleteGlossaryData(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />

      </Container>
    </>
  )
}
export default GlossaryList;

