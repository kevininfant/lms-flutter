import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultipleFileUpload from "@components/Controls/NVLMultipleFileUpload";
import NVLRichTextBox, { getContents, setContents } from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsGlossaryManagement, updateXlmsGlossaryManagement } from "@graphql/graphql/mutations";
import { getXlmsGlossaryManagement, listXlmsGlossaryManagementInfo } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayGetRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { WithContext as ReactTags } from "react-tag-input";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";

function AddNewEntry(props) {
  let totalSize = 0
  const [glossaryEditData, setGlossaryEditData] = useState({})
  const [Message, setMessage] = useState("");
  const [tags, setTags] = useState([]);
  const [fileValues, setFileValues] = useState([{
    FileName: router?.query["ConceptID"] != undefined ? JSON.parse(glossaryEditData?.EditData?.AttachFile?.FileName) : "",
    FileSize: router?.query["ConceptID"] != undefined ? JSON.parse(glossaryEditData?.EditData?.AttachFile?.FileSize) : 0,
    FilePath: router?.query["ConceptID"] != undefined ? JSON.parse(glossaryEditData?.EditData?.AttachFile?.FilePath) : "",
    PathChanged: false,
    id: router?.query["ConceptID"] != undefined ? JSON.parse(glossaryEditData?.EditData?.AttachFile?.id) : ""
  }])
  const [modalValues, setModalValues] = useState({
    ModalType: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      router.push("/GlossaryManagement/GlossaryList")
    },
  });
  const router = useRouter()

  const keyCodes = { comma: 188, enter: 13, tab: 9, };
  const delimiters = [keyCodes.comma, keyCodes.enter, keyCodes.tab];
  const handleDelete = (i) => {
    setTags(tags.filter((tag, index) => index !== i));
    setValue("ReactTags", "Delete", { shouldValidate: true });
  };
  const handleAddition = (tag) => {
    setTags([...tags, tag]);
    setValue("ReactTags", "Add", { shouldValidate: true });
  };
  const handleDrag = (tag, currPos, newPos) => {
    const newTags = tags.slice();
    newTags.splice(currPos, 1);
    newTags.splice(newPos, 0, tag);
    setTags(newTags);
  };

  useEffect(() => {
    async function fetchGlossaryData() {
      const conceptId = router.query["ConceptID"];
      const pattern = decodeURIComponent(router.query["Pattern"]);
      const editData = await AppsyncDBconnection(getXlmsGlossaryManagement, { PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "GLOSSARY#CONCEPT#PATTERN#" + pattern + "#" + conceptId }, props?.user?.signInUserSession?.accessToken?.jwtToken)

      setGlossaryEditData({ EditData: editData?.res?.getXlmsGlossaryManagement })
    }
    fetchGlossaryData()
    setValue("add", true)

    if (Message != "") {

      Message?.on("text-change", (e) => {
        const regex = new RegExp(/^\s+|\s+$/g);
        if (!regex.test(e)) {
          setValue("random", "Invalid", { shouldValidate: true });

        }
        if (getContents(Message) == "" || getContents(Message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {

          setValue("random", "Empty", { shouldValidate: true });
        } else {

          setValue("random", "NotEmpty", { shouldValidate: true });
        }
      });
    }
  }, [Message, props?.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query, setValue])
  useEffect(() => {
    if (router.query["ConceptID"] != undefined) {
      setValue("txtConcept", glossaryEditData?.EditData?.ConceptName)
      if (Message != "") {
        setContents(glossaryEditData?.EditData?.Definition.replaceAll(/(<([^>]+)>)/gi, ""), Message);

        setValue("random", "NotEmpty", { shouldValidate: true });
        Message?.history?.clear();
      }
    }

  }, [Message, glossaryEditData?.EditData?.AttachFile, glossaryEditData?.EditData?.AttachFiles, glossaryEditData?.EditData?.ConceptName, glossaryEditData?.EditData?.Definition, glossaryEditData?.EditData?.Keywords, router?.query, setError, setValue, watch])
  useMemo(() => {
    if (glossaryEditData?.EditData != undefined) {
      if (glossaryEditData?.EditData?.Keywords) {
        setTags(JSON.parse(glossaryEditData?.EditData?.Keywords));
      }
      if (glossaryEditData?.EditData?.AttachFile) {
        setFileValues(JSON.parse(glossaryEditData?.EditData?.AttachFile))
      }
    }
  }, [glossaryEditData?.EditData]);
  const validationSchema = Yup.object().shape({

    txtConcept: Yup.string().required("Concept is required").min(3, "Minimum 3 characters required").matches(Regex("AlphanumWithAllSpecialCharAtStart"), "Concept name is invalid").max(300, "Maximum 300 characters reached").nullable()
      .test("", "", (e) => {
        if (errors?.txtConcept?.message == "Concept name already exists") {
          clearErrors(["txtConcept"])
        }


        return true;

      })
    ,
    random: Yup.string().test("", "Definition is Required", (e, { createError }) => {
      if ((e == "Empty" || e == undefined)) {
        return false;
      }
      if (/^\s+|\s+$/g.test(getContents(Message).replaceAll(/(<([^>]+)>)/gi, ""))) {
        return createError({ message: "Definition is Invalid" })

      }
      if (getContents(Message)?.replaceAll(/(<([^>]+)>)/gi, "").length > 3000) {
        return createError({ message: "Maximum characters exceeded" })
      }
      if (getContents(Message)?.replaceAll(/(<([^>]+)>)/gi, "").length < 10) {
        return createError({ message: "Minimum 10 characters are required" })
      }

      return true;
    }),

    ReactTags: Yup.string().notRequired().test("eror", "", (e, { createError }) => {
      let msg = keywordsValidation()
      if (msg != "") {
        return createError({ message: msg });
      }
      return true;
    })
      .nullable(),

    fileError: Yup.object().notRequired().test("file_error", "", (e, { createError }) => {
      let msg = fileValidation(e)
      if (msg != "" && msg != watch("dynamicError")) {
        setValue("dynamicError", msg, { shouldValidate: true });
        return createError({ message: msg });

      }
      else if (msg == "") {
        setValue("dynamicError", "")
      }
      return true;
    })

  })


  const fileValidation = () => {
    let message = ""

    fileValues.map((size, index) => {
      totalSize += size.FileSize
      if (totalSize * 0.000001 > 50) {
        const val = fileValues.map(obj => {
          if (obj.id === size.id) {
            return { ...obj, FileName: "Select File" };
          }
          return obj;
        });
        setFileValues(val)

        message = "File size should be below 50MB";
      }
      else if (fileValues.length == 99) {
        setValue("add", false)

      }


    })
    return message;
  }

  const keywordsValidation = useCallback(() => {
    let message = ""
    if (tags?.length > 148) {
      message = "Word limit reached"
    }

    return message;
  }, [tags])
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setError, setValue, watch, reset, formState, clearErrors } = useForm(formOptions);
  const { errors } = formState;
  const PageRoutes = useMemo(() => {
    return [{ path: "/GlossaryManagement/GlossaryList", breadcrumb: "Glossary Management" }, { path: "", breadcrumb: router.query["ConceptID"] != undefined ? "Edit Concept" : "Add a new Entry" }]
  }, [router.query])
  let count = Object.keys(errors);
  let focus = false;
  if (count.length == 1 && count[0] == "ReactTags") {
    focus = true;
  }
  const resetValues = useCallback(() => {
    setValue("txtConcept", "")
  }, [setValue]);
  const submitHandler = async (data) => {
    document?.activeElement?.blur();
    const existingConceptName = await AppsyncDBconnection(listXlmsGlossaryManagementInfo,
      {
        PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "GLOSSARY#CONCEPT#PATTERN#", IsDeleted: false,
        GlossaryType: "NameExists", ConceptNamelowerCase: data.txtConcept.toLowerCase()
      }, props?.user?.signInUserSession?.accessToken?.jwtToken)

    if (router.query["ConceptID"] == undefined && existingConceptName?.res?.listXlmsGlossaryManagementInfo?.items.length != 0) {
      setError("txtConcept", { message: "Concept name already exists" })
      setValue("submit", false)
      resetValues()
      return false
    } else if (data.txtConcept != glossaryEditData?.EditData?.ConceptName && router.query["ConceptID"] != undefined && existingConceptName?.res?.listXlmsGlossaryManagementInfo?.items.length != 0) {
      setError("txtConcept", { message: "Concept name already exists" })
      setValue("submit", false)
      resetValues()
      return false

    }



    setValue("submit", true)
    const PK = "TENANT#" + props?.TenantInfo.TenantID;
    const conceptId = Math.random().toString(25).substring(2, 12);
    const pattern = (/[^A-Za-z0-9]/.test(data.txtConcept.charAt(0)) ? "Special" : data.txtConcept.charAt(0).toUpperCase())
    const skPattern = data.txtConcept.charAt(0).toUpperCase()
    const SK = (router.query["ConceptID"] != undefined ? glossaryEditData?.EditData.SK : "GLOSSARY#CONCEPT#PATTERN#" + skPattern + "#" + conceptId);
    const query = router.query["ConceptID"] != undefined ? updateXlmsGlossaryManagement : createXlmsGlossaryManagement
    let fileArray = [], multiFiles

    for (let i = 0; i < fileValues.length; i++) {
      if (fileValues[i]?.PathChanged == false && fileValues[i].FileSize != 0 || fileValues[i]?.PathChanged == undefined) {
        let fetchURL = process.env.TRAINING_UNSAVED_TO_SAVED + `?TenantId=${props?.TenantInfo.TenantID}&FileName=${fileValues[i].FileName}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&Page=Glossary&Id=${conceptId}&S3BucketName=${props?.TenantInfo.BucketName}&S3KeyName=${props?.TenantInfo.RootFolder}/${props?.TenantInfo.TenantID}`
        let groupMenuName = "GlossaryManagement"
        let menuId = "110303"
        let presignedHeader = {
          method: "GET", headers: {
            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
            defaultrole: props?.TenantInfo.UserGroup,
            groupmenuname: groupMenuName,
            menuid: menuId
          }
        }
        if (fileValues[i].FileName != "Select File") {
          let finalResult = await APIGatewayGetRequest(fetchURL, presignedHeader)
          if (finalResult?.res == undefined) {
            return
          }
          multiFiles = await finalResult?.res?.text();
          fileArray.push({
            FileName: fileValues[i].FileName, id: fileValues[i].id, FileSize: fileValues[i].FileSize, FilePath: multiFiles, glossaryID: conceptId, PathChanged: true
          })
        } else {

          setValue("dynamicError", "Delete the extra file")
          return
        }
      } else {
        fileArray.push({
          FileName: fileValues[i].FileName, id: fileValues[i].id, FileSize: fileValues[i].FileSize, FilePath: fileValues[i].FilePath, glossaryID: conceptId, PathChanged: true
        })
      }
    }
    for (let j = 1; j < fileArray.length; j++) {
      if (fileArray[j].FileSize == 0) {
        fileArray.splice(j, 1)
      }
    }

    const variables = {
      input: {
        PK: PK,
        SK: SK,
        ConceptName: data.txtConcept,
        ConceptNamelowerCase: data.txtConcept.toLowerCase(),
        ConceptID: router.query["ConceptID"] != undefined ? glossaryEditData?.EditData.ConceptID : conceptId,
        Definition: getContents(Message),
        Pattern: router.query["ConceptID"] != undefined ? skPattern : pattern,
        AttachFile: JSON.stringify(fileArray),
        Keywords: JSON.stringify(tags),
        IsDeleted: false,
        TenantID: props?.TenantInfo.TenantID,
        CreatedDate: new Date(),
        CreatedBy: props.user?.username,
        LastModifiedDate: new Date(),
        LastModifiedBy: props?.user?.username,
      },
    };
    const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
    finalResponse(finalStatus)


  }
  const finalResponse = useCallback((finalStatus) => {
    if (finalStatus != "Success") {
      setValue("submit", false)
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: finalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", true);
      setModalValues({
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
          router.push("/GlossaryManagement/GlossaryList")
        },
      });
      ModalOpen();
    }
  }, [router, setValue]);
  return (
    <>
      <Container loader={router.query["ConceptID"] != undefined && glossaryEditData?.EditData == null ? true : false} PageRoutes={PageRoutes}
        title={`${router.query["ConceptID"] == undefined ? "Add" : "Edit"} Concept`}>
        <NVLAlert MessageTop={modalValues.MessageTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />

        <form onSubmit={handleSubmit(submitHandler)} id="divUpload">
          <div className={`${watch("load") || watch("submit") ? "pointer-events-none" : ""} nvl-FormContent`}>
            <NVLTextbox id="txtConcept" labelText="Concept" labelClassName="nvl-Def-Label pb-1" title="Concept" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />

            <NVLlabel text="Definition" className="nvl-Def-Label">
              <span className="text-red-500 text-lg">*</span>
            </NVLlabel>
            <NVLRichTextBox id="txtDefinition" className={"isResizable nvl-mandatory"} setState={setMessage} ></NVLRichTextBox>
            <div id="divrandom" className="{invalid-feedback} text-red-500 text-sm pt-2">
              {errors?.random?.message}
            </div>
            <div className="py-2 gap-4">
              <div className="flex">
                <NVLlabel text="Attach File" className="nvl-Def-Label " />
                <NVLlabel
                  className="nvl-Def-Label"
                  HelpInfo={`${"Acceptable file format:docx, doc, ppt, pptx, pdf, csv, jpg, jpeg, png, xls, xlsx, txt. Acceptable File Size:All the files uploaded should be a total of 50MB. Acceptable File count:Only 99 files can be added"}`}
                  HelpInfoIcon={"fa fa-solid fa-circle-question"}
                />
              </div>
              <NVLMultipleFileUpload TenantInfo={props.TenantInfo} finalFileValidtion={fileValidation} fileError="fileError" id="getFile" FileValues={fileValues} setFileValues={setFileValues} setValue={setValue} LoaderId="loader" watch={watch} errors={errors} register={register} FileError={watch("dynamicError")} />

            </div>

            <div>
              {errors?.file?.message}
            </div>
            <NVLlabel text="Keywords" className="nvl-Def-Label" />

            <ReactTags className="nvl-Def-Input" id="rcttags" autofocus={focus} inline allowUnique tags={tags} placeholder="Type and Press Enter to add new keywords" delimiters={delimiters} handleDelete={handleDelete} handleAddition={handleAddition} handleDrag={handleDrag} inputFieldPosition="top" />
            <div className="{invalid-feedback} text-red-500 text-xs pt-2">
              {errors?.ReactTags?.message}
            </div>
            <div className="flex justify-center gap-2 pt-4">

              <NVLButton id="btnSave" disabled={watch("load")} type="submit" className={"w-32 nvl-button bg-primary text-white relative"} text={!watch("submit") ? "Save" : ""}> {watch("submit") ? <i className="fa fa-circle-notch fa-spin mr-2"></i> : ""}</NVLButton>
              <NVLButton id="btnCancel" type="button" className="nvl-button w-28" text="Cancel" onClick={() => router.push("/GlossaryManagement/GlossaryList")}></NVLButton>
            </div>
          </div>
        </form>

      </Container>

    </>

  )
}
export default AddNewEntry;
