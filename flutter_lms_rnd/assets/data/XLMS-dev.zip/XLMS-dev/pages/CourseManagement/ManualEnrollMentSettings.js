import { GetDateFormat } from "@components/Common/DateFormat";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXlmsCourseManagementInfo } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo } from "src/graphql/queries";
import * as Yup from "yup";

function ManualEnrollMentSettings(props) {
    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const initialModalState = {};

    useEffect(() => {
        const dataSource = async () => {
            const tenantId = props.user.attributes["custom:tenantid"];
            const courseId = decodeURIComponent(String(router.query["CourseID"]));
            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, {
                PK: "TENANT#" + tenantId,
                SK: "COURSEINFO#" + courseId,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            setCsrFetchedData({
                TenantId: tenantId,
                CourseID: courseId != undefined ? courseId : [],
                CourseData: courseData.res?.getXlmsCourseManagementInfo,
            });
            const initialModalState = {
                ModalInfo: "Success",
                ModalTopMessage: "Success",
                ModalBottomMessage: "Details have been saved successfully.",
                ModalOnClickEvent: () => {
                    router.push(`/CourseManagement/EnrollmentSettingsList?CourseID=${courseId}`);
                },
            };
            setModalValues(initialModalState);

        };

        dataSource();
        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
        });

    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router, router.query]);
    const [modalValues, setModalValues] = useState(initialModalState);

    const validationSchema = Yup.object().shape({
        txtstdate: Yup.date()
            .when("chkStartDateEnable", {
                is: true,
                then: Yup.date("Enroll startdate is required")
                    .required(" Enroll startdate is required")
                    .typeError("Enroll can be created only for present and future date")
                    .min(new Date(new Date().setDate(new Date().getDate() - 1)), "Enroll can be created only for present and future date")
                    .test("check", "Enroll startdate Should between the course date", (e) => {
                        const dateTime = new Date(e);
                        const enrolldate = GetDateFormat(dateTime, "yyyy-mm-dd");
                        const courseStartdate = GetDateFormat(csrFetchedData?.CourseData?.DateTime, "yyyy-mm-dd");
                        const courseEnddate = GetDateFormat(csrFetchedData?.CourseData?.EndDateTime, "yyyy-mm-dd");
                        if (enrolldate < courseStartdate || enrolldate > courseEnddate) {

                            return false;
                        }
                        return true;


                    }),
                otherwise: Yup.date().min(new Date(new Date().setDate(new Date().getDate() - 1)), "Enroll can be created only for present and future date").typeError("Enroll can be created only for present and future date").test("check", "Enroll startdate should between the course date", (e) => {
                    const dateTime = new Date(e);
                    const enrolldate = GetDateFormat(dateTime, "yyyy-mm-dd");
                    const courseStartdate = GetDateFormat(csrFetchedData?.CourseData?.DateTime, "yyyy-mm-dd");
                    const courseEnddate = GetDateFormat(csrFetchedData?.CourseData?.EndDateTime, "yyyy-mm-dd");

                    if (e != undefined) {
                        if (!csrFetchedData?.CourseData?.DateTime == "" && !csrFetchedData?.CourseData?.EndDateTime == "") {

                            if (enrolldate < courseStartdate || enrolldate > courseEnddate) {

                                return false;
                            }
                        }
                    }
                    return true;


                }),
            }),

        txtEnddate: Yup.date()
            .when("chkEndDateEnable", {
                is: true,
                then: Yup.date().min(Yup.ref("txtstdate"), "Enroll enddate must be greater than or equal to the  enroll startdate").required("Enroll enddate is required").typeError("Enroll enddate is required").test("check", "Enroll enddate should between the course date", (e) => {

                    const dateTime = new Date(e);

                    const enrollDate = GetDateFormat(dateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    const courseEndDate = GetDateFormat(csrFetchedData?.CourseData?.EndDateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    if (watch("chkStartDateEnable") == false) {
                        setValue("txtEnddate", "");

                    }
                    if (e != undefined) {
                        if (!csrFetchedData?.CourseData?.EndDateTime == "") {

                            if (enrollDate > courseEndDate) {

                                return false;
                            }
                        }
                    }

                    return true;
                }),
                otherwise: Yup.date().min(Yup.ref("txtstdate"), " Enroll enddate must be greater than or equal to the start date").typeError("Enroll can be created only for present and future date").test("check", "Enroll enddate Should create between the course date or future date", (e) => {
                    const dateTime = new Date(e);
                    const enrollDate = GetDateFormat(dateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    const courseEndDate = GetDateFormat(csrFetchedData?.CourseData?.EndDateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    if (e != undefined) {
                        if (!csrFetchedData?.CourseData?.EndDateTime == "") {

                            if (enrollDate > courseEndDate) {

                                return false;
                            }
                        }
                    }
                    return true;
                }),

            })

    });

    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };
    const { register, handleSubmit, setValue, watch, formState } =
    useForm(formOptions);


    useEffect(() => {

        setValue("ddlUserRole", csrFetchedData?.CourseData?.Defaultroll);
        setValue("rbEnrollExpiry", (csrFetchedData?.CourseData?.IsNotifyBeforeEnroll == null || csrFetchedData?.CourseData?.IsNotifyBeforeEnroll == undefined ? "false" : csrFetchedData?.CourseData?.IsNotifyBeforeEnroll?.toString()));
        setValue("txtstdate", dateCoversion(csrFetchedData?.CourseData?.EnrollStartDate) == "1970-01-1" ? undefined
            : dateCoversion(csrFetchedData?.CourseData?.EnrollStartDate));
        setValue("txtEnddate", dateCoversion(csrFetchedData?.CourseData?.EnrollEndDate) == "1970-01-1" ? undefined
            : dateCoversion(csrFetchedData?.CourseData?.EnrollEndDate));
        setValue("chkStartDateEnable", csrFetchedData?.CourseData?.EnrollStartDate == undefined || csrFetchedData?.CourseData?.EnrollStartDate == "" ? false : csrFetchedData?.CourseData?.EnrollStartDate);
        setValue("chkEndDateEnable", csrFetchedData?.CourseData?.EnrollEndDate == undefined || csrFetchedData?.CourseData?.EnrollEndDate == "" ? false : csrFetchedData?.CourseData?.EnrollEndDate);

    }, [csrFetchedData?.CourseData?.Defaultroll, csrFetchedData?.CourseData?.EnrollEndDate, csrFetchedData?.CourseData?.EnrollStartDate, csrFetchedData?.CourseData?.IsNotifyBeforeEnroll, setValue]);


    const finalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
                ModalOnClickEvent: () => {
                    router.push(`/CourseManagement/EnrollmentSettingsList?CourseID=${csrFetchedData?.CourseID}`);
                },
            });
            ModalOpen();
            return;
        } else {
            ModalOpen();
        }
    }, [csrFetchedData?.CourseID, router]);

    const role = [
        { value: "", text: "Select Role" },
        { value: "Trainer", text: "Trainer" },
        { value: "User", text: "User" },

    ];
    const dateCoversion = (date) => {
        const dateTime = new Date(date);
        const dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + (dateTime.getDate() < 10 ? "0" + dateTime.getDate() : dateTime.getDate());

        const splitDate =
      dateTimeString;
        return splitDate;
    };

    const { errors } = formState;
    const DateTime = useCallback(({ errors, register, setValue, watch }) => {
        const today = new Date();
        const dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate());

        if (!watch("chkStartDateEnable")) {
            if (watch("chkStartDateEnable"))
                setValue("chkStartDateEnable", false, { shouldValidate: true });
            if (!(watch("txtstdate") == undefined))
                setValue("txtstdate", undefined, { shouldValidate: true });

            if (watch("chkEndDateEnable"))
                setValue("chkEndDateEnable", false, { shouldValidate: true });

            if (!(watch("txtEnddate") == undefined))
                setValue("txtEnddate", undefined, { shouldValidate: true });
        }
        else if (!watch("chkEndDateEnable")) {
            if (!(watch("txtEnddate") == undefined)) {
                setValue("txtEnddate", undefined, { shouldValidate: true });
            }
        }
        return (
            <div className="grid">

                <div className="flex">
                    <div className="pb-4 pt-2">
                        <NVLlabel text=" Enrollment Start Date" className="nvl-Def-Label pb-1"></NVLlabel>
                        <NVLTextbox id="txtstdate" title="Start Date" type="date" tabIndex={!watch("chkStartDateEnable") ? "1" : "0"} className={!watch("chkStartDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkStartDateEnable")} setValue={setValue} errors={errors} register={register}></NVLTextbox>

                    </div>

                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkStartDateEnable" errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>

                <div className="flex">
                    <div className="">
                        <NVLlabel text=" Enrollment End Date" className="nvl-Def-Label pb-1"></NVLlabel>
                        <NVLTextbox title="End Date" id="txtEnddate" type="date" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"} className={!watch("chkEndDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkEndDateEnable")} errors={errors} register={register} setValue={setValue}></NVLTextbox>
                    </div>
                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkEndDateEnable" disabled={!watch("chkStartDateEnable")} errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>

            </div>
        );
    }, []);
    const submitHandler = async (data) => {
        setValue("submit", true);

        const PK = "TENANT#" + csrFetchedData?.TenantId;
        const SK = "COURSEINFO#" + csrFetchedData?.CourseID;
        const query = updateXlmsCourseManagementInfo;
        const enrollStartDate = GetDateFormat(data.txtstdate, "±YYYYYY-MM-DDTHH:mm:ss");
        const enrollEndDate = GetDateFormat(data.txtEnddate, "±YYYYYY-MM-DDTHH:mm:ss");

        const variables = {
            input: {
                PK: PK,
                SK: SK,
                CourseID: csrFetchedData?.CourseID,
                Defaultroll: data.ddlUserRole,
                CreatedDate: props.mode == "Create" ? new Date() : csrFetchedData?.CourseData?.CreatedDate,
                IsNotifyBeforeEnroll: data.rbEnrollExpiry,
                EnrollStartDate: watch("chkStartDateEnable") != false ? enrollStartDate : "",
                EnrollEndDate: watch("chkEndDateEnable") != false ? enrollEndDate : "",
                LastModifiedDate: new Date()

            }
        };
        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        finalResponse(finalStatus);
        setValue("submit", false);
    };

    const pageRoutes = useMemo(() => {
        return [
            { path: props.mode == "Create" || props.mode == "Edit" ? "/ActivityManagement/ActivityList" : `/CourseManagement/CourseList`, breadcrumb: props.mode == "Create" || props.mode == "Edit" ? "Activity Management" : "Course Management" },
            { path: `/CourseManagement/EnrollmentSettingsList?CourseID=${csrFetchedData?.CourseID}`, breadcrumb: "Enrollment Setting" },
            { path: "", breadcrumb: "ManualEnroll Settings" }
        ];
    }, [csrFetchedData?.CourseID, props.mode]);
    return (

        <>
            <Container>

                <NVLBreadCrumbs Routes={pageRoutes} loader={csrFetchedData?.CourseData?.CourseName == undefined}></NVLBreadCrumbs>
                <form onSubmit={handleSubmit(submitHandler)}>

                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues?.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className="nvl-FormContent">
                        <NVLlabel className="nvl-Def-Label" text={`Course Name : ${csrFetchedData?.CourseData?.CourseName}`} />
                        <NVLlabel showFull={true} className="nvl-Def-Label pt-1 pb-1" text={`Course Interface : Manual Enrollment`} />
                        <NVLSelectField labelClassName="nvl-Def-Label" labelText="Select Role" options={role} id="ddlUserRole" className={"nvl-non-mandatory nvl-Def-Input"} register={register} errors={errors}></NVLSelectField>
                        <NVLlabel showFull={true} className="nvl-Def-Label" text={` Course ValidDate From : ${csrFetchedData?.CourseData?.DateTime == undefined ? "-" : GetDateFormat(csrFetchedData?.CourseData?.DateTime, "day mm dd yyy").slice(3)}  TO  ${csrFetchedData?.CourseData?.EndDateTime == "" ? "-" : GetDateFormat(csrFetchedData?.CourseData?.EndDateTime, "day mm dd yyy").slice(3)}`} />
                        <DateTime errors={errors} register={register} watch={watch} setValue={setValue} />
                        <div className="flex justify-center gap-1 pt-2">
                            <NVLButton
                                id="btnSave"
                                text={!watch("submit") ? "Submit" : ""}
                                type={"submit"}
                                disabled={watch("submit") == "submit" ? true : false}
                                className={`w-32 nvl-button bg-primary text-white `}>
                                {watch("submit") && (
                                    <i className="fa fa-circle-notch fa-spin mr-2"></i>
                                )}
                            </NVLButton>
                            <NVLButton id="btnCancel" type="button" text="Cancel" onClick={() => router.push(`/CourseManagement/EnrollmentSettingsList?CourseID=${csrFetchedData?.CourseID}`)} className={`nvl-button w-28`}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
} export default ManualEnrollMentSettings;
