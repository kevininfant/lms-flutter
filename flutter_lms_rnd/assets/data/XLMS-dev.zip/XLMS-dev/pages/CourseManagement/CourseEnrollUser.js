import { GetDateFormat } from "@components/Common/DateFormat";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLMultiSelect from "@components/Controls/NVLMultiSelect";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLToolTip from "@components/Controls/NVLToolTip";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsCourseBatch, getXlmsCourseManagementInfo, listXlmsActiveCourseBatch, listXlmsCourseEnrollUserListView, listXlmsUserGroupListInfos, listXlmsUserListInfos } from "src/graphql/queries";
import * as Yup from "yup";

function EnrollUser(props) {

    const router = useRouter();
    const [currentDiv, setCurrentDiv] = useState("User");
    const [fileValues, setFileValues] = useState({ TextName: "Select File", FilePath: "", });
    const [multiselected, setMultiSelected] = useState([]);
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const CurrentBatch = useRef();
    const mode = useMemo(() => { return router.query["Mode"]; }, [router.query]);
    const courseName = useMemo(() => { return router.query["CourseName"]; }, [router.query]);
    const courseId = useMemo(() => { return router.query["CourseID"]; }, [router.query]);
    useEffect(() => {
        async function dataSource() {
            let userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "#USERINFO#", IsSuspend: false }, props.user?.signInUserSession?.accessToken?.jwtToken), tempUser = [];
            let userDetails = userData?.res?.listXlmsUserListInfos?.items ? userData?.res?.listXlmsUserListInfos?.items : []
            tempUser = [...tempUser, ...userDetails];
            while (userData?.res?.listXlmsUserListInfos?.nextToken != null) {
                userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "#USERINFO#", IsSuspend: false, nextToken: userData.res?.listXlmsUserListInfos.nextToken }, props.user?.signInUserSession?.accessToken?.jwtToken);
                if (userDetails?.length > 0) {
                    tempUser = [...tempUser, ...userDetails];
                }
            }
            let batchData = await AppsyncDBconnection(listXlmsActiveCourseBatch, { PK: "TENANT#" + props.TenantInfo?.TenantID + "#COURSEINFO#" + courseId, SK: "COURSEBATCH#", CurrentDate: new Date().toISOString().slice(0, 10), IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const groupData = await AppsyncDBconnection(listXlmsUserGroupListInfos, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "GROUPINFO#", IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const courseDataResponse = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#" + router.query["CourseID"] }, props.user.signInUserSession.accessToken.jwtToken);
            let variable = { GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + courseId, GsiSK: `BATCH#`, Department: "", Designation: "", IsSuspend: false }
            let EnrollData = await AppsyncDBconnection(listXlmsCourseEnrollUserListView, variable, props?.user?.signInUserSession?.accessToken?.jwtToken);
            let temp = EnrollData?.res?.listXlmsCourseEnrollUserListView?.items, tempuserSub = [];
            while (EnrollData && EnrollData?.res?.listXlmsCourseEnrollUserListView?.nextToken != null) {
                variable = { ...variable, nextToken: EnrollData?.res?.listXlmsCourseEnrollUserListView.nextToken }
                EnrollData = await AppsyncDBconnection(listXlmsCourseEnrollUserListView, variable, props?.user?.signInUserSession?.accessToken?.jwtToken);
                temp = [...temp, ...EnrollData?.res?.listXlmsCourseEnrollUserListView?.items]
            }
            if (temp?.length > 0) {
                temp.map((data) => { tempuserSub = [...tempuserSub, data?.UserSub] });
            }
            EnrollData = temp;
            temp = tempUser;
            if (tempUser?.length > 0) {
                tempUser = tempUser.filter((data) => { return !tempuserSub?.includes(data?.UserSub); })
            }
            setCsrFetchedData({ CourseData: courseDataResponse?.res?.getXlmsCourseManagementInfo, userData: temp, GroupData: groupData.res?.listXlmsUserGroupListInfos?.items, BatchData: batchData.res?.listXlmsActiveCourseBatch?.items, EnrollData: EnrollData, EnrollList: tempUser });
        }
        dataSource();
        return (() => {
            setCsrFetchedData((data) => { return data });
        });

    }, [props?.user?.signInUserSession?.accessToken?.jwtToken, courseId, props.TenantInfo.TenantID, router.query]);
    const initialModalState = useMemo(() => {
        return {
            ModalInfo: "Success",
            ModalTopMessage: "Success",
            ModalBottomMessage: "Details have been saved successfully.",
            ModalOnClickEvent: () => {
                if (mode == "CourseList") {
                    router.push("/CourseManagement/CourseList");
                }
                else if (mode == "EnrollmentList") {
                    router.push(`/CourseManagement/CourseDismissUser?CourseID=${courseId}&CourseName=${courseName}`);
                }
                else {
                    router.push(`/CourseManagement/EnrollmentSettingsList?CourseID=${encodeURIComponent(courseId)}`);
                }
            },
        };
    }, [courseId, courseName, mode, router]);
    const [modalValues, setModalValues] = useState(initialModalState);

    const validationSchema = Yup.object().shape({

        rbUser: Yup.string().test("NOValid", "novalid", (e) => {
            if (e == "User" && e != currentDiv) {
                setCurrentDiv("User");
                userHandler();
            } else if (e == "Group" && e != currentDiv) {
                setCurrentDiv("Group");
                groupHandler();
            } else if (e == "BulkUpload" && e != currentDiv) {
                setCurrentDiv("BulkUpload");
                bulkUploadHandler();
            }
            return true;
        }),

        ddlUser: Yup.string().test("MultiSlect_EmptyHandler", "", (e, { createError }) => {
            if ((e == "Empty" || e == undefined) && multiselected == null) {
                return createError({ message: `${watch("rbUser") == "User" ? "Users required" : watch("rbUser") == "Group" ? "Group is required" : ""}`, });
            }
            if (e == "NoData") {
                return createError({
                    message: `${watch("rbUser") == "User"
                        ? "There is no User found"
                        : "There is no group found"
                        }`,
                });
            }
            return true;
        }),

        ddlBatch: Yup.string().required("Select a Batch Name").nullable().test("novalid", "chnage", async (e) => {
            if (e != CurrentBatch.current) {
                setMultiSelected([]);
                CurrentBatch.current = e;
                setCsrFetchedData((csrFetchedData) => {
                    let temp = csrFetchedData?.EnrollData, tempuserSub = [], tempUser = csrFetchedData?.userData;
                    if (temp.length > 0) {
                        temp = temp.filter((data) => { return data.SK.includes(e); });
                        temp.map((data) => { tempuserSub = [...tempuserSub, data?.UserSub] });
                    }
                    if (tempUser?.length > 0) {
                        tempUser = tempUser.filter((data) => { return !tempuserSub?.includes(data?.UserSub); })
                    }
                    return { ...csrFetchedData, EnrollList: tempUser }
                })
            }
            return true;
        }),

        File: Yup.string().when("rbUser", {
            is: "BulkUpload",
            then: Yup.string().test("file_Error", "", (e, { createError }) => {
                if (e == undefined || e == "false") {
                    return createError({ message: "File is required" });
                }
                if (e == "fileType") {
                    return createError({ message: "Invalid file type" });
                }
                if (e == "Empty" || e == undefined) {
                    return createError({ message: "Empty File... Please Fill Values" });
                }
                if (e == "FileSize") {
                    return createError({ message: "File size should be 5MB" });
                }
                if (e == "HeaderMismatch" || e == undefined) {
                    return createError({
                        message: "Header Mismatch Please Choose Correct Format.",
                    });
                }
                if (e == "Error") {
                    return createError({ message: "Server Error Please Try Again" });
                }
                return true;
            }),
        }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;
    const MultiSelectList = useMemo(() => {
        const MultiSelectUserOrGroup = currentDiv == "User" ? csrFetchedData?.EnrollList : csrFetchedData?.GroupData, MultiSelectList = [];
        if (MultiSelectUserOrGroup && MultiSelectUserOrGroup.length > 0) {
            if (currentDiv == "User") {
                const UsersList = MultiSelectUserOrGroup;
                UsersList && UsersList.map((getItem) => {
                    if (getItem.EmailID != null) {
                        MultiSelectList.push({ value: getItem.UserSub, label: getItem.EmailID, Name: getItem.UserName, Depart: getItem.Department, Design: getItem.Designation, FName: getItem.FirstName, LName: getItem.LastName });
                    }
                });
            } else {
                MultiSelectUserOrGroup.map((getItem) => {
                    MultiSelectList.push({ value: getItem.SK, label: getItem.GroupName });
                });
            }
        }
        return MultiSelectList;
    }, [csrFetchedData?.EnrollList, csrFetchedData?.GroupData, currentDiv])

    useEffect(() => {
        setValue("rbUser", "User");
    }, [setValue]);

    const userTemplate = useMemo(() => {
        return [
            { HeaderName: "UserSub", Action: "true" },
            { HeaderName: "UserName", Action: "true" },
            { HeaderName: "EmailID", Action: "true" },
            { HeaderName: "Department", Action: "true" },
            { HeaderName: "Designation", Action: "true" },
            { HeaderName: "FirstName", Action: "true" },
            { HeaderName: "LastName", Action: "true" },
        ];
    }, []);

    const batchName = [{ value: "", text: "Select" }];
    if (csrFetchedData?.BatchData != undefined) {
        csrFetchedData?.BatchData?.map((batch) => {
            if (batch.EndDate == null || new Date(batch.EndDate) >= new Date())
                batchName.push({ value: batch.BatchID, text: batch.BatchName });
        });
    }

    const downloadCsvfile = useCallback(async (e) => {
        if (e.type == "click") {
            const userListJson = csrFetchedData?.EnrollList;
            const rows = [];
            userTemplate.forEach((element) => {
                element.Action === "true" ? rows.push(element.HeaderName) : "";
            });
            let csvContent = "data:text/csv;charset=utf-8,";
            csvContent += rows + "\r\n";
            userListJson?.forEach((element) => {
                if (element.UserSub != null) {
                    csvContent += element.UserSub + "," + element.UserName + "," + element.EmailID + "," + element.Department + "," + element.Designation + "," + element.FirstName + "," + element.LastName;
                    csvContent += "\n";
                }
            });
            let encodedUri = encodeURI(csvContent);
            let link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `${courseName}-Enroll.csv`);
            link.click();
            link.remove();
        }
    }, [courseName, csrFetchedData?.EnrollList, userTemplate]);

    async function fileValidation(e) {
        const file = e?.target?.files?.[0];
        if (file == undefined || watch("ddlBatch") == "" || watch("ddlBatch") == undefined) {
            e.stopPropagation();
            e.preventDefault();
            e.target.value = null;
            if (watch("ddlBatch") == "")
                setValue("ddlBatch", "", { shouldValidate: true });
            return;
        }
        setValue("File", "Uploading");
        const fileInput = document.getElementById("getFile");
        const filePath = fileInput.value;
        const allowedExtensions = /(\.csv)$/i;

        if (!allowedExtensions.exec(filePath)) {
            fileInput.value = "";
            setFileValues({ ...fileValues, TextName: "Select File", FilePath: "" });
            setValue("File", "fileType", { shouldValidate: true });
            return false;
        } else if (file.size > process.env.ACTIVITY_ENROLLUSER_FILE_SIZE) {
            setValue("File", "FileSize", { shouldValidate: true });
        } else {
            await uploadFile(e);
        }
    }

    async function uploadFile(e) {
        const file = e.target.files[0];
        const csvReader = new FileReader();
        csvReader.onload = async function (e) {
            const text = e.target.result;
            const lines = text.split("\n");
            const values = lines[0].split(",");
            let isCSVDatacheck = false;
            for (let i = 0; i < userTemplate.length; i++) {
                if (
                    values[i].trim() != userTemplate[i].HeaderName.trim() ||
                    values.length != userTemplate.length
                ) {
                    setValue("File", "HeaderMismatch", { shouldValidate: true });
                    isCSVDatacheck = true;
                    return;
                }
            }
            if (!isCSVDatacheck) {
                const data = lines[1].split(",");
                if (data.length != userTemplate.length) {
                    setValue("File", "Empty", { shouldValidate: true });
                    isCSVDatacheck = true;
                    return;
                }
            }
            if (!isCSVDatacheck) {
                const fetchURL =
                    process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
                    `?FileName=${file.name}&TenantID=${props?.TenantInfo?.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ManagementType=CourseManagement&Type=BulkUserUpload&CourseType=BulkUpload`;
                const headers = {
                    method: "GET",
                    headers: {
                        authorizationToken: await Auth.currentSession().then((s) =>
                            s.getAccessToken().getJwtToken()
                        ),
                        defaultrole: props.TenantInfo.UserGroup,
                        groupmenuname: "CourseManagement",
                        menuid: "300406",
                    },
                };
                const extension = file.name.substring(file.name.lastIndexOf(".") + 1).toLowerCase();
                const contentType = extension == "csv" ? "text/" + extension : ImageExtension.indexOf(extension) >= 0 ? "image/" + extension : VideoExtension.indexOf(extension) >= 0 ? "video/" + extension : "application/" + extension;
                const presignedHeader = { method: "PUT", headers: { "content-type": contentType, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "CourseManagement", menuid: "300406", }, body: file, };
                const finalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);
                if (finalStatus[0] != "Success") {
                    setFileValues({ ...fileValues, TextName: "Select File", FilePath: "", });
                    setValue("File", "Error", { shouldValidate: true });
                    return;
                } else {
                    setValue("File", "exist", { shouldValidate: true });
                    setFileValues({ ...fileValues, TextName: file.name, FilePath: finalStatus[1], });
                }
            }
        };
        csvReader.readAsText(file);
    }

    const userHandler = async () => {
        setMultiSelected([]);
        setFileValues({ TextName: "Select File", FilePath: "" });
        setValue("ddlUser", "", { shouldValidate: true });
        setValue("File", "", { shouldValidate: true });
    };

    const groupHandler = async () => {
        setMultiSelected([]);
        setFileValues({ TextName: "Select File", FilePath: "" });
        setValue("ddlUser", "", { shouldValidate: true });
        setValue("File", "", { shouldValidate: true });
    };

    const bulkUploadHandler = async () => {
        setMultiSelected([]);
    };

    const finalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: FinalStatus, });
            ModalOpen();
            return;
        } else {
            setModalValues(initialModalState);
            ModalOpen();
        }
    }, [initialModalState]);
    const [popupValues, setPopupValues] = useState({});
    const resetPopUp = useCallback(() => {
        setPopupValues({ Content: "" });
    }, []);

    const popUp = useCallback((Content) => {
        setPopupValues({ Content: Content });

    }, []);
    const submitHandler = async () => {
        const batchDataRes = await AppsyncDBconnection(getXlmsCourseBatch,
            {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + csrFetchedData.CourseData.CourseID,
                SK: "COURSEBATCH#" + watch("ddlBatch")
            },
            props?.user?.signInUserSession?.accessToken?.jwtToken);
        const batchData = batchDataRes?.res?.getXlmsCourseBatch;
        const courseStartDate = GetDateFormat(csrFetchedData?.CourseData?.DateTime, "yyyy-mm-dd");
        const courseEndDate = (csrFetchedData?.CourseData?.EndDateTime == undefined || csrFetchedData?.CourseData?.EndDateTime == "" || csrFetchedData?.CourseData?.EndDateTime == null) ? "" : GetDateFormat(csrFetchedData?.CourseData?.EndDateTime, "yyyy-mm-dd");
        const batchStartDate = GetDateFormat(batchData?.StartDate, "yyyy-mm-dd");
        const batchEndDate = (batchData?.EndDate == undefined || batchData.EndDate == "" || batchData.EndDate == null) ? "" : GetDateFormat(batchData?.EndDate, "yyyy-mm-dd");

        if (courseStartDate <= batchStartDate && (courseEndDate == undefined || courseEndDate == "" || courseEndDate >= batchEndDate)) {
            setValue("submit", true);
            const finalData = [];
            if (currentDiv == "User" && multiselected.length == 0) {
                setValue("ddlUser", "NoData", { shouldValidate: true });
                setValue("submit", false);
                return;
            } else if (currentDiv == "Group" && multiselected.length == 0) {
                setValue("ddlUser", "NoData", { shouldValidate: true });
                setValue("submit", false);
                return;
            }
            if (fileValues.FilePath == "" && currentDiv == "BulkUpload") {
                setValue("File", "false", { shouldValidate: true });
                setValue("submit", false);
                return;
            }
            if (currentDiv == "User") {
                for (let i = 0; i < multiselected.length; i++) {
                    finalData.push({ UserSub: multiselected[i].value, EmailID: multiselected[i].label, UserName: multiselected[i].Name, BatchID: watch("ddlBatch"), CourseID: courseId, Department: multiselected[i].Depart, Designation: multiselected[i].Design, FirstName: multiselected[i].FName, LastName: multiselected[i].LName });
                }
            }
            if (currentDiv != "User" && multiselected.length > 0) {
                for (let i = 0; i < multiselected.length; i++) {
                    finalData.push({ GroupID: multiselected[i].value?.split("#")[1], GroupName: multiselected[i].label, BatchID: watch("ddlBatch"), CourseID: courseId, });
                }
            }
            const fetchURL = currentDiv == "BulkUpload" ? process.env.APIGATEWAY_URL_COURSE_ENROLL_BULKUPLOAD : currentDiv == "User" ? process.env.APIGATEWAY_URL_COURSE_ENROLLUSER : process.env.APIGATEWAY_URL_COURSE_ENROLLGROUP;
            let tempvar = "";
            if (currentDiv == "User") {
                tempvar = '{ "Type":"' + currentDiv + '","TenantID":"' + props?.TenantInfo?.TenantID + '", "CourseName":"' + courseName + '","CourseID": "' + courseId + '","BatchID": "' + watch("ddlBatch") + '","UserDetails":' + JSON.stringify(finalData) + "}";
            }
            else if (currentDiv == "Group") {
                tempvar = '{ "Type":"' + currentDiv + '","TenantID":"' + props?.TenantInfo?.TenantID + '", "CourseName":"' + courseName + '","CourseID": "' + courseId + '","BatchID": "' + watch("ddlBatch") + '","GroupInfo":' + JSON.stringify(finalData) + "}";
            }
            else {
                tempvar = '{"TenantID": "' + props?.TenantInfo?.TenantID + '","ManagementType": "CourseManagement","Type": "BulkUserUpload", "FileName": "' + document.getElementById("getFile")?.files[0]?.name + '","CourseID": "' + courseId + '","BucketName":"' + props.TenantInfo.BucketName + '","RootFolder":"' + props.TenantInfo.RootFolder + '" ,"BatchID": "' + watch("ddlBatch") + '", "BatchName": "' + document.getElementById("ddlBatch").options[document.getElementById("ddlBatch").selectedIndex].text + '","CourseType":"BulkUpload"}';
            }
            const stateurl = currentDiv == "BulkUpload" ? process.env.STEP_FUNCTION_ARN_COURSE_ENROLL_BULKUPLOAD : currentDiv == "User" ? process.env.STEP_FUNCTION_ARN_COURSE_ENROLLUSER : process.env.STEP_FUNCTION_ARN_COURSE_ENROLLGROUP;
            const jsonSaveData = tempvar;
            const headers = {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    defaultrole: props.TenantInfo.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300201",
                    statemachinearn: stateurl,
                },
                body: jsonSaveData,
            };

            const finalStatus = await APIGatewayPostRequest(fetchURL, headers);
            finalResponse(finalStatus.Status);
            setValue("submit", false);
        }
        else {
            popUp("Start date and end date is mismatched, either in course or in batch.")
        }
    };
    let pageRoutes = [];
    if (mode == "CourseList") {
        pageRoutes = [
            { path: mode == "Create" || mode == "Edit" ? "/ActivityManagement/ActivityList" : `/CourseManagement/CourseList`, breadcrumb: mode == "Create" || mode == "Edit" ? "Activity Management" : "Course Management" },
            { path: "", breadcrumb: "Enroll User" }
        ];
    } else if (mode == "EnrollList") {
        pageRoutes = [
            { path: mode == "Create" || mode == "Edit" ? "/ActivityManagement/ActivityList" : `/CourseManagement/CourseList`, breadcrumb: mode == "Create" || mode == "Edit" ? "Activity Management" : "Course Management" },
            { path: mode == "EnrollList" ? `/CourseManagement/EnrollmentSettingsList?CourseID=${courseId}` : "/CourseManagement/CourseList", breadcrumb: "Enrollment Setting" },
            { path: "", breadcrumb: "Enroll User" }
        ];
    }
    else {
        pageRoutes = [
            { path: `/CourseManagement/CourseList`, breadcrumb: "Course Management" },
            { path: `/CourseManagement/CourseDismissUser?CourseID=${courseId}&CourseName=${courseName}`, breadcrumb: "Enrollment List" },
            { path: "", breadcrumb: "Enroll User" }
        ];

    }

    const overrideStrings = useMemo(() => {
        return {
            "allItemsAreSelected": currentDiv == "User" ? "All Users are Selected" : "All Groups are Selected",
            "noOptions": currentDiv == "User" ? "No Users Found" : "No Groups Found",
            "selectSomeItems": currentDiv == "User" ? "Select Users" : "Select Group",
        }
    }, [currentDiv])
    return (
        <>
            <Container loader={csrFetchedData?.userData == undefined} PageRoutes={pageRoutes}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)} id="Formjs">
                    <div className="nvl-FormContent">
                        <NVLlabel className="nvl-Def-Label break-all" showFull text={`Course Name : ${courseName}`}></NVLlabel>
                        <div className="flex">
                            <div>
                                <NVLSelectField id="ddlBatch" labelText="Batch Name" labelClassName="nvl-Def-Label" className={(csrFetchedData?.CourseData?.ActiveActivityCount == 0 || csrFetchedData?.CourseData?.ActiveActivityCount == undefined || csrFetchedData?.CourseData?.ActiveActivityCount == null) ? "Disabled nvl-mandatory nvl-Def-Input" : "nvl-mandatory nvl-Def-Input"} options={batchName} errors={errors} register={register} />
                            </div>
                            {(csrFetchedData?.CourseData?.ActiveActivityCount == 0 || csrFetchedData?.CourseData?.ActiveActivityCount == undefined || csrFetchedData?.CourseData?.ActiveActivityCount == null) ?
                                <NVLToolTip top={"hide"} PopDetail={"Their is no activity in a course. Kindly create a activity for a course"} PopIcon={"m-auto pl-3 pt-2 fa fa-solid fa-circle-question"} ></NVLToolTip> : ""}
                        </div>
                        <NVLlabel className="nvl-Def-Label pt-2" text="Enroll By"></NVLlabel>
                        <div className="flex gap-3 pt-2 flex-wrap">
                            <NVLRadio id="rbUser" type="radio" text="User" value={"User"} errors={errors} register={register} name="rbUser" />
                            <NVLRadio id="rbUser" type="radio" text="Group" value={"Group"} errors={errors} register={register} name="rbUser" />
                            <NVLRadio id="rbUser" type="radio" text="Bulk Upload" value={"BulkUpload"} errors={errors} register={register} name="rbUser" />
                        </div>
                        <section id="divUser" className={currentDiv == "BulkUpload" ? "hidden" : "pt-4"}>
                            <NVLMultiSelect overrideStrings={overrideStrings} id="ddlUser" className="w-96 nvl-mandatory" required={currentDiv == "User"} options={MultiSelectList} value={multiselected} onChange={(event) => { setMultiSelected(event); if (event?.length == undefined || event.length == 0) { setValue("ddlUser", "Empty", { shouldValidate: true }); } else { setValue("ddlUser", "", { shouldValidate: true }); } }} />
                            <div className="block {invalid-feedback} text-red-500  text-sm">
                                {errors.ddlUser?.message}
                            </div>
                        </section>
                        <section id="divBulkUpload" className={currentDiv != "BulkUpload" ? "hidden" : ""}>
                            <div className="pt-4">
                                <NVLlabel text="Upload File" className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: .csv <br>File size should not exceed 5MB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                            </div>
                            <div className="flex xl:flex-wrap items-center">
                                <div>
                                    <NVLFileUpload text={fileValues.TextName == null ? "Select File" : fileValues.TextName} accept={`${"Acceptable file format: csv<br>File size should not exceed 5MB"}`} onChange={(e) => fileValidation(e)} />
                                    <div className={"Center-Aligned-Items {invalid-feedback} text-red-500 text-sm "}>
                                        {errors?.File?.message}
                                    </div>
                                    <div className="flex my-4 justify-between">
                                        <NVLlabel text={"Download sample template"} className="nvl-Def-Label my-auto" />
                                        <NVLButton text={"Download"} type={"button"} className="bg-primary nvl-button rounded-2xl text-white" onClick={(e) => downloadCsvfile(e)} />
                                    </div>
                                    <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                                </div>
                            </div>
                        </section>
                        <div className="justify-center flex gap-4 pt-4">
                            <NVLButton text={currentDiv == "BulkUpload" && !watch("submit") ? "Upload" : currentDiv != "BulkUpload" && !watch("submit") ? "Enroll" : ""} type={"submit"} disabled={watch("File") == "Uploading" || watch("submit") ? true : false} className={`nvl-button w-28 ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`} ButtonType="success">
                                {watch("submit") && (<i className="fa fa-circle-notch fa-spin mr-2"> </i>)}
                            </NVLButton>
                        </div>
                    </div>
                    <NVLModalPopup
                        ButtonYestext="OK"
                        SubmitClick={() => resetPopUp()}
                        Content={popupValues.Content}
                        IsConfirmAlert
                        IsCloseIcon={false}
                    />
                </form>

            </Container>
        </>
    );
}

export default EnrollUser;
