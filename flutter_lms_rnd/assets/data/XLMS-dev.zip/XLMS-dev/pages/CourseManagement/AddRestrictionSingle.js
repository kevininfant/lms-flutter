import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLDragAndDropRestriction from "@components/Controls/NVLDragAndDropRestriction";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCustomFields, listXlmsUserGroupInfos } from "src/graphql/queries";
import * as Yup from "yup";

function AddRestrictionSingle({ BatchData, BatchID, actList, json, id, setData, TenantInfo, user, data, setSubmit, updateModuleData }) {
    const router = useRouter();
    const groupBy = function (xs, key) {
        return xs?.reduce(function (rv, x) {
            (rv[x[key]] = rv[x[key]] || []).push(x);
            return rv;
        }, {});
    };

    const previousVal = useRef({});
    const customRegex = useRef({})
    const listData = useRef(json?.flow);

    const [options, setOptions] = useState({});
    const [submit, setSubmitDrag] = useState(false);
    const [optionslength, setOptionlength] = useState(() => {
        if (json?.for?.length > 0) {
            return json?.for.length;
        }
        return 1;
    });

    let dynamicYupfields = {
        ["operator"]: Yup.string().when(("0type" + id), {
            is: "" || undefined || '',
            otherwise: Yup.string().required("The Field is Requried")
        }),
    };

    for (let i = 0; i < optionslength; i++) {
        dynamicYupfields = {
            ...dynamicYupfields,
            [i + "type" + id]: Yup.string()
                .test("", "", async (e) => {
                    if (e == previousVal.current?.[i]?.["type"]) {
                        return true;
                    }
                    else {
                        if (e == "userGroup") {
                            const groupResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + TenantInfo.TenantID, SK: "GROUPINFO#", }, user.signInUserSession.accessToken.jwtToken);
                            previousVal.current = { ...previousVal.current, [i]: { ...previousVal.current?.["1"], type: e } };
                            setOptions((data) => {
                                let value = [{ value: "", text: "Select Group" }];
                                if (groupResponse.res?.listXlmsUserGroupInfos?.items?.length > 0)
                                    groupResponse.res.listXlmsUserGroupInfos.items.map(item => {
                                        value = [...value, { value: item.GroupID, text: item.GroupName }];
                                    });
                                customRegex.current = { ...customRegex.current, [i]: {} }
                                return { ...data, [i]: { value: value, options: {} } };
                            });
                        }
                        else if (e != "") {
                            const customFieldResponse = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + TenantInfo.TenantID, SK: "CUSTOMFIELD#", }, user.signInUserSession.accessToken.jwtToken);
                            setOptions((data) => {
                                let value = [{ value: "", text: "Select ProfileField" }];
                                let optionsTemp = {}, regexValue = {};
                                if (customFieldResponse.res?.listXlmsCustomFields?.items?.length > 0)
                                    customFieldResponse.res.listXlmsCustomFields.items.map(item => {
                                        value = [...value, { value: item.ProfileFieldName, text: item.ProfileFieldName }];
                                        optionsTemp = { ...optionsTemp, [item.ProfileFieldName]: JSON.parse(item.FieldOptions) };
                                        regexValue = { ...regexValue, [item.ProfileFieldName]: { Max: item?.MaximumLength, Min: item?.MinimumLength, Regex: item?.Regex } }
                                    });
                                customRegex.current = { ...customRegex.current, [i]: regexValue }
                                return { ...data, [i]: { value: value, options: optionsTemp } };
                            });
                            previousVal.current = { ...previousVal.current, [i]: { ...previousVal.current?.[i], type: e } };
                        }
                        else {
                            setValue(i + "field" + id, "");
                        }
                        setValue(i + "value" + id, "");
                        setValue(i + "operator" + id, "");
                        return true;
                    }
                }).nullable(true),
            [i + "field" + id]: Yup.string().nullable(true).when([i + "type" + id], {
                is: "" || undefined || '',
                then: Yup.string().nullable(true),
                otherwise: Yup.string().required("Field is Requried").test("novalid", "novalie", e => {
                    if (previousVal.current?.[i]?.field != e) {
                        setValue(i + "value" + id, "");
                        previousVal.current = { ...previousVal.current, [i]: { ...previousVal.current?.[i], field: e } };
                    }
                    return true;
                })
            }),
            [i + "value" + id]: Yup.string().typeError().when([i + "type" + id], {
                is: "profileField",
                then: Yup.string().typeError().required("Field is Requried").test("Valid", "Invalid Value", (e, { createError }) => {
                    if (watch(i + "field" + id) == undefined || watch(i + "field" + id) == "") {
                        return true;
                    }
                    if (customRegex.current?.[id]?.[watch(i + "field" + id)] != undefined) {
                        let temp = customRegex.current?.[id]?.[watch(i + "field" + id)];
                        if (temp?.Min != undefined && e?.length < parseInt(temp?.Min)) {
                            return createError({ message: "The Minimun Length Must Be " + temp?.Min });
                        }
                        if (temp?.Max != undefined && e?.length > parseInt(temp?.Max)) {
                            return createError({ message: "The Maximum Length Must Be " + temp?.Max });
                        }
                        if (temp?.Regex != undefined && temp.Regex != "" && e?.match(new RegExp(temp.Regex, 'g'))?.[0] != e) {
                            return false
                        }
                    }
                    return true;
                })
            }),
            [i + "operator" + id]: Yup.string().typeError().when([i + "type" + id], {
                is: "" || undefined || '',
                otherwise: Yup.string().required("Field is Requried")
            }),
        };
    }

    useEffect(() => {
        return (() => {
            setOptionlength((data) => {
                getdataforjson(data);
                return data;
            })
        })
    }, [getdataforjson, id])

    const validationSchema = Yup.object().shape(dynamicYupfields);
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, formState, setValue, watch, clearErrors, handleSubmit } = useForm(formOptions);
    const { errors } = formState;

    const databind = useRef(false);

    const [items, setItems] = useState(() => {
        if (actList.length > 0 && BatchID == "") {
            const tempGroupZoom = groupBy(actList, "ZoomActivityID");
            let finalActList = [];
            actList.map((data) => {
                if (data?.ZoomActivityID == undefined) {
                    let actTemp = data;
                    if (tempGroupZoom?.[actTemp?.actId] != undefined) {
                        actTemp = { ...actTemp, ActList: tempGroupZoom?.[actTemp?.actId] }
                        finalActList = [...finalActList, actTemp];

                    }
                    else {
                        finalActList = [...finalActList, actTemp];
                    }
                }
            });
            return finalActList;
        }
        else if (listData.current?.ActivityList != undefined) {
            const tempGroupZoom = groupBy(listData.current.ActivityList, "ZoomActivityID");
            let finalActList = [];
            listData.current?.ActivityList.map((data) => {
                if (data?.ZoomActivityID == undefined) {
                    let actTemp = data;
                    if (tempGroupZoom?.[actTemp?.actId] != undefined) {
                        actTemp = { ...actTemp, ActList: tempGroupZoom?.[actTemp?.actId] }
                        finalActList = [...finalActList, actTemp];
                    }
                    else {
                        finalActList = [...finalActList, actTemp];
                    }
                }
            });
            return finalActList;
        } else {
            return [];
        }
    });

    useEffect(() => {
        if (json?.flow?.ActivityList?.length > 0) {
            listData.current = (json?.flow);
            if (actList.length == listData.current.ActivityList.length) {
                setItems(() => {
                    const tempGroupZoom = groupBy(listData.current.ActivityList, "ZoomActivityID");
                    let finalActList = [];
                    listData.current?.ActivityList.map((data) => {
                        if (data?.ZoomActivityID == undefined) {
                            let actTemp = data;
                            if (tempGroupZoom?.[actTemp?.actId] != undefined) {
                                actTemp = { ...actTemp, ActList: tempGroupZoom?.[actTemp?.actId] }
                                finalActList = [...finalActList, actTemp];
                            }
                            else {
                                finalActList = [...finalActList, actTemp];
                            }
                        }
                    });
                    return finalActList;
                });
            }
            else {
                let actListtemp = [], listCurrentData = listData.current.ActivityList;
                listData.current.ActivityList.map((data) => {
                    actListtemp = [...actListtemp, data.actId];
                });
                actList.map((data) => {
                    if (actListtemp.indexOf(data.actId) == -1) {
                        listCurrentData = [...listCurrentData, data];
                    }
                });
                listData.current = { ...listData.current, ActivityList: listCurrentData };
                setItems(() => {
                    const tempGroupZoom = groupBy(listData.current.ActivityList, "ZoomActivityID");
                    let finalActList = [];
                    listData.current?.ActivityList.map((data) => {
                        if (data?.ZoomActivityID == undefined) {
                            let actTemp = data;
                            if (tempGroupZoom?.[actTemp?.actId] != undefined) {
                                actTemp = { ...actTemp, ActList: tempGroupZoom?.[actTemp?.actId] }
                                finalActList = [...finalActList, actTemp];
                            }
                            else {
                                finalActList = [...finalActList, actTemp];
                            }
                        }
                    });
                    return finalActList;
                });
            }
        }
        else if (json?.flow?.ActivityList == undefined) {
            databind.current = true;
            let actOrder = {};
            actList.map((data, index) => {
                if (index != 0) {
                    const before = [actList[index - 1]];
                    actOrder = { ...actOrder, [data.actId]: { before: before } };
                }
                if (index != actList.length - 1) {
                    const after = [actList[index + 1]];
                    if (actOrder?.[data.actId] != undefined) {
                        actOrder = { ...actOrder, [data.actId]: { ...actOrder?.[data.actId], after: after } };
                    } else {
                        actOrder = { ...actOrder, [data.actId]: { after: after } };
                    }
                }
            });
            listData.current = { ActivityList: actList, must: actList, Visible: actList, Order: actOrder };
            setItems(() => {
                const tempGroupZoom = groupBy(listData.current.ActivityList, "ZoomActivityID");
                let finalActList = [];
                listData.current?.ActivityList.map((data) => {
                    if (data?.ZoomActivityID == undefined) {
                        let actTemp = data;
                        if (tempGroupZoom?.[actTemp?.actId] != undefined) {
                            actTemp = { ...actTemp, ActList: tempGroupZoom?.[actTemp?.actId] }
                            finalActList = [...finalActList, actTemp];
                        }
                        else {
                            finalActList = [...finalActList, actTemp];
                        }
                    }
                });
                return finalActList;
            });
        }
        if (json?.for?.length) {
            setOptionlength(json?.for?.length);
        }
    }, [actList, json, BatchID]);

    useEffect(() => {
        const bindValue = async () => {
            if (json?.for?.length > 0) {
                json.for.map(async (data, index) => {
                    if (data.type == "userGroup") {
                        const groupResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + TenantInfo.TenantID, SK: "GROUPINFO#", }, user.signInUserSession.accessToken.jwtToken);
                        previousVal.current = { ...previousVal.current, [index]: { ...previousVal.current?.[index], type: data.type } };
                        setOptions((temp) => {
                            let value = [{ value: "", text: "Select Group" }];
                            groupResponse.res.listXlmsUserGroupInfos.items.map(item => {
                                value = [...value, { value: item.GroupID, text: item.GroupName }];
                            });
                            customRegex.current = { ...customRegex.current, [index]: {} }
                            return { ...temp, [index]: { value: value, options: {} } };
                        });
                    }
                    else if (data.type == "profileField") {
                        const customFieldResponse = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + TenantInfo.TenantID, SK: "CUSTOMFIELD#", }, user.signInUserSession.accessToken.jwtToken);
                        setOptions((temp) => {
                            let value = [{ value: "", text: "Select ProfileField" }];
                            let optionsTemp = {}, regexValue = {};
                            if (customFieldResponse.res.listXlmsCustomFields != undefined)
                                customFieldResponse.res.listXlmsCustomFields.items.map(item => {
                                    value = [...value, { value: item.ProfileFieldName, text: item.ProfileFieldName }];
                                    if (item.FieldOptions != undefined) {
                                        optionsTemp = { ...optionsTemp, [item.ProfileFieldName]: JSON.parse(item.FieldOptions) };
                                    }
                                    regexValue = { ...regexValue, [item.ProfileFieldName]: { Max: item?.MaximumLength, Min: item?.MinimumLength, Regex: item?.Regex } }
                                });
                            customRegex.current = { ...customRegex.current, [index]: regexValue }

                            return { ...temp, [index]: { value: value, options: optionsTemp } };
                        });
                        previousVal.current = { ...previousVal.current, [index]: { ...previousVal.current?.[index], type: data.type, field: data.typevalue.key } };
                    }
                    if (index != json?.for?.length - 1) {
                        setValue(index + "type" + id, data.type);
                        if (data.type == "userGroup") {
                            setValue(index + "field" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);
                        }
                        else if (data.type == "profileField") {
                            setValue(index + "field" + id, data.typevalue.key);
                            setValue(index + "value" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);
                        }
                    }
                    else {
                        setValue(index + "type" + id, data.type);
                        if (data.type == "userGroup") {
                            setValue(index + "field" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);

                        }
                        else if (data.type == "profileField") {
                            setValue(index + "field" + id, data.typevalue.key);
                            setValue(index + "value" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);
                        }
                    }
                });
                listData.current = json?.flow;
            }
            setValue("operator", json?.operator, { shouldValidate: true });
        };
        bindValue();
        return (() => {
            setItems((data) => {
                return data;
            });
        });
    }, [json, TenantInfo.TenantID, user.signInUserSession.accessToken.jwtToken, setValue, id]);

    const dropdownData = useMemo(() => {
        const temp = [{ value: "", text: "Select Type" }, { value: "profileField", text: "Profile Field" }, { value: "userGroup", text: "User Group" }];
        return temp;
    }, []);

    const Options = useCallback((props) => {
        const rowGrid = [];
        for (let i = 0; i < optionslength; i++) {
            rowGrid.push(<CompletionRestrictControl idfor={props.idfor} final={i == optionslength - 1 && optionslength != 1 ? true : false} options={props.options} id={i} key={i} register={props.register} errors={props.errors} watch={props.watch} />);
        }
        return <>{rowGrid}</>;
    }, [optionslength]);

    const deleteOption = useCallback(async () => {
        setOptionlength((optionLength) => {
            clearErrors();
            setValue((optionLength - 1) + "type" + id, "");
            setValue((optionLength - 1) + "field" + id, "");
            setValue((optionLength - 1) + "value" + id, "");
            setValue((optionLength - 1) + "operator" + id, "", { shouldValidate: true });
            getdataforjson(optionLength - 1);
            return optionLength - 1;
        });
    }, [clearErrors, getdataforjson, id, setValue]);

    const CompletionRestrictControl = useCallback((props) => {
        let optionsGrp = [{ value: "", text: "Select Value" }];
        if (props.options?.[props.id]?.["value"] != undefined) {
            optionsGrp = props.options?.[props.id]?.["value"];
        }
        const optionsProfileField = props.options?.[props.id]?.["options"]?.[props.watch(props.id + "field" + props.idfor)];
        const optionsEquals = [{ value: "", text: "Select Type" }, { value: "equals", text: "Equals" }, { value: "notEquals", text: "Not Equals" }];
        return (
            <>
                <div className="flex w-full mx-auto">
                    <div className="w-1/4 ">
                        <NVLSelectField id={props.id + "type" + props.idfor} options={dropdownData} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input !w-full Disabled " : `nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                    </div>
                    {optionsGrp.length > 1 && props.watch(props.id + "type" + props.idfor) != "" && props.watch(props.id + "type" + props.idfor) == "profileField" && <>

                        <div className="w-1/4">
                            < NVLSelectField id={props.id + "field" + props.idfor} options={optionsGrp} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input !w-full Disabled " : `nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>
                        <div className="w-1/4 ">
                            <NVLSelectField id={props.id + "operator" + props.idfor} options={optionsEquals} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input !w-full Disabled " : `nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>
                    </>}
                    {optionsGrp.length > 1 && props.watch(props.id + "type" + props.idfor) != "" && props.watch(props.id + "type" + props.idfor) == "userGroup" && <>
                        <div className="w-1/4 ">
                            <NVLSelectField id={props.id + "operator" + props.idfor} options={optionsEquals} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input !w-full Disabled " : `nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>
                        <div className="w-1/4">
                            < NVLSelectField id={props.id + "field" + props.idfor} options={optionsGrp} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input !w-full Disabled " : `nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>

                    </>}
                    {props.watch(props.id + "type" + props.idfor) == "profileField" && optionsProfileField != undefined && optionsProfileField.length > 1 &&
                        <>
                            <div className="w-1/4">
                                <NVLSelectField id={props.id + "value" + props.idfor} options={optionsProfileField} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input !w-full Disabled " : `nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                            </div>

                        </>}
                    <>
                        {props.watch(props.id + "type" + props.idfor) == "profileField" && optionsProfileField != undefined && !(optionsProfileField.length > 1) &&
                            <div className="w-1/4 ">
                                <NVLTextbox id={props.id + "value" + props.idfor} options={optionsProfileField} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input !w-full Disabled " : `nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                            </div>}
                    </>
                    {props.final && <div className="pt-2">
                        <i className="fa-solid fa-trash text-red-600" onClick={() => { deleteOption(props?.id, optionslength); }}></i>
                    </div>}
                </div>

            </>
        );
    }, [BatchData, deleteOption, dropdownData, optionslength]);

    const addOption = useCallback(() => {
        setOptionlength((data) => {
            setValue((data) + "type" + id, "");
            setValue((data) + "field" + id, "");
            setValue((data) + "value" + id, "", { shouldValidate: true });
            return data + 1;
        });

    }, [id, setValue]);

    const getList = useCallback((list, watch, id, items) => {
        let actList = [];
        let actOrder = {};
        let actVisible = [];
        let actmust = [];
        list.map((data, index) => {
            if (data?.ActList == undefined) {
                actList = [...actList, data];
                if (index > 0) {
                    for (let i = index - 1; i >= 0; i--) {
                        if (watch(id + "order" + (i)) && watch(id + "visible" + (i))) {
                            let before = [];
                            for (let a = i; a >= 0; a--) {
                                if (watch(id + "order" + a) && watch(id + "visible" + a)) {
                                    if (list[a]?.ActList == undefined) {
                                        before = [list[a]];
                                    }
                                    else {
                                        const tempact = groupBy(list[a]?.ActList, "name");
                                        if (tempact?.[list[a].name + "-Feedback"]?.length > 0) {
                                            before = tempact?.[list[a].name + "-Feedback"];
                                        }
                                        else if (tempact?.[list[a].name + "-PostAssessment"]?.length > 0) {
                                            before = tempact?.[list[a].name + "-PostAssessment"];
                                        }
                                        else {
                                            before = [list[a]];
                                        }
                                    }
                                    break;
                                }
                            }
                            actOrder = { ...actOrder, [data.actId]: { before: before } };
                            before.map(temp => {
                                const temparray = actOrder?.[temp.actId]?.after == undefined ? [] : actOrder?.[temp.actId]?.after;
                                actOrder = { ...actOrder, [temp.actId]: { ...actOrder?.[temp.actId], after: [...temparray, data] } };
                            });
                            break;
                        }
                    }
                }
                if (watch(id + "must" + index)) {
                    actmust = [...actmust, data];
                    actVisible = [...actVisible, data];
                }
                else if (watch(id + "visible" + index)) {
                    actVisible = [...actVisible, data];
                }
            }
            else {
                const tempact = groupBy(data?.ActList, "name");
                if (tempact?.[data.name + "-PreAssessment"]?.length > 0) {
                    actList = [...actList, tempact?.[data.name + "-PreAssessment"][0]];
                    if (index > 0) {
                        for (let i = index - 1; i >= 0; i--) {
                            if (watch(id + "order" + (i)) && watch(id + "visible" + (i))) {
                                let before = [];
                                for (let a = i; a >= 0; a--) {
                                    if (watch(id + "order" + a) && watch(id + "visible" + a)) {
                                        before = [list[a]];
                                        break;
                                    }
                                }
                                actOrder = { ...actOrder, [tempact?.[data.name + "-PreAssessment"][0].actId]: { before: before } };
                                before.map(temp => {
                                    const temparray = actOrder?.[temp.actId]?.after == undefined ? [] : actOrder?.[temp.actId]?.after;
                                    actOrder = { ...actOrder, [temp.actId]: { ...actOrder?.[temp.actId], after: [...temparray, data] } };
                                });
                                break;
                            }
                        }
                    }
                    if (watch(id + "must" + index) || watch(id + "visible" + index)) {

                        const before = tempact?.[data.name + "-PreAssessment"];
                        actOrder = { ...actOrder, [data.actId]: { before: before } };
                    }
                    if (watch(id + "must" + index)) {
                        actmust = [...actmust, data];
                        actVisible = [...actVisible, tempact?.[data.name + "-PreAssessment"][0]];
                    }
                    else if (watch(id + "visible" + index)) {
                        actVisible = [...actVisible, tempact?.[data.name + "-PreAssessment"][0]];
                    }
                }
                else {
                    if (index > 0) {
                        for (let i = index - 1; i >= 0; i--) {
                            if (watch(id + "order" + (i)) && watch(id + "visible" + (i))) {
                                let before = [];
                                for (let a = i; a >= 0; a--) {
                                    if (watch(id + "order" + a) && watch(id + "visible" + a)) {
                                        before = [list[a]];
                                        break;
                                    }
                                }
                                actOrder = { ...actOrder, [data.actId]: { before: before } };
                                before.map(temp => {
                                    const temparray = actOrder?.[temp.actId]?.after == undefined ? [] : actOrder?.[temp.actId]?.after;
                                    actOrder = { ...actOrder, [temp.actId]: { ...actOrder?.[temp.actId], after: [...temparray, data] } };
                                });
                                break;
                            }
                        }
                    }
                }
                actList = [...actList, data];

                if (watch(id + "must" + index)) {
                    actmust = [...actmust, data];
                    actVisible = [...actVisible, data];
                }
                else if (watch(id + "visible" + index)) {
                    actVisible = [...actVisible, data];
                }
                if (tempact?.[data.name + "-PostAssessment"]?.length > 0) {
                    actList = [...actList, tempact?.[data.name + "-PostAssessment"][0]];
                    if (watch(id + "must" + index) || watch(id + "visible" + index)) {
                        actOrder = { ...actOrder, [tempact?.[data.name + "-PostAssessment"][0].actId]: { before: [data] } };
                    }
                    if (watch(id + "must" + index)) {
                        actmust = [...actmust, data];
                        actVisible = [...actVisible, tempact?.[data.name + "-PostAssessment"][0]];
                    }
                    else if (watch(id + "visible" + index)) {
                        actVisible = [...actVisible, tempact?.[data.name + "-PostAssessment"][0]];
                    }
                }
                if (tempact?.[data.name + "-Feedback"]?.length > 0) {
                    actList = [...actList, tempact?.[data.name + "-Feedback"][0]];

                    if (tempact?.[data.name + "-PostAssessment"]?.length > 0 && (watch(id + "must" + index) || watch(id + "visible" + index))) {
                        actOrder = { ...actOrder, [tempact?.[data.name + "-Feedback"][0].actId]: { before: tempact?.[data.name + "-PostAssessment"] } };
                    }
                    else if (watch(id + "must" + index) || watch(id + "visible" + index)) {
                        actOrder = { ...actOrder, [tempact?.[data.name + "-Feedback"][0].actId]: { before: [data] } };
                    }
                    if (watch(id + "must" + index)) {
                        actmust = [...actmust, data];
                        actVisible = [...actVisible, tempact?.[data.name + "-Feedback"][0]];
                    }
                    else if (watch(id + "visible" + index)) {
                        actVisible = [...actVisible, tempact?.[data.name + "-Feedback"][0]];
                    }
                }
            }
        });
        listData.current = { ActivityList: actList, Order: actOrder, Visible: actVisible, must: actmust };
    }, []);

    const getdataforjson = useCallback((Optionslength, temp, operator, tempjson) => {
        let json = { for: [], flow: listData.current };
        if (tempjson != undefined) {
            json = { ...tempjson };
        }
        else {
            if (temp != undefined) {
                json = { for: [], flow: temp };
            }
            for (var i = 0; i < Optionslength; i++) {
                json = {
                    ...json, for: [...json.for, {
                        type: watch(i + "type" + id),
                        typevalue: {
                            key: watch(i + "type" + id) == "profileField" ? watch(i + "field" + id) : "",
                            value: watch(i + "type" + id) != "profileField" ? watch(i + "field" + id) : watch(i + "value" + id),
                            operator: watch(i + "operator" + id),
                        }
                    }],
                }
            }
            json = { ...json, operator: watch("operator") }
            if (operator != undefined) {
                json = { ...json, operator: operator }
            }
        }
        setData(json, "" + id);
    }, [id, setData, watch]);

    useEffect(() => {
        if (submit != 0) {
            handleSubmit((temp) => {
                setOptionlength((data) => {
                    getdataforjson(data);
                    setSubmit((data) => {
                        return { ...data, [id]: "okay" }
                    })
                    return data
                });
            }, () => {
                setOptionlength((data) => {
                    getdataforjson(data);
                    setSubmit((data) => {
                        return { ...data, [id]: "Error" };
                    })
                    return data
                });
            })();
        }
    }, [submit, getdataforjson, setSubmit, handleSubmit, id]);

    return (
        <>
            <Container>
                <NVLSelectField labelText={"Condition"} labelClassName={"nvl-Def-Label"} id={"operator"} options={[{ value: "", text: "Select Condition" }, { value: "and", text: "And Condition" }, { value: "or", text: "Or Condition" }]} className={BatchData?.IsDefaultBatch == true ? "nvl-Def-Input Disabled " : `nvl-Def-Input`} errors={errors} register={register} />
                <Options idfor={id} id={optionslength} register={register} errors={errors} watch={watch} options={options} />
                <NVLButton id="btnSubmit" type="button" text={"Add Option field"} className={BatchData?.IsDefaultBatch == true ? "w-48 nvl-button text-gray-700 bg-primary Disabled " : "w-48 nvl-button bg-primary text-white "} onClick={() => addOption(optionslength, errors)}></NVLButton>
                <NVLDragAndDropRestriction BatchDatas={BatchData} updateModuleData={updateModuleData} setSubmitDrag={setSubmitDrag} data={data} id={id} json={listData.current} items={items} getList={getList} />
            </Container>
        </>
    );
}

export default AddRestrictionSingle;