import AssignmentAdminGrade from "@Pages/ActivityManagement/AssignmentAdminGrade";
import React from 'react';

export default function CourseAssignmentAdminGrade(props) {
  return (
    <>
        <AssignmentAdminGrade {...props}/>
    </>
  )
}
