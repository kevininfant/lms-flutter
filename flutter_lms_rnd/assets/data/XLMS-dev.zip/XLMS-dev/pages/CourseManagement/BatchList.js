import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import NVLToolTip from "@components/Controls/NVLToolTip";
import Container from "@Container/Container";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { createXlmsCourseEnrollUser, updateXlmsCourseBatch } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo, listXlmsCourseBatchInfosOrderList, listXlmsCourseBatchWiseDismissUserList } from "src/graphql/queries";

export default function ActivityList(props) {
    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("");
    const [courseData, setCourseData] = useState();

    const headerColumn = [
        { HeaderName: "Batch Name", Columnvalue: "BatchName", HeaderCss: "!w-6/12", },
        { HeaderName: "Start Date", Columnvalue: "Startdate", HeaderCss: "!w-2/12" },
        { HeaderName: "End Date", Columnvalue: "Enddate", HeaderCss: "!w-2/12" },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "!w-2/12" }
    ];
    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    };
    const refreshGrid = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    const resetPopUp = useCallback(() => {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "", Usercount: [] });

    }, []);

    const popup = useCallback(async (type, PK, SK) => {
        const moduleData = await AppsyncDBconnection(listXlmsCourseBatchWiseDismissUserList, { GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + PK.split("#")[3], GsiSK: "BATCH#" + SK.split("#")[1], }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const userCount = moduleData?.res?.listXlmsCourseBatchWiseDismissUserList?.items;
        const content = `${userCount?.length == undefined || userCount?.length == 0 ? "Are you sure to delete the batch?" : `${userCount?.length} Users assigned to the course.If deleted they will be Un Assigned from the course.Do you wish to proceed ?`}`;
        setPopupValues({ PK: PK, SK: SK, Content: content, Type: type, Usercount: userCount });
    }, [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken]);

    const updateField = useCallback(async (e) => {
        e.preventDefault();
        const userInfo = [];
        popupValues.Usercount?.map((getItem, index) => {
            userInfo = [...userInfo, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSE#ENROLLUSER#" + getItem.UserSub, SK: "COURSE#" + popupValues.PK.split("#")[3] + "#BATCH#" + popupValues.SK.split("#")[1], BatchID: popupValues.SK.split("#")[1], CourseID: popupValues.PK.split("#")[3], LastModifiedDate: new Date(), IsSuspend: true }];
            if ((index + 1) % 25 == 0 || index + 1 == popupValues.Usercount?.length) {
                AppsyncDBconnection(createXlmsCourseEnrollUser, { input: userInfo }, props.user.signInUserSession.accessToken.jwtToken);
                userInfo = [];
            }
        });


        let finalResult = await AppsyncDBconnection(updateXlmsCourseBatch, { input: { PK: popupValues.PK, SK: popupValues.SK, IsDeleted: true, LastModifiedDate: new Date() } }, props.user.signInUserSession.accessToken.jwtToken);
        if (finalResult.Status == "Success") {
            refreshGrid();
        }
        resetPopUp();
    }, [popupValues.PK, popupValues.SK, popupValues.Usercount, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, resetPopUp]);

    useEffect(() => {
        async function batchData() {
            const courseDataResponse = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#" + router.query["CourseID"] }, props.user.signInUserSession.accessToken.jwtToken);
            setCourseData({
                CourseData: courseDataResponse?.res?.getXlmsCourseManagementInfo
            })
        } batchData()
    }, [props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query])

    const actionRestriction = useCallback((getItem) => {
        const actionList = [];
        actionList.push({ id: 1, Color: "text-yellow-600", Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6", name: "Edit Batch", action: () => { router.push(`CreateBatch?CourseID=${getItem.CourseID}&BatchID=${getItem.BatchID}&CourseName=${router.query.CourseName}`); } });
        if (getItem?.IsDefaultBatch != true) {
            actionList.push({ id: 2, Color: "text-rose-700", Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6 ", name: "Delete", action: () => popup("isDelete", getItem.PK, getItem.SK) },);
        }
        return actionList;
    }, [popup, router]);

    const gridDataBind = useCallback(
        (viewData) => {
            const rowGrid = [];
            viewData &&
                viewData.map((getItem, index) => {
                    let actionList = [];
                    actionList = actionRestriction(getItem);
                    rowGrid.push({
                        PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
                        SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />),
                        ActivityId: (<NVLlabel id={"lblActivityId" + (index + 1)} name="ActivityId" text={getItem.SK} />),
                        BatchName: (<NVLlabel id={"txtActivityName" + (index + 1)} text={getItem.BatchName}></NVLlabel>),
                        Startdate: (<NVLlabel id={"txtActivityName" + (index + 1)} text={(getItem.StartDate == undefined || getItem.StartDate == "" || getItem.StartDate == null) ? "" : new Date(getItem.StartDate).toDateString().substring(4)}></NVLlabel>),
                        Enddate: (<NVLlabel id={"txtActivityName" + (index + 1)} text={(getItem.EndDate == undefined || getItem.EndDate == "" || getItem.EndDate == null) ? "" : new Date(getItem.EndDate).toDateString().substring(4)}></NVLlabel>),
                        Action: (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionList}    ></NVLRapidModal>),
                    });
                });
            return rowGrid;
        }, [actionRestriction]
    );

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };

    const cancelEvent = (e) => {
        e.preventDefault();
        resetPopUp();
    };

    const variable = useMemo(() => {
        return { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + router?.query?.CourseID, SK: "COURSEBATCH#", IsDeleted: false };
    }, [props.TenantInfo.TenantID, router?.query?.CourseID]);

    const pageRoutes = useMemo(() => {
        return [
            { path: "CourseList", breadcrumb: "Course Management" },
            { path: "", breadcrumb: "Batch List" }
        ];
    }, []);

    return (
        <>
            <Container title="Batch List" loader={props.TenantInfo == undefined}>
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <NVLHeader
                    ButtonToolTip={(courseData?.CourseData?.ActiveActivityCount == 0 || courseData?.CourseData?.ActiveActivityCount == undefined || courseData?.CourseData?.ActiveActivityCount == null) ? <NVLToolTip PopDetail={"Their is no activity in a course. Kindly create a activity for a course"}
                        PopIcon={"pl-3 pt-3 text-sm fa fa-solid fa-circle-question"} ></NVLToolTip> : ""}
                    TabRouting={props?.GeneralRoleData?.AllowNewTab} IsSearch={false} ButtonID5="btnCreateActivity" LinkName5="+ Create Batch" className5={(courseData?.CourseData?.ActiveActivityCount == 0 || courseData?.CourseData?.ActiveActivityCount == undefined || courseData?.CourseData?.ActiveActivityCount == null) ? "pointer-events-none nvl-button-gray" : (props.TabRouting == true ? "" : "nvl-button-success")} RedirectHome={"/"} RedirectAction5={(e) => headerHandler(e, `CreateBatch?CourseID=${router?.query?.CourseID}&BatchID=&CourseName=${router.query.CourseName}`)} href5={`CreateBatch?CourseID=${router?.query?.CourseID}&BatchID=ae27e9-18c&CourseName=${router.query.CourseName}`} placeholder={"Search by "} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshGrid} RedirectAction4={() => refreshGrid()} IsNestedHeader />

                <div className="max-w-full w-full justify-center">
                    <NVLGridTable
                        user={props.user}
                        refershPage={isRefreshing}
                        id="tblBatchList" Search={search}
                        HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsCourseBatchInfosOrderList}
                        querryName={"listXlmsCourseBatchInfosOrderList"}
                        variable={variable} />

                </div>
                <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />

            </Container>
        </>
    );
}