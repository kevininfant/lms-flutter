import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseSubCategory, updateXlmsCourseSubCategory } from "src/graphql/mutations";
import { getXlmsCourseSubCategory, listXlmsActiveCourseCategory, listXlmsCourseSubCategory } from "src/graphql/queries";
import * as Yup from "yup";

function SubCategory(props) {

    const [message, setMessage] = useState("");
    const router = useRouter();
    const [pageData, setPageData] = useState({});
    const refCategory = useRef();

    useEffect(() => {
        const dataSource = async () => {
            const tenantId = props?.user.attributes["custom:tenantid"];
            const categoryId = decodeURIComponent(String(router.query["CategoryID"]));
            const mode = decodeURIComponent(String(router.query["Mode"]));
            const subCategoryId = decodeURIComponent(String(router.query["SubCategoryID"]));

            const PK = "TENANT#" + tenantId;
            const SK = "COURSECATEGORY#" + categoryId + "#COURSESUBCATEGORY#" + subCategoryId;
            const categoryData = await AppsyncDBconnection(listXlmsActiveCourseCategory, { PK: "TENANT#" + tenantId, SK: "COURSECATEGORY#", IsDeleted: false, IsSuspend: false }, props.user?.signInUserSession?.accessToken?.jwtToken);


            const createdSubCategoryData = await AppsyncDBconnection(getXlmsCourseSubCategory, { PK: PK, SK: SK, IsDeleted: false, IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            let temp = {
                ...props,
                TenantID: tenantId,
                CategoryData: categoryData.res?.listXlmsActiveCourseCategory?.items != undefined ? categoryData.res?.listXlmsActiveCourseCategory?.items : [],
                SubCategoryData: createdSubCategoryData.res?.getXlmsCourseSubCategory != undefined ? createdSubCategoryData.res?.getXlmsCourseSubCategory : [],
                EditSK: SK,
                CoursePK: mode == "CourseEditDirect" && PK,
                CourseSK: mode == "CourseEditDirect" && SK,
                CourseCategoryID: mode == "CourseEditDirect" && categoryId,
                CategoryID: categoryId,
                SubCategoryID: subCategoryId
            };

            if (props.Mode == undefined) {
                temp = {
                    ...temp, Mode: mode,
                };
            }
            setPageData(temp);
        };
        dataSource();
        return (() => {
            setPageData((temp) => { return { ...temp }; });
        });
    }, [props, props?.user.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

    const initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            pageData.Mode == "CourseEditDirect" ? router.push(`/CourseManagement/EditSetting?parameters=${"Edit" + "$" + encodeURIComponent(pageData.CoursePK + "$" + pageData.CourseSK)}`) : pageData.Mode == "CourseDirect" ? router.push("/CourseManagement/CourseInfo") : router.push("/CourseManagement/CategoryList");
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);

    const clearForm = () => {
        reset();
        setValue("txtSubCategoryName", "")
        setHTMLContents("", message);
    };

    const finalResponse = useCallback((FinalStatus) => {
        document?.activeElement?.blur();

        if (FinalStatus != "Success") {
            document.getElementById("modepopup") != null ? document.getElementById("modepopup").classList.remove("hidden") : "";
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        } else {
            ModalOpen();
        }
    }, []);

    const categoryList = useMemo(() => {
        const categoryData = [{ value: "", text: "Select Category" }];
        if (pageData.CategoryData != undefined) {
            const CategoryFiltered = pageData.CategoryData?.filter(
                (obj) => !categoryData[obj.CategoryID] && (categoryData[obj.CategoryID] = true && obj.SubCategoryID == undefined)
            );
            CategoryFiltered?.map((category) => {
                [categoryData.push({ value: category.CategoryID, text: category.CategoryName })];
            });
        }
        return categoryData;
    }, [pageData.CategoryData]);


    useEffect(() => {
        if (props.open == 1) {
            reset();
            if (message != "") {
                setHTMLContents("", message);
            }
        }
    }, [message, props.open, reset]);
    const validationSchema = Yup.object().shape({
        ddlCategory: Yup.string().required("Category is required").test("", "", (e) => {
            refCategory.current = e;
            return true;
        }).nullable(),

        txtSubCategoryName: Yup.string()
            .required("Sub-Category name is required")
            .matches(Regex("AlphaNumForTopicName"), "Enter SubCategory Valid  name")
            .max(250, "Maximum length exceeded 250")
            .nullable()
            .test("", "", async (e, { createError }) => {
                const SK = `COURSECATEGORY#${watch("ddlCategory")}#COURSESUBCATEGORY#`;
                const existSubCategory = await AppsyncDBconnection(listXlmsCourseSubCategory, {
                    PK: "TENANT#" + props.TenantInfo.TenantID,
                    SK: SK,
                    IsDeleted: false,
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);

                const existingSubCategoryName = existSubCategory.res?.listXlmsCourseSubCategory?.items;

                const subCategoryNameFound = existingSubCategoryName?.some((subcategory) => subcategory?.SubCategoryName?.toLowerCase() == e?.toLowerCase());

                if (subCategoryNameFound && (pageData.Mode == "Edit" || pageData.Mode == "Create" || pageData.Mode == "CourseDirect" || pageData.Mode == "Popup") && e?.toLowerCase() != pageData.SubCategoryData?.SubCategoryName?.toLowerCase()) {


                    return createError({ message: "SubCategory Name already exists" });
                }

                const existCategoryName = pageData.CategoryData;

                const popupCategoryNameFound = existCategoryName.some((category) => category.text?.toLowerCase() == e?.toLowerCase());

                if (pageData.Mode == "Popup" && popupCategoryNameFound) {
                    return createError({ message: " * Sub category name and category name should not be same" });
                }
                const categoryNameFound = existCategoryName.some((category) => category.CategoryName?.toLowerCase() == e?.toLowerCase());

                if (categoryNameFound && (pageData.Mode == "Edit" || pageData.Mode == "Create" || pageData.Mode == "CourseDirect" || pageData.Mode == "Popup") && e?.toLowerCase() != pageData.SubCategoryData?.SubCategoryName?.toLowerCase()) {
                    return createError({ message: " * Sub category name and category name should not be same" });
                }
                if (e != "") {
                    return true;
                }
            }),

    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, reset, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    const submitHandler = async (data) => {
        setValue("submit", true);
        const PK = "TENANT#" + props.TenantInfo.TenantID;
        const subCategoryId = pageData.Mode == "Edit" ? pageData.SubCategoryID : Math.random().toString(25).substring(2, 12);
        const SK = pageData.Mode == "Edit" ? pageData.EditSK : `COURSECATEGORY#${watch("ddlCategory")}#COURSESUBCATEGORY#${subCategoryId}`;

        function getCategoryName() {
            const categoryName = categoryList?.filter(item => {
                return item?.value == refCategory.current;
            });
            return categoryName?.[0].text;
        }

        const query = pageData.Mode == "Edit" ? updateXlmsCourseSubCategory : createXlmsCourseSubCategory;
        const variables = {
            input: {
                PK: PK,
                SK: SK,
                SubCategoryID: subCategoryId,
                SubCategoryName: data.txtSubCategoryName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                CategoryName: getCategoryName(),
                CategoryID: watch("ddlCategory"),
                SubCategoryDescription: getContents(message),
                IsDeleted: false,
                IsSuspend: false,
                CreatedBy: pageData.Mode != "Edit" ? props.user.username : pageData.SubCategoryData?.CreatedBy,
                CreatedDate: pageData.Mode != "Edit" ? new Date() : pageData.SubCategoryData?.CreatedDate,
                LastModifiedBy: pageData.Mode == "Edit" ? props.user.username : pageData.SubCategoryData?.LastModifiedBy,
                LastModifiedDate: new Date()
            },
        };
        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        if (pageData.Mode != "Popup") {
            finalResponse(finalStatus);
        } else {
            document.getElementById("divPageModal")?.classList?.add("hidden");
            props.setOpen(() => {
                return false;
            });
            clearForm();
        }
        setValue("submit", false);
    };

    useEffect(() => {
        if (message != "") setHTMLContents("", message);
        if (pageData.Mode == "CourseDirect") {
            setValue("ddlCategory", pageData?.CategoryID);
        } else if (pageData.Mode == "CourseEditDirect") {
            setValue("ddlCategory", pageData?.CourseCategoryID);
        }
        if (pageData.Mode == "Edit") {
            setValue("ddlCategory", pageData.SubCategoryData?.CategoryID);
            setValue("txtSubCategoryName", pageData.SubCategoryData?.SubCategoryName);
            if (message != "") {
                setHTMLContents(pageData.SubCategoryData?.SubCategoryDescription, message);
                message?.history?.clear();
            }
        }

        setValue("submit", false);
    }, [setValue, message, pageData.SubCategoryData, pageData.Mode, pageData?.CategoryID, pageData?.CourseCategoryID, watch, props.SelectedCategory]);

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            {
                path: "/CourseManagement/CourseList",
                breadcrumb: "Course Management"
            },
            {
                path: pageData.Mode == "CourseDirect" ?
                    "/CourseManagement/CourseInfo" : pageData.Mode == "CourseEditDirect" ?
                        `/CourseManagement/EditSetting?parameters=${"Edit" + "$" +
                        encodeURIComponent(pageData.CoursePK + "$" + pageData.CourseSK)}` :
                        "/CourseManagement/CategoryList", breadcrumb: "Manage Course/ Category"
            },
            { path: "", breadcrumb: pageData.Mode == "Edit" ? "Edit Sub-Category" : "Create Sub-Category" }
        ];
    }, [pageData.CoursePK, pageData.CourseSK, pageData.Mode]);
    return (
        <>
            <Container PageRoutes={pageData.Mode != "Popup" ? pageRoutes : undefined} loader={pageData?.TenantID == undefined} title="SubCategory">
                {pageData.Mode != "Popup" && <> <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                </>}
                <form onSubmit={handleSubmit(submitHandler)} id="fmSubCategoryList" className="nvl-FormContent">
                    <div className={pageData.Mode != "Popup" ? "nvl-FormContent" : ""}>
                        <NVLSelectField id="ddlCategory" labelText={"Select Category"} labelClassName="nvl-Def-Label pb-1" errors={errors} register={register} options={categoryList} className={`w-96 nvl-mandatory ${pageData.Mode == "Edit" ? "Disabled" : ""}`} disabled={pageData.Mode == "Edit" ? true : false} />
                        <div className="pt-1">
                            <NVLTextbox required id="txtSubCategoryName" labelText="Sub-Category Name" labelClassName="nvl-Def-Label pb-1" title="Sub-Category Name" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        </div>
                        <div className={`${pageData.Mode == "Popup" ? "w-screen" : ""}`}>
                            <div className="pt-1">
                                <NVLlabel text="Sub-Category Description" className="nvl-Def-Label pb-1" ></NVLlabel></div>
                            <NVLRichTextBox id="txtSubCategoryDescription" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} />
                        </div>
                        <div className="justify-center flex gap-1">
                            <NVLButton text={!watch("submit") ? "Save" : ""} disabled={watch("submit") ? true : false} type="submit"
                                className="w-32 nvl-button bg-primary text-white " >
                                {
                                    watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
                                }
                            </NVLButton>
                            <NVLButton id="btnCancel" type="button" text={pageData.Mode == "Popup" || pageData.Mode == "Create" ? "Clear" : "Cancel"} className="nvl-button w-32" onClick={() => (pageData.Mode == "Popup" || pageData.Mode == "Create") ? clearForm() : router.push(pageData.Mode == "CourseDirect" ? "/CourseManagement/CourseInfo" : pageData.Mode == "CourseEditDirect" ? `/CourseManagement/EditSetting?parameters=${"Edit" + "$" + encodeURIComponent(pageData.CoursePK + "$" + pageData.CourseSK)}` : "/CourseManagement/CategoryList")} />
                        </div>
                    </div>

                </form>
            </Container>
        </>
    );
}

export default SubCategory;