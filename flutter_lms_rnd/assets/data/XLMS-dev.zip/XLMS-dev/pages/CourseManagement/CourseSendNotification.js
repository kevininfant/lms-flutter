import Notification from "@Pages/ActivityManagement/Notification";
import { useRouter } from "next/router";

function CourseSendNotification(props) {
    const router = useRouter();
    
    return (
        <div>
            <Notification user={props.user} 
                TenantInfo={props.TenantInfo} 
                CourseID={router.query["CourseID"]}
                GeneralRoleData={props.GeneralRoleData} 
                RoleData={props.RoleData} 
                props={props}
                ModuleID={router.query["ModuleID"]}/>
        </div>
    );
}

export default CourseSendNotification;

