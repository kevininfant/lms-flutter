import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseCategory, updateXlmsCourseCategory, updateXlmsCourseManagementInfo, updateXlmsCourseSubCategory } from "src/graphql/mutations";
import { getXlmsCourseCategory, listXlmsCourseCategory, listXlmsCourseManagementInfo, listXlmsCourseSubCategory } from "src/graphql/queries";
import * as Yup from "yup";

function CreateCategory(props) {
    const router = useRouter();
    const [csrFetchedCategoryData, setCsrFetchedCategoryData] = useState({});
    useEffect(() => {
     
        const dataSource = async () => {
            const tenantId = props?.user.attributes["custom:tenantid"];
            const categoryId = decodeURIComponent(String(router.query["CategoryID"]));
            const mode = decodeURIComponent(String(router.query["Mode"]));
            const subCategoryID = decodeURIComponent(String(router.query["SubCategoryID"]));
            const PK = "TENANT#" + tenantId;
            const SK = "COURSECATEGORY#" + categoryId + (subCategoryID != 0 ? "#COURSESUBCATEGORY#" + subCategoryID : "");

            const categoryData = await AppsyncDBconnection(listXlmsCourseCategory, {
                PK: "TENANT#" + tenantId,
                SK: "COURSECATEGORY#",
                IsDeleted: false,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const createdCategoryData = await AppsyncDBconnection(getXlmsCourseCategory, {
                PK: PK,
                SK: SK,
                IsDeleted: false,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            let temp = {
                ...props,
                TenantID: tenantId,
                CategoryID: categoryId,
                SubCategoryID: subCategoryID,
                CategoryData: categoryData.res?.listXlmsCourseCategory?.items != undefined ? categoryData.res?.listXlmsCourseCategory?.items : [],
                EditData: createdCategoryData.res?.getXlmsCourseCategory != undefined ? createdCategoryData.res?.getXlmsCourseCategory : [],
                EditSK: SK,
                CoursePK: mode == "CourseEditDirect" && PK,
                CourseSK: mode == "CourseEditDirect" && SK
            };
            if (props.Mode == undefined) {
                temp = {
                    ...temp, Mode: mode,
                };
            }
            setCsrFetchedCategoryData(temp);
        };
        dataSource();
        return (() => {
            setCsrFetchedCategoryData((temp) => { return { ...temp }; });
        });
    }, [props, props?.user.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

    const [message, setMessage] = useState("");
    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            csrFetchedCategoryData.Mode == "CourseEditDirect" ? router.push(`/CourseManagement/EditSetting?parameters=${"Edit" + "$" + encodeURIComponent(csrFetchedCategoryData.CoursePK + "$" + csrFetchedCategoryData.CourseSK)}`) : csrFetchedCategoryData.Mode == "CourseDirect" ? router.push("/CourseManagement/CourseInfo") : router.push("/CourseManagement/CategoryList");
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);

    const clearForm = () => {
        reset();
        setValue("txtCategoryName", "")
        setHTMLContents("", message);
    };
    useEffect(() => {
        if (csrFetchedCategoryData.Mode == "Edit") {
            setValue("txtCategoryName", csrFetchedCategoryData.EditData?.CategoryName);
            if (message != "") {
                setHTMLContents(csrFetchedCategoryData.EditData?.CategoryDescription, message);
                message?.history?.clear();
            }
        }
    }, [message, setValue, csrFetchedCategoryData.EditData, csrFetchedCategoryData.Mode]);

    const validationSchema = Yup.object().shape({
        txtCategoryName: Yup.string()
            .required("Category name is required")
            .matches(Regex("AlphaNumForTopicName"), "Enter Category Valid  name")
            .max(250, "Maximum length exceeded 250")
            .nullable()
            .test("", "", async (e, { createError }) => {

               
                const existingCategoryName = Object.values(csrFetchedCategoryData.CategoryData).filter((data) => {
                    const subCategorySK = data?.SK;
                    return subCategorySK?.split("#")?.[2] != "COURSESUBCATEGORY";
                });

                const categoryNameFound = existingCategoryName?.some((category) => category?.CategoryName?.toLowerCase() == e?.toLowerCase());

                if (categoryNameFound && (csrFetchedCategoryData.Mode == "Edit" || csrFetchedCategoryData.Mode == "Create" || csrFetchedCategoryData.Mode == "CourseDirect" || csrFetchedCategoryData.Mode == "Popup" || csrFetchedCategoryData.Mode == undefined) && e?.toLowerCase() != csrFetchedCategoryData.CategoryData?.CategoryName?.toLowerCase()) {

                    if (e?.toLowerCase() != csrFetchedCategoryData.EditData?.CategoryName?.toLowerCase()) {

                        return createError({ message: "Category Name already exists" });
                    }
                    return true;
                }

                const SK = (csrFetchedCategoryData.Mode == "Edit" || csrFetchedCategoryData.Mode == undefined) ? csrFetchedCategoryData.EditSK : (0 + "#COURSESUBCATEGORY#");

                const existSubCategory = await AppsyncDBconnection(listXlmsCourseSubCategory, {
                    PK: "TENANT#" + props.TenantInfo.TenantID,
                    SK: SK,
                    IsDeleted: false,
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);

                const existingSubCategoryName = existSubCategory.res?.listXlmsCourseSubCategory?.items;

                const categoryNameCheck = existingSubCategoryName?.some((subcategory) =>
                    subcategory?.SubCategoryName?.toLowerCase() == e?.toLowerCase());

                if (categoryNameCheck && (csrFetchedCategoryData.Mode == "Edit" || csrFetchedCategoryData.Mode == "Create" || csrFetchedCategoryData.Mode == "CourseDirect")
          && e?.toLowerCase() != existingSubCategoryName.SubCategoryName?.toLowerCase()) {
                    return createError({ message: "* Category Name should not be same as SubCategory Name" });
                }
                return true;
            }),

    });
    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };
    const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    const finalResponse = useCallback((finalStatus) => {
        document?.activeElement?.blur();
        if (finalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: finalStatus,
            });
            ModalOpen();
            return;
        } else {
            setValue("submit", true);
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    csrFetchedCategoryData.Mode == "CourseEditDirect" ? router.push(`/CourseManagement/EditSetting?parameters=${"Edit" + "$" + encodeURIComponent(csrFetchedCategoryData.CoursePK + "$" + csrFetchedCategoryData.CourseSK)}`) : csrFetchedCategoryData.Mode == "CourseDirect" ? router.push("/CourseManagement/CourseInfo") : router.push("/CourseManagement/CategoryList");
                },
            });
            ModalOpen();
        }
    }, [csrFetchedCategoryData.CoursePK, csrFetchedCategoryData.CourseSK, csrFetchedCategoryData.Mode, router, setValue]);

    useEffect(() => {
        if (props.open == 1) {
            reset();
            if (message != "") {
                setHTMLContents("", message);
            }
        }
    }, [message, props.open, reset]);


    const submitHandler = async (data) => {
        document?.activeElement?.blur();
        setValue("submit", true);
        const PK = "TENANT#" + props.TenantInfo.TenantID;

        const categoryId = csrFetchedCategoryData.Mode == "Edit" ? csrFetchedCategoryData.CategoryID : Math.random().toString(25).substring(2, 12);

        const SK = "COURSECATEGORY#" + categoryId;
        const query = csrFetchedCategoryData.Mode == "Edit" ? updateXlmsCourseCategory : createXlmsCourseCategory;

        const variables = {
            input: {
                PK: PK,
                SK: SK,
                CategoryID: categoryId,
                CategoryName: data.txtCategoryName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                CategoryDescription: getContents(message),
                IsDeleted: false,
                IsSuspend: false,
                CreatedBy: csrFetchedCategoryData.Mode != "Edit" ? props.user?.username : csrFetchedCategoryData.EditData?.CreatedBy,
                CreatedDate: csrFetchedCategoryData.Mode != "Edit" ? new Date() : csrFetchedCategoryData.EditData?.CreatedDate,
                LastModifiedBy: csrFetchedCategoryData.Mode == "Edit" ? props.user?.username : csrFetchedCategoryData.EditData?.LastModifiedBy,
                LastModifiedDate: new Date()
            },
        };

        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;

        if (csrFetchedCategoryData.Mode == "Edit" || csrFetchedCategoryData.Mode == "CourseDirect" || csrFetchedCategoryData.Mode == undefined) {
            const existSubCategory = await AppsyncDBconnection(listXlmsCourseSubCategory, {
                PK: "TENANT#" + props.TenantInfo.TenantID,
                SK: "COURSECATEGORY#" + categoryId + "#COURSESUBCATEGORY",
                IsDeleted: false,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const needToUpdateSubCategoryRecord =
        existSubCategory.res?.listXlmsCourseSubCategory?.items?.filter((subcategory) => {
            return subcategory?.CategoryID == categoryId;
        }
        );
            needToUpdateSubCategoryRecord?.map(async (subcategory) => {
                await AppsyncDBconnection(updateXlmsCourseSubCategory, {
                    input: {
                        PK: subcategory.PK,
                        SK: subcategory.SK,
                        CategoryName: data.txtCategoryName,
                        CategoryDescription: getContents(message),
                    }
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            }

            );

            const existCourseRecord = await AppsyncDBconnection(listXlmsCourseManagementInfo, {
                PK: "TENANT#" + props.TenantInfo?.TenantID,
                SK: "COURSEINFO#",
                IsDeleted: false,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const needToUpdateCourseCategoryRecord =
        existCourseRecord.res?.listXlmsCourseManagementInfo?.items?.filter((course) => {
            return course?.CategoryID == categoryId;
        }
        );

            needToUpdateCourseCategoryRecord?.map(async (course) => {
                await AppsyncDBconnection(updateXlmsCourseManagementInfo, {
                    input: {
                        PK: course.PK,
                        SK: course.SK,
                        CategoryName: data.txtCategoryName,
                        CategoryDescription: getContents(message),
                        LastModifiedBy: props.user.username,
                        LastModifiedDate: new Date(),
                    }
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            });
        }

        if (csrFetchedCategoryData.Mode != "Popup") {
            finalResponse(finalStatus);
        } else {
            document.getElementById("divPageModal")?.classList?.add("hidden");
           
            props.setOpen(() => {
                return false;
            });
            clearForm();
        }
        setValue("submit", false);
    };
    // Bread Crumbs
   

    const pageRoutes  = useMemo(() => {
        return [
            {
                path: "/CourseManagement/CourseList",
                breadcrumb: "Course Management"
            },
            {
                path: csrFetchedCategoryData.Mode == "CourseDirect" ?
                    "/CourseManagement/CourseInfo" : csrFetchedCategoryData.Mode == "CourseEditDirect" ?
                        `/CourseManagement/EditSetting?parameters=${"Edit" + "$" +
            encodeURIComponent(csrFetchedCategoryData.CoursePK + "$" + csrFetchedCategoryData.CourseSK)}` :
                        "/CourseManagement/CategoryList", breadcrumb: "Manage Course/ Category"
            },
            { path: "", breadcrumb: csrFetchedCategoryData.Mode == "Edit" ? "Edit Category" : "Create Category" }
        ];
    }, [csrFetchedCategoryData.CoursePK, csrFetchedCategoryData.CourseSK, csrFetchedCategoryData.Mode]);

    return (
        <>

            <Container  PageRoutes={csrFetchedCategoryData.Mode != "Popup" ? pageRoutes : undefined} loader={csrFetchedCategoryData?.TenantID == undefined} title="CreateCategory">
                <form onSubmit={handleSubmit(submitHandler)} id="fmCategoryList">
                    {csrFetchedCategoryData.Mode != "Popup" && <>
                        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} /></>}
                    <div className="nvl-FormContent">
                        <NVLTextbox required id="txtCategoryName" labelText="Category Name" labelClassName="nvl-Def-Label pb-1" title="Category Name" className={"nvl-mandatory nvl-Def-Input"} max={"50"} errors={errors} register={register} />
                        <div>
                            <NVLlabel text="Category Description" className="nvl-Def-Label pb-1" >
                            </NVLlabel>
                        </div>
                        <NVLRichTextBox id="txtCategoryDescription" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} max={"250"} />
                        <div className={`${csrFetchedCategoryData.Mode == "Popup" ? "flex flex-row gap-1 nvl-Def-Input" : "flex flex-row gap-1 nvl-Def-Input justify-center"} `}>
                            <NVLButton id="btnSubmit"
                                text={!watch("submit") ? "Save" : ""}
                                disabled={watch("submit") ? true : false}
                                type="submit"
                                className={"w-32 nvl-button bg-primary text-white"}
                            >
                                {
                                    watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
                                }
                            </NVLButton>
                            <NVLButton id="btnCancel" text={csrFetchedCategoryData.Mode == "Popup" || csrFetchedCategoryData.Mode == "Create" ? "Clear" : "Cancel"} type="button" className="nvl-button w-28" onClick={() => (csrFetchedCategoryData.Mode == "Popup" || csrFetchedCategoryData.Mode == "Create") ? clearForm() : router.push(csrFetchedCategoryData.Mode == "CourseDirect" ? "/CourseManagement/CourseInfo" : csrFetchedCategoryData.Mode == "CourseEditDirect" ? `/CourseManagement/EditSetting?parameters=${"Edit" + "$" + encodeURIComponent(csrFetchedCategoryData.CoursePK + "$" + csrFetchedCategoryData.CourseSK)}` : "/CourseManagement/CategoryList")}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CreateCategory;