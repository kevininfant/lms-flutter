import OfflineQuiz from "@Pages/ActivityManagement/OfflineQuiz";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { getXlmsCourseManagementInfo, getXlmsCourseModule, listXlmsCourseBatchInfos, listXlmsCourseBatchWiseDismissUserList } from "src/graphql/queries";

function CourseOfflineQuiz(props) {
    const router = useRouter();

    const [csrFetchedData, setCsrFetchedData] = useState();

    useEffect(() => {
        async function fetchQuizData() {
            const userCount = await AppsyncDBconnection(listXlmsCourseBatchWiseDismissUserList , { GsiPK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEID#" + router.query["CourseID"], GsiSK: "BATCH#" }, props.user.signInUserSession.accessToken.jwtToken);
            const activityData = await AppsyncDBconnection(getXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEID#" + router.query["CourseID"] + "#MODULEID#" + router.query["ModuleID"] + "#ACTIVITYTYPE#" + router.query["ActivityType"] + "#ACTIVITYID#" + router.query["ActivityID"] }, props.user.signInUserSession.accessToken.jwtToken);
            const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + router.query["CourseID"], SK: "COURSEBATCH#",IsDeleted:false }, props.user.signInUserSession.accessToken.jwtToken);
            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#" + router.query["CourseID"], }, props.user.signInUserSession.accessToken.jwtToken);
            setCsrFetchedData({
                EnrolledUser: userCount?.res?.listXlmsCourseBatchWiseDismissUserList?.items != undefined ? userCount?.res?.listXlmsCourseBatchWiseDismissUserList?.items : [],
                ActivityData: activityData?.res?.getXlmsCourseModule,
                BatchData: batchData.res?.listXlmsCourseBatchInfos?.items != undefined ? batchData.res?.listXlmsCourseBatchInfos?.items : [],
                CourseData: courseData?.res?.getXlmsCourseManagementInfo,
            });
        }
        fetchQuizData();
        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
        });
    }, [props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query]);


    return (
        <>
            <OfflineQuiz user={props.user} mode={router.query["Mode"]} TenantInfo={props.TenantInfo} ActivityID={router.query["ActivityID"]}
                ActivityType={router.query["ActivityType"]} CourseID={router.query["CourseID"]} ModuleID={router.query["ModuleID"]}
                EnrolledUser={csrFetchedData?.EnrolledUser} ActivityData={csrFetchedData?.ActivityData} BatchData={csrFetchedData?.BatchData} CourseData={csrFetchedData?.CourseData} UserSub={props.user.attributes["sub"]} />
        </>
    );
}
export default CourseOfflineQuiz;


