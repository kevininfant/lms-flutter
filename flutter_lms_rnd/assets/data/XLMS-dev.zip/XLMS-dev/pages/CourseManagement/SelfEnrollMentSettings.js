import { GetDateFormat } from "@components/Common/DateFormat";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXlmsCourseManagementInfo } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo } from "src/graphql/queries";
import * as Yup from "yup";

function SelfEnrollMentSettings(props) {

    const [message, setMessage] = useState("");
    const [fetchData, setData] = useState();
    const router = useRouter();
    const initialModalState ="";
    useEffect(() => {
        const dataSource = async () => {
            const tentId = props.user.attributes["custom:tenantid"];
            const courseId = decodeURIComponent(String(router.query["CourseID"]));
            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, {
                PK: "TENANT#" + tentId,
                SK: "COURSEINFO#" + courseId,

            }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            setData({
                TenantId: tentId,
                CourseID: courseId != undefined ? courseId : [],
                Coursedata: courseData.res?.getXlmsCourseManagementInfo,
            });
      
            const initialModalState = {
                ModalInfo: "Success",
                ModalTopMessage: "Success",
                ModalBottomMessage: "Details have been saved successfully.",
                ModalOnClickEvent: () => {
                    router.push(`/CourseManagement/EnrollmentSettingsList?CourseID=${courseId}`);
                },
            };
            setModalValues(initialModalState);
      
        };
    

        dataSource();
        return (() => {
            setData((temp) => { return { ...temp }; });
        });

    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router, router.query]);
  
    const [modalValues, setModalValues] = useState(initialModalState);
    const validationSchema = Yup.object().shape({
        txtstdate: Yup.date()
            .when("chkStartDateEnable", {
                is: true,
                then: Yup.date("Enroll startdate is required")
                    .required(" Enroll startdate is required")
                    .typeError("Enroll can be created only for present and future date")
                    .min(new Date(new Date().setDate(new Date().getDate() - 1)), "Enroll can be created only for present and future date")
                    .test("check", "Enroll startdate Should between the course date", (e) => {
                        const dateTime = new Date(e);
                        const enrolldate = GetDateFormat(dateTime, "yyyy-mm-dd");
                        const courseStartdate = GetDateFormat(fetchData?.Coursedata?.DateTime, "yyyy-mm-dd");
                        const courseEnddate = GetDateFormat(fetchData?.Coursedata?.EndDateTime, "yyyy-mm-dd");
                        if (enrolldate < courseStartdate || enrolldate > courseEnddate) {

                            return false;
                        }
                        return true;


                    }),
                otherwise: Yup.date().min(new Date(new Date().setDate(new Date().getDate() - 1)), "Enroll can be created only for present and future date").typeError("Enroll can be created only for present and future date").test("check", "Enroll startdate should between the course date", (e) => {
                    const dateTime = new Date(e);
                    const Enrolldate = GetDateFormat(dateTime, "yyyy-mm-dd");
                    const CourseStartdate = GetDateFormat(fetchData?.Coursedata?.DateTime, "yyyy-mm-dd");
                    const CourseEnddate = GetDateFormat(fetchData?.Coursedata?.EndDateTime, "yyyy-mm-dd");

                    if (e != undefined) {
                        if (!fetchData?.Coursedata?.DateTime == "" && !fetchData?.Coursedata?.EndDateTime == "") {

                            if (Enrolldate < CourseStartdate || Enrolldate > CourseEnddate) {

                                return false;
                            }
                        }
                    }
                    return true;


                }),
            }),

        txtEnddate: Yup.date()
            .when("chkEndDateEnable", {
                is: true,
                then: Yup.date().min(Yup.ref("txtstdate"), "Enroll enddate must be greater than or equal to the  enroll startdate")
                .required("Enroll enddate is required").typeError("Enroll enddate is required")
                .test("check", "Enroll enddate should between the course date", (e) => {
                    const dateTime = new Date(e);
                    const Enrolldate = GetDateFormat(dateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    const CourseEnddate = GetDateFormat(fetchData?.Coursedata.EndDateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    const CourseDateTime = GetDateFormat(fetchData?.Coursedata.DateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    if (watch("chkStartDateEnable") == false) {
                        setValue("txtEnddate", "");
                    }
                    if (e != undefined) {
                        if (!fetchData?.Coursedata.EndDateTime == "") {
                            if (Enrolldate > CourseEnddate || Enrolldate < CourseDateTime) {
                                return false;
                            }
                        }
                    }
                    return true;
                }),
                otherwise: Yup.date().min(Yup.ref("txtstdate"), " Enroll enddate must be greater than or equal to the start date").typeError("Enroll can be created only for present and future date").test("check", "Enroll enddate Should create between the course date or future date", (e) => {
                    const dateTime = new Date(e);
                    const Enrolldate = GetDateFormat(dateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    const CourseEnddate = GetDateFormat(fetchData?.Coursedata.EndDateTime, "±YYYYYY-MM-DDTHH:mm:ss");
                    if (e != undefined) {
                        if (!fetchData?.Coursedata.EndDateTime == "") {

                            if (Enrolldate > CourseEnddate|| Enrolldate < CourseDateTime) {

                                return false;
                            }
                        }
                    }
                    return true;
                }),

            }),

        txtMaximumEnrollUser: Yup.string().notRequired().test("", ("Enter Only Number"), (e) => {
            if (e == undefined || e == "") {
                return true;
            }
            const rejax = new RegExp(/^[0-9]+$/);
            if (!rejax.test(e)) {
                return false;
            }
            return true;


        }).nullable(),
    });
    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };
    const { register, handleSubmit, setValue, watch, formState } =
    useForm(formOptions);

    const { errors } = formState;


    useEffect(() => {

        setValue("ddlUserRole", props?.Coursedata?.DefaultAssignmentRoll);
        setValue("rbEnrollExpiry", (fetchData?.Coursedata?.IsNotifyBeforeEnroll == null || fetchData?.Coursedata?.IsNotifyBeforeEnroll == undefined ? "false" : fetchData?.Coursedata?.IsNotifyBeforeEnroll?.toString()));
        setValue("txtstdate", DateCoversion(fetchData?.Coursedata?.SelfEnrollStartDate) == "1970-01-1" || DateCoversion(fetchData?.Coursedata?.SelfEnrollStartDate) == "NaN-NaN-NaN" ? undefined
            : DateCoversion(fetchData?.Coursedata?.SelfEnrollStartDate));
        setValue("txtEnddate", DateCoversion(fetchData?.Coursedata?.SelfEnrollEndDate) == "1970-01-1" || DateCoversion(fetchData?.Coursedata?.SelfEnrollEndDate) == "NaN-NaN-NaN"? undefined
            : DateCoversion(fetchData?.Coursedata?.SelfEnrollEndDate));
        setValue("chkStartDateEnable", fetchData?.Coursedata?.SelfEnrollStartDate == undefined || fetchData?.Coursedata?.SelfEnrollStartDate == "" ? false : true);
        setValue("chkEndDateEnable", fetchData?.Coursedata?.SelfEnrollEndDate == undefined || fetchData?.Coursedata?.SelfEnrollEndDate == "" ? false : true);
        setValue("txtEnrollkey", fetchData?.Coursedata?.EnrollKey);
        setValue("rbMessage", fetchData?.Coursedata?.IsSentWelcomeMessage == false ? "No" : "Yes");
        setValue("txtSendMessage", fetchData?.Coursedata?.WelcomeMessage);
        setValue("txtMaximumEnrollUser", fetchData?.Coursedata?.MaximumEnrollUser);
        setValue("rbExistingExpiry", (fetchData?.Coursedata?.IsAllowExistingEnrollment == null || fetchData?.Coursedata?.IsAllowExistingEnrollment == undefined ? "false" : fetchData?.Coursedata?.IsAllowExistingEnrollment?.toString()));
        if (message != "") {
            setHTMLContents(fetchData?.Coursedata?.WelcomeMessage, message);
            message?.history?.clear();
        }
    }, [setValue, message, props?.Coursedata?.DefaultAssignmentRoll, fetchData?.Coursedata?.IsNotifyBeforeEnroll, fetchData?.Coursedata?.SelfEnrollStartDate, fetchData?.Coursedata?.SelfEnrollEndDate, fetchData?.Coursedata?.EnrollKey, fetchData?.Coursedata?.IsSentWelcomeMessage, fetchData?.Coursedata?.WelcomeMessage, fetchData?.Coursedata?.MaximumEnrollUser, fetchData?.Coursedata?.IsAllowExistingEnrollment]);


    const finalresponse = (finalStatus) => {
        if (finalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: finalStatus,
                ModalOnClickEvent: () => {

                    router.push(`/CourseManagement/EnrollmentSettingsList?CourseID=${fetchData?.CourseID}`);

                },
            });
            ModalOpen();
            return;
        } else {
            ModalOpen();
        }
    };
    const role = [
        { value: "", text: "Select Role" },
        { value: "Trainer", text: "Trainer" },
        { value: "User", text: "User" },

    ];
    const DateCoversion = (date) => {
        const dateTime = new Date(date);
        const dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + (dateTime.getDate() < 10 ? "0" + dateTime.getDate() : dateTime.getDate());

        const splitdate =
      dateTimeString;
        return splitdate;
    };
    useEffect(() => {
        if (watch("rbMessage") == "No") {
            setHTMLContents("", message);
        }
    });

    const DateTime = useCallback(({ errors, register, setValue, watch }) => {
        const today = new Date();
        const dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate());

        if (!watch("chkStartDateEnable")) {
            if (watch("chkStartDateEnable"))
                setValue("chkStartDateEnable", false, { shouldValidate: true });
            if (!(watch("txtstdate") == undefined))
                setValue("txtstdate", undefined, { shouldValidate: true });

            if (watch("chkEndDateEnable"))
                setValue("chkEndDateEnable", false, { shouldValidate: true });

            if (!(watch("txtEnddate") == undefined))
                setValue("txtEnddate", undefined, { shouldValidate: true });
        }
        else if (!watch("chkEndDateEnable")) {
            if (!(watch("txtEnddate") == undefined)) {
                setValue("txtEnddate", undefined, { shouldValidate: true });
            }
        }
        return (
            <div className="grid">

                <div className="flex">
                    <div className="pb-4">
                        <NVLlabel text="Enrollment Start Date" className="nvl-Def-Label"></NVLlabel>
                        <NVLTextbox id="txtstdate" title="Start Date" type="date" tabIndex={!watch("chkStartDateEnable") ? "1" : "0"} className={!watch("chkStartDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkStartDateEnable")} setValue={setValue} errors={errors} register={register}></NVLTextbox>

                    </div>

                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkStartDateEnable" errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>


                <div className="flex">
                    <div className="">
                        <NVLlabel text="Enrollment End Date" className="nvl-Def-Label"></NVLlabel>
                        <NVLTextbox title="End Date" id="txtEnddate" type="date" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"} className={!watch("chkEndDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} min={dateTime} disabled={!watch("chkEndDateEnable")} errors={errors} register={register} setValue={setValue}></NVLTextbox>
                    </div>
                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkEndDateEnable" disabled={!watch("chkStartDateEnable")} errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>

            </div>
        );
    }, []);
    const submitHandler = async (data) => {
      
        setValue("submit", true);
        const PK = "TENANT#" + fetchData.TenantId;
        const SK = "COURSEINFO#" + fetchData.CourseID;
        const query = updateXlmsCourseManagementInfo;

        const variables = {
            input: {

                PK: PK,
                SK: SK,
                CourseID: fetchData.CourseID,
                EnrollKey: data.txtEnrollkey,
                CreatedDate: props.mode == "Create" ? new Date() : props?.Coursedata?.CreatedDate,
                IsAllowExistingEnrollment: data.rbExistingExpiry,
                DefaultAssignmentRoll: data.ddlUserRole,
                IsSentWelcomeMessage: watch("rbMessage") == "Yes" ? true : false,
                MaximumEnrollUser: data.txtMaximumEnrollUser,
                WelcomeMessage: watch("rbMessage") == "Yes" ? getContents(message) : "",
                IsNotifyBeforeEnroll: data.rbEnrollExpiry,
                SelfEnrollStartDate: watch("chkStartDateEnable") != false ? data.txtstdate : "",
                SelfEnrollEndDate: watch("chkEndDateEnable") != false ? data.txtEnddate : "",
                LastModifiedDate: new Date()

            }
        };

        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        finalresponse(finalStatus);
        setValue("submit", false);

    };

    const pageRoutes = [
        {
            path: props.mode == "Create" || props.mode == "Edit" ? "/ActivityManagement/ActivityList" : `/CourseManagement/CourseList`,
            breadcrumb: props.mode == "Create" || props.mode == "Edit" ? "Activity Management" : "Course Management"
        },
        {
            path: `/CourseManagement/EnrollmentSettingsList?CourseID=${fetchData?.CourseID}`
            ,
            breadcrumb: "Enrollment Setting"
        },
        { path: "", breadcrumb: "Self Enrollment Settings" }
    ];
    return (


        <>
            <Container PageRoutes={pageRoutes} loader={fetchData?.Coursedata?.CourseName==undefined}>
                <form onSubmit={handleSubmit(submitHandler)}>
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className="nvl-FormContent">
                        <NVLlabel className="nvl-Def-Label pb-1" text={`Course Name : ${fetchData?.Coursedata?.CourseName}`} />
                        <NVLlabel showFull={true} className="nvl-Def-Label pb-1" text={`Course Interface : Self Enrollment`} />
                        <NVLlabel text="Allow Existing Enrollment " className="nvl-Def-Label"></NVLlabel>
                        <div className="flex gap-16">
                            <NVLRadio text="Yes" value="true" name="rbExistingExpiry" id="rbExistingExpiry" errors={errors} register={register} ></NVLRadio>
                            <NVLRadio text="No" value="false" name="rbExistingExpiry" id="rbExistingExpiry" errors={errors} register={register}></NVLRadio>
                        </div>
                        <div>
                            <NVLlabel text="Enroll key" className="nvl-Def-Label pb-1 pt-2" />
                            <NVLTextbox
                                id="txtEnrollkey"
                                title="Enroll Key"
                                className="nvl-non-mandatory"
                                errors={errors}
                                register={register}
                            />
                        </div>
                        <NVLSelectField labelClassName="nvl-Def-Label" labelText="Select Role" options={role} id="ddlUserRole" className={"nvl-non-mandatory nvl-Def-Input"} register={register} errors={errors}></NVLSelectField>
                        <div className="grid ">
                            <NVLlabel showFull={true} className="nvl-Def-Label" text={` Course ValidDate From : ${fetchData?.Coursedata.DateTime == undefined ? "-" : GetDateFormat(fetchData?.Coursedata.DateTime, "day mm dd yyy").slice(3)}  TO  ${fetchData?.Coursedata.EndDateTime == "" ? "-" : GetDateFormat(fetchData?.Coursedata.EndDateTime, "day mm dd yyy").slice(3)}`} />
                            <DateTime errors={errors} register={register} watch={watch} setValue={setValue} />
                        </div>
                        <NVLlabel text="Notify Before Enroll Expiry " className="nvl-Def-Label"></NVLlabel>
                        <div className="flex gap-16">

                            <NVLRadio text="Yes" value="true" name="rbEnrollExpiry" id="rbEnrollExpiry" errors={errors} register={register} ></NVLRadio>
                            <NVLRadio text="No" value="false" name="rbEnrollExpiry" id="rbEnrollExpiry" errors={errors} register={register}></NVLRadio>
                        </div>
                        <div>
                            <NVLlabel text="Maximum Enroll User" className="nvl-Def-Label pb-1 pt-2" />
                            <NVLTextbox
                                id="txtMaximumEnrollUser"
                                title="Maximum Enroll User"
                                className="nvl-non-mandatory"
                                errors={errors}
                                register={register}
                            />
                        </div>
                        <NVLlabel text="Send Welcome Message" className="nvl-Def-Label pb-1 pt-2" />
                        <div className="flex gap-8 font-bold text-gray-600">

                            <NVLRadio id="rbMessage" text="Yes" name="rbMessage" value={"Yes"} errors={errors} register={register} defaultChecked></NVLRadio>
                            <NVLRadio id="rbMessage" text="No" name="rbMessage" value={"No"} errors={errors} register={register} ></NVLRadio>
                        </div>

                        <div className={`${watch("rbMessage") != "Yes" ? "hidden" : "pt-4"}`}>

                            <NVLRichTextBox

                                id="txtSendMessage" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} max={"250"}
                            >

                            </NVLRichTextBox>
                        </div>
                        <div className="flex justify-center gap-1 pt-2">
                            <NVLButton
                                id="btnSave"
                                text={!watch("submit") ? "Submit" : ""}
                                type={"submit"}
                                disabled={watch("submit") == "submit" ? true : false}
                                className={"w-32 nvl-button bg-primary text-white "}>
                                {watch("submit") && (
                                    <i className="fa fa-circle-notch fa-spin mr-2"></i>
                                )}
                            </NVLButton>
                            <NVLButton id="btnCancel" type="button" text="Cancel" onClick={() => router.push(`/CourseManagement/EnrollmentSettingsList?CourseID=${fetchData?.CourseID}`)} className={`nvl-button w-28`}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>

        </>
    );


}
export default SelfEnrollMentSettings;
