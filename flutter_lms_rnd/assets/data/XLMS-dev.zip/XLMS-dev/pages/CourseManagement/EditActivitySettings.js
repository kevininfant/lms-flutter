import Container from "@components/Container/Container";
import EditActivity from "@Pages/ActivityManagement/EditActivitySettings";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { getXlmsActivityManagementInfo, getXlmsCourseActivityConfig, getXlmsCourseModule, listXlmsCourseModule, listXlmsLanguages } from "src/graphql/queries";


function EditActivitySettings(props) {
    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const moduleId = useMemo(() => { return router.query["ModuleID"]; }, [router.query]);
    const courseId = useMemo(() => { return router.query["CourseID"]; }, [router.query]);
    const activityId = useMemo(() => { return router.query["ActivityID"]; }, [router.query]);
    const activityType = useMemo(() => { return router.query["ActivityType"]; }, [router.query]);
    const mode = useMemo(() => { return router.query["Mode"]; }, [router.query]);
   

    useEffect(() => {

        async function dataSource() {
            let isUpdateData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId }, props.user.signInUserSession.accessToken.jwtToken);
            isUpdateData = isUpdateData.res?.getXlmsActivityManagementInfo;
            if (courseId !=undefined) {
                if (mode == "ModuleDirect") {
                    isUpdateData = await AppsyncDBconnection(getXlmsCourseModule, {
                        PK: "TENANT#" + props?.TenantInfo?.TenantID,
                        SK: "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId
                    }, props.user.signInUserSession.accessToken.jwtToken);
    
                    isUpdateData = isUpdateData.res?.getXlmsCourseModule;
                } else {
                    const zoomWise = await AppsyncDBconnection(listXlmsCourseModule, {
                        PK: "TENANT#" + props?.TenantInfo?.TenantID,
                        SK: "COURSEID#" + courseId + "#MODULEID#" + moduleId ,
                        IsDeleted: false
                    }, props.user.signInUserSession.accessToken.jwtToken);
        
                    const zoomWiseActivity = zoomWise.res.listXlmsCourseModule.items;
                    const filtereddata = zoomWiseActivity.filter((id)=> (id.ZoomActivityID == router.query["ZoomActivityID"]) && id.ActivityName.includes(mode) );
                    isUpdateData=filtereddata[0];
                }
            }
        
            const recordContentData = await AppsyncDBconnection(getXlmsCourseActivityConfig, { PK: "XLMS#LEARNINGBYTES", SK: "OPTION#OptionName" }, props.user.signInUserSession.accessToken.jwtToken);
            const recordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME" }, props.user.signInUserSession.accessToken.jwtToken);
            setCsrFetchedData({
                EditData: isUpdateData,
                RecordContent: recordContentData?.res?.getXlmsCourseActivityConfig,
                LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
            });
        }
        dataSource();

        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
        });
    }, [activityId, activityType, courseId, moduleId, mode, props?.TenantInfo?.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query]);

    return (
        <>
            <Container loader={Object.keys(csrFetchedData) == 0} >
                {Object.keys(csrFetchedData) != 0 && <EditActivity user={props?.user} mode={mode} ActivityData={props?.ActivityData} ActivityType={activityType} TenantInfo={props.TenantInfo} EditData={csrFetchedData?.EditData}
                    ActivityID={activityId}
                    TenantName={props?.TenantInfo?.TenantName}
                    RecordContent={csrFetchedData?.RecordContent}
                    LanguageName={csrFetchedData?.LanguageName}
                    CourseID={courseId}
                    ModuleID={moduleId}
                    ZoomActivityID={router.query["ZoomActivityID"]}
                    ZoomActivityName={router.query["ZoomActiviyName"]}
                />}
            </Container>
        </>
    );
}

export default EditActivitySettings;

