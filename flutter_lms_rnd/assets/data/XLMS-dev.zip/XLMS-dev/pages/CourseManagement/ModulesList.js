import { createMeeting } from "@components/Common/ZoomMeeting";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import NVLWarning from "@components/Controls/NVLWarning";
import { APIGatewayGetRequest, APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createXlmsBatchCourseBatch, createXlmsCourseModuleStatus, updateXlmsCourseManagementInfo, updateXlmsCourseModule } from "src/graphql/mutations";
import { getXlmsCourseActivityConfig, getXlmsCourseManagementInfo, getXlmsCourseModule, listXlmsCourseBatch, listXlmsCourseModule } from "src/graphql/queries";

function ModulesList(props) {
    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [courseModule, setCourseModule] = useState();
    const [submit, setSubmit] = useState()
    const moduleDatas = useRef();
    const moduleData1 = useRef();
    const courseID = useMemo(() => { return router.query["CourseID"]; }, [router.query]);
    const initialModalState = { ModalInfo: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details Saved Successfully", };
    const [modalValues, setModalValues] = useState(initialModalState);
    const refreshData = useCallback(async () => {
        const moduleList = await AppsyncDBconnection(listXlmsCourseModule, {
            PK: `TENANT#${props.TenantInfo.TenantID}#COURSEINFO#${courseID}`,
            SK: "COURSEMODULE#",
            IsDeleted: false
        }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        let temp = moduleList?.res?.listXlmsCourseModule?.items != undefined ? moduleList?.res?.listXlmsCourseModule?.items : [], tempModule = [];
        for (let i = 0; i < temp?.length; i++) {
            if (temp[i]?.ActiveActivityCount == undefined) {
                const variable = { PK: `TENANT#${props.TenantInfo.TenantID}`, SK: `COURSEID#${courseID}#MODULEID#${temp[i]?.ModuleID}`, IsDeleted: false };
                const ActivityDataResponse = await AppsyncDBconnection(listXlmsCourseModule, variable, props.user?.signInUserSession?.accessToken?.jwtToken);
                let ActivityCount = 0, ActiveActivityCount = 0;
                ActivityDataResponse?.res?.listXlmsCourseModule?.items?.map((data) => { ActivityCount++; if (!data.IsSuspend) { ActiveActivityCount++; } })
                tempModule = [...tempModule, { ...temp[i], ActivityCount: ActivityCount, ActiveActivityCount: ActiveActivityCount }]
            }
        };
        if (tempModule?.length > 0) {
            AppsyncDBconnection(createXlmsBatchCourseBatch, { input: tempModule }, props.user?.signInUserSession?.accessToken?.jwtToken);
        }
        const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#" + router.query["CourseID"] }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        setCourseModule((data) => { return { ...data, CourseData: courseData?.res?.getXlmsCourseManagementInfo != undefined ? courseData?.res?.getXlmsCourseManagementInfo : [], ModuleList: moduleList?.res?.listXlmsCourseModule?.items != undefined ? moduleList?.res?.listXlmsCourseModule?.items : [] }; });

    }, [courseID, props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

    const resetPopUp = useCallback(() => {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
        refreshData();
    }, [refreshData]);

    const popUp = useCallback((type, PK, SK, Content) => {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });

    }, []);
    const finalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: FinalStatus, });
            ModalOpen();
            return;
        } else {
            setModalValues({ ModalInfo: "Success", ModalTopMessage: FinalStatus, ModalBottomMessage: "Details Saved Successfully" });
            ModalOpen();
        }


    }, []);
    useEffect(() => {
        refreshData()
        async function moduleData() {
            const AuthorizedToken = props.user?.signInUserSession?.accessToken?.jwtToken;
            const activityData = await AppsyncDBconnection(getXlmsCourseActivityConfig, { PK: "XLMS#ACTIVITY", SK: "ACTIVITY#ACTIVITYTYPE", IsDeleted: false }, AuthorizedToken);
            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#" + router.query["CourseID"] }, AuthorizedToken);
            const moduleList = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + courseID, SK: "COURSEMODULE#", IsDeleted: false }, AuthorizedToken);
            setCourseModule({
                ActivityData: activityData.res?.getXlmsCourseActivityConfig != undefined ? activityData.res?.getXlmsCourseActivityConfig : [],
                ModuleList: moduleList?.res?.listXlmsCourseModule?.items != undefined ? moduleList?.res?.listXlmsCourseModule?.items : [],
                CourseData: courseData?.res?.getXlmsCourseManagementInfo != undefined ? courseData?.res?.getXlmsCourseManagementInfo : []
            });
        }
        moduleData();
        return (() => {
            setCourseModule({});
        });

    }, [courseID, props, props.TenantInfo.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, refreshData, router.query]);

    async function updateField() {
        setSubmit(true)
        var isSus = false;
        var isDelete = false;
        let jsonSaveData = "";
        let moduleActivityDataResponse, moduleBatchListResponse, moduleActivityListResponse, moduleDataResponse, finalResult;
        const listActivity = [];
        const listBatch = [];
        const stateMachineArn = process.env.BATCH_RESTRICTION_SET;
        const restrictionUrl = process.env.BATCH_RESTRICTION_API;

        if (popupValues.Type == "isSuspend") {
            isSus = true;
        } else if (popupValues.Type == "isDelete") {
            isDelete = true;
            isSus = true;
        }
        if (popupValues.Type != "isDeleteActivity") {
            const deletedStatus = await AppsyncDBconnection(updateXlmsCourseModule, {
                input:
                    popupValues.Type == "isSuspend" || popupValues.Type == "isUnSuspend"
                        ? { PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus, ModifiedDate: new Date() }
                        : {
                            PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus, IsDeleted: isDelete, ModifiedDate: new Date(),
                        },
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            let variables, moduleCount, activeModuleCount, activeActivityCount, activityCount;

            moduleDataResponse = await AppsyncDBconnection(listXlmsCourseBatch, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSEID#" + courseID + "#MODULEID#" + popupValues.SK.split("#")[1], IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            moduleData1.current = moduleDataResponse?.res?.listXlmsCourseBatch.items
            if (popupValues.Type == "isDelete") {
                refreshData()
                activityCount = (courseModule?.CourseData?.ActivityCount == undefined || courseModule?.CourseData?.ActivityCount == null) ? 0 : ~~courseModule?.CourseData?.ActivityCount - moduleData1.current?.length;
                activeActivityCount = (courseModule?.CourseData?.ActiveActivityCount == undefined || courseModule?.CourseData?.ActiveActivityCount == null) ? 0 : ~~courseModule?.CourseData?.ActiveActivityCount - moduleData1.current?.length
                moduleCount = (courseModule?.CourseData?.ModuleCount == undefined || courseModule?.CourseData?.ModuleCount == null) ? 0 : ~~courseModule?.CourseData?.ModuleCount - 1;
                variables = { input: { PK: courseModule?.CourseData?.PK, SK: courseModule?.CourseData?.SK, ModuleCount: moduleCount, ActiveModuleCount: activeModuleCount, ActivityCount: activityCount, ActiveModuleCount: activeModuleCount } }
            }
            if (popupValues.Type == "isSuspend") {
                refreshData()
                activeModuleCount = (courseModule?.CourseData?.ActiveModuleCount == undefined || courseModule?.CourseData?.ActiveModuleCount == null) ? 0 : ~~courseModule?.CourseData?.ActiveModuleCount - 1;
                activeActivityCount = (courseModule?.CourseData?.ActiveActivityCount == undefined || courseModule?.CourseData?.ActiveActivityCount == null) ? 0 : ~~courseModule?.CourseData?.ActiveActivityCount - moduleData1.current?.length
                variables = { input: { PK: courseModule?.CourseData?.PK, SK: courseModule?.CourseData?.SK, ActiveModuleCount: activeModuleCount, ActiveActivityCount: activeActivityCount } }
            } else if (popupValues.Type == "isUnSuspend") {
                refreshData()
                activeModuleCount = (courseModule?.CourseData?.ActiveModuleCount == undefined || courseModule?.CourseData?.ActiveModuleCount == null) ? 0 : ~~courseModule?.CourseData?.ActiveModuleCount + 1;
                activeActivityCount = (courseModule?.CourseData?.ActiveActivityCount == undefined || courseModule?.CourseData?.ActiveActivityCount == null) ? 0 : ~~courseModule?.CourseData?.ActiveActivityCount + moduleData1.current?.length
                variables = { input: { PK: courseModule?.CourseData?.PK, SK: courseModule?.CourseData?.SK, ActiveModuleCount: activeModuleCount, ActiveActivityCount: activeActivityCount } }
            }

            await AppsyncDBconnection(updateXlmsCourseManagementInfo, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)

            if (popupValues.Type == "isUnSuspend" || popupValues.Type == "isSuspend") {
                moduleDataResponse = await AppsyncDBconnection(getXlmsCourseModule, { PK: popupValues.PK, SK: popupValues.SK }, props?.user?.signInUserSession?.accessToken?.jwtToken);
                moduleDatas.current = moduleDataResponse?.res?.getXlmsCourseModule
                moduleBatchListResponse = await AppsyncDBconnection(listXlmsCourseBatch, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + router.query["CourseID"], SK: "COURSEBATCH#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
                moduleActivityListResponse = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEID#" + router.query["CourseID"] + "#MODULEID#" + moduleDatas.current?.ModuleID + "#ACTIVITYTYPE#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
                moduleBatchListResponse?.res?.listXlmsCourseBatch?.items.map((getItem) => {
                    listBatch.push(getItem.BatchID)
                })
                moduleActivityListResponse?.res?.listXlmsCourseModule?.items.map((getItem) => {
                    listActivity.push('{"ActivityID": "' + getItem?.ActivityID + '","ActivityName": "' + getItem?.ActivityName + '","ActivityType": "' + getItem?.ActivityType + '","ZoomActivityID": ' + getItem?.ZoomActivityID + ' }')
                })
                let mode = popupValues.Type == "isSuspend" ? "Delete" : "Add";
                jsonSaveData = '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","CourseID": "' + router.query["CourseID"] + '","ModuleID": "' + moduleDatas.current?.ModuleID + '","ModuleName": "' + moduleDatas.current?.ModuleName + '","Mode": "' + mode + '","BatchID": ' + JSON.stringify(listBatch) + ',  "ActivityData": [' + listActivity + ']}';
                let headers = { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken, defaultrole: props?.TenantInfo.UserGroup, groupmenuname: "CourseManagement", menuid: "300406", statemachinearn: stateMachineArn, }, body: jsonSaveData, };
                finalResult = await APIGatewayPostRequest(restrictionUrl, headers);
                finalResponse(finalResult.Status)
            }
            refreshData()
            const existActivity = await AppsyncDBconnection(
                listXlmsCourseModule,
                {
                    PK: "TENANT#" + props.TenantInfo.TenantID,
                    SK: "COURSEID#" + courseID + "#MODULEID#" + popupValues.SK.split("#")[1],
                    IsDeleted: false,
                }, props?.user?.signInUserSession?.accessToken?.jwtToken
            );

            const existingActivity =
                existActivity.res?.listXlmsCourseModule?.items;

            let moduleActivityList = [];
            existingActivity?.map((activity) => {
                moduleActivityList = ([...moduleActivityList, { ...activity, PK: activity.PK, SK: activity.SK, IsDeleted: isDelete, IsSuspend: isSus, ModifiedDate: new Date() }]);
            });
            if (moduleActivityList.length > 0) {
                await AppsyncDBconnection(createXlmsCourseModuleStatus, {
                    input: [...moduleActivityList],
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            }

            if (deletedStatus.Status == "Success") {
                refreshData();
            }

        } else {
            const Type = popupValues.SK.split("#")[5];
            const deletedStatus = await AppsyncDBconnection(
                updateXlmsCourseModule,
                { input: { PK: popupValues.PK, SK: popupValues.SK, IsDeleted: true, ModifiedDate: new Date() } }, props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            const moduleDataResponse = await AppsyncDBconnection(getXlmsCourseModule, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + courseID, SK: "COURSEMODULE#" + popupValues.SK.split("#")[3] }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const moduleSet = moduleDataResponse?.res?.getXlmsCourseModule
            if (popupValues.Type == "isDeleteActivity") {
                let activityCount = (courseModule?.CourseData?.ActivityCount == undefined || courseModule?.CourseData?.ActivityCount == null) ? 1 : ~~courseModule?.CourseData?.ActivityCount - 1;
                let activeActivityCount = (courseModule?.CourseData?.ActiveActivityCount == undefined || courseModule?.CourseData?.ActiveActivityCount == null) ? 1 : ~~courseModule?.CourseData?.ActiveActivityCount - 1
                await AppsyncDBconnection(updateXlmsCourseManagementInfo, { input: { PK: courseModule?.CourseData?.PK, SK: courseModule?.CourseData?.SK, ActivityCount: activityCount, ActiveActivityCount: activeActivityCount } }, props?.user?.signInUserSession?.accessToken?.jwtToken)

                let activityCounts = (moduleSet?.ActivityCount == undefined || moduleSet?.ActivityCount == null) ? 1 : ~~moduleSet?.ActivityCount - 1;
                let activeActivityCounts = (moduleSet?.ActiveActivityCount == undefined || moduleSet?.ActiveActivityCount == null) ? 1 : ~~moduleSet?.ActiveActivityCount - 1
                await AppsyncDBconnection(updateXlmsCourseModule, { input: { PK: moduleSet?.PK, SK: moduleSet?.SK, ActivityCount: activityCounts, ActiveActivityCount: activeActivityCounts } }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            }

            moduleActivityDataResponse = await AppsyncDBconnection(getXlmsCourseModule, { PK: popupValues.PK, SK: popupValues.SK }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            moduleDatas.current = moduleActivityDataResponse?.res?.getXlmsCourseModule
            moduleBatchListResponse = await AppsyncDBconnection(listXlmsCourseBatch, { PK: "TENANT#" + props.TenantInfo.TenantID + "#COURSEINFO#" + router.query["CourseID"], SK: "COURSEBATCH#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
            moduleBatchListResponse?.res?.listXlmsCourseBatch?.items.map((getItem) => {
                listBatch.push(getItem.BatchID)
            })

            if (Type != "Zoom") {
                jsonSaveData = '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","CourseID": "' + router.query["CourseID"] + '","ModuleID": "' + moduleDatas.current?.ModuleID + '","ModuleName": "' + moduleDatas.current?.ModuleName + '","Mode": "Delete","BatchID": ' + JSON.stringify(listBatch) + ',  "ActivityData": [{"ActivityID": "' + moduleDatas.current?.ActivityID + '","ActivityName": "' + moduleDatas.current?.ActivityName + '","ActivityType": "' + moduleDatas.current?.ActivityType + '","ZoomActivityID": null }]}';
                let headers = { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken, defaultrole: props?.TenantInfo.UserGroup, groupmenuname: "CourseManagement", menuid: "300406", statemachinearn: stateMachineArn, }, body: jsonSaveData, };
                finalResult = await APIGatewayPostRequest(restrictionUrl, headers);
                finalResponse(finalResult.Status)
            }

            if (Type == "Zoom") {
                const moduleActivityList = [];
                const activity = await AppsyncDBconnection(
                    listXlmsCourseModule,
                    {
                        PK: "TENANT#" + props.TenantInfo.TenantID,
                        SK: "COURSEID#" + courseID + "#MODULEID#" + popupValues.SK.split("#")[3],
                        IsDeleted: false,
                    }, props?.user?.signInUserSession?.accessToken?.jwtToken
                );

                const existingActivity = activity.res?.listXlmsCourseModule?.items;
                const zoomRelated = existingActivity.filter((i) => i.ZoomActivityID == popupValues.SK.split("#")[7]);
                jsonSaveData = '{' + '"TenantID": "' + props?.TenantInfo.TenantID + '","CourseID": "' + router.query["CourseID"] + '","ModuleID": "' + moduleDatas.current?.ModuleID + '","ModuleName": "' + moduleDatas.current?.ModuleName + '","Mode": "Delete","BatchID": ' + JSON.stringify(listBatch) + ',  "ActivityData": [{"ActivityID": "' + moduleDatas.current?.ActivityID + '","ActivityName": "' + moduleDatas.current?.ActivityName + '","ActivityType": "' + moduleDatas.current?.ActivityType + '","ZoomActivityID": "' + popupValues.SK.split("#")[7] + '" }]}';
                let headers = { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken, defaultrole: props?.TenantInfo.UserGroup, groupmenuname: "CourseManagement", menuid: "300406", statemachinearn: stateMachineArn, }, body: jsonSaveData, };
                finalResult = await APIGatewayPostRequest(restrictionUrl, headers);
                finalResponse(finalResult.Status)
                zoomRelated.map((items) => {
                    moduleActivityList.push({ PK: items.PK, SK: items.SK });
                });
                moduleActivityList.map(async (getItem) => {
                    await AppsyncDBconnection(
                        updateXlmsCourseModule,
                        { input: { PK: getItem.PK, SK: getItem.SK, IsDeleted: true, ModifiedDate: new Date() } }, props?.user?.signInUserSession?.accessToken?.jwtToken
                    );
                });

                //Delete Zoom meeting 
                let EditData = await AppsyncDBconnection(getXlmsCourseModule, { PK: popupValues.PK, SK: popupValues.SK }, props.user.signInUserSession.accessToken.jwtToken);
                EditData = EditData.res?.getXlmsCourseModule;

                const meetingDetails = {
                    topic: "Deleted",
                    type: 2,
                    timezone: "UTC",
                    agenda: "Zoom Test"
                };
                let groupMenuName = "CourseManagement";
                let menuId = "300509";
                const zoomHeader = { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, menuid: menuId, groupmenuname: groupMenuName, defaultrole: props.TenantInfo.UserGroup, };
                let ZoomResponse = await APIGatewayGetRequest(process.env.APIGATEWAY_ZOOM_TOKEN, { method: 'GET', headers: zoomHeader });
                const temp = await ZoomResponse?.res.text();
                createMeeting({ token: JSON.parse(temp)?.access_token, meetingDetails: meetingDetails, meetingID: EditData?.MeetingID, mode: "delete" })

            }
            if (deletedStatus.Status == "Success") {
                if (popupValues.SK.split("#")?.[3] != undefined) {
                    SetModuleID((temp) => {
                        let bool = false;
                        if (temp?.[popupValues.SK.split("#")[3]] != undefined) {
                            bool = temp?.[popupValues.SK.split("#")[3]];
                        }
                        return { ...temp, [popupValues.SK.split("#")[3]]: !bool };
                    });
                    callData(popupValues.SK.split("#")[1], popupValues.SK.split("#")[3]);
                }
                refreshData();
            }
            else {
                return;
            }
        }

        setSubmit(false)
        refreshData();
        resetPopUp();
    }
    const actionRestriction = useCallback((getItem) => {
        const actionList = [{
            id: 3,
            Color: "text-yellow-600",
            Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
            name: "Edit Activity",
            action: () => router.push(`ModuleInfo?Mode=ModuleEdit&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}&CourseID=${getItem.CourseID}&ModuleID=${getItem.ModuleID}&ModuleName=${getItem.ModuleName}`)
        },
        {
            id: 4,
            Color: "text-yellow-600",
            Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
            name: "Delete Activity",
            action: () => popUp("isDeleteActivity", getItem.PK, getItem.SK, "Are you sure to Delete the Activity?"),
        }];

        if (getItem.ActivityType == "Quiz") {
            actionList.push(
                {
                    id: 5,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-plane-circle-xmark text-red-600 bg-red-100 w-6",
                    name: "Offline Quiz Grade",
                    action: () => router.push(`CourseOfflineQuiz?ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}&Mode=ModuleDirect&CourseID=${getItem.CourseID}&ModuleID=${getItem.ModuleID}`)
                },
                {
                    id: 6,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-plane-circle-xmark text-red-600 bg-red-100 w-6",
                    name: "Quiz Response",
                    action: () => router.push(`CourseQuizResponse?ActivityID=${getItem.ActivityID}&Mode=ModuleDirect&CourseID=${getItem.CourseID}&ModuleID=${getItem.ModuleID}`)
                }
            );
        }
        else if (getItem.ActivityType == "Discussion") {
            actionList.push(
                {
                    id: 5,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Topic List",
                    action: () => router.push(`/ActivityManagement/UserConsume?Mode=Start&ActivityID=${getItem.ActivityID}&CourseID=${getItem.CourseID}&ModuleID=${getItem.ModuleID}&CourseName=${getItem.CourseName}&ActivityName=Discussion`)
                },);

        } else if (getItem.ActivityType == "Zoom") {
            actionList.push(
                {
                    id: 5,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                    name: "Meeting Preview",
                    action: () =>
                        router.push(`/CourseManagement/CourseZoomAdminView?CourseID=${getItem.CourseID}&ModuleID=${getItem.ModuleID}&ActivityID=${getItem.ActivityID}&ActivityType=${getItem.ActivityType}`),
                },
            );
        }
        else if (getItem.ActivityType == "Assignment") {
            actionList.push(
                {
                    id: 5,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                    name: "Admin Page",
                    action: () =>
                        router.push(`/CourseManagement/AssignmentAdminPage?CourseID=${getItem?.CourseID}&ActivityID=${getItem?.ActivityID}&ModuleID=${getItem.ModuleID}`),
                });

        }
        return actionList;
    }, [popUp, router]);

    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData && viewData?.map((getItem, index) => {
            !getItem?.IsDeleted
                ? rowGrid.push({
                    PK: (
                        <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
                    ),
                    SK: (
                        <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
                    ),
                    ActivityName: (
                        <NVLlabel id={"txtName" + (index + 1)} text={getItem.ActivityName}></NVLlabel>
                    ),
                    Date: (
                        <NVLlabel id={"txtName" + (index + 1)} text={(new Date(getItem.CreatedDate)).toLocaleDateString()}></NVLlabel>
                    ),
                    IsSuspend: (
                        <>
                            <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                                <div
                                    className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"
                                        }	`}
                                ></div>
                                <NVLlabel
                                    className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"
                                        } my-auto ml-2	`}
                                    text={!getItem.IsSuspend ? "Active" : "Inactive"}
                                ></NVLlabel>
                            </div>
                        </>
                    ),
                    ActivityType: (
                        <NVLlabel id={"txtActivitycategory" + (index + 1)} text={getItem.ActivityType == "ScormPackage" ? "SCORM Package" : getItem.ActivityType}></NVLlabel>
                    ),
                    Action: (
                        <NVLRapidModal
                            id={"RapidModal" + (index + 1)}
                            ActionList={actionRestriction(getItem)}
                        ></NVLRapidModal>
                    ),
                })
                : "";
        });
        return rowGrid;
    }, [actionRestriction]);

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };
    const [moduleID, SetModuleID] = useState({});
    const headerColumn = useMemo(() => {
        return [
            { HeaderName: "Activity Name", Columnvalue: "ActivityName", HeaderCss: "w-5/12 " },
            { HeaderName: "Activity Type", Columnvalue: "ActivityType", HeaderCss: "w-5/12" },
            { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-1/12 " },
        ];
    }, []);

    const [rowGridData, setRowGridData] = useState({});
    const callData = useCallback(async (CourseID, ModuleID) => {
        const variable = { PK: `TENANT#${props.TenantInfo.TenantID}`, SK: `COURSEID#${CourseID}#MODULEID#${ModuleID}`, IsDeleted: false };
        const response = await AppsyncDBconnection(listXlmsCourseModule, variable, props.user.signInUserSession.accessToken.jwtToken);
        setRowGridData((data) => {
            const temp = gridDataBind(response.res.listXlmsCourseModule?.items);
            return { ...data, [ModuleID]: temp };
        });

    }, [gridDataBind, props.TenantInfo, props.user.signInUserSession.accessToken.jwtToken]);
    const getActivityName = useCallback((ModuleID, ModuleName) => {
        const activityData = [];
        if (courseModule?.ActivityData != undefined || courseModule?.ActivityData?.length > 0) {
            JSON?.parse(courseModule?.ActivityData?.ActivityType)?.map((activity, index) => {
                if (activity != "Survey") {
                    activityData.push(
                        {
                            id: index,
                            Icon: "fa fa-plus",
                            Color: "text-primary",
                            name: activity,
                            MenuCss: "text-xs",
                            action: () => {
                                router.push(`ModuleInfo?Mode=ModuleDirect&ActivityType=${activity}&CourseID=${courseID}&ModuleID=${ModuleID}&ModuleName=${ModuleName}`);
                            }
                        });
                }

            });
        }
        return activityData;
    }, [courseModule, courseID, router]);
    const [isRefreshing, setIsRefreshing] = useState(true)
    const refreshGrid = async () => {
        setIsRefreshing((count) => {
            return count + 1;
        });
        router.push(router.asPath);
    };
    const ModuleListData = useCallback(() => {
        if (courseModule?.ModuleList?.length > 0) {
            return (
                <>
                    {courseModule?.ModuleList?.map((data, index) => {
                        if (moduleID?.[data.ModuleID]) {
                            let Temp;
                            if (data.IsSuspend) {
                                Temp = <><div className="text-xs p-2">Module is disabled</div></>;
                            }
                            else if (rowGridData?.[data.ModuleID] != undefined && rowGridData?.[data.ModuleID].length > 0) {
                                Temp = <NVLGridTable refershPage={isRefreshing} Header={"NoHeader"} id="tblModuleList" HeaderColumn={headerColumn} RowGridDataPass={{ RowGrid: rowGridData?.[data.ModuleID] != undefined ? rowGridData?.[data.ModuleID] : [] }} />;
                            }
                            else if (!(rowGridData?.[data.ModuleID] != undefined && rowGridData?.[data.ModuleID].length > 0)) {
                                Temp = <><div className="text-xs p-2">No Activites Found</div></>;
                            }
                            return (
                                <div key={index} className={"w-full border border-b-2 justify-between m-auto p-2"}>
                                    <div className={"w-full border border-b-2 flex justify-between m-auto p-2"}>
                                        <div onClick={() => {
                                            SetModuleID((temp) => {
                                                let bool = false;
                                                if (temp?.[data.ModuleID] != undefined) {
                                                    bool = temp?.[data.ModuleID];
                                                }
                                                return { ...temp, [data.ModuleID]: !bool };
                                            });
                                        }} className="bg-white text-lg flex-end font-bold"><NVLlabel text={data.ModuleName} className={"w-full  m-auto p-2 font-bold"} />
                                        </div>
                                        <div className={`${data.IsSuspend || (courseModule?.CourseData?.DataProcessing == 1) ? "pointer-events-none" : ""}`}>
                                            <div className="-translate-x-16">
                                                <NVLRapidModal id={"RapidModal" + (index + 1)} CustomIcon
                                                    ActionList={getActivityName(data.ModuleID, data.ModuleName)}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                    {Temp}
                                </div>
                            );
                        }
                        return (
                            <div key={index} className={"w-full border border-b-2 flex justify-between m-auto p-2"}>
                                <div onClick={() => {
                                    SetModuleID((temp) => {
                                        let bool = false;
                                        if (temp?.[data.ModuleID] != undefined) {
                                            bool = temp?.[data.ModuleID];
                                        }
                                        return { ...temp, [data.ModuleID]: !bool };
                                    });
                                    callData(data.CourseID, data.ModuleID);
                                }} className={(courseModule?.CourseData?.DataProcessing == 1) ? "pointer-events-none" : "bg-white text-lg flex-end font-bold w-1/2"}><NVLlabel text={data.ModuleName} className={"w-full flex justify-between m-auto p-2 font-bold "} /></div>
                                <div className={`${data.IsSuspend || (courseModule?.CourseData?.DataProcessing == 1) ? "pointer-events-none" : ""}`}>
                                    <NVLRapidModal id={"RapidModal" + (index + 1)} CustomIcon
                                        ActionList={getActivityName(data.ModuleID, data.ModuleName)}
                                    />
                                </div>
                                <div className={(courseModule?.CourseData?.DataProcessing == 1) ? 'z-10 justify-items-end pointer-events-none' : 'z-10 justify-items-end'}>
                                    <NVLRapidModal
                                        id={"RapidModal" + (index + 1)}
                                        ActionList={data.IsSuspend ? [
                                            {
                                                id: 6,
                                                Color: "text-yellow-600",
                                                Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                                                name: "Show Module",
                                                MenuCss: "text-xs",
                                                action: () => popUp("isUnSuspend", data.PK, data.SK, "Are you sure to Show the Module?"),
                                            },
                                            {
                                                id: 7,
                                                Color: "text-yellow-600",
                                                Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                                                name: "Delete Module",
                                                MenuCss: "text-xs",
                                                action: () => popUp("isDelete", data.PK, data.SK, "Are you sure to Delete the Module?"),
                                            },
                                        ] : [
                                            {
                                                id: 1,
                                                Color: "text-green-700",
                                                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                                                name: "Edit Module",
                                                MenuCss: "text-xs",
                                                action: () =>
                                                    router.push(`/CourseManagement/AddModule?Mode=Edit&CourseID=${data.CourseID}&ModuleID=${data.ModuleID}`)
                                            },
                                            {
                                                id: 2,
                                                Color: "text-yellow-600",
                                                Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                                                name: "Hide Module",
                                                MenuCss: "text-xs",
                                                action: () => popUp("isSuspend", data.PK, data.SK, "Are you sure to Hide the Module?"),
                                            },
                                        ]}
                                    ></NVLRapidModal>
                                </div>
                            </div>
                        );
                    })
                    }
                </>
            );
        }
        else {
            return (
                <div className="pt-2">
                    <NVLNoImage id="NoRecord" className="w-96 h-96" alignItem={"center"} />
                </div>
            )
        }
    }, [courseModule?.ModuleList, courseModule?.CourseData?.DataProcessing, moduleID, getActivityName, rowGridData, isRefreshing, headerColumn, callData, popUp, router]);


    // Bread Crumbs
    const pageRoutes = [
        { path: "/CourseManagement/CourseList", breadcrumb: "Course Management" },
        { path: "", breadcrumb: "Manage Course" }
    ];
    return (
        <>
            <Container title="ModulesList" loader={courseModule == undefined} PageRoutes={pageRoutes} >
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalInfo={modalValues.ModalInfo} />

                <NVLHeader
                    refreshEvent={!(courseModule?.CourseData?.DataProcessing == undefined || courseModule?.CourseData?.DataProcessing == 0) && refreshGrid}
                    refreshIcon={!(courseModule?.CourseData?.DataProcessing == undefined || courseModule?.CourseData?.DataProcessing == 0) && true}

                    className={(courseModule?.CourseData?.DataProcessing == 1
                        &&
                        (courseModule?.CourseData?.DataProcessing == undefined || courseModule?.CourseData?.DataProcessing == 0)
                    ) ? "pointer-events-none" : ""}

                    className5={(courseModule?.CourseData?.DataProcessing == 1
                    ) ? "Disabled nvl-button-gray" : false}

                    TabRouting={props?.GeneralRoleData?.AllowNewTab} onClick1={refreshData} RedirectAction4={() => refreshData()} ButtonID5="btnAddModule" LinkName5="Add Module"
                    href5={`/CourseManagement/AddModule?Mode=Create&CourseID=${courseID}`} RedirectAction5={(e) => headerHandler(e, `/CourseManagement/AddModule?Mode=Create&CourseID=${courseID}`)} IsNestedHeader />
                {!(courseModule?.CourseData?.DataProcessing == undefined || courseModule?.CourseData?.DataProcessing == 0) &&
                    <div className="px-3 pb-1">
                        <NVLWarning Header={"In Processing!..."} className={"!p-1 text-xs"}
                            Content={"Action is in progress, it will take some time"}></NVLWarning>
                    </div>
                }
                <div className="px-3 pt-2 "><ModuleListData /></div>
                <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={() => resetPopUp()} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} loader={submit} Content={popupValues.Content} ></NVLModalPopup>
            </Container>
        </>
    );
}


export default ModulesList;

