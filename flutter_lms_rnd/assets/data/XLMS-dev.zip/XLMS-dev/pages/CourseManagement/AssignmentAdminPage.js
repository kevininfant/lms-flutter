
import AssignmentAdminPage from "@Pages/ActivityManagement/AssignmentAdminPage";
export default function CourseAssignmentAdminPage(props) {
    return (
        <>
            <AssignmentAdminPage {...props} />
        </>)
}