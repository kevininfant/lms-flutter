import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { BatchPut } from "BatchPutItem/BatchPut";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";
import { createXlmsBatchCourseManagementInfo, createXlmsCourseManagementShardingInfo, updateXlmsCourseManagementInfo } from "src/graphql/mutations";
import { listXlmsCourseManagementInfo, listXlmsCourseModule } from "src/graphql/queries";

export default function CourseList(props) {
    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("");

    const headerColumn = [{ HeaderName: "Course Name", Columnvalue: "CourseName", HeaderCss: "w-1/6", }, { HeaderName: "Course Category", Columnvalue: "CategoryName", HeaderCss: "w-1/6", }, { HeaderName: "Created Date", Columnvalue: "CreatedDate", HeaderCss: "w-1/6 whitespace-nowrap" }, { HeaderName: "Course Description", Columnvalue: "CourseDescription", HeaderCss: "w-1/6", }, { HeaderName: "Course Status", Columnvalue: "IsSuspend", HeaderCss: "w-1/6", }, { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-1/6" },];

    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    const refreshGrid = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    const resetPopUp = useCallback(() => {
        setPopupValues({ item: {}, Content: "", Type: "" });
        refreshGrid();
        setSearch("");

    }, []);

    const popUp = useCallback((type, item, Content) => {
        setPopupValues({ item: item, Content: Content, Type: type });
    }, []);


    async function updateField(e) {
        e.preventDefault();
        var isSus = false;
        var isDelete = false;
        if (popupValues.Type == "isSuspend") {
            isSus = true;
        } else if (popupValues.Type == "isDelete") {
            isSus = true;
            isDelete = true;
        }
        if (popupValues.item.Shard != undefined) {
            BatchPut({ Values: popupValues.item, Shard: popupValues.item.Shard, query: createXlmsCourseManagementShardingInfo, UpdateData: { IsSuspend: isSus, IsDeleted: isDelete, ModifiedDate: new Date() }, user: props.user.signInUserSession.accessToken.jwtToken });
        }
        const final = await AppsyncDBconnection(updateXlmsCourseManagementInfo, { input: { PK: popupValues?.item?.PK, SK: popupValues?.item?.SK, IsSuspend: isSus, IsDeleted: isDelete, LastModifiedBy: props.user.username, LastModifiedDate: new Date(), }, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        if (final.Status == "Success") {
            refreshGrid();
        }
        resetPopUp();
    }

    const actionRestriction = useCallback((getItem) => {

        const actionList = [];
        if (getItem?.DataProcessing != 1) {
            if (props.RoleData?.ShowCourse && getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 1,
                        Color: "text-yellow-600",
                        Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                        name: "Show Course",
                        action: () =>
                            popUp("", getItem, "Are you sure to Show the course?"),
                    },
                );
            }
            if (props.RoleData?.DeleteCourse && getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 2,
                        Color: "text-rose-700",
                        Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                        name: "Delete Course",
                        action: () =>
                            popUp("isDelete", getItem, "Are you sure to Delete the Course?"),
                    }
                );
            }
            if (props.RoleData?.ManageCourse && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 3,
                        Color: "text-green-700",
                        Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                        name: "Manage Course",
                        action: () =>
                            router.push(
                                `/CourseManagement/ModulesList?CourseID=${getItem.CourseID}`
                            )
                    },

                );
            }
            if (props.RoleData?.CourseEditSetting && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 4,
                        Color: "text-green-700",
                        Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                        name: "Edit Settings",
                        action: () =>
                            router.push(
                                `/CourseManagement/CourseEditSettings?&Mode=Edit&CourseID=${getItem.CourseID}`

                            ),
                    },

                );
            }
            if (props.RoleData?.CourseEnrollUser && !getItem.IsSuspend && !getItem.IsManualDisable && (getItem.EndDateTime == '' || new Date(getItem.EndDateTime) >= new Date())) {
                actionList.push(
                    {
                        id: 5,
                        Color: "text-blue-700",
                        Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6 pointer-events-none ",
                        name: "Enroll User",
                        action: () =>
                            router.push(`/CourseManagement/CourseEnrollUser?Mode=CourseList&CourseID=${getItem.CourseID}&CourseName=${getItem.CourseName}`),
                    },
                );
            }

            if (props.RoleData?.CourseEnrollUser && !getItem.IsSuspend && !getItem.IsManualDisable) {
                actionList.push({
                    id: 6,
                    Color: "text-blue-700",
                    Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                    name: "Enrollment List",
                    action: () => router.push(`/CourseManagement/CourseDismissUser?Mode=Edit&CourseID=${getItem.CourseID}&CourseName=${getItem.CourseName}`
                    ),
                },
                );
            }
            if (props.RoleData?.EnrolementSetting && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 6,
                        Color: "text-blue-700",
                        Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                        name: "Enrollment Settings",
                        action: () =>
                            router.push(
                                `/CourseManagement/EnrollmentSettingsList?CourseID=${getItem.CourseID}`
                            ),
                    },
                );
            }
            if (props.RoleData?.CreateBatch && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 7,
                        Color: "text-blue-700",
                        Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                        name: "Batch List",
                        action: () =>
                            router.push(`/CourseManagement/BatchList?CourseID=${getItem.CourseID}&CourseName=${getItem.CourseName}`),
                    },
                );
            }
            if (props.RoleData?.AddCourseCertificate && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 8,
                        Color: "text-blue-700",
                        Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                        name: "Add Certificate",
                        action: () =>
                            router.push(
                                `/ActivityManagement/Certificate?Mode=CourseDirect&CourseID=${getItem.CourseID}`
                            ),
                    },
                );
            }
            if (props.RoleData?.AddCourseBadge && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 9,
                        Color: "text-blue-700",
                        Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                        name: "Add Badge",
                        action: () =>
                            router.push(
                                `/ActivityManagement/AddBadge?Mode=CourseDirect&CourseID=${getItem.CourseID}`
                            ),
                    },
                );
            }
            if (props.RoleData?.SendNotificationCourse && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 10,
                        Color: "text-blue-700",
                        Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                        name: "Send Notification",
                        action: () =>
                            router.push(
                                `/CourseManagement/CourseNotification?Mode=CourseDirect&CourseID=${getItem.CourseID}`
                            ),
                    },
                );
            }
            if (props.RoleData?.HideCourse && !getItem.IsSuspend) {
                actionList.push(
                    {
                        id: 11,
                        Color: "text-yellow-600",
                        Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                        name: "Hide Course",
                        action: () =>
                            popUp("isSuspend", getItem, "Are you sure to Hide the course?"),
                    }
                );
            }
        }
        return actionList;
    }, [props.RoleData?.ShowCourse, props.RoleData?.DeleteCourse, props.RoleData?.ManageCourse, props.RoleData?.CourseEditSetting, props.RoleData?.CourseEnrollUser, props.RoleData?.EnrolementSetting, props.RoleData?.CreateBatch, props.RoleData?.AddCourseCertificate, props.RoleData?.AddCourseBadge, props.RoleData?.SendNotificationCourse, props.RoleData?.HideCourse, popUp, router]);
    const gridDataBind = useCallback(async (viewData) => {
        const rowGrid = [];
        let temp = [];
        for (let i = 0; i < viewData?.length; i++) {
            if (viewData[i]?.ModuleCount == undefined || viewData[i]?.ActiveActivityCount == 0) {
                const moduleDataResponse = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + viewData[i]?.CourseID, SK: "COURSEMODULE#", IsDeleted: false, IsSuspend: false }, props.user?.signInUserSession?.accessToken?.jwtToken);
                const moduleSuspendDataResponse = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + viewData[i]?.CourseID, SK: "COURSEMODULE#", IsDeleted: false, IsSuspend: true }, props.user?.signInUserSession?.accessToken?.jwtToken);
                const variable = { PK: `TENANT#${props.TenantInfo.TenantID}`, SK: `COURSEID#${viewData[i]?.CourseID}#MODULEID#`, IsDeleted: false };
                const ActivityDataResponse = await AppsyncDBconnection(listXlmsCourseModule, variable, props.user?.signInUserSession?.accessToken?.jwtToken);
                let ActivityCount = 0, ActiveActivityCount = 0;
                ActivityDataResponse?.res?.listXlmsCourseModule?.items?.map((data) => { ActivityCount++; if (!data.IsSuspend) { ActiveActivityCount++; } })
                let ActiveModule = moduleDataResponse?.res?.listXlmsCourseModule?.items?.length != undefined ? moduleDataResponse?.res?.listXlmsCourseModule?.items?.length : 0, InactiveModule = moduleSuspendDataResponse?.res?.listXlmsCourseModule?.items?.length != undefined ? moduleSuspendDataResponse?.res?.listXlmsCourseModule?.items?.length : 0;
                const removeEmpty = (obj) => {
                    let tempjson = {};
                    Object.keys(obj).forEach((k) => {
                        if (obj?.[k] != undefined) {
                            tempjson = { ...tempjson, [k]: obj?.[k] }
                        }
                    });
                    return tempjson;
                };
                temp = [...temp, { ...removeEmpty(viewData[i]), ModuleCount: ActiveModule + InactiveModule, ActivityCount: ActivityCount, ActiveModuleCount: ActiveModule, ActiveActivityCount: ActiveActivityCount }]
            }
        }
        viewData &&
            viewData.map((getItem, index) => {
                if (!getItem.IsDeleted) {
                    var regex = /(<([^>]+)>)/gi, body = getItem?.CourseDescription, result = body?.replace(regex, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " "), ActionList = [];
                    ActionList = actionRestriction(getItem);
                    rowGrid.push({
                        PK: (
                            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
                        ),
                        SK: (
                            <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
                        ),
                        CourseId: (
                            <NVLlabel id={"lblCourseId" + (index + 1)} name="CourseId" text={getItem.SK} />
                        ),
                        CourseName: (
                            <NVLLink id={"txtCourseName" + (index + 1)} text={getItem.CourseName} className="break-all" onClick={() => (getItem?.DataProcessing != 1) ? router.push(`/CourseManagement/ModulesList?CourseID=${getItem.CourseID}`) : ""}>
                                {" "}
                            </NVLLink>
                        ),
                        CategoryName: (
                            <NVLlabel id={"txtCoursecategory" + (index + 1)} text={getItem.CategoryName} className="whitespace-nowrap"></NVLlabel>
                        ),

                        CreatedDate: (
                            <NVLlabel id={"txtName" + (index + 1)} text={new Date(getItem.CreatedDate).toDateString().substring(4)}></NVLlabel>
                        ),

                        CourseDescription: (
                            <NVLlabel title={result} text={result}></NVLlabel>
                        ),

                        IsSuspend: (
                            <>
                                <div className="flex m-auto w-full" title={getItem?.DataProcessing != 1 ? (getItem.IsSuspend ? "Inactive" : "Active") : "InProgress"}>
                                    <div className={`rounded-full my-auto h-3 w-3 ${getItem?.DataProcessing != 1 ? (getItem.IsSuspend ? "bg-red-500" : "bg-green-600") : "bg-red-500"}`}></div>
                                    <NVLlabel className={`${getItem?.DataProcessing != 1 ? (getItem.IsSuspend ? "text-red-500" : "text-green-600 pointe") : "text-red-500"} my-auto ml-2`} text={getItem?.DataProcessing != 1 ? (!getItem.IsSuspend ? "Active" : "Inactive") : "InProgress"} ></NVLlabel>
                                </div>
                            </>
                        ),
                        Action: (
                            <NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={ActionList} index={(index + 1) > 10 ? (index + 1) % 10 : index + 1}></NVLRapidModal>
                        ),
                    });
                }
            });
        if (temp?.length > 0) {
            AppsyncDBconnection(createXlmsBatchCourseManagementInfo, { input: temp }, props.user?.signInUserSession?.accessToken?.jwtToken)
        }
        return rowGrid;
    }, [actionRestriction, props?.TenantInfo?.TenantID, props.user?.signInUserSession?.accessToken?.jwtToken, router]);

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };

    const variable = useMemo(() => ({ PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSEINFO#", IsDeleted: false, }), [props?.TenantInfo?.TenantID]);

    const pageRoutes = useMemo(() => {
        return [{ path: "", breadcrumb: "Course Management" }];
    }, []);

    return (
        <>
            <Container title="Course Management">
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <NVLHeader
                    IsSearch={props.RoleData?.SeTenanthCourse ? true : false}
                    TabRouting={props?.GeneralRoleData?.AllowNewTab}
                    ButtonID1="btnCreateActivity"
                    onClick1={refreshGrid}
                    LinkName4="Manage Course/Category"
                    LinkName2={"+ Create Course"}
                    className2={props.RoleData?.CreateCourse ? (props.TabRouting == true ? " " : "nvl-button-success") : "hidden"}
                    className4={props.RoleData?.ManageCourseOrCategory ? (props.TabRouting == true ? " " : "nvl-button-success") : "hidden"}
                    href2="/CourseManagement/CourseInfo?Mode=Create&0"
                    RedirectAction2={(e) =>
                        headerHandler(
                            e,
                            "/CourseManagement/CourseInfo?Mode=Create&0"
                        )
                    }
                    href4="/CourseManagement/CategoryList"
                    RedirectAction4={(e) =>
                        headerHandler(e, "/CourseManagement/CategoryList")
                    }
                    RedirectAction1={() => refreshGrid()}
                    placeholder={"Search"}
                    SearchonChange={(e) => searchBoxVal(e)}
                    IsNestedHeader
                />
                <NVLGridTable
                    refershPage={isRefreshing}
                    Search={search}
                    id="tblActivityList"
                    className="max-w-full"
                    HeaderColumn={headerColumn}
                    GridDataBind={gridDataBind}
                    query={listXlmsCourseManagementInfo}
                    querryName={"listXlmsCourseManagementInfo"}
                    variable={variable}
                    user={props?.user}
                />
                <div id="isModaldiv">
                    <NVLModalPopup
                        ButtonYestext="Yes"
                        SubmitClick={(e) => updateField(e)}
                        CancelClick={() => resetPopUp()}
                        ButtonNotext="No"
                        CloseIconEvent={() => resetPopUp()}
                        Content={popupValues.Content}
                    ></NVLModalPopup>
                </div>
            </Container>
        </>
    );
}