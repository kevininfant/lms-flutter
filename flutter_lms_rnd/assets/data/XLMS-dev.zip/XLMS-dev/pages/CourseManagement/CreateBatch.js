import { GetDateFormat } from "@components/Common/DateFormat";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLlabel from "@components/Controls/NVLlabel";
import { createXlmsCourseBatch, createXlmsCourseManagementShardingInfo, updateXlmsCourseBatch } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { Auth } from "aws-amplify";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsCourseBatch, getXlmsCourseManagementInfo, listXlmsCourseBatch, listXlmsCourseModule } from "src/graphql/queries";
import * as Yup from "yup";
import AddRestrictionSingle from "./AddRestrictionSingle";

function CreateBatch(props) {
    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const batchSingleData = useRef();

    useEffect(() => {
        const courseId = decodeURIComponent(String(router.query["CourseID"]));
        const mode = decodeURIComponent(String(router.query["Mode"]));
        const courseName = decodeURIComponent(String(router.query["CourseName"]));
        const courseMode = decodeURIComponent(String(router.query["CourseMode"]));
        let batchID = "", CurrentBatchData = {};
        const user = props?.user;
        const tenantId = user.attributes["custom:tenantid"];
        const authorizedToken = user?.signInUserSession?.accessToken?.jwtToken;
        try {
            batchID = decodeURIComponent(String(router.query["BatchID"]));
        }
        catch (e) { batchID = ""; }
        const dataSource = async () => {

            if (batchID != "") {
                const batchVariable = { PK: "TENANT#" + tenantId + "#COURSEINFO#" + courseId, SK: "COURSEBATCH#" + batchID };
                CurrentBatchData = (await AppsyncDBconnection(getXlmsCourseBatch, batchVariable, authorizedToken));
                CurrentBatchData = CurrentBatchData?.res?.getXlmsCourseBatch;
                batchSingleData.current = CurrentBatchData
            }
            const activityVariable = {
                PK: "TENANT#" + tenantId,
                SK: "COURSEID#" + courseId,
                IsDeleted: false
            };

            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, {
                PK: "TENANT#" + tenantId,
                SK: "COURSEINFO#" + courseId,

            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const batchData = await AppsyncDBconnection(listXlmsCourseBatch, {
                PK: "TENANT#" + tenantId + "#COURSEINFO#" + courseId,
                SK: "COURSEBATCH#",
            }, authorizedToken);

            let actList = (await AppsyncDBconnection(listXlmsCourseModule, activityVariable, authorizedToken));
            actList = actList.res?.listXlmsCourseModule?.items;
            if (actList?.length > 0) {
                actList = [...actList].sort((a, b) => a.ActivityID - b.ActivityID)
            }
            let moduleList = await AppsyncDBconnection(listXlmsCourseModule, { PK: `TENANT#${tenantId}#COURSEINFO#${courseId}`, SK: "COURSEMODULE#", IsDeleted: false }, authorizedToken);
            moduleList = moduleList?.res?.listXlmsCourseModule?.items;
            let ModulesListTemp = [];
            if (moduleList?.length > 0) {
                moduleList.map((data) => {
                    if (!data.IsSuspend) {
                        ModulesListTemp = [...ModulesListTemp, data.ModuleID];
                    }
                });
            }

            const temp = [];
            if (actList != undefined) {
                actList.map((item) => {
                    if (!item.IsDeleted && !item.IsSuspend && ModulesListTemp.includes(item.ModuleID))
                        temp.push(item);
                });
            }
            setCsrFetchedData((data) => {
                return {
                    ...data,
                    CourseID: courseId,
                    ModuleData: moduleList,
                    CourseName: courseName,
                    TenantID: tenantId,
                    CourseMode: courseMode,
                    mode: mode,
                    Coursedata: courseData.res?.getXlmsCourseManagementInfo,
                    BatchData: batchData.res?.listXlmsCourseBatch?.items,
                    ActList: temp,
                    CurrentBatchData: CurrentBatchData != undefined ? CurrentBatchData : {},
                    BatchID: batchID
                };
            });
        };
        dataSource();
        return (() => {
            setCsrFetchedData((data) => {
                return { ...data };
            });
        });
    }, [csrFetchedData.user, props?.user, router.query]);

    useEffect(() => {
        finalJson.current = ({ RS: JSON.parse(csrFetchedData?.CurrentBatchData?.Restriction != undefined ? csrFetchedData?.CurrentBatchData?.Restriction : "{}"), Variables: {} });
        setRestrictionLength(() => {
            if (csrFetchedData?.CurrentBatchData?.Restriction != undefined) {
                return Object.keys(JSON.parse(csrFetchedData?.CurrentBatchData?.Restriction != undefined ? csrFetchedData?.CurrentBatchData?.Restriction : "{}")).length;
            }
            else {
                return 1;
            }
        });
    }, [csrFetchedData?.CurrentBatchData?.Restriction]);

    const actList = useMemo(() => {
        let temp = [];
        csrFetchedData?.ModuleData?.map((getItem) => {
            csrFetchedData?.ActList?.map((data) => {
                if (data.ModuleID == getItem?.ModuleID) {
                    temp = [...temp, { name: data.ActivityName, actId: data.ActivityID, ModuleID: data.ModuleID, ModuleName: getItem?.ModuleName, ZoomActivityID: data.ZoomActivityID, ActivityType: data.ActivityType }];
                }
            });
        })

        return temp;
    }, [csrFetchedData?.ActList, csrFetchedData?.ModuleData]);

    const finalJson = useRef({ RS: JSON.parse(csrFetchedData?.CurrentBatchData?.Restriction != undefined ? csrFetchedData?.CurrentBatchData?.Restriction : "{}"), Variables: {} });

    const [data, getData] = useState(0);
    const [submit, setSubmit] = useState([]);

    const [message, setMessage] = useState("");
    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push(`/CourseManagement/BatchList?CourseID=${csrFetchedData?.CourseID}&CourseName=${csrFetchedData?.CourseName}`);
        },
    };
    const Chnage = useRef(false);
    const [restrictionLength, setRestrictionLength] = useState(() => {
        if (csrFetchedData?.CurrentBatchData?.Restriction != undefined) {
            return Object.keys(JSON.parse(csrFetchedData?.CurrentBatchData?.Restriction != undefined ? csrFetchedData?.CurrentBatchData?.Restriction : "{}")).length;
        }
        else {
            return 1;
        }
    });
    const [modalValues, setModalValues] = useState(initialModalState);

    const validationSchema = Yup.object().shape({
        txtBatchName: Yup.string()
            .required("Batch Name is required")
            .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Enter Valid Batch name")
            .max(100, "Maximum length exceeded 100")
            .nullable()
            .test("", "", (e, { createError }) => {
                if (csrFetchedData?.BatchID != "") {
                    return true;
                }
                if (csrFetchedData?.BatchData != undefined) {
                    const existingBatchName = Object.values(csrFetchedData?.BatchData).filter((data) => {
                        if (data.IsDeleted != true) {
                            return data.BatchName.toLowerCase() == e.toLowerCase();
                        }
                    }
                    );

                    if (existingBatchName?.[0]?.BatchName != undefined &&
                        e?.toLowerCase() != csrFetchedData?.BatchData?.BatchName?.toLowerCase()) {

                        return createError({ message: " * Batch name already exists" });
                    }
                }
                return true;
            }),
        txtstdate: Yup.date()
            .required("Start Date is required")
            .typeError("Start Date is required")
            .min(new Date(new Date().setDate(new Date().getDate() - 1)), "Batch can be created only for present and future date")
            .test("check", "Start Date should be between the course start and end date", (e) => {
                const courseStartDate = GetDateFormat(csrFetchedData?.Coursedata?.DateTime, "yyyy-mm-dd");
                const courseEndDate = GetDateFormat(csrFetchedData?.Coursedata?.EndDateTime, "yyyy-mm-dd");
                const batchStartDate = GetDateFormat(e, "yyyy-mm-dd");
                if (csrFetchedData?.Coursedata?.DateTime != undefined && csrFetchedData?.Coursedata?.DateTime != "") {
                    if (batchStartDate < courseStartDate || batchStartDate > courseEndDate) {
                        return false;
                    }
                }

                if (watch("txtEnddate") != undefined && watch("txtEnddate") != "" && e != "" && e != undefined && (watch("txtEnddate") != "NaN-NaN-NaN" && new Date(watch("txtEnddate")).toISOString() <= new Date(e).toISOString()) && errors?.txtEnddate == undefined) {
                    setError("txtEnddate", { message: "End Date must be greater than  Start Date" });
                }
                else if (watch("txtEnddate") != undefined && watch("txtEnddate") != "" && e != "" && e != undefined && (watch("txtEnddate") != "NaN-NaN-NaN" && new Date(watch("txtEnddate")).toISOString() > e.toISOString()) && errors?.txtEnddate != undefined) {
                    if (!(csrFetchedData?.Coursedata?.EndDateTime != undefined && new Date(csrFetchedData?.Coursedata?.EndDateTime) < new Date(watch("txtEnddate")))) {
                        clearErrors(["txtEnddate"])
                    }
                }
                return true;
            }).nullable(true),
        txtEnddate: Yup.date().when('txtstdate', (txtstdate, schema) => {
            if (txtstdate && txtstdate != "Invalid Date") {
                const dayAfter = new Date(txtstdate.getTime() + 86400000);
                return schema.min(dayAfter, 'End Date must be greater than  Start Date');
            }
            return schema;
        }).required("End Date is required").typeError("End Date is required").test("check", "End Date should be between the course start and end date", (e) => {
            if (csrFetchedData?.Coursedata?.EndDateTime != undefined && (new Date(csrFetchedData?.Coursedata?.EndDateTime) < new Date(new Date(e)))) {
                return false;
            }
            return true;
        }),
    });

    useEffect(() => {
        if (message != "") {
            message?.on("text-change", () => {
                if (getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {
                    setValue("txtBatchDescription", "Empty", { shouldValidate: true });
                } else {
                    setValue("txtBatchDescription", "NotEmpty", { shouldValidate: true });
                }
                setValue("txtBatchDescription", "NotEmpty", { shouldValidate: true });
            });
        }
        const dateCoversion = (date) => { const dateTime = new Date(date); const dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + (dateTime.getDate() < 10 ? ("0" + dateTime.getDate()) : dateTime.getDate()); return dateTimeString; };
        if (csrFetchedData?.BatchID != "" && csrFetchedData?.BatchID != undefined) {
            setValue("txtBatchName", csrFetchedData?.CurrentBatchData.BatchName);
            setValue("txtstdate", dateCoversion(csrFetchedData?.CurrentBatchData.StartDate));
            setValue("txtEnddate", dateCoversion((csrFetchedData?.CurrentBatchData.EndDate == null || csrFetchedData?.CurrentBatchData.EndDate == "" || csrFetchedData?.CurrentBatchData.EndDate == undefined) ? "" : csrFetchedData?.CurrentBatchData.EndDate));
            if (message != "") {
                setHTMLContents(csrFetchedData?.CurrentBatchData.BatchDescription, message);
                message?.history?.clear();
                setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
            }
        }
    }, [message, csrFetchedData?.BatchID, csrFetchedData?.CurrentBatchData, csrFetchedData?.CurrentBatchData?.Restriction, setValue]);

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, setError, clearErrors, watch, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    const finalResponse = useCallback((finalStatus) => {
        rest.current = true
        if (finalStatus != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Danger", ModalBottomMessage: finalStatus, });
            ModalOpen();
            return;
        } else {
            setValue("submit", "");
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    router.push(`/CourseManagement/BatchList?CourseID=${csrFetchedData?.CourseID}&CourseName=${csrFetchedData?.CourseName}`);
                },
            });
            ModalOpen();
        }
    }, [csrFetchedData?.CourseID, csrFetchedData?.CourseName, router, setValue]);

    useEffect(() => {
        if (csrFetchedData?.open == 1) {
            reset();
            if (message != "") {
                setHTMLContents("", message);
            }
        }
    }, [message, csrFetchedData?.open, reset]);

    const submitHandler = async (data) => {
        setValue("submit", true, { shouldValidate: true });
        getData((temp) => { return temp + 1; });
        const tenantId = csrFetchedData?.TenantID;
        const courseName = csrFetchedData?.CourseName;
        const courseId = csrFetchedData?.CourseID;
        const PK = csrFetchedData?.Mode == "Popup" ? "TENANT#" + csrFetchedData?.TenantInfo.TenantID + "#COURSEINFO#" + csrFetchedData?.CourseData?.CourseID : "TENANT#" + tenantId + "#" + "COURSEINFO#" + courseId;
        const batchId = csrFetchedData?.BatchID != "" ? csrFetchedData?.BatchID : crypto.randomUUID().toString(25).substring(2, 12);
        const SK = "COURSEBATCH#" + batchId;
        const variables = {
            input: {
                ...props.BatchData,
                PK: PK,
                SK: SK,
                CourseName: csrFetchedData?.Mode == "Popup" ? csrFetchedData?.CourseData?.CourseName : courseName,
                BatchName: data.txtBatchName,
                BatchID: batchId,
                BatchDescription: getContents(message),
                CourseID: csrFetchedData?.Mode == "Popup" ? csrFetchedData?.CourseData?.CourseID : courseId,
                CreatedBy: props?.user?.username,
                CreatedDate: new Date(),
                LastModifiedDate: new Date(),
                LastModifiedBy: props?.user?.username,
                StartDate: data.txtstdate,
                EndDate: data.txtEnddate,
                IsDeleted: false,
                TenantID: props?.TenantInfo?.TenantID
            },
        };
        finalJson.current = { ...finalJson.current, Variables: variables };
    };
    const rest = useRef(false);
    useEffect(() => {

        async function saveData() {
            let temp = Object.values(submit)
            if (temp.length == restrictionLength) {
                if (!temp?.includes("Error")) {
                    const query = csrFetchedData?.BatchID != "" ? updateXlmsCourseBatch : createXlmsCourseBatch;
                    if (Object.values(finalJson.current.RS != undefined ? finalJson.current.RS : {})?.length > 0) {
                        Object.values(finalJson.current.RS).map((data) => {

                        });
                    }
                    const variables = {
                        input: {
                            ...finalJson.current.Variables.input, Restriction: JSON.stringify({ ...finalJson.current.RS })
                        }
                    };
                    /*Batch Update*/
                    if (csrFetchedData?.CurrentBatchData.Shard != null || csrFetchedData?.CurrentBatchData?.Shard != undefined) {
                        for (let i = 1; i <= csrFetchedData?.CurrentBatchData?.Shard; i++) {
                            UpdateBatch({ UpdateData: csrFetchedData?.BatchData, inn: variables.input, pk: "TENANT#" + csrFetchedData?.TenantID + "#COURSEINFO#" + csrFetchedData?.CurrentBatchData?.CourseID + "#" + i, props: props, query: createXlmsCourseManagementShardingInfo });
                        }
                    }
                    (AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).then((finalStatus) => {
                        setValue("submit", false);
                        if (rest.current == false) {
                            finalResponse(finalStatus.Status);
                        }
                        setSubmit(() => {
                            return {};
                        });

                    });
                }
                else {
                    setValue("submit", false);
                    setSubmit(() => {
                        return {};
                    });
                }
            }
        }
        saveData();
    }, [csrFetchedData?.BatchData, csrFetchedData?.BatchID, csrFetchedData?.CurrentBatchData?.CourseID, csrFetchedData?.CurrentBatchData?.Shard, csrFetchedData?.TenantID, finalResponse, props, restrictionLength, setValue, submit]);

    const AddRestrictionLoop = useCallback((PageData) => {
        const rowGrid = [];
        if (PageData?.BatchID != "" && Object.keys(PageData?.finalJson.current.RS != undefined ? finalJson.current.RS : {}).length == 0) {
            return <></>;
        }
        for (let i = 0; i < PageData?.restrictionLength; i++) {
            rowGrid.push(<AddRestriction setSubmit={PageData?.setSubmit} BatchID={PageData?.BatchID} key={i} restrictionLength={PageData?.restrictionLength} json={PageData?.finalJson.current.RS?.["RS" + i]} data={PageData?.data} actList={PageData?.actList} id={i} setData={PageData?.setData} final={i == PageData?.restrictionLength - 1 && PageData?.restrictionLength != 1 ? true : false} options={PageData?.options} TenantInfo={PageData?.TenantInfo} user={PageData?.user} />);
        }
        return <>{rowGrid}</>;
    }, []);

    const setData = useCallback((data, id) => {
        if (id != undefined && restrictionLength != undefined) {
            if (id < restrictionLength && Chnage.current == false) {
                finalJson.current = { ...finalJson.current, RS: { ...finalJson.current.RS, ["RS" + (id)]: data } };
            }
            else {
                if (id != 0) {
                    delete finalJson.current.RS["RS" + (id)];
                }
            }
        }
    }, [restrictionLength]);

    const moduleData = useRef([]);
    useEffect(() => {
        async function moduleList() {
            let currentuser = await Auth?.currentAuthenticatedUser();
            let TentID = currentuser?.attributes["custom:tenantid"];
            const moduleDataResponse = await AppsyncDBconnection(listXlmsCourseModule, { PK: "TENANT#" + TentID + "#COURSEINFO#" + router.query["CourseID"], SK: "COURSEMODULE#", IsDeleted: false }, currentuser?.signInUserSession?.accessToken?.jwtToken)
            moduleData.current = moduleDataResponse?.res?.listXlmsCourseModule?.items
        } moduleList()
    }, [router.query])
    const AddRestriction = useCallback((PageData) => {
        return (
            <>
                <div className="flex w-3/5 mx-auto">
                    <div className="w-full m-2" >
                        {(PageData?.BatchID != undefined) && <>
                            <AddRestrictionSingle
                                BatchData={batchSingleData.current}
                                updateModuleData={moduleData.current}
                                setSubmit={PageData?.setSubmit}
                                BatchID={PageData?.BatchID}
                                restrictionLength={PageData?.restrictionLength}
                                actList={PageData?.actList}
                                json={PageData?.json}
                                id={PageData?.id}
                                setData={PageData?.setData}
                                TenantInfo={PageData?.TenantInfo}
                                user={PageData?.user}
                                data={PageData?.data} />
                        </>
                        }
                        {
                            PageData?.final && <div className="pt-2">
                                <i className="fa-solid fa-trash text-red-600" onClick={() => {
                                    setRestrictionLength((data) => {
                                        Chnage.current = true;
                                        delete finalJson.current.RS["RS" + (data - 1)];
                                        return data - 1;
                                    });
                                }}></i>
                            </div>
                        }
                    </div>

                </div>

            </>
        );
    }, []);
    const today = new Date();
    const dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate());
    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            {
                path: "/CourseManagement/CourseList",
                breadcrumb: "Course Management"
            },
            {
                path: `/CourseManagement/BatchList?CourseID=${csrFetchedData?.CourseID}&CourseName=${csrFetchedData?.CourseName}`,
                breadcrumb: "Batch List"
            },

            { path: "", breadcrumb: csrFetchedData?.BatchID != "" ? "Edit Batch" : "Create Batch" }
        ];
    }, [csrFetchedData?.BatchID, csrFetchedData?.CourseID, csrFetchedData?.CourseName]);

    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedData?.CurrentBatchData == undefined}>
                <form onSubmit={handleSubmit(submitHandler)} >
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className={csrFetchedData?.Mode != "Popup" ? "nvl-FormContent" : ""}>
                        <div className="flex gap-2">
                            <NVLlabel text={`Course Name : ${csrFetchedData?.Mode == "Popup" ? csrFetchedData?.CourseData?.CourseName : csrFetchedData?.CourseName}`} className="nvl-Def-Label" />
                        </div>
                        <NVLTextbox disabled={csrFetchedData?.BatchID != ""} id="txtBatchName" title="Batch Name" className={`nvl-mandatory nvl-Def-Input ${csrFetchedData?.BatchID != "" ? "Disabled" : ""}`} max={"50"} labelText="Batch Name" labelClassName="font-semibold text-gray-500" errors={errors} register={register} />
                        <div className="{invalid-feedback} text-orange-600 text-sm hidden" id="Batch_name_errors">
                            *Batch name already exist
                        </div>
                        <div>
                            <NVLlabel text="Batch Description" className="nvl-Def-Label" >
                            </NVLlabel>
                            <NVLRichTextBox id="txtBatchDescription" className={csrFetchedData?.CurrentBatchData?.IsDefaultBatch == true ? "Disabled" : "isResizable nvl-non-mandatory nvl-Def-Input"} setState={setMessage} max={"250"} />
                        </div>
                        <div>
                            <NVLTextbox labelClassName={"nvl-Def-Label"} labelText={"Start Date"} id="txtstdate" type="date" className={csrFetchedData?.CurrentBatchData?.IsDefaultBatch == true ? "Disabled" : "nvl-mandatory nvl-Def-Input"} min={dateTime} errors={errors} register={register} required></NVLTextbox>
                            <NVLTextbox labelClassName={"nvl-Def-Label"} labelText={"End Date"} id="txtEnddate" type="date" className={csrFetchedData?.CurrentBatchData?.IsDefaultBatch == true ? "Disabled" : "nvl-mandatory nvl-Def-Input"} min={dateTime} errors={errors} register={register} required></NVLTextbox>
                        </div>
                    </div>
                    <AddRestrictionLoop restrictionLength={restrictionLength} setSubmit={setSubmit} BatchID={csrFetchedData?.BatchID} data={data} actList={actList} setData={setData} TenantInfo={props?.TenantInfo} user={props?.user} Json={csrFetchedData?.RestrictionSet} finalJson={finalJson} />

                    <NVLButton id="AddOptions" text={"Add Restriction Set"} type="button" onClick={() => { Chnage.current = false; setRestrictionLength((data) => { return data + 1; }); }} className={csrFetchedData?.CurrentBatchData?.IsDefaultBatch == true ? "w-32 nvl-button text-gray-700 bg-primary Disabled" : "w-32 nvl-button bg-primary text-white "} />
                    <div className="{invalid-feedback} text-red-500 text-sm pt-2" id="desc_errors">
                        {errors?.RS_Set?.message}
                    </div>
                    <div className=" justify-center flex gap-4 pt-4">
                        <NVLButton
                            id="btnSave"
                            text={!watch("submit") ? "Save" : ""}
                            disabled={watch("submit") ? true : false}
                            type="submit"
                            onClick={() => { Chnage.current = false; handleSubmit(submitHandler) }}
                            className={csrFetchedData?.CurrentBatchData?.IsDefaultBatch == true ? "w-32 nvl-button bg-primary Disabled" : "w-32 nvl-button bg-primary text-white "} >
                            {
                                watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
                            }
                        </NVLButton>
                        <NVLButton
                            id="btnClear"
                            text={"Cancel"}
                            type="button"
                            className="nvl-button w-28"
                            onClick={() => router.push(`/CourseManagement/BatchList?CourseID=${csrFetchedData?.CourseID}&CourseName=${csrFetchedData?.CourseName}`)}
                        ></NVLButton>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CreateBatch;