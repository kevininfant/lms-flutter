import QuestionList from "@Pages/ActivityManagement/CommonActivitySettings/QuestionList";
import { useRouter } from "next/router";

function CourseQuestionList(props) {
    const router = useRouter();
    return (
        <>
            <QuestionList  user={props.user} mode={router.query["Mode"]} TenantInfo={props.TenantInfo}
                ActivityID={router.query["ActivityID"]}
                ActivityType={router.query["ActivityType"]}
                TenantName={props.TenantInfo.TenantName}
                UserSub={props.user.attributes["sub"]}
                CourseID={router.query["CourseID"]}
                ModuleID={router.query["ModuleID"]}/>

        </>
    );
}

export default CourseQuestionList;

