import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import NVLHeader from "@Controls/NVLHeader";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createXlmsCategoryStatus, updateXlmsCourseCategory, updateXlmsCourseSubCategory } from "src/graphql/mutations";
import { listXlmsCourseManagementInfo, listXlmsCourseSubCategory } from "src/graphql/queries";

export default function CategoryList(props) {

    const router = useRouter();
    const [isRefreshing, setIsRefreshing] = useState(0);
    const [popupValues, setPopupValues] = useState([]);
    const [search, setSearch] = useState("");
    const [courseListData, setCourseListData] = useState([]);
    const [subCategoryData, setSubCategory] = useState([]);
    useEffect(() => {
        async function categoryFetch() {
            const response = await AppsyncDBconnection(listXlmsCourseSubCategory, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSECATEGORY#", IsDeleted: false, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const fetchedCategoryData = response.res?.listXlmsCourseSubCategory?.items != undefined ? response.res?.listXlmsCourseSubCategory?.items : [];
            const categoryList = [];

            const categoryFiltered = fetchedCategoryData?.filter(
                (obj) =>
                    !categoryList[obj.CategoryID] && (categoryList[obj.CategoryID] = true)
            );
            const subCategoryFiltered = fetchedCategoryData?.filter(
                (obj) => obj.SubCategoryName != null
            );

            categoryList.push({ CategoryFiltered: categoryFiltered, SubCategoryFiltered: subCategoryFiltered });
            setSubCategory(subCategoryFiltered);

        }
        categoryFetch();
        return (() => {
            setSubCategory((temp) => { return { ...temp }; });

        });
    }, [props?.user?.signInUserSession?.accessToken?.jwtToken, props.TenantInfo.TenantID]);


    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    };


    const resetPopUp = useCallback(() => {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
        refreshData();
        setSearch("");

    }, [refreshData]);


    const popUp = useCallback((type, PK, SK, Content) => {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });

    }, []);


    const refreshData = useCallback(async () => {

        document.getElementById("divManageCourseCategory")?.classList?.add("!w-full");
        document.getElementById("divCourseDetails")?.classList?.remove("w-1/2");
        document.getElementById("divCourseDetails")?.classList?.add("hidden");
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });

        const subCategoryList = await AppsyncDBconnection(listXlmsCourseSubCategory, {
            PK: "TENANT#" + props.TenantInfo.TenantID,
            SK: "COURSECATEGORY#",
            IsDeleted: false,
        }, props?.user?.signInUserSession?.accessToken?.jwtToken);

        const updatedSubCategoryList = subCategoryList.res?.listXlmsCourseSubCategory?.items != undefined ? subCategoryList.res?.listXlmsCourseSubCategory?.items : [];

        const categoryList = [];

        const categoryFiltered = updatedSubCategoryList?.filter(
            (obj) =>
                !categoryList[obj.CategoryID] && (categoryList[obj.CategoryID] = true)
        );
        const subCategoryFiltered = updatedSubCategoryList?.filter(
            (obj) => obj.SubCategoryName != null
        );
        categoryList.push({ CategoryFiltered: categoryFiltered, SubCategoryFiltered: subCategoryFiltered });
        setSubCategory(() => { return subCategoryFiltered; });

        gridDataBind(updatedSubCategoryList);

    }, [props?.user?.signInUserSession?.accessToken?.jwtToken, gridDataBind, props.TenantInfo.TenantID]);

    async function updateCategory() {
        var isSus = false;
        var isDelete = false;

        if (popupValues.Type == "isSuspend") {
            isSus = true;
        } else if (popupValues.Type == "isDelete") {
            isDelete = true;
            isSus = true;
        }

        if (popupValues.Type != "isDeleteSub") {
            const deletedStatus = await AppsyncDBconnection(updateXlmsCourseCategory, {
                input:
                    popupValues.Type == "isSuspend" || popupValues.Type == "isUnSuspend"
                        ? { PK: popupValues.PK, SK: `${`COURSECATEGORY#${popupValues.SK?.split("#")?.[1]}`}`, IsSuspend: isSus }
                        : {
                            PK: popupValues.PK,
                            SK: `${`COURSECATEGORY#${popupValues.SK?.split("#")?.[1]}`}`,
                            IsSuspend: isSus,
                            IsDeleted: isDelete,
                        },
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const existSubCategory = await AppsyncDBconnection(
                listXlmsCourseSubCategory,
                {
                    PK: popupValues.PK,
                    SK: `${`COURSECATEGORY#${popupValues.SK?.split("#")?.[1]}#COURSESUBCATEGORY#`}`,
                    IsDeleted: false,
                }, props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            const existingSubCAtegory =
                existSubCategory.res?.listXlmsCourseSubCategory?.items;
            const subCategoryList = [];

            existingSubCAtegory?.map((SubCategory) => {
                subCategoryList.push({
                    PK: SubCategory.PK,
                    SK: SubCategory.SK,
                    CategoryID: SubCategory.CategoryID,
                    CategoryName: SubCategory.CategoryName,
                    CategoryDescription: SubCategory.CategoryDescription,
                    SubCategoryID: SubCategory.SubCategoryID,
                    SubCategoryDescription: SubCategory.SubCategoryDescription,
                    SubCategoryName: SubCategory.SubCategoryName,
                    CreatedDate: SubCategory.CreatedDate,
                    IsDeleted: isDelete,
                    IsSuspend: isSus,
                });
            });

            if (subCategoryList.length > 0) {
                await AppsyncDBconnection(createXlmsCategoryStatus, {
                    input: [...subCategoryList],
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            }

            if (deletedStatus.Status == "Success") {
                refreshData();
            }
        }
        else {

            const deletedStatus = await AppsyncDBconnection(
                updateXlmsCourseSubCategory,
                { input: { PK: popupValues.PK, SK: popupValues.SK, IsDeleted: true } }, props?.user?.signInUserSession?.accessToken?.jwtToken
            );
            if (deletedStatus.Status == "Success") {
                refreshData();
            }
        }
        resetPopUp();
    }


    function getDateFormat(CreatedDt) {
        return (new Date(CreatedDt).toDateString().substring(4));
    }
    const actionRestrictionCategory = useCallback((getItem) => {

        const actionList = [];
        if (props.RoleData?.EditCategory && !getItem.IsSuspend) {
            actionList.push(

                {
                    id: crypto.randomUUID(),
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Edit Category",
                    action: () =>
                        router.push(
                            `/CourseManagement/CreateCategory?Mode=Edit&CategoryID=${getItem.CategoryID}&SubCategoryID=${getItem.SubCategoryID != null ? getItem.SubCategoryID : 0}`
                        ),
                },
            );
        }
        if (props.RoleData?.ShowOrHideCategory && !getItem.IsSuspend) {
            actionList.push(
                {
                    id: crypto.randomUUID(),
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                    name: "Hide Category",
                    action: () =>
                        popUp(
                            "isSuspend",
                            getItem?.PK,
                            getItem?.SK,
                            "Are you sure to Hide Category?"
                        ),
                },
            );
        }

        if (props.RoleData?.ShowOrHideCategory && getItem.IsSuspend) {
            actionList.push(
                {
                    id: crypto.randomUUID(),
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                    name: "Show Category",
                    action: () =>
                        popUp(
                            "isUnSuspend",
                            getItem.PK,
                            getItem.SK,
                            "Are you sure to Show Category?"
                        ),
                },

            );
        }
        if (props.RoleData?.DeleteCategory && getItem.IsSuspend) {

            actionList.push(
                {
                    id: crypto.randomUUID(),
                    Color: "text-yellow-600",
                    Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                    name: "Delete Category",
                    action: () =>
                        popUp(
                            "isDelete",
                            getItem.PK,
                            getItem.SK,
                            "Are you sure to Delete Category?"
                        ),
                },

            );
        }
        return actionList;
    }, [props.RoleData?.EditCategory, props.RoleData?.ShowOrHideCategory, props.RoleData?.DeleteCategory, router, popUp]);


    const actionRestrictionSubCategory = useCallback((SubCategory, getItem) => {
        const actionList = [];
        if (props.RoleData?.EditSubCategory && !getItem.IsSuspend) {
            actionList.push(
                {
                    id: crypto.randomUUID(),
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                    name: "Edit SubCategory",
                    action: () =>
                        router.push(
                            `/CourseManagement/SubCategory?Mode=Edit&CategoryID=${getItem.CategoryID}&SubCategoryID=${SubCategory.SubCategoryID}`
                        ),
                },

            );
        }
        if (props.RoleData?.DeleteSubCategory && !getItem.IsSuspend) {
            actionList.push(
                {
                    id: crypto.randomUUID(),
                    Color: "text-yellow-600",
                    Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                    name: "Delete SubCategory",
                    action: () =>
                        popUp(
                            "isDeleteSub",
                            SubCategory.PK,
                            SubCategory.SK,
                            "Are you sure to Delete Sub Category?"
                        ),
                },
            );
        }
        return actionList;
    }, [props.RoleData?.EditSubCategory, props.RoleData?.DeleteSubCategory, router, popUp]);


    const gridDataBind = useCallback(
        (viewData) => {

            const getSubCategoryCourseList = (
                async (SubCategoryID) => {

                    const response = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEINFO#", IsDeleted: false, IsSuspend: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
                    const courseData = response?.res?.listXlmsCourseManagementInfo?.items;
                    const courseDatafilter = courseData?.filter((Course) => !courseData[Course.SubCategoryID]);
                    const courseList = courseDatafilter?.filter(
                        (obj) => obj.SubCategoryID == SubCategoryID
                    );
                    setCourseListData(courseList);
                }
            );
            const subCategoryHandler = (index) => {

                document.getElementById("divCourseList")?.classList?.add("hidden");
                document.getElementById("divsubName" + index)?.classList?.toggle("hidden");
                document.getElementById("divSubAction" + index)?.classList?.toggle("hidden");
                document.getElementById("ShowCatIcon" + index)?.classList?.toggle("hidden");
                document.getElementById("ShowSubIcon" + index)?.classList?.toggle("hidden");
            };
            const getCategoryCourseList = async (CategoryID) => {

                const response = await AppsyncDBconnection(listXlmsCourseManagementInfo, {
                    PK: "TENANT#" + props.TenantInfo.TenantID,
                    SK: "COURSEINFO#",
                    IsDeleted: false,
                    IsSuspend: false,
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);
                const courseData = response?.res?.listXlmsCourseManagementInfo?.items;

                const courseDatafilter = courseData?.filter((Course) => !courseData[Course.CategoryID]);

                const courseList = courseDatafilter?.filter(
                    (obj) => obj.CategoryID == CategoryID
                );
                setCourseListData(courseList);

                if (courseList && Object.values(courseList)?.length > 0) {
                    document.getElementById("divManageCourseCategory")?.classList?.remove("!w-full");
                    document.getElementById("divCourseDetails")?.classList?.add("!w-1/2");
                    document.getElementById("divCourseDetails")?.classList?.remove("hidden");

                }
            };
            const rowGrid = [];

            viewData?.map((getItem, index) => {
                !getItem.IsDeleted && getItem.SubCategoryID == undefined
                    ? rowGrid.push({
                        PK: (
                            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
                        ),
                        SK: (
                            <NVLlabel id={"lblSKID" + (index + 1)} name="PK" text={getItem.SK} />
                        ),
                        CategoryName: (
                            <>
                                <div>
                                    <div className="flex amplify-link">
                                        {(getItem.CategoryName) && (
                                            <>
                                                <i className="fa fa-caret-right text-lg cursor-pointer my-auto" id={"ShowCatIcon" + getItem?.CategoryID}
                                                    onClick={() => subCategoryHandler(getItem?.CategoryID)}
                                                ></i>
                                                <i
                                                    className="fa fa-caret-down text-lg hidden cursor-pointer my-auto"
                                                    id={"ShowSubIcon" + getItem?.CategoryID}
                                                    onClick={() => subCategoryHandler(getItem?.CategoryID)}
                                                ></i>
                                                <NVLLink id={"txtName" + (index + 1)} title={getItem?.CategoryName} onClick={() => { subCategoryHandler(getItem?.CategoryID); getCategoryCourseList(getItem.CategoryID); }}
                                                    text={getItem?.CategoryName}
                                                    className="pl-4 cursor-pointer"
                                                ></NVLLink>
                                            </>
                                        )}
                                    </div>
                                </div>
                                <div id={"divsubName" + getItem?.CategoryID} className="hidden">
                                    {subCategoryData?.length > 0 && subCategoryData?.map((SubCategory, idx) => {
                                        return (
                                            <div key={idx}>
                                                <div>
                                                    {(getItem?.CategoryID == SubCategory?.CategoryID && SubCategory?.SubCategoryName != null) && (
                                                        <>
                                                            <div className="flex pl-3">
                                                                <div id={idx}>
                                                                    <NVLLink id={"txtName" + (index + 1)} title={SubCategory?.SubCategoryName} text={
                                                                        SubCategory?.SubCategoryName
                                                                    }
                                                                        className="pl-4"
                                                                        onClick={() =>
                                                                            getSubCategoryCourseList(
                                                                                SubCategory.SubCategoryID
                                                                            )
                                                                        }
                                                                    ></NVLLink>
                                                                </div>
                                                            </div>
                                                        </>
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </>
                        ),

                        Date: (
                            <NVLlabel
                                id={"txtDate" + (index + 1)}
                                text={getDateFormat(getItem.CreatedDate)}
                            />
                        ),

                        IsSuspend: (
                            <>
                                <div
                                    className="flex m-auto w-full"
                                    title={getItem?.IsSuspend ? "Inactive" : "Active"}
                                >
                                    <div
                                        className={`rounded-full my-auto h-3 w-3 ${getItem?.IsSuspend ? "bg-red-500" : "bg-green-600"
                                            }	`}
                                    ></div>
                                    <NVLlabel className={`${getItem?.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2	`} text={!getItem?.IsSuspend ? "Active" : "Inactive"}
                                    ></NVLlabel>
                                </div>
                            </>
                        ),
                        Action: !getItem?.IsSuspend ? (
                            <>
                                <NVLRapidModal
                                    id={"RapidModal" + (index + 1)}
                                    ActionList={actionRestrictionCategory(getItem)}
                                ></NVLRapidModal>
                                <div id={"divSubAction" + getItem.CategoryID} className="hidden">
                                    {subCategoryData?.length > 0 && subCategoryData?.map((SubCategory, SubCatIdx) => {
                                        return (
                                            <div key={SubCatIdx}>
                                                {(getItem.CategoryID == SubCategory.CategoryID && SubCategory?.SubCategoryName != null) && (
                                                    <>

                                                        {SubCategory?.SubCategoryName != null && <div>
                                                            <NVLRapidModal
                                                                id={"RapidModal" + (index + 1)}
                                                                ActionList={actionRestrictionSubCategory(SubCategory, getItem)}
                                                            ></NVLRapidModal>
                                                        </div>}
                                                    </>
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            </>
                        ) : (
                            <NVLRapidModal
                                id={"RapidModal" + (index + 1)}
                                ActionList={actionRestrictionCategory(getItem)}
                            ></NVLRapidModal>
                        ),
                    })
                    : "";
            });
            return rowGrid;
        }, [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, subCategoryData, actionRestrictionCategory, actionRestrictionSubCategory]
    );

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };
    const variable = useRef({
        PK: "TENANT#" + props.TenantInfo.TenantID,
        SK: "COURSECATEGORY#",
        IsDeleted: false,
    });
    const GridTable = useCallback(() => {
        return (
            <NVLGridTable
                id="tblCourseCategoryList"
                refershPage={isRefreshing}
                Search={search}
                className="max-w-full"
                HeaderColumn={[
                    { HeaderName: "Category Name", Columnvalue: "CategoryName", HeaderCss: "w-4/12", },
                    { HeaderName: "Created Date", Columnvalue: "Date", HeaderCss: "w-4/12" },
                    { HeaderName: "Status", Columnvalue: "IsSuspend", HeaderCss: "w-4/12" },
                    { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-4/12" },
                ]}
                GridDataBind={gridDataBind}
                query={listXlmsCourseSubCategory}
                querryName={"listXlmsCourseSubCategory"}
                variable={variable.current}
                user={props?.user}
            />
        );
    }, [isRefreshing, search, gridDataBind, props?.user]);

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            {
                path: "/CourseManagement/CourseList",
                breadcrumb: "Course Management"
            },
            { path: "", breadcrumb: "Manage Course/ Category" }
        ];
    }, []);
    return (
        <>
            <Container title="CategoryList" loader={subCategoryData == undefined} PageRoutes={pageRoutes}>
                <NVLHeader
                    TabRouting={props?.GeneralRoleData?.AllowNewTab}
                    LinkName2="+Create Sub Category"
                    LinkName3="+Create Category"
                    className3={props.RoleData?.CreateCategory ? (props.TabRouting == true ? " " : "nvl-button-success") : "hidden"}
                    className2={props.RoleData?.CreateSubCategory ? (props.TabRouting == true ? " " : "nvl-button-success") : "hidden"}
                    href2="/CourseManagement/SubCategory?Mode=Create&$0$0$0"
                    RedirectAction2={(e) =>
                        headerHandler(
                            e,
                            "/CourseManagement/SubCategory?Mode=Create&$0$0$0"
                        )
                    }
                    onClick1={refreshData}
                    RedirectAction1={() => refreshData()}
                    href3="/CourseManagement/CreateCategory?Mode=Create&$0$0"
                    RedirectAction3={(e) =>
                        headerHandler(
                            e,
                            "/CourseManagement/CreateCategory?Mode=Create&$0$0"
                        )
                    }
                    IsSearch={true}
                    placeholder={"Search"}
                    SearchonChange={(e) => searchBoxVal(e)}
                    TableID={"tblCategoryList"}
                    IsNestedHeader
                />

                <div className="pt-3 w-full flex">
                    <>
                        <div
                            id="divManageCourseCategory"
                            className={`${courseListData && Object?.keys(courseListData)?.length == 0 ? "w-full" : "w-2/3 "}`}>
                            <GridTable />
                        </div>
                        <div id="divCourseDetails"
                            className={`${courseListData && Object?.keys(courseListData || null)?.length == 0 ? "" : "w-1/2 "}text-xs px-1 border-3 pt-1 ${courseListData && Object?.keys(courseListData)?.length == 0 ? "hidden" : ""
                                }`}
                        >
                            <div className="nvl-GridTable-Header px-6 flex justify-center  border-b py-3 text-xs border-l-0 border-r-0 whitespace-nowrap font-semibold text-left w-4/8 bg-blueGray-600 text-blueGray-200 border-blueGray-500">
                                <span> CategoryName-Sub-CategoryName-Course List </span>
                            </div>
                            {courseListData && Object?.keys(courseListData)?.length > 0 ? (
                                courseListData.map((item, idx) => {
                                    return (
                                        <div key={idx}>
                                            <div
                                                className={`${idx % 2 == 0
                                                    ? "bg-th-grid-th-bg-start-color"
                                                    : "bg-th-grid-td-bg-end-color"
                                                    } px-6 align-middle border-b py-3 text-xs border-l-0 border-r-0 whitespace-nowrap font-semibold text-left w-4/8 bg-blueGray-600 text-blueGray-200 border-blueGray-500`}
                                            >
                                                <table>
                                                    <tbody>
                                                        <tr key={idx} className="nvl-GridTable-Cell w-4/8">
                                                            <td>
                                                                <li title={item?.CourseName}>{item?.CourseName.length > 35 ? item?.CourseName.substring(0, 33) + "..." : item?.CourseName}</li>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    );
                                })
                            ) : (
                                <div className="justify-center flex pt-6">
                                    <NVLlabel
                                        text="Some network issue try again"
                                        className="text-gray-600 font-semibold"
                                    />
                                </div>
                            )}
                        </div>
                    </>
                </div>
                <div id="isModaldiv">
                    <NVLModalPopup
                        ButtonYestext="Yes"
                        ButtonNotext="No"
                        SubmitClick={() => updateCategory()}
                        CancelClick={() => resetPopUp()}
                        CloseIconEvent={() => resetPopUp()}
                        Content={popupValues.Content}
                    ></NVLModalPopup>
                </div>
            </Container>
        </>
    );
}

CategoryList.defaultProps = {
    color: "light",
};

