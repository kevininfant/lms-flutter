import QuizResponse from "@Pages/ActivityManagement/QuizResponse";
import { useRouter } from "next/router";

function CourseQuizResponse(props) {
    const router = useRouter();
    
    return (
        <div>
            <QuizResponse user={props.user} TenantInfo={props.TenantInfo} CourseID={router.query["CourseID"]} ModuleID={router.query["ModuleID"]} BucketName={props.TenantInfo.BucketName} RootFolder={props.TenantInfo.RootFolder}/>
        </div>
    );
}

export default CourseQuizResponse;
