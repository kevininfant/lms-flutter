import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { updateXlmsCourseManagementInfo } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo, listXlmsCourseBatchInfos, listXlmsCourseBatchWiseDismissUserList, listXlmsCourseManagementInfo } from "src/graphql/queries";


function EnrollmentSettingsList(props) {

    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [search] = useState("");
    const [isRefreshing, setIsRefreshing] = useState(0);
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const count = useRef({});
    const refreshGrid = async () => {
    
        setIsRefreshing((count) => {
          return count + 1;
        });
      };
   

    useEffect(() => {
        const dataSource  = async () => {
            const tenantId = props?.user.attributes["custom:tenantid"];
            const courseId = router.query["CourseID"];
            const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + "#COURSEINFO#" + courseId, SK: "COURSEBATCH#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const response = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEINFO#" + courseId, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const enrollData = await AppsyncDBconnection(listXlmsCourseBatchWiseDismissUserList, { GsiPK: "TENANT#" + tenantId + "#COURSEID#" + courseId, GsiSK: "BATCH#" }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            count.current = ({
                ManualEnrollUserCount: enrollData.res?.listXlmsCourseBatchWiseDismissUserList?.items != undefined ? enrollData.res?.listXlmsCourseBatchWiseDismissUserList.items.filter((temp) => temp.IsManualEnroll) : "0",
                SelfEnrollUserCount: enrollData.res?.listXlmsCourseBatchWiseDismissUserList?.items != undefined ? enrollData.res?.listXlmsCourseBatchWiseDismissUserList?.items.filter((temp) => temp.IsSelfEnroll) : "0"
            });
            setCsrFetchedData({
                EnrollData: enrollData.res?.listXlmsCourseBatchWiseDismissUserList?.items != undefined ? enrollData.res?.listXlmsCourseBatchWiseDismissUserList?.items : [],
                BatchData: batchData.res?.listXlmsCourseBatchInfos?.items != undefined ? batchData.res?.listXlmsCourseBatchInfos?.items : [],
                TenantID: tenantId,
                CourseID: courseId,
                CourseData: response.res?.getXlmsCourseManagementInfo
            });

        };
        dataSource();
        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
        });
    }, [props?.user.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query, setCsrFetchedData]);

    const headerColumn = [
        { HeaderName: "Enrollment Type", Columnvalue: "Type", HeaderCss: "w-3/12", },
        { HeaderName: "Users", Columnvalue: "Users", HeaderCss: "w-3/12", },
        { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-0/12", },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
    ];

    const resetPopUp= useCallback(()=>{
        setPopupValues({ PK: "", SK: "", Content: "", Type: "", Mode: "" });

    },[]);

    const popUp=useCallback((type, PK, SK, Content,Mode)=>{
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type ,Mode :Mode});

    },[]);

    async function updateField(e) {
         e.preventDefault();
        var isDisable = false;
        if (popupValues.Type == "isdisable") {
            isDisable = true;
        } else if (popupValues.Type == "isenable") {
            isDisable = false;
        }

        const selfVariables = {
            input: {
                PK: popupValues.PK,
                SK: popupValues.SK,
                IsSelfDisable: isDisable,
                LastModifiedBy: props.user.username,
                LastModifiedDate: new Date(),
            },
        };
        const manual = {
            input: {
                PK: popupValues.PK,
                SK: popupValues.SK,
                IsManualDisable: isDisable,
                LastModifiedBy: props.user.username,
                LastModifiedDate: new Date(),
            },
        };
      

        const variables = popupValues.Mode == "Manual" ? manual : selfVariables;


        await AppsyncDBconnection(updateXlmsCourseManagementInfo, variables
            , props?.user?.signInUserSession?.accessToken?.jwtToken);
            refreshGrid();
        resetPopUp(); 
    }

    const gridDataBind = useCallback(async () => {
        if (csrFetchedData.EnrollData != undefined) {

            const manualActionList = [];
            const selfActionList = [];

            async function getEnrollmentSettingData() {
                const enrollData = await AppsyncDBconnection(getXlmsCourseManagementInfo, {
                    PK: "TENANT#" + csrFetchedData?.TenantID,
                    SK: "COURSEINFO#" + csrFetchedData?.CourseID,
                }, props?.user?.signInUserSession?.accessToken?.jwtToken);
              
                return enrollData.res?.getXlmsCourseManagementInfo;
            }
           
            const enrollmentData = await getEnrollmentSettingData();

           
            !enrollmentData?.IsManualDisable ? manualActionList.push(
            
                {
                    id: 1,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                    name: "Disable",
                    action: () =>
                        popUp(
                            "isdisable",
                            enrollmentData?.PK,
                            enrollmentData?.SK,
                            "Are you sure to Disable?",
                            "Manual"
                        ),
                },
                {
                    id: 2,
                    Color: "text-blue-700",
                    Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                    name: "Enroll User",
                    action: () =>
                        router.push(`/CourseManagement/CourseEnrollUser?Mode=EnrollList&CourseID=${csrFetchedData.CourseID}&CourseName=${encodeURIComponent(csrFetchedData.CourseData?.CourseName)}`
                        ),
                },
                {
                    id: 3,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Edit Setting",
                    action: () =>
                        router.push(`/CourseManagement/ManualEnrollMentSettings?CourseID=${csrFetchedData.CourseID}`
                        ),
                },):
              manualActionList.push(
                    {
                        id: 1,
                        Color: "text-yellow-600",
                        Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                        name: "Enable",
                        action: () =>
                            popUp(
                                "isenable",
                                enrollmentData?.PK,
                                enrollmentData?.SK,
                                "Are you sure to Enable?",
                                "Manual"
                            ),
                    });

            !enrollmentData?.IsSelfDisable ? selfActionList.push(
            
                {
                    id: 1,
                    Color: "text-yellow-600",
                    Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                    name: "Disable",
                    action: () =>
                        popUp(
                            "isdisable",
                            enrollmentData?.PK,
                            enrollmentData?.SK,
                            "Are you sure to Disable?",
                            "Self"
                        ),
                },

                {
                    id: 3,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Edit Setting",
                    action: () =>
                        router.push(`/CourseManagement/SelfEnrollMentSettings?CourseID=${csrFetchedData.CourseID}`
                        ),
                },) :
                selfActionList.push(
                    {
                        id: 1,
                        Color: "text-yellow-600",
                        Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                        name: "Enable",
                        action: () =>
                            popUp(
                                "isenable",
                                enrollmentData?.PK,
                                enrollmentData?.SK,
                                "Are you sure to Enable?",
                                "Self"
                            ),
                    });

            return [
                {
                    Type: "Manual Enrollment",
                    Users: count.current.ManualEnrollUserCount?.length == undefined ? "0" : count.current?.ManualEnrollUserCount.length,
                    Status: (
                        <>
                            <div className="flex m-auto w-full" title={enrollmentData?.IsManualDisable ? "Inactive" : "Active"}>
                                <div
                                    className={`rounded-full my-auto h-3 w-3 ${enrollmentData?.IsManualDisable ? "bg-red-500" : "bg-green-600"
                                    }	`}
                                ></div>
                                <NVLlabel
                                    className={`${enrollmentData?.IsManualDisable ? "text-red-500" : "text-green-600"
                                    } my-auto ml-2	`}
                                    text={!enrollmentData?.IsManualDisable ? "Active" : "Inactive"}
                                ></NVLlabel>
                            </div>
                        </>
                    ),
                    Action: <NVLRapidModal
                        id={"RapidModal"}
                        ActionList={manualActionList}
                    ></NVLRapidModal>

                },
                {
                    Type: "Self Enrollment",
                    Users: count.current?.SelfEnrollUserCount?.length == undefined ? "0" : count?.current.SelfEnrollUserCount?.length,
                    Status: (
                        <>
                            <div className="flex m-auto w-full" title={enrollmentData?.IsSelfDisable ? "Inactive" : "Active"}>
                                <div
                                    className={`rounded-full my-auto h-3 w-3 ${enrollmentData?.IsSelfDisable ? "bg-red-500" : "bg-green-600"
                                    }	`}
                                ></div>
                                <NVLlabel
                                    className={`${enrollmentData?.IsSelfDisable ? "text-red-500" : "text-green-600"
                                    } my-auto ml-2	`}
                                    text={!enrollmentData?.IsSelfDisable ? "Active" : "Inactive"}
                                ></NVLlabel>
                            </div>
                        </>
                    ),
                    Action: <NVLRapidModal
                        id={"RapidModal"}
                        ActionList={selfActionList}
                    ></NVLRapidModal>
                },];
        }
    }, [csrFetchedData.CourseData?.CourseName, csrFetchedData.CourseID, csrFetchedData.EnrollData, csrFetchedData?.TenantID, popUp, props?.user?.signInUserSession?.accessToken?.jwtToken, router]);

    const variable = {
        PK: "TENANT#" + props?.TenantInfo?.TenantID,
        SK: "COURSEINFO#" + csrFetchedData.CourseID,
    };

    const pageRoutes = useMemo(() => {
        return [
            {
                path: props.mode == "Create" || props.mode == "Edit" ? "/ActivityManagement/ActivityList" : `/CourseManagement/CourseList`, breadcrumb: props.mode == "Create" || props.mode == "Edit" ? "Activity Management" : "Course Management"
            },
            { path: "", breadcrumb: "Enrollment Setting" }
        ];
    }, [props.mode]);
    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedData?.EnrollData == undefined} title="Course Management">
                <NVLGridTable
                    Search={search}
                    id="tblEnrollList"
                    className="max-w-full"
                    HeaderColumn={headerColumn}
                    GridDataBind={gridDataBind}
                    query={listXlmsCourseManagementInfo}
                    querryName={"listXlmsCourseManagementInfo"}
                    variable={variable}
                    refershPage={isRefreshing}
                    user={props?.user}
                />
                <div id="isModaldiv">
                    <NVLModalPopup
                        ButtonYestext="Yes"
                        SubmitClick={(e) => updateField(e)}
                        CancelClick={() => resetPopUp()}
                        ButtonNotext="No"
                        CloseIconEvent={() => resetPopUp()}
                        Content={popupValues.Content}
                    ></NVLModalPopup>
                </div>
            </Container>
        </>
    );
}

export default EnrollmentSettingsList;