import SendNotificationList from "@Pages/ActivityManagement/SendNotificationList";
import { useRouter } from "next/router";

function CourseNotfication(props) {
    const router = useRouter();
    
    return (
        <div>
            <SendNotificationList user={props.user} 
                TenantInfo={props.TenantInfo} 
                CourseID={router.query["CourseID"]}
                GeneralRoleData={props.GeneralRoleData} 
                RoleData={props.RoleData} 
                props={props}
                ModuleID={router.query["ModuleID"]}/>
        </div>
    );
}

export default CourseNotfication;
