
import DismissUser from "@Pages/ActivityManagement/DismissUser";
import { useRouter } from "next/router";

function CourseDismissUser(props) {
    const router = useRouter();
    return (
        <>
            <DismissUser user={props.user} 
                mode={router.query["Mode"]} 
                TenantInfo={props.TenantInfo} 
                CourseID={router.query["CourseID"]} 
                ModuleID={router.query["ModuleID"]}/>
        </>
    );
}
export default CourseDismissUser;
