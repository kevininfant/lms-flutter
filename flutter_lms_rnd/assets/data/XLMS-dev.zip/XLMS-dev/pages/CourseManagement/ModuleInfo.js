import ActivityInfo from "@Pages/ActivityManagement/ActivityInfo";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { getXlmsCourseActivityConfig, getXlmsCourseModule, listXlmsCourseModule } from "src/graphql/queries";

function ModuleInfo(props) {
    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const moduleId = useMemo(() => { return router.query["ModuleID"]; }, [router.query]);
    const courseId = useMemo(()                                                  => { return router.query["CourseID"]; }, [router.query]);
    const activityId = useMemo(() => { return router.query["ActivityID"]; }, [router.query]);
    const activityType = useMemo(() => { return router.query["ActivityType"]; }, [router.query]);
    const mode = useMemo(() => { return router.query["Mode"]; }, [router.query]);
    const zoomActivityID = useMemo(()=>{return router.query["ZoomActivityID"];},[router.query]);
    useEffect(() => {
        async function fetchData() {
            const activityData = await AppsyncDBconnection(getXlmsCourseActivityConfig, {
                PK: "XLMS#ACTIVITY",
                SK: "ACTIVITY#ACTIVITYTYPE",
            }, props.user.signInUserSession.accessToken.jwtToken);
            const moduleData = await AppsyncDBconnection(getXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + courseId,
                SK: "COURSEMODULE#" + moduleId,
            }, props.user.signInUserSession.accessToken.jwtToken);

            const moduleActivityData = await AppsyncDBconnection(getXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId
            }, props.user.signInUserSession.accessToken.jwtToken);
          
            const zoomWise = await AppsyncDBconnection(listXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "COURSEID#" + courseId + "#MODULEID#" + moduleId ,
                IsDeleted: false
            }, props.user.signInUserSession.accessToken.jwtToken);

            const zoomWiseActivity = zoomWise?.res?.listXlmsCourseModule?.items;
            const filteredData = zoomWiseActivity?.filter((id)=> (id.ZoomActivityID == router.query["ZoomActivityID"]) && id.ActivityName?.includes(mode) );
            setCsrFetchedData({
                ModuleData: moduleData.res?.getXlmsCourseModule,
                ModuleActivityData: (mode == "ModuleEdit" || mode == "ModuleDirect") ? moduleActivityData.res?.getXlmsCourseModule : filteredData[0],
                ActivityData: activityData.res?.getXlmsCourseActivityConfig,
            });
        }
        fetchData();

        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
        });
    }, [activityId, activityType, courseId, moduleId, mode, props?.TenantInfo?.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query]);
    return (
        <>
            {Object.keys(csrFetchedData).length != 0 && <ActivityInfo user={props.user} ModuleId={moduleId} CourseID={courseId} mode={mode} ActivityData={csrFetchedData?.ActivityData} ActivityType={activityType} EditData={csrFetchedData?.ModuleActivityData} TenantInfo={props.TenantInfo} ZoomActivityID={zoomActivityID} ModuleData={csrFetchedData?.ModuleData} TenantID={props.TenantInfo.TenantID} />}
        </>
    );
}

export default ModuleInfo;
