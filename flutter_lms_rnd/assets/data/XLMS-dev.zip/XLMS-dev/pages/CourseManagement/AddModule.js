import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseManagementShardingInfo, createXlmsCourseModule, updateXlmsCourseManagementInfo, updateXlmsCourseModule } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo, getXlmsCourseModule, listXlmsCourseModule, listXlmsCourseModulesKeys } from "src/graphql/queries";
import * as Yup from "yup";

function AddModule(props) {
    const [message, setMessage] = useState("");
    const [csrFetchedCourseData, setCsrFetchedUserData] = useState();
    const router = useRouter();
    const courseId = useMemo(() => {
        return router.query["CourseID"];
    }, [router.query]);
    const mode = useMemo(() => { return router.query["Mode"]; }, [router.query]);
    const moduleId = useMemo(() => { return router.query["ModuleID"]; }, [router.query]);
    useEffect(() => {
        const dataSource = async () => {
            const moduleData = await AppsyncDBconnection(listXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + courseId,
                SK: "COURSEMODULE#",
                IsDeleted: false
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const createModuleData = await AppsyncDBconnection(getXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + courseId,
                SK: "COURSEMODULE#" + moduleId,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const courseModuleActivity = await AppsyncDBconnection(listXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "COURSEID#" + courseId + "#MODULEID#" + moduleId + "#",
                IsDeleted: false
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "COURSEINFO#" + courseId,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            setCsrFetchedUserData({
                EditData: mode == "Edit" && createModuleData?.res?.getXlmsCourseModule,
                ModuleData: moduleData.res?.listXlmsCourseModule?.items != undefined ? moduleData.res?.listXlmsCourseModule?.items : [],
                CourseActivityData: courseModuleActivity?.res?.listXlmsCourseModule?.items,
                CourseData: courseData?.res?.getXlmsCourseManagementInfo,
            });
        };
        dataSource();
        return (() => {
            setCsrFetchedUserData((temp) => { return { ...temp }; });
        });
    }, [courseId, moduleId, mode, props?.TenantInfo?.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, router, router.query]);


    useEffect(() => {

        if (mode == "Edit") {
            setValue("txtModuleName", csrFetchedCourseData?.EditData?.ModuleName);
            if (message != "") {
                setHTMLContents(csrFetchedCourseData?.EditData?.ModuleDescription, message);
                message?.history?.clear();
            }
        }
    }, [message, setValue, csrFetchedCourseData?.EditData, mode, props, csrFetchedCourseData?.EditData?.ModuleName, csrFetchedCourseData?.EditData?.ModuleDescription]);

    const validationSchema = Yup.object().shape({
        txtModuleName: Yup.string().required("Module name is required").matches(Regex("AlphaNumForTopicName"), "Enter Valid Module name").max(250, "Maximum length exceeded 250").nullable()
            .test("", "", (e, { createError }) => {

                const modulename = csrFetchedCourseData?.ModuleData;
                const moduleNameFound = modulename?.some((batch) => batch.ModuleName?.toLowerCase() == e?.toLowerCase());
                if (moduleNameFound && (mode == "Edit" || mode == "Create") && e?.toLowerCase() != csrFetchedCourseData?.ModuleData?.ModuleName?.toLowerCase()) {
                    if (e?.toLowerCase() != csrFetchedCourseData?.EditData?.ModuleName?.toLowerCase()) {
                        return createError({ message: " * Module Name already exists" });
                    }
                }
                return true;

            }),

    });
    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };

    const { register, handleSubmit, watch, reset, formState, setValue } = useForm(formOptions);
    const { errors } = formState;
    const finalResponse = (FinalStatus) => {
        document?.activeElement?.blur();
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        } else {
            setModalValues({
                ModalInfo: "Success",
                ModalTopMessage: "Success",
                ModalBottomMessage: "Details have been saved successfully.",
                ModalOnClickEvent: () => {
                    router.push(`/CourseManagement/ModulesList?CourseID=${courseId}`);
                }
            });
            ModalOpen();
        }
    };

    const initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push(`/CourseManagement/ModulesList?CourseID=${courseId}`);
        },
    };

    const [modalValues, setModalValues] = useState(initialModalState);
    const clearForm = () => {
        reset();
        setValue("txtModuleName", "")
        setHTMLContents("", message);
    };

    const submitHandler = async (data) => {
        setValue("submit", true);
        const PK = `TENANT#${props.TenantInfo.TenantID}#COURSEINFO#${courseId}`;
        let moduleId = mode == "Edit" ? router.query["ModuleID"] : "";
        if (mode != "Edit") {
            const variable = { PK: `TENANT#${props.TenantInfo.TenantID}#COURSEINFO#${courseId}`, SK: "COURSEMODULE#" };
            const response = await AppsyncDBconnection(listXlmsCourseModulesKeys, variable, props.user.signInUserSession.accessToken.jwtToken);
            let length = (response.res.listXlmsCourseModulesKeys?.items.length + 1).toString();
            while (length.length <= 5) {
                length = "0" + length;
            }
            moduleId = length;
        }
        const SK = "COURSEMODULE#" + moduleId;
        const finalStatus = "";
        const query = mode == "Edit" ? updateXlmsCourseModule : createXlmsCourseModule;
        for (let i = 1; i <= csrFetchedCourseData?.CourseActivityData.length; i++) {
            if (csrFetchedCourseData?.CourseActivityData?.[i]?.PK != undefined && csrFetchedCourseData?.CourseActivityData?.[i]?.SK != undefined) {
                const variable = {
                    input: { PK: csrFetchedCourseData?.CourseActivityData[i].PK, SK: csrFetchedCourseData?.CourseActivityData[i].SK, ModuleName: data.txtModuleName, ModifiedDate: new Date() },
                };
                if (mode == "Edit") {

                    await AppsyncDBconnection(query, variable, props.user.signInUserSession.accessToken.jwtToken);
                    if (csrFetchedCourseData?.CourseActivityData[i]?.Shard != null || csrFetchedCourseData?.CourseActivityData[i]?.Shard != undefined) {
                        for (let i = 1; i <= csrFetchedCourseData?.CourseActivityData[i]?.Shard; i++) {
                            UpdateBatch({ inn: { ...csrFetchedCourseData?.CourseActivityData[i], ...variable.input }, props: props, pk: "TENANT#" + props.TenantInfo.TenantID + "#" + i, query: createXlmsCourseManagementShardingInfo, });
                            UpdateBatch({ inn: variable.input, props: props, pk: "TENANT#" + props.TenantInfo.TenantID, query: updateXlmsCourseModule });
                        }
                    }
                }
            }
        }
        const variables = {
            input: {
                PK: PK,
                SK: SK,
                CourseID: courseId,
                CourseName: props.CourseName,
                ModuleID: moduleId,
                ModuleName: data.txtModuleName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                ModuleDescription: getContents(message),
                Shard: (csrFetchedCourseData?.CourseData?.Shard != undefined && mode == "Create") ? csrFetchedCourseData?.CourseData?.Shard : undefined,
                IsSuspend: false,
                IsDeleted: false,
                CreatedBy: mode != "Edit" ? props.user?.username : csrFetchedCourseData?.EditData?.CreatedBy,
                CreatedDate: mode != "Edit" ? new Date() : csrFetchedCourseData?.EditData?.CreatedDate,
                ModifiedBy: mode == "Edit" ? props.user?.username : csrFetchedCourseData?.EditData?.ModifiedBy,
                ModifiedDate: new Date(),
                TenantID: props.TenantInfo?.TenantID
                
            },
        };
        if (!mode == "Edit") {
            variables = { ...variables, input: { ...variables.input, ActiveActivityCount: 0, ActivityCount: 0 } };
        }
        finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        finalResponse(finalStatus);
        setValue("submit", false);

        if (finalStatus == "Success" && mode == "Create") {
            let moduleCount = (csrFetchedCourseData?.CourseData?.ModuleCount == undefined || csrFetchedCourseData?.CourseData?.ModuleCount == null) ? (csrFetchedCourseData?.ModuleData?.length < 1) ? 1 : csrFetchedCourseData?.ModuleData?.length : ~~csrFetchedCourseData?.CourseData?.ModuleCount + 1;
            let activeModuleCount = (csrFetchedCourseData?.CourseData?.ActiveModuleCount == undefined || csrFetchedCourseData?.CourseData?.ActiveModuleCount == null) ? (csrFetchedCourseData?.ModuleData?.length < 1) ? 1 : csrFetchedCourseData?.ModuleData?.length : ~~csrFetchedCourseData?.CourseData?.ActiveModuleCount + 1;

            finalStatus = (await AppsyncDBconnection(updateXlmsCourseManagementInfo,
                {
                    input:
                    {
                        PK: csrFetchedCourseData?.CourseData?.PK, SK: csrFetchedCourseData?.CourseData?.SK,
                        ModuleCount: moduleCount,
                        ActiveModuleCount: activeModuleCount
                    }
                }, props?.user?.signInUserSession?.accessToken?.jwtToken));
        }
        if (csrFetchedCourseData?.CourseData?.Shard != undefined && mode == "Create") {
            for (let i = 1; i <= csrFetchedCourseData?.CourseData?.Shard; i++) {
                const variables = {
                    input: {
                        PK: PK + "#" + i,
                        SK: SK,
                        CourseID: courseId,
                        CourseName: props.CourseName,
                        ModuleID: moduleId,
                        ModuleName: data.txtModuleName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                        ModuleDescription: getContents(message),
                        IsSuspend: false,
                        IsDeleted: false,
                        Shard: i,
                        CreatedBy: props.user?.username,
                        CreatedDate: new Date(),
                        ModifiedBy: props.user?.username,
                        ModifiedDate: new Date()
                    },
                };
                finalStatus = (await AppsyncDBconnection(createXlmsCourseManagementShardingInfo, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
                finalResponse(finalStatus);
            }
        }
    };

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            {
                path: "/CourseManagement/CourseList",
                breadcrumb: "Course Management"
            },
            {
                path: `/CourseManagement/ModulesList?CourseID=${courseId}`, breadcrumb: "Manage Course"
            },
            { path: "", breadcrumb: `${mode != "Edit" ? "Add " : "Edit "}Module` }
        ];
    }, [courseId, mode]);
    return (
        <>
            <Container>
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)}>
                    <div className="nvl-FormContent !overflow-y-visible">
                        <div className="">
                            <div className="pt-1">
                                <NVLTextbox id="txtModuleName" labelClassName="nvl-Def-Label" labelText="Module Name " type="text" title="Module Name" pattern="^\S[ a-zA-Z\d@#$_.\-\s]*" errors={errors} register={register} className="nvl-mandatory nvl-Def-Input" />
                            </div>
                        </div>
                        <div className="flex">
                            <NVLlabel text={"Module Description"} className="nvl-Def-Label"></NVLlabel>
                            <div className="px-1 -translate-y-1">
                                {/* <span className="text-red-500 text-lg">*</span> */}
                            </div>
                        </div>
                        <NVLRichTextBox id="txtModuleDescription" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} max={"250"} />
                        {/* <div className="{invalid-feedback} text-red-500 text-sm pt-2" id="desc_errors">
                            {errors?.txtModuleDescription?.message}
                        </div> */}

                        <div className="Center-Aligned-Item flex justify-center gap-3 pt-4">
                            <div>
                                <NVLButton id="btnSubmit" text={!watch("submit") ? "Save" : ""} disabled={watch("submit") ? true : false} type="submit" className={"w-32 nvl-button bg-primary text-white "}>
                                    {
                                        watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
                                    }
                                </NVLButton>
                            </div>
                            <NVLButton id="btnCancel" type="reset" text={mode == "Create" ? "Clear" : "Cancel"} onClick={() => (mode == "Create" ? clearForm() : router.push(`/CourseManagement/ModulesList?CourseID=${courseId}`))} className={"nvl-button w-28"}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default AddModule;