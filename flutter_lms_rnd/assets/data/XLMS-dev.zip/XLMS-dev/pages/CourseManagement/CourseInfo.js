import { GetDateFormat } from "@components/Common/DateFormat";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLImageUpload from "@components/Controls/NVLImageUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLRichTextBox, { getContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import CreateCategory from "@Pages/CourseManagement/CreateCategory";
import SubCategory from "@Pages/CourseManagement/SubCategory";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { WithContext as ReactTags } from "react-tag-input";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseManagementInfo } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo, listXlmsActiveCourseCategory, listXlmsCourseManagementInfo, listXlmsCourseSubCategory } from "src/graphql/queries";
import * as Yup from "yup";

function CourseInfo(props) {
    const router = useRouter();
    const [message, setMessage] = useState("");
    const [open, setOpen] = useState(false);
    const customMessage = useRef("");
    const [popupName, setPopupName] = useState("");
    const refCategory = useRef();
    const stDate = useRef();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const [errorMessage, seterrorMessage] = useState({ Video: "", Image: "" });
    useEffect(() => {
        const datasource = async () => {
            const tenantId = props.user.attributes["custom:tenantid"];
            const courseId = decodeURIComponent(String(router.query["CourseID"]));
            const mode = decodeURIComponent(String(router.query["Mode"]));
            const editData = await AppsyncDBconnection(
                getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEINFO#" + courseId, },
                props.user?.signInUserSession?.accessToken?.jwtToken
            );

            const categoryData = await AppsyncDBconnection(listXlmsActiveCourseCategory, { PK: "TENANT#" + tenantId, SK: "COURSECATEGORY#", IsDeleted: false, IsSuspend: false }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const courseData = await AppsyncDBconnection(
                listXlmsCourseManagementInfo,
                { PK: "TENANT#" + tenantId, SK: "COURSEINFO#", IsDeleted: false },
                props.user?.signInUserSession?.accessToken?.jwtToken
            );
            setCsrFetchedData({
                TenantID: tenantId,
                CategoryData: categoryData.res?.listXlmsCourseCategory?.items != undefined ? categoryData.res?.listXlmsCourseCategory?.items : [],
                CourseData: courseData?.res?.listXlmsCourseManagementInfo?.items != undefined ? courseData?.res?.listXlmsCourseManagementInfo?.items : [],
                CourseEditData: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo,
                mode: mode,
            });

        };
        datasource();
        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
        });
    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

    const [tags, setTags] = useState(csrFetchedData.CourseEditData?.keyWords ? JSON.parse(csrFetchedData.CourseEditData?.keyWords) : []);

    const [logo, setLogo] = useState({
        Logofile: csrFetchedData.CourseEditData?.CourseThumbNail,
        ImgHeight: "w-44 h-20",
        lblFile: "",
        uploadImage: "",
        TentImgUrl: csrFetchedData.CourseEditData?.CourseThumbNail,
        setimage: "",
    });

    const [fileValues, setFileValues] = useState({
        TextName: "Select File",
        FilePath: "",
        path: "",
        pathchanged: "",
    });
    const [subcategoryList, setSubcategoryList] = useState([]);
    const getSubCategory = useCallback(() => {
        const subCategoryList = [{ value: "", text: "Select" }];
        const filterCategory = subcategoryList?.filter(
            (obj) => obj?.SubCategoryName != null
        );

        filterCategory?.map((getItem) => {
            subCategoryList?.push({
                value: getItem.SubCategoryID,
                text: getItem.SubCategoryName,
            });
        });
        return subCategoryList;
    }, [subcategoryList]);

    const getCategory = useCallback(async () => {
        const categoryData = await AppsyncDBconnection(listXlmsActiveCourseCategory, { PK: "TENANT#" + props.TenantInfo?.TenantID, SK: "COURSECATEGORY#", IsDeleted: false, IsSuspend: false }, props.user?.signInUserSession?.accessToken?.jwtToken);

        const category = [{ value: "", text: "Select" }];
        const categoryFiltered =
            categoryData.res?.listXlmsActiveCourseCategory?.items?.filter(
                (obj) =>
                    !category[obj.CategoryID] &&
                    (category[obj.CategoryID] = true) && obj.SubCategoryID == undefined
            );
        categoryFiltered?.map((categoryData) => [
            category.push({
                value: categoryData.CategoryID,
                text: categoryData.CategoryName,
            }),
        ]);
        setCategoryState(() => {
            return category;
        });
    }, [props.user?.signInUserSession?.accessToken?.jwtToken, props.TenantInfo?.TenantID]);

    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/CourseManagement/CourseList");
        },
    };

    const [modalValues, setModalValues] = useState(initialModalState);


    const validationSchema = Yup.object().shape({
        txtCourseName: Yup.string()
            .required("Course name is required")
            .matches(
                Regex("AlphanumSpecialCharModified"),
                "Enter Course Valid name"
            )
            .max(250, "Maximum length exceeded 250")
            .test("", "", (e, { createError }) => {
                const existingCourseName = Object.values(csrFetchedData.CourseData).filter(
                    (data) => {
                        return data.CourseName.toLowerCase() == e.toLowerCase();
                    }
                );

                if (existingCourseName?.[0]?.CourseName != undefined &&
                    e?.toLowerCase() != csrFetchedData.CourseEditData?.CourseName?.toLowerCase()) {

                    return createError({ message: "Course name already exists" });
                }

                return true;
            })
            .nullable(),
        RichTextBox: Yup.string().nullable(),
        ddlCategory: Yup.string()
            .required("Category is required")
            .nullable()
            .test("NOValid", "", async (e) => {
                if (e == "") return setSubcategoryList([]);
                refCategory.current = e;
                const query = listXlmsCourseSubCategory, variables = { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSECATEGORY#" + e, IsDeleted: false, };
                const finalResponseCourse = await AppsyncDBconnection(query, variables, props.user?.signInUserSession?.accessToken?.jwtToken);
                const subCategoryData = finalResponseCourse?.res?.listXlmsCourseSubCategory?.items;
                setSubcategoryList(subCategoryData);
                return true;
            }),
        ddlSubCategory: Yup.string(),
        ddlBatch: Yup.string().nullable(),
        txtCourseValidity: Yup.string()
            .notRequired()
            .test("", "", (val) => {
                if (val == "" || val == undefined || val == null) {
                    return true;
                }
                const limitedTime = 999;
                const rejax = new RegExp(/^[0-9]+$/);
                if (!rejax.test(val)) {
                    setValue("Error", "Course Validity should be Numbers Only");
                }
                else if (val < 1) {
                    setValue("Error", "Course Validity should not be less than 1");

                }
                else if (val > limitedTime) {
                    setValue("Error", "Course Validity should not exceed more than 3 digits");
                }
                else if (parseInt(val) <= 0) {
                    setValue("Error", "Duration only positive values and more then zero`");
                }
                else if (val?.length == "1") {
                    setValue("Error", "");
                    return true;
                }
                else {
                    setValue("Error", "");
                    return true;
                }

            }).nullable(),
        txtstdate: Yup.string()
            .nullable()
            .notRequired()
            .test("Check", "Course can be created only for present and future date",
                (e) => {
                    if (e == "" || e == undefined || e == null) {
                        return true;
                    }
                    else {
                        if (new Date(e) > new Date(new Date().setDate(new Date().getDate() - 1))) {
                            if ((stDate.current != e) && (watch("chkEndDateEnable") != undefined && watch("chkEndDateEnable"))
                                && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
                                stDate.current = e;
                                setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true });
                            } else {
                                clearErrors(["txtEnddate"]);
                            }
                            return true;
                        }
                        else {
                            return false;
                        }
                    }

                }).nullable(true),

        txtEnddate: Yup.date()
            .when("chkEndDateEnable", {
                is: true,
                then: Yup.date().test("error", "End Date must be greater than or equal to the start date", (e) => {
                    if (e > new Date(watch("txtstdate"))) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }).required("End Date is Required").typeError("End Date is invalid Value").nullable(),
                otherwise: Yup.date().test("novalid", "noError", e => {
                    if (watch("chkCutDateEnable")) {
                        setValue("chkCutDateEnable", false);
                    }
                    if (e != undefined) {
                        setValue("txtEnddate", undefined);
                    }
                    if (watch("txtCutdate") != undefined) {
                        setValue("txtCutdate", undefined);
                    }
                    else if (errors?.txtEnddate != undefined) {
                        clearErrors(["txtEnddate", "txtCutdate"]);
                    }
                    return true;
                }).nullable(true)
            })
            .nullable(true),


        ReactTags: Yup.string()
            .nullable(),
        chkViewTheActivity: Yup.bool().nullable(),
        chkCompleteTheActivity: Yup.bool().nullable(),
        txtHours: Yup.string()
            .notRequired()
            .max(3, "Total Hours should not exceed more than 3 characters")
            .test("error", "", (val, { createError }) => {
                if (val == undefined || val == "" || val == null) {
                    return true;
                }
                const limitedTime = 999;
                const rejax = new RegExp(/^[0-9]+$/);
                if (!rejax.test(val)) {
                    return createError({ message: "Total Hours should be Numbers Only" });
                }
                if (val < 1) {
                    return createError({ message: "Total Hours should not be less than 1" });
                }
                else if (val > limitedTime) {
                    return createError({ message: "Total Hours should not exceed more than 3 characters" });;
                }
                return true;
            })
            .nullable(),
        File: Yup.string()
            .test("file_Error", "", (e, { createError }) => {
                if (e == "Error") {
                    return createError({ message: "Server Error Please Try Again" });
                }
                return true;
            })
            .nullable(),
        imageControl: Yup.string()
            .test("Image_Error", "", (e, { createError }) => {
                if (e == "Error") {
                    return createError({ message: "Server Error Please Try Again" });
                }
                return true;
            })
            .nullable(),
    });

    const dateCoversion = (date) => {
        const dateTime = new Date(date);
        const dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + (dateTime.getDate() < 10 ? "0" + dateTime.getDate() : dateTime.getDate());
        const splitdate = dateTimeString;
        return splitdate;
    };
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, formState, clearErrors } = useForm(formOptions);

    const { errors } = formState;
    useEffect(() => {
        if (csrFetchedData.mode == "Create") setValue("rbCompletiontracking", "false");
        setValue("chkStartDateEnable", true);
        setValue("txtstdate", dateCoversion(new Date()))
    }, [csrFetchedData.mode, props, setValue]);
    useEffect(() => {
        if (csrFetchedData.CourseEditData?.CategoryID == watch("ddlCategory") && subcategoryList?.length != 0) {
            setValue("ddlSubCategory", csrFetchedData.CourseEditData?.SubCategoryID);
        }
    }, [csrFetchedData.CourseEditData?.CategoryID, csrFetchedData.CourseEditData?.SubCategoryID, subcategoryList?.length, props, setValue, watch]);

    const finalResponse = useCallback((FinalStatus) => {
        document?.activeElement?.blur();
        if (FinalStatus != "Success") {
            document.getElementById("btnSave")?.setAttribute("disabled", "false");
            document.getElementById("btnCancel")?.setAttribute("disabled", "false");
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        } else {
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => router.push("/CourseManagement/CourseList"),
            });
            ModalOpen();
        }
    }, [router]);

    const keyCodes = {
        comma: 188,
        enter: 13,
        tab: 9,
    };

    const delimiters = useMemo(() => {
        return [keyCodes.comma, keyCodes.enter, keyCodes.tab];
    }, [keyCodes.comma, keyCodes.enter, keyCodes.tab]);

    const visibility = [
        { value: "", text: "Show" },
        { value: "Hide", text: "Hide" },
    ];

    const fileValidation = useCallback(
        async (e, mode) => {
            if (e.target.files.length == 0) {
                return;
            }
            const file = e.target.files[0];

            if (mode == "Video") {
                setValue("File", "Uploading");
                const fileInput = document.getElementById("getFile");
                const extension = e.target?.files[0]?.name
                    ?.substring(e.target.files[0].name.lastIndexOf(".") + 1)
                    .toLowerCase();
                if (
                    process.env.COURSE_VIDEO_EXTENTION.indexOf(extension) <= -1 ||
                    fileInput == null
                ) {
                    fileInput.value = "";
                    setFileValues({
                        ...fileValues,
                        TextName: "Select File",
                        FilePath: "",
                    });
                    seterrorMessage({ ...errorMessage, Video: "Invalid file type" })
                    setValue("File", "");
                    // setValue("File", "fileType", { shouldValidate: true });
                    return false;
                } else if (file.size > process.env.COURSE_VIDEO_SIZE) {
                    fileInput.value = "";
                    setFileValues({
                        ...fileValues,
                        TextName: "Select File",
                        FilePath: "",
                    });
                    seterrorMessage({ ...errorMessage, Video: "File size should not exceed 1GB" })
                    setValue("File", "");
                    // setValue("File", "fileSize", { shouldValidate: true });
                    return false;
                }
            } else if (mode == "ThumbNail") {
                setValue("imageControl", "Upload");
                const extension = e.target.files[0].name
                    .substring(e.target.files[0].name.lastIndexOf(".") + 1)
                    .toLowerCase();

                if (process.env.COURSE_THUMBNAIL_EXTENTION.indexOf(extension) <= -1) {
                    setLogo({
                        ...logo,
                        Logofile: null,
                        lblFile: "Please upload only .jpg, .jpeg, .png file!",
                    });
                    seterrorMessage({ ...errorMessage, Image: "Invalid file type" })
                    setValue("imageControl", "");
                    // setValue("imageControl", "Wrong_Format", { shouldValidate: true });
                    return false;

                } else if (file.size > process.env.COURSE_THUMBNAIL_SIZE) {
                    setLogo({
                        ...logo,
                        Logofile: null,
                        lblFile: "File size should be 128MB",
                    });
                    seterrorMessage({ ...errorMessage, Image: "File size should be 128MB" })
                    setValue("imageControl", "");
                    // setValue("imageControl", "Thumbnail_size", {
                    //     shouldValidate: true,
                    // });
                    return false;
                }
            }
            uploadFile(e, mode);
        },
        [uploadFile, setValue, fileValues, errorMessage, logo]
    );
    const uploadFile = useCallback(
        (e, mode) => {
            const file = e.target.files[0];
            const csvReader = new FileReader();

            csvReader.onload = async function () {
                const fetchURL =
                    process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
                    `?FileName=${e.target.files[0].name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ManagementType=CourseManagement&CourseType=${mode}&Type=Course`;

                const headers = {
                    method: "GET",
                    headers: {
                        authorizationToken: await Auth.currentSession().then((s) =>
                            s.getAccessToken().getJwtToken()
                        ),
                        defaultrole: props.TenantInfo.UserGroup,
                        groupmenuname: "CourseManagement",
                        menuid: "300406",
                    },
                };

                const imageExtension = ["jpg", "jpeg", "png"];
                const videoExtension = ["mp4", "mkv", "webm", "avi", "mov", "wmv"];
                const extension = e.target.value
                    .substring(e.target.value.lastIndexOf(".") + 1)
                    .toLowerCase();
                const contentType =
                    imageExtension.indexOf(extension) >= 0
                        ? "image/" + extension
                        : videoExtension.indexOf(extension) >= 0
                            ? extension == "mkv"
                                ? "video/x-matroska"
                                : extension == "avi"
                                    ? "video/x-ms-video"
                                    : extension == "mov"
                                        ? "video/quicktime"
                                        : extension == "wmv"
                                            ? "x-ms-wmv"
                                            : "video/" + extension
                            : "application/" + extension;

                const presignedHeader = {
                    method: "PUT",
                    headers: {
                        "content-type": contentType,
                        authorizationToken: await Auth.currentSession().then((s) =>
                            s.getAccessToken().getJwtToken()
                        ),
                        defaultrole: props.TenantInfo.UserGroup,
                        groupmenuname: "CourseManagement",
                        menuid: "300406",
                    },
                    body: file,
                };
                const finalStatus = await APIGatewayPutRequest(
                    fetchURL,
                    headers,
                    presignedHeader
                );

                if (mode == "Video") {
                    if (finalStatus[0] != "Success") {
                        setFileValues({
                            ...fileValues,
                            TextName: "Select File",
                            FilePath: "",
                            pathchanged: false,
                            setfile: "",
                        });
                        setValue("File", "Error", { shouldValidate: true });
                        return;
                    } else {
                        seterrorMessage({ ...errorMessage, Video: "" });
                        setFileValues({
                            TextName: e.target.files[0].name,
                            FilePath: finalStatus[1],
                            path: finalStatus[1],
                            pathchanged: true,
                            setfile: "Video",
                        });
                        setValue("File", "exist", { shouldValidate: true });
                    }
                } else {
                    if (finalStatus[0] == "Success") {
                        seterrorMessage({ ...errorMessage, Image: "" });
                        setLogo({
                            Logofile: file,
                            lblFile: "",
                            ImgHeight: "w-44 h-20",
                            uploadImage: file,
                            TentImgUrl: finalStatus[1],
                            setimage: "Image",
                        });
                        setValue("imageControl", "Image", { shouldValidate: true });
                    } else {
                        setValue("imageControl", "Error", { shouldValidate: true });
                        setLogo({
                            Logofile: null,
                            ImgHeight: "",
                            lblFile: "",
                            uploadImage: "",
                            TentImgUrl: null,
                        });

                        return;
                    }
                }
            };
            csvReader.readAsText(file);
        },
        [errorMessage, fileValues, props.TenantInfo.BucketName, props.TenantInfo.RootFolder, props.TenantInfo.TenantID, props.TenantInfo.UserGroup, setValue]
    );

    const removeImg = () => {
        setValue("imageControl", "", { shouldValidate: true });
        setLogo({
            Logofile: null,
            lblFile: "",
            ImgHeight: "",
            uploadImage: null,
            TentImgUrl: null,
        });
        setValue("imageControl", "");
    };

    const DateTime = useCallback(({ errors, register, setValue, watch }) => {
        const today = new Date();
        const dateTime =
            today.getFullYear() +
            "-" +
            (today.getMonth() + 1 >= 10
                ? today.getMonth() + 1
                : "0" + (today.getMonth() + 1)) +
            "-" +
            (today.getDate() < 9 ? "0" + today.getDate() : today.getDate());


        if (!watch("chkStartDateEnable")) {
            if (watch("chkStartDateEnable"))
                setValue("chkStartDateEnable", false, { shouldValidate: true });
            if (!(watch("txtstdate") == undefined))
                setValue("txtstdate", undefined, { shouldValidate: true });

            if (watch("chkEndDateEnable"))
                setValue("chkEndDateEnable", false, { shouldValidate: true });

            if (!(watch("txtEnddate") == undefined))
                setValue("txtEnddate", undefined, { shouldValidate: true });
        } else if (!watch("chkEndDateEnable")) {
            if (!(watch("txtEnddate") == undefined)) {
                setValue("txtEnddate", undefined, { shouldValidate: true });
            }
        }
        return (
            <div className="grid">
                <div className="flex">
                    <div className="pb-4">
                        <NVLlabel text="Start Date" className="nvl-Def-Label"></NVLlabel>
                        <NVLTextbox
                            id="txtstdate"
                            title="Start Date"
                            type="date"
                            tabIndex={!watch("chkStartDateEnable") ? "1" : "0"}
                            className={
                                !watch("chkStartDateEnable")
                                    ? "Disabled nvl-Def-Input"
                                    : "nvl-Def-Input"
                            }
                            min={dateTime}
                            disabled={!watch("chkStartDateEnable")}
                            setValue={setValue}
                            errors={errors}
                            register={register}
                        ></NVLTextbox>
                    </div>

                    <div className="translate-y-8 translate-x-8 hidden">
                        <NVLCheckbox
                            text="Enable"
                            id="chkStartDateEnable"
                            errors={errors}
                            register={register}
                        ></NVLCheckbox>
                    </div>
                </div>

                <div className="flex">
                    <div className="">
                        <NVLlabel text="End Date" className="nvl-Def-Label"></NVLlabel>
                        <NVLTextbox
                            title="End Date"
                            id="txtEnddate"
                            type="date"
                            tabIndex={!watch("chkEndDateEnable") ? "1" : "0"}
                            className={
                                !watch("chkEndDateEnable")
                                    ? "Disabled nvl-Def-Input"
                                    : "nvl-Def-Input"
                            }
                            min={dateTime}
                            disabled={!watch("chkEndDateEnable")}
                            errors={errors}
                            register={register}
                            setValue={setValue}
                        ></NVLTextbox>
                    </div>
                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox
                            text="Enable"
                            id="chkEndDateEnable"
                            disabled={!watch("chkStartDateEnable")}
                            errors={errors}
                            register={register}
                        ></NVLCheckbox>
                    </div>
                </div>
            </div>
        );
    }, []);

    const handleDelete = useCallback(
        (i) => {
            setTags(tags.filter((tag, index) => index !== i));
            setValue("ReactTags", "Delete", { shouldValidate: true });
        },
        [setTags, setValue, tags]
    );
    const handleAddition = useCallback(
        (tag) => {
            setTags([...tags, tag]);
            setValue("ReactTags", "Add", { shouldValidate: true });
        },
        [setTags, setValue, tags]
    );
    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags, setTags]
    );

    const ReactTagsButton = useCallback(() => {
        const count = Object.keys(errors);
        let focus = false;
        if (count.length == 1 && count[0] == "ReactTags") {
            focus = true;
        }
        return (
            <>
                <div className="nvl-FormContent">
                    <NVLlabel text="Keywords" className="pt-2 nvl-Def-Label pb-2" />
                    <ReactTags
                        id="rcttags"
                        autofocus={focus}
                        inline
                        allowUnique
                        tags={tags}
                        placeholder={"Type and Press Enter to add new keywords "}
                        title="E.g : xx,yy"
                        delimiters={delimiters}
                        handleDelete={handleDelete}
                        handleAddition={handleAddition}
                        handleDrag={handleDrag}
                        inputFieldPosition="top"
                    />
                    <div className="{invalid-feedback} text-red-500 text-sm">
                        {errors?.ReactTags?.message}
                    </div>
                </div>
            </>
        );
    }, [errors, delimiters, handleAddition, handleDelete, handleDrag, tags]);
    const [categoryState, setCategoryState] = useState(() => {
        if (csrFetchedData.CategoryData != undefined) {
            const category = [{ value: "", text: "Select" }];
            const categoryFiltered = csrFetchedData.CategoryData?.filter(
                (obj) => !category[obj.CategoryID] && (category[obj.CategoryID] = true)
            );
            categoryFiltered.map((categoryData) => [
                category.push({
                    value: categoryData.CategoryID,
                    text: categoryData.CategoryName,
                }),
            ]);
            return category;
        }
    });
    const getComponent = useCallback((PopupName) => {

        const componentData = {
            Category: (
                <CreateCategory
                    Mode="Popup"
                    setOpen={setOpen}
                    open={open}
                    user={props?.user}
                    TenantInfo={props.TenantInfo}
                    CategoryData={csrFetchedData.CategoryData}
                />
            ),
            SubCategory: (
                <SubCategory
                    Mode="Popup"
                    setOpen={setOpen}
                    open={open}
                    user={props?.user}
                    TenantInfo={props.TenantInfo}
                    CategoryData={categoryState}
                />
            ),
        };
        return componentData[PopupName];
    },
        [open, props?.user, props.TenantInfo, csrFetchedData.CategoryData, categoryState]
    );

    const submitHandler = async (data) => {
        setValue("submit", true);
        seterrorMessage({ ...errorMessage, Video: "", Image: "" })
        document.getElementById("btnSave")?.setAttribute("disabled", "true");
        document.getElementById("btnCancel")?.setAttribute("disabled", "true");
        const PK = "TENANT#" + props.TenantInfo.TenantID;
        const courseId = crypto.randomUUID().toString(25).substring(2, 12);
        const SK = "COURSEINFO#" + courseId;
        let finalResult, thumbNailUrl, videoUrl;

        if (logo.setimage == "Image") {
            const fetchURL =
                process.env.ACTIVITY_UNSAVED_TO_SAVED +
                `?FileName=${logo.Logofile.name}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ManagementType=CourseManagement&Type=Course&CourseType=ThumbNail&CourseID=${courseId}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationToken: await Auth.currentSession().then((s) =>
                        s.getAccessToken().getJwtToken()
                    ),
                    defaultrole: props.TenantInfo.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300406",
                },
            };

            finalResult = await APIGatewayGetRequest(fetchURL, headers);
            thumbNailUrl = await finalResult?.res?.text();
        }

        if (fileValues.setfile == "Video") {
            const fetchURL =
                process.env.ACTIVITY_UNSAVED_TO_SAVED +
                `?FileName=${fileValues.TextName}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ManagementType=CourseManagement&Type=Course&CourseType=Video&&CourseID=${courseId}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationToken: await Auth.currentSession().then((s) =>
                        s.getAccessToken().getJwtToken()
                    ),
                    defaultrole: props.TenantInfo.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300406",
                },
            };
            finalResult = await APIGatewayGetRequest(fetchURL, headers);

            videoUrl = await finalResult?.res?.text();
        }

        function getCategoryName() {
            const categoryName = categoryState.filter(item => {
                return item.value == refCategory.current;
            });
            return categoryName?.[0].text;
        }

        const startdate = data?.txtstdate == undefined || data?.txtstdate == "" ? new Date() : GetDateFormat(data?.txtstdate, "±YYYYYY-MM-DDTHH:mm:ss");
        const enddate = data?.txtEnddate == undefined ? "" : GetDateFormat(data?.txtEnddate, "±YYYYYY-MM-DDTHH:mm:ss");

        const query = createXlmsCourseManagementInfo;
        const variables = {
            input: {
                PK: PK,
                SK: SK,
                TenantID: props?.TenantInfo?.TenantID,
                CourseName: data.txtCourseName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                CourseDescription: getContents(message),
                CourseID: courseId,
                CategoryID: watch("ddlCategory"),
                CategoryName: getCategoryName(),
                SubCategoryID: watch("ddlSubCategory"),
                SubCategoryName: document.getElementById("ddlSubCategory")?.options[document.getElementById("ddlSubCategory")?.selectedIndex]?.text,
                DateTime: watch("chkStartDateEnable") != false ? startdate : new Date(),
                EndDateTime: watch("chkEndDateEnable") != false ? enddate : "",
                TotalHours: data.txtHours * 60,
                CourseValidity: data.txtCourseValidity,
                CourseVisibility: watch("ddlVisibility"),
                CourseThumbNail: thumbNailUrl,
                CourseIntroVideo: videoUrl,
                keyWords: JSON.stringify(tags),
                IsSelfDisable: true,
                IsDeleted: false,
                IsSuspend: false,
                CreatedDate: new Date(),
                CreatedBy: props.user.username,
            },
        };



        const finalStatus = (
            await AppsyncDBconnection(query, variables, props.user?.signInUserSession?.accessToken?.jwtToken)
        ).Status;
        finalResponse(finalStatus);
        setOpen((open) => {
            return !open;
        });
        document.getElementById("divPageModal")?.classList?.add("hidden");
        setValue("submit", false);
    };

    useEffect(() => {
        if ((open != 0 && open % 2 == 0) || !open) {
            getCategory();
            setValue("ddlCategory", "");
        }
    }, [getCategory, open, csrFetchedData.mode, setValue]);

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            {
                path: "/CourseManagement/CourseList",
                breadcrumb: "Course Management"
            },
            { path: "", breadcrumb: csrFetchedData.mode == "Edit" ? "Edit Setting" : "Create Course" }
        ];
    }, [csrFetchedData.mode]);
    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedData.TenantID == undefined}>
                <NVLPageModalPopup
                    ModalType="Page"
                    ScreenName={`Create ${popupName}`}
                    PageComponent={getComponent(popupName)}
                    open={open}
                    setOpen={setOpen}
                />
                <form onSubmit={handleSubmit(submitHandler)} className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : ""}`}>

                    <NVLAlert
                        ButtonYestext={"X"}
                        MessageTop={modalValues.ModalTopMessage}
                        MessageBottom={modalValues.ModalBottomMessage}
                        ModalOnClick={modalValues.ModalOnClickEvent}
                        ModalInfo={modalValues.ModalInfo}
                    />
                    <div className="nvl-FormContent">
                        <div className="pt-4">
                            <NVLTextbox
                                labelText="Course Name"
                                labelClassName="nvl-Def-Label pb-1"
                                id="txtCourseName"
                                title="Course Name"
                                className="nvl-mandatory"
                                max={"50"}
                                errors={errors}
                                register={register}
                            />
                        </div>
                        <div className="pt-4">
                            <NVLlabel
                                text="Course Description"
                                className="nvl-Def-Label pb-1"
                            ></NVLlabel>
                            <NVLRichTextBox
                                id="txtCourseDescription"
                                className="isResizable nvl-non-mandatory nvl-Def-Input"
                                setState={setMessage}
                                max={"250"}
                            />
                        </div>

                        <NVLSelectField
                            id="ddlCategory"
                            labelText="Select Category"
                            labelClassName="nvl-Def-Label pb-1"
                            errors={errors}
                            register={register}
                            options={categoryState}
                            className={`w-96 nvl-mandatory`}
                        />
                        <div className="text-right">
                            <NVLButton
                                id="btncreateCategory"
                                ButtonType="link"
                                type={"button"}
                                text=" + Create Category"
                                onClick={() => {
                                    setPopupName("Category");
                                    setOpen((open) => {
                                        return open + 1;
                                    });
                                }}
                            />
                        </div>

                        <NVLSelectField
                            id="ddlSubCategory"
                            labelText="Select SubCategory"
                            labelClassName="nvl-Def-Label pb-1"
                            errors={errors}
                            register={register}
                            options={getSubCategory()}
                            className={`w-96 nvl-non-mandatory`}
                        />
                        <div className="text-right">
                            <NVLButton
                                id="btncreateSubCategory"
                                ButtonType="link"
                                type={"button"}
                                text=" + Create SubCategory"
                                onClick={() => {
                                    setPopupName("SubCategory");
                                    setOpen((open) => {
                                        return open + 1;
                                    });
                                }}
                            />
                        </div>
                        <NVLlabel />
                        <DateTime
                            errors={errors}
                            register={register}
                            watch={watch}
                            setValue={setValue}
                        />
                        <div>
                            <NVLlabel
                                text="Course Validity"
                                className="nvl-Def-Label pb-1 pt-2"
                                HelpInfo={"Course validity should be in Days"}
                                HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"}
                            />
                            <NVLTextbox
                                id="txtCourseValidity"
                                title="Course Validity"
                                className="nvl-non-mandatory"
                                errors={errors}
                                register={register}
                            />
                            {watch("Error") != "" && watch("Error") != undefined && <div className="{invalid-feedback}   text-red-500 text-sm ">{watch("txtCourseValidity") ? watch("Error") : ""}</div>}
                        </div>
                        <div className="pt-1">
                            <div className="pb-2">
                                <NVLlabel
                                    text="Course Intro Video"
                                    className="nvl-Def-Label"
                                    HelpInfo={`${"Acceptable file format: .mp4,.mkv,.webm,.avi,.mov,.wmv.<br>File size should not exceed more than 1 GB"}`}
                                    HelpInfoIcon={"fa fa-solid fa-circle-question"}
                                />
                            </div>
                            <NVLFileUpload
                                id="getFile"
                                text={
                                    fileValues.TextName == null
                                        ? "Select File"
                                        : fileValues.TextName?.length > 20
                                            ? fileValues.TextName?.substring(0, 20) + "..."
                                            : fileValues.TextName
                                }
                                onChange={(e) => fileValidation(e, "Video")}
                            ></NVLFileUpload>
                            <NVLLoader
                                className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"
                                    }`}
                                id="loader"
                            />
                            <div className={" {invalid-feedback} text-red-500 text-sm "}>
                                {errorMessage.Video ?? errors?.File?.message}
                            </div>
                        </div>
                        <div>
                            <NVLlabel
                                text="Total hours"
                                className="nvl-Def-Label pb-1 pt-2"
                            />
                            <NVLTextbox
                                id="txtHours"
                                title="Course Hours"
                                className="nvl-non-mandatory"
                                errors={errors}
                                register={register}
                            />
                        </div>
                        <div className="pb-2">
                            <NVLlabel text="Visiblity" className="nvl-Def-Label pb-1 pt-2" />
                            <NVLSelectField
                                id="ddlVisibility"
                                errors={errors}
                                options={visibility}
                                register={register}
                                className="w-96 nvl-non-mandatory"
                            />
                        </div>
                        <NVLlabel
                            text="Upload ThumbNail"
                            className="nvl-Def-Label"
                            HelpInfo={`${"Acceptable file format: jpg, png, jpeg.<br>File size should not exceed more than 128Mb"}`}
                            HelpInfoIcon={"fa fa-solid fa-circle-question"}
                        />
                        <NVLImageUpload
                            watch={watch}
                            control={"imageControl"}
                            accept={".jpg,.png,.jpeg"}
                            text={"Upload Thumbnail"}
                            Logofile={logo.Logofile}
                            uploadImage={logo.uploadImage}
                            ImgHeight={logo.ImgHeight}
                            UploadLogo={(e) => fileValidation(e, "ThumbNail")}
                            removeImg={removeImg}
                        />
                        <div className="{invalid-feedback} text-red-500 text-xs pt-1">
                            {errorMessage.Image ?? errors?.imageControl?.message}
                        </div>
                        <ReactTagsButton tags={tags} />
                        <div className=" text-red-500  text-sm" id="chkbox">
                            <span>{customMessage.current}</span>
                        </div>
                    </div>
                    <div className="flex justify-center gap-1 pt-2" id="divButton">
                        <NVLButton
                            id="btnSave"
                            text={(!watch("submit") || watch("File") == "Uploading" ||
                                watch("imageControl") == "Upload") ? "Submit" : ""}
                            type={"submit"}
                            className={`w-32 nvl-button bg-primary text-white ${(watch("File") == "Uploading" || watch("submit")) ? "pointer-events-none" : ""} 
              ${watch("submit") ? "pointer-events-none" : ""}`}>
                            {watch("submit") && (<i className="fa fa-circle-notch fa-spin mr-2"></i>)}
                        </NVLButton>
                        <NVLButton
                            id="btnCancel"
                            text={"Cancel"}
                            type="button"
                            className={`nvl-button w-28 ${(watch("File") == "Uploading" || watch("submit")) ? "nvl-button-light pointer-events-none" : ""} 
              ${watch("submit") ? "nvl-button-light pointer-events-none" : ""}`}
                            onClick={() => router.push("/CourseManagement/CourseList")}
                        ></NVLButton>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CourseInfo;