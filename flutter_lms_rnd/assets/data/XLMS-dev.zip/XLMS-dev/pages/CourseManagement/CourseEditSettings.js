import { GetDateFormat } from "@components/Common/DateFormat";
import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLImageUpload from "@components/Controls/NVLImageUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import CreateBatch from "@Pages/CourseManagement/CreateBatch";
import CreateCategory from "@Pages/CourseManagement/CreateCategory";
import SubCategory from "@Pages/CourseManagement/SubCategory";
import { Auth } from "aws-amplify";
import { UpdateBatch } from "BatchPutItem/BatchUpdate";
import { APIGatewayGetRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { WithContext as ReactTags } from "react-tag-input";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseManagementInfo, createXlmsCourseManagementShardingInfo, updateXlmsCourseBatch, updateXlmsCourseManagementInfo } from "src/graphql/mutations";
import { getXlmsCourseManagementInfo, listXlmsCourseBatchInfos, listXlmsCourseCategory, listXlmsCourseManagementInfo, listXlmsCourseSubCategory } from "src/graphql/queries";
import * as Yup from "yup";
function CourseEditSetting(props) {
    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    const [logo, setLogo] = useState({});
    const stDate = useRef();
    const [fileValues, setFileValues] = useState({});
    const isSub = useRef();
    const [errorMessage, seterrorMessage] = useState({ Video: "", Image: "" });

    useEffect(() => {
        const dataSource = async () => {
            const tenantId = props.user.attributes["custom:tenantid"];
            const courseId = decodeURIComponent(String(router.query["CourseID"]));
            const mode = decodeURIComponent(String(router.query["Mode"]));
            const editData = await AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEINFO#" + courseId, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + tenantId + "#COURSEINFO#" + courseId, SK: "COURSEBATCH#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const defaultBatchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + tenantId + "#COURSEINFO#" + courseId, SK: "COURSEBATCH#", IsDeleted: false, BatchType: "Default" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const categoryData = await AppsyncDBconnection(listXlmsCourseCategory, { PK: "TENANT#" + tenantId, SK: "COURSECATEGORY#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const courseData = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + tenantId, SK: "COURSEINFO#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            setCsrFetchedData({
                TenantID: tenantId,
                CategoryData: categoryData.res?.listXlmsCourseCategory?.items != undefined ? categoryData.res?.listXlmsCourseCategory?.items : [],
                CourseData: courseData?.res?.listXlmsCourseManagementInfo?.items != undefined ? courseData?.res?.listXlmsCourseManagementInfo?.items : [],
                BatchData: mode == "Edit" && batchData.res?.listXlmsCourseBatchInfos?.items,
                DefaultBatchData: mode == "Edit" && defaultBatchData.res?.listXlmsCourseBatchInfos?.items,
                CourseEditData: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo,
                mode: mode,
                CourseID: courseId,
            });
            setLogo({
                Logofile: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo?.CourseThumbNail == undefined ? null : mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo.CourseEditData?.CourseThumbNail,
                ImgHeight: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo?.CourseThumbNail == undefined ? "" : "w-44 h-20",
                lblFile: "",
                uploadImage: "",
                TentImgUrl: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo?.CourseThumbNail == undefined ? null : mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo?.CourseThumbNail,
                setimage: "",
            });
            setFileValues({
                TextName: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo?.CourseIntroVideo && mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo.CourseIntroVideo.substring(mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo.CourseIntroVideo.lastIndexOf("/") + 1, mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo.CourseIntroVideo.length),
                FilePath: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo?.CourseIntroVideo,
                path: mode == "Edit" && editData?.res?.getXlmsCourseManagementInfo?.CourseIntroVideo,
                pathchanged: false,
            });
        };
        dataSource();
        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
            setLogo((temp) => { return { ...temp }; });
            setFileValues((temp) => { return { ...temp }; });
        });

    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query]);
    const [message, setMessage] = useState("");
    const [open, setOpen] = useState(false);
    const [open2, setOpen2] = useState("");
    const [customMessage, setCustomMessage] = useState("");
    const [popupName, setPopupName] = useState("");
    const [tags, setTags] = useState(csrFetchedData?.CourseEditData?.keyWords ? JSON.parse(csrFetchedData?.CourseEditData?.keyWords) : []);

    const [subcategoryList, setSubcategoryList] = useState([]);

    const categoryList = useMemo(() => [{ value: "", text: "Select" }], []);
    const categoryFiltered = csrFetchedData?.CategoryData?.filter((obj) => !categoryList[obj.CategoryID] && (categoryList[obj.CategoryID] = true));
    categoryFiltered?.map((category) => [
        categoryList.push({
            value: category.CategoryID,
            text: category.CategoryName,
        }),
    ]);

    const [categoryState, setCategoryState] = useState(() => {
        const category = [{ value: "", text: "Select Category" }];
        const categoryFiltered = csrFetchedData?.CategoryData?.filter((obj) => !category[obj.CategoryID] && (category[obj.CategoryID] = true));
        categoryFiltered?.map((categoryData) => [
            category.push({
                value: categoryData.CategoryID,
                text: categoryData.CategoryName,
            }),
        ]);
        return category;
    });


    const getSubCategory = useCallback(() => {
        const subCategoryListTemp = [{ value: "", text: "Select" }];
        const filterCategory = subcategoryList?.filter((obj) => obj?.SubCategoryName != null);

        filterCategory?.map((getItem) => {
            subCategoryListTemp?.push({
                value: getItem.SubCategoryID,
                text: getItem.SubCategoryName,
            });
        });
        return subCategoryListTemp;
    }, [subcategoryList]);

    const getBatch = useCallback(async () => {
        const batchData = await AppsyncDBconnection(listXlmsCourseBatchInfos, { PK: "TENANT#" + props.TenantInfo?.TenantID + "#COURSEINFO#" + csrFetchedData?.CourseID, SK: "COURSEBATCH#", }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const batchitem = [{ value: "", text: "Select Batch" }];

        const batchFiltered = batchData?.res?.listXlmsCourseBatchInfos?.items?.filter((obj) => !batchitem[obj.BatchID] && (batchitem[obj.BatchID] = true));
        batchFiltered?.map((batch) => [batchitem.push({ ...batchitem, value: batch.BatchID, text: batch.BatchName })]);

        setBatchState(() => {
            return batchitem;
        });
    }, [props?.user?.signInUserSession?.accessToken?.jwtToken, props.TenantInfo?.TenantID, csrFetchedData?.CourseID]);

    const getCategory = useCallback(async () => {
        const categoryData = await AppsyncDBconnection(
            listXlmsCourseCategory,
            {
                PK: "TENANT#" + props.TenantInfo?.TenantID,
                SK: "COURSECATEGORY#",
                IsDeleted: false,
            },
            props?.user?.signInUserSession?.accessToken?.jwtToken
        );

        const category = [{ value: "", text: "Select" }];
        const categoryFiltered = categoryData.res?.listXlmsCourseCategory?.items?.filter((obj) => !category[obj.CategoryID] && (category[obj.CategoryID] = true) && !obj?.IsSuspend);
        categoryFiltered?.map((categoryData) => [
            category.push({
                value: categoryData.CategoryID,
                text: categoryData.CategoryName,
            }),
        ]);
        setCategoryState(() => {
            return category;
        });
    }, [props?.user?.signInUserSession?.accessToken?.jwtToken, props.TenantInfo?.TenantID]);

    const validationSchema = Yup.object().shape({
        txtCourseName: Yup.string()
            .required("Course name is required")
            .matches(Regex("AlphaNumForTopicName"), "Enter Course Valid name")
            .max(250, "Maximum length exceeded 250")
            .test("", "", (e, { createError }) => {
                const existingCourseName = Object.values(csrFetchedData?.CourseData).filter((data) => {
                    return data.CourseName.toLowerCase() == e.toLowerCase();
                });

                if (existingCourseName?.[0]?.CourseName != undefined && e?.toLowerCase() != csrFetchedData?.CourseEditData?.CourseName?.toLowerCase()) {
                    return createError({ message: "Course name already exists" });
                }
                return true;
            })
            .nullable(),
        RichTextBox: Yup.string().nullable(),
        ddlCategory: Yup.string()
            .required("Category is required")
            .nullable()
            .test("NOValid", "", async (e) => {
                if (e == "") return setSubcategoryList([]);
                const query = listXlmsCourseSubCategory,
                    variables = {
                        PK: "TENANT#" + props.TenantInfo.TenantID,
                        SK: "COURSECATEGORY#" + e,
                        IsDeleted: false,
                    };
                const finalResponseCourse = await AppsyncDBconnection(
                    query,
                    variables,
                    props?.user?.signInUserSession?.accessToken?.jwtToken
                );
                const data = finalResponseCourse?.res?.listXlmsCourseSubCategory?.items;

                isSub.current = (data?.filter((x) => x.SubCategoryID == csrFetchedData?.CourseEditData?.SubCategoryID)?.length) > 0 ? true : false;
                setSubcategoryList(data);
                return true;
            }),
        ddlSubCategory: Yup.string(),
        ddlBatch: Yup.string().nullable(),
        txtCourseValidity: Yup.string()
            .notRequired()
            .max(3, "Course Validity should not exceed more than 3 characters")
            .test("error", "", (val, { createError }) => {
                if (val == undefined || val == "" || val == null) {
                    return true;
                }
                const rejax = new RegExp(/^([1-9][0-9]{0,2})$/);
                if (!rejax.test(val)) {
                    return createError({ message: "Course Validity should be Numbers Only" });
                }
                if (val < 1) {
                    return createError({ message: "Course Validity should not be less than 1" });
                }
                return true;
            })
            .nullable(),
        txtstdate: Yup.string()
            .nullable(true)
            .notRequired().test("Check", "Course can be created only for present and future date", (e) => {
                if (e == "" || e == undefined || e == null) {
                    return true;
                }
                else {
                    if (new Date(e).toDateString() != new Date(csrFetchedData?.CourseEditData?.DateTime).toDateString()) {
                        if (new Date(e) > new Date(new Date().setDate(new Date().getDate() - 1))) {
                            if ((stDate.current != e) && (watch("chkEndDateEnable") != undefined && watch("chkEndDateEnable"))
                                && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
                                stDate.current = e;
                                setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true });
                            } else {
                                clearErrors(["txtEnddate"]);
                            }
                            return true;

                        }
                        else {
                            return false;
                        }
                    }
                    else {
                        return true
                    }
                }
            }).nullable(true),

        txtEnddate: Yup.date()
            .when("chkEndDateEnable", {
                is: true,
                then: Yup.date().test("error", "End Date must be greater than or equal to the start date", (e) => {

                    if (e > new Date(watch("txtstdate"))) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }).required("End Date is Required").typeError("End Date is invalid Value").nullable(),
            })
            .nullable(true),

        ReactTags: Yup.string().nullable(),
        chkViewTheActivity: Yup.bool().nullable(),
        chkCompleteTheActivity: Yup.bool().nullable(),
        rbCompletiontracking: Yup.string()
            .test("error", "", (e) => {
                if (e == "true") {
                    const array = ["chkViewTheActivity", "chkCompleteTheActivity"];
                    const result = [];
                    array.map((item) => {
                        result.push(watch(item));
                    });
                    if (result.indexOf(true) == -1) {
                        setCustomMessage("Choose activity Completion");
                        return false;
                    } else {
                        setCustomMessage("");
                        return true;
                    }
                } else {
                    resetData();
                    setCustomMessage("");
                }
                return true;
            })
            .nullable(),
        txtHours: Yup.string()
            .notRequired()
            .max(3, "Total Hours should not exceed more than 3 characters")
            .test("error", "", (val, { createError }) => {
                if (val == undefined || val == "" || val == null) {
                    return true;
                }
                const rejax = new RegExp(/^([1-9][0-9]{0,2})$/);
                if (!rejax.test(val)) {
                    return createError({ message: "Total Hours should be Number Only" });
                }
                if (val < 1) {
                    return createError({ message: "Total Hours should not be less than 1" });
                }
                return true;
            })
            .nullable(),
        File: Yup.string()
            .test("file_Error", "", (e, { createError }) => {
                if (e == "Error") {
                    return createError({ message: "Server Error Please Try Again" });
                }
                return true;
            })
            .nullable(),
        imageControl: Yup.string()
            .test("Image_Error", "", (e, { createError }) => {
                if (e == "Error") {
                    return createError({ message: "Server Error Please Try Again" });
                }
                return true;
            })
            .nullable(),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, formState, clearErrors } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        if (message != "") {
            message?.on("text-change", () => {
                if (
                    getContents(message) == "" ||
                    getContents(message)
                        .replaceAll(/(<([^>]+)>)/gi, "")
                        .trim().length == 0
                ) {
                    setValue("RichTextBox", "Empty", { shouldValidate: true });
                } else {
                    setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
                }
            });
        }
    }, [message, setValue]);

    const initialModalState = { ModalType: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully.", ModalOnClickEvent: () => { router.push("/CourseManagement/CourseList"); }, };
    const [modalValues, setModalValues] = useState(initialModalState);

    const resetData = () => {
        setValue("chkViewTheActivity", false);
        setValue("chkCompleteTheActivity", false);
    };

    useEffect(() => {
        const isCat = ((categoryState.filter((x) => x.value == csrFetchedData?.CourseEditData?.CategoryID)?.length > 0) ? true : false);
        if (csrFetchedData.mode != undefined || csrFetchedData.mode != null) {
            if (csrFetchedData?.mode == "Create")
                setValue("rbCompletiontracking", "false");
            if (csrFetchedData?.mode == "Edit") {
                setValue("txtCourseName", csrFetchedData?.CourseEditData?.CourseName);
                setValue("ddlCategory", isCat ? csrFetchedData?.CourseEditData?.CategoryID : "");
                setValue("ddlSubCategory", ((isCat) ? csrFetchedData?.CourseEditData?.SubCategoryID : ""));
                setValue("ddlBatch", csrFetchedData?.CourseEditData?.BatchID);
                setValue("chkPageShowOnCourse", csrFetchedData?.CourseEditData?.IsShowOnCoursePage);
                setValue("txtstdate", dateCoversion(csrFetchedData?.CourseEditData?.DateTime) == "1970-01-1" || dateCoversion(csrFetchedData?.CourseEditData?.DateTime) == "NaN-NaN-NaN" || csrFetchedData?.CourseEditData?.DateTime == null ? undefined : dateCoversion(csrFetchedData?.CourseEditData?.DateTime));
                setValue("txtEnddate", dateCoversion(csrFetchedData?.CourseEditData?.EndDateTime) == "1970-01-1" ? undefined : dateCoversion(csrFetchedData?.CourseEditData?.EndDateTime));
                setValue("chkStartDateEnable", true);
                setValue("chkEndDateEnable", csrFetchedData?.CourseEditData?.EndDateTime == undefined || csrFetchedData?.CourseEditData?.EndDateTime == "" ? false : true);
                setValue("txtCourseValidity", csrFetchedData?.CourseEditData?.CourseValidity);
                setValue("Thumbnailurl", csrFetchedData?.CourseEditData?.CourseThumbNail == undefined ? null : csrFetchedData?.CourseEditData?.CourseThumbNail);
                setValue("imageControl", csrFetchedData?.CourseEditData?.CourseThumbNail == null ? "" : "Image");
                setLogo({
                    Logofile: csrFetchedData.CourseEditData?.CourseThumbNail == undefined ? null : csrFetchedData.CourseEditData?.CourseThumbNail,
                    ImgHeight: csrFetchedData.CourseEditData?.CourseThumbNail == undefined ? "" : "w-44 h-20",
                    lblFile: "",
                    uploadImage: "",
                    TentImgUrl: csrFetchedData.CourseEditData?.CourseThumbNail == undefined ? null : csrFetchedData.CourseEditData?.CourseThumbNail,
                    setimage: "",
                });
                setValue("File", csrFetchedData?.CourseEditData?.CourseIntroVideo);
                setValue("txtHours", csrFetchedData.CourseEditData?.TotalHours == undefined || csrFetchedData.CourseEditData?.TotalHours == 0 ? null : csrFetchedData.CourseEditData?.TotalHours / 60);
                setValue("ddlVisibility", csrFetchedData?.CourseEditData?.CourseVisibility);
                setValue("rbCompletiontracking", csrFetchedData?.CourseEditData?.IsCompletionTracking == false || csrFetchedData?.CourseEditData?.IsCompletionTracking == undefined ? "false" : csrFetchedData?.CourseEditData?.IsCompletionTracking?.toString());
                setValue("chkViewTheActivity", csrFetchedData?.CourseEditData?.IsViewTheActivity);
                setValue("chkCompleteTheActivity", csrFetchedData?.CourseEditData?.IsReceivePassingGrade);
                if (csrFetchedData?.CourseEditData?.keyWords) {
                    setTags(JSON.parse(csrFetchedData?.CourseEditData?.keyWords));
                }
                if (message != "") {
                    setHTMLContents(csrFetchedData?.CourseEditData?.CourseDescription, message);
                    message?.history?.clear();
                    setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
                }
            }
        }
    }, [setValue, message, csrFetchedData.mode, csrFetchedData.CourseEditData?.CourseName, csrFetchedData.CourseEditData?.CategoryID, csrFetchedData.CourseEditData?.SubCategoryID, csrFetchedData.CourseEditData?.BatchID, csrFetchedData.CourseEditData?.IsShowOnCoursePage, csrFetchedData.CourseEditData?.DateTime, csrFetchedData.CourseEditData?.EndDateTime, csrFetchedData.CourseEditData?.CourseValidity, csrFetchedData.CourseEditData?.CourseThumbNail, csrFetchedData.CourseEditData?.CourseIntroVideo, csrFetchedData.CourseEditData?.TotalHours, csrFetchedData.CourseEditData?.CourseVisibility, csrFetchedData.CourseEditData?.IsCompletionTracking, csrFetchedData.CourseEditData?.IsViewTheActivity, csrFetchedData.CourseEditData?.IsReceivePassingGrade, csrFetchedData.CourseEditData?.keyWords, csrFetchedData.CourseEditData?.CourseDescription, csrFetchedData, categoryState]);

    useEffect(() => {
        setValue("ddlBatch", csrFetchedData?.CourseEditData?.BatchID);
    }, [csrFetchedData?.CourseEditData?.BatchID, csrFetchedData?.CourseEditData?.SubCategoryID, setValue]);

    useEffect(() => {
        if (csrFetchedData?.CourseEditData?.CategoryID == watch("ddlCategory") && subcategoryList?.length != 0) {
            setValue("ddlBatch", csrFetchedData?.CourseEditData?.BatchID);
            setValue("ddlSubCategory", ((isSub?.current) ? csrFetchedData?.CourseEditData?.SubCategoryID : ""));
        }
    }, [csrFetchedData?.CourseEditData?.BatchID, csrFetchedData?.CourseEditData?.CategoryID, csrFetchedData?.CourseEditData?.SubCategoryID, subcategoryList?.length, setValue, watch]);

    const finalResponse = useCallback((FinalStatus) => {
        document?.activeElement?.blur();

        if (FinalStatus != "Success") {
            document.getElementById("btnSave")?.setAttribute("disabled", "false");
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        } else {
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => router.push("/CourseManagement/CourseList"),
            });
            ModalOpen();
        }
    }, [router]);

    const dateCoversion = (date) => {
        const dateTime = new Date(date);
        const dateTimeString = dateTime.getFullYear() + "-" + (dateTime.getMonth() < 9 ? "0" : "") + (dateTime.getMonth() + 1) + "-" + (dateTime.getDate() < 10 ? "0" + dateTime.getDate() : dateTime.getDate());
        const splitdate = dateTimeString;
        return splitdate;
    };

    const keyCodes = {
        comma: 188,
        enter: 13,
        tab: 9,
    };

    const delimiters = useMemo(() => {
        return [keyCodes.comma, keyCodes.enter, keyCodes.tab];
    }, [keyCodes.comma, keyCodes.enter, keyCodes.tab]);

    const visibility = [
        { value: "", text: "Show" },
        { value: "Hide", text: "Hide" },
    ];

    const uploadFile = useCallback(
        (e, mode) => {
            const file = e.target.files[0];
            const csvReader = new FileReader();
            csvReader.onload = async function () {
                const fetchURL = process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${e.target.files[0].name}&TenantID=${props.TenantInfo?.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ManagementType=CourseManagement&CourseType=${mode}&Type=Course`;

                const headers = {
                    method: "GET",
                    headers: {
                        authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
                        defaultrole: props.TenantInfo.UserGroup,
                        groupmenuname: "CourseManagement",
                        menuid: "300406",
                    },
                };

                const imageExtension = ["jpg", "jpeg", "png"];
                const videoExtension = ["mp4", "mkv", "webm", "avi", "mov", "wmv"];
                const extension = e.target.value.substring(e.target.value.lastIndexOf(".") + 1).toLowerCase();
                const contentType = imageExtension.indexOf(extension) >= 0 ? "image/" + extension : videoExtension.indexOf(extension) >= 0 ? (extension == "mkv" ? "video/x-matroska" : extension == "avi" ? "video/x-ms-video" : extension == "mov" ? "video/quicktime" : extension == "wmv" ? "x-ms-wmv" : "video/" + extension) : "application/" + extension;

                const presignedHeader = {
                    method: "PUT",
                    headers: {
                        "content-type": contentType,
                        authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
                        defaultrole: props.TenantInfo.UserGroup,
                        groupmenuname: "CourseManagement",
                        menuid: "300406",
                    },
                    body: file,
                };
                const finalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);

                if (mode == "Video") {
                    if (finalStatus[0] != "Success") {
                        setFileValues({
                            ...fileValues,
                            TextName: "Select File",
                            FilePath: "",
                            pathchanged: false,
                            setfile: "",
                        });
                        setValue("File", "Error", { shouldValidate: true });
                        return;
                    } else {
                        seterrorMessage({ ...errorMessage, Video: "" });
                        setFileValues({
                            TextName: e.target.files[0].name,
                            FilePath: finalStatus[1],
                            path: finalStatus[1],
                            pathchanged: true,
                            setfile: "Video",
                        });
                        setValue("File", "exist", { shouldValidate: true });
                    }
                } else {
                    if (finalStatus[0] == "Success") {
                        seterrorMessage({ ...errorMessage, Image: "" });
                        setLogo({
                            Logofile: file,
                            lblFile: "",
                            ImgHeight: "w-44 h-20",
                            uploadImage: file,
                            TentImgUrl: finalStatus[1],
                            setimage: "Image",
                        });
                        setValue("imageControl", "Image", { shouldValidate: true });
                    } else {
                        setValue("imageControl", "Error", { shouldValidate: true });
                        setLogo({
                            Logofile: null,
                            ImgHeight: "",
                            lblFile: "",
                            uploadImage: "",
                            TentImgUrl: null,
                        });

                        return;
                    }
                }
            };
            csvReader.readAsText(file);
        },
        [errorMessage, fileValues, props.TenantInfo.BucketName, props.TenantInfo.RootFolder, props.TenantInfo?.TenantID, props.TenantInfo.UserGroup, setValue]
    );
    const fileValidation = useCallback(
        async (e, mode) => {
            if (e.target.files.length == 0) {
                return;
            }
            const file = e.target.files[0];
            if (mode == "Video") {
                setValue("File", "Uploading");
                const fileInput = document.getElementById("getFile");
                const extension = e.target?.files[0]?.name?.substring(e.target.files[0].name.lastIndexOf(".") + 1).toLowerCase();
                if (process.env.COURSE_VIDEO_EXTENTION.indexOf(extension) <= -1 || fileInput == null) {
                    fileInput.value = "";
                    setFileValues({
                        ...fileValues,
                        TextName: "Select File",
                        FilePath: "",
                    });
                    seterrorMessage({ ...errorMessage, Video: "Invalid file type" })
                    setValue("File", "");
                    // setValue("File", "fileType", { shouldValidate: true });
                    return false;
                } else if (file.size > process.env.COURSE_VIDEO_SIZE) {
                    fileInput.value = "";
                    setFileValues({
                        ...fileValues,
                        TextName: "Select File",
                        FilePath: "",
                    });
                    seterrorMessage({ ...errorMessage, Video: "File size should not exceed 1GB" })
                    setValue("File", "");
                    // setValue("File", "fileSize", { shouldValidate: true });
                    return false;
                }
            } else if (mode == "ThumbNail") {
                setValue("imageControl", "Upload");
                const extension = e.target.files[0].name.substring(e.target.files[0].name.lastIndexOf(".") + 1).toLowerCase();

                if (process.env.COURSE_THUMBNAIL_EXTENTION.indexOf(extension) <= -1) {
                    setLogo({
                        ...logo,
                        Logofile: null,
                        lblFile: "Please upload only .jpg, .jpeg, .png file!",
                    });
                    seterrorMessage({ ...errorMessage, Image: "Invalid file type" })
                    setValue("imageControl", "");
                    // setValue("imageControl", "Wrong_Format", { shouldValidate: true });
                    return false;
                } else if (file.size > process.env.COURSE_THUMBNAIL_SIZE) {
                    setLogo({
                        ...logo,
                        Logofile: null,
                        lblFile: "File size should be 128MB",
                    });
                    seterrorMessage({ ...errorMessage, Image: "File size should be 128MB" })
                    setValue("imageControl", "");
                    // setValue("imageControl", "Thumbnail_size", {
                    //     shouldValidate: true,
                    // });
                    return false;
                }
            }
            uploadFile(e, mode);
        },
        [uploadFile, setValue, fileValues, errorMessage, logo]
    );
    const removeImg = () => {
        setValue("imageControl", "", { shouldValidate: true });
        setLogo({
            Logofile: null,
            lblFile: "",
            ImgHeight: "",
            uploadImage: null,
            TentImgUrl: null,
        });

    };

    const DateTime = useCallback(({ errors, register, setValue, watch }) => {
        const today = new Date();
        const dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate());
        if (!watch("chkStartDateEnable")) {
            if (watch("chkStartDateEnable")) setValue("chkStartDateEnable", false, { shouldValidate: true });
            if (!(watch("txtstdate") == undefined)) setValue("txtstdate", undefined, { shouldValidate: true });

            if (watch("chkEndDateEnable")) setValue("chkEndDateEnable", false, { shouldValidate: true });

            if (!(watch("txtEnddate") == undefined)) setValue("txtEnddate", undefined, { shouldValidate: true });
        } else if (!watch("chkEndDateEnable")) {
            if (!(watch("txtEnddate") == undefined)) {
                setValue("txtEnddate", undefined, { shouldValidate: true });
            }
        }
        return (
            <div className="grid">
                <div className="flex">
                    <div className="pb-4">
                        <NVLlabel text="Start Date"></NVLlabel>
                        <NVLTextbox id="txtstdate" title="Start Date" type="date" tabIndex={!watch("chkStartDateEnable") ? "1" : "0"} className={!watch("chkStartDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"}
                            //min={dateTime} 
                            disabled={!watch("chkStartDateEnable")} setValue={setValue} errors={errors} register={register}></NVLTextbox>
                    </div>

                    <div className="translate-y-8 translate-x-8 hidden">
                        <NVLCheckbox text="Enable" id="chkStartDateEnable" errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>

                <div className="flex">
                    <div className="">
                        <NVLlabel text="End Date"></NVLlabel>
                        <NVLTextbox title="End Date" id="txtEnddate" type="date" tabIndex={!watch("chkEndDateEnable") ? "1" : "0"} className={!watch("chkEndDateEnable") ? "Disabled nvl-Def-Input" : "nvl-Def-Input"} 
                        //min={dateTime} 
                        disabled={!watch("chkEndDateEnable")} errors={errors} register={register} setValue={setValue}></NVLTextbox>
                    </div>
                    <div className="translate-y-8 translate-x-8">
                        <NVLCheckbox text="Enable" id="chkEndDateEnable" disabled={!watch("chkStartDateEnable")} errors={errors} register={register}></NVLCheckbox>
                    </div>
                </div>
            </div>
        );
    }, []);

    const handleDelete = useCallback(
        (i) => {
            setTags(tags.filter((tag, index) => index !== i));
            setValue("ReactTags", "Delete", { shouldValidate: true });
        },
        [setTags, setValue, tags]
    );
    const handleAddition = useCallback(
        (tag) => {
            setTags([...tags, tag]);
            setValue("ReactTags", "Add", { shouldValidate: true });
        },
        [setTags, setValue, tags]
    );
    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags, setTags]
    );

    const ReactTagsButton = useCallback(() => {
        const count = Object.keys(errors);
        let focus = false;
        if (count.length == 1 && count[0] == "ReactTags") {
            focus = true;
        }
        return (
            <>
                <div className="nvl-FormContent">
                    <NVLlabel text="Keywords" className="pt-2 nvl-Def-Label pb-2" />
                    <ReactTags id="rcttags" autofocus={focus} inline allowUnique tags={tags} placeholder={"Type and Press Enter to add new keywords "} title="E.g : xx,yy" delimiters={delimiters} handleDelete={handleDelete} handleAddition={handleAddition} handleDrag={handleDrag} inputFieldPosition="top" />
                    <div className="{invalid-feedback} text-red-500 text-sm">{errors?.ReactTags?.message}</div>
                </div>
            </>
        );
    }, [errors, delimiters, handleAddition, handleDelete, handleDrag, tags]);

    const getComponent = useCallback(
        (PopupName) => {
            const componentData = {
                Batch: <CreateBatch Mode="Popup" setOpen={setOpen} open={open} user={props?.user} TenantInfo={props.TenantInfo} CourseData={csrFetchedData?.CourseEditData} BatchData={csrFetchedData?.BatchData} />,
                Category: <CreateCategory Mode="Popup" setOpen={setOpen} open={open} user={props?.user} TenantInfo={props.TenantInfo} CategoryData={csrFetchedData?.CategoryData} />,
                SubCategory: <SubCategory Mode="Popup" setOpen={setOpen} open={open} user={props?.user} TenantInfo={props.TenantInfo} CategoryData={categoryState} />,
            };

            return componentData[PopupName];
        },
        [open, props?.user, props.TenantInfo, csrFetchedData?.CourseEditData, csrFetchedData?.BatchData, csrFetchedData?.CategoryData, categoryState]
    );
    const submitHandler = async (data) => {
        setValue("submit", true);
        seterrorMessage({ ...errorMessage, Video: "", Image: "" })
        document.getElementById("btnSave")?.setAttribute("disabled", "true");
        setValue("submit", "Submit");
        const PK = "TENANT#" + props.TenantInfo?.TenantID;
        const courseId = csrFetchedData?.mode == "Edit" ? csrFetchedData?.CourseID : crypto.randomUUID().toString(25).substring(2, 12);
        const SK = csrFetchedData?.mode == "Edit" ? csrFetchedData?.CourseEditData.SK : "COURSEINFO#" + courseId;
        let finalResult, thumbNailUrl, videoUrl;

        if (logo.setimage == "Image") {
            const fetchURL = process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${logo.Logofile.name}&TenantID=${props.TenantInfo?.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ManagementType=CourseManagement&Type=Course&CourseType=ThumbNail&CourseID=${courseId}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
                    defaultrole: props.TenantInfo.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300406",
                },
            };
            finalResult = await APIGatewayGetRequest(fetchURL, headers);

            thumbNailUrl = await finalResult?.res?.text();
        }

        if (fileValues.setfile == "Video") {
            const fetchURL = process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${fileValues.TextName}&TenantID=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&ManagementType=CourseManagement&Type=Course&CourseType=Video&&CourseID=${courseId}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
                    defaultrole: props.TenantInfo.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300406",
                },
            };
            finalResult = await APIGatewayGetRequest(fetchURL, headers);
            videoUrl = await finalResult?.res?.text();
        }

        function getCategoryName() {
            const categoryName = categoryState.filter(item => {
                return item.value == watch("ddlCategory");
            });
            return categoryName?.[0].text;
        }

        const batchId = csrFetchedData?.mode == "Edit" ? watch("ddlBatch") : "";
        const query = csrFetchedData?.mode == "Edit" ? updateXlmsCourseManagementInfo : createXlmsCourseManagementInfo;

        const startDate = data.txtstdate == null ? "" : data.txtstdate == "" ? csrFetchedData?.CourseEditData?.DateTime : GetDateFormat(data.txtstdate, "±YYYYYY-MM-DDTHH:mm:ss");
        const endDate = GetDateFormat(data.txtEnddate, "±YYYYYY-MM-DDTHH:mm:ss");
        const variables = {
            input: {
                PK: PK,
                SK: SK,
                CourseName: data.txtCourseName?.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                CourseDescription: getContents(message),
                CourseID: courseId,
                CategoryID: watch("ddlCategory"),
                CategoryName: getCategoryName(),
                SubCategoryID: watch("ddlSubCategory"),
                SubCategoryName: document.getElementById("ddlSubCategory")?.options[document.getElementById("ddlSubCategory")?.selectedIndex]?.text,
                BatchName: document.getElementById("txtBatchName")?.options[document.getElementById("txtBatchName")?.selectedIndex]?.text,
                BatchID: batchId,
                DateTime: watch("chkStartDateEnable") != false ? startDate : "",
                EndDateTime: watch("chkEndDateEnable") != false ? endDate : "",
                TotalHours: data.txtHours * 60,
                CourseValidity: data.txtCourseValidity,
                CourseVisibility: watch("ddlVisibility"),
                CourseThumbNail: logo.Logofile == null ? null : thumbNailUrl ?? csrFetchedData?.CourseEditData?.CourseThumbNail,
                CourseIntroVideo: videoUrl ?? csrFetchedData?.CourseEditData?.CourseIntroVideo,
                keyWords: JSON.stringify(tags),
                //Note: Feature they want to Completion Tracking needed.
                //IsCompletionTracking: watch("rbCompletiontracking"),
                // IsViewTheActivity: watch("rbCompletiontracking") == "true" ? data.chkViewTheActivity : false,
                // IsReceivePassingGrade: watch("rbCompletiontracking") == "true" ? data.chkCompleteTheActivity : false,
                IsDeleted: false,
                IsSuspend: false,
                LastModifiedBy: props.user.username,
                LastModifiedDate: new Date(),
            },
        };
        if (!csrFetchedData?.mode == "Edit") {
            variables = { ...variables, input: { ...variables.input, ModuleCount: 0, ActivityCount: 0, ActiveModuleCount: 0, ActiveActivityCount: 0 } }
        }
        /*Batch Update*/
        if (csrFetchedData?.CourseEditData?.Shard != null || csrFetchedData?.CourseEditData?.Shard != undefined) {
            for (let i = 1; i <= csrFetchedData?.CourseEditData?.Shard; i++) {
                UpdateBatch({ UpdateData: csrFetchedData?.CourseEditData, inn: { ...csrFetchedData.CourseEditData, ...variables.input }, pk: "TENANT#" + props?.TenantInfo?.TenantID + "#" + i, props: props, query: createXlmsCourseManagementShardingInfo });
            }
        }

        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        if (csrFetchedData?.DefaultBatchData?.["0"]?.PK != undefined) {
            let temp = { PK: csrFetchedData?.DefaultBatchData[0].PK, SK: csrFetchedData?.DefaultBatchData[0].SK, StartDate: watch("chkStartDateEnable") != false ? startDate : "" };
            if (watch("chkEndDateEnable") != false) { temp = { ...temp, EndDate: endDate }; }
            (await AppsyncDBconnection(updateXlmsCourseBatch, { input: temp }, props?.user?.signInUserSession?.accessToken?.jwtToken))
        }
        setOpen((open) => {
            return !open;
        });
        document.getElementById("divPageModal")?.classList?.add("hidden");
        setValue("submit", false);
        finalResponse(finalStatus);


    };

    const [batchState, setBatchState] = useState(() => {
        const batchData = [{ value: "", text: "Select Batch" }];
        const batchFiltered = props.Batch?.filter((obj) => !batchData[obj.BatchID] && (batchData[obj.BatchID] = true));
        batchFiltered?.map((Batch) => [Batch.push({ ...Batch, value: Batch.BatchID, text: Batch.BatchName })]);
        return batchData;
    });

    useEffect(() => {
        if ((open != 0 && open % 2 == 0) || !open) getBatch();
        getCategory();
        setValue("ddlCategory", "");
        getBatch();
    }, [getBatch, getCategory, open, setValue]);
    const createBatchPopUp = () => {
        setOpen2("By Continuing, the information in this page will not be saved. Wish to continue?");
    };
    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/CourseManagement/CourseList", breadcrumb: "Course Management" },
            { path: "", breadcrumb: csrFetchedData?.mode == "Edit" ? "Edit Settings" : "Create Course" }
        ];

    }, [csrFetchedData?.mode]);
    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedData.mode == undefined}>

                <NVLPageModalPopup ModalType="Page" ScreenName={`Create ${popupName}`} PageComponent={getComponent(popupName)} open={open} setOpen={setOpen} />
                <form onSubmit={handleSubmit(submitHandler)} noValidate className={`${watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit") ? "pointer-events-none" : ""}`}>
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className="nvl-FormContent">
                        <div className="pt-4">
                            <NVLTextbox labelText="Course Name" labelClassName="nvl-Def-Label pb-1" id="txtCourseName" title="Course Name" className="nvl-mandatory" max={"50"} errors={errors} register={register} />
                        </div>
                        <div className="pt-4">
                            <NVLlabel text="Course Description" className="nvl-Def-Label pb-1"></NVLlabel>
                            <NVLRichTextBox id="txtCourseDescription" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} />
                        </div>
                        <NVLSelectField id="ddlCategory" labelText="Select Category" labelClassName="nvl-Def-Label pb-1" errors={errors} register={register} options={categoryState} className={`w-96 nvl-mandatory`} />
                        <div className="text-right">
                            <NVLButton
                                id="btncreateCategory"
                                ButtonType="link"
                                type={"button"}
                                text=" + Create Category"
                                onClick={() => {
                                    setPopupName("Category");
                                    setOpen((open) => {
                                        return open + 1;
                                    });
                                }}
                            />
                        </div>

                        <NVLSelectField id="ddlSubCategory" labelText="Select SubCategory" labelClassName="nvl-Def-Label pb-1" errors={errors} register={register} options={getSubCategory()} className={`w-96 nvl-non-mandatory`} />
                        <div className="text-right">
                            <NVLButton
                                id="btncreateSubCategory"
                                ButtonType="link"
                                type={"button"}
                                text=" + Create SubCategory"
                                onClick={() => {
                                    setPopupName("SubCategory");
                                    setOpen((open) => {
                                        return open + 1;
                                    });
                                }}
                            />
                        </div>
                        < NVLModalPopup
                            ButtonYestext="Continue"
                            SubmitClick={() => router.push(
                                `/CourseManagement/CreateBatch?Mode=Create&BatchID=&CourseID=${csrFetchedData?.CourseID}&CourseName=${csrFetchedData?.CourseEditData?.CourseName}&CourseMode=CourseMode`
                            )}
                            CancelClick={() => setOpen2("")}
                            ButtonNotext="Cancel"
                            CloseIconEvent={() => setOpen2("")}
                            Content={open2} />

                        <NVLlabel />
                        <div className={`${csrFetchedData?.mode == "Create" ? "hidden" : ""}`}>
                            <NVLSelectField labelText="Batch Name" labelClassName="nvl-Def-Label pb-1" id="ddlBatch" errors={errors} options={batchState} register={register} className="w-96 nvl-non-mandatory" />
                            <div className="text-right">
                                <NVLButton
                                    id="btncreateBatch"
                                    ButtonType="link"
                                    type={"button"}
                                    text=" + Create Batch"
                                    onClick={() => createBatchPopUp()
                                    }
                                />
                            </div>
                        </div>
                        <DateTime errors={errors} register={register} watch={watch} setValue={setValue} />
                        <div>
                            <NVLlabel text="Course Validity" className="nvl-Def-Label pb-1 pt-2" HelpInfo={"Course validity should be in Days"} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"} />
                            <NVLTextbox id="txtCourseValidity" title="Course Validity" className="nvl-non-mandatory" errors={errors} register={register} />
                        </div>
                        <div className="pt-1">
                            <div className="pb-2">
                                <NVLlabel text="Course Intro Video" className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: .mp4,.mkv,.webm,.avi,.mov,.wmv.<br>File size should not exceed more than 1 GB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                            </div>
                            <NVLFileUpload id="getFile" text={fileValues.TextName == null ? "Select File" : fileValues.TextName?.length > 20 ? fileValues.TextName?.substring(0, 20) + "..." : fileValues.TextName} onChange={(e) => fileValidation(e, "Video")}></NVLFileUpload>
                            <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                            <div className={" {invalid-feedback} text-red-500 text-sm "}>{errorMessage.Video ?? errors?.File?.message}</div>
                        </div>
                        <div>
                            <NVLlabel text="Total hours" className="nvl-Def-Label pb-1 pt-2" />
                            <NVLTextbox id="txtHours" title="Course Hours" className="nvl-non-mandatory" errors={errors} register={register} />
                        </div>
                        <div className="pb-2">
                            <NVLlabel text="Visiblity" className="nvl-Def-Label pb-1 pt-2" />
                            <NVLSelectField id="ddlVisibility" errors={errors} options={visibility} register={register} className="w-96 nvl-non-mandatory" />
                        </div>
                        <NVLlabel text="Upload ThumbNail" className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: jpg, png, jpeg.<br>File size should not exceed more than 128Mb"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                        <NVLImageUpload watch={watch} control={"imageControl"} accept={".jpg,.png,.jpeg"} text={"Upload Thumbnail"} Logofile={logo.Logofile} uploadImage={logo.uploadImage} ImgHeight={logo.ImgHeight} UploadLogo={(e) => fileValidation(e, "ThumbNail")} removeImg={removeImg} />
                        <div className="{invalid-feedback} text-red-500 text-xs pt-1">{errorMessage.Image ?? errors?.imageControl?.message}</div>
                        <ReactTagsButton tags={tags} />

                        {/* Note: Feature they want to Completion Tracking needed.
            
            <NVLlabel className="nvl-Def-Label w-52 pb-2" text="Completion Tracking"></NVLlabel>
           
            <div className="flex gap-16">
              <NVLRadio text="Yes" value={"true"} id="rbCompletiontracking" name="rbCompletiontracking" errors={errors} register={register}></NVLRadio>
              <NVLRadio
                text="No"
                value={"false"}
                onClick={() => {
                  setCustomMessage("");
                }}
                id="rbCompletiontracking"
                name="rbCompletiontracking"
                errors={errors}
                register={register}
              ></NVLRadio>
            </div>
            <div className={`${watch("rbCompletiontracking") == "true" ? "pt-4" : " hidden"}`}>
              <NVLCheckbox showFull text="Student must View this activity to complete it" id="chkViewTheActivity" errors={errors} register={register}></NVLCheckbox>
              <NVLCheckbox showFull text="Student must receive passing grade to complete this activity" id="chkCompleteTheActivity" errors={errors} register={register}></NVLCheckbox>
            </div> 
            
            */}


                        <div className=" text-red-500  text-sm" id="chkbox">
                            <span>{customMessage}</span>
                        </div>
                    </div>
                    <div className="flex justify-center gap-1 pt-2">
                        <NVLButton
                            id="btnSave"
                            text={!watch("submit") || watch("File") == "Uploading" || watch("imageControl") == "Upload" ? "Submit" : ""}
                            disabled={watch("File") == "Uploading" || watch("imageControl") == "Upload" ? true : false}
                            type={"submit"}
                            className={`w-32 nvl-button bg-primary text-white ${watch("File") == "Uploading" || watch("imageControl") == "Upload" ? "pointer-events-none" : ""}`}
                        >
                            {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                        </NVLButton>
                        <NVLButton id="btnCancel" text={"Cancel"} disabled={watch("File") == "Uploading" || watch("imageControl") == "Upload" ? true : false} type="button" className={`nvl-button w-28 ${(watch("File") == "Uploading" || watch("submit")) ? "nvl-button-light pointer-events-none" : ""} 
              ${watch("submit") ? "nvl-button-light pointer-events-none" : ""}`} onClick={() => router.push("/CourseManagement/CourseList")}></NVLButton>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CourseEditSetting;