import { getXlmsCourseModule } from "@graphql/graphql/queries";
import ZoomAdminView from "@Pages/ActivityManagement/ZoomAdminView";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";

function AdminView(props) {
    const router=useRouter();
    const [activityData,setActivityData] = useState();
  
    useEffect(()=>{
        async function fetchData(){
            const moduleActivityData = await AppsyncDBconnection(getXlmsCourseModule, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "COURSEID#" + router.query["CourseID"] + "#MODULEID#" + router.query["ModuleID"] + "#ACTIVITYTYPE#" + router.query["ActivityType"] + "#ACTIVITYID#" + router.query["ActivityID"]
            }, props.user.signInUserSession.accessToken.jwtToken);
            setActivityData(moduleActivityData.res?.getXlmsCourseModule);
        }
        fetchData();
        return (() => {
            setActivityData((temp) => { return { ...temp }; });
        });
    },[props?.TenantInfo?.TenantID, props.user.signInUserSession.accessToken.jwtToken, router.query]);

    return (
        <><ZoomAdminView FinalData={activityData}/></>
    );
}

export default AdminView;