import Container from "@components/Container/Container";
import NVLText from "@components/Controls/NVLlabel";
import NVLHeader from "@Controls/NVLHeader";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";

function CompanyOverView(props) {
    const router = useRouter();
    const [company, setcompany] = useState();

    //CSR-Initial data load using GraphQL 
    useEffect(() => {
        const fetchData = async () => {
            const fetchUrl = process.env.COMPANYOVERVIEW;
            const tenantID = router.query["TenantID"];
            const bucketName = router.query["BucketName"];
            const rootFolder = router.query["RootFolder"];
            const updateCacheForKey = {method: "GET",headers: {"Content-Type": "application/json",authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,defaultrole: "SiteAdmin",groupmenuname: "CompanyManagement",menuid: "100301",}, };
            fetch( fetchUrl + "?TenantId=" + tenantID + "&BucketName=" + bucketName + "&RootFolder=" + rootFolder + "&S3BucketName=" + bucketName + "&S3KeyName=" + rootFolder / tenantID, updateCacheForKey)
                .then(async (response) => {
                    const companyInfo = await response.text();
                    try {const info = JSON.parse(companyInfo); setcompany(info);}
                    catch { setcompany({});}
                });
        };
        fetchData();
        return (() => { setcompany((Info) => { return { ...Info }; }); });
    
    }, [props.user.signInUserSession.accessToken.jwtToken, router.query]);

    const pageRoutes =useMemo(() => {return [{ path: "/CompanyManagement/CompanyList", breadcrumb: "Company Management" },{ path: "", breadcrumb: "Company Overview" }];},[]);
  
    return (
        <>
            <Container PageRoutes={pageRoutes} loader={company?.CompanyName == undefined} title="Company Overview">
                <NVLHeader IsSearch={false} /><div className="nvl-Cmny-OverView-Data font-medium shadow-md text-th-body-txt-color bg-gray-200 rounded gap-6 text-sm break-all">
                    <div className="flex gap-2 shadow-md p-3 rounded-md break-all "><i className="fa-solid fa-building pt-0.5 text-th-body-icon-color "></i><NVLText text="Company Name" className="  font-semibold " /></div>
                    <span className="pt-4 font-bold " ><i className="fa-solid fa-chevron-right text-th-body-icon-color"></i></span>
                    <div className="flex gap-2 shadow-lg  p-3  rounded-md break-all"><NVLText text={company?.CompanyName} className=" p-1"></NVLText></div>
                    <div className="flex gap-2 shadow-md p-3  rounded-md "><i className="fa-solid fa-user pt-0.5 text-th-body-icon-color"></i><NVLText text="Company Admin" className="  font-semibold" /></div>
                    <span className="pt-4 font-bold"><i className="fa-solid fa-chevron-right text-th-body-icon-color"></i></span>
                    <div className="flex gap-2 shadow-lg p-3 rounded-md "> <NVLText showFull={"show"} text={company?.CompanyAdminCount + " User(s)"} className=""></NVLText></div>
                    <div className="flex gap-2 shadow-md p-3  rounded-md  "><i className="fa-solid fa-users pt-0.5 text-th-body-icon-color"></i><NVLText text="Company User" className="  font-semibold"></NVLText></div>
                    <span className="pt-4 font-bold"><i className="fa-solid fa-chevron-right text-th-body-icon-color"></i></span>
                    <div className="flex gap-2 shadow-lg   p-3  rounded-md "><NVLText showFull={"show"} text={company?.EnabledUsers + " User(s)"} className=""></NVLText></div>
                    <div className="flex gap-2 shadow-md p-3 rounded-md  "><i className="fa-solid fa-book-open pt-0.5 text-th-body-icon-color"></i><NVLText text="Courses" className=" font-semibold"></NVLText></div>
                    <span className="pt-4 font-bold"><i className="fa-solid fa-chevron-right text-th-body-icon-color"></i></span>
                    <div className="flex gap-2 shadow-lg  p-3  rounded-md "><NVLText showFull={"show"} text={company?.ActiveCourseCount + " Course(s)"} className=""></NVLText></div>
                    <div className="flex gap-2 shadow-md p-3 rounded-md  "><i className="fa-solid fa-database pt-0.5 text-th-body-icon-color"></i><NVLText text="Storage" className="font-semibold"></NVLText></div>
                    <span className="pt-4 font-bold"><i className="fa-solid fa-chevron-right text-th-body-icon-color"></i></span>
                    <div className="flex gap-2 shadow-lg p-3  rounded-md "><NVLText showFull={"show"} text={company?.FolderSize + " of 1 TB used"} className=""></NVLText></div>
                    <div className="flex gap-2 shadow-md p-3 rounded-md "><i className="fa-solid fa-blog pt-0.5 text-th-body-icon-color"></i><NVLText text="Training Programs" className="  font-semibold"></NVLText></div>
                    <span className="pt-4 font-bold"><i className="fa-solid fa-chevron-right text-th-body-icon-color"></i></span>
                    <div className="flex gap-2 shadow-lg p-3   rounded-md "><NVLText text="NA" className=""></NVLText></div>
                </div>
            </Container>
        </>
    );
}

export default CompanyOverView;
