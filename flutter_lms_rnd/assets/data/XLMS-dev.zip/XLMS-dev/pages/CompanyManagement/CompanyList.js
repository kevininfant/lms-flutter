import Container from "@Container/Container";
import ChangePassword from "@Pages/UserManagement/ChangePassword";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import NVLlabel from "@components/Controls/NVLlabel";
import { onCreateXlmsTenantInfo, onUpdateXlmsTenantInfo } from "@graphql/graphql/subscriptions";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { updateXlmsTenantInfo } from "src/graphql/mutations";
import { getXlmsLoginPolicy, listXlmsTenantInfosOrderList } from "src/graphql/queries";

export default function CompanyList(props) {
  const { t } = useTranslation();
  const router = useRouter();
  const [popupValues, setPopupValues] = useState({});
  const [modalValues, setModalValues] = useState({});
  const [isRefreshing, setIsRefreshing] = useState(0);
  const [search, setSearch] = useState("");
  const [submit,setSubmit] =  useState()
  const [open, setOpen] = useState(false);
  const PasswordChange = useRef();

  const initialModalState = useMemo(()=>{
    return ({
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Password changed successfully.",
    ModalOnClickEvent: () => {
      router.push("/CompanyManagement/CompanyList")
    }})
    
   },[router])

    const [successPopup, setSuccessPopup] = useState({});
     
     const finalResponse = useCallback((finalStatus) => {
       if (finalStatus != "Success") {
           setSuccessPopup({
           ModalInfo: "Danger",
           ModalTopMessage: "Error",
           ModalBottomMessage: finalStatus,
         });
         ModalOpen();
         return;
       } else {
         setSuccessPopup(initialModalState)
         setOpen((open) => {
                 return false;
               });
           
         ModalOpen();
       }
     }, [initialModalState]);

   useEffect(() => {
       async function fetchData() {
           const loginPolicy = await AppsyncDBconnection(getXlmsLoginPolicy, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "POLICY#LOGINPOLICY" }, props.user.signInUserSession.accessToken.jwtToken);
           PasswordChange.current = { ...PasswordChange.current, LoginPolicy: loginPolicy.res?.getXlmsLoginPolicy }
       }
       fetchData();
   }, [props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken])

  
  const searchBoxVal = (e) => {
    setSearch(e); setIsRefreshing((count) => {
      return count + 1;
    });
  };

  const refreshGrid = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };

  const headerColumn = [
    { HeaderName: "Company Name", Columnvalue: "TenantDisplayName", HeaderCss: "w-2/12", },
    { HeaderName: "Company Email", Columnvalue: "EmailID", HeaderCss: "w-3/12", },
    { HeaderName: "Company Number", Columnvalue: "MobileNo", HeaderCss: "w-2/12", },
    { HeaderName: "Created Date", Columnvalue: "CreatedDate", HeaderCss: "w-2/12 whitespace-nowrap", },
    { HeaderName: "Plan Active", Columnvalue: "PlanCode", HeaderCss: "w-2/12" },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-0/12" },
    { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
  ];

  function resetPopUp() {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
  }

  function popUp(type, PK, SK, Content) {
    setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
  }

  async function updateField(e) {
    e.preventDefault();
    setSubmit(true)
    let setAPIURL = process.env.APIGATEWAY_URL_UNSUSPENDTENANT;
    let stateURL = process.env.STEP_FUNCTION_ARN_UNSUSPENDTENANT;
    let isSus = false;
    let isDelete = false;
    if (popupValues.Type == "isSuspend") {
      isSus = true;
      setAPIURL = process.env.APIGATEWAY_URL_SUSPENDTENANT;
      stateURL = process.env.STEP_FUNCTION_ARN_SUSPENDTENANT;
    }

    else if (popupValues.Type == "isDelete") {
      isDelete = true;
      const variables = { input: { PK: popupValues.PK, SK: popupValues.SK, IsDeleted: isDelete }, };
      const query = updateXlmsTenantInfo;
      const finalStatus = await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
      if (finalStatus.Status == "Success") {
        resetPopUp();
        return;
      }
      setModalValues({ ModalInfo: "Danger", ModalBottomMessage: finalStatus.Status, });
      ModalOpen();
      resetPopUp();
      return;
    }
    const jsonSaveData = '{' + '"TenantId": "' + popupValues.SK.split("#").pop() + '", "IsSuspend": ' + isSus + ' }';
    const presignedHeader =
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: "CompanyManagement",
        menuid: popupValues.Type == "isSuspend" ? "100500" : "100501",
        statemachinearn: stateURL
      },
      body: jsonSaveData,
    };

    let finalStatus = await APIGatewayPostRequest(setAPIURL, presignedHeader);
    if (finalStatus.Status == "Success") {
      let message = "";
      let variables = "";
      const query = updateXlmsTenantInfo;
      message = (popupValues.Type == "isSuspend") ? "Suspend is in progress" : "UnSuspend is in progress";
      variables = (popupValues.Type != "isSuspend") ? { input: { PK: popupValues.PK, SK: popupValues.SK, IsSuspend: false, Status: message, }, } : { input: { PK: popupValues.PK, SK: popupValues.SK, Status: message, }, };
      finalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
      if (finalStatus != "Success") {
        setModalValues({
          ModalInfo: "Danger",
          ModalBottomMessage: finalStatus,
        });
        ModalOpen();
      } else {
      }
    }

    else {
      setModalValues({
        ModalInfo: "Danger",
      });
      ModalOpen();
    }
    setSubmit(false)
    resetPopUp();
  }

  //List of ActionList Against Company
  const actionRestriction = useCallback((getItem) => {
    const actionList = [];
    if (props.RoleData?.CompanyOverview && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 1,
          Color: "text-blue-700",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Company Overview",
          action: () =>
            router.push(
              `/CompanyManagement/CompanyOverView?TenantDisplayName=${getItem.TenantDisplayName}&TenantID=${getItem.TenantID}&BucketName=${getItem.BucketName}&RootFolder=${getItem.RootFolder}`
            ),
        });
    }

    if (props.RoleData?.EditCompany && !getItem.IsSuspend) {
      actionList.push(
        {

          id: 2,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit",
          action: () =>
            router.push(
              `/CompanyManagement/CompanyDetails?TenantID=${getItem.TenantID}`
            ),
        });
    }

    if (props.RoleData?.SuspendCompany && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 3,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
          name: "Suspend",
          action: () =>
            popUp("isSuspend", getItem.PK, getItem.SK, "Are you sure want to suspend company"),
        });
    }
    if (props.RoleData?.DeleteCompany && getItem.IsSuspend) {
      actionList.push(
        {
          id: 4,
          className: "hidden",
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete Company",
          action: () =>
            popUp(
              "isDelete",
              getItem.PK,
              getItem.SK,
              "Are you sure to delete the organisation? This action cannot be undone, all the Users and Courses in the organisation will be erased."
            ),
        });
    }

    if (props.RoleData?.UnsuspendCompany && getItem.IsSuspend) {
      actionList.push(
        {
          id: 5,
          className: "hidden",
          Color: "text-yellow-600",
          Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
          name: "Unsuspend",
          action: () =>
            popUp(
              "unSuspend",
              getItem.PK,
              getItem.SK,
              "Are you sure want to Unsuspend company"
            ),
        });
    }
    if (props.RoleData?.EditCompany && !(getItem.IsSuspend == "true")) {
      actionList.push(
          {
              id: 4,
              Color: "text-green-700",
              Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
              name: "Change Password",
              action: () => { PasswordChange.current = { ...PasswordChange.current, UserName: getItem.EmailID, Name: getItem.TenantDisplayName }; setOpen(true); },
          },
      );
  }
    return actionList;
  }, [router, props]);

  function getDateFormat(CreatedDt) {
    return (new Date(CreatedDt).toDateString().substring(4));
  }


  const gridDataBind = useCallback((viewData) => {
    const rowGrid = [];
    viewData.map((getItem, index) => {
      !getItem.IsDeleted
        ? rowGrid.push({
          PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
          SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />),
          TenantDisplayName: (<NVLlabel id={"txtName" + (index + 1)} text={getItem.TenantDisplayName} title={getItem.TenantDisplayName}></NVLlabel>),
          EmailID: (<NVLlabel id={"txtEmailID" + (index + 1)} text={getItem.EmailID}></NVLlabel>),
          MobileNo: (<NVLlabel id={"txtMobileNo" + (index + 1)} text={getItem.MobileNo}></NVLlabel>),
          CreatedDate: (<NVLlabel id={"txtCreateddate" + (index + 1)} text={getDateFormat(getItem.CreatedDate)}></NVLlabel>),
          PlanCode: (<NVLlabel id={"txtPlanCode" + (index + 1)} text={getItem.PlanCode == undefined ? "Plan Not Active" : getItem.PlanCode}></NVLlabel>),
          Action: !getItem.IsSuspend ? (<NVLRapidModal id={"RapidModal" + (index + 1)}  ActionList={getItem.Status.toLowerCase().indexOf("progress") != -1 ? [] : actionRestriction(getItem)}></NVLRapidModal>) : (<NVLRapidModal  id={"RapidModal" + (index + 1)} ActionList={getItem.Status.toLowerCase().indexOf("progress") != -1 ? [] : actionRestriction(getItem)}></NVLRapidModal>),
          Status: (
            <>
              <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                <div className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "text-red-500" : getItem.Status.indexOf("progress") != -1 ? "text-red-500" : "text-green-500"}`}></div>
                <NVLlabel className={getItem.IsSuspend ? "text-red-500" : getItem.Status.indexOf("progress") != -1 ? "text-red-500" : "text-green-500"} text={getItem.IsSuspend ? "Suspended" : getItem.Status} />
              </div>
            </>
          ),
        })
        : "";
    });
    return rowGrid;
  }, [actionRestriction]);

  const headerHandler = (e, url) => {
    e.preventDefault();
    router.push(url);
  };

  const cancelEvent = useCallback((e) => {
    e.preventDefault();
    resetPopUp();
  }, []);

  const variable = useMemo(() => { return { PK: "XLMS#TENANTINFO", IsDeleted: false }; }, []);

  // Bread Crumbs
  const pageRoutes = useMemo(() => { return [{ path: "", breadcrumb: t("Company Management") }]; }, [t]);

  return (
    <>
      <Container title={t("Company Management")}>
      <NVLPageModalPopup
                    ModalType="Page"
                    ScreenName={"Change Password"}
                    PageComponent={<ChangePassword user={props.user} setOpen={setOpen}  finalResponse={finalResponse} PasswordChange={PasswordChange.current} />}
                    open={open}
                    setOpen={setOpen}
                />
               <NVLAlert ButtonYestext={"X"} MessageTop={successPopup.ModalTopMessage} MessageBottom={successPopup.ModalBottomMessage} ModalOnClick={successPopup.ModalOnClickEvent} ModalInfo={successPopup.ModalInfo} />

        <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} href3="/CompanyManagement/CompanyCreate" IsSearch={props.RoleData?.SeTenanthCompany ? true : false} className3={props.RoleData?.CreateCompany ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} LinkName3="+ Create Company" RedirectAction3={(e) => headerHandler(e, "/CompanyManagement/CompanyCreate")} RedirectAction2={() => refreshGrid()} onClick1={refreshGrid} placeholder={"Search by Company Name/Email"} SearchonChange={(e) => searchBoxVal(e)} Search={search} IsNestedHeader />
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <div className="max-w-full w-full justify-center">
          <NVLGridTable SubscriptionVariable={{ PK: "XLMS#TENANTINFO" }} CreateSubscription={onCreateXlmsTenantInfo} UpdateSubscription={onUpdateXlmsTenantInfo} UpdateSubscriptionName={"onUpdateXlmsTenantInfo"} CreateSubscriptionName={"onCreateXlmsTenantInfo"} user={props.user} refershPage={isRefreshing} Search={search} id="tblCompanyList" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsTenantInfosOrderList} querryName={"listXlmsTenantInfosOrderList"} variable={variable} />
        </div>
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} loader={submit} Content={popupValues.Content} />
      </Container>
    </>
  );
}