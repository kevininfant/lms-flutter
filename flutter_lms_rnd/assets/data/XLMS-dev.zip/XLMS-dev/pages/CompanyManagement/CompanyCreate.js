import CompanyInfo from "./CompanyInfo";

function CompanyCreate(props) {
    const info = { ...props, mode: "CREATE" };

    return (
        <>
            <CompanyInfo props={info} />
        </>
    );
}

export default CompanyCreate;