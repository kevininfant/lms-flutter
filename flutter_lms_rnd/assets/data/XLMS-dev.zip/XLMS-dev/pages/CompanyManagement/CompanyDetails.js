import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { getXlmsTenantInfo } from "src/graphql/queries";
import CompanyInfo from "./CompanyInfo";

function CompanyDetails(props) {
    const [state, setState] = useState({});
    const router = useRouter();

    //CSR-Initial data load using GraphQL 
    useEffect(() => {
        const dataSource = async () => {
            const tenantId = router.query["TenantID"];
            const response = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + tenantId }, props.user.signInUserSession.accessToken.jwtToken);
            const info = { ...props, mode: "EDIT", editData: response.res.getXlmsTenantInfo };
            setState(info);
        };

        dataSource();
        return (() => { setState((Info)=>{return{...Info};}); });
        
    }, [props, router.query]);

    return (
        <>
            <CompanyInfo props={state} />
        </>
    );
}

export default CompanyDetails;

