import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLImageUpload from "@components/Controls/NVLImageUpload";
import NVLLink from "@components/Controls/NVLLink";
import Jsondata from "@Constants/dropdowndata.json";
import Container from "@Container/Container";
import NVLButton from "@Controls/NVLButton";
import NVLHeader from "@Controls/NVLHeader";
import NVLlabel from "@Controls/NVLlabel";
import NVLSelectField from "@Controls/NVLSelectField";
import NVLTextbox from "@Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { useTranslation } from "react-i18next";
import { Regex } from "RegularExpression/Regex";
import { getXlmsEmailIdExistsOrNot, listXlmsBucketInfo, listXlmsCompanyCodeExistInfos, listXlmsTenantMobileNoExistInfos, listXlmsTenantNameExistInfos } from "src/graphql/queries";
import * as Yup from "yup";

function CompanyInfo({ props }) {

    const { t } = useTranslation();
    const router = useRouter();
    const [modalValues, setModalValues] = useState({
        ModalType: props.mode === "EDIT" ? "Success" : "Info",
        ModalTopMessage: props.mode === "EDIT" ? "Success" : "In Progress",
        ModalBottomMessage: props.mode === "EDIT" ? "Details have been saved successfully." : "Creation is in progress. Will contact you once the creation is over",
        ModalOnClickEvent: () => {
            if (props?.TenantInfo?.UserGroup == "CompanyAdmin") {
                router.push("/SiteConfiguration/SiteConfigSettings");
            } else {
                router.push("/CompanyManagement/CompanyList");
            }

        },
    });
    const previousState = useRef({ txtCompanyName: {}, txtContactEmail: {}, txtContactMobileNumber: {}, txtCompanyCode: {} });

    const [logo, setLogo] = useState({
        Logofile: props.mode === "EDIT" ? (props.editData.LogoUrlPath == "" ? null : props.editData.LogoUrlPath) : null,
        ImgHeight: props.mode === "EDIT" ? (props.editData.LogoUrlPath == "" ? "" : "w-44 h-20") : "",
        lblFile: "",
        uploadImage: "",
        TentImgUrl: props.mode === "EDIT" ? props.editData.LogoUrlPath : null,
    });

    //Form submit
    const submitHandler = useCallback(async (data) => {
        setValue("submit", true);
        const dateTime = new Date().toISOString();
        const stateUrl = props.mode == "EDIT" ? process.env.STEP_FUNCTION_ARN_COMPANYEDIT : process.env.STEP_FUNCTION_ARN_COMPANYCREATION;
        const setUploadUrl = props.mode == "EDIT" ? process.env.APIGATEWAY_URL_COMPANYEDIT : process.env.APIGATEWAY_URL_COMPANYCREATION;
        const imgUrlPath = logo.TentImgUrl == null ? "" : logo.TentImgUrl;
        const tenantId = props?.editData?.TenantID == undefined ? "" : props?.editData?.TenantID;
        let bucketName = props.mode == "EDIT" ? props.editData.BucketName : "NULL";
        let rootFolder = props.mode == "EDIT" ? props.editData.RootFolder : "NULL";
        if (props.mode != "EDIT") {
            const query = listXlmsBucketInfo, variables = { PK: "XLMS#BUCKETINFO", SK: "BUCKETNAME#", IsActivate: true };
            const finalResponse = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken));
            if (finalResponse?.res?.listXlmsBucketInfo?.items.length >= 1) {
                bucketName = finalResponse.res.listXlmsBucketInfo.items[0].BucketName;
                rootFolder = finalResponse.res.listXlmsBucketInfo.items[0].RootFolder;
            }
        }
        const firstTimeLogin = props.mode == "EDIT" ? "false" : "true";

        const menuId = props.mode == "EDIT" ? "100400" : "100200";
        const jsonSaveData = '{' + '"TenantId": "' + tenantId + '","TenantName": "' + data.txtCompanyName.replace(/\s{2,}(?!\s)/g, ' ').trim() + '","CompanyCode": "' + data.txtCompanyCode + '", "EmailID": "' + data.txtContactEmail + '", "MobileNo": "' + data.txtContactMobileNumber + '", "AlterMobileNo": "' + data.txtAlternateContactMobileNumber + '", "Address1": "' + data.txtAddress1?.replace(/\s{2,}(?!\s)/g, ' ').trim() + '", "Address2": "' + data.txtAddress2?.replace(/\s{2,}(?!\s)/g, ' ').trim() + '", "City": "' + data.txtCity.replace(/\s{2,}(?!\s)/g, ' ').trim() + '", "State": "' + data.txtState.replace(/\s{2,}(?!\s)/g, ' ').trim() + '", "Country": "' + data.ddlCountry + '", "CreatedDate": "' + dateTime + '", "CreatedBy": "' + props.user.username + '", "LogoUrlPath": "' + imgUrlPath + '", "Status":"Active", ' + '"FirstTimeLogin": "' + firstTimeLogin + '", "BucketName":"' + bucketName + '", "RootFolder":"' + rootFolder + '", "UserSub":"' + props?.editData?.UserSub + '" }';

        const headers = { method: "POST", headers: { "Content-Type": "application/json", authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "CompanyManagement", menuid: menuId, statemachinearn: stateUrl }, body: jsonSaveData, };
        const finalStatus = await APIGatewayPostRequest(setUploadUrl, headers);
        if (finalStatus.Status == "Success") {
            setModalValues({ ModalInfo: props.mode === "EDIT" ? "Success" : "Info", ModalOnClickEvent: () => { if (props?.TenantInfo?.UserGroup == "CompanyAdmin") { router.push("/SiteConfiguration/SiteConfigSettings"); } else { router.push("/CompanyManagement/CompanyList"); } }, });
            ModalOpen();
        }
        else {
            setModalValues({ ModalInfo: "Danger", });
            ModalOpen();
        }
        setValue("submit", false);

    }, [logo.TentImgUrl, props.TenantInfo?.UserGroup, props.editData?.BucketName, props.editData?.RootFolder, props.editData?.TenantID, props.editData?.UserSub, props.mode, props.user?.signInUserSession.accessToken.jwtToken, props.user?.username, router, setValue]);

    const uploadLogo = useCallback(async (e) => {
        if (e.target.files.length == 0) {
            return;
        }
        setValue("imageControl", "Upload");
        let file = e.target.files[0];
        const tempPresignedURL = props.mode != "EDIT" ? process.env.COMPANYLOGO_PRESIGNED_URL_S3_BUCKET : process.env.COMPANYLOGOEDIT_PRESIGNED_URL_S3_BUCKET;
        const extension = e.target.files[0].name.substring(e.target.files[0].name.lastIndexOf(".") + 1).toLowerCase();
        if (process.env.COMPANYLOGO_EXTENTION.indexOf(extension) <= -1) {
            setLogo({ ...logo, Logofile: null, lblFile: "Please upload only .jpg, .jpeg, .png file!", });
            setValue("imageControl", "Error");
            return false;
        } else if ((file.type.split("/").pop() != file.name.split(".").pop()) && !((file.name.split(".").pop() == "jpg" && file.type.split("/").pop() == "jpeg") || (file.name.split(".").pop() == "jpeg" && file.type.split("/").pop() == "jpg"))) {
            setLogo({ ...logo, Logofile: null, lblFile: "File format seems to be changed!", });
            setValue("imageControl", "Error");
            return false;
        } else if (file.size > process.env.COMPANYLOGO_SIZE) {
            setLogo({ ...logo, Logofile: null, lblFile: "File size should be 50kB!", });
            setValue("imageControl", "Error");
            return false;
        }

        const createFile = (bits, name) => {
            try {
                return new File(bits, name, { type: "image/" + name.split(".").pop(), lastModified: new Date() });
            } catch (e) {
                var myBlob = new Blob(bits);
                myBlob.lastModified = new Date();
                myBlob.name = name;
                return myBlob;
            }
        };

        let fileName = e.target.files[0].name;
        if (((file.name.split(".").pop() == "jpg" && file.type.split("/").pop() == "jpeg") || (file.name.split(".").pop() == "jpeg" && file.type.split("/").pop() == "jpg"))) {
            fileName = fileName.split(".")[0] + "." + file.type.split("/").pop();
            file = createFile([file], fileName);
        }
        setLogo({ Logofile: file, lblFile: "", ImgHeight: "w-44 h-20", uploadImage: file, TentImgUrl: fileName });
        const menuId = props.mode == "EDIT" ? "100401" : "100201";
        const requestOptions = { method: "GET", headers: { authorizationtoken: props.user.signInUserSession.accessToken.jwtToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "CompanyManagement", menuid: menuId } };
        const presignedHeader = { method: "PUT", body: file, };
        if (props.mode == "EDIT") {
            const url = tempPresignedURL + `?logoname=${fileName}&RootFolder=${props.editData.RootFolder}&S3KeyName=${props.editData.RootFolder}/${props.editData.TenantID}&S3BucketName=${props.editData.BucketName}&BucketName=${props.editData.BucketName}&tenantId=${props.editData.TenantID}`;
            const finalStatus = await APIGatewayPutRequest(url, requestOptions, presignedHeader);
            if (finalStatus[0] == "Success") {
                setValue("imageControl", "Image");
            }
            else {
                setModalValues({ ModalInfo: "Danger", ModalBottomMessage: finalStatus[1], });
                ModalOpen();
                setValue("imageControl", "");
            }

        } else {
            const url = tempPresignedURL + `?logoname=${fileName}&isUser=${"false"}`;
            const finalStatus = await APIGatewayPutRequest(url, requestOptions, presignedHeader);
            if (finalStatus[0] == "Success") {
                setValue("imageControl", "Image");
            }
            else {
                setModalValues({ ModalInfo: "Danger", ModalBottomMessage: finalStatus[1], });
                ModalOpen();
                setValue("imageControl", "");
            }
        }
    }, [logo, props.TenantInfo?.UserGroup, props.editData?.BucketName, props.editData?.RootFolder, props.editData?.TenantID, props.mode, props?.user?.signInUserSession?.accessToken.jwtToken, setValue]);

    const removeImg = useCallback(() => {
        document.getElementById("fulogo").value = null;
        setLogo({ Logofile: null, lblFile: "", ImgHeight: "", uploadImage: null, TentImgUrl: null, });
        setValue("imageControl", "");
    }, [setValue]);

    //Form validation rules
    const validationSchema = Yup.object().shape({
        txtCompanyName: Yup.string().required(t("Company name is required")).matches(Regex("AlphaNumWithAllowedSpecialChar"), t("Invalid Company Name")).min(3, t("Minimum 3 characters are required")).max(100, t("Maximum 100 characters limit exceed")).test("name", t("Company Name Already Exists"), async (e) => {
            if (props.mode == "EDIT" && e.toLowerCase() == props.editData.TenantDisplayName.toLowerCase()) {
                return true;
            }
            if (e == "" || !Regex("AlphaNumWithAllowedSpecialChar").exec(e)) {
                previousState.current = { ...previousState.current, txtCompanyName: { previousVal: e, previousState: false } };
                return false;
            }
            if (previousState.current?.txtCompanyName?.previousState != undefined && e == previousState.current.txtCompanyName?.previousVal) {
                return previousState.current.txtCompanyName?.previousState;
            }
            const query = listXlmsTenantNameExistInfos, variables = { PK: "XLMS#TENANTINFO", SK: "#TENANT#", TenantName: e.toUpperCase() };
            const finalResponse = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession.accessToken.jwtToken));
            if (finalResponse.Status == "Success") {
                if (finalResponse?.res?.listXlmsTenantNameExistInfos.items.length > 0) {
                    previousState.current = { ...previousState.current, txtCompanyName: { previousVal: e, previousState: false } };
                    return false;
                }
                previousState.current = { ...previousState.current, txtCompanyName: { previousVal: e, previousState: true } };
                return true;
            }
            return false;
        }),
        txtCompanyCode: Yup.string().required(t("Company Code is required")).typeError("Company Code is required").uppercase()
            .matches(Regex("OnlyUpperCaseAndNumWithoutSpace"), t("Accepts only alpha-numeric and the maximum character limit is 5"))
            .min(5, "Company code should contain 5 characters").max(5, "Maximum character limit exceed")
            .test("email", t("Company Code already exists"), async (e) => {
                if (props.mode == "EDIT" && e == props.editData.CompanyCode) {
                    return true;
                }
                if (e == "" || Regex("OnlyUpperCaseAndNumWithoutSpace").exec(e) == null || e.length != 5) {
                    previousState.current = { ...previousState.current, txtCompanyCode: { previousVal: e, previousState: false } };
                    return false;
                }
                if (previousState.current?.txtCompanyCode?.previousState != undefined && e == previousState.current.txtCompanyCode?.previousVal) {
                    return previousState.current.txtCompanyCode?.previousState;
                }
                const query = listXlmsCompanyCodeExistInfos, variables = { PK: "XLMS#TENANTINFO", SK: "#TENANT#", CompanyCode: e };
                const finalResponse = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession.accessToken.jwtToken));
                if (finalResponse.Status == "Success") {
                    if (finalResponse?.res?.listXlmsCompanyCodeExistInfos.items.length > 0) {
                        previousState.current = { ...previousState.current, txtCompanyCode: { previousVal: e, previousState: false } };
                        return false;
                    }
                    previousState.current = { ...previousState.current, txtCompanyCode: { previousVal: e, previousState: true } };
                    return true;
                }
                return false;
            }),
        txtContactEmail: Yup.string().required(t("Email is required"))
            .matches(Regex("Email"), t("Invalid Email")).max(128, "Maximum character limit exceed")
            .test("email", t("Email already exists"), async (e) => {

                if (props.mode == "EDIT" && props.TenantInfo.UserGroup == "CompanyAdmin") {
                    return true;
                }
                if (props.mode == "EDIT" && props.TenantInfo.UserGroup == "SiteAdmin" && e == props.editData.EmailID) {
                    return true;
                }
                if (e == "" || !Regex("Email").exec(e) || e.length > 128) {
                    previousState.current = { ...previousState.current, txtContactEmail: { previousVal: e, previousState: false } };
                    return false;
                }
                if (previousState.current?.txtContactEmail?.previousState != undefined && e == previousState.current.txtContactEmail?.previousVal) {
                    return previousState.current.txtContactEmail.previousState;
                }
                const isEmailExists = await AppsyncDBconnection(getXlmsEmailIdExistsOrNot, { PK: "XLMS#EMAIL", SK: "EMAILID#" + e.toLowerCase() }, props.user.signInUserSession.accessToken.jwtToken);
                if (isEmailExists.res.getXlmsEmailIdExistsOrNot != null) {
                    previousState.current = { ...previousState.current, txtContactEmail: { previousVal: e, previousState: false } };
                    return false;
                }
                previousState.current = { ...previousState.current, txtContactEmail: { previousVal: e, previousState: true } };
                return true;
            }),
        txtContactMobileNumber: Yup.string(t("Enter a valid number")).required(t("Mobile number is required")).min(10,
            t("Enter a valid number")).max(10, t("Enter a valid number")).matches(/^[6-9][0-9]{9}$/, t("Enter a valid number"))
            .test("number", t("Number already exists"), async (e) => {

                if (props.mode == "EDIT" && props.TenantInfo.UserGroup == "CompanyAdmin") {
                    return true;
                }
                if (props.mode == "EDIT" && props.TenantInfo.UserGroup == "SiteAdmin" && e == props.editData.MobileNo) {
                    return true;
                }
                if (e == "" || !Regex("PhoneNumber").exec(e)) {
                    previousState.current = { ...previousState.current, txtContactMobileNumber: { previousVal: e, previousState: false } };

                    return false;
                }
                if (previousState.current?.txtContactMobileNumber?.previousState != undefined && e == previousState.current.txtContactMobileNumber?.previousVal) {
                    return previousState.current.txtContactMobileNumber.previousState;
                }
                if ((watch("txtContactMobileNumber")) != (watch("txtAlternateContactMobileNumber"))) {
                    setValue("alternateNumber", undefined);
                }
                const query = listXlmsTenantMobileNoExistInfos, variables = { PK: "XLMS#TENANTINFO", SK: "#TENANT#", MobileNo: e };
                const finalResponse = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession.accessToken.jwtToken));
                let mobile = finalResponse?.res?.listXlmsTenantMobileNoExistInfos?.items && finalResponse?.res?.listXlmsTenantMobileNoExistInfos?.items;
                if (mobile?.length == 1 && mobile?.[0]?.TenantID != router.query["TenantID"]) {
                    previousState.current = { ...previousState.current, txtContactMobileNumber: { previousVal: e, previousState: false } };
                    return false;
                } else {
                    previousState.current = { ...previousState.current, txtContactMobileNumber: { previousVal: e, previousState: true } };
                    return true;
                }
                return false;
            }),
        txtAlternateContactMobileNumber: Yup.string().notRequired()
            .test("number", "", async (e) => {
                if (e != undefined && e != "") {
                    if (watch("txtContactMobileNumber") == watch("txtAlternateContactMobileNumber")) {
                        setValue("alternateNumber", "Alternate mobile number should not be same as mobile number");
                        return false
                    } else {
                        setValue("alternateNumber", undefined);
                    }
                    if (e != "" && e?.length != 10) {
                        setValue("alternateNumber", t("Enter a valid number"));
                        return false;
                    }
                    if (e == "") {
                        return true;
                    }
                    const rejax = new RegExp(/^[6-9][0-9]{9}$/);
                    if (!rejax.test(e)) {
                        setValue("alternateNumber", t("Enter a valid number"));
                        return false;
                    }
                }
                return true;
            }),
        txtAddress1: Yup.string().notRequired().max(500, t("Maximum 500 characters Reached")).nullable(),
        txtAddress2: Yup.string().notRequired().max(500, t("Maximum 500 characters Reached")).nullable(),
        txtCity: Yup.string().required(t("Enter a city")).matches(Regex("AllowAlphaNumWithSpace"), t("Invalid City")).max(50, t("Maximum 50 characters Reached")),
        txtState: Yup.string().required(t("Enter a state")).matches(Regex("AllowAlphaNumWithSpace"), t("Invalid State")).max(50, t("Maximum 50 characters Reached")),
        ddlCountry: Yup.string().required(t("Choose a country")),
        imageControl: Yup.string(),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true };
    const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    const clearAllControls = useCallback(() => {
        reset();
        removeImg();
    }, [removeImg, reset]);

    useEffect(() => {
        if (props.mode == "EDIT") {
            setValue("txtCompanyName", props.editData.TenantDisplayName);
            setValue("txtCompanyCode", props.editData.CompanyCode);
            setValue("txtContactEmail", props.editData.EmailID);
            setValue("txtContactMobileNumber", props.editData.MobileNo);
            setValue("txtAlternateContactMobileNumber", props.editData.AlterMobileNo);
            setValue("txtAddress1", props.editData.Address1);
            setValue("txtAddress2", props.editData.Address2);
            setValue("txtCity", props.editData.City);
            setValue("txtState", props.editData.State);
            setValue("ddlCountry", props.editData.Country);

            if (props.editData.LogoUrlPath != null && props.editData.LogoUrlPath != "") {
                setValue("imageControl", "Image");
                setLogo({
                    Logofile: props.mode === "EDIT" ? (props.editData.LogoUrlPath == "" ? null : props.editData.LogoUrlPath) : null,
                    ImgHeight: props.mode === "EDIT" ? (props.editData.LogoUrlPath == "" ? "" : "w-44 h-20") : "",
                    lblFile: "",
                    uploadImage: "",
                    TentImgUrl: props.mode === "EDIT" ? props.editData.LogoUrlPath : null,
                });
            }

        }
    }, [props, setValue]);


    // Bread Crumbs
    const pageRoutes = useMemo(() => { return [{ path: props?.TenantInfo?.UserGroup == "CompanyAdmin" ? "/SiteConfiguration/SiteConfigSettings" : "/CompanyManagement/CompanyList", breadcrumb: props?.TenantInfo?.UserGroup == "CompanyAdmin" ? "Site Configuration" : "Company Management" }, { path: props.mode == "", breadcrumb: props.mode == "EDIT" ? ("Edit Company") : ("Create Company") }]; }, [props?.TenantInfo?.UserGroup, props.mode]);

    return (
        <>
            <Container title={props?.TenantInfo?.UserGroup == "CompanyAdmin" ? "Manage Accounts" : props.mode == "EDIT" ? "Edit Company" : "Create Company"} loader={props.mode == undefined} PageRoutes={pageRoutes}>
                <NVLHeader IsSearch={false} HeaderOption={props.mode == "EDIT" ? (<div className="items-center">
                    <NVLlabel className={"font-medium"} text={`Your Current Plan : ${props.editData.PlanCode == null ? "-" : props.editData.PlanCode}`} />{" "}
                    <NVLLink text="CHANGE PLAN" className={"font-semibold underline"} onClick={() => { if (props.TenantInfo.UserGroup == "SiteAdmin") { router.push(`/PlanProcessor/PlanInfo?TenantID=${props?.editData?.TenantID}`); } else { router.push("/PlanProcessor/PlanInfo"); } }} />{" "}      </div>) : ("")} IsNestedHeader={false} />
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)} className={`${(watch("File") == "Uploading" || watch("imageControl") == "Upload" || watch("submit")) ? "pointer-events-none" : "px-2"}`}>
                    <div className="nvl-FormContent">
                        <NVLTextbox id="txtCompanyName" labelText={t("Company Name")} labelClassName="nvl-Def-Label" errors={errors} title="Enter Company Name" className="nvl-mandatory nvl-Def-Input" register={register} />
                        <NVLlabel text={t("Company Code")} className="nvl-Def-Label" HelpInfo={`${"Accepts only alpha-numeric upto 5 characters"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"}><span className="text-red-600 text-sm">*</span></NVLlabel>
                        <NVLTextbox id="txtCompanyCode" title="Enter Company Code" errors={errors} className={`UppercaseText nvl-Def-Input nvl-mandatory ${props.mode == "EDIT" && props.TenantInfo.UserGroup == "CompanyAdmin" ? "Disabled nvl-Def-Input" : ""}`} disabled={props.mode == "EDIT" && props.TenantInfo.UserGroup == "CompanyAdmin" ? true : false} register={register} />
                        <NVLTextbox id="txtContactEmail" labelText={t("Contact Email")} labelClassName="nvl-Def-Label" title="Enter Company Email" errors={errors} className={`nvl-Def-Input nvl-mandatory ${props.mode == "EDIT" && (props.TenantInfo.UserGroup == "CompanyAdmin") ? "Disabled nvl-Def-Input" : ""}`} disabled={props.mode == "EDIT" && (props.TenantInfo.UserGroup == "CompanyAdmin") ? true : false} register={register} />
                        <NVLTextbox id="txtContactMobileNumber" labelText={t("Mobile Number")} labelClassName="nvl-Def-Label" errors={errors} title="Enter Company Mobile Number" type="number" className={` ${props.mode == "EDIT" && (props.TenantInfo.UserGroup == "CompanyAdmin") ? "Disabled nvl-Def-Input" : ""}nvl-Def-Input nvl-mandatory`} disabled={props.mode == "EDIT" && (props.TenantInfo.UserGroup == "CompanyAdmin") ? true : false} register={register} />
                        <NVLTextbox id="txtAlternateContactMobileNumber" labelText={t("Alternate Mobile Number")} labelClassName="nvl-Def-Label" errors={errors} title=" Enter Alternate Mobile Number " type="number" className="nvl-Def-Input nvl-non-mandatory" register={register} />
                        <div className={"{invalid-feedback} text-red-500 text-sm "} id="errorsCompletation">
                            {watch("alternateNumber")}
                        </div>
                        <NVLTextbox id="txtAddress1" errors={errors} labelText={t("Address 1")} labelClassName="nvl-Def-Label" className="nvl-Def-Input nvl-non-mandatory" title="Enter your Address 1" register={register} />
                        <NVLTextbox id="txtAddress2" errors={errors} labelText={t("Address 2")} labelClassName="nvl-Def-Label" className="nvl-Def-Input nvl-non-mandatory" title="Enter your Address 2" register={register} />
                        <NVLSelectField id="ddlCountry" errors={errors} labelText={t("Country")} labelClassName="nvl-Def-Label" options={Jsondata.Country} register={register} className="nvl-Def-Input nvl-mandatory"></NVLSelectField>
                        <NVLTextbox id="txtState" errors={errors} labelText={t("State")} labelClassName="nvl-Def-Label" title="Enter your State " className="nvl-Def-Input nvl-mandatory" register={register} />
                        <NVLTextbox id="txtCity" errors={errors} labelText={t("City")} labelClassName="nvl-Def-Label" title="Enter your City " className="nvl-Def-Input nvl-mandatory" register={register} />
                        <NVLlabel text={t("Upload Company Logo")} className="nvl-Def-Label" HelpInfo={`${t("Acceptable file format: jpg, png, jpeg.<br>File size should not exceed more than 50KB")}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                        <NVLlabel className="block text-sm font-medium text-gray-700" id="lblLogo" />
                        <NVLImageUpload text={t("Upload Logo")} watch={watch} control={"imageControl"} accept={".jpg,.png,.jpeg"} Logofile={logo.Logofile} uploadImage={logo.uploadImage} ImgHeight={logo.ImgHeight} mode={props.mode} UploadLogo={uploadLogo} removeImg={removeImg} lblFile={logo.lblFile} />
                        <div className=" flex flex-row gap-1 justify-center nvl-Def-Input mt-2">
                            <NVLButton id="btnSubmit" text={!watch("submit") ? (props.mode == "CREATE" ? t("Submit") : t("Save Changes")) : ""} type="submit" disabled={watch("imageControl") == "Upload" || watch("submit") ? true : false} className={watch("submit") ? (props.mode == "EDIT" ? "w-32 nvl-button bg-primary text-white " : "w-28 nvl-button  bg-primary text-white ") : "w-28 nvl-button  bg-primary text-white"}>{
                                watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
                            }</NVLButton>
                            <NVLButton id="btnCancel" text={props.mode == "CREATE" ? t("Clear") : t("Cancel")} type="reset" className="nvl-button w-28"
                                onClick={() => (props.mode == "CREATE" ? clearAllControls() : props?.TenantInfo?.UserGroup == "CompanyAdmin" ? router.push("/SiteConfiguration/SiteConfigSettings") : router.push("/CompanyManagement/CompanyList"))}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CompanyInfo;