import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsRepositoryCategory, updateXlmsRepositoryCategory } from "@graphql/graphql/mutations";
import { getXlmsRepositoryCategory, listXlmsRepositoryCategory } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";

function Category(props) {
    const [message, setMessage] = useState("");
    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/KnowledgeRepository/ManageCategory")
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);
    const router = useRouter()
    const [pageData, setPageData] = useState({})

    useEffect(() => {
        async function fetchData() {
            const categoryId = decodeURIComponent(String(router.query["CategoryID"]));
            const category = await AppsyncDBconnection(getXlmsRepositoryCategory, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#CATEGORY#" + categoryId }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            const categoryList = await AppsyncDBconnection(listXlmsRepositoryCategory, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#CATEGORY#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            setPageData({
                categoryData: category.res?.getXlmsRepositoryCategory != undefined ? category.res?.getXlmsRepositoryCategory : {},
                categoryList: categoryList.res?.listXlmsRepositoryCategory?.items != undefined ? categoryList.res?.listXlmsRepositoryCategory?.items : []
            })
        }
        fetchData()
        return (() => {
            setPageData((temp) => { return { ...temp } });
        })
    }, [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query])

    const fetchCategory = useCallback(async () => {
        const categoryList = await AppsyncDBconnection(listXlmsRepositoryCategory, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#CATEGORY#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        setPageData((temp) => { return { ...temp, categoryList: categoryList.res?.listXlmsRepositoryCategory?.items != undefined ? categoryList.res?.listXlmsRepositoryCategory?.items : [] } })
    }, [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken])

    const validationSchema = Yup.object().shape({
        txtCategoryName: Yup.string().required("Category Name is required")
            .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Invalid Category Name")
            .min(3, "Category name should not be less than 3 characters")
            .max(250, "Maximum 250 characters Reached")
            .test("", "Category Name already exists", (e) => {
                if (props.Mode == "Popup") {
                    fetchCategory()
                }
                const existingCategoryName = pageData?.categoryList;
                const CategoryNameFound = existingCategoryName && existingCategoryName?.some((category) => category?.CategoryName?.toLowerCase() == e?.toLowerCase());
                if (CategoryNameFound && (router.query["Mode"] == "Edit" || router.query["Mode"] == "Create" || props.Mode == "Popup") && e?.toLowerCase() != pageData?.categoryData?.CategoryName?.toLowerCase()) {
                    if (e?.toLowerCase() != pageData?.categoryData?.CategoryName?.toLowerCase()) {
                        return false;
                    }
                }
                return true
            }).nullable()
    })
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, reset, formState, clearErrors } = useForm(formOptions);
    const { errors } = formState;

    const PageRoutes = useMemo(() => {
        return [{ path: "/KnowledgeRepository/ManageCategory", breadcrumb: "Manage Category" },
        { path: "", breadcrumb: router.query["Mode"] == "Edit" ? "Edit Category" : "Create Category" }]
    }, [router.query])

    useEffect(() => {
        if (router.query["Mode"] == "Edit") {
            setValue("txtCategoryName", pageData?.categoryData?.CategoryName)
            if (message != "") {
                setHTMLContents(pageData?.categoryData?.CategoryDescription, message);
                setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
                message?.history?.clear();
            }
        }
    }, [message, pageData?.categoryData?.CategoryDescription, pageData?.categoryData?.CategoryName, router.query, setValue])

    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: finalStatus,
            });
            ModalOpen();
            return;
        } else {
            setValue("submit", true);
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    router.push("/KnowledgeRepository/ManageCategory")
                },
            });
            ModalOpen();
        }
    }, [router, setValue]);

    useEffect(() => {
        if (props.open == 1) {
            clearField()
        }
    }, [clearField, props.open])

    const clearField = useCallback(() => {
        setValue("txtCategoryName", "")
        if (message != "") {
            setHTMLContents("", message);
        }
        clearErrors()
    }, [clearErrors, message, setValue])

    const submitHandler = useCallback(async (data) => {
        document?.activeElement?.blur();
        setValue("submit", true)

        const PK = "TENANT#" + props.TenantInfo.TenantID;

        const categoryId = (router.query["Mode"] == "Edit" && props.Mode != "Popup") ? pageData?.categoryData?.CategoryID : Math.random().toString(25).substring(2, 12);

        const SK = (router.query["Mode"] == "Edit" && props.Mode != "Popup") ? pageData?.categoryData?.SK : "KNOWLEDGEREPO#CATEGORY#" + categoryId;
        const query = (router.query["Mode"] == "Edit" && props.Mode != "Popup") ? updateXlmsRepositoryCategory : createXlmsRepositoryCategory;

        const variables = {
            input: {
                PK: PK,
                SK: SK,
                CategoryID: categoryId,
                CategoryName: data.txtCategoryName,
                CategoryDescription: getContents(message),
                IsSuspend: false,
                IsDeleted: false,
                CreatedBy: (router.query["Mode"] == "Edit" && props.Mode != "Popup") ? pageData?.categoryData?.CreatedBy : props.user?.username,
                CreatedDate: (router.query["Mode"] == "Edit" && props.Mode != "Popup") ? pageData?.categoryData?.CreatedDate : new Date(),
                LastModifiedBy: (router.query["Mode"] == "Edit" && props.Mode != "Popup") ? pageData?.categoryData?.LastModifiedBy : props.user?.username,
                LastModifiedDate: new Date()
            },
        };

        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;

        if (props.Mode != "Popup") {
            finalResponse(finalStatus);
        } else {
            document?.getElementById("divPageModal")?.classList?.add("hidden");
            props.setOpen(() => {
                return false;
            });
            clearField();
        }
        setValue("submit", false)
    }, [clearField, finalResponse, message, pageData?.categoryData?.CategoryID, pageData?.categoryData?.CreatedBy, pageData?.categoryData?.CreatedDate, pageData?.categoryData?.LastModifiedBy, pageData?.categoryData?.SK, props, router.query, setValue])

    const cancelPopup = () => {
        props.setOpen(() => { return false })
        clearField()
    }
    return (
        <>
            <Container loader={pageData?.categoryData == undefined ? true : false} PageRoutes={props.Mode != "Popup" ? PageRoutes : undefined} title={`${props.Mode != "Popup" ? (router.query["Mode"] == "Edit" ? "Edit Category" : "Create Category") : props.Title}`}>
                <form onSubmit={handleSubmit(submitHandler)} id="divCategory">
                    {props.Mode != "Popup" &&
                        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    }
                    <div className={`${watch("submit") ? "nvl-FormContent pointer-events-none" : "nvl-FormContent"}`} >
                        <NVLTextbox id="txtCategoryName" labelText="Category Name" labelClassName="nvl-Def-Label pb-1" title="Category Name" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <NVLlabel text="Category Description" className="nvl-Def-Label" />
                        <NVLRichTextBox id="txtCategoryDescription" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} />
                        <div className="flex justify-center gap-2 pt-4">
                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Save" : ""} type="submit" className={"w-32 nvl-button bg-primary text-white"}>
                                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                            </NVLButton>
                            <NVLButton id="btnCancel" text={router.query["Mode"] == "Edit" || props.Mode == "Popup" ? "Cancel" : "Clear"} type="button" className="nvl-button w-28"
                                onClick={() => router.query["Mode"] != "Edit" && props.Mode != "Popup" ? clearField() : props.Mode == "Popup" ? cancelPopup() : router.push("/KnowledgeRepository/ManageCategory")} ></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    )
}
export default Category;