import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLImageUpload from "@components/Controls/NVLImageUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLToggle from "@components/Controls/NVLToggle";
import NVLWarning from "@components/Controls/NVLWarning";
import { createXlmsBatchAssetInfo } from "@graphql/graphql/mutations";
import { getXlmsAssetInfo, listXlmsActiveRepositoryCategory, listXlmsAssetInfo } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import Category from "@Pages/KnowledgeRepository/Category";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";

function UploadDocument(props) {
    const [message, setMessage] = useState("");
    const router = useRouter()
    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/KnowledgeRepository/KnowledgeRepositoryList")
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);
    const [pageData, setPageData] = useState({})
    const [categoryState, setCategoryState] = useState(() => { return [{ value: "", text: "Select" }] })
    const [fileValues, setFileValues] = useState({ TextName: "Select File", FilePath: "", });

    const [logo, setLogo] = useState({
        Logofile: null,
        ImgHeight: "",
        lblFile: "",
        uploadImage: "",
        TentImgUrl: null,
        setimage: "",
    });
    const toggleAction = useRef()
    const [open, setOpen] = useState(false);
    const uploadFileType = useRef()

    useEffect(() => {

        async function fetchData() {
            const categoryList = [{ value: "", text: "Select" }]
            const listCategory = await AppsyncDBconnection(listXlmsActiveRepositoryCategory, { PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#CATEGORY#", IsSuspend: false, IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            const categoryData = listCategory.res?.listXlmsActiveRepositoryCategory?.items != undefined ? listCategory.res?.listXlmsActiveRepositoryCategory?.items : []
            const AssetList = await AppsyncDBconnection(listXlmsAssetInfo, { PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#ASSET#", IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            const AssetData = await AppsyncDBconnection(getXlmsAssetInfo, { PK: "TENANT#" + props?.TenantInfo.TenantID, SK: "KNOWLEDGEREPO#ASSET#" + router.query["AssetID"] }, props?.user?.signInUserSession?.accessToken?.jwtToken)
            const AssetEditData = AssetData?.res?.getXlmsAssetInfo
            const categoryFiltered = categoryData?.filter((obj) => !categoryList[obj.CategoryID] && (categoryList[obj.CategoryID] = true));
            categoryFiltered?.map((categoryData) => [categoryList.push({ value: categoryData.CategoryID, text: categoryData.CategoryName })]);
            setCategoryState(() => { return categoryList; });

            if (router.query["Mode"] == "Edit") {
                uploadFileType.current = AssetEditData?.FileType
            }

            setPageData({
                CategoryData: categoryData,
                AssetData: AssetEditData && AssetEditData,
                AssetList: AssetList.res?.listXlmsAssetInfo?.items != undefined ? AssetList.res?.listXlmsAssetInfo?.items : []
            })
            setLogo({
                Logofile: router.query["Mode"] == "Edit" && AssetEditData?.ThumbNail == undefined ? null : AssetEditData?.ThumbNail,
                ImgHeight: router.query["Mode"] == "Edit" && AssetEditData?.ThumbNail == undefined ? "" : "w-44 h-20",
                lblFile: "",
                uploadImage: "",
                TentImgUrl: router.query["Mode"] == "Edit" && AssetEditData?.ThumbNail == undefined ? null : AssetEditData?.ThumbNail,
                setimage: "",
            })
            setFileValues({
                TextName: router.query["Mode"] == "Edit" && AssetEditData?.UploadFile != undefined ? AssetEditData?.UploadFile && AssetEditData?.UploadFile?.split("/")[7] : "Select File",
                FilePath: router.query["Mode"] == "Edit" && AssetEditData?.UploadFile != undefined ? AssetEditData?.UploadFile && AssetEditData?.UploadFile : "",
                path: router.query["Mode"] == "Edit" && AssetEditData?.UploadFile != undefined ? AssetEditData?.UploadFile && AssetEditData?.UploadFile : "",
                pathchanged: false,
            });
        }
        fetchData()
        return (() => {
            setPageData((temp) => { return { ...temp } })
            setLogo((temp) => { return { ...temp } })
            setFileValues((temp) => { return { ...temp } })
            setCategoryState((temp) => { return { ...temp } })
        })
    }, [getCategory, props?.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query])



    const getCategory = useCallback(async () => {
        const categoryData = await AppsyncDBconnection(listXlmsActiveRepositoryCategory, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "KNOWLEDGEREPO#CATEGORY#", IsSuspend: false, IsDeleted: false }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        const category = [{ value: "", text: "Select" }];
        const categoryFiltered =
            categoryData.res?.listXlmsActiveRepositoryCategory?.items?.filter(
                (obj) =>
                    !category[obj.CategoryID] &&
                    (category[obj.CategoryID] = true)
            );
        categoryFiltered?.map((categoryData) => [
            category.push({
                value: categoryData.CategoryID,
                text: categoryData.CategoryName,
            }),
        ]);
        setCategoryState(() => {
            return category;
        });
    }, [props?.user?.signInUserSession?.accessToken?.jwtToken, props?.TenantInfo?.TenantID]);


    const getHelpInfo = useCallback(() => {

        let helpText;
        if (watch("ddlFileType") == "Video") {
            helpText = ".mp4, .avi, .mov";
        } else if (watch("ddlFileType") == "Document") {
            helpText = ".doc, .docx, .zip, .pdf, .csv, .xls, .xlsx";
        } else if (watch("ddlFileType") == "Audio") {
            helpText = ".mp3"
        } else if (watch("ddlFileType") == "Image") {
            helpText = ".jpg, .jpeg, .png"
        }
        return helpText;
    }, [watch])

    const validationSchema = Yup.object().shape({
        txtAssetName: Yup.string().required("Asset Name is required").max(250, "Maximum 250 characters reached")
            .test("", "Asset name already exists", (e,{createError}) => {
                if (e != "" || e != undefined) {
                    const existingAssetName = pageData?.AssetList;
                    const AssetNameFound = existingAssetName && existingAssetName?.some((asset) => asset?.AssetName?.toLowerCase() == e?.toLowerCase());
                    if (AssetNameFound && (router.query["Mode"] == "Edit" || router.query["Mode"] == "Create") && e?.toLowerCase() != pageData?.AssetData?.AssetName?.toLowerCase()) {
                        return false;
                    }   
                 if (e != "" && e.length < 3) {
                    return createError({ message: "Asset name should not be less than 3 characters" })
                 }
                const rejax = Regex("AlphaNumWithAllowedSpecialChar")
                if ( !rejax.test(e)) {
                    return createError({ message: "Asset Name is invalid" })
                }
                }
                return true
            }).nullable(),
        ddlCategory: Yup.string().required("Category is required").nullable(),
        ddlFileType: Yup.string().required("File Type is required")
            .test("", "", (e) => {
                if ((router.query["Mode"] == "Edit" && uploadFileType.current != undefined && e != uploadFileType.current) || ((router.query["Mode"] == "Create" && e != uploadFileType.current))) {
                    uploadFileType.current = e
                    setValue("txtURL", "")
                    setFileValues({ TextName: "Select File", FilePath: "", path: "" })
                    setValue("File", "");
                    clearErrors(["File", "txtURL"])
                    toggleAction.current = false;
                    e != "URL" && (document.getElementById("tgAccess").checked = false)
                }
                return true
            }).nullable(),
        txtURL: Yup.string()
            .when("ddlFileType", {
                is: "URL",
                then: Yup.string().required("URL is required").matches(Regex("Url"), "Url is invalid").nullable(),
            }).nullable(),
        txtAuthor: Yup.string().max(250, "Maximum 250 characters reached")
            .notRequired()
            .test("", "Author name is invalid", (e, { createError }) => {
                if (e == undefined || e == "") {
                    return true;
                }
                if (e != "" && e.length < 3) {
                    return createError({ message: "Author name should not be less than 3 characters" })
                }
                const rejax = Regex("AcceptAllRestrictSpaceAtBeginning")
                if (!rejax.test(e)) {
                    return false;
                }
                return true;
            })
            .nullable(),

        File: Yup.string().nullable()
            .when("ddlFileType", {
                is: (e) => e != "URL",
                then: Yup.string()
                    .test("file_Error", "", (e, { createError }) => {
                        if (e == "" || e == undefined && fileValues.FilePath == "") {

                            return createError({ message: "File is required" })
                        }
                        if (e == "fileType") {
                            return createError({ message: ` Please upload only ${getHelpInfo()} file!` });
                        }
                        if (e == "fileSize") {
                            return createError({ message: "File size should not exceed 1GB" });
                        }
                        if (e == "Error") {
                            return createError({ message: "Server Error Please Try Again" });
                        }
                        if (e == "FileNotValid") {
                            return createError({ message: "Server Error Please Try Again" });
                        }
                        if (e == "fileFormat") {
                            return createError({ message: "File format seems to be changed!" });
                        }
                        return true;
                    })
            })
            .nullable(),
        imageControl: Yup.string().nullable(),
    })
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, reset, formState, clearErrors } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        if ((open != 0 && open % 2 == 0) || !open) {
            getCategory();
        }
    }, [getCategory, open]);


    const PageRoutes = useMemo(() => {
        return [{ path: "/KnowledgeRepository/KnowledgeRepositoryList", breadcrumb: "Knowledge Repository" },
        { path: "", breadcrumb: router.query["Mode"] == "Edit" ? "Edit Asset" : "Create Asset" }]
    }, [router.query])


    const fileType = useMemo(() => {
        return [{ value: "", text: "Select" },
        { value: "Image", text: "Image" },
        { value: "Audio", text: "Audio" },
        { value: "Video", text: "Video" },
        { value: "Document", text: "Document" },
        { value: "URL", text: "URL" }
        ]
    }, [])

    useEffect(() => {
        const isCat = ((categoryState.length != undefined && categoryState?.filter((x) => x.value == pageData?.AssetData?.CategoryID)?.length > 0) ? true : false);
        if (router.query["Mode"] == "Edit") {
            setValue("txtAssetName", pageData?.AssetData?.AssetName)
            setValue("ddlCategory", isCat ? pageData?.AssetData?.CategoryID : "")
            setValue("ddlFileType", pageData?.AssetData?.FileType)
            setValue("txtAuthor", pageData?.AssetData?.Author)
            setValue("txtURL", pageData?.AssetData?.AttachURL)
            setValue("tgAccess", pageData?.AssetData?.IsDownloadAccess == true ? (document.getElementById("tgAccess").checked = true) : false);
            toggleAction.current = pageData?.AssetData?.IsDownloadAccess
            setValue("Thumbnailurl", pageData?.AssetData?.UploadFile == undefined ? null : pageData?.AssetData?.UploadFile);
            setValue("imageControl", pageData?.AssetData?.ThumbNail == null ? "" : "Image");
            // if (message != "") {
            //     setHTMLContents(pageData?.AssetData?.AssetDescription, message);
            //     setValue("RichTextBox", "NotEmpty", { shouldValidate: true });
            //     message?.history?.clear();
            // }
        }
    }, [categoryState, message, pageData?.AssetData, pageData?.AssetData?.AssetName, pageData?.AssetData?.AttachURL, pageData?.AssetData?.Author, pageData?.AssetData?.CategoryID, pageData?.AssetData?.FileType, pageData?.AssetData?.IsDownloadAccess, router.query, setValue])

    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: finalStatus,
            });
            ModalOpen();
            return;
        } else {
            setValue("submit", true);
            setModalValues({
                ModalInfo: "Success",
                ModalTopMessage: "Success",
                ModalBottomMessage: "Details have been saved successfully.",
                ModalOnClickEvent: () => {
                    router.push("/KnowledgeRepository/KnowledgeRepositoryList")
                },
            });
            ModalOpen();
        }
    }, [router, setValue]);

    const createFile = (bits, name) => {
        try {
            return new File(bits, name, {
                type: "image/" + name.split(".").pop(),
                lastModified: new Date(),
            });
        } catch (e) {
            let myBlob = new Blob(bits);
            myBlob.lastModified = new Date();
            myBlob.name = name;
            return myBlob;
        }
    };

    const fileValidation = useCallback(
        async (e, mode) => {
            if (e.target.files.length == 0) {
                return;
            }
            const file = e.target.files[0];
            document.getElementById("Filerequired").style.display = "none";
            let FileName = e.target.files[0].name;
            if ((file.name.split(".").pop() == "jpg" && file.type.split("/").pop() == "jpeg") || (file.name.split(".").pop() == "jpeg" && file.type.split("/").pop() == "jpg")) {
                FileName = FileName.split(".")[0] + "." + file.type.split("/").pop();
                file = createFile([file], FileName);
            }

            if (mode == "Files") {
                setValue("File", "Uploading");
                const fileInput = document.getElementById("getFile");
                const extension = e.target?.files[0]?.name
                    ?.substring(e.target.files[0].name.lastIndexOf(".") + 1)
                    .toLowerCase();

                let Extension;
                if (watch("ddlFileType") == "Image") {
                    Extension = ["jpg", "jpeg", "png"];
                } else if (watch("ddlFileType") == "Video") {
                    Extension = ["mp4", "avi", "mov"];
                } else if (watch("ddlFileType") == "Document") {
                    Extension = ["doc", "docx", "zip", "pdf", "csv", "xls", "xlsx"];
                } else if (watch("ddlFileType") == "Audio") {
                    Extension = ["mp3"];
                }

                if (Extension?.indexOf(extension) <= -1 || fileInput == null) {
                    fileInput.value = "";
                    setFileValues({
                        ...fileValues,
                        TextName: "Select File",
                        FilePath: "",
                    });
                    setValue("File", "fileType", { shouldValidate: true });
                    return false;
                } else if (file.size > process.env.KNOWLEDGEREPO_FILE_SIZE) {
                    fileInput.value = "";
                    setFileValues({
                        ...fileValues,
                        TextName: "Select File",
                        FilePath: "",
                    });
                    setValue("File", "fileSize", { shouldValidate: true });
                    return false;
                }
            } else if (mode == "ThumbNail") {
                setValue("imageControl", "Upload");
                const extension = e.target.files[0].name
                    .substring(e.target.files[0].name.lastIndexOf(".") + 1)
                    .toLowerCase();

                if (process.env.KNOWLEDGEREPO_THUMBNAIL_EXTENTION.indexOf(extension) <= -1) {
                    setLogo({
                        ...logo,
                        Logofile: null,
                        lblFile: "Please upload only .jpg, .jpeg, .png file!",
                    });
                    setValue("imageControl", "Wrong_Format", { shouldValidate: true });
                    document.getElementById("Filerequired").innerHTML =
                        "Please upload only .jpg, .jpeg, .png file!";
                    document.getElementById("Filerequired").style.display = "block";

                    return false;
                } else if (file.size > process.env.KNOWLEDGEREPO_THUMBNAIL_SIZE) {
                    setLogo({
                        ...logo,
                        Logofile: null,
                        lblFile: "File size should be 50KB",
                    });
                    setValue("imageControl", "Thumbnail_size", {
                        shouldValidate: true,
                    });
                    document.getElementById("Filerequired").innerHTML =
                        "File size should be 50KB";
                    document.getElementById("Filerequired").style.display = "block";
                    return false;
                }
            }
            uploadFile(e, mode);

        },
        [uploadFile, setValue, watch, fileValues, logo]
    );

    const uploadFile = useCallback(
        (e, mode) => {
            const file = e.target.files[0];
            const csvReader = new FileReader();
            csvReader.onload = async function () {
                let fileType;
                const arr = (new Uint8Array(csvReader.result)).subarray(0, 4);
                let header = '', temp = 0;
                for (let i = 0; i < arr.length; i++) {
                    header += arr[i].toString(16);
                }
                const imageExtension = ["jpg", "jpeg", "png"];
                const videoExtension = ["mp4", "avi", "mov"];
                const docExtension = ["doc", "docx", "zip", "pdf", "csv", "xls", "xlsx"];
                const audioExtension = ["mp3"]
                const extension = e.target.value
                    .substring(e.target.value.lastIndexOf(".") + 1)
                    .toLowerCase();

                let contentType;
                if (mode == "ThumbNail") {
                    contentType = imageExtension.indexOf(extension) >= 0 ? "image/" + extension : "application/" + extension;
                } else {
                    if (watch("ddlFileType") == "Image") {
                        contentType = imageExtension.indexOf(extension) >= 0 ? "image/" + extension : "application/" + extension;
                    } else if (watch("ddlFileType") == "Video") {
                        contentType = videoExtension.indexOf(extension) >= 0 ? extension == "avi" ? "video/x-ms-video" : extension == "mov" ? "video/quicktime" : "video/" + extension : "application/" + extension;
                    } else if (watch("ddlFileType") == "Audio") {
                        contentType = audioExtension.indexOf(extension) >= 0 ? "audio/mpeg" : "application/" + extension;
                    } else if (watch("ddlFileType") == "Document") {
                        contentType = docExtension.indexOf(extension) >= 0 ? extension == "zip" ? "application/zip" :
                            extension == "doc" ? "application/msword" : extension == "docx" ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document" : extension == "xls" ? "application/vnd.ms-excel" :
                                extension == "xlsx" ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : extension == "csv" ? "text/" + extension :
                                    extension == "pdf" ? "application/" + extension : "application/" + extension : "application/" + extension;
                    }
                }
                switch (header + '|' + contentType) {
                    case '89504e47|image/png':
                        fileType = 'image/png';
                        break;
                    case 'ffd8ffe0|image/jpg':
                    case 'ffd8ffe1|image/jpg':
                    case 'ffd8ffe2|image/jpg':
                        fileType = 'image/jpg';
                        break;
                    case 'ffd8ffe0|image/jpeg':
                    case 'ffd8ffe1|image/jpeg':
                    case 'ffd8ffe2|image/jpeg':
                        fileType = 'image/jpeg';
                        break;
                    case '25504446|application/pdf':
                        fileType = 'application/pdf';
                        break;
                    case '504b34|application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': /*xlsx*/
                        fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                        break;
                    case '89504e47|application/vnd.ms-excel':
                    case 'd0cf11e0|application/vnd.ms-excel':
                    case '65737472|application/vnd.ms-excel':
                        fileType = 'application/vnd.ms-excel'; // XLS file format
                        break;
                    case '51756573|text/csv':
                    case '504b2c53|text/csv':
                    case '22636f75|text/csv':
                    case '55736572|text/csv':
                    case '22557365|text/csv':
                    case '2c53616d|text/csv':
                        fileType = 'text/csv';
                        break;
                    case '00014|video/quicktime':
                    case '6d6f6f76|video/quicktime':
                        fileType = 'video/quicktime'; // MOV file format
                        break;
                    case 'd0cf11e0a1b11ae1|application/msword':
                    case 'd0cf11e0|application/msword':
                        fileType = 'application/msword'; // DOC file format
                        break;
                    case '504b030414000600|application/vnd.openxmlformats-officedocument.wordprocessingml.document':
                    case '504b34|application/vnd.openxmlformats-officedocument.wordprocessingml.document':
                        fileType = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';// DOCX file format
                        break;
                    case '52494646|video/x-ms-video':
                        fileType = 'audio/vnd.rn-realaudio'; // AVI file format
                        break;
                    case '00020|video/mp4':
                        fileType = 'video/mp4';
                        break;
                    case '4944333|audio/mpeg':
                    case '49443303|audio/mpeg':
                        fileType = 'audio/mp3';
                        break;
                    case '504b34|application/zip':
                    case '504b0304|application/zip':
                    case '504b0708|application/zip':
                    case '504b0506|application/zip':
                    case '504b537058|application/zip':
                        fileType = 'application/zip'; // ZIP file format
                        break;
                    default:
                        fileType = 'unknown';
                        if (mode == "ThumbNail") {
                            if (fileType != contentType) {
                                setLogo({
                                    ...logo,
                                    Logofile: null,
                                    lblFile: "File format seems to be changed!",
                                });
                                setValue("imageControl", " File format seems to be changed!", {
                                    shouldValidate: true,
                                });
                                document.getElementById("Filerequired").innerHTML =
                                    " File format seems to be changed!";
                                document.getElementById("Filerequired").style.display = "block";
                            }
                            return false
                        } else {
                            // fileInput.value = "";
                            if (fileType != contentType) {
                                setFileValues({
                                    ...fileValues,
                                    TextName: "Select File",
                                    FilePath: "",
                                });
                                setValue("File", "fileFormat", { shouldValidate: true });
                            }
                            return false
                        }
                        break;
                }
                if (temp == 1) {
                    return false;
                }

                const fetchURL =
                    process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${e.target.files[0].name}&TenantID=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&ManagementType=KnowledgeRepository&Type=${mode == "ThumbNail" ? mode : watch("ddlFileType")}`;
                const headers = {
                    method: "GET",
                    headers: {
                        authorizationToken: await Auth.currentSession().then((s) =>
                            s.getAccessToken().getJwtToken()
                        ),
                        defaultrole: props?.TenantInfo.UserGroup,
                        groupmenuname: "CourseManagement",
                        menuid: "300406",
                    },
                };


                const presignedHeader = {
                    method: "PUT",
                    headers: {
                        "content-type": contentType,
                    },
                    body: file,
                };
                const finalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);

                if (mode == "Files") {
                    if (finalStatus[0] != "Success") {
                        setFileValues({
                            ...fileValues,
                            TextName: "Select File",
                            FilePath: "",
                            pathchanged: false,
                            setfile: "",
                        });
                        setValue("File", "Error", { shouldValidate: true });
                        return;
                    } else {
                        setFileValues({
                            TextName: e.target.files[0].name,
                            FilePath: finalStatus[1],
                            path: finalStatus[1],
                            pathchanged: true,
                            setfile: watch("ddlFileType"),
                        });
                        setValue("File", "exist", { shouldValidate: true });
                        if ((watch("ddlFileType") == "Document" && e.target.files[0].name?.split('.')[1] != "pdf") ) {
                            (document.getElementById("tgAccess").checked = true)
                            setValue("tgAccess", true);
                            toggleAction.current = true
                        } else {
                            (document.getElementById("tgAccess").checked = false)
                            setValue("tgAccess", false);
                            toggleAction.current = false
                        }
                    }
                } else {
                    if (finalStatus[0] == "Success") {
                        setLogo({
                            Logofile: file,
                            lblFile: "",
                            ImgHeight: "w-44 h-20",
                            uploadImage: file,
                            TentImgUrl: finalStatus[1],
                            setimage: "ThumbNail",
                        });
                        setValue("imageControl", "Image", { shouldValidate: true });

                    } else {
                        setValue("imageControl", "Error", { shouldValidate: true });
                        setLogo({
                            Logofile: null,
                            ImgHeight: "",
                            lblFile: "",
                            uploadImage: "",
                            TentImgUrl: null,
                        });

                        return;
                    }
                }
            };
            csvReader.readAsArrayBuffer(file);
        },
        [fileValues, logo, props?.TenantInfo.BucketName, props?.TenantInfo.RootFolder, props?.TenantInfo.TenantID, props?.TenantInfo.UserGroup, setValue, watch]
    );

    const removeImg = () => {
        setValue("imageControl", "", { shouldValidate: true });
        setLogo({
            Logofile: null,
            lblFile: "",
            ImgHeight: "",
            uploadImage: null,
            TentImgUrl: null,
            setimage: "removeimage"
        });
        setValue("imageControl", "");
        document.getElementById("Filerequired").style.display = "none";
    };

    const clearField = useCallback(() => {
        setValue("txtAssetName", "")
        // setHTMLContents("", message);
        setValue("ddlCategory", "")
        setValue("ddlFileType", "")
        setValue("txtAuthor", "")
        setValue("txtURL", "")
        setLogo({
            Logofile: null,
            lblFile: "",
            ImgHeight: "",
            uploadImage: null,
            TentImgUrl: null,
            setimage: ""
        });
        setValue("imageControl", "");
        document.getElementById("Filerequired").style.display = "none";
        setFileValues({ TextName: "Select File", FilePath: "", path: "" })
        document.getElementById("tgAccess").checked = false
        clearErrors()
    }, [clearErrors, setValue])

    const getComponent = useCallback((PopupName) => {
        const componentData = {
            Category: (
                <Category
                    Mode="Popup"
                    setOpen={setOpen}
                    open={open}
                    user={props?.user}
                    TenantInfo={props?.TenantInfo}
                    Title={router.query["Mode"] == "Create" ? "Create Asset" : "Edit Asset"}
                />
            ),
        };
        return componentData[PopupName];
    },
        [open, props?.user, props?.TenantInfo, router.query]
    );


    const submitHandler = useCallback(async (data) => {
        document?.activeElement?.blur();
        setValue("submit", true)
        document.getElementById("Filerequired").style.display = "none";
        const PK = "TENANT#" + props?.TenantInfo.TenantID;
        const AssetId = router.query["Mode"] == "Edit" ? pageData?.AssetData?.AssetID : Math.random().toString(25).substring(2, 12);
        const SK = router.query["Mode"] == "Edit" ? pageData?.AssetData?.SK : "KNOWLEDGEREPO#ASSET#" + AssetId;
        const query = createXlmsBatchAssetInfo;

        function getCategoryName() {
            const categoryName = categoryState?.filter(item => {
                return item.value == data.ddlCategory;
            });
            return categoryName?.[0].text;
        }

        let thumbNailUrl, fileUrl, finalResult;
        if (logo?.setimage == "ThumbNail") {
            const fetchURL =
                process.env.ACTIVITY_UNSAVED_TO_SAVED +
                `?FileName=${logo?.Logofile?.name}&TenantID=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&ManagementType=KnowledgeRepository&Type=ThumbNail&AssetID=${AssetId}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationToken: await Auth.currentSession().then((s) =>
                        s.getAccessToken().getJwtToken()
                    ),
                    defaultrole: props?.TenantInfo.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300406",
                },
            };

            finalResult = await APIGatewayGetRequest(fetchURL, headers);
            thumbNailUrl = await finalResult?.res?.text();
        }

        if (fileValues?.setfile == watch("ddlFileType")) {
            const fetchURL =
                process.env.ACTIVITY_UNSAVED_TO_SAVED +
                `?FileName=${fileValues?.TextName}&TenantID=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&ManagementType=KnowledgeRepository&Type=${watch("ddlFileType")}&AssetID=${AssetId}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationToken: await Auth.currentSession().then((s) =>
                        s.getAccessToken().getJwtToken()
                    ),
                    defaultrole: props?.TenantInfo.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300406",
                },
            };
            finalResult = await APIGatewayGetRequest(fetchURL, headers);
            fileUrl = await finalResult?.res?.text();
        }


        const temp = [{
            PK: PK,
            SK: SK,
            AssetID: AssetId,
            AssetName: data.txtAssetName,
            // AssetDescription: getContents(message),
            CategoryID: data.ddlCategory,
            CategoryName: getCategoryName(),
            FileType: data.ddlFileType,
            UploadFile: fileValues.pathchanged == true ? fileUrl : pageData?.AssetData?.UploadFile,
            ThumbNail: logo?.setimage == "ThumbNail" ? thumbNailUrl : logo?.setimage == "removeimage" && router.query["Mode"] == "Edit" ? null : pageData?.AssetData?.ThumbNail,
            AttachURL: data.txtURL,
            IsDownloadAccess: toggleAction.current == undefined ? false : toggleAction.current,
            Author: data.txtAuthor,
            IsSuspend: false,
            IsDeleted: false,
            CreatedBy: router.query["Mode"] != "Edit" ? props?.user?.username : pageData?.AssetData?.CreatedBy,
            CreatedDate: router.query["Mode"] != "Edit" ? new Date() : pageData?.AssetData?.CreatedDate,
            LastModifiedBy: router.query["Mode"] != "Edit" ? props?.user?.username : pageData?.AssetData?.LastModifiedBy,
            LastModifiedDate: new Date()
        }]


        const variables = { input: [...temp] }

        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;

        if (watch("ddlFileType") == "Video") {
            const fetchUrl = process.env.KNOWLEDGEREPO_VIDEO_COURSE_STREAMING +
                `?FileName=${fileValues?.TextName}&TenantID=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&ManagementType=KnowledgeRepository&Type=Video&AssetID=${AssetId}&UserSub=${props?.user.attributes?.sub}`;
            const headers = {
                method: "POST",
                headers: {
                    authorizationtoken: props?.user?.signInUserSession.accessToken.jwtToken,
                    defaultrole: props?.TenantInfo?.UserGroup,
                    groupmenuname: "CourseManagement",
                    menuid: "300200",
                }
            };
            await APIGatewayGetRequest(fetchUrl, headers);
        }

        finalResponse(finalStatus);
        setValue("submit", false)
    }, [categoryState, fileValues?.TextName, fileValues.pathchanged, fileValues?.setfile, finalResponse, logo?.Logofile?.name, logo?.setimage, pageData?.AssetData?.AssetID, pageData?.AssetData?.CreatedBy, pageData?.AssetData?.CreatedDate, pageData?.AssetData?.LastModifiedBy, pageData?.AssetData?.SK, pageData?.AssetData?.ThumbNail, pageData?.AssetData?.UploadFile, props?.TenantInfo.BucketName, props?.TenantInfo.RootFolder, props?.TenantInfo.TenantID, props?.TenantInfo.UserGroup, props?.user.attributes?.sub, props?.user?.signInUserSession.accessToken.jwtToken, props?.user?.username, router.query, setValue, watch])


    return (
        <>
            <Container PageRoutes={PageRoutes} loader={pageData?.CategoryData == undefined ? true : false} title="Create Asset">
                <NVLPageModalPopup
                    ModalType="Page"
                    ScreenName={`Create Category`}
                    PageComponent={getComponent("Category")}
                    open={open}
                    setOpen={setOpen}
                />
                <form onSubmit={handleSubmit(submitHandler)} id="divUpload">
                    {!(pageData?.AssetData?.FileProcessing == undefined || pageData?.AssetData?.FileProcessing == 0) && <NVLWarning Header={"In Processing!..."} Content={"File is processing, it will take some time"}></NVLWarning>}
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.MessageTop} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className={` ${watch("File") == "Uploading" || watch("submit") || (pageData?.AssetData?.FileProcessing != undefined && pageData?.AssetData?.FileProcessing != 0) ? "nvl-FormContent pointer-events-none" : "nvl-FormContent"}`}>
                        <NVLTextbox id="txtAssetName" labelText="Asset Name" labelClassName="nvl-Def-Label pb-1" title="Asset Name" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        {/* In Future */}
                        {/* <NVLlabel text="Asset Description" className="nvl-Def-Label" />
                        <NVLRichTextBox id="txtAssetDescription" className="isResizable nvl-non-mandatory nvl-Def-Input" setState={setMessage} /> */}
                        <NVLSelectField id="ddlCategory" options={categoryState.length != undefined ? categoryState : [{ value: "", text: "Select" }]} labelText="Category" labelClassName="nvl-Def-Label pb-1" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <div className="text-right">
                            <NVLButton id="btncreateCategory" ButtonType="link" type={"button"} text=" + Create Category"
                                onClick={() => {
                                    setOpen((open) => {
                                        return open + 1;
                                    });
                                }}
                            />
                        </div>
                        <NVLSelectField id="ddlFileType" options={fileType} labelText="File Type" labelClassName="nvl-Def-Label pb-1" className={"nvl-mandatory nvl-Def-Input "} errors={errors} register={register} />
                        <div className={watch("ddlFileType") == "" || watch("ddlFileType") == "URL" ? "hidden" : ""}>
                            <NVLlabel text="Upload File" className="nvl-Def-Label"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <div className="grid grid-flow-col gap-1">
                                <NVLFileUpload text={fileValues?.TextName == null || fileValues?.TextName == "" ? "Select File" : fileValues?.TextName} className={"nvl-mandatory"} accept={`${`Acceptable file format: ${getHelpInfo()} <br>File size should not exceed more than 1GB`}`} onChange={(e) => fileValidation(e, "Files")} />
                                <div className="pt-2">
                                    <NVLLoader className={`text-sm  ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                                </div>
                                <div className="my-auto">
                                    <NVLlabel className="nvl-Def-Label" HelpInfo={`Acceptable file format: ${getHelpInfo()} <br>File size should not exceed 1GB`} HelpInfoIcon={"fa fa-solid fa-circle-question pt-1"} />
                                </div>
                            </div>
                            <div className={"Center-Aligned-Items {invalid-feedback} text-red-500 text-sm pt-2 "}>
                                {errors?.File?.message}
                            </div>
                        </div>
                        <div className={watch("ddlFileType") == "" || watch("ddlFileType") != "URL" ? "hidden" : ""}>
                            <NVLTextbox id="txtURL" labelText="URL" labelClassName="nvl-Def-Label pb-1" title="URL" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        </div>
                        <div>
                            <div className="flex pt-4">
                                <NVLlabel text="Upload ThumbNail" className="nvl-Def-Label "></NVLlabel>
                                <NVLlabel className="nvl-Def-Label" HelpInfo={`${"Acceptable file format: jpg, png, jpeg.<br> File size should not exceed 50KB"}`} HelpInfoIcon={"fa fa-solid fa-circle-question"} />
                            </div>
                            <NVLImageUpload watch={watch} control={"imageControl"} accept={`${"Acceptable file format: .jpg, .png, .jpeg.<br> File size should not exceed 50KB"}`} Logofile={logo?.Logofile} text={"Upload Thumbnail"} UploadLogo={(e) => fileValidation(e, "ThumbNail")}
                                removeImg={removeImg} uploadImage={logo?.uploadImage} ImgHeight={logo?.ImgHeight} />
                            <div id="Filerequired" className="{invalid-feedback} text-red-500 text-xs pt-1">
                                {errors?.imageControl?.message}
                            </div>
                        </div>
                        <div id="File" className="{invalid-feedback} text-red-500 text-xs pt-2" />
                        {watch("ddlFileType") != "URL" && <div className="flex gap-4 pt-3">
                            <NVLlabel text="Download access" className="nvl-Def-Label pt-1" />
                            <NVLToggle id="tgAccess" name="tgAccess" onChange={(e) => { toggleAction.current = e.target.checked }} errors={errors} register={register} />
                        </div>}
                        <NVLTextbox id="txtAuthor" labelText="Author" labelClassName="nvl-Def-Label pb-1 pt-2" title="Author" className={"nvl-non-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        <div className="flex justify-center gap-2 pt-4">
                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Save" : ""} type="submit" className={"w-32 nvl-button bg-primary text-white"}>
                                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                            </NVLButton>
                            <NVLButton id="btnCancel" text={router.query["Mode"] != "Edit" ? "Clear" : "Cancel"} type="button" className="nvl-button w-28" onClick={() => router.query["Mode"] != "Edit" ? clearField() : router.push("/KnowledgeRepository/KnowledgeRepositoryList")}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    )
}
export default UploadDocument;