import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { createXlmsBatchAssetInfo, updateXlmsRepositoryCategory } from "@graphql/graphql/mutations";
import { listXlmsAssetInfo, listXlmsRepositoryCategory } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";

function ManageCategory(props){
    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("")
    const router=useRouter()
    const [submit,setSubmit] =  useState()
    const PageRoutes = useMemo(() => {
        return [{ path: "/KnowledgeRepository/KnowledgeRepositoryList", breadcrumb: "Knowledge Repository"},
        { path: "", breadcrumb: "Manage Category" }]
    }, [])

    const headerColumn = [
        {HeaderName: "Category Name", Columnvalue: "CategoryName", HeaderCss: "w-3/12", },
        {HeaderName: "Category Description", Columnvalue: "Description", HeaderCss: "w-3/12"}, 
        {HeaderName: "Date", Columnvalue: "CreatedDate", HeaderCss: "w-0/12 whitespace-nowrap" },
        {HeaderName: "Status", Columnvalue: "IsSuspend", HeaderCss: "w-3/12"}, 
        {HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-3/12"},
]

const searchBoxVal = (e) => {
  setSearch(e);
  setIsRefreshing((count) => {
    return count + 1;
  });
}

const refreshData = async () => {
  setSearch("");
  setIsRefreshing((count) => {
    return count + 1;
  });
};

function resetPopUp() {
  setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
  document.getElementById("tableSearch").value = "";
}

function popup(type, PK, SK, Content) {
  setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
}


async function updateField(e) {
  e.preventDefault();
  setSubmit(true)
  let isSus = false;
  let isDelete = false;
  if (popupValues.Type == "isSuspend") {
    isSus = true;
  } else if (popupValues.Type == "isDelete") {
    isDelete = true;
  } 

  let categoryID = popupValues.SK?.split("#")[2]

  const AssetList = await AppsyncDBconnection(listXlmsAssetInfo, { PK: popupValues.PK, SK: "KNOWLEDGEREPO#ASSET#", IsDeleted:false } , props.user.signInUserSession.accessToken.jwtToken)

  let CategoryAsset =[] , FinalStatus;
 

     FinalStatus = await AppsyncDBconnection(updateXlmsRepositoryCategory, { input: { PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus , IsDeleted : isDelete , LastModifiedDate : new Date() } }, props.user.signInUserSession.accessToken.jwtToken)
    AssetList.res?.listXlmsAssetInfo.items?.filter((asset)=>{
      if (asset.CategoryID == categoryID) {
       CategoryAsset = ([...CategoryAsset,{ ...asset, PK:asset.PK , SK:asset.SK ,  IsSuspend: isSus, IsDeleted : isDelete,  LastModifiedDate : new Date()}])
      }
   })
   await AppsyncDBconnection( createXlmsBatchAssetInfo, { input: [...CategoryAsset] }, props.user.signInUserSession.accessToken.jwtToken)
  
  if (FinalStatus?.Status == "Success") {
    refreshData();
  }
  setSubmit(false)
  resetPopUp();
}

function getDateFormat(CreatedDt) {

  return (new Date(CreatedDt).toDateString().substring(4))
}

const cancelEvent = (e) => {
  e.preventDefault();
  resetPopUp();
};

const actionRestriction = useCallback((getItem) => {
    let actionList = [];
    if (props.RoleData?.RepositoryShowCategory && getItem.IsSuspend) {
      actionList.push(
        {
          id: 1,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
          name: "Show Category",
          action: () =>
            popup(
              "isUnSuspend",
              getItem.PK,
              getItem.SK,
              "Are you sure to Show Category?"
            ),
        }
      )
    }
    if (props.RoleData?.RepositoryDeleteCategory && getItem.IsSuspend) {
      actionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete Category",
          action: () =>
            popup(
              "isDelete",
              getItem.PK,
              getItem.SK,
              "Are you sure to Delete Category?"
            ),
        }
      )
    }
    if (props.RoleData?.RepositoryEditCategory && !getItem.IsSuspend) {

      actionList.push(
        {
          id: 3,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit Category",
          action: () =>

            router.push(
              `/KnowledgeRepository/Category?Mode=Edit&CategoryID=${getItem.CategoryID}`
            ),
        }
      )
    }
    if (props.RoleData?.RepositoryHideCategory && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 4,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
          name: "Hide Category",
          action: () =>
            popup(
              "isSuspend",
              getItem.PK,
              getItem.SK,
              "Are you sure to Hide Category?"
            ),
        }
      )
    }
    return actionList;
  }, [props.RoleData?.RepositoryDeleteCategory, props.RoleData?.RepositoryEditCategory, props.RoleData?.RepositoryHideCategory, props.RoleData?.RepositoryShowCategory, router])

const gridDataBind = useCallback(
    (viewData) => {
      const rowGrid = [];

      viewData && viewData.map((getItem, index) => {
        let regex = /(<([^>]+)>)/gi,
          body = getItem.CategoryDescription,
          result = body?.replace(regex, "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " "),
          actionList = [];
          
        actionList = actionRestriction(getItem)
        rowGrid.push({
          PK: (
            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
          ),
          SK: (
            <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
          ),
          CategoryID: (
            <NVLlabel id={"lblCategoryId" + (index + 1)} name="CategoryID" text={getItem.SK} />
          ),
          CategoryName: (
            <>
              <NVLlabel id={"txtCategoryName" + (index + 1)} text={getItem.CategoryName}></NVLlabel>
            </>
          ),
          Description:(
            <>
            <NVLlabel id={"txtCategoryDescription" + (index + 1)} text={result}></NVLlabel>
          </>
          ),
          CreatedDate:(
            <>
              <NVLlabel id={"txtDate" + (index + 1)} text={getDateFormat(getItem.CreatedDate)}></NVLlabel>
            </>
          ),
          IsSuspend: (
            <>
              <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                <div
                  className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"
                    }	`}
                ></div>
                <NVLlabel
                  className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"
                    } my-auto ml-2	`}
                  text={!getItem.IsSuspend ? "Active" : "Inactive"}
                ></NVLlabel>
              </div>
            </>
          ),
          Action: (
            <NVLRapidModal
              id={"RapidModal" + (index + 1)}
              ActionList={actionList}
              index={(index+1) > 10 ? (index+1)%10 : index+1}
            ></NVLRapidModal>
          ),
        });
      });

      return rowGrid;
    }, [actionRestriction]
  );

  const headerHandler = (e, url) => {
    e.preventDefault();
    router.push(url);
  };
  const variable = useMemo(()=>{
    return { PK: "TENANT#" + props.TenantInfo.TenantID , SK:"KNOWLEDGEREPO#CATEGORY#", IsDeleted:false}
  },[props.TenantInfo.TenantID]) 

  

return (
    <>
    <Container  PageRoutes={PageRoutes} title={"Manage Category"}>
    <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} IsSearch={props.RoleData?.RepositoryCategorySeTenanth ? true : false} ButtonID5="btnCategory" LinkName5="Create Category" 
    className5={props.RoleData?.RepositoryCreateCategory ? (props?.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectHome={"/"} RedirectAction5={(e) => headerHandler(e, "/KnowledgeRepository/Category?Mode=Create")} href5="/KnowledgeRepository/Category?Mode=Create" placeholder={"Search by Category Name"} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshData} RedirectAction4={() => refreshData()}  IsNestedHeader />
        <div className="max-w-full w-full justify-center">
          <NVLGridTable
            user={props.user}
            refershPage={isRefreshing}
            id="tblActivityList" Search={search}
            HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsRepositoryCategory}
            querryName={"listXlmsRepositoryCategory"}
            variable={variable} />
        </div>
        <NVLModalPopup ButtonYestext="Yes" loader={submit} SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
    </Container>
    </>
)
}
export default ManageCategory;