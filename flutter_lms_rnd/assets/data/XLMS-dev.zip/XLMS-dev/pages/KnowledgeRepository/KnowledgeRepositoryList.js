import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { createXlmsBatchAssetInfo } from "@graphql/graphql/mutations";
import { getXlmsAssetInfo, listXlmsAssetInfo } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";

function KnowledgeRepository(props){
    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [search, setSearch] = useState("")
    const router=useRouter()
    const PageRoutes = useMemo(() => {
        return [{ path: "", breadcrumb: "Knowledge Repository"}]
    }, [])

    const headerColumn = [
        {HeaderName: "Asset Name", Columnvalue: "AssetName", HeaderCss: "w-3/12", },
        {HeaderName: "Asset Type", Columnvalue: "Type", HeaderCss: "w-3/12"}, 
        { HeaderName: "Date", Columnvalue: "CreatedDate", HeaderCss: "w-0/12 whitespace-nowrap" },
        { HeaderName: "Status", Columnvalue: "IsSuspend", HeaderCss: "w-0/12 " },
        {HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-3/12"},
]

const searchBoxVal = (e) => {
  setSearch(e);
  setIsRefreshing((count) => {
    return count + 1;
  });
}

const refreshData = async () => {
  setSearch("");
  setIsRefreshing((count) => {
    return count + 1;
  });
};

function resetPopUp() {
  setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
  document.getElementById("tableSearch").value = "";
}

function popup(type, PK, SK, Content) {
  setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
}

async function updateField(e) {
  e.preventDefault();
  let isSus = false;
  let isDelete = false;
  if (popupValues.Type == "isSuspend") {
    isSus = true;
  } else if (popupValues.Type == "isDelete") {
    isDelete = true;
  }
  let AssetData  , UpdateData=[]
  let AssetList = await AppsyncDBconnection(getXlmsAssetInfo,{PK: popupValues.PK, SK: popupValues.SK} , props.user.signInUserSession.accessToken.jwtToken )
   AssetData = (AssetList.res?.getXlmsAssetInfo)
   
   UpdateData = ([...UpdateData,{...AssetData, PK: popupValues.PK, SK: popupValues.SK, IsSuspend: isSus , IsDeleted: isDelete, LastModifiedDate : new Date()}])

  let FinalStatus = await AppsyncDBconnection(createXlmsBatchAssetInfo, { input:  [...UpdateData] }, props.user.signInUserSession.accessToken.jwtToken)


  if (FinalStatus.Status == "Success") {
    refreshData();
  }
  resetPopUp();
}

const cancelEvent = (e) => {
  e.preventDefault();
  resetPopUp();
};

const actionRestriction = useCallback((getItem) => {
    let actionList = [];
    if (props.RoleData?.ShowRepositoryAssets && getItem.IsSuspend) {
      actionList.push(
        {
          id: 1,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
          name: "Show Asset",
          action: () =>
            popup(
              "isUnSuspend",
              getItem.PK,
              getItem.SK,
              "Are you sure to Show Asset?"
            ),
        }
      )
    }
    if (props.RoleData?.DeleteRepositoryAssets && getItem.IsSuspend) {
      actionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete Asset",
          action: () =>
            popup(
              "isDelete",
              getItem.PK,
              getItem.SK,
              "Are you sure to Delete Asset?"
            ),
        }
      )

    }
    if (props.RoleData?.EditRepositoryAssets && !getItem.IsSuspend) {

      actionList.push(
        {
          id: 3,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit Asset",
          action: () =>
            router.push(
              `/KnowledgeRepository/UploadDocument?Mode=Edit&AssetID=${getItem.AssetID}`
            ),
        }
      )
    }
    if (props.RoleData?.HideRepositoryAssets && !getItem.IsSuspend) {
      actionList.push(
        {
          id: 4,
          Color: "text-yellow-600",
          Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
          name: "Hide Asset",
          action: () =>
            popup(
              "isSuspend",
              getItem.PK,
              getItem.SK,
              "Are you sure to Hide Asset?"
            ),
        }
      )
    }
    return actionList;
  }, [props.RoleData?.DeleteRepositoryAssets, props.RoleData?.EditRepositoryAssets, props.RoleData?.HideRepositoryAssets, props.RoleData?.ShowRepositoryAssets, router])

  function getDateFormat(CreatedDt) {
    return (new Date(CreatedDt).toDateString().substring(4))
  }

const gridDataBind = useCallback(
    (viewData) => {
      const rowGrid = [];
 
      viewData && viewData.map((getItem, index) => {

        let regex = /(<([^>]+)>)/gi,
          body = getItem.ActivityDescription,
          result = body?.replace(regex, "").body?.replace(/&amp;/g, "&").replace(/&nbsp;/g, ' '),
          actionList = [];
        actionList = actionRestriction(getItem)
        rowGrid.push({
          PK: (
            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
          ),
          SK: (
            <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
          ),
          AssetId: (
            <NVLlabel id={"lblAssetId" + (index + 1)} name="AssetId" text={getItem.SK} />
          ),
          AssetName: (
            <>
              <NVLlabel id={"txtAssetName" + (index + 1)} text={getItem.AssetName}></NVLlabel>
            </>
          ),
          Type:(
            <>
             <NVLlabel id={"txtAssetType" + (index + 1)} text={getItem.FileType} />
            </>
          ),
          CreatedDate:(
            <>
            <NVLlabel id={"txtAssetType" + (index + 1)} text={getDateFormat(getItem.CreatedDate)} />
            </>
          ),
          IsSuspend: (
            <>
              <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                <div
                  className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"
                    }	`}
                ></div>
                <NVLlabel
                  className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"
                    } my-auto ml-2	`}
                  text={!getItem.IsSuspend ? "Active" : "Inactive"}
                ></NVLlabel>
              </div>
            </>
          ),
          Action: (
            <NVLRapidModal
              id={"RapidModal" + (index + 1)}
              ActionList={actionList}
              index={(index+1) > 10 ? (index+1)%10 : index+1}
            ></NVLRapidModal>
          ),
        });
      });
      return rowGrid;
    }, [actionRestriction]
  );

  const headerHandler = (e, url) => {
    e.preventDefault();
    router.push(url);
  };
  const variable = {PK: "TENANT#" + props.TenantInfo.TenantID , SK:"KNOWLEDGEREPO#ASSET#", IsDeleted:false}


return (
    <>
    <Container title="Knowledge Repository" PageRoutes={PageRoutes}>
    <NVLHeader IsSearch={props.RoleData?.RepositoryKeywordSeTenanth ? true : false} TabRouting={props?.GeneralRoleData?.AllowNewTab}
    ButtonID5="btnCategory" LinkName5="Manage Category" className5={props.RoleData?.RepositoryManageCategory ? (props?.TabRouting == true ? "" : "nvl-button-success") : "hidden"} SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshData} RedirectAction3={() => refreshData()}
    ButtonID4="btnUpload" LinkName4="Upload Document" className4={props.RoleData?.RepositoryUploadDocument ? (props?.TabRouting == true ? "" : "nvl-button-success") : "hidden"}
    RedirectHome={"/"} RedirectAction5={(e) => headerHandler(e, "/KnowledgeRepository/ManageCategory")} href5="/KnowledgeRepository/ManageCategory" 
    RedirectAction4={(e) => headerHandler(e, "/KnowledgeRepository/UploadDocument?Mode=Create")} href4="/KnowledgeRepository/UploadDocument?Mode=Create"
    placeholder={"Search by Asset Type"}  IsNestedHeader />
        <div className="max-w-full w-full justify-center">
          <NVLGridTable
            user={props.user}
            refershPage={isRefreshing}
            id="tblActivityList" Search={search}
            HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsAssetInfo}
            querryName={"listXlmsAssetInfo"}
            variable={variable} />
        </div>
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content}  />
    </Container>
    </>
)
}
export default KnowledgeRepository;