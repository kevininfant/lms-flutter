import Container from "@components/Container/Container";
import CompanyAdminDashboard from "@Home/CompanyAdminDashboard";
import SiteAdminDashboard from "@Home/SiteAdminDashboard";
import UserDashboard from "@Home/UserDashboard";

function Index(props) {
  const UserGrp = props.user.signInUserSession.accessToken.payload["cognito:groups"]?.[0];

  return (
    <>
      <Container user={props.user} signOut={props.signOut} title="Dashboard">
        {UserGrp == "SiteAdmin" && <SiteAdminDashboard {...props}></SiteAdminDashboard>}
        {UserGrp == "CompanyAdmin" && <CompanyAdminDashboard {...props} ></CompanyAdminDashboard>}
        {(UserGrp == "User" || UserGrp == "Manager" || UserGrp == "Trainer") && <UserDashboard {...props}></UserDashboard>}
      </Container>
    </>
  );
}
export default Index;
