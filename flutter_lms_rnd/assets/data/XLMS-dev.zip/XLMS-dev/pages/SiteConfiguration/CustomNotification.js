import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRichTextBox, { getContents, setContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLTextBox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCustomNotification, updateXlmsCustomNotification } from "src/graphql/mutations";
import { getXlmsCustomNotification, getXlmsDefaultNotificationFields, listXlmsCustomFields, listXlmsCustomNotification } from "src/graphql/queries";
import * as Yup from "yup";

function CustomNotification(props) {

    const router = useRouter();
    const [csrFetchedNotifyData, setCsrFetchedNotifyData] = useState();
    const initialModalState = {};


    useEffect(() => {
        const dataSource = async () => {
            let TenantID = "";
            if (props.user.signInUserSession.accessToken.payload["cognito:groups"][0] != "SiteAdmin") {
                TenantID = props.user?.attributes["custom:tenantid"];
            }
            else {
                TenantID = decodeURIComponent(String(router.query["TenantID"]));
            }
            const mode = decodeURIComponent(String(router.query["Mode"]));
            const templateId = decodeURIComponent(String(router.query["TemplateID"]));
            let CustomNotificationData;
            if (mode == "Edit") {
                CustomNotificationData = await AppsyncDBconnection(getXlmsCustomNotification, { PK: "TENANT#" + TenantID, SK: "CUSTOMNOTIFICATION#" + templateId }, props.user.signInUserSession.accessToken.jwtToken);
            }
            const notificationFields = await AppsyncDBconnection(getXlmsDefaultNotificationFields, { PK: "XLMS#DELIMETERFIELDS", SK: "NOTIFICATIONFIELDS#DELIMETER" }, props.user.signInUserSession.accessToken.jwtToken);
            const customFieldData = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + TenantID, SK: "CUSTOMFIELD#" }, props.user.signInUserSession.accessToken.jwtToken);
            setCsrFetchedNotifyData({
                customnotificationdata: mode == "Edit" && CustomNotificationData.res.getXlmsCustomNotification,
                mode: mode,
                NotificationData: notificationFields.res?.getXlmsDefaultNotificationFields?.DefaultFields,
                CustomFieldData: customFieldData.res?.listXlmsCustomFields?.items,
                TenantID: TenantID,
                TemplateID: templateId
            });

            const initialModalState = {
                ModalInfo: "Success",
                ModalTopMessage: "Success",
                ModalBottomMessage: "Details have been saved successfully.",
                ModalOnClickEvent: () => {
                    router.push(`/SiteConfiguration/CustomNotificationList?TenantID=${(TenantID)}`);
                },
            };
            setModalValues(initialModalState);
        };
        dataSource();
        return (() => {
            setCsrFetchedNotifyData((temp) => { return { ...temp }; });
        });
    }, [props.user?.attributes, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload, router, router.query]);

   

    const [modalValues, setModalValues] = useState(initialModalState);
    const [message, setMessage] = useState("");

    const notificationFields = useMemo((() => {
        if (csrFetchedNotifyData?.NotificationData != undefined) {
            const delimeterData = JSON.parse(csrFetchedNotifyData?.NotificationData);

            const customFieldDataList = [];
            csrFetchedNotifyData?.CustomFieldData && csrFetchedNotifyData?.CustomFieldData?.map((customField) => {
                customFieldDataList.push(customField.ProfileFieldName);
            });

            const finalCustomFieldData = [];
            customFieldDataList.map((customField) => {
                finalCustomFieldData.push({ customField: customField });
            });

            const finalDelimetersData = { ...delimeterData?.CompanyDetails, ...delimeterData?.ActivityDetails, ...delimeterData?.UserDetails, ...delimeterData?.CourseDetails, ...customFieldDataList };
            return Object.entries(finalDelimetersData);
        }
    }),[csrFetchedNotifyData?.CustomFieldData, csrFetchedNotifyData?.NotificationData]);

    const validationSchema = Yup.object().shape({
        txtTemplateName: Yup.string().required("Template name is required")
            .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Template name invalid").max(250, "Maximum 250 characters exceed ")
            .test("", "Template name already exist", async (e, { createError }) => {
               const tenantID = decodeURIComponent(String(router.query["TenantID"]))
                const response = await AppsyncDBconnection(listXlmsCustomNotification, {
                    PK: "TENANT#" + tenantID, SK: "CUSTOMNOTIFICATION#",

                    IsDeleted: false,

                }, props?.user.signInUserSession.accessToken.jwtToken);

                const existingTemplateName = response.res?.listXlmsCustomNotification?.items;
                const templateNameCheck = existingTemplateName?.some((template) =>
                    template?.TemplateName?.toLowerCase() == e?.toLowerCase());

                if (templateNameCheck && (csrFetchedNotifyData.mode == "Edit" || csrFetchedNotifyData.mode == "Create")
          && e?.toLowerCase() != existingTemplateName.TemplateName?.toLowerCase()) {
                    if (e?.toLowerCase() != csrFetchedNotifyData.customnotificationdata?.TemplateName?.toLowerCase()) {
                        return createError({ message: "Template name already exist" });
                    }
                }
                return true;
            }),

        txtTemplateDescr: Yup.string().max(500, "Maximum 500 characters exceed"),
        txtSubjectName: Yup.string().required("Subject name is required").matches(Regex("AlphaNumWithAllowedSpecialChar"), "Subject name is invalid").max(250, "Maximum 250 characters exceed"),

        random: Yup.string()
            .test("", "Message is required", (e) => {
                if (e == "Empty" || e == undefined) {
                    return false;
                }
                return true;
            }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, reset, formState, watch } = useForm(formOptions);
    const { errors } = formState;

    const finalResponse = (FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        }
        ModalOpen();
        
    };

    useEffect(() => {
        if (message != "") {
            message?.on("text-change", () => {
                if (getContents(message) == "" || getContents(message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {
                    setValue("random", "Empty", { shouldValidate: true });
                } else {
                    setValue("random", "NotEmpty", { shouldValidate: true });
                }
            });
        }
        setValue("submit", false);
        if (csrFetchedNotifyData?.mode === "Edit") {
            setValue("txtTemplateName", csrFetchedNotifyData.customnotificationdata?.TemplateName);
            setValue("txtTemplateDescr", csrFetchedNotifyData.customnotificationdata?.TemplateDescription);
            if (message != "") {
                setHTMLContents(csrFetchedNotifyData.customnotificationdata?.Message, message);
                message?.history?.clear();
                setValue("random", "NotEmpty", { shouldValidate: true });
            }
            setValue("txtSubjectName", csrFetchedNotifyData.customnotificationdata?.SubjectName);
        }
    }, [props, setValue, message, csrFetchedNotifyData?.mode, csrFetchedNotifyData?.customnotificationdata?.TemplateName, csrFetchedNotifyData?.customnotificationdata?.TemplateDescription, csrFetchedNotifyData?.customnotificationdata?.SubjectName, csrFetchedNotifyData?.customnotificationdata?.Message]);

    const submitHandler = async (data) => {
          setValue("submit", true);
        let PK = "",
            TemplateID = "",
            SK = "";
        PK = csrFetchedNotifyData.mode != "Edit" ? "TENANT#" + csrFetchedNotifyData?.TenantID : csrFetchedNotifyData.customnotificationdata.PK;
        TemplateID = csrFetchedNotifyData.mode != "Edit"?Math.random().toString(25).substring(2, 8):csrFetchedNotifyData.customnotificationdata.TemplateID;
        SK = csrFetchedNotifyData.mode != "Edit" ? "CUSTOMNOTIFICATION#" + TemplateID : csrFetchedNotifyData.customnotificationdata.SK;

        const messageData = getContents(message);

        if (message != "") {
            setValue("random", "NotEmpty", { shouldValidate: true });
        }

        const query = csrFetchedNotifyData.mode != "Edit" ? createXlmsCustomNotification : updateXlmsCustomNotification;
        const variables = {
            input: {
                PK: PK,
                SK: SK,
                TemplateID: TemplateID,
                TemplateName: data.txtTemplateName.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                TemplateDescription: data.txtTemplateDescr.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                SubjectName: data.txtSubjectName.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                Message: messageData,
                LastModifiedDate: new Date()
            },
        };
      

        const finalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
        finalResponse(finalStatus);
        setValue("submit", false);
    
    };

    const resetControls = (e) => {
        e.preventDefault();
        setHTMLContents("", message);
        document.getElementsByClassName("ql-editor")[0].innerHTML = "";
        reset();
    };


    const pageRoutes =  useMemo(()=>{return[
        { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
        { path: `/SiteConfiguration/NotificationSettingList?TenantID=${csrFetchedNotifyData?.TenantID}`, breadcrumb: "Notification Setting" },
        { path: `/SiteConfiguration/CustomNotificationList?TenantID=${csrFetchedNotifyData?.TenantID}`, breadcrumb: "Custom Notification" },
        { path: "", breadcrumb: `${csrFetchedNotifyData?.mode == "Create" ? "Add Notification" : "Edit Notification"}` }
    ];},[csrFetchedNotifyData?.TenantID, csrFetchedNotifyData?.mode]);

    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedNotifyData?.TenantID == undefined}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)} id="CustomNotificationForm" className={`${ watch("submit") ? "pointer-events-none px-2" : "px-2"}`}>
                    <div className="nvl-FormContent">
                        <NVLlabel text="Template Name" className="nvl-Def-Label pt-5">
                            <span className="text-red-500 text-lg">*</span>
                        </NVLlabel>
                        <NVLTextBox id="txtTemplateName" title="Enter the template name" errors={errors} className="nvl-mandatory pt-2 nvl-Def-Input" register={register}></NVLTextBox>

                        <NVLlabel text="Template Description" className="nvl-Def-Label"></NVLlabel>
                        <NVLMultilineTxtbox id="txtTemplateDescr" title="Enter template description" className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register}></NVLMultilineTxtbox>

                        <NVLlabel text="Subject Name" className="nvl-Def-Label">
                            <span className="text-red-500 text-lg">*</span>
                        </NVLlabel>
                        <NVLTextBox id="txtSubjectName" title="Enter Subject Name" className="nvl-mandatory nvl-Def-Input" errors={errors} register={register}></NVLTextBox>

                        <NVLlabel text="Message" className="nvl-Def-Label">
                            <span className="text-red-500 text-lg">*</span>
                        </NVLlabel>
                        <NVLRichTextBox id="txtMessage" className={"isResizable nvl-mandatory !nvl-Def-Input"} setState={setMessage}></NVLRichTextBox>
                        <div className={"invalid-feedback   text-red-500 text-sm "}>{errors?.random?.message}</div>

                        <NVLlabel showFull text="* Click on the below items to add it in the Description field."></NVLlabel>
                        <div className="pt-2 flex gap-6 font-semibold">
                            <div className="gap-4 flex flex-wrap text-2xl">
                                {notificationFields && Array.from(notificationFields)?.map((fieldsData) => {
                                    return (
                                        <>
                                            <NVLlabel id="lblUserName" className="NotifyItems text-lg" text={fieldsData?.[1]} onClick={() => {
                                                setContents("{" + fieldsData?.[0] > 0 ? fieldsData?.[0] : "{" + fieldsData?.[1] + "}", message);
                                            }}
                                            />
                                        </>
                                    );
                                })}
                            </div>
                        </div>
                        <div className="flex flex-row gap-1 justify-center nvl-Def-Input mt-4">
                            <NVLButton id="btnSubmit" text={!watch("submit") ? "Submit" : ""} disabled={watch("submit") ? true : false} type={"submit"} className={watch("submit") ? "w-32 nvl-button bg-primary text-white" : "w-28 nvl-button  bg-primary text-white"}>{watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
                            <NVLButton id="btnCancel" text={csrFetchedNotifyData?.mode == "Create" ? "Clear" : "Cancel"} type="button" className="nvl-button w-28" onClick={(e) => (csrFetchedNotifyData.mode == "Create" ? resetControls(e) : router.push("/SiteConfiguration/CustomNotificationList"))}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CustomNotification;

