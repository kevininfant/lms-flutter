import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { deleteXlmsSMTPConfig, updateXlmsLoginPolicy } from "src/graphql/mutations";
import { listXlmsActiveTenantInfo, listXlmsSMTPConfig } from "src/graphql/queries";
import * as Yup from "yup";

function SMTPList(props) {
  const router = useRouter();
  const [Search, setSearch] = useState("");
  const [tenantId, setCurrentTenantId] = useState(props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : "")
  const variable = useRef({ PK: "TENANT#" + props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : "", SK: "SMTPSETTINGS#" })

  const [isRefreshing, setIsRefreshing] = useState(0);
  const [popupValues, setPopupValues] = useState({});

  const HeaderColumn = [
    { HeaderName: "Company", Columnvalue: "Company", HeaderCss: "w-3/12" },
    { HeaderName: "SMTP Host", Columnvalue: "SMTPHost", HeaderCss: "w-3/12" },
    { HeaderName: "SMTP User", Columnvalue: "SMTPUser", HeaderCss: "w-3/12" },
    { HeaderName: "Email", Columnvalue: "Email", HeaderCss: "w-3/12" },
    { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-3/12" },
  ];

  const validationSchema = Yup.object().shape({
    ddlSearch:
      props.TenantInfo.UserGroup == "SiteAdmin" &&
      Yup.string()
        .required("Please Select The Field")
        .test("NOValid", "ChangeHandler", (e) => {
          if (e != tenantId) {
            variable.current = { PK: "TENANT#" + e, SK: "SMTPSETTINGS#" };
            setIsRefreshing((data) => { return data + 1 });
            setCurrentTenantId(() => { return e });
          }
          return true;
        }),
  });
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
  const { register, handleSubmit, formState, watch,setValue } = useForm(formOptions);
  const { errors } = formState;

  const SearchBoxVal = (e) => {
    setSearch(e);
    setIsRefreshing((count) => {
      return count + 1;
  });
  };
  const [TenantList, setTenantList] = useState()

  


  useEffect(() => {
    async function FetchTenantData() {

      const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
      setTenantList(tenantResponse.res?.listXlmsActiveTenantInfo?.items)
    }
    FetchTenantData()
    return (() => {
      setTenantList((temp) => { return { ...temp } })
    })
  }, [props.user.signInUserSession.accessToken.jwtToken])

  const DropdownData = useMemo(() => {
    let CurrentTenant = [];
    let temp = [{ value: "", text: "Select Company" }]
    if (TenantList?.length > 2 && props.TenantInfo.UserGroup == "SiteAdmin") {
      TenantList?.map((getItem) =>
        temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }),
      );
    } else if (TenantList?.length > 0 && props.TenantInfo.UserGroup != "SiteAdmin" && props.TenantInfo.UserGroup != undefined) {
      variable.current = { PK: "TENANT#" + tenantId, SK: "SMTPSETTINGS#" };
      temp = [];
      CurrentTenant = TenantList?.filter(function (Tenant) {
        return Tenant.TenantID == tenantId;
      });
      CurrentTenant?.map((getItem) => {
        temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, });
      });
      setValue("ddlSearch", tenantId, { shouldValidate: true });
    }
    return temp;
  }, [TenantList, props.TenantInfo.UserGroup, setValue, tenantId]);

  function ResetPopUp() {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
  }

  function popup(type, PK, SK, Content) {
    setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
  }

  const refreshData = async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  };


  async function UpdateField(e) {
    e.preventDefault();
    let isDelete = false;
    if (popupValues.Type == "isDelete") {
      isDelete = true;
    }
    refreshData();
    let query = deleteXlmsSMTPConfig;
    let variables = {
      input: { PK: popupValues.PK, SK: popupValues.SK },
    };
    await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)
      .then(() => {
        const variable = {
          input: {
            PK: "TENANT#" + tenantId,
            SK: "POLICY#LOGINPOLICY",
            IsMFAMail: false
          },
        }
        AppsyncDBconnection(updateXlmsLoginPolicy, variable, props.user.signInUserSession.accessToken.jwtToken)

        refreshData();
      })
      .catch((e) => {
        alert(e?.errors?.[0].message);
        return;
      });
    ResetPopUp();
  }

  const actionRestriction = useCallback((getItem) => {

    let ActionList = [];

    if (props.RoleData?.EditSMTP) {
      ActionList.push(
        {
          id: 1,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit SMTP",
          action: () =>
            router.push(
              `/SiteConfiguration/SMTPInfo?Mode=Edit&PK=${encodeURIComponent(getItem.PK)}&SK=${encodeURIComponent(getItem.SK)}`
            ),
        })
    }
    if (props.RoleData?.DeleteSMTP) {
      ActionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete SMTP",
          action: () =>
            popup(
              "isDelete",
              getItem.PK,
              getItem.SK,
              "Are you sure want to Delete SMTP"
            ),
        })
    }
    return ActionList;
  }, [router, props])

  const gridDataBind = useCallback((viewData) => {
    const RowGrid = [];
    viewData &&
      viewData.map((getItem, index) => {
        let ActionList = [];
        ActionList = actionRestriction(getItem)
        !getItem.IsDeleted
          ? RowGrid.push({
            PK: (
              <NVLlabel
                id={"lblPKID" + (index + 1)}
                name="PK"
                text={getItem.PK}
              />
            ),
            SK: (
              <NVLlabel
                id={"lblSKID" + (index + 1)}
                name="SK"
                text={getItem.SK}
              />
            ),
            Company: (
              <NVLlabel
                id={"txtCompany" + (index + 1)}
                text={getItem.CompanyName}
              />
            ),
            SMTPHost: (
              <NVLlabel
                id={"txtSMTPHost" + (index + 1)}
                text={getItem.SMTPHost}
              ></NVLlabel>
            ),
            SMTPUser: (
              <NVLlabel
                id={"txtSMTPUser" + (index + 1)}
                text={getItem.SMTPUser}
              ></NVLlabel>
            ),
            Email: (
              <NVLlabel
                id={"txtEmail" + (index + 1)}
                text={getItem.EmailID}
              ></NVLlabel>
            ),
            Action: (
              <NVLRapidModal
                id={"RapidModal" + (index + 1)}
                ActionList={ActionList}
              ></NVLRapidModal>
            ),
          })
          : "";
      });
    return RowGrid;
  }, [actionRestriction]);
  const HeaderHandler = (data) => {
    if (data.ddlSearch != "") {
      router.push(
        `/SiteConfiguration/SMTPInfo?Mode=create&PK=${encodeURIComponent(props.TenantInfo.UserGroup == "SiteAdmin" ? data.ddlSearch : props.TenantInfo.TenantID)}`
      );
    } else {
      validationSchema.validate();
    }
  };


  const PageRoutes = useMemo(() => {
    return [
      { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
      { path: "", breadcrumb: "Email Configuration" }
    ];
  }, [])

  return (
    <>
      <Container title="SMTP" loader={TenantList == undefined} PageRoutes={PageRoutes}>
        <NVLHeader IsSearch={false} placeholder="Search by UserName" LinkName1="Add SMTP" TabRouting={props?.GeneralRoleData} className1={props.RoleData?.AddSMTP ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} SearchonChange={(e) => SearchBoxVal(e)} RedirectHome={"/SiteConfiguration/SiteConfigSettings"} href1={watch("ddlSearch") != "" ? `/SiteConfiguration/SMTPInfo?Mode=create&PK=${encodeURIComponent(props.TenantInfo.UserGroup == "SiteAdmin" ? watch("ddlSearch") : props.TenantInfo.TenantID)}` : ""} RedirectAction1={handleSubmit((data) => HeaderHandler(data))} IsNestedHeader IsDropdown={true} errors={errors} register={register} DropdownData={DropdownData} IsDropdownDisable={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} />
        { (watch("ddlSearch") != undefined && watch("ddlSearch") != "") &&<NVLGridTable user={props.user} refershPage={isRefreshing} Search={Search} id="tblActivityList" className="max-w-full" HeaderColumn={HeaderColumn} GridDataBind={gridDataBind} query={listXlmsSMTPConfig} querryName={"listXlmsSMTPConfig"} variable={variable.current} />}
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => UpdateField(e)} CancelClick={() => ResetPopUp()} ButtonNotext="No" CloseIconEvent={() => ResetPopUp()} Content={popupValues.Content}
        ></NVLModalPopup>
      </Container>
    </>
  );
}

export default SMTPList;

