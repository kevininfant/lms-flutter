import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLPassword from "@components/Controls/NVLPassword";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { createXlmsSMSConfig, updateXlmsSMSConfig } from "@graphql/graphql/mutations";
import { getXlmsSMSConfig, listXlmsActiveTenantInfo } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";



function SMSConfigInfo(props) {

    const router = useRouter();
    const [currentTenantId, setCurrentTenantId] = useState(props.TenantInfo.TenantID);
    const [smsFetchedData, setSmsFetchedData] = useState({});

    const validatePassword = (password) => {
        let i = 0,
            message = "Password Should Have ";
        if (!password?.match(/\d+/g)) {
            i++;
            message = message + "A Number";

        }
        if (!password.match(/[A-Z]+/g)) {
            i++;
            if (i > 1) {
                message = message + ", ";
            }
            message = message + "A Captial Letter";
        }
        if (!password.match(/[a-z]+/g)) {
            i++;
            if (i > 1) {
                message = message + ", ";
            }
            message = message + "A Small Letter";
        }
        if (!password.match(/[\W_]+/g)) {
            i++;
            if (i > 1) {
                message = message + ", ";
            }
            message = message + "A Special Character";
        }
        if (i > 0) {
            return message;
        }
        return true;
    };

    const validationSchema = Yup.object().shape({
        ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" && Yup.string().required("Company is required")
            .test("", "ChangeHandler", (e) => {
                if (e != currentTenantId) {
                    setCurrentTenantId(e);
                }
                return true;
            }),

        txtSmsUrl: Yup.string().required("Sms Url is required").matches(Regex("Url"), "Url is invalid").nullable(),
        txtSmsApiKey: Yup.string().required("Sms API Key is required").nullable(),
        txtSenderId: Yup.string().required("Sender Id is required").nullable(),
        txtUserid: Yup.string().required("User Id is required").nullable(),
        txtPassword: Yup.string().required("Password is required").test("", (e, { createError }) => {
            const toValidatePassword = validatePassword(e);
            if (toValidatePassword != true) {
                return createError({ message: toValidatePassword });
            }
            else if (e.length > 100) {
                return createError({ message: "Maximum characters reached" });
            }
            else {
                return true;
            }
        }).nullable(),
    });


    const initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/SiteConfiguration/SiteConfigSettings");
        },
    };

    const [modalValues, setModalValues] = useState(initialModalState);
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, reset, formState, watch } = useForm(formOptions);
    const { errors } = formState;

    useMemo(async () => {
        const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
        setSmsFetchedData((data) => { return { ...data, TenantList: tenantResponse?.res?.listXlmsActiveTenantInfo?.items != undefined ? tenantResponse?.res?.listXlmsActiveTenantInfo?.items : [] } })
        return tenantResponse;
    }, [props.user.signInUserSession.accessToken.jwtToken])

    useEffect(() => {
        async function fetchData() {

            let tenantDetail;
            if (props.TenantInfo.UserGroup == "SiteAdmin") {
                tenantDetail = currentTenantId;
            }
            else {
                tenantDetail = props.user.attributes["custom:tenantid"];
            }
            const getSmsConfiguredData = await AppsyncDBconnection(getXlmsSMSConfig, { PK: "TENANT#" + tenantDetail, SK: "SMSSETTINGS#" }, props.user.signInUserSession.accessToken.jwtToken);

            setSmsFetchedData((temp) => {
                return {
                    ...temp,
                    TenantId: tenantDetail,
                    mode: getSmsConfiguredData?.res?.getXlmsSMSConfig != undefined ? "Edit" : "Create",
                    getSmsConfiguredData: getSmsConfiguredData?.res?.getXlmsSMSConfig
                }


            });
        }
        fetchData();

    }, [currentTenantId, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, watch]);


    const selectCompany = useMemo(() => {
        const tempSelectCompany = [{ value: "", text: "Select Company" }];
        if (smsFetchedData?.TenantList?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin") {
            smsFetchedData?.TenantList?.map((getItem) =>
                tempSelectCompany.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, })
            );
        } else if (smsFetchedData?.TenantList?.length > 0 && props.TenantInfo.UserGroup != "") {
            const CurrentTenant = smsFetchedData?.TenantList?.filter(function (Tenant) {
                return Tenant.TenantID == props.TenantInfo.TenantID;
            });
            CurrentTenant?.map((getItem) =>
                tempSelectCompany.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
            tempSelectCompany.shift();
        }
        return tempSelectCompany;
    }, [smsFetchedData?.TenantList, props.TenantInfo.UserGroup, props.TenantInfo.TenantID]);



    const finalResponse = (FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: FinalStatus, });
            ModalOpen();
            return;
        } else {
            setValue("submit", "");
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    router.push("/SiteConfiguration/SiteConfigSettings");
                },
            });
            ModalOpen();
        }
    };


    const submitHandler = (async (data) => {
        setValue("loader", true);
        const pk = "TENANT#" + currentTenantId, sk = "SMSSETTINGS#", query = smsFetchedData?.mode != "Edit" ? createXlmsSMSConfig : updateXlmsSMSConfig, variables = {
            input: {
                PK: pk,
                SK: sk,
                CompanyName: document.getElementById("ddlCompany").options[document.getElementById("ddlCompany").selectedIndex].text,
                EmailID: "",
                Password: data.txtPassword,
                SMSApiKey: data.txtSmsApiKey,
                SMSUrl: data.txtSmsUrl,
                SMSSenderId: data.txtSenderId,
                SMSUserId: data.txtUserid,
            },
        }, finalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
        setValue("loader", false);
        finalResponse(finalStatus);

    });

    useEffect(() => {
        reset({ txtSmsUrl: "", txtSmsApiKey: "", txtSenderId: "", txtUserid: "", txtPassword: "", });
        if (smsFetchedData?.mode == "Edit") {

            setValue("txtSmsUrl", smsFetchedData?.getSmsConfiguredData?.SMSUrl);
            setValue("txtSmsApiKey", smsFetchedData?.getSmsConfiguredData?.SMSApiKey);
            setValue("txtSenderId", smsFetchedData?.getSmsConfiguredData?.SMSSenderId);
            setValue("txtUserid", smsFetchedData?.getSmsConfiguredData?.SMSUserId);
            setValue("txtPassword", smsFetchedData?.getSmsConfiguredData?.Password);
        }


    }, [reset, setValue, smsFetchedData]);



    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "SMS Configuration" }
        ];
    }, []);



    return (<>
        <Container PageRoutes={pageRoutes} loader={smsFetchedData?.TenantList == undefined}>
            <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
            <form onSubmit={handleSubmit(submitHandler)} id="Formjs" className={`${ watch("loader") ? "pointer-events-none" : "px-2"}`}>
                <div className="nvl-FormContent">
                    <NVLSelectField id="ddlCompany" options={selectCompany} labelText="Select Company" labelClassName="font-semibold text-gray-500" disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} errors={errors} title="Select Company" register={register} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled" : ""} w-96 nvl-mandatory `} ></NVLSelectField>
                    <NVLTextbox id="txtSmsUrl" errors={errors} labelText="SMS Url" labelClassName="font-semibold text-gray-500" title="Enter Url" className="nvl-mandatory" register={register} />
                    <NVLTextbox id="txtSmsApiKey" errors={errors} labelText="SMS API Key" labelClassName="font-semibold text-gray-500" title="Enter API Key" className="nvl-mandatory" register={register} />
                    <NVLTextbox id="txtSenderId" errors={errors} title=" Enter Sender Id" labelText="Sender Id" labelClassName="font-semibold text-gray-500" className="nvl-mandatory" register={register} />
                    <NVLTextbox id="txtUserid" errors={errors} title="Enter User Id" labelText="User Id" labelClassName="font-semibold text-gray-500" className="nvl-mandatory" register={register} />
                    <div className="relative  pt-2">
                        <NVLPassword title="Enter the Password" id="txtPassword" type="password" labelText="Password" labelClassName="nvl-Def-Label" className=" nvl-mandatory nvl-Def-Input !pr-8" register={register} errors={errors}></NVLPassword>

                    </div>
                    <div className="justify-center flex gap-4 pt-4 ">
                        <NVLButton id="btnSave" text={watch("loader") ? "" : "Save"} disabled={watch("loader") ? true : false} type={"submit"} className={"w-32 nvl-button bg-primary text-white"}> {watch("loader") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
                        <NVLButton id="btnCancel" text={"Cancel"} type="reset" className="nvl-button w-32" onClick={() => { router.push("/SiteConfiguration/SiteConfigSettings"), reset(); }} />
                    </div>
                </div>
            </form>
        </Container>

    </>);
}
export default SMSConfigInfo;