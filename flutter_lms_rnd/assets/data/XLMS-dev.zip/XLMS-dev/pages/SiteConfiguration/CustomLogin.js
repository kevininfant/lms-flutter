import Container from "@Container/Container";
import NVLButton from "@Controls/NVLButton";
import NVLTextbox from "@Controls/NVLTextBox";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLImage from "@components/Controls/NVLImage";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsBatchLoginScreenInfo } from "src/graphql/mutations";
import { getXlmsLoginScreenInfo, getXlmsTenantInfo, listXlmsLoginScreenInfos, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

export default function CustomLogin(props) {
    const [getData, setPageData] = useState();
    const [listData, setListData] = useState();
    const [tenantID, setTenantId] = useState();
    const fetchedData = useRef();
    const router = useRouter();

    /*Form validation rules*/
    const validationSchema = Yup.object().shape({
        ddlCompanyName: fetchedData.current ? Yup.string().test('companyName', async (e) => {
            if (e != '') {
                setTenantId(e);
                return true;
            }
            else {
                return false
            }
        }).nullable() : Yup.string().required("Select a company").test('companyName', async (e, { createError }) => {
            if (e == "") {
                setValue("LogoUrl", ""),
                    setValue("txtCompanyCode", "")
            }

            const existingTenantIDName = listData != undefined && Object?.values(listData).filter(
                (data) => {
                    return data?.TenantID?.toLowerCase() == e?.toLowerCase();
                }
            );
            if (existingTenantIDName?.[0]?.TenantID != undefined) {
                return (
                    setValue("txtCompanyCode", ""),
                    setValue("LogoUrl", ''),
                    createError({ message: "Company Name already exists" })
                );
            }
            if (e != '') {
                setTenantId(e);
                return true;
            }
            else {
                return false
            }
        }).nullable(),
        txtDomain: Yup.string().required("Domain Name is required").max(250, ("Maximum 250 characters limit exceed")),
        txtWebClientid: Yup.string().required("Web Client ID is required").max(250, ("Maximum 250 characters limit exceed"))
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true };
    const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        if (router.query['DomainName'] != undefined || router.query['DomainName'] != null) {
            async function FetchData() {
                const existingRecord = await AppsyncDBconnection(getXlmsLoginScreenInfo,
                    { PK: "XLMS#LOGINSCREENINFO", SK: "LOGIN#" + router.query['DomainName'] + "#QUERYSTRING#" + router.query["QueryString"]?.split('?')?.[1] + "#QUERYVALUE#" + router.query["QueryString"]?.split('?')?.[0] }, props.user.signInUserSession.accessToken.jwtToken);
                fetchedData.current = existingRecord.res?.getXlmsLoginScreenInfo;
                if (fetchedData.current != null) {
                    setValue("ddlCompanyName", fetchedData.current.TenantID)
                    setValue("txtDomain", fetchedData.current.DomainName)
                    setValue("txtCompanyCode", fetchedData.current.CompanyCode)
                    setValue("txtWebClientid", fetchedData.current.WebClientID)
                    setValue("txtQuerystring", fetchedData.current.QueryString?.split("?")[1])
                    setValue("txtQueryvalue", fetchedData.current.QueryString?.split("?")[0])
                    setValue("LogoUrl", fetchedData.current.LogoUrl)
                    setValue("tenantID", fetchedData.current.TenantID)
                    setValue("tenantName", fetchedData.current.TenantName)
                }
            }
            router.query['DomainName'] && FetchData();
        }
        else {
            async function getCompanyCode() {
                const listCompanyCode = await AppsyncDBconnection(listXlmsLoginScreenInfos, { PK: "XLMS#LOGINSCREENINFO", SK: "LOGIN#", IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
                let response = listCompanyCode.res?.listXlmsLoginScreenInfos?.items;
                const companyCode = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + tenantID }, props.user.signInUserSession.accessToken.jwtToken);
                setValue('txtCompanyCode', companyCode.res?.getXlmsTenantInfo?.CompanyCode);
                setValue('LogoUrl', companyCode.res?.getXlmsTenantInfo?.LogoUrlPath);
                setListData(response)
            }
            getCompanyCode();
        }
    }, [props.user.signInUserSession.accessToken.jwtToken, router.query, setValue, tenantID])


    const resetData = () => {
        reset()
    }

    const cancel = () => {
        router.push("/SiteConfiguration/CustomLoginList")
    }

    const dropdownData = useMemo(() => {
        let temp = router.query['DomainName'] == undefined ? [{ value: "", text: "Select Company" }] :
            [{ value: watch("tenantID"), text: watch("tenantName") }];

        if (getData?.length > 2 && props.TenantInfo.UserGroup == "SiteAdmin") {
            getData.map((getItem) =>
                temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, })
            );
        }
        return temp;
    }, [getData, props.TenantInfo.UserGroup, router.query, watch]);

    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push('/SiteConfiguration/SiteConfigSettings')
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);

    useEffect(() => {
        async function getTenantInfo() {
            const tenantResponse = await AppsyncDBconnection(
                listXlmsTenantInfos,
                { PK: "XLMS#TENANTINFO", SK: "#TENANT#" },
                props.user.signInUserSession.accessToken.jwtToken
            );
            let response = tenantResponse?.res?.listXlmsTenantInfos?.items;
            setPageData(response);
        }
        getTenantInfo();
        return (() => {
            setPageData((temp) => {
                return { ...temp };
            });
        });
    }, [props.user.signInUserSession.accessToken.jwtToken])


    /* Submit Action */
    const submitHandler = useCallback(async (data) => {
        const tenantName = document.getElementById("ddlCompanyName").options[document.getElementById("ddlCompanyName").selectedIndex].text;
        //getXlmsLoginScreenInfo
        let variables =
        {
            input: [{
                PK: "XLMS#LOGINSCREENINFO",
                SK: "LOGIN#" + data.txtDomain + "#QUERYSTRING#" + data.txtQuerystring + "#QUERYVALUE#" + data?.txtQueryvalue,
                TenantName: tenantName,
                CompanyCode: data?.txtCompanyCode,
                DomainName: data?.txtDomain,
                QueryString: data?.txtQueryvalue + "?" + data.txtQuerystring,
                WebClientID: data?.txtWebClientid,
                TenantID: tenantID,
                IsSuspend: false,
                IsDeleted: false,
                CreatedBy: "Site Administrator",
                CreatedDate: new Date(),
                LastModifiedBy: new Date(),
                LastModifiedDate: new Date(),
                LogoUrl: data?.LogoUrl
            }]
        };

        const finalStatus = await AppsyncDBconnection(createXlmsBatchLoginScreenInfo, variables, props?.user?.signInUserSession.accessToken?.jwtToken);
        if (finalStatus.Status != "Success") {
            setModalValues([{
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: finalStatus,
            }]);
            ModalOpen();
            return;
        }
        else {
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    router.push("/SiteConfiguration/CustomLoginList")
                },
            });
            ModalOpen();
        }
    }, [props?.user?.signInUserSession.accessToken?.jwtToken, router, tenantID]);

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "/SiteConfiguration/CustomLoginList", breadcrumb: "Custom Login List" },
            { path: "", breadcrumb: "Custom Login" }
        ];
    }, []);

    return <>
        <Container title="Custom Login">
            <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
            <form onSubmit={handleSubmit(submitHandler)}
                className={"px-2"}>
                <div className="nvl-FormContent">
                    <NVLSelectField id="ddlCompanyName" options={dropdownData} labelText={("Company Name")} labelClassName="nvl-Def-Label" errors={errors} title="Company Name" tabIndex={fetchedData.current ? -1 : 0} className={`nvl-mandatory nvl-Def-Input ${fetchedData.current ? "Disabled" : ""}`} register={register} />
                    <NVLTextbox id="txtDomain" labelText={("Domain Name")} labelClassName="nvl-Def-Label" errors={errors} title="Domain Name" tabIndex={fetchedData.current ? -1 : 0} className={`nvl-mandatory nvl-Def-Input ${fetchedData.current ? "Disabled" : ""}`} register={register} />
                    <NVLTextbox id="txtCompanyCode" labelText={("Company Code")} labelClassName="nvl-Def-Label" errors={errors} title="Company Code" tabIndex={-1} className={`nvl-mandatory nvl-Def-Input Disabled ${fetchedData.current ? "Disabled" : ""}`} register={register} />
                    <NVLTextbox id="txtWebClientid" labelText={("Web Client Id")} labelClassName="nvl-Def-Label" errors={errors} title="Web Client Id" className="nvl-mandatory nvl-Def-Input" register={register} />
                    <NVLTextbox id="txtQuerystring" labelText={("Query String Name")} labelClassName="nvl-Def-Label" errors={errors} title="Query String Name" tabIndex={fetchedData.current ? -1 : 0} className={`nvl-non-mandatory nvl-Def-Input ${fetchedData.current ? "Disabled" : ""}`} register={register} />
                    <NVLTextbox id="txtQueryvalue" labelText={("Query String Value")} labelClassName="nvl-Def-Label" errors={errors} title="Query String Value" tabIndex={fetchedData.current ? -1 : 0} className={`nvl-non-mandatory nvl-Def-Input ${fetchedData.current ? "Disabled" : ""}`} register={register} />
                    {watch("LogoUrl") != undefined && watch("LogoUrl") != '' ?
                        <>
                            <NVLlabel text={("Preview")} className="text-xs nvl-Def-Label" />
                            <NVLImage src={watch("LogoUrl")} className="my-2 p-2 w-44 h-20"/>
                        </> : ''
                    }
                    <div className="flex justify-center">
                        <NVLButton id="btnSubmit" text={"submit"} type="submit" className="w-28" ButtonType='primary'></NVLButton>
                        <div className="mx-2">
                            {fetchedData.current ?
                                <NVLButton id="btnClear" text={"Cancel"} type="button" onClick={() => cancel()} className="nvl-button w-28"></NVLButton> :
                                <NVLButton id="btnClear" text={"Clear"} type="reset" onClick={() => resetData()} className="nvl-button w-28"></NVLButton>
                            }
                        </div>
                    </div>
                </div>
            </form>
            <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        </Container></>
}
