import NVLButton from '@components/Controls/NVLButton';
import NVLColorInput from '@components/Controls/NVLColorInput';
import NVLlabel from '@components/Controls/NVLlabel';
import NVLTextbox from '@components/Controls/NVLTextBox';
import { yupResolver } from '@hookform/resolvers/yup';
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useCallback, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Regex } from "RegularExpression/Regex";
import { createXlmsTenantBranding } from 'src/graphql/mutations';
import { listXlmsTenantCheckBrandings } from 'src/graphql/queries';
import * as Yup from 'yup';

export default function BrandingModalPopup(props) {
    const [color, setColor] = useState({});
    const validationSchema = Yup.object().shape({
        txtCreateTheme: Yup.string().required("Theme name is Required").matches(Regex("AlphaNumWithAllowedSpecialChar"), "Invalid Theme Name").max(15, "Maximum 15 characters Reached")
            .test("Exists", "Theme Name Already exists",
                async (e) => {
                    const tenantBranding = await AppsyncDBconnection(
                        listXlmsTenantCheckBrandings,
                        { PK: "XLMS#BRANDING#TENANT#" + props.TenantID, SK: "BRANDING#", ThemeModeLower: e.toLowerCase(), IsDeleted: false},
                        props.user.signInUserSession.accessToken.jwtToken
                    );
                    if ((e?.toLowerCase()=="default-theme"||e?.toLowerCase()=="dark-theme")|| tenantBranding.res?.listXlmsTenantCheckBrandings?.items?.length != 0) {
                  
                        return false;
                    }
                    return true;
                }),
    });

    const resetData = useCallback(() => {
        reset({ txtCreateTheme: "" });
        setColor({});
    }, [reset]);

    const formOptions = { mode: 'onChange', resolver: yupResolver(validationSchema), reValidateMode: 'onChange', nativeValidation: true,};
    const { register, handleSubmit, reset, formState,setValue ,watch} = useForm(formOptions);
    const { errors } = formState;

    function handleChange(event, item, value) {
        setColor({
            ...color,
            [value]: { ...color?.[value], [item]: event.target.value },

        });
    }

    const submitHandler = async (data) => {
        
        if (document.getElementById("divCreateTheme") != null) {
            if (!document.getElementById("divCreateTheme")?.classList?.contains("pointer-events-none")) {
                document.getElementById("divCreateTheme")?.classList?.add("pointer-events-none");
            }
        }
        const header = {
            "--nvl-header-bg-color": color.Header?.["--nvl-header-bg-color"] == undefined ? "#f9fafc" : color.Header?.["--nvl-header-bg-color"],
            "--nvl-header-txt-color": color.Header?.["--nvl-header-txt-color"] == undefined ? "rgb(55 65 81)" : color.Header?.["--nvl-header-txt-color"],
            "--nvl-header-icon-color": color.Header?.["--nvl-header-icon-color"] == undefined ? "#757575" : color.Header?.["--nvl-header-icon-color"]
        };
        const sidebar = {
            "--nvl-sidebar-bg-color": color.SideBar?.["--nvl-sidebar-bg-color"] == undefined ? "#f9fafc" : color.SideBar?.["--nvl-sidebar-bg-color"],
            "--nvl-sidebar-txt-color": color.SideBar?.["--nvl-sidebar-txt-color"] == undefined ? "rgb(55 65 81)" : color.SideBar?.["--nvl-sidebar-txt-color"],
            "--nvl-sidebar-icon-color": color.SideBar?.["--nvl-sidebar-icon-color"] == undefined ? "rgb(55 65 81)" : color.SideBar?.["--nvl-sidebar-icon-color"],
            "--nvl-sidebar-nested-bg-color": color.SideBar?.["--nvl-sidebar-nested-bg-color"] == undefined ? "rgb(239 246 255)" : color.SideBar?.["--nvl-sidebar-nested-bg-color"],
            "--nvl-sidebar-hover-bg-color": color.SideBar?.["--nvl-sidebar-hover-bg-color"] == undefined ? "rgb(239 246 255)" : color.SideBar?.["--nvl-sidebar-hover-bg-color"]
        };
        const body = {
            "--nvl-body-bg-color": color.Body?.["--nvl-body-bg-color"] == undefined ? "rgb(255, 255, 255)" : color.Body?.["--nvl-body-bg-color"],
            "--nvl-body-txt-color": color.Body?.["--nvl-body-txt-color"] == undefined ? "rgb(75 85 99)" : color.Body?.["--nvl-body-txt-color"],
            "--nvl-body-icon-color": color.Body?.["--nvl-body-icon-color"] == undefined ? "#0d6aff" : color.Body?.["--nvl-body-icon-color"],
            "--nvl-body-button-bg-color": color.Body?.["--nvl-body-button-bg-color"] == undefined ? "#099127" : color.Body?.["--nvl-body-button-bg-color"],
            "--nvl-body-button-hover-bg-color": color.Body?.["--nvl-body-button-hover-bg-color"] == undefined ? "#099127" : color.Body?.["--nvl-body-button-hover-bg-color"],
            "--nvl-loading-spinner-bg-clr": color.Body?.["--nvl-loading-spinner-bg-clr"] == undefined ? "#1d74ff" : color.Body?.["--nvl-loading-spinner-bg-clr"]
        };
        const grid = {
            "--nvl-grid-header-bg-color": color.Grid?.["--nvl-grid-header-bg-color"] == undefined ? "rgb(219 234 254)" : color.Grid?.["--nvl-grid-header-bg-color"],
            "--nvl-grid-row-start-bg-color": color.Grid?.["--nvl-grid-row-start-bg-color"] == undefined ? "rgb(243 244 246)" : color.Grid?.["--nvl-grid-row-start-bg-color"],
            "--nvl-grid-row-end-bg-color": color.Grid?.["--nvl-grid-row-end-bg-color"] == undefined ? "rgb(255, 255, 255)" : color.Grid?.["--nvl-grid-row-end-bg-color"],
            "--nvl-grid-txt-color": color.Grid?.["--nvl-grid-txt-color"] == undefined ? "rgb(75 85 99)" : color.Grid?.["--nvl-grid-txt-color"]

        };
        const themeId = Math.random().toString(25).substring(2, 12);
        const brandingData = {PK: 'XLMS#BRANDING#TENANT#' + props.TenantID,SK: 'BRANDING#' + themeId,ThemeMode: data.txtCreateTheme,ThemeModeLower:data.txtCreateTheme.toLowerCase(),TenantID: props.TenantID,IsActivate: false,IsDeleted: false,Body: JSON.stringify(body),Header: JSON.stringify(header),SideBar: JSON.stringify(sidebar),Grid: JSON.stringify(grid)};

        const query = createXlmsTenantBranding;
        const finalStatus = await AppsyncDBconnection(query, { input: brandingData }, props.user.signInUserSession.accessToken.jwtToken);
        if (finalStatus.Status == "Success") {
            props?.setData((temp) => {
                return ({ ...temp, BrandingData: [...temp.BrandingData, brandingData] });
            });
        }
        if (document.getElementById("divCreateTheme") != null) {
            if (document.getElementById("divCreateTheme")?.classList?.contains("pointer-events-none")) {
                document.getElementById("divCreateTheme")?.classList?.remove("pointer-events-none");
            }
        }

        props.setOpen();
        setValue("submited", false);
        resetData(); reset();
    };
    return (
        <div>
            {/* modal */}
            <div hidden={props.open}>
                <div id="div">
                    {/* <div as="div" className="relative z-10" initialFocus={cancelButtonRef} onClose={props.setOpen}> */}
                    <div>
                        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
                    </div>

                    <div className="fixed z-10 inset-0 overflow-y-auto" id="divCreateTheme">
                        <div className="flex items-end sm:items-center justify-center min-h-full p-4 text-center sm:p-0">
                            <div>
                                <div className="relative bg-th-body-bg-color rounded-xl text-left shadow-xl transform transition-all w-full md:w-[90ch]">
                                    <div className=" flex justify-between border-b-2 border-gray-300 p-2">
                                        <div className="flex title-font font-medium items-center text-gray-900 mb-4 md:mb-0  px-2 py-1">
                                            <i className="bg-gradient-to-r from-blue-600 via-green-500 to-indigo-400 p-2 rounded fa-solid fa-feather"></i>
                                            <span className="ml-3 text-xl bg-gradient-to-r from-blue-600 via-green-500 to-indigo-400 inline-block text-transparent bg-clip-text">Color theme creation</span>
                                        </div>
                                        <i onClick={() => { props.setOpen(); resetData(); reset(); }} className="fa-solid fa-xmark text-red-600 h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-red-100"></i>
                                    </div>
                                    {/* herodsf */}
                                    <div className="flex flex-wrap w-full ">
                                        <p className="text-sm px-10 font-semibold text-th-body-txt-color inline-block bg-clip-text">SCREEN PREVIEW </p>
                                        <div className=" container text-center  bg-gray-50 text-gray-800 mx-10 my-4 border-8 rounded-lg text-xs">
                                            {/* HEADER */}
                                            <header className=" p-2" style={{ backgroundColor: color.Header?.["--nvl-header-bg-color"], color: color.Header?.["--nvl-header-txt-color"] }}>
                                                <div className="flex items-center sm:justify-between sm:gap-4">
                                                    <div className="hidden md:ml-10 md:block md:space-x-8 md:pr-4 ">
                                                        <span href="#" className="font-medium">
                              Product
                                                        </span>
                                                        <span href="#" className="font-medium ">
                              Features
                                                        </span>
                                                        <span href="#" className="font-medium ">
                              Marketplace
                                                        </span>
                                                        <span href="#" className="font-medium ">
                              Company
                                                        </span>

                                                        <span href="#" className="font-medium ">
                              Log in
                                                        </span>
                                                    </div>
                                                    <div className="flex items-center justify-between flex-1 gap-8 sm:justify-end">
                                                        <div className="flex gap-4">
                                                            <i style={{ color: color.Header?.["--nvl-header-icon-color"] }} className="fa-solid fa-graduation-cap"></i>
                                                            <i style={{ color: color.Header?.["--nvl-header-icon-color"] }} className="fa-solid fa-bell"></i>
                                                        </div>
                                                    </div>
                                                </div>
                                            </header>
                                            <div className="flex">
                                                {/* side */}
                                                <div style={{ backgroundColor: color.SideBar?.["--nvl-sidebar-bg-color"], color: color.SideBar?.["--nvl-sidebar-txt-color"] }} className="flex flex-col gap-2 border-r w-44">
                                                    <summary className="flex items-center px-4 rounded-lg ">
                                                        <i style={{ color: color.SideBar?.["--nvl-sidebar-icon-color"] }} className="fa-solid fa-gear"></i>
                                                        <span className="ml-3 text-sm font-medium">
                                                            {" "}
                              General{" "}
                                                        </span>
                                                    </summary>
                                                    <summary className="flex items-center px-4 rounded-lg ">
                                                        <i style={{ color: color.SideBar?.["--nvl-sidebar-icon-color"] }} className="fa-solid fa-users"></i>
                                                        <span className="ml-3 text-sm font-medium">
                                                            {" "}
                              Teams{" "}
                                                        </span>
                                                    </summary>
                                                    <div style={{ backgroundColor: color.SideBar?.["--nvl-sidebar-nested-bg-color"] }}>
                                                        <summary className="flex items-center px-4 py-2  rounded-lg ">
                                                            <i style={{ color: color.SideBar?.["--nvl-sidebar-icon-color"] }} className="fa-solid fa-building"></i>
                                                            <span className="ml-3 text-sm font-medium">
                                                                {" "}
                                Company{" "}
                                                            </span>
                                                            <span className="ml-auto transition duration-300 shrink-0 " open>
                                                            </span>
                                                        </summary>
                                                        <span className="ml-3 text-sm font-medium">
                                                            {" "}
                              SubMenu{" "}
                                                        </span>
                                                    </div>
                                                    <summary className="flex items-center px-4 rounded-lg ">
                                                        <i style={{ color: color.SideBar?.["--nvl-sidebar-icon-color"] }} className="fa-solid fa-book"></i>
                                                        <span className="ml-3 text-sm font-medium">
                                                            {" "}
                              Courses{" "}
                                                        </span>
                                                    </summary>
                                                    <summary className="flex items-center px-4 rounded-lg ">
                                                        <i style={{ color: color.SideBar?.["--nvl-sidebar-icon-color"] }} className="fa-solid fa-building"></i>
                                                        <span className="ml-3 text-sm font-medium">
                                                            {" "}
                              Company{" "}
                                                        </span>
                                                    </summary>
                                                </div>
                                                <div className="h-22 py-4 px-4" style={{ backgroundColor: color.Body?.["--nvl-body-bg-color"], color: color.Body?.["--nvl-body-txt-color"] }}>
                                                    <p className=" mt-0 mb-6">
                            It is a long established fact that a reader will be
                            distracted by the readable content of a page when
                            looking at its layout. The point of using Lorem
                            Ipsum is that it has a more-or-less normal
                            distribution of letters,
                                                    </p>
                                                    <div className="border-1 py-2">
                                                        <table className="container mx-auto" style={{ color: color.Grid?.["--nvl-grid-txt-color"] }}>
                                                            <thead className="border " style={{ backgroundColor: color.Grid?.["--nvl-grid-header-bg-color"] }}>
                                                                <tr>
                                                                    <th>Song</th>
                                                                    <th>Artist</th>
                                                                    <th>Year</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr className="border" style={{ backgroundColor: color.Grid?.["--nvl-grid-row-start-bg-color"] }}>
                                                                    <td>The Sliding Mr. Bones (Next Stop, Pottersville)</td>
                                                                    <td>Malcolm Lockyer</td>
                                                                    <td><i className="fa-solid fa-caret-down" style={{ color: color.Grid?.["--nvl-body-icon-color"] }}></i></td>
                                                                </tr>
                                                                <tr className="border" style={{ backgroundColor: color.Grid?.["--nvl-grid-row-end-bg-color"] }}>
                                                                    <td>Witchy Woman</td>
                                                                    <td>The Eagles</td>
                                                                    <td><i className="fa-solid fa-caret-down" style={{ color: color.Grid?.["--nvl-body-icon-color"] }}></i></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div className="flex justify-evenly">
                                                        <a style={{ backgroundColor: color.Body?.["--nvl-body-button-bg-color"] }} className={`hover:bg-["${color.Body?.["--nvl-body-button-hover-bg-color"]}"] inline-block px-6 py-2.5 font-medium text-xs leading-tight uppercase rounded shadow-md  hover:shadow-lg focus:shadow-lg focus:outline-none focus:ring-0 active:shadow-lg transition duration-150 ease-in-out cursor-none`} data-mdb-ripple="true" data-mdb-ripple-color="light" role="button">
                              Happy Let&apos;s Create
                                                        </a>
                                                        <div className="flex gap-2 font-semibold text-sm items-center" style={{ color: color.Body?.["--nvl-loading-spinner-bg-clr"] }}>
                              Loading....
                                                        </div></div>
                                                </div>
                                            </div>
                                            {/* side end */}
                                        </div>
                                    </div>
                                    {/* /color pallete */}
                                    <form onSubmit={handleSubmit(submitHandler)} className={watch("submit") ? "pointer-events-none" : ""}>
                                        <p className="text-sm px-10 font-semibold text-th-body-txt-color inline-block  bg-clip-text">TOOLS FOR PICKING COLORS</p>
                                        <div className="border-8 p-2 rounded-lg grid gap-2">
                                            <div className='h-32 overflow-auto'>
                                                <div className=" flex bg-gray-200 rounded p-2">
                                                    <span className="w-28 h-8 my-auto text-sm font-bold bg-gradient-to-r from-blue-600 via-green-500 to-indigo-400 inline-block text-transparent bg-clip-text">HEADER</span>
                                                    <div className="grid grid-flow-col gap-2 p-1 rounded justify-items-center  overflow-y-auto  ">
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color.Header?.["--nvl-header-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-header-bg-color', 'Header')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Background
                                                            </span>
                                                        </div>
                                                        <div className=" grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Header?.["--nvl-header-txt-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-header-txt-color', 'Header')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Text
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Header?.["--nvl-header-icon-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-header-icon-color', 'Header')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Icon
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="  flex bg-gray-200 rounded p-2">
                                                    <span className="w-28 h-8 my-auto text-sm font-bold bg-gradient-to-r from-blue-600 via-green-500 to-indigo-400 inline-block text-transparent bg-clip-text">SIDE BAR</span>
                                                    <div className="grid grid-flow-col gap-2 p-1 rounded justify-items-center  overflow-y-auto  ">
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput type="color" onChange={(e) => handleChange(e, '--nvl-sidebar-bg-color', 'SideBar')} value={color?.SideBar?.["--nvl-sidebar-bg-color"]} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Background
                                                            </span>
                                                        </div>
                                                        <div className=" grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.SideBar?.["--nvl-sidebar-txt-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-sidebar-txt-color', 'SideBar')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">

                              Text
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.SideBar?.["--nvl-sidebar-icon-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-sidebar-icon-color', 'SideBar')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">

                              Icon
                                                            </span>
                                                        </div>

                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.SideBar?.["--nvl-sidebar-nested-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-sidebar-nested-bg-color', 'SideBar')} />
                                                            </button>

                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Sub Menu
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.SideBar?.["--nvl-sidebar-hover-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-sidebar-hover-bg-color', 'SideBar')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Menu Hover
                                                            </span>
                                                        </div>

                                                    </div>
                                                </div>

                                                <div className="  flex bg-gray-200 rounded p-2">
                                                    <span className="w-28 h-8 my-auto text-sm font-bold bg-gradient-to-r from-blue-600 via-green-500 to-indigo-400 inline-block text-transparent bg-clip-text">BODY</span>
                                                    <div className="grid grid-flow-col gap-2 p-1 rounded justify-items-center  overflow-y-auto ">
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Body?.["--nvl-body-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-body-bg-color', 'Body')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Background
                                                            </span>
                                                        </div>
                                                        <div className=" grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Body?.["--nvl-body-txt-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-body-txt-color', 'Body')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Text
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Body?.["--nvl-body-icon-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-body-icon-color', 'Body')} />
                                                            </button>

                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Icon
                                                            </span>
                                                        </div>

                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Body?.["--nvl-body-button-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-body-button-bg-color', 'Body')} />
                                                            </button>

                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Button
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Body?.["--nvl-body-button-hover-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-body-button-hover-bg-color', 'Body')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Button Hover
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Body?.["--nvl-loading-spinner-bg-clr"]} type="color" onChange={(e) => handleChange(e, '--nvl-loading-spinner-bg-clr', 'Body')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Loader
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className=" flex bg-gray-200 rounded p-2 ">
                                                    <span className="w-28 h-8 my-auto text-sm font-bold bg-gradient-to-r from-blue-600 via-green-500 to-indigo-400 inline-block text-transparent bg-clip-text">GRID</span>
                                                    <div className="grid grid-flow-col gap-2  p-1 rounded justify-items-center  overflow-y-auto ">
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Grid?.["--nvl-grid-header-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-grid-header-bg-color', 'Grid')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Grid Header
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Grid?.["--nvl-grid-row-start-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-grid-row-start-bg-color', 'Grid')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Grid row
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Grid?.["--nvl-grid-row-end-bg-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-grid-row-end-bg-color', 'Grid')} />
                                                            </button>

                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Grid row end
                                                            </span>
                                                        </div>
                                                        <div className="grid gap-3 p-0.5 h-10 rounded w-28 bg-gradient-to-r from-blue-500 via-red-500 to-yellow-500">
                                                            <button className="h-1 text-blue-800 bg-white cursor-none" type='button'>
                                                                <NVLColorInput value={color?.Grid?.["--nvl-grid-txt-color"]} type="color" onChange={(e) => handleChange(e, '--nvl-grid-txt-color', 'Grid')} />
                                                            </button>
                                                            <span className="text-xs inline-block py-1 px-2.5 leading-none text-center whitespace-nowrap align-baseline font-bold bg-gray-200 text-gray-700 rounded">
                              Grid Text
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className='flex justify-end'>
                                                <div>
                                                <NVLlabel text={"Theme Name"} showFull={true} className={"nvl-Def-Label"} />
                                                <div className='flex'>
                                                    <NVLTextbox errors={errors} title={"Theme Name"} register={register} id="txtCreateTheme" className="p-1 px-2 h-6 my-auto appearance-none outline-none w-92 text-gray-800 text-xs" />
                                                    <NVLButton id="btnSave" text={watch("submited") ? "" : "Create"} type="submit"
                                                        className={`${watch("submited") ? "Disabled text-primary" : ""} nvl-button bg-primary text-white 
                                                        text-sm  mx-2 w-32  px-4 py-2`}
                                                        onClick={(() => setValue("submited", true))}>
                                                        {watch("submited") && (<i className="fa fa-circle-notch fa-spin ml-2 text-primary"></i>)}
                                                    </NVLButton>
                                                </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* modal close */}
        </div>
    );
}