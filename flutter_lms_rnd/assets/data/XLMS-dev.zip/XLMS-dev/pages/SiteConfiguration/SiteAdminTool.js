import Container from "@Container/Container";
import NVLButton from "@Controls/NVLButton";
import NVLTextbox from "@Controls/NVLTextBox";
import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useForm } from "react-hook-form";
import { listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

function SiteAdminTool(props) {
    const [getData, setPageData] = useState();
    const rowData = useRef();
    const [rowGrid, setRowGrid] = useState([]);

    useEffect(() => {
        async function getTenantInfo() {
            const tenantResponse = await AppsyncDBconnection(
                listXlmsTenantInfos,
                { PK: "XLMS#TENANTINFO", SK: "#TENANT#" },
                props.user.signInUserSession.accessToken.jwtToken
            );
            let response = tenantResponse?.res?.listXlmsTenantInfos?.items;
            setPageData(response);
        }
        getTenantInfo();
        return (() => {
            setPageData((temp) => {
                return { ...temp };
            });
        });
    }, [props.user.signInUserSession.accessToken.jwtToken])

    const dropdownData = useMemo(() => {

        let temp = [{ value: "", text: "Select Company" }];
        if (getData?.length >= 0 && props.TenantInfo.UserGroup == "SiteAdmin") {
            getData.map((getItem) =>
                temp?.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, })
            );
        }
        return temp;
    }, [getData, props.TenantInfo.UserGroup]);

    const [tenantState, setTenantState] = useState(() => {
        const tenant = [{ value: "", text: "Select Company" }];

        getData?.map((tenantData) => [
            tenant.push({
                value: tenantData.TenantID,
                text: tenantData.TenantDisplayName,
            }),
        ]);

        // setPageData(() => {
        //     return tenant;
        // });
    });

    const [state, setState] = useState({ txtState: 1, ddlState: 1 })
    const [optionsLength, setOptionLength] = useState(() => {
        let optionSize = 1;
        // if (mode == "Edit" || mode == "ModuleEdit" || fetchQuizData?.Preview == "Preview")
        //   optionSize = fetchQuizData?.Editdata && JSON?.parse(fetchQuizData?.Editdata?.Options).length;
        return optionSize;
    });


    //validation
    let DynamicYupfields = {};
    for (let i = 1; i <= state.txtState; i++) {
        DynamicYupfields = {
            ...DynamicYupfields,
            [`txtPK${i}`]:
                Yup.string()
                    .required("PK is required")
                    .test("error", "", (val, { createError }) => {
                        if (val == undefined || val == "" || val == null) {
                            return createError({ message: "PK is required" });
                        }
                        else {
                            return true
                        }
                    })
                    .nullable(true),
            [`txtSK${i}`]:
                Yup.string()
                    .notRequired()
        };
    }
    for (let i = 1; i <= state.ddlState; i++) {
        DynamicYupfields = {
            ...DynamicYupfields,
            [`ddlCompanyName${i}`]:
                Yup.string()
                    .required("Company Name is required")
                    .test("error", "", (val, { createError }) => {
                        if (val == undefined || val == "" || val == null) {
                            return createError({ message: "Company Name is required" });
                        }
                        else {
                            return true
                        }
                    })
                    .nullable(true),
        };
    }
    const validationSchema = Yup.object().shape(DynamicYupfields);
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
    const { errors } = formState;

    //Submit Handler
    const submitHandler = async (data) => {
        let Record = [];
        for (let i = 1; i <= state.txtState; i++) {
            Record.push({ PK: data?.["txtPK" + i], SK: data?.["txtSK" + i] });
            // Record = {
            //     ...Record.Record,
            //     Record: {
            //         PK: data?.["txtPK" + i],
            //         SK: data?.["txtSK" + i],
            //     },
            // };
        }



        let Tenant = [];
        for (let i = 1; i <= state.ddlState; i++) {
            Tenant.push({ TenantID: data?.["ddlCompanyName" + i], })
            // Tenant = {
            //     ...Tenant,
            //     Tenant: {
            //         ...Tenant.Tenant,
            //         ["ddlCompanyName" + i]: data?.["ddlCompanyName" + i],
            //     },
            // };
        }
        let tenatList = { ...Tenant };
        let recordList = { ...Record };
        let tenatListValues = Object.values(tenatList);
        let recordListValues = Object.values(recordList)
        const setUploadUrl = '';
        const jsonSaveData = '{' + '"Record"' + ":" + JSON.stringify(recordListValues) + "," + '"TenantList"' + ":" + JSON.stringify(tenatListValues) + '}';

        const headers = {
            method: "POST", headers: {
                "Content-Type": "application/json",
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                defaultrole: props.TenantInfo.UserGroup,
                // groupmenuname: "CompanyManagement", menuid: menuId,
                // statemachinearn: stateUrl
            },
            body: jsonSaveData,
        };
        const finalStatus = await APIGatewayPostRequest(setUploadUrl, headers);
        if (finalStatus.Status == "Success") {
            console.log("success");
        }
        else {
            console.log("failed");
        }
        setValue("submit", false);
    }


    const resetData = () => {
        reset()
    }

    const Setoptions = useCallback(
        (props) => {
            return (
                <>
                    {
                        <>
                            <div>
                                <div className="">
                                    <NVLTextbox title={"PK"} labelText={("PK")} labelClassName="nvl-Def-Label" id={"txtPK" + (props.id)} className="w-96 nvl-mandatory" errors={props?.errors} register={register}></NVLTextbox>
                                </div>
                                <div id="field_div">
                                    <NVLlabel text={"SK"} className="nvl-Def-Label w-52"></NVLlabel>
                                    <div className="flex gap-10  relative">
                                        <NVLTextbox title={"SK"} id={"txtSK" + (props.id)} className="w-96 nvl-non-mandatory" errors={props?.errors} reset={reset} register={register}></NVLTextbox>
                                        <div className={`pt-1 ${props.id > 1 ? "" : "hidden"}`}>
                                            <i
                                                className="fa-solid fa-trash text-red-600"
                                                onClick={() => {
                                                    deleteOption(props?.id);
                                                }}
                                            ></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </>}
                </>
            );
        },
        [deleteOption, register, reset]
    );

    const DrpOption = useCallback((props) => {
        
        return (
            <>
                {
                    <div className="flex gap-8">
                        <div>
                            <NVLSelectField id={"ddlCompanyName" + (props.id)}
                                options={dropdownData}
                                labelText={("Company Name")} labelClassName="nvl-Def-Label" errors={props?.errors} title="Company Name" className={`nvl-mandatory nvl-Def-Input`} register={register} />
                        </div>
                        <div className={`flex items-center pt-2 pl-2 ${props.id > 1 ? "" : "hidden"}`}>
                            <i className="fa-solid fa-trash text-red-600"
                                onClick={() => {
                                    deleteDdlOption(props?.id);
                                }}
                            ></i>
                        </div>
                    </div>
                }
            </>

        )
    }, [dropdownData, register, deleteDdlOption])


    const addOption = useCallback(() => {
        setOptionLength((data) => {
            return data + 1;
        });
    }, []);


    const deleteOption = useCallback((id) => {
        for (let i = id; i < optionsLength - 1; i++) {
            setValue("txtPK" + i, watch("txtPK" + (i + 1)));
            setValue("txtSK" + i, watch("txtSK" + (i + 1)));
            // setValue("ddlPoints" + i, watch("ddlPoints" + (i + 1)));
            // setValue("chkFeedback" + i, watch("chkFeedback" + (i + 1)));
            // setValue("txtFeedback" + i, watch("txtFeedback" + (i + 1)));
        }
        setOptionLength((data) => {
            setValue("txtPK" + (data - 1), "");
            return data - 1;
        });
    },
        [optionsLength, setValue, watch]
    );



    const Options = useCallback((props) => {
        let rowGrid = [];
        for (let i = 1; i <= props.Optionslength; i++) {
            rowGrid.push(<Setoptions id={i} key={i} watch={props.watch} errors={props.errors} state={props.state} Optionslength={props.Optionslength} controlType={"textBox"} DeleteOption={props.DeleteOption} />);
        }
        rowData.current = rowGrid;
        return <>{rowGrid}</>;
    }, []);

    const DdlOptions = useCallback((props) => {
        let rowGrid = [];
        for (let i = 1; i <= state.ddlState; i++) {
            rowGrid.push(<DrpOption id={i} key={i} errors={props.errors} state={props.state} controlType={"dropdown"} />);
        }
        return <>{rowGrid}</>;
    }, [state.ddlState]);


    const deleteDdlOption = useCallback(
        (id) => {
            setState((stateCount) => {
                if (id != stateCount.ddlState) {
                    for (let i = 0; i + id < stateCount.ddlState; i++) {
                        setValue("ddlCompanyName" + (i + id), watch("ddlCompanyName" + (i + id + 1)));
                    }
                    setValue("ddlCompanyName" + stateCount.ddlState, "");
                } else {
                    setValue("ddlCompanyName" + stateCount.ddlState, "");
                }
                return { ...stateCount, ddlState: stateCount.ddlState - 1 };
            });
        }, [setValue, watch]);

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Site Admin Tool" }
        ];
    }, []);
    return (
        <Container title="Site Admin Tool">
            <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
            <form onSubmit={handleSubmit(submitHandler)}>
                <div className="nvl-FormContent">
                    {/* <NVLCustomTxtBoxField id="txtTextfield" labelText="pk" buttonValue='Add' Optionslength={optionsLength} setOptionlength={setOptionLength} setValue={setValue} watch={watch} title="PK" errors={errors} register={register} /> */}
                    <Options errors={errors} watch={watch} register={register} Optionslength={optionsLength} />
                    <div className="pt-2">
                        <NVLButton
                            id="btnfield"
                            text="Add"
                            type="button"
                            ButtonType="primary"
                            register={register}
                            onClick={() => addOption()}
                        ></NVLButton>
                        <DdlOptions errors={errors} register={register} state={state} />
                        <NVLButton
                            text="Add"
                            id="btnfield"
                            type="button"
                            ButtonType="primary"
                            register={register}
                            onClick={() => {
                                setState((state) => {
                                    return ({ ...state, ddlState: state.ddlState + 1 });
                                });
                            }}
                        ></NVLButton>
                    </div>
                    <div className="flex justify-center">
                        <NVLButton id="btnSubmit" text={"submit"} type="submit" className="w-28" ButtonType='primary'></NVLButton>
                        <div className="mx-2">
                            <NVLButton id="btnClear" text={"Clear"} type="reset" onClick={() => resetData()} className="nvl-button w-28"></NVLButton>
                        </div>
                    </div>
                </div>
            </form>
        </Container>
    )
}

export default SiteAdminTool