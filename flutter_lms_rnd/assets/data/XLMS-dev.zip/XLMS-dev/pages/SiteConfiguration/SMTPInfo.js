import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLPassword from "@components/Controls/NVLPassword";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsSMTPConfig, updateXlmsSMTPConfig } from "src/graphql/mutations";
import { getXlmsSMTPConfig, listXlmsActiveTenantInfo } from "src/graphql/queries";
import * as Yup from "yup";

function SMTP(props) {
  const router = useRouter();
  const [SmtpData, setSmtpData] = useState()
  const mode = useMemo(() => { return router.query["Mode"] }, [router.query])
  const refTenant = useRef();

  const tenantID = useMemo(() => {
    let TenantId;
    if (props.TenantInfo.UserGroup != "SiteAdmin") {
      TenantId = props.TenantInfo.TenantID;
    } else {
      if (mode != "Edit") {
        TenantId = router.query["PK"]
      }
    }
    return TenantId
  }, [mode, props.TenantInfo.TenantID, props.TenantInfo.UserGroup, router.query])
  
  const validatePassword = (password) => {
    let i = 0,
      message = "Password Should Have ";
    if (!password.match(/\d+/g)) {
      i++;
      message = message + "A Number";
  
    }
    if (!password.match(/[A-Z]+/g)) {
      i++;
      if (i > 1) {
        message = message + ", ";
      }
      message = message + "A Captial Letter";
    }
    if (!password.match(/[a-z]+/g)) {
      i++;
      if (i > 1) {
        message = message + ", ";
      }
      message = message + "A Small Letter";
    }
    if (!password.match(/[\W_]+/g)) {
      i++;
      if (i > 1) {
        message = message + ", ";
      }
      message = message + "A Special Character";
    }
    if (i > 0) {
      return message;
    }
    return true;
  };

  const validationSchema = Yup.object().shape({

    ddlCompany: props.TenantInfo.UserGroup == "SiteAdmin" ? Yup.string().test("", "", (e) => {
      if (refTenant.current?.ddlCompany != e && mode != "Edit") {
        refTenant.current = { ...refTenant.current, ddlCompany: e };
        reset({txtHost:"",chkSecure:false,txtUserName:"",txtEmail:"",txtPassword:""})
      }
      return true;
    }) : Yup.string(),
    txtHost: Yup.string().required("SMTP Host is required").matches(Regex("AllowAlphaNumericAndDot"), 
    "Enter Valid SMTP Host").max(50, "Maximum 50 characters reached"),
    txtUserName: Yup.string().required("SMTP User name is required").matches(Regex("AllowAlphaNumWithoutSpace"),
     "Enter Valid User name").max(50, "Maximum 50 characters reached"),
    txtEmail: Yup.string().required("Email is required").matches(Regex("Email"), "Enter Valid Email").max(100, "Maximum 100 characters reached"),
    chkSecure: Yup.bool().required("Check Secure"),
      txtPassword: Yup.string().test("", (e, { createError }) => {
        if (e == "" || e == undefined) {
                return true;
              }
        const toValidatePassword = validatePassword(e);
        if (toValidatePassword != true) {
            return createError({ message: toValidatePassword });
        }
        else if (e.length > 100) {
            return createError({ message: "Maximum 100 characters reached" });
        }
        else {
            return true;
        }
    }).nullable(),
  })

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  const { register, handleSubmit, setValue, reset, formState, watch, clearErrors } = useForm(formOptions);
  const { errors } = formState;
  const ClearAllControls = () => {
    setValue("txtHost", "");
    setValue("chkSecure",false);
    setValue("txtUserName","");
    setValue("txtEmail", "");
    setValue("txtPassword", "");
    clearErrors(["txtHost","txtUserName","txtEmail","txtPassword"])
  };

  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      router.push("/SiteConfiguration/SMTPList");
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);
  useEffect(() => {
    async function FectchSmtpData() {
      const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);

      let PK, SK;
      if (mode == "Edit") {
        PK = router.query["PK"]
        SK = router.query["SK"]
      }
      let editData = await AppsyncDBconnection(getXlmsSMTPConfig, { PK: PK, SK: SK }, props.user.signInUserSession.accessToken.jwtToken);
      setSmtpData({
        TenantList: tenantResponse?.res?.listXlmsActiveTenantInfo?.items != undefined ? tenantResponse?.res?.listXlmsActiveTenantInfo?.items : [],
        EditData: editData.res?.getXlmsSMTPConfig
      })
    }
    FectchSmtpData()
    return (() => {
      setSmtpData((temp) => { return { ...temp } })
    })
  }, [mode, props.user.signInUserSession.accessToken.jwtToken, router.query])

  const SelectCompany = useMemo(() => {

    let tempSelectCompany = [{ value: "", text: "Select Company" }];
    if (SmtpData?.TenantList?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin") {
      SmtpData?.TenantList?.map((getItem) => tempSelectCompany.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
    } else if (SmtpData?.TenantList?.length > 0 && props.TenantInfo.UserGroup != "") {
      let CurrentTenant = SmtpData?.TenantList?.filter(function (Tenant) {
        return Tenant.TenantID == tenantID;
      });
      CurrentTenant?.map((getItem) =>
        tempSelectCompany.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
      tempSelectCompany.shift();
    }
    return tempSelectCompany;
  }, [SmtpData?.TenantList, tenantID, props.TenantInfo.UserGroup]);



  const FinalResponse = (FinalStatus, ModalType) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: ModalType,
        ModalTopMessage: ModalType == "Error" ? "Error" : "Warning",
        ModalBottomMessage: FinalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", "");
      setModalValues({
        ModalInfo: "Success",
        ModalOnClickEvent: () => {
          router.push("/SiteConfiguration/SMTPList");
        },
      });
      ModalOpen();
    }
  };


  const onSubmit = async (data) => {
    
    setValue("submitbtn", true);
    let SMTPID = Math.random().toString(25).substring(2, 12);
    setValue("submit", "Submit");
    let PK = mode == "Edit" ? SmtpData?.EditData?.PK :  "TENANT#" + router.query["PK"],
      SK = mode == "Edit" ? SmtpData?.EditData?.SK : "SMTPSETTINGS#" + SMTPID;
    let query = mode != "Edit" ? createXlmsSMTPConfig : updateXlmsSMTPConfig;
    let variables = {
      input: {
        PK: PK,
        SK: SK,
        CompanyName: document.getElementById("ddlCompany").options[document.getElementById("ddlCompany").selectedIndex].text,
        SMTPHost: data.txtHost,
        SMTPUser: data.txtUserName,
        SMTPSecure: data.chkSecure,
        EmailID: data.txtEmail,
        Password: data.txtPassword,
        IsDeleted: false
      },
    };
    let FinalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
    FinalResponse(FinalStatus);
    setValue("submitbtn", false);
  };

  useEffect(() => {
    setValue("ddlCompany", tenantID);
    if (mode == "Edit") {
      setValue("ddlCompany", SmtpData?.EditData?.PK.split("#")[1]);
      setValue("txtHost", SmtpData?.EditData?.SMTPHost);
      setValue("chkSecure", SmtpData?.EditData?.SMTPSecure);
      setValue("txtUserName", SmtpData?.EditData?.SMTPUser);
      setValue("txtEmail", SmtpData?.EditData?.EmailID);
      setValue("txtPassword", SmtpData?.EditData?.Password);
    }

  }, [tenantID, mode, props, setValue, SmtpData?.EditData]);


  const PageRoutes = useMemo(() => {
    return [
      { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
      { path: "/SiteConfiguration/SMTPList", breadcrumb: "SMTP Configuration" },
      { path: "", breadcrumb: mode == "Edit" ? "Edit SMTP" : "Add SMTP" }
    ];
  }, [mode]);

  return (
    <>
      <Container title="SMTP" loader={SmtpData == undefined} PageRoutes={PageRoutes}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(onSubmit)} id="Formjs" className={`${ watch("submitbtn") ? "pointer-events-none" : "px-2"}`}>
          <div className="nvl-FormContent">
            <NVLSelectField id="ddlCompany" options={SelectCompany} labelText="Select Company" labelClassName="font-semibold text-gray-500" disabled={true} errors={errors} title="Select Company" register={register} className={`${ "Disabled w-96 nvl-mandatory"} `} />
            <NVLTextbox id="txtHost" errors={errors} labelText="SMTP Host" labelClassName="font-semibold text-gray-500" title="Enter SMTP Host" disabled={mode == "Edit" ? true : false} className={`${mode == "Edit" ? "Disabled" : ""} nvl-mandatory`} register={register} />
            <div className="pt-2 ">
              <NVLCheckbox id="chkSecure" errors={errors} register={register} text="SMTP Secure" />
            </div>
            <NVLTextbox id="txtUserName" errors={errors} labelText="SMTP UserName" labelClassName="font-semibold text-gray-500" title="Enter SMTP User Name" className="nvl-mandatory" register={register} />
            <NVLTextbox id="txtEmail" errors={errors} title="Enter Email" labelText="Email" labelClassName="font-semibold text-gray-500" className="nvl-mandatory " register={register} />
            <div className="relative ">
              <NVLPassword title="Password" id="txtPassword" type="password" labelText="Password" labelClassName="nvl-Def-Label" className=" nvl-non-mandatory nvl-Def-Input !pr-8" register={register} errors={errors}></NVLPassword>
              {watch("Error") != "" && watch("Error") != undefined && <div className="{invalid-feedback}   text-red-500 text-sm ">{watch("txtPassword") != "" ? watch("Error") : ""}</div>}
            </div>
          </div>
          <div className="justify-center flex gap-4 pt-4 ">
            <NVLButton id="btnSave" text={!watch("submitbtn") ? "Save" : ""} disabled={watch("submitbtn") ? true : false} type="submit" className={watch("submitbtn") ? "w-32 nvl-button bg-primary text-white" : "w-28 nvl-button  bg-primary text-white"}> {watch("submitbtn") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
            <NVLButton id="btnCancel" text={mode == "Edit" ? "Cancel" : "Clear"} type="button" className="nvl-button w-32" onClick={() => (mode == "Edit" ? router.push("/SiteConfiguration/SMTPList") : ClearAllControls())} />
          </div>
        </form>
      </Container>
      <div id="modepopup" className="hidden modalTop">
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
      </div>
    </>
  );
}

export default SMTP;