import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { deleteXlmsCustomNotification } from "src/graphql/mutations";
import { listXlmsActiveTenantInfo, listXlmsCustomNotification } from "src/graphql/queries";
import * as Yup from "yup";

export default function CustomNotificationList(props) {
    const router = useRouter();
    const [data, setData] = useState([]);
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [popupValues, setPopupValues] = useState({});
    const [variable, setvariable] = useState({
        PK: "TENANT#" + props.TenantInfo.TenantID, SK: "CUSTOMNOTIFICATION#",
    });

    useEffect(() => {
        const dataSource = async () => {
            const tenantId = decodeURIComponent(String(router.query["TenantID"]));
            const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            setData({
                TenantData: tenantResponse?.res?.listXlmsActiveTenantInfo?.items,
                TenantID: tenantId != undefined && tenantId
            });
        };
        dataSource();
        return (() => {
            setData((temp) => { return { ...temp }; });
        });

    }, [props.user.signInUserSession.accessToken.jwtToken, router.query]);

    const headerColumn = [
        // { HeaderName: "S No", Columnvalue: "SNo", HeaderCss: "w-1/12" },
        { HeaderName: "Template Name", Columnvalue: "TemplateName", HeaderCss: "w-4/12", },
        { HeaderName: "Template Description", Columnvalue: "TemplateDescription", HeaderCss: "w-0/12", },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-2/12" },
    ];


    const validationSchema = Yup.object().shape({
        ddlSearch:
      props.TenantInfo.UserGroup == "SiteAdmin"
          ? Yup.string()
              .required("Please Select The Field")
              .test("NOValid", "ChangeHandler", (e) => {
                  if (props.TenantInfo.UserGroup != "SiteAdmin") {
                      return true;
                  }
                  if (e != "") {
                      setvariable({ PK: "TENANT#" + e, SK: "CUSTOMNOTIFICATION#" });
                      return true;
                  }
                  return false;
                  
              })
          : Yup.string().nullable(),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
    const { register, setValue, formState } = useForm(formOptions);
    const { errors } = formState;
    const dropdownData = useMemo(() => {
        let CurrentTenant = [];
        const temp = [{ value: "", text: "Select Company" }];
        if (data.TenantData != undefined) {
            if (props.TenantInfo.UserGroup != "" || props.TenantInfo.UserGroup != undefined) {
                CurrentTenant = data.TenantData.filter(function (Tenant) {
                    return Tenant.TenantID == data.TenantID;
                });
                CurrentTenant.map((getItem) =>
                    temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
                setValue("ddlSearch", data.TenantID, { shouldValidate: true });
            }
            temp.shift();
        }
        return temp;
    }, [data.TenantData, props.TenantInfo.UserGroup, data.TenantID, setValue]);


    function ResetPopUp() {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    // document.getElementById("tableSearch").value = "";
    }
    const refreshData = async () => {
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    async function UpdateField(e) {
        e.preventDefault();
        refreshData();
        await AppsyncDBconnection(
            deleteXlmsCustomNotification,
            { input: { PK: popupValues.PK, SK: popupValues.SK } }, props?.user.signInUserSession.accessToken.jwtToken
        )
            .then(() => {
                refreshData();
            })
            .catch((e) => {
                alert(e?.errors?.[0].message);
                return;
            });
        ResetPopUp();
    }

    function popup(type, PK, SK, Content) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
    }

    const actionRestriction = useCallback((getItem) => {
        const actionList = [];


        if (props.RoleData?.EditCustomNotification) {

            actionList.push(
                { id: 1, Color: "text-green-700", Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6", name: "Edit", action: () =>
                    router.push(  `/SiteConfiguration/CustomNotification?Mode=Edit&TemplateID=${getItem.TemplateID}`),
                },);
        }
        if (props.RoleData?.DeleteCustomNotification) {
            actionList.push(
                { id: 2, Color: "text-rose-700", Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6", name: "Delete", action: () =>
                    popup( "isDelete", getItem.PK, getItem.SK, "Are you sure to Delete Notification?" ),
                });
        }
        return actionList;
    }, [router, props]);

    const gridDataBind = useCallback(
        (viewData) => {
            const rowGrid = [];
            viewData &&
        viewData.map((getItem, index) => {
            let ActionList = [];
            ActionList = actionRestriction(getItem);
            rowGrid.push({
                PK: (
                    <NVLlabel
                        id={"lblPKID" + (index + 1)}
                        name="PK"
                        text={getItem.PK}
                    />
                ),
                SK: (
                    <NVLlabel
                        id={"lblSKID" + (index + 1)}
                        name="SK"
                        text={getItem.SK}
                    />
                ),
                // SNo: (
                //     <NVLlabel
                //         id={"lblSNo" + (index + 1)}
                //         name="SNo"
                //         text={index + 1}
                //     />
                // ),
                TemplateName: (
                    <NVLlabel
                        id={"txtTemplateName" + (index + 1)}
                        text={
                            getItem.TemplateName
                        }
                    ></NVLlabel>
                ),
                TemplateDescription: (
                    <NVLlabel
                        id={"txtTemplateDescr" + (index + 1)}
                        text={
                            getItem.TemplateDescription
                        }
                    ></NVLlabel>
                ),
                Action: (
                    <NVLRapidModal
                        id={"RapidModal" + (index + 1)}
                        ActionList={ActionList}
                    ></NVLRapidModal>
                ),
            });
        });
            return rowGrid;
        },
        [actionRestriction]
    );
    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };
    // Bread Crumbs
    const pageRoutes = [
        { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
        { path: `/SiteConfiguration/NotificationSettingList?TenantID=${(data.TenantID)}`, breadcrumb: "Notification Setting" },
        { path: "", breadcrumb: "Custom Notification" }
    ];
    return (
        <>
            <Container PageRoutes={pageRoutes} loader={data.TenantID == undefined}>
                <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab}
                    LinkName1="Send Notification" LinkName2="Add Notification"
                    className2={props.RoleData?.AddCustomNotification ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} className1={props.RoleData?.SendCustomNotification ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"}
                    href1="/SiteConfiguration/SendNotification"
                    href2={`/SiteConfiguration/CustomNotification?Mode=Create&TenantID=${data.TenantID}`}
                    RedirectAction1={(e) => headerHandler(e, "/SiteConfiguration/SendNotification")} RedirectAction2={(e) => headerHandler(e, `/SiteConfiguration/CustomNotification?Mode=Create&TenantID=${data.TenantID}`)} TableID={"tblCustomlist"}
                    IsDropdownDisable={true} IsDropdown={true} title="Select Company"

                    DropdownData={dropdownData}
                    register={register} errors={errors}
                    DropdownRequired={true} IsNestedHeader />
                <NVLGridTable user={props.user} refershPage={isRefreshing} id="tblUserList" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsCustomNotification} querryName={"listXlmsCustomNotification"} variable={variable} />
                <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => UpdateField(e)} CancelClick={() => ResetPopUp()} ButtonNotext="No" CloseIconEvent={() => ResetPopUp()} Content={popupValues.Content}></NVLModalPopup>
            </Container>
        </>
    );
}

