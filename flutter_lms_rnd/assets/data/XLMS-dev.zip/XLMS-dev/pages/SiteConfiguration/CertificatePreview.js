
import { useEffect, useRef } from "react";

export default function CertificatePreview(props) {
    const tess = useRef();

    useEffect(() => {
        let Certificate = props.cert.toString();
        Certificate = Certificate.replaceAll('class="panel rounded-md"', 'class="panel"');
        Certificate = Certificate.replaceAll('<div class="top-left"></div><div class="top"></div><div class="top-right"></div><div class="right"></div><div class="right-bottom"></div><div class="bottom"></div><div class="bottom-left"></div><div class="left"></div>', "");
        Certificate = Certificate.replaceAll('class="focus:outline-none rounded focus:border-4 border-yellow-600 cursor-pointer"', 'class="rounded"');
        Certificate = Certificate.replaceAll('<i class="fa fa-solid close-icon-pattern fa-minus text-red-600 h-6 w-6 grid place-content-center cursor-pointer rounded-full bg-red-100"></i>', "");
        tess.current.innerHTML = Certificate;
    }, [props.cert]);

    return (
        <section className="text-gray-600 body-font m-10 flex gap-8 text-xs font-semibold bg-gray-200 rounded-md">
            <div className={` justify-center relative sm:flex-row sm:items-center items-start mx-auto overflow-auto max-w-screen-2xl`} id="CustomeCert">
                <div style={{width:props?.watch("txtTempWidth")+"mm",height:props?.watch("txtTempHeight")+"mm",marginLeft:props?.watch("txtLeftMargin")+"mm",marginRight:props?.watch("txtRightMargin")+"mm"}} ref={tess}></div>
            </div>
        </section> 

        
    );
}
