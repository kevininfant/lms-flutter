import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLWarning from "@components/Controls/NVLWarning";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsPopUpInfo, updateXlmsPopUpInfo } from "src/graphql/mutations";
import { getXlmsPopUpInfo, getXlmsTenantInfo, listXlmsActiveTenantInfo, listXlmsPopUpInfo } from "src/graphql/queries";
import * as Yup from "yup";


function AddPopUp(props) {
    const router = useRouter();
    const [PopUpData, setPopUpData] = useState()
    const mode = useMemo(() => { return router.query["Mode"] }, [router.query])
    const fileName = useRef();
    const [fileValues, setFileValues] = useState({ TextName: "Select File", FilePath: "", });
    const uploadFileType = useRef()
    const stDate = useRef();


    const validationSchema = Yup.object().shape({
        txtURL: Yup.string()
            .when("ddlFileType", {
                is: "URL",
                then: Yup.string().required("URL is required").matches(Regex("Url"), "Url is invalid").nullable(),
            }).nullable(),
        File: Yup.string().nullable()
            .when("ddlFileType", {
                is: (e) => e != "URL",
                then: Yup.string()
                    .test("", "", (e, { createError }) => {
                        if (e == "" || e == undefined && fileValues.FilePath == "") {
                            return createError({ message: "File is required" })
                        }
                        if (e == "fileType") {
                            return createError({ message: ` Please upload only .jpg, .jpeg, .png, .mp4, .mp3 file!` });
                        }
                        if (e == "fileSize") {
                            return createError({ message: "File size should not exceed 128MB" });
                        }
                        if (e == "Error") {
                            return createError({ message: "Server error please try again" });
                        }
                        if (e == "fileValid") {
                            return createError({ message: "File format seems to be changed" });
                        }
                        return true;
                    })
            })
            .nullable(),
        ddlFileType: Yup.string().required("File type is required").test("", "", (e) => {
            if (e != uploadFileType.current) {
                uploadFileType.current = e
                clearErrors(["File", "txtURL"])
            }
            if (watch("ddlFileType") == "File") {
                setValue("txtURL", "")
            } else {
                setFileValues({ TextName: "Select File", FilePath: "", path: "" })
            }
            return true
        }).nullable(),
        txtTitle: Yup.string().required("Popup title is required").min(3, "Title should not be lesser than 3 characters").matches(Regex("AlphanumWithAllSpecialChar"), "Popup title is invalid").max(250, "Maximum 250 characters reached")
            .test("", "", (e, { createError }) => {
                const existingPopUpName = PopUpData?.PopUpData && Object.values(PopUpData?.PopUpData).filter(
                    (data) => {
                        return data?.PopUpName.toLowerCase() == e.toLowerCase();
                    }
                );
                const popUpNameFound = existingPopUpName?.some((popup) => popup?.PopUpName?.toLowerCase() == e?.toLowerCase());
                if (mode == "Edit" && ((PopUpData?.EditData?.PopUpName == watch("txtTitle")) == popUpNameFound)) {
                    return true
                }
                else
                    if (existingPopUpName?.[0]?.PopUpName != undefined &&
                        e?.toLowerCase() != PopUpData?.PopUpData?.PopUpName?.toLowerCase()) {
                        return createError({ message: "Popup title already exists" });
                    }
                return true;

            })
            .nullable(),
        txtstdate: (PopUpData?.EditData?.StartDate != (document?.getElementById("txtstdate") && document?.getElementById("txtstdate")?.value)) && Yup.string()
            .required("Start date is required").typeError("Start date is invalid value")
            .test("Check", "Popup can be created only for present and future date time", (e) => {            
                if (new Date(e) >= new Date(watch("txtEnddate"))) {
                    setError("txtEnddate", { message: "End date must be greater than the start date" })
                }
                if (new Date(e) < new Date(watch("txtEnddate"))) {
                    setError("txtEnddate", { message: "" })
                }
                if (e == "" || e == undefined || e == null) {
                    return true;
                }
                else {
                    if (new Date(e) > new Date(new Date().setMinutes(new Date().getMinutes() - 1))) {
                        if ((stDate.current != e) && (watch("txtEnddate") != undefined) && (new Date(e) >= new Date(watch("txtEnddate")))) {
                            stDate.current = e;
                            setValue("txtEnddate", watch("txtEnddate"), { shouldValidate: true })
                        }
                        return true;
                    }
                    else {
                        return false
                    }
                }
            }).nullable(true),

        txtEnddate: Yup.string()
            .required("End date is required").typeError("End Date is invalid value")
            .test("Check", "End date must be greater than the start date", (e) => {
                if (new Date(e) > new Date(watch("txtstdate"))) {
                    return true;
                }
                else {
                    return false
                }

            }).typeError("End Date is invalid value").nullable(),
    })

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, setError, formState, watch, clearErrors, reset } = useForm(formOptions);
    const { errors } = formState;

    const initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/SiteConfiguration/ManagePopUpList");
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);
    useEffect(() => {
        async function FetchPopUp() {

            let tenantDataResponse;
            const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            if (props?.TenantInfo?.UserGroup == "SiteAdmin") {
                tenantDataResponse = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + router.query["TenantID"] }, props.user.signInUserSession.accessToken.jwtToken);
            }
            let PK, SK;
            const popUpData = await AppsyncDBconnection(listXlmsPopUpInfo, { PK: (props?.TenantInfo?.UserGroup == "SiteAdmin") ? "TENANT#" + router.query["TenantID"] : "TENANT#" + props?.TenantInfo?.TenantID, SK: "POPUP#" }, props.user.signInUserSession.accessToken.jwtToken)
            if (mode == "Edit") {
                PK = props?.TenantInfo?.UserGroup == "SiteAdmin" ? "TENANT#" + tenantDataResponse?.res?.getXlmsTenantInfo?.TenantID : "TENANT#" + props?.TenantInfo?.TenantID
                SK = "POPUPID#" + router.query["PopUpID"]
            }
            let editData = await AppsyncDBconnection(getXlmsPopUpInfo, { PK: PK, SK: SK }, props.user.signInUserSession.accessToken.jwtToken);
            setPopUpData({
                TenantList: tenantResponse?.res?.listXlmsActiveTenantInfo?.items != undefined ? tenantResponse?.res?.listXlmsActiveTenantInfo?.items : [],
                EditData: editData?.res?.getXlmsPopUpInfo,
                PopUpData: popUpData?.res?.listXlmsPopUpInfo?.items,
                TenantData: tenantDataResponse?.res?.getXlmsTenantInfo
            })
            if (mode == "Edit") {
                uploadFileType.current = PopUpData?.EditData?.FileType
            }
        }
        FetchPopUp()
        return (() => {
            setPopUpData((temp) => { return { ...temp } })
        })
    }, [PopUpData?.EditData?.FileType, mode, props?.TenantInfo?.TenantID, props?.TenantInfo?.UserGroup, props.user.signInUserSession.accessToken.jwtToken, router.query, setValue, watch])

    const DateTime = useCallback(({ EndDate, StartDate, errors, register, setValue }) => {
        const today = new Date();
        const dateTime = today.getFullYear() + "-" + (today.getMonth() + 1 >= 10 ? today.getMonth() + 1 : "0" + (today.getMonth() + 1)) + "-" + (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) + "T" + today.getHours() + ":" + today.getMinutes();
        return (
            <div className="grid">
                {StartDate == undefined && (
                    <div className="flex">
                        <div className="pt-1">
                            <div className="pb-1">
                                <NVLlabel text="Start Date" className="font-semibold text-gray-500"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            </div>
                            <NVLTextbox
                                id="txtstdate"
                                title="Start Date"
                                type="datetime-local"
                                className="nvl-Def-Input nvl-mandatory"
                                // min={dateTime}
                                setValue={setValue}
                                errors={errors}
                                register={register}
                            ></NVLTextbox>
                        </div>
                    </div>
                )}
                {EndDate == undefined && (
                    <div className="flex">
                        <div className="">
                            <div className="pb-1">
                                <NVLlabel text="End Date" className="font-semibold text-gray-500"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            </div>
                            <NVLTextbox
                                title="End Date"
                                id="txtEnddate"
                                type="datetime-local"
                                className="nvl-Def-Input nvl-mandatory"
                                // min={dateTime}
                                errors={errors}
                                register={register}
                                setValue={setValue}
                            ></NVLTextbox>
                        </div>
                    </div>
                )}
            </div>
        );
    }, []);

    const SelectFileType = useMemo(() => {
        return [{ value: "", text: "Select" },
        { value: "File", text: "File Attachment" },
        { value: "URL", text: "URL Link" }
        ]
    }, [])

    const uploadFile = useCallback(
        async (e, mode) => {
            setValue("File", "")
            const file = e.target.files[0];
            setValue("File", "Uploading", { shouldValidate: true });
            const reader = new FileReader();
            let header = '';
            let temp, fileType;
            reader.onload = async function () {
                const arr = (new Uint8Array(reader.result)).subarray(0, 4);
                for (let i = 0; i < arr.length; i++) {
                    header += arr[i].toString(16);
                }
                const imageExtension = ["jpg", "jpeg", "png"];
                const videoExtension = ["mp4", "webm"];
                const audioExtension = ["mp3"]
                const extension = e.target.value
                    .substring(e.target.value.lastIndexOf(".") + 1)
                    .toLowerCase();
                const contentType =
                    imageExtension.indexOf(extension) >= 0
                        ? "image/" + extension
                        : videoExtension.indexOf(extension) >= 0 ? "video/" + extension
                            : audioExtension.indexOf(extension) >= 0 ? "audio/mpeg"
                                : "application/" + extension
                switch (header + '|' + contentType) {
                    case '89504e47|image/png':
                        fileType = 'image/png';
                        break;
                    case 'ffd8ffe0|image/jpg':
                    case 'ffd8ffe1|image/jpg':
                    case 'ffd8ffe2|image/jpg':
                        fileType = 'image/jpg';
                        break;
                    case 'ffd8ffe0|image/jpeg':
                    case 'ffd8ffe1|image/jpeg':
                    case 'ffd8ffe2|image/jpeg':
                        fileType = 'image/jpeg';
                        break;
                    case '4944333|audio/mpeg':
                    case '4944334|audio/mpeg':
                    case '49443303|audio/mpeg':
                        fileType = 'audio/mp3';
                        break;
                    case '000001ba|video/mp4':
                    case '00020|video/mp4':
                        fileType = 'video/mp4';
                        break;
                    case '1a45dfa3|video/webm':
                        fileType = 'video/webm';
                        break;
                    default:
                        temp = 1;
                        setValue("File", "fileValid", { shouldValidate: true });
                        setFileValues({ TextName: "Select File", FilePath: "", path: "" })
                        break;
                }
                if (temp == 1) {
                    return false;
                }

                const fetchURL =
                    props?.TenantInfo?.UserGroup == "SiteAdmin" ? process.env.POPUP_UPLOAD_UNSAVE_PRESIGN + `?FileName=${e.target.files[0].name}&TenantId=${router.query["TenantID"]}&BucketName=${PopUpData?.TenantData?.BucketName}&RootFolder=${PopUpData?.TenantData?.RootFolder}&Page=ModalPopUp&S3BucketName=${PopUpData?.TenantData?.BucketName}&S3KeyName=${PopUpData?.TenantData?.RootFolder + "/" + router.query["TenantID"]}` :
                        process.env.POPUP_UPLOAD_UNSAVE_PRESIGN + `?FileName=${e.target.files[0].name}&TenantId=${props?.TenantInfo.TenantID}&BucketName=${props?.TenantInfo.BucketName}&RootFolder=${props?.TenantInfo.RootFolder}&Page=ModalPopUp&S3BucketName=${props?.TenantInfo.BucketName}&S3KeyName=${props?.TenantInfo.RootFolder + "/" + props?.TenantInfo.TenantID}`;
                const headers = {
                    method: "GET",
                    headers: {
                        authorizationtoken: await Auth.currentSession().then((s) =>
                            s.getAccessToken().getJwtToken()
                        ),
                        defaultrole: props?.TenantInfo.UserGroup,
                        groupmenuname: "SiteConfiguration",
                        menuid: "601601",
                    },
                };


                const presignedHeader = {
                    method: "PUT",
                    headers: {
                        "content-type": contentType,
                    },
                    body: file,
                };
                const finalStatus = await APIGatewayPutRequest(fetchURL, headers, presignedHeader);
                if (mode == "Files") {
                    if (finalStatus[0] != "Success") {
                        setFileValues({
                            ...fileValues,
                            TextName: "Select File",
                            FilePath: "",
                            pathchanged: false,
                            setfile: "",
                        });
                        setValue("File", "Error", { shouldValidate: true });
                        return;
                    } else {
                        setFileValues({
                            TextName: e.target.files[0].name,
                            FilePath: finalStatus[1],
                            path: finalStatus[1],
                            pathchanged: true,
                            setfile: watch("ddlFileType"),
                        });
                        setValue("File", "exist", { shouldValidate: true });
                    }
                }
            };
            reader.readAsArrayBuffer(file);
        },
        [PopUpData?.TenantData?.BucketName, PopUpData?.TenantData?.RootFolder, fileValues, props, router.query, setValue, watch]
    );

    const FinalResponse = (FinalStatus) => {
        if (FinalStatus != "Success") {
            setValue("submit", false);
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        } else {
            setValue("submit", "");
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    router.push("/SiteConfiguration/ManagePopUpList");
                },
            });
            ModalOpen();
        }
    };
    const fileValidation = useCallback((e, mode) => {
        setValue("File", "")
        if (e.target.files.length == 0) {
            return;
        }
        const file = e.target.files[0];
        let FileName = e.target.files[0].name;
        fileName.current = e.target.files[0].name;
        const filePath = FileName.split(".")[0] + "." + file.type.split("/").pop();


        if ((file.name.split(".").pop() == "jpg" && file.type.split("/").pop() == "jpeg") || (file.name.split(".").pop() == "jpeg" && file.type.split("/").pop() == "jpg")) {
            FileName = FileName.split(".")[0] + "." + file.type.split("/").pop();
            file = createFile([file], FileName);
        }

        if (file.size > process.env.POPUP_FILE_SIZE) {

            setValue("File", "fileSize", {
                shouldValidate: true,
            })
            setFileValues({
                TextName: "Select File",
                FilePath: "",
                pathchanged: false,
                setfile: ""
            })
            return false;
        }
        const extension = e.target?.files[0]?.name
            ?.substring(e.target.files[0].name.lastIndexOf(".") + 1)
            .toLowerCase();

        const allowedExtensions = ["jpg", "jpeg", "png", "mp4", "mp3", "webm"]

        if (allowedExtensions.indexOf(extension) <= -1 || file == null) {
            file.value = "";
            setValue("File", "fileType", {
                shouldValidate: true,
            });
            setFileValues({
                TextName: "Select File",
                FilePath: "",
                pathchanged: false,
                setfile: ""
            })
            return false;
        }
        uploadFile(e, mode);
    }, [setValue, uploadFile])

    const createFile = (bits, name) => {
        try {
            return new File(bits, name, {
                type: "image/" + name.split(".").pop(),
                lastModified: new Date(),
            });
        } catch (e) {
            let myBlob = new Blob(bits);
            myBlob.lastModified = new Date();
            myBlob.name = name;
            return myBlob;
        }
    };


    const onSubmit = async (data) => {
        document?.activeElement?.blur();
        setValue("submit", true);
        let popUpID = Math.random().toString(25).substring(2, 12);
        const filePath = "";
        const finalResult = "";

        let FileType, fileExtension;

        fileExtension = fileValues?.TextName?.substring(fileValues?.TextName?.lastIndexOf('.') + 1, fileValues?.TextName?.length);

        if (watch("ddlFileType") == "File") {
            FileType = (fileExtension == "mp4" || fileExtension == "webm") ? "Video" : fileExtension == "mp3" ? "Audio" : "Image"

        } else {
            FileType = data.txtURL?.toLowerCase()?.includes("youtu.be") || data.txtURL?.toLowerCase()?.includes("youtube") ? "Youtube" : data.txtURL?.toLowerCase()?.includes("vimeo") ? "Vimeo" : "URL"
        }

        if (watch("ddlFileType") == "File" && watch("File") == "exist") {
            const fetchURL =
                props?.TenantInfo?.UserGroup == "SiteAdmin" ? process.env.POPUP_UPLOAD_UNSAVED_TO_SAVE + `?FileName=${fileValues?.TextName}&TenantId=${router.query["TenantID"]}&BucketName=${PopUpData?.TenantData?.BucketName}&RootFolder=${PopUpData?.TenantData?.RootFolder}&Page=ModalPopUp&PopUpId=${mode == "Edit" ? router.query["PopUpID"] : popUpID}&S3BucketName=${PopUpData?.TenantData?.BucketName}&S3KeyName=${PopUpData?.TenantData?.RootFolder + "/" + router.query["TenantID"]}` :
                    process.env.POPUP_UPLOAD_UNSAVED_TO_SAVE + `?FileName=${fileValues?.TextName}&TenantId=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&Page=ModalPopUp&PopUpId=${mode == "Edit" ? router.query["PopUpID"] : popUpID}&S3BucketName=${props?.TenantInfo.BucketName}&S3KeyName=${props?.TenantInfo.RootFolder + "/" + props?.TenantInfo.TenantID}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationToken: await Auth.currentSession().then((s) =>
                        s.getAccessToken().getJwtToken()
                    ),
                    defaultrole: props.TenantInfo.UserGroup,
                    groupmenuname: "SiteConfiguration",
                    menuid: "601601",
                },
            };
            finalResult = await APIGatewayGetRequest(fetchURL, headers);
            filePath = await finalResult?.res?.text();
        }
        let FinalStatus;


        let date = new Date().toISOString();
        let PK = mode == "Edit" ? PopUpData?.EditData?.PK : props?.TenantInfo?.UserGroup == "SiteAdmin" ? "TENANT#" + router.query["TenantID"] : "TENANT#" + props?.TenantInfo?.TenantID,
            SK = mode == "Edit" ? "POPUP#LASTMODIFIEDDATE#" + date + "#POPUPID#" + PopUpData?.EditData?.PopUpId : "POPUP#LASTMODIFIEDDATE#" + date + "#POPUPID#" + popUpID;
        let query = createXlmsPopUpInfo;
        let variables = {
            input: {
                PK: PK,
                SK: SK,
                FileType: FileType,
                PopUpId: mode == "Edit" ? router.query["PopUpID"] : popUpID,
                PopUpName: data.txtTitle,
                FilePath: watch("ddlFileType") == "File" ? fileValues.pathchanged == true ? filePath : PopUpData?.EditData?.FilePath : "",
                URL: data.txtURL,
                FileName: watch("ddlFileType") == "File" ? fileValues?.TextName : data.txtURL,
                StartDate: data.txtstdate,
                EndDate: data.txtEnddate,
                CreatedDate: mode == "Edit" ? PopUpData?.EditData?.CreatedDate : date,
                CreatedBy: props.user.username,
                LastModifiedDate: date,
                LastModifiedBy: props.user.username,
                IsDeleted: false
            },
        };
        if (finalResult?.res?.status == 200 || watch("ddlFileType") == "URL" || watch("ddlFileType") == "File") {
            FinalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
        }

        if (FinalStatus == "Success") {
            PK = mode == "Edit" ? PopUpData?.EditData?.PK : props.TenantInfo.UserGroup != "SiteAdmin" ? "TENANT#" + props.TenantInfo.TenantID : "TENANT#" + router.query["TenantID"],
                SK = mode == "Edit" ? "POPUPID#" + PopUpData?.EditData?.PopUpId : "POPUPID#" + popUpID;
            query = mode == "Edit" ? updateXlmsPopUpInfo : createXlmsPopUpInfo;
            variables = {
                input: {
                    PK: PK,
                    SK: SK,
                    FileType: FileType,
                    PopUpId: mode == "Edit" ? PopUpData?.EditData?.SK.split("#")[1] : popUpID,
                    PopUpName: data.txtTitle,
                    FilePath: watch("ddlFileType") == "File" ? fileValues.pathchanged == true ? filePath : PopUpData?.EditData?.FilePath : "",
                    URL: data.txtURL,
                    FileName: watch("ddlFileType") == "File" ? fileValues?.TextName : data.txtURL,
                    StartDate: data.txtstdate,
                    EndDate: data.txtEnddate,
                    CreatedDate: mode == "Edit" ? PopUpData?.EditData?.CreatedDate : date,
                    CreatedBy: props.user.username,
                    LastModifiedDate: date,
                    LastModifiedBy: props.user.username,
                    IsDeleted: false
                },
            };
            if (finalResult?.res?.status == 200 || watch("ddlFileType") == "URL" || watch("ddlFileType") == "File") {
                FinalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
            }
        }

        if (mode == "Edit" && FinalStatus == "Success") {
            let PK = mode == "Edit" ? PopUpData?.EditData?.PK : "TENANT#" + props.TenantInfo.TenantID,
                SK = "POPUP#LASTMODIFIEDDATE#" + PopUpData?.EditData?.LastModifiedDate + "#POPUPID#" + PopUpData?.EditData?.PopUpId;
            let query = updateXlmsPopUpInfo;
            let variables = {
                input: {
                    PK: PK,
                    SK: SK,
                    IsDeleted: true
                }
            }
            if (finalResult?.res?.status == 200 || watch("ddlFileType") == "URL" || watch("ddlFileType") == "File") {
                FinalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken)).Status;
            }
        }

        FinalResponse(FinalStatus);

        if (fileValues.pathchanged == true && watch("ddlFileType") == "File" && (fileValues?.TextName.split(".").pop() == "mp4" || fileValues?.TextName.split(".").pop() == "webm")) {
            const fetchUrl = props?.TenantInfo?.UserGroup == "SiteAdmin" ? process.env.POPUP_VIDEO_TRANSCODING_URL + `?FileName=${fileValues?.TextName}&TenantId=${router.query["TenantID"]}&BucketName=${PopUpData?.TenantData?.BucketName}&RootFolder=${PopUpData?.TenantData?.RootFolder}&Page=ModalPopUp&PopUpId=${mode == "Edit" ? router.query["PopUpID"] : popUpID}&UserSub=${props?.user.attributes?.sub}&S3BucketName=${PopUpData?.TenantData?.BucketName}&S3KeyName=${PopUpData?.TenantData?.RootFolder + "/" + router.query["TenantID"]}` : process.env.POPUP_VIDEO_TRANSCODING_URL + `?FileName=${fileValues?.TextName}&TenantId=${props.TenantInfo.TenantID}&BucketName=${props.TenantInfo.BucketName}&RootFolder=${props.TenantInfo.RootFolder}&Page=ModalPopUp&PopUpId=${mode == "Edit" ? router.query["PopUpID"] : popUpID}&UserSub=${props?.user.attributes?.sub}&S3BucketName=${props?.TenantInfo.BucketName}&S3KeyName=${props?.TenantInfo.RootFolder + "/" + props?.TenantInfo.TenantID}`;
            const headers = {
                method: "GET",
                headers: {
                    authorizationtoken: props?.user?.signInUserSession.accessToken.jwtToken,
                    defaultrole: props?.TenantInfo?.UserGroup,
                    groupmenuname: "SiteConfiguration",
                    menuid: "601602",
                }
            };
            await APIGatewayGetRequest(fetchUrl, headers);
        }
        setValue("Submit", false);
    };


    useEffect(() => {
        if (mode == "Edit") {
            setValue("ddlFileType", (PopUpData?.EditData?.FileType == "Image" || PopUpData?.EditData?.FileType == "Video" || PopUpData?.EditData?.FileType == "Audio") ? "File" : "URL");
            setValue("txtTitle", PopUpData?.EditData?.PopUpName);
            setValue("txtstdate", PopUpData?.EditData?.StartDate);
            setValue("txtEnddate", PopUpData?.EditData?.EndDate);
            setValue("txtURL", (PopUpData?.EditData?.FilePath == "" || PopUpData?.EditData?.FilePath == undefined || PopUpData?.EditData?.FilePath == null) ? PopUpData?.EditData?.URL : "")
            setFileValues({
                TextName: (PopUpData?.EditData?.URL == undefined || PopUpData?.EditData?.URL == null || PopUpData?.EditData?.URL == "") ? PopUpData?.EditData?.FileName : "",
                FilePath: PopUpData?.EditData?.FilePath,
                path: PopUpData?.EditData?.FilePath,
                pathchanged: false,
                setfile: watch("ddlFileType"),
            })
        }
    }, [PopUpData?.EditData, PopUpData?.EditData?.EndDate, PopUpData?.EditData?.FileName, PopUpData?.EditData?.FilePath, PopUpData?.EditData?.FileType, PopUpData?.EditData?.PopUpName, PopUpData?.EditData?.StartDate, PopUpData?.EditData?.URL, mode, props, setValue, watch]);

    const clearFields = useCallback(() => {
        reset()
        setFileValues({
            TextName: "Select File",
            FilePath: "",
            pathchanged: false,
            setfile: ""
        })
    }, [reset])


    const PageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "/SiteConfiguration/ManagePopUpList", breadcrumb: "ManagePopUpList" },
            { path: "", breadcrumb: mode == "Edit" ? "Edit PopUp" : "Add PopUp" }
        ];
    }, [mode]);


    return (
        <>
            <Container title={`${mode == "Edit" ? "Edit Popup" : "Add Popup"}`} loader={PopUpData == undefined ? true : false} PageRoutes={PageRoutes}>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(onSubmit)} noValidate id="Formjs" className={`${watch("submit") || watch("File") == "Uploading" || (PopUpData?.EditData?.FileProcessing != undefined && PopUpData?.EditData?.FileProcessing != 0) ? "px-2 pointer-events-none" : "px-2"}`}>
                    {!(PopUpData?.EditData?.FileProcessing == undefined || PopUpData?.EditData?.FileProcessing == 0) && <NVLWarning Header={"In Processing!..."} Content={"File is processing, it will take some time"}></NVLWarning>}
                    <div className="nvl-FormContent">
                        <NVLTextbox id="txtTitle" labelText="Title" labelClassName="font-semibold text-gray-500" disabled={false} errors={errors} title="Title" register={register} className={`${"nvl-mandatory"} `} />
                        <NVLSelectField id="ddlFileType" options={SelectFileType} labelText="Select File Type" labelClassName="font-semibold text-gray-500" disabled={false} errors={errors} title="Select File Type" register={register} className={`${"  w-96 nvl-mandatory"} `} />
                        <div className={watch("ddlFileType") == "File" ? "" : "hidden"}>
                            <NVLlabel text="Upload File" className="nvl-Def-Label"><span className="text-red-500 text-lg">*</span></NVLlabel>
                            <div className="grid grid-flow-col">
                                <NVLFileUpload text={fileValues?.TextName == null || fileValues?.TextName == "" ? "Select File" : fileValues?.TextName} className={"nvl-mandatory"} accept={`${`Acceptable file format: .jpg, .jpeg, .png, .mp4, .mp3, .webm <br>File size should not exceed more than 128MB`}`} onChange={(e) => fileValidation(e, "Files")} />
                                <div className="pt-3 pl-1">
                                    <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                                </div>
                                <div className="my-auto">
                                    <NVLlabel className="nvl-Def-Label" HelpInfo={`Acceptable file format: .jpg, .jpeg, .png, .mp4, .mp3, .webm <br>File size should not exceed 128MB`} HelpInfoIcon={"fa fa-solid fa-circle-question pt-2"} />
                                </div>
                            </div>
                            <div className={"Center-Aligned-Items {invalid-feedback} text-red-500 text-sm pt-2 "}>
                                {errors?.File?.message}
                            </div>
                        </div>
                        <div className={watch("ddlFileType") == "" || watch("ddlFileType") != "URL" ? "hidden" : ""}>
                            <NVLTextbox id="txtURL" labelText="URL" labelClassName="nvl-Def-Label pb-1" title="URL" className={"nvl-mandatory nvl-Def-Input"} errors={errors} register={register} />
                        </div>
                        <NVLlabel />
                        <DateTime
                            errors={errors}
                            register={register}
                            watch={watch}
                            setValue={setValue}
                        />
                        <div className="flex justify-center gap-1 pt-2" id="divButton">
                            <NVLButton
                                id="btnSave"
                                text={(!watch("submit") || watch("File") == "Uploading") ? "Submit" : ""}
                                type={"submit"}
                                className={`w-32 nvl-button bg-primary text-white ${(watch("File") == "Uploading" || watch("submit")) ? "pointer-events-none" : ""} 
                                ${watch("submit") ? "pointer-events-none" : ""}`}>
                                {watch("submit") && (<i className="fa fa-circle-notch fa-spin mr-2"></i>)}
                            </NVLButton>
                            <NVLButton
                                id="btnCancel"
                                text={mode == "Edit" ? "Cancel" : "Clear"}
                                type="button"
                                className={`nvl-button w-28 ${(watch("File") == "Uploading" || watch("submit")) ? "nvl-button-light pointer-events-none" : ""} 
                                ${watch("submit") ? "nvl-button-light pointer-events-none" : ""}`}
                                onClick={() => mode == "Edit" ? router.push("/SiteConfiguration/ManagePopUpList") : clearFields()}
                            ></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
            <div id="modepopup" className="hidden modalTop">
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
            </div>
        </>
    );
}

export default AddPopUp;