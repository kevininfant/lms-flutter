import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLToggle from "@components/Controls/NVLToggle";
import NVLMultilineTxtBox from "@Controls/NVLMultilineTxtBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCustomField, updateXlmsCustomField } from "src/graphql/mutations";
import { getXlmsCustomField, listXlmsCustomFieldsName, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

function CustomFieldSettings(props) {

    const router = useRouter();
    const [options, setOption] = useState([{ value: "", text: "Select" }]);
    const [customFieldType, setCustomFieldType] = useState("");
    const initialModalState = { ModalType: "Success", ModalTopMessage: "Success", ModalBottomMessage: "Details have been saved successfully.", ModalOnClickEvent: () => { router.push("/SiteConfiguration/CustomFieldList"); }, };

    const [modalValues, setModalValues] = useState(initialModalState);
    const [csrFetchedCustomFieldData, setFetchedData] = useState();
    const mode = useMemo(() => { return router.query["Mode"]; }, [router.query]);
    const tenantID = useMemo(() => {
        let TenantId;
        if (props.TenantInfo.UserGroup != "SiteAdmin") {
            TenantId = props.TenantInfo.TenantID;
        } else {
            TenantId = router.query["TenantID"];
        }
        return TenantId;
    }, [props.TenantInfo.TenantID, props.TenantInfo.UserGroup, router.query]);

    const urlSk = useMemo(() => { return router.query["SK"]; }, [router.query]);

    useEffect(() => {
        async function FetchCustomData() {
            const tenantResponse = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" }, props.user.signInUserSession.accessToken.jwtToken);
            const existingRecord = await AppsyncDBconnection(getXlmsCustomField, { PK: "TENANT#" + tenantID, SK: urlSk }, props.user.signInUserSession.accessToken.jwtToken);
            setFetchedData({
                TenantList: tenantResponse.res?.listXlmsTenantInfos.items != undefined ? tenantResponse.res?.listXlmsTenantInfos.items : [],
                ExistData: existingRecord.res?.getXlmsCustomField
            });
        }
        FetchCustomData();
        return (() => {
            setFetchedData((temp) => { return { ...temp }; });
        });
    }, [tenantID, urlSk, props.TenantInfo.TenantID, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, router.query, setValue]);

    const validationSchema = Yup.object().shape({

        ddlCompany:
            Yup.string().test("", "Please Add Options", (e, { createError }) => {
                if (e == "") {
                    return createError({ message: "Company is required" });
                }
                return true;
            }).nullable(),
        ddlCustomField: Yup.string()
            .required("Custom field is required").nullable()
            .test("", "", (e) => {

                customFieldHandler(e);
                setCustomFieldType(e);
                return true;
            }),
        txtProfileFieldName: Yup.string().required("Profile field name is required").matches(Regex("AllowAlphaNumWithSpace"), "Profile field name is invalid")
            .test("CheckName", "Profile field name already exists", async (e, { createError }) => {
                if (mode != "Edit") {
                    const finalData = await AppsyncDBconnection(listXlmsCustomFieldsName, {
                        PK: "TENANT#" + tenantID,
                        SK: "CUSTOMFIELD#",
                        ProfileFieldNameLower: e.toLowerCase()
                    }, props?.user?.signInUserSession?.accessToken?.jwtToken);

                    if (finalData?.res?.listXlmsCustomFieldsName?.items?.length == 1) {
                        return false;
                    }
                    if (e.length >= 40) {
                        return createError({ message: "Maximum 40 characters exceed" });
                    }
                    return true;

                }
                return true;

            }).nullable().max("250", "Maximum 250 characters exceed"),


        txtProfileFieldDescr: Yup.string().required("Profile field description  is required").nullable().max("500", " Maximum 500 characters exceed"),
        txtFieldOptions: customFieldType == "Checkbox" || customFieldType == "DropdownMenu" ?
            Yup.string().notRequired()
                .test("", "", (e) => {
                    if (e == "" || e == undefined) {
                        return true;
                    }
                    const rejax = new RegExp(/^(?!\s)(?!.*\s$)[\w\s()-]+$/);
                    if (!rejax.test(e)) {
                        setValue("Error", "Invalid Option");
                    }
                    else if (e.length > 30) {
                        setValue("Error", "Maximum 30 characters exceed");
                    }
                    else {
                        setValue("Error", "");
                    }
                    return true;
                }).nullable() : Yup.string().nullable(),
        ddlFieldVisibleStatus: Yup.string().required("Field visible is required").nullable(),
        customOption: customFieldType == "Checkbox" || customFieldType == "DropdownMenu"
            ? Yup.string()
                .test("", "Please Add Options", (e) => {
                    if (e == "Option") {

                        setValue("OptionError", "Options already exists");
                    }
                    else {
                        setValue("Error", "");
                    }
                    if (options.length > 1) {
                        return true;
                    }
                    setValue("Error", "");
                    return false;
                })
            : Yup.string().nullable(),

        txtminlength: customFieldType == "TextArea" || customFieldType == "TextInput" ?
            Yup.string().notRequired()
                .test("", "", (e, { createError }) => {
                    if (e == "" || e == undefined) {
                        return true;
                    }
                    const rejax = new RegExp(Regex("AllowOnlyNumbers"));
                    if (!rejax.test(e)) {
                        return createError({ message: "Minimum length is invalid" });
                    }
                    if (parseInt(e) <= 0){
                        return createError({ message: "Minimum length should be greater than Zero" });
                    }
                    if (e > parseInt(watch("txtmaxlength"))) {
                        return createError({ message: "Minimum length should be lesser than Maximum length" });
                    } 
                    else {
                        clearErrors(["txtmaxlength"])
                    }
                        return true;
                }).nullable().max("5", "Maximum 5 characters exceed") : Yup.string().nullable(),

        txtmaxlength: customFieldType == "TextArea" || customFieldType == "TextInput" ? Yup.string()
            .test("", "", (e, { createError }) => {
                if (e == "" || e == undefined) {
                    return true;
                }
                if (parseInt(e) <= 0){
                    return createError({ message: "Maximum length should be greater than Zero" });
                }
                const rejax = new RegExp(Regex("AllowOnlyNumbers"));
                    if (!rejax.test(e)) {
                        return createError({ message: "Maximum length is invalid" });
                    }
                if (e < parseInt(watch("txtminlength"))) {
                    return createError({ message: "Maximum length should be greater than Minimum length" });
                }
                 else {
                        clearErrors(["txtminlength"])
                }
                    return true;
            }).nullable().max("5", "Maximum 5 characters exceed") : Yup.string().nullable(),
        ddlFieldDefaultOptions: customFieldType == "Checkbox" || customFieldType == "DropdownMenu"
            ? Yup.string().nullable()
                .test("", "", (e, { createError }) => {

                    if (options.length <= 1) {
                        return createError({ message: " Minimum one option is required" })
                    }
                    else {
                        if (errors?.ddlFieldDefaultOptions != undefined) {
                            clearErrors(["ddlFieldDefaultOptions"]);
                        }
                        return true
                    }
                }) : Yup.string().nullable(),

        ddlDisplayPage: Yup.string().required("Display page is required").nullable(),
        ddlDateVisibility: customFieldType == "DateOrTime" ? Yup.string().required("Date visibility is required").nullable() : Yup.string().nullable()

    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, reset, watch, formState, setValue, clearErrors } = useForm(formOptions);
    const { errors } = formState;


    const selectCompany = useMemo(() => {

        const tempSelectCompany = [{ value: "", text: "Select Company" }];
        if (csrFetchedCustomFieldData?.TenantList?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin") {
            csrFetchedCustomFieldData?.TenantList?.map((getItem) => tempSelectCompany.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
        } else if (csrFetchedCustomFieldData?.TenantList?.length > 0 && props.TenantInfo.UserGroup != "") {
            const currentTenant = csrFetchedCustomFieldData?.TenantList?.filter(function (Tenant) {
                return Tenant.TenantID == tenantID;
            });
            currentTenant?.map((getItem) =>
                tempSelectCompany.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
            tempSelectCompany.shift();
        }
        return tempSelectCompany;
    }, [csrFetchedCustomFieldData?.TenantList, tenantID, props.TenantInfo.UserGroup]);

    const customFieldData = [
        { value: "", text: "Create New Custom Field" },
        { value: "Checkbox", text: "Check Box" },
        { value: "DateOrTime", text: "Date / Time" },
        { value: "DropdownMenu", text: "Dropdown Menu" },
        { value: "TextArea", text: "Text Area" },
        { value: "TextInput", text: "Text Input" },
    ];

    const visibiltyData = [
        { value: "", text: "Select Visibility Status" },
        { value: "Visible to User", text: "Visible to User" },
        { value: "Visible to All", text: "Visible to All" },
    ];
    const dateVisibility = [
        { value: "", text: "Select Date" },
        { value: "Past", text: "Past Date" },
        { value: "Present&Future", text: "Present & Future Date" },
    ];
    const userdata = [
        { value: "", text: "Select Display Page" },
        { value: "UserInfo", text: "User Info" },
        { value: "CompanyInfo", text: "Company Info" },
        { value: "CourseInfo", text: "Course Info" },
    ];

    const regexfield = [
        { value: "", text: "Choose Regex" },
        { value: "[A-Za-z]+", text: "Alphabets Only" },
        { value: "[0-9]+", text: "Allow Only Numbers" },
        { value: "[a-zA-Z0-9_ ]+", text: "Allow Alpha with space" },
        { value: "CustomRegex", text: "Regex" },
    ];

    const addItem = useCallback(() => {
        const optionData = watch("txtFieldOptions");
        optionData.trim();
        if (optionData != "") {
            const a = options.find((element) => element.value == optionData.toLowerCase());
            if (a?.value == undefined) {
                options.push({ value: optionData.toLowerCase(), text: optionData });
                setValue("txtFieldOptions", "");
                setValue("OptionError", "")
                setValue("customOption", "Okay", { shouldValidate: true });
            } else {
                setValue("txtFieldOptions", "");
                setValue("customOption", "Option", { shouldValidate: true });
            }
        }
    }, [options, setValue, watch]);

    useEffect(() => {
        if (csrFetchedCustomFieldData?.TenantList != undefined && tenantID != undefined) {
            setValue("ddlCompany", tenantID);
        }
        if (csrFetchedCustomFieldData?.ExistData != undefined) {
            if (csrFetchedCustomFieldData?.ExistData.CustomFieldType == "Checkbox" || csrFetchedCustomFieldData?.ExistData.CustomFieldType == "DropdownMenu") {
                document.getElementById("divOptionsControl").classList.remove("hidden");
            }
        }
        if (csrFetchedCustomFieldData?.ExistData != undefined) {
            const regex = ["[A-Za-z]+", "[0-9]+", "[a-zA-Z0-9_ ]+"];
            setValue("ddlCustomField", csrFetchedCustomFieldData?.ExistData?.CustomFieldType);
            setValue("txtProfileFieldName", csrFetchedCustomFieldData?.ExistData?.ProfileFieldName);
            setValue("txtCustomFieldID", csrFetchedCustomFieldData?.ExistData?.CustomFieldID);
            setValue("txtProfileFieldDescr", csrFetchedCustomFieldData?.ExistData?.ProfileFieldDescr);
            setValue("tgFieldRequired", csrFetchedCustomFieldData?.ExistData?.IsFieldRequired ? (document.getElementById("tgFieldRequired").checked = true) : "");
            setValue("tgFieldLock", csrFetchedCustomFieldData?.ExistData?.IsFieldLock ? (document.getElementById("tgFieldLock").checked = true) : "", { shouldValidate: true });
            setValue("tgFieldUniqueData", csrFetchedCustomFieldData?.ExistData?.IsFieldUniqueData ? (document.getElementById("tgFieldUniqueData").checked = true) : "", { shouldValidate: true });
            setValue("tgFieldDisplay", csrFetchedCustomFieldData?.ExistData?.IsFieldDisplay ? (document.getElementById("tgFieldDisplay").checked = true) : "", { shouldValidate: true });
            setValue("tgGroupAutomatic", csrFetchedCustomFieldData?.ExistData?.IsApplicableForGroup ? (document.getElementById("tgGroupAutomatic").checked = true) : "", { shouldValidate: true });
            setValue("tgFieldDisplayOnUser", csrFetchedCustomFieldData?.ExistData?.IsDisplayUserProfile ? (document.getElementById("tgFieldDisplayOnUser").checked = true) : "", { shouldValidate: true });
            setValue("ddlFieldVisibleStatus", csrFetchedCustomFieldData?.ExistData?.FieldVisibleStatus, { shouldValidate: true });
            setValue("ddlDateVisibility", csrFetchedCustomFieldData?.ExistData?.CustomRegex, { shouldValidate: true });
            setValue("ddlDisplayPage", csrFetchedCustomFieldData?.ExistData?.DisplayPage);
            setValue("txtminlength", csrFetchedCustomFieldData?.ExistData?.MinimumLength, { shouldValidate: true });
            setValue("txtmaxlength", csrFetchedCustomFieldData?.ExistData?.MaximumLength, { shouldValidate: true });
            if (regex.includes(csrFetchedCustomFieldData?.ExistData?.Regex)) {
                setValue("ddlRegex", csrFetchedCustomFieldData?.ExistData?.Regex, { shouldValidate: true });
            }
            else {
                setValue("ddlRegex", csrFetchedCustomFieldData?.ExistData?.Regex, { shouldValidate: true });
                setValue("txtRegex", csrFetchedCustomFieldData?.ExistData?.Regex, { shouldValidate: true });
            }
            if (csrFetchedCustomFieldData?.ExistData?.FieldOptions != null) {
                setOption(JSON.parse(csrFetchedCustomFieldData?.ExistData.FieldOptions));
            }
            else {
                setValue("ddlFieldVisibleStatus", csrFetchedCustomFieldData?.ExistData?.FieldVisibleStatus);
                setValue("ddlDateVisibility", csrFetchedCustomFieldData?.ExistData?.CustomRegex);
            }
        }
    }, [csrFetchedCustomFieldData?.ExistData, setValue, tenantID, router.query, csrFetchedCustomFieldData?.TenantList]);

    useEffect(() => {


        const customField = document.getElementById("ddlCustomField");
        if (customField) {
            customField.addEventListener("change", function () {
                reset({ txtProfileFieldName: "", txtProfileFieldDescr: "", ddlFieldVisibleStatus: "" });
                document.getElementById("tgFieldRequired", "").checked = false;
                document.getElementById("tgFieldLock", "").checked = false;
                document.getElementById("tgFieldUniqueData", "").checked = false;
                document.getElementById("tgFieldDisplay", "").checked = false;
                document.getElementById("tgGroupAutomatic", "").checked = false;
                document.getElementById("tgGroupAutomatic", "").checked = false;
                document.getElementById("tgFieldDisplayOnUser", "").checked = false;
                setOption([{ value: "", text: "Select" }]);
                return;
            });
        }
        const a = options.filter((obj) => {
            return obj.value == csrFetchedCustomFieldData?.ExistData?.FieldDefaultOptions;
        });
        if (a.length == 1) {
            setValue("ddlFieldDefaultOptions", a[0].value);
        }
    }, [options, setValue, csrFetchedCustomFieldData?.ExistData?.FieldDefaultOptions, reset]);

    const customFieldHandler = useCallback((e) => {
        const optionField = ["Checkbox", "DropdownMenu", "Radio"];
        const textInput = ["TextArea", "TextInput"];
        if (textInput.includes(e)) {
            document.getElementById("divRegexControl")?.classList.remove("hidden");
        } else {
            document.getElementById("divRegexControl")?.classList.add("hidden");
        }
        if (optionField.includes(e)) {
            document.getElementById("divOptionsControl")?.classList.remove("hidden");
        } else {
            document.getElementById("divOptionsControl")?.classList.add("hidden");
        }
        if (e != 0) {
            document.getElementById("divCustomFields")?.classList.remove("hidden");
        } else {
            document.getElementById("divCustomFields")?.classList.add("hidden");
        }
    }, []);
    function clearForm() {
        reset({ ddlCustomField: "", txtProfileFieldName: "", txtProfileFieldDescr: "", ddlFieldVisibleStatus: "", txtminlength: "", txtmaxlength: "", ddlDisplayPage: "", ddlRegex: "", txtRegex: "", txtFieldOptions: "", ddlDateVisibility: "" });
        document.getElementById("divCustomFields")?.classList.add("hidden");
        setOption([{ value: "", text: "Select" }]);
    }

    const removeItem = useCallback(() => {
        const sb = watch("ddlFieldDefaultOptions");
        if (sb != "") {
            setOption((options) =>
                options.filter((obj) => {

                    return obj.value !== sb;
                })
            );
        }
    }, [watch]);

    const finalResponse = (FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        }
        ModalOpen();

    };
    const submithandler = useCallback(async (data) => {

        setValue("submit", true);
        const tenantName = tenantID;
        const customControlName = data.ddlCustomField == "Checkbox" ? "CHK" : data.ddlCustomField == "DropdownMenu" ? "DDL" : data.ddlCustomField == "TextInput" ? "TXT" : data.ddlCustomField == "DateOrTime" ? "DT" : data.ddlCustomField == "TextArea" ? "TA" : "";
        let CustomFieldID = (customControlName + data.txtProfileFieldName.trim() + Math.random().toString(9).substring(2, 5)).replace(/ /g, "");
        CustomFieldID = csrFetchedCustomFieldData?.ExistData != null ? csrFetchedCustomFieldData?.ExistData.CustomFieldID : CustomFieldID;
        const defaultFieldOption = (customControlName == "CHK" || customControlName == "DDL") ? data.ddlFieldDefaultOptions : "";
        let SK = "CUSTOMFIELD#" + data.ddlCustomField + "#FIELDID#" + CustomFieldID;
        SK = csrFetchedCustomFieldData?.ExistData != null ? urlSk : SK;
        const query = csrFetchedCustomFieldData?.ExistData != null ? updateXlmsCustomField : createXlmsCustomField; const variables = {
            input: {
                PK: "TENANT#" + tenantID,
                SK: SK,
                TenantName: tenantName,
                TenantID: tenantID,
                CustomFieldType: data.ddlCustomField,
                CustomFieldID: CustomFieldID,
                CustomRegex: data.ddlDateVisibility,
                ProfileFieldName: data.txtProfileFieldName.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                ProfileFieldNameLower: data.txtProfileFieldName.replace(/\s{2,}(?!\s)/g, ' ').trim().toLowerCase(),
                ProfileFieldDescr: data.txtProfileFieldDescr.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                IsFieldRequired: document.getElementById("tgFieldRequired").checked,
                IsFieldLock: document.getElementById("tgFieldLock").checked,
                IsFieldUniqueData: document.getElementById("tgFieldUniqueData").checked,
                IsFieldDisplay: document.getElementById("tgFieldDisplay").checked,
                IsApplicableForGroup: document.getElementById("tgGroupAutomatic").checked,
                IsDisplayUserProfile: document.getElementById("tgFieldDisplayOnUser").checked,
                FieldVisibleStatus: data.ddlFieldVisibleStatus,
                DisplayPage: data.ddlDisplayPage,
                FieldOptions: JSON.stringify(options),
                FieldDefaultOptions: defaultFieldOption,
                FieldDateTime: data.ddlCustomField == "DateOrTime" ? "" : "",
                CreatedBy: csrFetchedCustomFieldData?.ExistData == null ? props.user.username : csrFetchedCustomFieldData?.ExistData?.CreatedBy,
                CreatedDate: csrFetchedCustomFieldData?.ExistData == null ? new Date() : csrFetchedCustomFieldData?.ExistData?.CreatedDate,
                LastModifiedBy: csrFetchedCustomFieldData?.ExistData != null ? props.user.username : csrFetchedCustomFieldData?.ExistData?.LastModifiedBy,
                LastModifiedDate: new Date(),
                MinimumLength: data.txtminlength,
                MaximumLength: data.txtmaxlength,
                Regex: data.ddlCustomField == "TextArea" || data.ddlCustomField == "TextInput" ? (data.ddlRegex != "CustomRegex" ? data.ddlRegex : data.txtRegex) : "",
            },
        };

        const finalResult = await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
        finalResponse(finalResult.Status);
        setValue("submit", false);
    }, [setValue, tenantID, csrFetchedCustomFieldData?.ExistData, props.user.username, props.user.signInUserSession.accessToken.jwtToken, urlSk, options]);

    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "/SiteConfiguration/CustomFieldList", breadcrumb: "Custom Field Settings " },
            { path: "", breadcrumb: csrFetchedCustomFieldData?.ExistData != null ? "Edit Custom Field Settings" : "Add Custom Field" }
        ];


    }, [csrFetchedCustomFieldData?.ExistData])
    return (
        <>
            <NVLHeader RedirectHome={"/SiteConfiguration/CustomFieldList"} />
            <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalType} />
            <Container title="CustomField" loader={csrFetchedCustomFieldData?.TenantList == undefined} PageRoutes={pageRoutes}>
                <form onSubmit={handleSubmit(submithandler)} id="customFieldForm" className={`${watch("submit") ? "pointer-events-none" : "px-2"}`}>
                    <div className="nvl-FormContent">
                        <NVLSelectField labelText="Company Name"
                            labelClassName="nvl-Def-Label"
                            id="ddlCompany"
                            errors={errors}
                            register={register}
                            className={csrFetchedCustomFieldData?.ExistData != null || (csrFetchedCustomFieldData?.ExistData == null || props.TenantInfo.UserGroup != "SiteAdmin") ? "nvl-Def-Input Disabled" : "nvl-Def-Input nvl-mandatory"}
                            options={selectCompany}
                            disabled={csrFetchedCustomFieldData?.ExistData != null || (csrFetchedCustomFieldData?.ExistData == null || props.TenantInfo.UserGroup != "SiteAdmin") ? true : false}
                        ></NVLSelectField>
                        <NVLSelectField labelText="Custom Field" labelClassName="nvl-Def-Label" id="ddlCustomField" disabled={csrFetchedCustomFieldData?.ExistData != null ? true : false} errors={errors} register={register} className={csrFetchedCustomFieldData?.ExistData != null ? "nvl-Def-Input Disabled" : "nvl-Def-Input nvl-mandatory"} options={customFieldData}></NVLSelectField>
                        <div className={csrFetchedCustomFieldData?.ExistData == null ? "hidden" : ""} id="divCustomFields">

                            <NVLTextbox labelText="Profile Field Name" labelClassName="nvl-Def-Label" id="txtProfileFieldName" disabled={csrFetchedCustomFieldData?.ExistData != null ? true : false} errors={errors} register={register} className={csrFetchedCustomFieldData?.ExistData != null ? "nvl-Def-Input Disabled" : "nvl-Def-Input nvl-mandatory"} type={"text"} required={true} title="Profile Field Name"></NVLTextbox>
                            <NVLlabel text=" Custom Field ID" className="nvl-Def-Label"></NVLlabel>
                            <NVLTextbox id="txtCustomFieldID" errors={errors} disabled={true} className="Disabled nvl-Def-Input" title="Custom Field ID" register={register}></NVLTextbox>
                            <NVLMultilineTxtBox labelText="Profile Field Description" labelClassName="nvl-Def-Label" id="txtProfileFieldDescr" errors={errors} register={register} className={"nvl-Def-Input nvl-mandatory"} title="Profile Field Description" pattern="[a-zA-Z]*"></NVLMultilineTxtBox>
                            <div className="pt-4">
                                <NVLlabel text="If the Field Required" className="nvl-Def-Label"></NVLlabel>
                            </div>
                            <div className="flex flex-gap-2 pt-2">
                                <NVLToggle id="tgFieldRequired" errors={errors} register={register} />
                            </div>
                            <div className="pt-2">
                                <NVLlabel text="If the Field Lock" className="nvl-Def-Label"></NVLlabel>
                            </div>
                            <div className="flex flex-gap-2 pt-2 space-x-10">
                                <NVLToggle id="tgFieldLock" errors={errors} register={register} />
                            </div>
                            <div className="pt-2">
                                <NVLlabel text="Should the Field unique data" className="nvl-Def-Label"></NVLlabel>
                            </div>
                            <div className="flex flex-gap-2 pt-2 space-x-10">
                                <NVLToggle id="tgFieldUniqueData" errors={errors} register={register} />
                            </div>
                            <div className="pt-2">
                                <NVLlabel text="Display on Register Page" className="nvl-Def-Label"></NVLlabel>
                            </div>

                            <div className="flex flex-gap-2 pt-2 space-x-10">
                                <NVLToggle id="tgFieldDisplay" errors={errors} register={register} />
                            </div>
                            <div className={`${watch("ddlCustomField") == "DropdownMenu" ? "" : "hidden"}`}>
                                <div className="pt-2">
                                    <NVLlabel text="Is Applicable for Automatic Group" className="nvl-Def-Label"></NVLlabel>
                                </div>

                                <div className="flex flex-gap-2 pt-2 space-x-10">
                                    <NVLToggle id="tgGroupAutomatic" errors={errors} register={register} />
                                </div>
                            </div>
                            <div className="pt-2">
                                <NVLlabel text="Display on User Profile" className="nvl-Def-Label" HelpInfo={"If enabled this field will be displayed in user profile"}
                                    HelpInfoIcon="fa fa-solid fa-circle-question"></NVLlabel>
                            </div>
                            <div className="flex flex-gap-2 pt-2 space-x-10">
                                <NVLToggle id="tgFieldDisplayOnUser" errors={errors} register={register} />
                            </div>
                            <div className="Center-Aligned-Items pt-4">
                                <NVLSelectField labelText="Display Page" labelClassName="nvl-Def-Label" id="ddlDisplayPage" errors={errors} register={register} options={userdata} className={"nvl-Def-Input nvl-mandatory"}></NVLSelectField>
                            </div>
                            <div className="Center-Aligned-Items pt-4">
                                <NVLSelectField labelText="Field Visible Status" labelClassName="nvl-Def-Label" id="ddlFieldVisibleStatus" errors={errors} register={register} options={visibiltyData} className={"nvl-Def-Input nvl-mandatory"}></NVLSelectField>
                            </div>
                            <div className={`${watch("ddlCustomField") == "DateOrTime" ? "" : "hidden"}`}>
                                <div className="pt-2">
                                    <NVLSelectField labelText="Date Visibility" labelClassName="nvl-Def-Label" id="ddlDateVisibility" errors={errors} register={register} options={dateVisibility} className={"nvl-Def-Input nvl-mandatory"}></NVLSelectField>
                                </div>
                            </div>
                            <div>
                                <div id="divRegexControl" className="hidden">
                                    <NVLTextbox labelText="Minimum Length" labelClassName="nvl-Def-Label" className={" nvl-non-mandatory nvl-Def-Input"} id="txtminlength" errors={errors} title="Minimum Length" register={register}></NVLTextbox>
                                    <NVLTextbox labelText="Maximum Length" labelClassName="nvl-Def-Label" className={" nvl-non-mandatory nvl-Def-Input"} id="txtmaxlength" errors={errors} title="Maximum Length" register={register}></NVLTextbox>
                                    <NVLSelectField labelText="Choose Regex" labelClassName="nvl-Def-Label" id="ddlRegex" errors={errors} register={register}
                                        options={regexfield} className={"nvl-Def-Input nvl-non-mandatory"}></NVLSelectField>
                                    <div id="divRegex" className={`${watch("ddlRegex") == "CustomRegex" ? "" : "hidden"}`}>
                                        <NVLTextbox labelText="Custom Regex" labelClassName="nvl-Def-Label" className={" nvl-non-mandatory nvl-Def-Input"} id="txtRegex" errors={errors} title="Custom Regex" register={register}></NVLTextbox>
                                    </div>
                                </div>
                            </div>

                            <div className="pt-4">
                                <div className="hidden" id="divOptionsControl">
                                    <NVLTextbox labelText="Add options" labelClassName="nvl-Def-Label" id="txtFieldOptions" title="Options" className={" nvl-non-mandatory nvl-Def-Input"} errors={errors} register={register} />
                                    <div className="text-right">
                                        <div className={" {invalid-feedback} text-red-500 text-sm "}>{errors?.FieldOptions?.message}</div>
                                        <NVLButton id="btnAddItem" disabled={watch("Error") != "" && watch("Error") != undefined ? true : false} type="button" ButtonType={"link"} text="+Add Item" onClick={() => addItem()} />
                                    </div>
                                    {watch("Error") != "" && watch("Error") != undefined && <div className="{invalid-feedback}   text-red-500 text-sm ">{watch("Error")}</div>}
                                    <NVLSelectField
                                        labelText="Default Options" labelClassName="nvl-Def-Label"
                                        id="ddlFieldDefaultOptions" className={"nvl-Def-Input nvl-mandatory"} options={options} errors={errors} register={register}></NVLSelectField>

                                    <div className="text-right">
                                        <NVLButton id="btnRemoveItem" className={`${watch("ddlFieldDefaultOptions") == "" ? "!text-gray-600 " : ""}`} type="button" ButtonType={"link"} text="+Remove Item" disabled={watch("ddlFieldDefaultOptions") == "" ? true : false} onClick={() => removeItem()} />
                                    </div>
                                    {watch("OptionError") != "" && watch("OptionError") != undefined && errors?.ddlFieldDefaultOptions == undefined && <div className="{invalid-feedback}   text-red-500 text-sm ">{watch("OptionError")}</div>}


                                </div>
                            </div>
                            <div className="flex flex-row gap-1 justify-center nvl-Def-Input mt-4">
                                <NVLButton id="btnSubmit" text={!watch("submit") ? (csrFetchedCustomFieldData?.ExistData == null ? "Submit" : "Save Changes") : ""} type="submit" disabled={watch("submit") ? true : false} className={watch("submit") ? csrFetchedCustomFieldData?.ExistData != null ? "w-32 nvl-button bg-primary text-white " : "w-28 nvl-button  bg-primary text-white " : "w-28 nvl-button  bg-primary text-white"}> {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
                                <NVLButton id="btnCancel" text={csrFetchedCustomFieldData?.ExistData == null ? "Clear" : "Cancel"} type="button" className="nvl-button w-28" onClick={() => (csrFetchedCustomFieldData?.ExistData == null ? clearForm() : router.push("/SiteConfiguration/CustomFieldList"))}></NVLButton>
                            </div>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CustomFieldSettings;
