import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLTextbox from "@components/Controls/NVLTextBox";

export default function CertificateInfo(props) {
    return (
        <section className="text-gray-600 body-font flex gap-8 text-xs font-semibold shadow-xl py-4 bg-gray-200 rounded-md">
            <div className="nvl-FormContent">
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="Template Name" id="txtTempName" placeholder={"Template Name"} className="nvl-mandatory nvl-Def-Input" register={props.register} errors={props.errors} />
                <NVLMultilineTxtbox labelClassName="nvl-Def-Label" labelText="Template Description" id="txtTempDesc" placeholder="Group Description" className="nvl-non-mandatory  nvl-Def-Input" register={props.register} errors={props.errors} />
                <NVLlabel text="Width" HelpInfo={`Width should be given above ${props?.watch("txtTempWidth")}mm`} HelpInfoIcon="fa fa-solid fa-circle-question" className="nvl-Def-Label" />       
                <NVLTextbox id="txtTempWidth" placeholder={"Width"} className="nvl-non-mandatory nvl-Def-Input" register={props.register} errors={props.errors} />
                <NVLlabel text="Height" HelpInfo={`Height should be given above ${props?.watch("txtTempHeight")}mm`} HelpInfoIcon="fa fa-solid fa-circle-question" className="nvl-Def-Label" />       
                <NVLTextbox id="txtTempHeight" placeholder={"Height"} className="nvl-non-mandatory nvl-Def-Input" register={props.register} errors={props.errors} />
                <NVLlabel text="Right Margin" HelpInfo={`Right Margin should be given above ${props?.watch("txtRightMargin")}mm`} HelpInfoIcon="fa fa-solid fa-circle-question" className="nvl-Def-Label" />       
                <NVLTextbox id="txtRightMargin" placeholder={"Right Margin"} className="nvl-non-mandatory nvl-Def-Input" register={props.register} errors={props.errors} />
                <NVLlabel text="Left Margin" HelpInfo={`Left Margin should be given above ${props?.watch("txtLeftMargin")}mm`} HelpInfoIcon="fa fa-solid fa-circle-question" className="nvl-Def-Label" />       
                <NVLTextbox id="txtLeftMargin" placeholder={"Left Margin"} className="nvl-non-mandatory nvl-Def-Input" register={props.register} errors={props.errors} />
                <div className={`${props.mode == "Edit" ? "hidden" : ""}`}>
                    <NVLlabel className="nvl-Def-Label" text="Template Viewport"></NVLlabel>
                    <div className={"flex gap-10 "}>
                        <NVLRadio  text="Landscape" id="rbTemplateType" name="rbTemplateType" value={"Landscape"} errors={props.errors} register={props.register} ></NVLRadio>
                        <NVLRadio  text="Potrait" id="rbTemplateType" name="rbTemplateType" value={"Potrait"} errors={props.errors} register={props.register} ></NVLRadio>
                    </div>
                </div>
            </div>
        </section>
    );
}
