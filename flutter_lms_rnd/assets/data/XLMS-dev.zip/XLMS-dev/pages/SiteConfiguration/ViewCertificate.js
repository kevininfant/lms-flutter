import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import * as htmlToImage from 'html-to-image';
import { useRouter } from "next/router";
import 'quill/dist/quill.bubble.css';
import 'quill/dist/quill.snow.css';
import { useEffect, useMemo, useRef, useState } from "react";
import { getXlmsCustomCertificate, getXlmsTenantInfo } from "src/graphql/queries";


function ViewCertificate(props) {
  const router = useRouter();
  const [fetchdata, setFetchdata] = useState()
  const [fetchingViewCert, setfetchingViewCert] = useState(true)
  const tess = useRef();
  useEffect(() => {
    async function FetchData() {
      let TenantID = router.query["TenantID"]
      let TemplateID = router.query["TemplateID"];

      const tenantResponse = await AppsyncDBconnection(getXlmsCustomCertificate, {
        PK: "TENANT#" + TenantID,
        SK: "CUSTOMCERTIFICATE#" + TemplateID,
      }, props.user.signInUserSession.accessToken.jwtToken);
      const tenantInfo = await AppsyncDBconnection(getXlmsTenantInfo, {
        PK: "XLMS#TENANTINFO",
        SK: "#" + "TENANT#" + TenantID,
      }, props.user.signInUserSession.accessToken.jwtToken);
      setFetchdata({
        TenantId: TenantID,
        EditData: tenantResponse.res.getXlmsCustomCertificate != undefined ? tenantResponse.res.getXlmsCustomCertificate : [],
        CurrentTenantInfo: tenantInfo.res.getXlmsTenantInfo != undefined ? tenantInfo.res.getXlmsTenantInfo : [],
        FinalCert: ""
      })
    }

    FetchData()
    return (() => {
      setFetchdata((temp) => { return { ...temp } })
    })
  }, [props.user.signInUserSession.accessToken.jwtToken, router.query])
  useEffect(() => {
    async function temp() {
      let GetCertificate = await fetch(process.env.APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE + "?ObjectUrl=" + fetchdata?.EditData?.TemplateUrlPath + "&S3BucketName=" + fetchdata?.CurrentTenantInfo?.BucketName +
        "&S3KeyName=" + fetchdata?.CurrentTenantInfo?.RootFolder + "/" +
        fetchdata?.CurrentTenantInfo?.TenantID,
        {
          method: "GET",
          headers: {
            "Content-Type": "application/text",
            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
            defaultrole: props.user.signInUserSession.accessToken.payload["cognito:groups"][0],
            menuid: "601302",
            groupmenuname: "SiteConfiguration"
          },
        }
      );
      let Certificate = await GetCertificate.text();
      Certificate = Certificate.replaceAll('class="panel rounded-md"', 'class="panel"');
      Certificate = Certificate.replaceAll('<div class="top-left"></div><div class="top"></div><div class="top-right"></div><div class="right"></div><div class="right-bottom"></div><div class="bottom"></div><div class="bottom-left"></div><div class="left"></div>', "");
      Certificate = Certificate.replaceAll('class="focus:outline-none rounded border-yellow-600 cursor-pointer"', 'class="rounded"');
      Certificate = Certificate.replaceAll('<i class="fa fa-solid close-icon-pattern fa-minus text-red-600 h-6 w-6 grid place-content-center cursor-pointer rounded-full bg-red-100"></i>', "");
      Certificate = Certificate.replaceAll('${UserName}', "Asaithambi");
      if (tess.current != undefined)
        tess.current.innerHTML = Certificate;
      setfetchingViewCert(false)
    }

    temp();
  }, [fetchdata?.CurrentTenantInfo?.RootFolder, fetchdata?.CurrentTenantInfo?.TenantID, fetchdata?.CurrentTenantInfo?.BucketName, fetchdata?.EditData?.TemplateUrlPath, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload])
  const downloadImage = async () => {
    const dataUrl = await htmlToImage.toPng(tess.current);
    const link = document.createElement('a');
    link.download = "certificate.png";
    link.href = dataUrl;
    link.click();
    link.remove();
  }
  const PageRoutes = useMemo(() => {
    return [
      { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
      { path: "/SiteConfiguration/CustomCertificateList", breadcrumb: "Custom Certificate List" },
      { path: "", breadcrumb: "View Certificate" }
    ];
  }, []);
  return (
    <>
      <Container PageRoutes={PageRoutes} loader={fetchingViewCert}>
        <section className="text-gray-600 body-font text-xs font-semibold shadow-xl rounded-md grid place-content-center ">
         <div className={` justify-center relative sm:flex-row sm:items-center items-start mx-auto overflow-auto max-w-screen-2xl`}>
         
          <div 
          style={{width:fetchdata?.EditData?.TemplateWidth+"mm",height:fetchdata?.EditData?.TemplateHeight+"mm",
          marginLeft:fetchdata?.EditData?.TemplateLeftMargin+"mm",marginRight:fetchdata?.EditData?.TemplateRightMargin+"mm"}}
           ref={tess}></div>

</div>
          <div id="Hello" />
          <div className=" mx-auto flex justify-center p-2 gap-4">
            <NVLButton text="Back" type={"success"} className="nvl-button bg-primary text-white w-32 h-10 " onClick={() => router.push("/SiteConfiguration/CustomCertificateList")} />
            <NVLButton text="Print" type={"success"} className="nvl-button bg-primary text-white w-32 h-10 " onClick={downloadImage} />
          </div>
        </section>
      </Container>
    </>
  );
}

export default ViewCertificate;