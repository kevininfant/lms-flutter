import Container from '@components/Container/Container';
import NVLBreadCrumbs from '@components/Controls/NVLBreadCrumbs';
import NVLGridTable from '@components/Controls/NVLGridTable';
import NVLHeader from '@components/Controls/NVLHeader';
import NVLModalPopup from '@components/Controls/NVLModalPopup';
import NVLRapidModal from '@components/Controls/NVLRapidModal';
import NVLlabel from '@components/Controls/NVLlabel';
import { createXlmsBatchLoginScreenInfo } from '@graphql/graphql/mutations';
import { listXlmsLoginScreenInfos } from '@graphql/graphql/queries';
import { AppsyncDBconnection } from 'DBConnection/ErrorResponse';
import { useRouter } from 'next/router';
import { useCallback, useMemo, useState } from 'react';

function CustomLoginList(props) {
    const router = useRouter();
    const [popupValues, setPopupValues] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(0);
    const [search, setSearch] = useState("");

    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };

    const searchBoxVal = (e) => {
        setSearch(e); setIsRefreshing((count) => {
            return count + 1;
        });
    };

    const refreshGrid = useCallback(() => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    }, []);

    function resetPopUp() {
        setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    }

    function popUp(type, PK, SK, Content) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
    }
    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData.map((getItem, index) => {
            !getItem.IsDeleted
                ? rowGrid.push({
                    TenantName: (<NVLlabel id={"txtCompanyName" + (index + 1)} text={getItem.TenantName} title={getItem.TenantName} className="py-2"></NVLlabel>),
                    CompanyCode: (<NVLlabel id={"txtCompanyCode" + (index + 1)} text={getItem.CompanyCode} title={getItem.CompanyCode} className="py-2"></NVLlabel>),
                    DomainName: (<NVLlabel id={"txtDomain" + (index + 1)} text={getItem.DomainName} className=""></NVLlabel>),
                    WebClientID: (<NVLlabel id={"txtWebClientid" + (index + 1)} text={getItem.WebClientID} className=""></NVLlabel>),
                    QueryString: (<NVLlabel id={"txtQuerystring" + (index + 1)} text={getItem.QueryString.split("?")[1]} className=""></NVLlabel>),
                    QueryStringValue: (<NVLlabel id={"txtQueryvalue" + (index + 1)} text={getItem.QueryString.split("?")[0]} className=""></NVLlabel>),
                    Action: (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal>),
                })
                : "";
        });
        return rowGrid;
    }, [actionRestriction]);

    async function updateField(e) {
        e.preventDefault();
        let isDelete = false;
        if (popupValues.Type == "isDelete") {
            isDelete = true;
            const variables = { input: { PK: popupValues.PK, SK: popupValues.SK, IsDeleted: isDelete }, };
            const query = createXlmsBatchLoginScreenInfo;
            const finalStatus = await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
            if (finalStatus.Status == "Success") {
                resetPopUp();
                refreshGrid();
                return;
            }
        }
    }

    const headerColumn = [
        { HeaderName: "Company Name", Columnvalue: "TenantName", HeaderCss: "w-2/12 ", },
        { HeaderName: "Company Code", Columnvalue: "CompanyCode", HeaderCss: "w-2/12 ", },
        { HeaderName: "Domain Name", Columnvalue: "DomainName", HeaderCss: "w-3/12 ", },
        { HeaderName: "Query String", Columnvalue: "QueryString", HeaderCss: "w-2/12 ", },
        { HeaderName: "Query String Value", Columnvalue: "QueryStringValue", HeaderCss: "w-2/12 whitespace-nowrap ", },
        { HeaderName: "Web ClientID", Columnvalue: "WebClientID", HeaderCss: "w-2/12 " },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12 " },
    ];

    //List of ActionList Against Company
    const actionRestriction = useCallback((getItem) => {
        const actionList = [];
        // if (true) {
        actionList.push(
            {
                id: 2,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit",
                action: () =>
                    router.push(
                        `/SiteConfiguration/CustomLogin?DomainName=${getItem.DomainName}&QueryString=${getItem.QueryString}`
                    ),
            });
        //}
        //if (true) {
        actionList.push(
            {
                id: 4,
                className: "hidden",
                Color: "text-rose-700",
                Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                name: "Delete Company",
                action: () =>
                    popUp(
                        "isDelete",
                        getItem.PK,
                        getItem.SK,
                        "Are you sure to delete the organisation?"
                    ),
            });
        //}
        return actionList;
    }, [router]);

    const cancelEvent = useCallback((e) => {
        e.preventDefault();
        resetPopUp();
    }, []);


    //Breadcrumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Custom Login Management" }
        ];
    }, []);

    return (
        <>
            <Container title={"Custom Login Management"}>
                <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
                <NVLHeader
                    // TabRouting={props?.GeneralRoleData?.AllowNewTab}
                    href3="/SiteConfiguration/SiteConfigSettings/CustomLogin"
                    //  IsSearch={props.RoleData?.SeTenanthCompany ? true : false}
                    IsSearch={true}
                    //  className3={props.RoleData?.CreateCompany ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"}
                    LinkName3="+ Add Custom Login" RedirectAction3={(e) => headerHandler(e, "/SiteConfiguration/CustomLogin")}
                    RedirectAction2={() => refreshGrid()}
                    onClick1={refreshGrid} placeholder={"Search by Company Name"}
                    SearchonChange={(e) => searchBoxVal(e)}
                    Search={search}
                    IsNestedHeader={true}
                />
                <div className="max-w-full w-full justify-center">
                    <NVLGridTable
                        user={props.user}
                        refershPage={isRefreshing}
                        id="tblCustomLoginList"
                        Search={search}
                        HeaderColumn={headerColumn}
                        GridDataBind={gridDataBind} query={listXlmsLoginScreenInfos}
                        querryName={"listXlmsLoginScreenInfos"} variable={{ PK: "XLMS#LOGINSCREENINFO", SK: "LOGIN#", IsDeleted: false }}
                    />
                </div>
                <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
            </Container>
        </>
    )
}

export default CustomLoginList