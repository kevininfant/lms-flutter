import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCustomFields, listXlmsUserGroupInfos } from "src/graphql/queries";
import * as Yup from "yup";
function AddOptionOnBoard({ id, TenantInfo, user, data, setSubmit, json, setData }) {
    const [options, setOptions] = useState({});
    const previousVal = useRef({});
    const customRegex = useRef({})
    const [optionslength, setOptionlength] = useState(() => {
        if (json?.for?.length > 0) {
            return json?.for.length;
        }
        return 1;
    });

    let dynamicYupfields = {
        ["operator"]: Yup.string().when(("0type" + id), {
            is: "" || undefined || '',
            otherwise: Yup.string().required("The Field is Requried")
        }),
    };

    for (let i = 0; i < optionslength; i++) {
        dynamicYupfields = {
            ...dynamicYupfields,
            [i + "type" + id]: Yup.string()
                .test("", "", async (e) => {
                    if (e == previousVal.current?.[i]?.["type"]) {
                        return true;
                    }
                    else {
                        if (e == "userGroup") {
                            const groupResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + TenantInfo.TenantID, SK: "GROUPINFO#", }, user.signInUserSession.accessToken.jwtToken);
                            previousVal.current = { ...previousVal.current, [i]: { ...previousVal.current?.["1"], type: e } };
                            setOptions((data) => {
                                let value = [{ value: "", text: "Select Group" }];
                                if (groupResponse.res?.listXlmsUserGroupInfos?.items?.length > 0)
                                    groupResponse.res.listXlmsUserGroupInfos.items.map(item => {
                                        value = [...value, { value: item.GroupID, text: item.GroupName }];
                                    });
                                customRegex.current = { ...customRegex.current, [i]: {} }
                                return { ...data, [i]: { value: value, options: {} } };
                            });
                        }
                        else if (e != "") {
                            const customFieldResponse = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + TenantInfo.TenantID, SK: "CUSTOMFIELD#", }, user.signInUserSession.accessToken.jwtToken);
                            setOptions((data) => {
                                let value = [{ value: "", text: "Select ProfileField" }];
                                let optionsTemp = {}, regexValue = {};
                                if (customFieldResponse.res?.listXlmsCustomFields?.items?.length > 0)
                                    customFieldResponse.res.listXlmsCustomFields.items.map(item => {
                                        value = [...value, { value: item.ProfileFieldName, text: item.ProfileFieldName }];
                                        optionsTemp = { ...optionsTemp, [item.ProfileFieldName]: JSON.parse(item.FieldOptions) };
                                        regexValue = { ...regexValue, [item.ProfileFieldName]: { Max: item?.MaximumLength, Min: item?.MinimumLength, Regex: item?.Regex } }
                                    });
                                customRegex.current = { ...customRegex.current, [i]: regexValue }
                                return { ...data, [i]: { value: value, options: optionsTemp } };
                            });
                            previousVal.current = { ...previousVal.current, [i]: { ...previousVal.current?.[i], type: e } };
                        }
                        else {
                            setValue(i + "field" + id, "");
                        }
                        setValue(i + "value" + id, "");
                        setValue(i + "operator" + id, "");
                        return true;
                    }
                }).nullable(true),
            [i + "field" + id]: Yup.string().nullable(true).when([i + "type" + id], {
                is: "" || undefined || '',
                then: Yup.string().nullable(true),
                otherwise: Yup.string().required("Field is Requried").test("novalid", "novalie", e => {
                    if (previousVal.current?.[i]?.field != e) {
                        setValue(i + "value" + id, "");
                        previousVal.current = { ...previousVal.current, [i]: { ...previousVal.current?.[i], field: e } };
                    }
                    return true;
                })
            }),
            [i + "value" + id]: Yup.string().typeError().when([i + "type" + id], {
                is: "profileField",
                then: Yup.string().typeError().required("Field is Requried").test("Valid", "Invalid Value", (e, { createError }) => {
                    if (watch(i + "field" + id) == undefined || watch(i + "field" + id) == "") {
                        return true;
                    }
                    if (customRegex.current?.[id]?.[watch(i + "field" + id)] != undefined) {
                        let temp = customRegex.current?.[id]?.[watch(i + "field" + id)];
                        if (temp?.Min != undefined && e?.length < parseInt(temp?.Min)) {
                            return createError({ message: "The Minimun Length Must Be " + temp?.Min });
                        }
                        if (temp?.Max != undefined && e?.length > parseInt(temp?.Max)) {
                            return createError({ message: "The Maximum Length Must Be " + temp?.Max });
                        }
                        if (temp?.Regex != undefined && temp.Regex != "" && e?.match(new RegExp(temp.Regex, 'g'))?.[0] != e) {
                            return false
                        }
                    }
                    return true;
                })
            }),
            [i + "operator" + id]: Yup.string().typeError().when([i + "type" + id], {
                is: "" || undefined || '',
                otherwise: Yup.string().required("Field is Requried")
            }),
        };
    }
    useEffect(() => {
        return (() => {
            setOptionlength((data) => {
                getdataforjson(data);
                return data;
            })
        })
    }, [getdataforjson, id])
    const validationSchema = Yup.object().shape(dynamicYupfields);
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, formState, setValue, watch, clearErrors, handleSubmit } = useForm(formOptions);
    const { errors } = formState;

    useEffect(()=>{
        if(data!=0){
            handleSubmit((temp) => {
                setOptionlength((data) => {
                    getdataforjson(data);
                    setSubmit((data) => {
                        return { ...data, [id]: "okay" }
                    })
                    return data
                });
            }, () => {
                setOptionlength((data) => {
                    getdataforjson(data);
                    setSubmit((data) => {
                        return { ...data, [id]: "Error" };
                    })
                    return data
                });
            })();
        }
    },[data, getdataforjson, handleSubmit, id, setSubmit])

    useEffect(() => {
        const bindValue = async () => {
            if (json?.for?.length > 0) {
                json.for.map(async (data, index) => {
                    if (data.type == "userGroup") {
                        const groupResponse = await AppsyncDBconnection(listXlmsUserGroupInfos, { PK: "TENANT#" + TenantInfo.TenantID, SK: "GROUPINFO#", }, user.signInUserSession.accessToken.jwtToken);
                        previousVal.current = { ...previousVal.current, [index]: { ...previousVal.current?.[index], type: data.type } };
                        setOptions((temp) => {
                            let value = [{ value: "", text: "Select Group" }];
                            groupResponse.res.listXlmsUserGroupInfos.items.map(item => {
                                value = [...value, { value: item.GroupID, text: item.GroupName }];
                            });
                            customRegex.current = { ...customRegex.current, [index]: {} }
                            return { ...temp, [index]: { value: value, options: {} } };
                        });
                    }
                    else if (data.type == "profileField") {
                        const customFieldResponse = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + TenantInfo.TenantID, SK: "CUSTOMFIELD#", }, user.signInUserSession.accessToken.jwtToken);
                        setOptions((temp) => {
                            let value = [{ value: "", text: "Select ProfileField" }];
                            let optionsTemp = {}, regexValue = {};
                            if (customFieldResponse.res.listXlmsCustomFields != undefined)
                                customFieldResponse.res.listXlmsCustomFields.items.map(item => {
                                    value = [...value, { value: item.ProfileFieldName, text: item.ProfileFieldName }];
                                    if (item.FieldOptions != undefined) {
                                        optionsTemp = { ...optionsTemp, [item.ProfileFieldName]: JSON.parse(item.FieldOptions) };
                                    }
                                    regexValue = { ...regexValue, [item.ProfileFieldName]: { Max: item?.MaximumLength, Min: item?.MinimumLength, Regex: item?.Regex } }
                                });
                            customRegex.current = { ...customRegex.current, [index]: regexValue }

                            return { ...temp, [index]: { value: value, options: optionsTemp } };
                        });
                        previousVal.current = { ...previousVal.current, [index]: { ...previousVal.current?.[index], type: data.type, field: data.typevalue.key } };
                    }
                    if (index != json?.for?.length - 1) {
                        setValue(index + "type" + id, data.type);
                        if (data.type == "userGroup") {
                            setValue(index + "field" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);
                        }
                        else if (data.type == "profileField") {
                            setValue(index + "field" + id, data.typevalue.key);
                            setValue(index + "value" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);
                        }
                    }
                    else {
                        setValue(index + "type" + id, data.type);
                        if (data.type == "userGroup") {
                            setValue(index + "field" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);

                        }
                        else if (data.type == "profileField") {
                            setValue(index + "field" + id, data.typevalue.key);
                            setValue(index + "value" + id, data.typevalue.value);
                            setValue(index + "operator" + id, data.typevalue.operator);
                        }
                    }
                });
            }
            setValue("operator", json?.operator, { shouldValidate: true });
        };
        bindValue();

    }, [json, TenantInfo.TenantID, user.signInUserSession.accessToken.jwtToken, setValue, id]);

    const dropdownData = useMemo(() => {
        const temp = [{ value: "", text: "Select Type" }, { value: "profileField", text: "Profile Field" }, { value: "userGroup", text: "User Group" }];
          return temp;
    }, []);

    const Options = useCallback((props) => {
        const rowGrid = [];
        for (let i = 0; i < optionslength; i++) {


            rowGrid.push(<CompletionRestrictControl idfor={props.idfor} final={i == optionslength - 1 && optionslength != 1 ? true : false} options={props.options} id={i} key={i} register={props.register} errors={props.errors} watch={props.watch} />);

        };
        return <>{rowGrid}</>;

    }, [optionslength]);


    const deleteOption = useCallback(async () => {
        setOptionlength((optionLength) => {
            clearErrors();
            setValue((optionLength - 1) + "type" + id, "");
            setValue((optionLength - 1) + "field" + id, "");
            setValue((optionLength - 1) + "value" + id, "");
            setValue((optionLength - 1) + "operator" + id, "", { shouldValidate: true });

            getdataforjson(optionLength - 1);
            return optionLength - 1;
        });
    }, [clearErrors, getdataforjson, id, setValue]);

    const CompletionRestrictControl = useCallback((props) => {
        let optionsGrp = [{ value: "", text: "Select Value" }];
        if (props.options?.[props.id]?.["value"] != undefined) {
            optionsGrp = props.options?.[props.id]?.["value"];
        }
        const optionsProfileField = props.options?.[props.id]?.["options"]?.[props.watch(props.id + "field" + props.idfor)];

        const optionsEquals = [{ value: "", text: "Select Type" }, { value: "equals", text: "Equals" }, { value: "notEquals", text: "Not Equals" }];
        return (
            <>
                <div className="flex w-full mx-auto">
                    <div className="w-1/4 ">
                        <NVLSelectField id={props.id + "type" + props.idfor} options={dropdownData} className={`nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                    </div>
                    {optionsGrp.length > 1 && props.watch(props.id + "type" + props.idfor) != "" && props.watch(props.id + "type" + props.idfor) == "profileField" && <>

                        <div className="w-1/4">
                            < NVLSelectField id={props.id + "field" + props.idfor} options={optionsGrp} className={`nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>
                        <div className="w-1/4 ">
                            <NVLSelectField id={props.id + "operator" + props.idfor} options={optionsEquals} className={`nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>
                    </>}
                    {optionsGrp.length > 1 && props.watch(props.id + "type" + props.idfor) != "" && props.watch(props.id + "type" + props.idfor) == "userGroup" && <>
                        <div className="w-1/4 ">
                            <NVLSelectField id={props.id + "operator" + props.idfor} options={optionsEquals} className={`nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>
                        <div className="w-1/4">
                            < NVLSelectField id={props.id + "field" + props.idfor} options={optionsGrp} className={`nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                        </div>

                    </>}
                    {props.watch(props.id + "type" + props.idfor) == "profileField" && optionsProfileField != undefined && optionsProfileField.length > 1 &&
                        <>
                            <div className="w-1/4">
                                <NVLSelectField id={props.id + "value" + props.idfor} options={optionsProfileField} className={`nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                            </div>

                        </>}
                    <>
                        {props.watch(props.id + "type" + props.idfor) == "profileField" && optionsProfileField != undefined && !(optionsProfileField.length > 1) &&
                            <div className="w-1/4 ">
                                <NVLTextbox id={props.id + "value" + props.idfor} options={optionsProfileField} className={`nvl-Def-Input !w-full`} errors={props.errors} register={props.register} />
                            </div>}
                    </>
                    {props.final && <div className="pt-2">
                        <i className="fa-solid fa-trash text-red-600" onClick={() => { deleteOption(props?.id, optionslength); }}></i>
                    </div>}
                </div>

            </>
        );
    }, [deleteOption, dropdownData, optionslength]);

    const addOption = useCallback(() => {
            if (optionslength <= 5) {
                setOptionlength((data) => {
                    setValue((data) + "type" + id, "", { shouldValidate: true });
                    setValue((data) + "field" + id, "", { shouldValidate: true });
                    setValue((data) + "value" + id, "", { shouldValidate: true });
                    return data + 1;
                }
                )
            }
    }, [id, optionslength, setValue]);

    const getdataforjson = useCallback((Optionslength, temp, operator, tempjson) => {
        let json = { for: [] };
        if (tempjson != undefined) {
            json = { ...tempjson };
        }
        else {
            if (temp != undefined) {
                json = { for: []};
            }
            for (var i = 0; i < Optionslength; i++) {
                json = {
                    ...json, for: [...json.for, {
                        type: watch(i + "type" + id),
                        typevalue: {
                            key: watch(i + "type" + id) == "profileField" ? watch(i + "field" + id) : "",
                            value: watch(i + "type" + id) != "profileField" ? watch(i + "field" + id) : watch(i + "value" + id),
                            operator: watch(i + "operator" + id),
                        }
                    }],
                }
            }
            json = { ...json, operator: watch("operator") }
            if (operator != undefined) {
                json = { ...json, operator: operator }
            }
        }

        setData(json, "" + id);
    }, [id, setData, watch]);


    return (
        <>
            <Container>
                <NVLSelectField labelText={"Condition"} labelClassName={"nvl-Def-Label"} id={"operator"} options={[{ value: "", text: "Select Condition" }, { value: "and", text: "And Condition" }, { value: "or", text: "Or Condition" }]} className={`nvl-Def-Input`} errors={errors} register={register} />
                <Options idfor={id} id={optionslength} register={register} errors={errors} watch={watch} options={options} />
                <NVLButton id={"btnSubmit"+id} type="button" text={"Add  field"} className={dropdownData == "profileField" ? "w-48 nvl-button text-gray-700 bg-primary Disabled " : "w-48 nvl-button bg-green-500 text-white "} onClick={() => addOption(optionslength, errors)}></NVLButton>
            </Container>
        </>
    );
}

export default AddOptionOnBoard;