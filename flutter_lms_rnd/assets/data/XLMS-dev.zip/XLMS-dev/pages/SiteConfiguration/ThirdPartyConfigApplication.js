import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLPassword from "@components/Controls/NVLPassword";
import Container from "@Container/Container";
import NVLButton from "@Controls/NVLButton";
import NVLMultilineTxtbox from "@Controls/NVLMultilineTxtBox";
import NVLTextbox from "@Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXLMSThirdPartyApplication, updateXLMSThirdPartyApplication } from "src/graphql/mutations";
import { getXLMSThirdPartyApplication } from "src/graphql/queries";
import * as Yup from "yup";


function ThirdPartyConfigApplication(props) {
  const router = useRouter();
  const initialModalState = {
    ModalInfo: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Data Saved Successfully.",
    ModalOnClickEvent: () => {
      if (!router.query["ActivityID"] && !router.query["CourseID"]) {
        router.push("/SiteConfiguration/ThirdPartyConfigSettings");
      } else if (!router.query["CourseID"] && router.query["ActivityID"] != undefined) {
        router.push(`/ActivityManagement/EditActivitySettings?Mode=Edit&ActivityID=${router.query["ActivityID"]}&ActivityType=Zoom`);
      } else {
        router.push(`/CourseManagement/EditActivitySettings?Mode=ModuleDirect&ActivityID=${router.query["ActivityID"]}&ActivityType=Zoom&CourseID=${router.query["CourseID"]}&ModuleID=${router.query["ModuleID"]}`);
      }
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);

  const [PageData, setPageData] = useState({});

  const FinalResponse = (FinalStatus) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
      });
      ModalOpen();
      return;
    } else {
      ModalOpen();
    }
  };

  const submitHandler = async (data) => {
    setValue("submit", true)
    let PK = "TENANT#" + PageData?.TenantID;
    let SK = PageData?.ApplicationName + "#";
    let query = PageData?.mode == "Edit" ? updateXLMSThirdPartyApplication : createXLMSThirdPartyApplication;
    let variables = {
      input: {
        PK: PK,
        SK: SK,
        ApplicationName: data.txtApplicationName.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        ApplicationDescription: data.txtDescription.replace(/\s{2,}(?!\s)/g, ' ').trim(),
        APIKey: data.txtAPIKey,
        // MailSubject: data.txtContactEmail,
        APISecretKey: data.txtAPISecret,
        APIUrl: data.txtAPIUrl,
        UserName: data.txtUsername,
        Password: data.txtPassword,
        CreatedDate: new Date(),
        CreatedBy: props.user.username,
      },
    };

    let FinalStatus = (await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken));
    FinalResponse(FinalStatus.Status);
    setValue("submit", false)
  };

  const validationSchema = Yup.object().shape({
    txtApplicationName: Yup.string().required("Application Name is required"),
    txtContactEmail: Yup.string(),
    txtDescription: Yup.string(),
    txtAPIKey: Yup.string().required("Account ID is required").max(100, "Maximum 100 characters exceed"),
    txtAPISecret: PageData?.ApplicationName != "GoogleMeet" ? Yup.string().required("Client ID is required").max(100, "Maximum 100 characters exceed") : Yup.string().required("Client ID is required").test("Max100", "Enter valid Client ID", (e) => {
      if (e == "" || e == undefined) {
        return true;
      }
      if (Regex("AllowAlphaNumericandHyphen").exec(e) && e.length < 101) {
        return true;
      }
      return false;
    }),
    txtAPIUrl: Yup.string().required("Client Secret is required").matches(Regex("AllowAlphaNumericandHyphen"), "Enter valid Client Secret"),
    txtUsername:router.query["ApplicationType"] == "GoogleMeet" && Yup.string().matches(Regex("AllowAlphaNumWithoutSpace"), "Enter valid User Name"),
    txtPassword: Yup.string().notRequired()
      .test("Password", "", (e) => {
        if (e == "" || e == undefined) {
          return true;
        }
        let i = 0,
          message = "Password Should Have ";
        if (!e.match(/\d+/g)) {
          i++;
          message = message + "A Number";
        }
        if (!e.match(/[A-Z]+/g)) {
          i++;
          if (i > 1) {
            message = message + ", ";
          }
          message = message + "A Captial Letter";
        }
        if (!e.match(/[a-z]+/g)) {
          i++;
          if (i > 1) {
            message = message + ", ";
          }
          message = message + "A Small Letter";
        }
        if (!e.match(/[\W_]+/g)) {
          i++;
          if (i > 1) {
            message = message + ", ";
          }
          message = message + "A Special Character";
        }
        if (i > 0) {
          setValue("Error", message)
          return false;
        }

        if ((e).length > 100) {
          setValue("Error", "Maximum 100 characters exceed")
          return false;
        }
        else {
          setValue("Error", "")
        }
        return true;
      }).nullable(),
  });

  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true };
  const { register, handleSubmit, setValue, reset, formState, watch } = useForm(formOptions);
  const { errors } = formState;

  useEffect(() => {
    setValue("txtApplicationName", PageData?.ApplicationName);
    if (PageData?.mode == "Edit") {
      setValue("txtAPIKey", PageData?.EditData.APIKey);
      setValue("txtAPISecret", PageData?.EditData.APISecretKey);
      setValue("txtAPIUrl", PageData?.EditData.APIUrl);
      setValue("txtUsername", PageData?.EditData.UserName);
      setValue("txtPassword", PageData?.EditData.Password);
      setValue("txtDescription", PageData?.EditData.ApplicationDescription);
    }
  }, [PageData?.ApplicationName, PageData?.EditData?.APIKey, PageData?.EditData?.APISecretKey, PageData?.EditData?.APIUrl, PageData?.EditData?.ApplicationDescription, PageData?.EditData?.Password, PageData?.EditData?.UserName, PageData?.mode, setValue]);

  useEffect(() => {
    const fetchData = async () => {
      let TenantID = props.user.attributes["custom:tenantid"];
      let Name = router.query["ApplicationType"];
      const dta = await AppsyncDBconnection(getXLMSThirdPartyApplication, { PK: "TENANT#" + TenantID, SK: Name + "#" }, props.user.signInUserSession.accessToken.jwtToken);
      const temp = {
        TenantID: TenantID,
        ApplicationName: Name,
        EditData: dta?.res?.getXLMSThirdPartyApplication != null ? dta?.res?.getXLMSThirdPartyApplication : "",
        mode: dta?.res?.getXLMSThirdPartyApplication != null ? "Edit" : ""
      }
      setPageData(temp);
    }
    fetchData();
    return (() => {
      setPageData((temp) => { return { ...temp } })
    })
  }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query]);

  const PageRoutes = useMemo(() => {
    let routes;
    if (!router.query["ActivityID"] && !router.query["CourseID"]) {
      routes = [{ path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
      { path: "/SiteConfiguration/ThirdPartyConfigSettings", breadcrumb: "Third Party Configuration" },
      { path: "", breadcrumb: PageData?.ApplicationName }];
    } else if (!router.query["CourseID"] && router.query["ActivityID"] != undefined) {
      routes = [{ path: "/ActivityManagement/ActivityList", breadcrumb: "Activity Management" },
      { path: "", breadcrumb: PageData?.ApplicationName }]
    } else {
      routes = [{ path: "/CourseManagement/CourseList", breadcrumb: "Course Management" },
      { path: `/CourseManagement/ModulesList?CourseID=${router.query["CourseID"]}`, breadcrumb: "Manage Course" },
      { path: "", breadcrumb: PageData?.ApplicationName }]
    }
    return routes;
  }, [PageData?.ApplicationName, router.query])

  return (
    <>
      <Container PageRoutes={PageRoutes} loader={PageData?.TenantID == undefined} title={PageData?.ApplicationName}>
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(submitHandler)} className={`${watch("submit") ? "pointer-events-none" : "px-2"}`}>
          <div className="nvl-FormContent">
            <NVLTextbox id="txtApplicationName" labelText="Name" labelClassName="font-semibold text-gray-500" errors={errors} title="Enter Application Name" className="nvl-mandatory Disabled nvl-Def-Input" register={register} />
            <NVLMultilineTxtbox id="txtDescription" cols="40" rows="5" labelText="Description" labelClassName="font-semibold text-gray-500" errors={errors} title="Description" className={`nvl-non-mandatory nvl-Def-Input`} register={register} />
            <NVLTextbox id="txtAPIKey" labelText="Account ID" labelClassName="font-semibold text-gray-500" errors={errors} title="Account ID" className="nvl-mandatory nvl-Def-Input" register={register} />
            <NVLTextbox id="txtAPISecret" errors={errors} labelText="Client ID" labelClassName="font-semibold text-gray-500" className={props.ApplicationName != "GoogleMeet" ? `nvl-mandatory nvl-Def-Input` : `nvl-non-mandatory nvl-Def-Input`} title="Client ID" register={register} />
            <NVLTextbox id="txtAPIUrl" errors={errors} labelText="Client Secret" labelClassName="font-semibold text-gray-500" className="nvl-mandatory nvl-Def-Input" title="Client Secret" register={register} />

            {((watch("txtAPIKey") && watch("txtAPISecret") && watch("txtAPIUrl"))&& router.query["ApplicationType"] == "Zoom" ) && <div className={`break-words h- flex shadow-md gap-6 rounded overflow-hidden divide-x max-w-2xl bg-amber-200 `}>
              <div className="flex flex-1 flex-col p-2 dark:border-violet-400">
                <span className="text-xs dark:text-white flex items-center gap-4 p-2">
                  <i className="fa fa-info-circle" aria-hidden="true"></i>
                  <div>
                      Zoom meeting can&apos;t be created, if the account is not activated
                  </div>
                </span>
              </div>
            </div>}
            {router.query["ApplicationType"] == "GoogleMeet" && <><NVLTextbox id="txtUsername" errors={errors} labelText="Account Login" labelClassName="font-semibold text-gray-500" title="User Name" className="nvl-Def-Input" register={register} />
              <div className="relative ">
                <NVLPassword title="Password" id="txtPassword" type="password" labelText="Password" labelClassName="nvl-Def-Label" className=" nvl-non-mandatory nvl-Def-Input !pr-8" register={register} errors={errors}></NVLPassword>
                {watch("Error") != "" && watch("Error") != undefined && <div className="{invalid-feedback}   text-red-500 text-sm ">{watch("txtPassword") != "" ? watch("Error") : ""}</div>
                }
              </div>
            </>}
            <div className="py-2 gap-2 pl-10 justify-center">
              <NVLButton id="btnSubmit" text={!watch("submit") ? "Save" : ""} type="submit" className={"w-28 nvl-button  bg-primary text-white "}>
                {watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
              </NVLButton>
              <NVLButton id="btnCancel" text={"Cancel"} type="reset" className="nvl-button w-28 mx-2" onClick={() => {
                if (!router.query["ActivityID"] && !router.query["CourseID"]) {
                  router.push("/SiteConfiguration/ThirdPartyConfigSettings")
                } else if (!router.query["CourseID"] && router.query["ActivityID"] != undefined) {
                  router.push("/ActivityManagement/ActivityList")
                } else {
                  router.push(`/CourseManagement/ModulesList?CourseID=${router.query["CourseID"]}`)
                }
                reset()
              }}></NVLButton>
            </div>
          </div>
        </form>
      </Container>
    </>
  );
}

export default ThirdPartyConfigApplication;

