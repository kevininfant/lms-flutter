
import Container from "@components/Container/Container";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLThemeCard from "@components/Controls/NVLThemeCard";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXlmsTenantBranding, updateXlmsTenantInfo } from "src/graphql/mutations";
import { getXlmsTenantBranding, getXlmsTenantInfo, listXlmsActiveTenantInfo, listXlmsTenantBrandings } from 'src/graphql/queries';
import * as Yup from "yup";
import BrandingModalPopup from "../SiteConfiguration/BrandingModalPopup";

export default function Branding(props) {
    const [csrFetchedBrandingData, setCsrFetchedBrandingData] = useState({});
    useEffect(() => {
        const dataSource = async () => {
            var TenantID = props.user.attributes["custom:tenantid"] != undefined ? props.user.attributes["custom:tenantid"] : "";
            const tenantBranding = await AppsyncDBconnection(listXlmsTenantBrandings, { PK: "XLMS#BRANDING#TENANT#" + TenantID, SK: "BRANDING#", IsDeleted: false, }, props.user.signInUserSession.accessToken.jwtToken);
            const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            let brandingOrder = tenantBranding?.res?.listXlmsTenantBrandings?.items.filter((el) => {
                return el?.ThemeMode == "Default-Theme" || el?.ThemeMode == "Dark-Theme";
            })
            let removeDup = [...brandingOrder, ...tenantBranding?.res?.listXlmsTenantBrandings?.items];

            let newArray = [];
            let uniqueObject = {};
            for (let i in removeDup) {
                let objTitle = removeDup[i]?.ThemeMode;
                uniqueObject[objTitle] = removeDup[i];
            }
            for (let i in uniqueObject) {
                newArray.push(uniqueObject[i]);
            }

            setCsrFetchedBrandingData({
                TenantList: tenantResponse?.res?.listXlmsActiveTenantInfo?.items,
                TenantID: TenantID,
                BrandingData: newArray ? newArray : undefined,
            });
        };
        dataSource();
        return (() => {
            setCsrFetchedBrandingData((temp) => { return { ...temp }; });
        });

    }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken]);
    const [open, setOpen] = useState(true);
    const [preview, setPreview] = useState("true");

    function PreviewThemeColorApply(BrandingInfo) {
        if (BrandingInfo != undefined) {
            setPreview(BrandingInfo);
            const r = document.querySelector(':root');
            const bodyColor = JSON.parse(BrandingInfo.Body);
            const sideBarColor = JSON.parse(BrandingInfo.SideBar);
            const gridColor = JSON.parse(BrandingInfo.Grid);
            const headerColor = JSON.parse(BrandingInfo.Header);
            if (BrandingInfo?.Body != undefined) {
                Object.keys(bodyColor).map((item) => {
                    r.style.setProperty(item, bodyColor[item]);
                });
            }
            if (BrandingInfo?.SideBar != undefined) {
                Object.keys(sideBarColor).map((item) => {
                    r.style.setProperty(item, sideBarColor[item]);
                });
            }
            if (BrandingInfo?.Grid != undefined) {
                Object.keys(gridColor).map((item) => {
                    r.style.setProperty(item, gridColor[item]);
                });
            }
            if (BrandingInfo?.Header != undefined) {
                Object.keys(headerColor).map((item) => {
                    r.style.setProperty(item, headerColor[item]);
                });
            }
        }
        else {
            const body = {
                "--nvl-body-bg-color": "rgb(255, 255, 255)",
                "--nvl-body-button-bg-color": "#099127",
                "--nvl-body-button-hover-bg-color": "#0c6e0c",
                "--nvl-body-icon-color": "#0d6aff",
                "--nvl-body-txt-color": "rgb(75 85 99)",
                "--nvl-loading-spinner-bg-clr": "hsl(0, 72%, 48%)"
            };

            const sidder = {
                "--nvl-sidebar-bg-color": "#f9fafc 0% 0% no-repeat padding-box",
                "--nvl-sidebar-hover-bg-color": "rgb(219 234 254)",
                "--nvl-sidebar-icon-color": "rgb(55 65 81)",
                "--nvl-sidebar-nested-bg-color": "rgb(239 246 255)",
                "--nvl-sidebar-txt-color": "rgb(55 65 81)"
            };

            const grid = {
                "--nvl-grid-header-bg-color": "rgb(219 234 254)",
                "--nvl-grid-row-end-bg-color": "rgb(255, 255, 255)",
                "--nvl-grid-row-start-bg-color": "rgb(243 244 246)",
                "--nvl-grid-txt-color": "rgb(66, 66, 66)"
            };

            const header = {
                "--nvl-header-bg-color": "#f9fafc",
                "--nvl-header-icon-color": "#757575",
                "--nvl-header-txt-color": "rgb(55 65 81)"
            };

            const r = document.querySelector(':root');
            Object.keys(body).map((item) => {
                r.style.setProperty(item, body[item]);
            });

            Object.keys(sidder).map((item) => {
                r.style.setProperty(item, sidder[item]);
            });

            Object.keys(grid).map((item) => {
                r.style.setProperty(item, grid[item]);
            });

            Object.keys(header).map((item) => {
                r.style.setProperty(item, header[item]);
            });
        }

    }

    const validationSchema = Yup.object().shape({
        ddlSearch:
            props.TenantInfo.UserGroup == "SiteAdmin" &&
            Yup.string()
                .required("Please Select The Field")
                .test("In Valid", "ChangeHandler", async (e) => {
                    const siteBranding = await AppsyncDBconnection(
                        listXlmsTenantBrandings,
                        {
                            PK: 'XLMS#BRANDING#TENANT#' + e,
                            SK: 'BRANDING#',
                            IsDeleted: false,
                        }
                        , props.user.signInUserSession.accessToken.jwtToken);


                        let brandingOrder = siteBranding?.res?.listXlmsTenantBrandings?.items.filter((el) => {
                            return el?.ThemeMode == "Default-Theme" || el?.ThemeMode == "Dark-Theme";
                        })
                        let removeDup = [...brandingOrder, ...siteBranding?.res?.listXlmsTenantBrandings?.items];

                    let newArray = [];
                    let uniqueObject = {};
                    for (let i in removeDup) {
                        let objTitle = removeDup[i]?.ThemeMode;
                        uniqueObject[objTitle] = removeDup[i];
                    }
                    for (let i in uniqueObject) {
                        newArray.push(uniqueObject[i]);
                    }
                    setCsrFetchedBrandingData((temp) => { return { ...temp, BrandingData: newArray&&newArray, TenantID: e }; });
                    return true;
                }),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
    const { register, handleSubmit, formState } = useForm(formOptions);
    const { errors } = formState;

    async function getServerProps(TentID) {
        const tenantBranding = await AppsyncDBconnection(
            getXlmsTenantInfo,
            { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + TentID },
            props.user.signInUserSession.accessToken.jwtToken);
        return tenantBranding?.res?.getXlmsTenantInfo?.ThemeMode;
    }
    const dropdownData = useMemo(() => {
        let CurrentTenant = [];
        let temp = [{ value: "", text: "Select Company" }];
        if (csrFetchedBrandingData.TenantList != undefined) {
            if (csrFetchedBrandingData.TenantList.length > 2 && props.TenantInfo.UserGroup == "SiteAdmin") {
                csrFetchedBrandingData.TenantList.map((getItem) =>
                    temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }),
                );
            } else if (props.TenantInfo.UserGroup != "SiteAdmin" && props.TenantInfo.UserGroup != undefined) {
                temp = [];
                CurrentTenant = csrFetchedBrandingData.TenantList.filter(function (Tenant) {
                    return Tenant.TenantID == csrFetchedBrandingData.TenantID;
                });
                CurrentTenant.map((getItem) => {
                    temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, });
                });
            }
        }
        return temp;
    }, [csrFetchedBrandingData.TenantID, csrFetchedBrandingData.TenantList, props.TenantInfo.UserGroup]);

    const deleteThemeSettings = async (BrandingInfo) => {

        const brandingData = {
            PK: BrandingInfo.PK,
            SK: BrandingInfo.SK,
            IsActivate: false,
            IsDeleted: true,
        };
        const finalStatus = await AppsyncDBconnection(updateXlmsTenantBranding, { input: brandingData }, props.user.signInUserSession.accessToken.jwtToken);
        if (finalStatus.Status == "Success") {
            const removeIndex = csrFetchedBrandingData.BrandingData.findIndex(item => item.SK == BrandingInfo.SK);
            csrFetchedBrandingData.BrandingData.splice(removeIndex, 1);

            setCsrFetchedBrandingData((temp) => {
                return ({ ...temp, ...csrFetchedBrandingData.BrandingData });
            });


            if (await getServerProps(csrFetchedBrandingData.TenantID) == finalStatus.res.updateXlmsTenantBranding.SK.split("#")[1]) {
                const brandingData = {
                    PK: 'XLMS#TENANTINFO',
                    SK: '#TENANT#' + csrFetchedBrandingData.TenantID,
                    ThemeMode: "",
                };
                const query = updateXlmsTenantInfo;
                const finalStatus = await AppsyncDBconnection(query, { input: brandingData }, props.user.signInUserSession.accessToken.jwtToken);

                if (finalStatus.Status == "Success") {
                    const tenantBranding = await AppsyncDBconnection(
                        getXlmsTenantBranding,
                        { PK: "XLMS#BRANDING#TENANT#" + csrFetchedBrandingData.TenantID, SK: "BRANDING#" + brandingData.ThemeMode },
                        props.user.signInUserSession.accessToken.jwtToken);
                    PreviewThemeColorApply(tenantBranding.res.getXlmsTenantBranding);
                }

            }
            if (preview.ThemeMode == finalStatus.res.updateXlmsTenantBranding.ThemeMode) {
                const tenantBranding = await AppsyncDBconnection(
                    getXlmsTenantBranding,
                    { PK: "XLMS#BRANDING#TENANT#" + csrFetchedBrandingData.TenantID, SK: "BRANDING#" + await getServerProps(csrFetchedBrandingData.TenantID) },
                    props.user.signInUserSession.accessToken.jwtToken);
                PreviewThemeColorApply(tenantBranding.res.getXlmsTenantBranding);
            }

        }
    };
    const applyThemeSettings = async (BrandingInfo) => {

        const brandingData = {
            PK: 'XLMS#TENANTINFO',
            SK: '#TENANT#' + csrFetchedBrandingData.TenantID,
            ThemeMode: BrandingInfo.SK.split("#")[1],
        };
        const query = updateXlmsTenantInfo;
        const finalStatus = await AppsyncDBconnection(query, { input: brandingData }, props.user.signInUserSession.accessToken.jwtToken);
        if (finalStatus.Status == "Success" && props.TenantInfo.UserGroup != "SiteAdmin") {

            PreviewThemeColorApply(BrandingInfo);
        }
    };

    const headerHandler = (data) => {
        if (data.ddlSearch != "") {
            if (props.RoleData.CustomColorTheme)
                setOpen();
        } else {
            validationSchema.validate();
        }
    };

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Branding" }
        ];

    }, []);

    return (
        <>
            <Container title="Branding" PageRoutes={pageRoutes} loader={csrFetchedBrandingData.TenantID == undefined}>
                <BrandingModalPopup open={open} user={props.user} setOpen={() => setOpen(!open)} TenantID={csrFetchedBrandingData.TenantID} setData={setCsrFetchedBrandingData} Data={csrFetchedBrandingData} />
                <NVLHeader ButtonID1="btnCreateActivity" LinkName1={props.RoleData?.CustomColorTheme ? "+ Create Theme" : ""} className1={props.RoleData?.CustomColorTheme ? (props.TabRouting == true ? "" : "nvl-button-success") : ""} href1={props.RoleData?.CustomColorTheme ? "#" : ""} TabRouting={false} IsNestedHeader RedirectAction1={handleSubmit((data) => headerHandler(data))} IsDropdown={true} DropdownData={dropdownData} errors={errors} register={register} IsDropdownDisable={props.RoleData?.CustomColorTheme ? (props.TenantInfo.UserGroup != "SiteAdmin" ? true : false) : false} DropdownRequired={true} />
                <section className="text-gray-600 body-font">
                    <div className="container px-3 py-5 mx-auto flex flex-wrap">
                        <div className="container mx-auto">
                            {csrFetchedBrandingData?.BrandingData &&
                                csrFetchedBrandingData?.BrandingData?.length != 0 ?
                                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                    {csrFetchedBrandingData?.BrandingData?.map((getItem, index) => {
                                        return (
                                            <div key={index}>
                                                <NVLThemeCard ThemeInfo={getItem} RoleData={props.RoleData} deleteOnClick={() => deleteThemeSettings(getItem)} preViewOnClick={() => PreviewThemeColorApply(getItem)} applyOnClick={() => applyThemeSettings(getItem)} borderclass="border-b-4 border-th-body-icon-hover-color" className="h-36 nvl-card-shadow" outerclass="p-3" />
                                            </div>
                                        );
                                    })} </div> :
                                    <NVLNoImage id="NoRecord" className="w-96 h-96 mx-auto" alignItem={""} />
                            }
                        </div>
                    </div>
                </section>
            </Container>
        </>
    );
}