import { Image } from "@aws-amplify/ui-react";
import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import 'quill/dist/quill.bubble.css';
import 'quill/dist/quill.snow.css';
import { useCallback, useEffect, useState } from "react";
import ReactPlayer from "react-player";
import { getXlmsPopUpInfo, getXlmsTenantInfo } from "src/graphql/queries";

export default function ViewPopUp(props) {
    const router = useRouter();
    const [PageData, setPageData] = useState({});

    useEffect(() => {
        const fetchData = async (i) => {
            let URl_PK = props.TenantInfo.UserGroup == "SiteAdmin" ? "TENANT#" + router.query["TenantID"] : "TENANT#" + props.TenantInfo.TenantID;
            let URl_SK = "POPUPID#" + router.query["PopUpID"];
            let UserSub = props.user.attributes["sub"];
            let tenantData;
            if (props?.TenantInfo?.UserGroup == "SiteAdmin") {
                tenantData = await AppsyncDBconnection(getXlmsTenantInfo, {
                    PK: "XLMS#TENANTINFO",
                    SK: "#TENANT#" + router.query["TenantID"]
                }, props?.user.signInUserSession.accessToken.jwtToken);
            }
            const popUpResponse = await AppsyncDBconnection(getXlmsPopUpInfo, {
                PK: URl_PK,
                SK: URl_SK
            }, props?.user.signInUserSession.accessToken.jwtToken);
            const temp = {
                UserSub: UserSub,
                EditData: popUpResponse?.res?.getXlmsPopUpInfo != undefined ? popUpResponse.res.getXlmsPopUpInfo : {},
                TenantData: tenantData?.res?.getXlmsTenantInfo != undefined ? tenantData.res.getXlmsTenantInfo : {},
            }
            setPageData(temp);
        }
        fetchData();
        return (() => {
            setPageData((temp) => { return { ...temp } });
        })
    }, [props.TenantInfo?.BucketName, props?.TenantInfo?.RootFolder, props.TenantInfo?.TenantID, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload, router.query]);
    const PageRoutes = [
        { path: "/SiteConfiguration/ManagePopUpList", breadcrumb: "ManagePopUpList" },
        { path: "", breadcrumb: "View PopUp" }
    ];

    const fileReader = useCallback((data) => {
        switch (data?.FileType) {
            case "Youtube": return (<>
                <ReactPlayer onContextMenu={e => e.preventDefault()} width="100%" height="500px" url={data?.URL} playing={false} controls={true} />
            </>)
            case "URL": return (<>
                <iframe src={data?.URL + "#toolbar=0"} width="100%" height="500px"></iframe>
            </>)
            case "Image": return (<>
                <Image download alt="testimonial" className="w-full h-[500px] shadow-xl p-1 my-auto rounded-lg bg-gray-200 inline-block border-gray-200" src={data?.FilePath} />
            </>)
            case "Audio": return (<>
                <ReactPlayer onContextMenu={e => e.preventDefault()} width="100%" height="100px" url={data?.FilePath} playing={false} controls={true} />
            </>)
            case "Video": return (<>
                <ReactPlayer onContextMenu={e => e.preventDefault()} width="100%" height="500px" url={data?.MpdUrlPath} playing={false} controls={true} />
            </>)
            default:
                return null
        }

    }, [],)

    return (
        <>
            <Container PageRoutes={PageRoutes} loader={PageData?.UserSub == undefined} title="ViewPopUp">
                <section className="flex justify-center text-gray-600 body-font px-10 pt-10  gap-8 text-xs font-semibold shadow-xl py-4 bg-gray-100 rounded-md ">
                    {fileReader(PageData?.EditData)}
                </section>
                <div className="p-4 rounded w-full mx-auto bg-gray-200 flex justify-center gap-20">
                    <NVLButton text="Back" type={"success"} className="nvl-button bg-primary text-white w-32 h-10 " onClick={() => router.push(`/SiteConfiguration/ManagePopUpList`)} />
                </div>
            </Container>
        </>
    );
}