import Container from "@components/Container/Container";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRapidModal from "@Controls/NVLRapidModal";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsTenantInfo, listXlmsActiveTenantInfo, listXlmsTenantCustomRoleInfos } from "src/graphql/queries";
import * as Yup from "yup";

function RoleList(props) {
    const router = useRouter();
    const [getData, setPageData] = useState({});
    const [isRefreshing, setIsRefreshing] = useState(0);
    const headerColumn = useMemo(() => {
        let temp = [];
        temp.push({ HeaderName: `${props.TenantInfo.UserGroup != "SiteAdmin" ? "Custom Role Name" : "Role Name"}`, Columnvalue: "CustomRoleName", HeaderCss: "w-6/12", });
        if (props.TenantInfo.UserGroup == "SiteAdmin") {
            temp.push({ HeaderName: "Role Type", Columnvalue: "RoleType", HeaderCss: "w-0/12" });
        }
        temp = [...temp,
        { HeaderName: "Mapping Role Name", Columnvalue: "MappingRoleName", HeaderCss: "w-4/12", },
        { HeaderName: `${props.TenantInfo.UserGroup != "SiteAdmin" ? "Custom Role Description" : "Role Description"}`, Columnvalue: "CustomRoleDescription", HeaderCss: "w-w-6/12", },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
        ];
        return temp;
    }, [props.TenantInfo.UserGroup]);

    const validationSchema = Yup.object().shape({
        ddlSearch:
            props?.TenantInfo.UserGroup == "SiteAdmin" &&
            Yup.string()
                .required("Please Select The Field")
                .test("NOValid", "ChangeHandler", async (e) => {

                    if (e != undefined && e != "") {
                        const tenantResponse = await AppsyncDBconnection(
                            getXlmsTenantInfo,
                            { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + e },
                            props.user.signInUserSession.accessToken.jwtToken
                        );
                        setPageData((temp) => {
                            return { ...temp, TenantID: e, Name: tenantResponse.res.getXlmsTenantInfo.TenantDisplayName, PlanCode: tenantResponse.res.getXlmsTenantInfo.PlanCode, PlanDate: tenantResponse.res.getXlmsTenantInfo.StartDate, variable: { PK: "TENANT#" + e, SK: "CUSTOMROLE#" } };
                        });
                        setIsRefreshing((count) => {
                            return count + 1;
                        })
                        return true;
                    }
                    return false;
                }),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
    const { register, handleSubmit, formState, setValue ,watch} = useForm(formOptions);
    const { errors } = formState;

    const dropdownData = useMemo(() => {
        let CurrentTenant = [];
        let temp = [{ value: "", text: "Select Company" }];
        if (getData?.TenantList?.length > 2 && props.TenantInfo.UserGroup == "SiteAdmin") {
            getData.TenantList.map((getItem) =>
                temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, })
            );
        } else if (props.TenantInfo.UserGroup != "SiteAdmin" && props.TenantInfo.UserGroup != undefined) {
            temp = [];
            CurrentTenant = getData?.TenantList?.filter(function (Tenant) {
                return Tenant.TenantID == getData.TenantID;
            });
            CurrentTenant?.map((getItem) => {
                temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, });
            });
            setValue("ddlSearch", getData?.TenantID, { shouldValidate: true });
        }
        return temp;
    }, [getData.TenantList, getData.TenantID, props.TenantInfo.UserGroup, setValue]);

    const tenantName = "";
    const actionRestriction = useCallback((getItem, index) => {
        const actionList = [];
        if (props.RoleData?.EditRole) {
            actionList.push(
                {
                    id: index,
                    Color: "text-green-700",
                    Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                    name: "Edit",
                    action: () =>
                        router.push(
                            `/SiteConfiguration/Role?TenantID=${getData.TenantID}&TenantName=${getData.Name}&mode=Edit&RoleName=${getItem.CustomRoleName || getItem.RoleName}&PlanCode=${getData.PlanCode}&StartDate=${getData.PlanDate}`
                        ),
                }

            );
        }
        if (props.RoleData?.DeleteRole && getItem.CustomRoleName != undefined) {
            actionList.push(
                {
                    id: index,
                    Color: "text-rose-700",
                    Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                    name: "Delete",
                    action: () =>
                        router.push(
                            `/SiteConfiguration/Role?TenantID=${getData.TenantID}&TenantName=${getData.Name}&mode=Delete&RoleName=${getItem.CustomRoleName}&PlanCode=${getData.PlanCode}&StartDate=${getData.PlanDate}`
                        ),
                }
            );
        }

        return actionList;
    }, [props.RoleData?.EditRole, props.RoleData?.DeleteRole, router, getData.TenantID, getData.Name, getData.PlanCode, getData.PlanDate]);

    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData && viewData.map((getItem, index) => {
            let ActionList = [];
            ActionList = actionRestriction(getItem);
            const temp = {
                CustomRoleName: (<NVLlabel id={"lblRoleName" + (index + 1)} text={getItem.CustomRoleName || getItem.RoleName}></NVLlabel>),
                RoleType: (<>  {props.TenantInfo.UserGroup == "SiteAdmin" && <NVLlabel id={"lblRoleType" + (index + 1)} text={!getItem.IsDefault ? "Custom" : "Default"}></NVLlabel>}</>),
                MappingRoleName: (<NVLlabel id={"lblMappingRoledesc" + (index + 1)} text={!getItem.IsDefault ? getItem.RoleName : "-"}></NVLlabel>),
                CustomRoleDescription: (<NVLlabel id={"lblRoledesc" + (index + 1)} text={getItem.CustomRoleDescription?.replace(/\s+/g, ' ') || getItem.RoleDescription?.replace(/\s+/g, ' ')}></NVLlabel>),
                Action: (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={ActionList}  ></NVLRapidModal>),
            };
            if (getItem.IsDefault && props.TenantInfo.UserGroup == "SiteAdmin")
                rowGrid.push(temp);
            else if (!getItem.IsDefault) {
                rowGrid.push(temp);
            }
        });

        return rowGrid;
    }, [actionRestriction, props.TenantInfo.UserGroup]
    );
    const handleUrl = () => {
        if (props?.TenantID != "" && props.TenantInfo.UserGroup == "SiteAdmin") {
            router.push(
                `/SiteConfiguration/Role?TenantID=${getData.TenantID}&TenantName=${getData.Name}&mode=Create&RoleName=&PlanCode=${getData.PlanCode}&StartDate=${getData.PlanDate}`
            );
        } else {
            router.push(
                `/SiteConfiguration/Role?TenantID=${getData.TenantID}&TenantName=${getData.Name}&mode=Create&RoleName=${props.TenantInfo.UserGroup}&PlanCode=${props.TenantInfo.PlanCode}&StartDate=${props.TenantInfo.StartDate}`
            );
        }
    };
    useEffect(() => {
        const fetchData = async () => {
            const tenantID = props.user.attributes["custom:tenantid"];
            const tenantResponse = await AppsyncDBconnection(
                listXlmsActiveTenantInfo,
                { PK: "XLMS#TENANTINFO", SK: "#TENANT#" },
                props?.user?.signInUserSession.accessToken.jwtToken);

            let temp = {
                TenantList: tenantResponse.res.listXlmsActiveTenantInfo?.items,
                TenantID: tenantID != undefined ? tenantID : "",
            };
            if (props.TenantInfo.UserGroup != "SiteAdmin") {
                temp = { ...temp, Name: props.TenantInfo.TenantName, PlanCode: props.TenantInfo.PlanCode, PlanDate: props.TenantInfo.StartDate, variable: { PK: "TENANT#" + tenantID, SK: "CUSTOMROLE#" } };

            }
            setPageData((data) => {
                return { ...data, ...temp };
            });
        };
        fetchData();

        return (() => {
            setPageData((temp) => { return { ...temp }; });
        });
    }, [props.TenantInfo.PlanCode, props.TenantInfo.StartDate, props.TenantInfo.TenantName, props.TenantInfo.UserGroup, props.user.attributes, props.user?.signInUserSession.accessToken.jwtToken, setValue]);

    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Permission & Role Management" }
        ];
    }, [])

    const refreshGrid = async () => {
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    return (
        <>
            <form>
                <Container PageRoutes={pageRoutes} loader={getData?.TenantID == undefined} title="Permission & Role Management">
                    <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} LinkName1="Add New Roles" placeholder={"Search by Role"} IsNestedHeader
                        href1={`${(props?.TenantID != "" && props.TenantInfo.UserGroup == "SiteAdmin") ? `/SiteConfiguration/Role?TenantID=${getData.TenantID}&TenantName=${tenantName}&mode=Create&RoleName=&PlanCode=${getData.PlanCode}&StartDate=${getData.PlanDate}` : `/SiteConfiguration/Role?TenantID=${getData.TenantID}&TenantName=${tenantName}&mode=Create&RoleName=&PlanCode=${props.TenantInfo.PlanCode}&StartDate=${props.TenantInfo.StartDate}`}`}
                        className1={props.RoleData?.AddNewRole ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"}
                        RedirectHome={"/SiteConfiguration/SiteConfigSettings"}
                        RedirectAction1={handleSubmit((data) => handleUrl(data, "/"))}
                        TableID={"tblRoleListData"}
                        IsDropdown={true}
                        DropdownData={dropdownData} IsDropdownDisable={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false}
                        DropdownRequired={true} errors={errors}
                        register={register}
                        onClick1={refreshGrid}

                        RedirectAction5={() => refreshGrid()}
                    />
                    <div className="pt-5">
                       { (watch("ddlSearch") != undefined && watch("ddlSearch") != "") && <NVLGridTable user={props.user} refershPage={isRefreshing} id="tblActivityList" className="max-w-full" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsTenantCustomRoleInfos} querryName={"listXlmsTenantCustomRoleInfos"} variable={getData.variable} />}
                    </div>
                </Container>
            </form>
        </>
    );
}

export default RoleList;