import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import Container from "@Container/Container";
import NVLHeader from "@Controls/NVLHeader";
import NVLRapidModal from "@Controls/NVLRapidModal";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXlmsCustomCertificate } from "src/graphql/mutations";
import { listXlmsActiveTenantInfo, listXlmsDisableCustomCertificate } from "src/graphql/queries";
import * as Yup from "yup";

function CustomCertificateList(props) {
    const router = useRouter();
    const [isRefreshing, setIsRefreshing] = useState(true);
    const [popupValues, setPopupValues] = useState({});
    const variable = useRef({ PK: "TENANT#" + props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : "", SK: "CUSTOMCERTIFICATE#" });
    const [data, setData] = useState();
    const headerColumn = [
        { HeaderName: "Template Name ", Columnvalue: "TemplateName", HeaderCss: "w-6/12", },
        { HeaderName: "Template Description", Columnvalue: "TemplateDescription", HeaderCss: "w-6/12", },
        { HeaderName: "Action ", Columnvalue: "Action", HeaderCss: "w-0/12" },
    ];
    const validationSchema = Yup.object().shape({
        ddlSearch:
            props.TenantInfo.UserGroup == "SiteAdmin" &&
            Yup.string()
                .required("Please Select The Field")
                .test("NOValid", "ChangeHandler", (e) => {
                    variable.current = { PK: "TENANT#" + e, SK: "CUSTOMCERTIFICATE#" };
                    setIsRefreshing((temp) => { return (temp + 1); });
                    return true;
                }),

    });
    useEffect(() => {
        async function FetchData() {
            let TenantID = "";
            if (props.user.signInUserSession.accessToken.payload["cognito:groups"][0] != "SiteAdmin") {
                TenantID = props?.TenantInfo?.TenantID;
            }
            TenantID = props?.TenantInfo?.TenantID;
            const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, {
                PK: "XLMS#TENANTINFO",
                SK: "#TENANT#",
            }, props.user.signInUserSession.accessToken.jwtToken);
            setData({
                TenantData: tenantResponse?.res?.listXlmsActiveTenantInfo?.items,
                tenantID: TenantID,
            });

        }
        FetchData();
        return (() => {
            setData((temp) => { return { ...temp }; });
        });
    }, [props?.TenantInfo?.TenantID, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken.payload]);
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
    const { register, handleSubmit, setValue, formState, watch } = useForm(formOptions);
    const { errors } = formState;

    const dropdownData = useMemo(() => {
        let CurrentTenant = [];
        let temp = [{ value: "", text: "Select Company" }];
        if (data?.TenantData?.length > 0 && props?.TenantInfo?.UserGroup == "SiteAdmin") {
            data?.TenantData.map((getItem) => { temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }); });
        } else if (props.TenantInfo.UserGroup != "SiteAdmin" && props.TenantInfo.UserGroup != undefined) {
            variable.current = { PK: "TENANT#" + data?.tenantID, SK: "CUSTOMCERTIFICATE#" };
            temp = [];
            CurrentTenant = data?.TenantData?.filter(function (Tenant) { return Tenant?.TenantID == data?.tenantID; });
            CurrentTenant?.map((getItem) => {
                temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, });
            });
            setValue("ddlSearch", data?.tenantID, { shouldValidate: true });
        }
        return temp;
    }, [props.TenantInfo.UserGroup, data?.TenantData, data?.tenantID, setValue]);

    const actionRestriction = useCallback((getItem) => {
        const actionList = [];
        if (props.RoleData?.EditCustomCertificate && !getItem.IsDisabled) {
            actionList.push({
                id: 1,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit Certificate",
                action: () => router.push(`/SiteConfiguration/CustomCertificateInfo?Mode=Edit&TenantID=${getItem.TenantID}&TemplateID=${getItem.TemplateID}`),
            });
        }
        if (props.RoleData?.ViewCustomCertificate && !getItem.IsDisabled) {
            actionList.push({
                id: 2,
                Color: "text-blue-700",
                Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                name: "View Certificate",
                action: () => router.push(`/SiteConfiguration/ViewCertificate?TenantID=${getItem.TenantID}&TemplateID=${getItem.TemplateID}`),
            });
        }
        if (props.RoleData?.DisableCustomCertificate && !getItem.IsDisabled) {
            actionList.push({
                id: 3,
                Color: "text-yellow-600",
                Icon: "fa-solid fa-door-open text-yellow-600 bg-yellow-100  w-6",
                name: "Disable Certificate",
                action: () => popup("IsDisable", getItem.PK, getItem.SK, "Are you sure you want to continue?", getItem.TemplateUrlPath, "IsDisable", "", ""),
            },
            );
        }
        if (props.RoleData?.DeleteCustomCertificate && getItem.IsDisabled) {
            actionList.push({
                id: 4,
                Color: "text-rose-700",
                Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                name: "Delete Certificate",
                action: () => popup("isDelete", getItem.PK, getItem.SK, "Are you sure you want to continue?", getItem.TemplateUrlPath, "isDelete", getItem.BucketName, getItem.RootFolder),
            },
            );
        }
        if (props.RoleData?.EnableCustomCertificate && getItem.IsDisabled) {
            actionList.push({
                id: 5,
                Color: "text-yellow-600",
                Icon: "fa-solid fa-tent-arrow-turn-left bg-yellow-100 text-yellow-600 w-6",
                name: "Enable Certificate",
                action: () =>
                    popup("Enable", getItem.PK, getItem.SK, "Are you sure you want to continue?", getItem.TemplateUrlPath, "Enable", "", ""),
            },
            );
        }
        return actionList;
    }, [router, props]);


    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData?.map((getItem, index) => {
            !getItem.IsDeleted && rowGrid.push({
                PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
                SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="PK" text={getItem.SK} />),
                TemplateName: (<NVLlabel id={"lblFieldType" + (index + 1)} text={getItem.TemplateName} />),
                TemplateDescription: (<NVLlabel id={"lblFieldName" + (index + 1)} text={getItem.TemplateDescription} />),
                Action: !getItem.IsDisabled ? (
                    <NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal>) : (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal>),
            });
        });
        return rowGrid;
    }, [actionRestriction]);

    const deleteField = async (e) => {
        e.preventDefault();
        let suspend = true;
        if (popupValues.Action == "isDelete") {
            const authToken = await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken());
            const deleteCertificate = await fetch(process.env.APIGATEWAY_URL_DELETE_OBJECT_URL + "?ObjectUrl=" + popupValues.ObjectUrl + "&S3BucketName=" + popupValues?.BucketName + "&S3KeyName=" + popupValues?.RootFolder + "/" + popupValues?.PK.split("#")[1], {
                method: "GET", headers: { "Content-Type": "application/text", authorizationToken: authToken, defaultrole: props.TenantInfo.UserGroup, groupmenuname: "SiteConfiguration", menuid: "601304" },
            });
            await deleteCertificate.text();
            const variables = { input: { PK: popupValues.PK, SK: popupValues.SK, IsDeleted: true, }, };
            await AppsyncDBconnection(updateXlmsCustomCertificate, variables, props.user.signInUserSession.accessToken.jwtToken);
            resetPopUp();
            return;
        } else if (popupValues.Action == "Enable") {
            suspend = false;
        }
        const variables = { input: { PK: popupValues.PK, SK: popupValues.SK, IsDisabled: suspend, } };
        const finalResult = await AppsyncDBconnection(updateXlmsCustomCertificate, variables, props.user.signInUserSession.accessToken.jwtToken);
        if (finalResult.Status == "Success") {
            resetPopUp();
        }
    };

    const handleUrl = (data) => {
        if (data.ddlSearch != "") {
            router.push(`CustomCertificateInfo?Mode=Create&TenantID=${data.ddlSearch}&0`);
        } else {
            validationSchema.validate();
        }
    };

    const resetPopUp = useCallback(() => {
        setPopupValues({ PK: "", SK: "", Content: "", Action: "", ObjectUrl: "", });
        setIsRefreshing((temp) => { return (temp + 1); });
    }, []);


    function popup(Action, PK, SK, Content, ObjectUrl, type, BucketName, RootFolder) {
        setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type, ObjectUrl: ObjectUrl, Action: Action, BucketName: BucketName, RootFolder: RootFolder });
    }

    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Custom Certificate " }];
    }, []);

    return (
        <>
            <form>
                <Container PageRoutes={pageRoutes} loader={data?.tenantID == undefined} >
                    <NVLHeader LinkName1="Add Custom Certificate" TabRouting={props?.GeneralRoleData?.AllowNewTab} IsNestedHeader className1={props.RoleData?.CreateCustomCertificate ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectHome={"/SiteConfiguration/SiteConfigSettings"} href1={watch("ddlSearch") != "" && watch("ddlSearch") != undefined ? `CustomCertificateInfo?TenantID=${watch("ddlSearch")}}` : ""} RedirectAction1={handleSubmit((data) => handleUrl(data, "/"))} placeholder={"Search by Company Name/Email"} TableID={"tblCustomField"} IsDropdown={true} DropdownData={dropdownData} IsDropdownDisable={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} DropdownRequired={true} errors={errors} register={register} />
                   { (watch("ddlSearch") != undefined && watch("ddlSearch") != "") && <NVLGridTable user={props.user} refershPage={isRefreshing} id="tblCustomField" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsDisableCustomCertificate} querryName={"listXlmsDisableCustomCertificate"} variable={variable.current} />}
                    <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => deleteField(e)} CancelClick={() => resetPopUp()} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
                </Container>
            </form>
        </>
    );
}
export default CustomCertificateList;