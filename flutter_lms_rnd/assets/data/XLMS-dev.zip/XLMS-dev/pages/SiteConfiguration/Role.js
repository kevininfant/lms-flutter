import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLMultilineTxtBox from "@components/Controls/NVLMultilineTxtBox";
import NVLNoImage from "@components/Controls/NVLNoImage";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import Tree from "@components/MultiTreeCheckBox/Tree/Tree";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { getXlmsTenantCustomRoleInfo, getXlmsTenantInfo, listXlmsActiveRolesAndPermissions, listXlmsRolesAndPermissions, listXlmsTenantCheckCustomRoleInfos, listXlmsTenantRoleInfos } from "src/graphql/queries";
import * as Yup from "yup";

function Role(props) {
    const router = useRouter();
    const previousInputValue = useRef({
        txtCustomRoleName: { "value": "", "state": false },
        ddlExistingRole: { "value": "", "state": false }
    });
    const [getPageData, setPageData] = useState({});
    const [currentRole, setRole] = useState();
    const [modalValues, setModalValues] = useState({
        ModalInfo: getPageData?.mode === "Edit" || getPageData?.mode === "Delete" ? "Success" : "Info",
        ModalType:
            getPageData?.mode === "Edit" || getPageData?.mode === "Delete" ? "Success" : "Info",
        ModalTopMessage:
            getPageData?.mode === "Edit" || getPageData?.mode === "Delete"
                ? "Success"
                : "Info",
        ModalBottomMessage:
            getPageData?.mode === "Edit"
                ? "Details have been saved successfully."
                : getPageData?.mode === "Delete"
                    ? "Details have been Delete successfully."
                    : "Creation is in progress. Will contact you once the creation is over",
        ModalOnClickEvent: () => {
            router.push("/SiteConfiguration/Rolelist");
        },
    });

    const roleDropdownData = useMemo(() => {
        const temp = [{ value: "", text: "User Existing Role Name" }];
        if (getPageData?.roleData?.length > 0) {
            getPageData?.roleData.map((getItem) => {
                temp.push({ value: getItem.SK, text: getItem.RoleName });
            });
        }
        return temp;
    }, [getPageData]);

    const validationSchema = Yup.object().shape({
        txtCustomRoleName: Yup.string() .required("Role Name is required")
            .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Role Name is invalid")
           .min(4, "Role Name should be greater than 3 characters")
           .max(250,"Maximum 250 characters exceed")
            .test("name", "Role Name already exists", async (e) => {
                if (getPageData?.mode != "Edit" && getPageData?.mode != "Delete") {
                    const roleLowerCase = e.toLowerCase();
                    if (e == "") {
                        return previousInputValue.current.txtCustomRoleName["state"];
                    }

                    if (previousInputValue.current.txtCustomRoleName["value"] != undefined && e.toLowerCase() == previousInputValue.current.txtCustomRoleName["value"]) {
                        previousInputValue.current.txtCustomRoleName["value"] = e.toLowerCase();
                        return previousInputValue.current.txtCustomRoleName["state"];
                    }
                    if (roleLowerCase.length > 3) {
                        const fetchRoleExistCheck = await AppsyncDBconnection(
                            listXlmsTenantCheckCustomRoleInfos,
                            {
                                PK: "TENANT#" + getPageData?.TenantID,
                                SK: "CUSTOMROLE#",
                                RoleNameDisplay: roleLowerCase
                            }, props.user.signInUserSession.accessToken.jwtToken
                        );

                        if (fetchRoleExistCheck?.res?.listXlmsTenantCheckCustomRoleInfos.items.length > 0) {
                            previousInputValue.current.txtCustomRoleName["value"] = e.toLowerCase();
                            previousInputValue.current.txtCustomRoleName["state"] = false;
                            return false;
                        }
                    }
                }
                previousInputValue.current.txtCustomRoleName["value"] = e.toLowerCase();
                previousInputValue.current.txtCustomRoleName["state"] = true;
                return true;
            }),
        ddlExistingRole: Yup.string()
            .required("Existing Role Name is required")
            .test("novalid", "", async (e) => {
                if (e == "") {
                    return previousInputValue.current.ddlExistingRole["state"];
                }

                if (!(getPageData?.mode === "Edit" || getPageData?.mode === "Delete")) {
                    const getSk = "ROLE#" + document.getElementById("ddlExistingRole").options[
                        document.getElementById("ddlExistingRole").selectedIndex].text;
                    ddlHandlerRole(getSk);
                }
                previousInputValue.current.ddlExistingRole["value"] = e;
                previousInputValue.current.ddlExistingRole["state"] = true;
                return true;
            }),
    }
    );

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, reset, watch, setValue, formState } = useForm(formOptions,);
    const { errors } = formState;

    useEffect(() => {
        if (getPageData?.mode === "Edit" || getPageData?.mode == "Delete") {
            if (!getPageData?.CustomRoleData.IsDefault) {
                setValue("txtCustomRoleName", getPageData?.CustomRoleData?.CustomRoleName);
                ddlHandlerRole("ROLE#" + getPageData?.CustomRoleData?.CustomRoleName);
            }
            else {
                setValue("txtCustomRoleName", getPageData?.CustomRoleData.RoleName);
                ddlHandlerRole("ROLE#" + getPageData?.CustomRoleData.RoleName);
            }
            setValue("txtRoleDesc", getPageData?.CustomRoleData?.CustomRoleDescription || getPageData?.CustomRoleData?.RoleDescription);
            setValue("ddlExistingRole", "ROLEINFO#" + getPageData?.CustomRoleData.RoleName);
        }
    }, [getPageData?.mode, ddlHandlerRole, getPageData?.CustomRoleData, setValue]);

    const ddlHandlerRole = useCallback(async (SK) => {
        if (currentRole != SK) {
            setRole(SK);
            const getPk = "TENANT#" + getPageData?.TenantID + "#PLAN#" + getPageData?.PlanCode + "#STARTDATE#" + getPageData?.StartDate;
            if (getPk != "" && SK != "") {
                const existingData = await AppsyncDBconnection(
                    (getPageData?.mode == "Create" ? listXlmsActiveRolesAndPermissions : listXlmsRolesAndPermissions),
                    getPageData?.mode == "Create" ? { PK: getPk, SK: SK, ActionAllow: true } : { PK: getPk, SK: SK },
                    props.user.signInUserSession.accessToken.jwtToken);
                const temprole = (getPageData?.mode == "Create") ? existingData.res.listXlmsActiveRolesAndPermissions?.items : existingData.res.listXlmsRolesAndPermissions.items;

                if (temprole != null || temprole != 0) {
                    existingDataHandler(temprole);
                }
            }
        }
    }, [currentRole, getPageData?.TenantID, getPageData?.PlanCode, getPageData?.StartDate, getPageData?.mode, props.user.signInUserSession.accessToken.jwtToken, existingDataHandler]);

    const existingDataHandler = useCallback((temprole) => {
        bindCheckboxTree(temprole);
    }, []);

    const submitHandler = async (data) => {
        setValue("submit", true);
        const dateTime = new Date();
        const checkboxtreeData = RoleDataGet(dateTime, data, getPageData.CustomFeatureList);
        const createEditBy = getPageData?.mode == "Edit" ? "LastModifiedBy" : getPageData?.mode == "Delete" ? "LastModifiedBy" : "CreatedBy";
        const createEditDt = getPageData?.mode == "Edit" ? "LastModifiedDate" : getPageData?.mode == "Delete" ? "LastModifiedDate" : "CreatedDate";

        const description = data.txtRoleDesc?.replace(/\s+/g, " ") == undefined ? "" : data.txtRoleDesc?.replace(/\s+/g, " ");
        /* // eslint-disable-next-line quotes */
        const jsonData = '{' + '"Group":{"TenantID": "' + getPageData?.TenantID + '","TenantName": "' + getPageData?.TenantName + '",  "CustomRoleName": "' + data.txtCustomRoleName.replace(/ /g, '') + '", "CustomRoleDescription": "' + description + '", "' + createEditBy + '": "' + props.user.username + '", "' + createEditDt + '": "' + dateTime + '",  "StatusFlag":"Live" ,  "RoleName":"' + data.ddlExistingRole.split("#")[1] + '"},"Role":' + JSON.stringify(checkboxtreeData) + '}';
        const stateMachineArn = (getPageData?.mode == "Edit" ? process.env.STEP_FUNCTION_ARN_ROLE_PERMISSION_EDIT : getPageData?.mode == "Delete" ? process.env.STEP_FUNCTION_ARN_ROLE_PERMISSION_DELETE : process.env.STEP_FUNCTION_ARN_ROLE_PERMISSION_CREATION);
        const menuID = (getPageData?.mode == "Edit" ? "600702" : getPageData?.mode == "Delete" ? "600703" : "600701");
        await fetch(process.env.APIGATEWAY_URL_ROLE_PERMISSION_CREATION, {
            method: "POST",
            headers: {
                'Content-Type': "application/json",
                statemachinearn: stateMachineArn,
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                defaultrole: props?.TenantInfo.UserGroup,
                groupmenuname: "SiteConfiguration",
                menuid: menuID,
            },
            body: jsonData,
        })
            .then(() => {
                {
                    setModalValues({
                        ModalInfo: getPageData?.mode === "Edit" || getPageData?.mode === "Delete" ? "Success" : "Info",
                        ModalType: getPageData?.mode === "Edit" || getPageData?.mode === "Delete" ? "Success" : "Info",
                        ModalTopMessage: getPageData?.mode === "Edit" || getPageData?.mode === "Delete" ? "Success" : "In Progress",
                        ModalBottomMessage: getPageData?.mode === "Edit" ? "Details have been saved successfully." : getPageData?.mode === "Delete" ? "Details have been Deleted successfully." : "Creation is in progress. Will contact you once the creation is over",
                        ModalOnClickEvent: () => { router.push("/SiteConfiguration/Rolelist"); },
                    }),
                        ModalOpen();
                }
            })
            .catch(() => {
                setModalValues({
                    ModalInfo: "Danger",
                }),
                    ModalOpen();
            });
        setValue("submit", false);
    };

    function resetValues() {
        setRole(crypto.randomUUID());
        reset();
        setPageData((data) => {
            return ({ ...data, CustomFeatureList: [], CustomRole: [], Items: [] });
        });
    }

    /* Role And Permission Start */
    function RoleDataGet(dateTime, data, ActionValue) {
        const parentMenuData = getPageData.CustomRole;
        parentMenuData?.map((e) => {
            const actAllow = ActionValue.find(({ SK }) => SK === e.SK);
            e.ActionAllow = actAllow.state;
            e.SK = getPageData?.mode == "Create" ? "ROLE#" + data.txtCustomRoleName.replace(/ /g, "") + "#GrpMenu#" + e.FeatureName + "#MenuID#" + e.MenuID : e.SK;
            e.RoleName = data.txtCustomRoleName.replace(/ /g, "");
            e.CreatedDate = dateTime;
            e.CreatedBy = props.user.username;
            e.LastModifiedBy = props.user.username;
            e.LastModifiedDate = dateTime ;
        });
        return parentMenuData;
    }

    const bindCheckboxTree = (SampleDatas) => {
        const treeViewArrived = [];
        SampleDatas?.forEach(element => {
            treeViewArrived.push({
                "id": parseInt(element.MenuID),
                "name": element.Action,
                "parentId": parseInt(element.RelationID),
                "state": element.ActionAllow,
                "SK": element.SK
            });
        });

        const removeDuplicateData = [...new Map(treeViewArrived?.map(item => [item["SK"], item])).values()];
        setPageData((data) => {
            return ({ ...data, CustomFeatureList: removeDuplicateData, CustomRole: SampleDatas, Items: removeDuplicateData });
        });
    };
    const TreeView = useCallback((props) => {
        return (
            <Tree items={props?.Items != undefined ? props?.Items : []} setPageData={setPageData} />
        );
    }, []);

    useEffect(() => {
        const fetchData = async (i) => {
            const tenantResponse = await AppsyncDBconnection(getXlmsTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" + router.query["TenantID"] }, props?.user.signInUserSession.accessToken.jwtToken);
            const roleResponse = await AppsyncDBconnection(listXlmsTenantRoleInfos, { PK: "TENANT#" + router.query["TenantID"], SK: "ROLEINFO#" }, props?.user.signInUserSession.accessToken.jwtToken);
            const customRoleData = await AppsyncDBconnection(getXlmsTenantCustomRoleInfo, { PK: "TENANT#" + router.query["TenantID"], SK: "CUSTOMROLE#" + router.query["RoleName"], }, props?.user.signInUserSession.accessToken.jwtToken);
            const roleGridData = await AppsyncDBconnection(listXlmsRolesAndPermissions, { PK: "TENANT#" + router.query["TenantID"] + "#PLAN#" + router.query["PlanCode"] + "#STARTDATE#" + router.query["StartDate"], SK: "ROLE#" + router.query["RoleName"] + "#GrpMenu#", }, props?.user.signInUserSession.accessToken.jwtToken);
            const temp = {
                roleData: roleResponse.res.listXlmsTenantRoleInfos?.items,
                roleGridData: roleGridData.res.listXlmsRolesAndPermissions?.items,
                CustomRoleData: customRoleData.res.getXlmsTenantCustomRoleInfo,
                TenantID: tenantResponse.res.getXlmsTenantInfo?.TenantID,
                TenantName: tenantResponse.res.getXlmsTenantInfo?.TenantName,
                CustomRoleName: router.query["RoleName"],
                mode: router.query["mode"],
                PlanCode: tenantResponse.res.getXlmsTenantInfo?.PlanCode,
                StartDate: tenantResponse.res.getXlmsTenantInfo?.StartDate,
            };
            setPageData(temp);
        };
        fetchData();
        return (() => {
            setPageData((temp) => { return { ...temp }; });
        });
    }, [props?.user.signInUserSession.accessToken.jwtToken, router.query]);
    /* Role And Permission End */
    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "/SiteConfiguration/Rolelist", breadcrumb: "Permission & Role Management" },
            { path: "", breadcrumb: getPageData?.mode == "Edit" ? "Edit Permission & Role" : getPageData?.mode == "Delete" ? "Delete Permission & Role Management" : "Add New Roles" }
        ];
    }, [getPageData?.mode]);


    return (
        <>
            <Container loader={getPageData?.TenantID == undefined} title="Role" PageRoutes={pageRoutes}>
                <form onSubmit={handleSubmit(submitHandler)} className={`${ watch("submit") ? "pointer-events-none" : "px-2"}`}>
                    <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                    <div className="nvl-FormContent">
                        <NVLTextbox labelText={"User Role Name"} title={"Enter Role Name"} labelClassName={"nvl-Def-Label"} errors={errors} register={register} id="txtCustomRoleName" disabled={getPageData?.mode == "Edit" && true} className={getPageData?.mode != "Create" ? "Disabled placeholder:px-0 nvl-mandatory nvl-Def-Input" : "placeholder:px-0 nvl-mandatory nvl-Def-Input"} placeholder="User Role Name" ></NVLTextbox>
                        <NVLSelectField labelText={"User Existing Role Name"} labelClassName={`nvl-Def-Label ${getPageData?.CustomRoleData?.IsDefault != undefined && getPageData?.CustomRoleData?.IsDefault ? "hidden" : ""}`} errors={errors} register={register} id="ddlExistingRole" disabled={getPageData?.mode != "Create" ? true : false} required className={getPageData?.mode != "Create" ? `Disabled nvl-mandatory nvl-Def-Input ${getPageData?.CustomRoleData?.IsDefault ? "!hidden" : ""}` : "nvl-mandatory nvl-Def-Input"} options={roleDropdownData}></NVLSelectField>
                        <NVLMultilineTxtBox labelText={"Role Description"} title={"Enter Role Description"} labelClassName={"nvl-Def-Label"} errors={errors} register={register} id="txtRoleDesc" disabled={getPageData?.mode == "Delete" ? true : false} className={getPageData?.mode == "Delete" ? "Disabled nvl-Def-Input nvl-non-mandatory" : "nvl-Def-Input nvl-non-mandatory"} placeholder="Role Description" ></NVLMultilineTxtBox>
                    </div>

                    <div>
                        <div className=" flex flex-row gap-1 justify-center p-4 w-5/7 mx-auto bg-gray-100">
                            {getPageData.Items && getPageData.Items?.length > 0 ? (<TreeView Items={getPageData.Items} />) : (
                                <NVLNoImage
                                    id="NoRecord"
                                    className="nvl-Def-Input"
                                    alignItem={"center"}
                                />
                            )}
                        </div>
                    </div>
                    <div
                        className={"Center-Aligned-Item flex flex-row gap-1 justify-center pt-2"}
                    >
                        <NVLButton
                            id="btnSubmit"
                            text={!watch("submit") ?
                                (getPageData?.mode == "Edit"
                                    ? "Save Changes"
                                    : getPageData?.mode == "Delete"
                                        ? "Delete"
                                        : "Submit")
                                : ""

                            }
                            type="submit"
                            disabled={watch("submit") ? true : false}
                            className={
                                watch("submit") ? (
                                    getPageData?.mode == "Create" || getPageData?.mode == "Edit"
                                        ? "w-32 nvl-button bg-primary text-white "
                                        : getPageData?.mode == "Delete"
                                            ? "w-28 nvl-button  bg-red-500 text-white "
                                            : "")
                                    : "w-40 nvl-button text-center  bg-primary text-white"}>{watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}
                        </NVLButton>
                        <NVLButton
                            id="btnCancel"
                            text={getPageData?.mode == "Create" ? "Clear" : "Cancel"}
                            type="reset"
                            className="nvl-button w-28"
                            onClick={() =>
                                getPageData?.mode != "Create"
                                    ? router.push("/SiteConfiguration/Rolelist")
                                    : resetValues()
                            }
                        ></NVLButton>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default Role;