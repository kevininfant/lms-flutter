import Container from "@components/Container/Container";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";


function ThirdPartyConfigSettings(props) {
  const PK = "XLMS#TENANTINFO";
  const SK = "#TENANT#" + props.TenantId;

  const router = useRouter();

  const CardsList = [
    props.RoleData?.Zoom ? { id: "1", CardName: "Zoom", CardIcon: <i className="fa fa-solid fa-pen-ruler text-5xl" />, ActionUrl: () => router.push(`/SiteConfiguration/ThirdPartyConfigApplication?ApplicationType=${"Zoom"}`) } :"",
    props.RoleData?.GoogleMeet ? { id: "2", CardName: "Google Meet", CardIcon: <i className="fa fa-brands fa-google text-5xl"></i>, ActionUrl: () => router.push(`/SiteConfiguration/ThirdPartyConfigApplication?ApplicationType=${"GoogleMeet"}`) } :"",];

  const [PageData, setPageData] = useState({});
  useEffect(() => {
    const fetchData = async (i) => {
      let TentID = props.user.attributes["custom:tenantid"];

      const temp = {
        TenantId: TentID != undefined ? TentID : "",
      }
      setPageData(temp);
    }
    fetchData();
    return (() => {
      setPageData((temp) => { return { ...temp } });
    })
  }, [props.user.attributes]);

  const PageRoutes = useMemo(()=>{return [
    { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
    { path: "", breadcrumb: "Third Party Configuration" }
  ];},[])
  return (
    <>
      <Container PageRoutes={PageRoutes} loader={PageData?.TenantId == undefined} title="Third Party Config Settings">
        <div className="grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-4 gap-4">
          {CardsList &&
            CardsList.map((getItem, index) => {
              return (
                <div key={index}>
                  <NVLSettingsCard CardIcon={getItem.CardIcon} CardName={getItem.CardName} onClick={getItem.ActionUrl} />
                </div>
              );
            })}
        </div>
      </Container>
    </>
  );
}

export default ThirdPartyConfigSettings;
