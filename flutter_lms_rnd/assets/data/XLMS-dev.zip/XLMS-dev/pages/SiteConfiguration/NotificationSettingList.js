import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import NVLToggle from "@components/Controls/NVLToggle";
import Container from "@Container/Container";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXLMSDefaultNotificationTemplate } from "src/graphql/mutations";
import { getXLMSDefaultNotificationTemplate, listXlmsActiveTenantInfo, listXLMSDefaultNotificationTemplates } from "src/graphql/queries";
import * as Yup from "yup";

export default function NotificationList(props) {
    const [getData, setData] = useState([]);
    const [isRefreshing, setIsRefreshing] = useState(0);
    const router = useRouter();

    useEffect(() => {
        const dataSource = async () => {
            const tenantResponse = await AppsyncDBconnection(
                listXlmsActiveTenantInfo,
                { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false },
                props.user?.signInUserSession?.accessToken?.jwtToken
            );
            setData({
                TenantList: tenantResponse?.res?.listXlmsActiveTenantInfo?.items,
                TenantID: props?.user.attributes["custom:tenantid"] != undefined ? props?.user.attributes["custom:tenantid"] : "",
            });
        };
        dataSource();
        return (() => {
            setData((temp) => { return { ...temp }; });
        });

    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken]);
    const variable = useRef({ PK: "TENANT#" + ((props.TenantInfo.UserGroup != "SiteAdmin") ? props.TenantInfo.TenantID : ""), SK: "DEFAULTTEMPLATE#", });
    const headerColumn = [
        { HeaderName: "Notification Template Name", Columnvalue: "TemplateName", HeaderCss: "w-3/12", },
        { HeaderName: "Enable For Web", Columnvalue: "EnableForWeb", HeaderCss: "w-2/12", },
        { HeaderName: "Enable For Mail", Columnvalue: "EnableForMail", HeaderCss: "w-3/12", },
        { HeaderName: "Enable For Mobile", Columnvalue: "EnableForMobile", HeaderCss: "w-3/12", },
        { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
    ];
    const validationSchema = Yup.object().shape({
        ddlSearch:
            props.TenantInfo.UserGroup == "SiteAdmin"
            && Yup.string()
                .required("Please Select The Field")
                .test("NOValid", "ChangeHandler", (e) => {

                    variable.current = { PK: "TENANT#" + e, SK: "DEFAULTTEMPLATE#" };
                    setIsRefreshing((count) => {
                        return count + 1;
                    });
                    return true;

                })

    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
    const { register, formState, handleSubmit, setValue, watch } = useForm(formOptions);
    const { errors } = formState;

    const dropdownData = useMemo(() => {
        let CurrentTenant = [];
        const temp = [{ value: "", text: "Select Company" }];
        if (getData?.TenantList != undefined) {
            if (getData?.TenantList.length > 2 && props.TenantInfo.UserGroup == "SiteAdmin") {
                getData?.TenantList.map((getItem) =>
                    temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }),
                );
            } else if (props.TenantInfo.UserGroup != "SiteAdmin" && props.TenantInfo.UserGroup != undefined) {
                variable.current = { PK: "TENANT#" + getData.TenantID, SK: "DEFAULTTEMPLATE#" };
                setIsRefreshing((count) => {
                    return count + 1;
                });
                CurrentTenant = getData?.TenantList.filter(function (Tenant) {
                    return Tenant.TenantID == getData.TenantID;
                });
                CurrentTenant.map((getItem) => {
                    temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, });
                });
                setValue("ddlSearch", getData.TenantID, { shouldValidate: true });
            }
        }
        return temp;

    }, [getData.TenantID, getData?.TenantList, props.TenantInfo.UserGroup, setValue]);

    const toggleHandler = useCallback(async (event, getItem, ToggleAction) => {
        const query = getXLMSDefaultNotificationTemplate;
        let variablesWeb = {
            PK: getItem.PK,
            SK: getItem.SK,
        };
        const temp = await AppsyncDBconnection(query, variablesWeb, props?.user?.signInUserSession?.accessToken?.jwtToken);

        if (temp.Status == "Success") {
            const updatevariable = temp.res.getXLMSDefaultNotificationTemplate;
            const currentToggleName = ToggleAction == "IsWeb" ? "Web" : ToggleAction == "IsMail" ? "Mail" : ToggleAction == "IsMobile" ? "Mobile" : "";
            variablesWeb = { input: { ...updatevariable, IsEnableForWeb: event.target.checked, LastModifiedDate: new Date() }, };
            const variablesMail = { input: { ...updatevariable, IsEnableForMail: event.target.checked, LastModifiedDate: new Date() }, };
            const variablesMobile = { input: { ...updatevariable, IsEnableForMobile: event.target.checked, LastModifiedDate: new Date() }, };

            const finalvariables = currentToggleName == "Web" ? variablesWeb : currentToggleName == "Mail" ? variablesMail : currentToggleName == "Mobile" ? variablesMobile : "";
            AppsyncDBconnection(updateXLMSDefaultNotificationTemplate, finalvariables, props?.user?.signInUserSession?.accessToken?.jwtToken);
        }
    }, [props?.user?.signInUserSession?.accessToken?.jwtToken]);

    const actionRestriction = useCallback((getItem) => {
        const actionList = [];
        if (props.RoleData?.EditNotificationTemplateSetting) {
            actionList.push({
                id: 1,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit Notification",
                action: () =>
                    router.push(`/SiteConfiguration/EditNotificationSetting?mode=Edit&PK=${encodeURIComponent(getItem.PK)}&SK=${encodeURIComponent(getItem.SK)}`),
            });
        }
        if (props.RoleData?.ViewNotificationTemplateSetting) {
            actionList.push({
                id: 2,
                Color: " text-blue-700 ",
                Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
                name: "View Notification",
                action: () =>
                    router.push(`/SiteConfiguration/ViewNotificationSetting?mode=View&PK=${encodeURIComponent(getItem.PK)}&SK=${encodeURIComponent(getItem.SK)}`),
            });
        }
        return actionList;
    },
        [router, props]
    );

    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData &&
            viewData.map((getItem, index) => {
                let ActionList = [];
                ActionList = actionRestriction(getItem);
                rowGrid.push({
                    SNo: (
                        <NVLlabel id={"lblSNo" + (index + 1)} name="SNo" text={index + 1} />
                    ),
                    TemplateName: (
                        <NVLlabel id={"txtTemplateName#" + (index + 1)} text={getItem.TemplateName} showFull />
                    ),
                    EnableForWeb: (
                        <NVLToggle id={"ChkIsWeb#" + (index + 1)} defaultChecked={getItem.IsEnableForWeb} name="IsWeb" onChange={(event) => toggleHandler(event, getItem, "IsWeb", index)} />
                    ),
                    EnableForMail: (
                        <NVLToggle id={"ChkIsMail#" + (index + 1)} defaultChecked={getItem.IsEnableForMail} name="IsMail" onChange={(event) => toggleHandler(event, getItem, "IsMail", index)} />
                    ),
                    EnableForMobile: (
                        <NVLToggle id={"ChkIsMobile#" + (index + 1)} defaultChecked={getItem.IsEnableForMobile} name="IsMobile" onChange={(event) => toggleHandler(event, getItem, "IsMobile", index)} />
                    ),
                    IsSuspend: (
                        <>
                            <div className="flex m-auto w-full" title={getItem.IsSuspend ? "Inactive" : "Active"}>
                                <div className={`rounded-full my-auto h-3 w-3 ${getItem.IsSuspend ? "bg-red-500" : "bg-green-600"}	`}></div>
                                <NVLlabel className={`${getItem.IsSuspend ? "text-red-500" : "text-green-600"} my-auto ml-2	`} text={!getItem.IsSuspend ? "Active" : "Inactive"} />
                            </div>
                        </>
                    ),
                    Action: (
                        <NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={ActionList} />
                    ),
                });
            });
        return rowGrid;
    },
        [actionRestriction, toggleHandler]
    );

    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Notification Setting" }

        ];
    }, []);

    const handleUrl = (data) => {
        if (data.ddlSearch != "" || data.ddlSearch != undefined) { router.push(`/SiteConfiguration/CustomNotificationList?TenantID=${(props.TenantInfo.UserGroup == "SiteAdmin" ? watch("ddlSearch") : props.TenantInfo.TenantID)}`); }
        else {
            validationSchema.validate();
        }
    };
    return (
        <>

            <Container PageRoutes={pageRoutes} loader={getData.TenantID == undefined} >
                <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab}
                    LinkName2="Custom Notification"
                    className2={props.RoleData?.CustomTemplateNotification ? props.TabRouting == true ? "" : "nvl-button-success" : "hidden"}
                    href2={watch("ddlSearch") != "" || watch("ddlSearch") != undefined ? `/../SiteConfiguration/CustomNotificationList?TenantID=${(props.TenantInfo.UserGroup == "SiteAdmin" ? watch("ddlSearch") : props.TenantInfo.TenantID)}` : ""}
                    RedirectAction2={handleSubmit((data) => handleUrl(data, "/"))}
                    TableID={"tblCustomlist"}
                    IsNestedHeader
                    IsDropdown={true}
                    errors={errors}
                    register={register}
                    DropdownData={dropdownData}
                    IsDropdownDisable={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false}
                    DropdownRequired={true} />
                {(watch("ddlSearch") != undefined && watch("ddlSearch") != "") && <NVLGridTable user={props.user} refershPage={isRefreshing} id="tblUserList" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query=
                    {listXLMSDefaultNotificationTemplates} PaginationReq={false} RowGridDataPass={{ rowGrid: [] }} pageSize={500}
                    querryName={"listXLMSDefaultNotificationTemplates"} variable={variable.current} />}
            </Container>
        </>
    );
}
