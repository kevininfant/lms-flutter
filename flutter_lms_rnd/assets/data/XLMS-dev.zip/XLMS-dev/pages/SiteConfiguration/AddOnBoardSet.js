import Container from "@components/Container/Container";
import NVLMultiSelect from "@components/Controls/NVLMultiSelect";
import NVLRadio from "@components/Controls/NVLRadio";
import { listXlmsCourseManagementInfo, listXlmsCourseSubCategory } from "@graphql/graphql/queries";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import AddOptionOnBoard from "pages/SiteConfiguration/AddOptionOnBoard";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

export default function AddOnboardSet({ props, id, data, data1, handleSubmit, onboardjson, setJsonData, setSubmit, submit, errors, setValue, watch, register, onboardLength }) {
  const [selectedCourseData, setselectedCourseData] = useState([])
  const [afterCourseData, setafterCourseData] = useState([])
  const [multiselectedcategory, setMultiSelectedCategory] = useState([]);
  const [aftercategory, setAfterCategory] = useState([]);
  const [currentDiv, setCurrentDiv] = useState("User");
  const [fetchList, setFetchList] = useState()
  const [restrictionLength, setRestrictionLength] = useState(1)
  const [onBoardoptionslength, setOnBoardOptionlength] = useState(() => {
    if (onboardjson?.for?.length > 0) {
      return onboardjson?.for.length;
    }
    return 1;
  });
  useEffect(() => {
    async function categoryFetch() {

      const categoryResponse = await AppsyncDBconnection(listXlmsCourseSubCategory, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSECATEGORY#", IsDeleted: false, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const courseResponse = await AppsyncDBconnection(listXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSEINFO#", IsDeleted: false, }, props?.user?.signInUserSession?.accessToken?.jwtToken);
      const fetchedCategoryData = categoryResponse.res?.listXlmsCourseSubCategory?.items != undefined ? categoryResponse.res?.listXlmsCourseSubCategory?.items : [];
      const fetchedCourseData = courseResponse.res?.listXlmsCourseManagementInfo?.items != undefined ? courseResponse.res?.listXlmsCourseManagementInfo?.items : [];
      const categoryList = [];
      const categoryFiltered = fetchedCategoryData?.filter(
        (obj) => !categoryList[obj.CategoryID] && (categoryList[obj.CategoryID] = true)
      );
      setFetchList({ CategoryList: categoryFiltered, CourseList: fetchedCourseData })
    }
    categoryFetch()
  }, [props.TenantInfo.TenantID, props?.user?.signInUserSession?.accessToken?.jwtToken, watch])


  // const validationSchema = Yup.object().shape({

  //   ddlCategory: Yup.string().test("", "", (e, { createError }) => {
  //     if (e != " ") {
  //       if ((e == "NoData" || e == undefined) && multiselectedcategory?.length == 0) return createError({ message: "Select Category" });

  //     }
  //     return true

  //   }).nullable(),

  //   ddlCourse: Yup.string().test("", "", (e, { createError }) => {
  //     if (e != "") {
  //       if ((e == "NoData" || e == undefined) && selectedCourseData?.length == 0) return createError({ message: "Select Course" });
  //     }
  //     return true


  //   }).nullable(),
  //   EnrollCourseDuration: Yup.string().required("Enroll Course Duration is required").matches(Regex("AllowOnlyNumbers"), "Enroll Course Duration is invalid").test("", "", (e, { createError }) => {
  //     if (e != "") {
  //       if (parseInt(e) == 0) return createError({ message: "Enroll Course Duration should be greater than zero" })
  //     }
  //     return true
  //   }).max(3, "Maximum limit exceeds").nullable()
  // })

  // const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
  // const { register, handleSubmit, setValue, reset, formState, watch, clearErrors } = useForm(formOptions);
  // const { errors } = formState;


  const MultiSelectListCategory = useMemo(() => {

    if (currentDiv == "User") {
      let MultiSelectListCategory = [];
      fetchList?.CategoryList && fetchList?.CategoryList.map((getItem) => {
        if (getItem.CategoryID) {
          MultiSelectListCategory.push({
            value: getItem.CategoryID,
            label: getItem.CategoryName,
            Name: getItem.CategoryName,

          });
        }
      });
      return MultiSelectListCategory;
    }
  }, [currentDiv, fetchList?.CategoryList])


  const finalJson = useRef({ RS: {} });

  const MultiSelectListCourse = useMemo(() => {
    if (currentDiv == "User") {

      let MultiSelectListCourse = [];
      fetchList?.CourseList && fetchList?.CourseList.map((getItem) => {
        if (getItem.CourseID) {
          MultiSelectListCourse.push({
            value: getItem.CourseID,
            label: getItem.CourseName,
            Name: getItem.CourseName
          });
        }
      });

      return MultiSelectListCourse;
    }
  }, [currentDiv, fetchList?.CourseList])

  const setData = useCallback((data, id) => {
    setValue("onBoardrs" + id, data)
    if (id != undefined && onboardLength != undefined) {
      if (id < onboardLength) {
        finalJson.current = { ...finalJson.current, RS: { ...finalJson.current.RS, ["RS" + (id)]: data } };

      }
      else {
        if (id != 0) {
          delete finalJson.current.RS["RS" + (id)];
        }
      }
    };

  }, [onboardLength, setValue]);
  const selectCategroy = useMemo(() => {
    if (multiselectedcategory?.length == 0) {
      return MultiSelectListCourse;
    }
    let finalList = [];
    for (let index = 0; index < multiselectedcategory?.length; index++) {

      let FilterValue = fetchList?.CourseList?.filter((item) => {
        return item?.CategoryID == multiselectedcategory?.[index]?.value;
      })
      finalList = [...finalList, ...FilterValue];
    }
    let FinalAns = []
    finalList?.filter((val) => {
      if (val.CourseID) {
        FinalAns.push({
          value: val.CourseID,
          label: val.CourseName,
          Name: val.CourseName
        });
      }
    });
    return FinalAns;

  }, [multiselectedcategory, MultiSelectListCourse, fetchList?.CourseList])
  const afterCourseCompletion = useMemo(() => {

    if (aftercategory?.length == 0) {
      // let myval = MultiSelectListCourse.filter((data) => selectedCourseData.every((item) => data.value != item.value))
      // let tamil = []
      // myval.filter((data) => {
      //   if (data.value) {
      //     tamil.push({
      //       value: data.value,
      //       label: data.label,
      //       Name: data.Name
      //     })
      //   }
      // }); console.log(tamil, "-------------------->");
      // return tamil;
      return MultiSelectListCourse;
    }
    let afterCourse = [];
    for (let i = 0; i < aftercategory?.length; i++) {

      let FilterAfterCourse = fetchList?.CourseList?.filter((data) => {

        let isCourseSelected = selectedCourseData?.[i]?.filter((item) => {
          return item?.value == data?.CourseID;
        }
        )

        return isCourseSelected?.length == 0 && data?.CategoryID == aftercategory?.[i]?.value;
      })
      afterCourse = [...afterCourse, ...FilterAfterCourse]
    }

    let FinalAfterCourse = []


    afterCourse?.filter((data) => {
      if (data.CourseID) {
        FinalAfterCourse.push({
          value: data.CourseID,
          label: data.CourseName,
          Name: data.CourseName

        });
      }
    });

    return FinalAfterCourse

  }, [MultiSelectListCourse, aftercategory, fetchList?.CourseList, selectedCourseData])
  const AddRestriction = useCallback((PageData) => {
    return (
      <>

        <div className=" flex w-70%">
          <div className="w-4/5 " >
            <>
              <AddOptionOnBoard
                setSubmit={PageData?.setSubmit}
                isOnboarding={PageData?.true}
                json={PageData?.json}
                id={PageData?.id}
                restrictionLength={PageData?.restrictionLength}
                setData={PageData?.setData}
                TenantInfo={PageData?.TenantInfo}
                user={PageData?.user}
                data={PageData?.data} />
            </>
            {
              PageData?.final && <div className="pt-2">
                <i className="fa-solid fa-trash text-red-600" onClick={() => {
                  setRestrictionLength((data) => {
                    delete finalJson.current.RS["RS" + (data - 1)];
                    return data - 1;
                  });
                }}></i>
              </div>
            }
          </div>

        </div>

      </>
    );
  }, []);



  const AddRestrictionLoop = useCallback((PageData) => {
    const rowGrid = [];
    for (let i = 0; i < PageData?.restrictionLength; i++) {
      rowGrid.push(<AddRestriction
        setSubmit={PageData?.setSubmit}
        key={i}
        restrictionLength={PageData?.restrictionLength}
        json={PageData?.finalJson.current.RS?.["RS" + i]}
        data={PageData?.data}
        id={PageData?.id}
        setData={PageData?.setData}
        final={i == PageData?.restrictionLength - 1 && PageData?.restrictionLength != 1 ? true : false}
        options={PageData?.options}
        TenantInfo={PageData?.TenantInfo} user={PageData?.user} />);
    }


    return <>{rowGrid}</>;
  }, []);

  // const setCategoryMultiSelect = useCallback((event, id) => {
  //   setMultiSelectedCategory((prev) => {
  //     return { ...prev, [id]: event }
  //   })

  // }, [])
  // console.log(multiselectedcategory);
  const setCourseMultiSelect = useCallback((event, id) => {
    setselectedCourseData((prev) => {
      return { ...prev, [id]: event }
    })
  }, [])

  const setAfterCourseMultiSelect = useCallback((event, id) => {
    setafterCourseData((prev) => {
      return { ...prev, [id]: event }
    })

  }, [])
  useEffect(() => {
    return (() => {

      getdataforonboard(data1);
      return data1;

    })
  }, [data1, getdataforonboard, id])
  useEffect(() => {
    if (data1 != 0) {
      handleSubmit((temp) => {

        getdataforonboard(data1);
        setSubmit((data) => {
          return { ...data, [id]: "okay" }
        })
        return data1

      }, () => {

        getdataforonboard(data1);
        setSubmit((data) => {
          return { ...data, [id]: "Error" };
        })
        return data1

      })();
    }
  }, [data1, getdataforonboard, handleSubmit, id, setSubmit])
 
 

  const getdataforonboard = useCallback((onBoardoptionslength, tempjson, temp,) => {
      
    let onboardjson = { values: [] }
    if (tempjson != undefined) {
      onboardjson = { ...tempjson };

    }
    else {
      if (temp != undefined) {
        onboardjson = { values: [] };
      }
      for (var i = 0; i < onBoardoptionslength; i++) {
        onboardjson = {
          ...onboardjson, values: [...onboardjson.values, {
            asnz: selectedCourseData, aftercourse: afterCourseData
          }],
        }
      }
      onboardjson = { ...onboardjson }
    }
    setJsonData(onboardjson, "" + id);
  }, [setJsonData, id, selectedCourseData, afterCourseData]);

  return (
    <>
      <Container title="OnBoarding"></Container>
      <form>
        <div className=" nvl-FormContent z-50 !w-[60%]  items-center justify-center">
          <div className="">
            <div >
              <div className="">
                <AddRestrictionLoop
                  id={id}
                  setSubmit={setSubmit}
                  restrictionLength={restrictionLength}
                  finalJson={finalJson}
                  data={data}
                  setData={setData}
                  TenantInfo={props?.TenantInfo}
                  user={props?.user}
                />
              </div>
            </div>
          </div>
          <label className={"pt-4 -mt-3  z-50"}><p className=" nvl-Def-Label pb-1">Filter By Category </p></label>
          <NVLMultiSelect id={"ddlCategory" + id}
            className={"w-96 nvl-mandatory"}
            options={MultiSelectListCategory} value={multiselectedcategory}
            onChange={(event) => {
              // setCategoryMultiSelect(event,"ddlCategory"+id)
              // clearErrors("ddlCategory")
              setMultiSelectedCategory(event);

            }} register={register} disabled={false} />
          <div className="block {invalid-feedback} text-red-500  text-sm">
            {errors.ddlCategory?.message}
          </div>


          <label className={"pt-4 "}><p className="nvl-Def-Label pb-1 ">Course</p>
            <NVLMultiSelect id={"ddlCourse" + id}
              className="w-96 nvl-mandatory" labelText="Course"
              // options={filterCourseData} value={selectedCourseData}
              options={selectCategroy} value={selectedCourseData?.["ddlCourse" + id]}

              onChange={(event) => {
                setCourseMultiSelect(event, "ddlCourse" + id)
                // clearErrors("ddlCourse")
                // setselectedCourseData(event);

              }} />
            <div className="block {invalid-feedback} text-red-500  text-sm">
              {errors.ddlCourse?.message}
            </div>
          </label>
          {/* <NVLTextbox id={"EnrollCourseDuration" + id} labelText="Enroll Course Duration (in Days)" labelClassName="nvl-Def-Label pb-1 " title="Enroll Course Duration" className={`nvl-mandatory nvl-Def-Input ${watch("obformm" + id) == true ? "Disabled " : ""}`} errors={errors} register={register} /> */}
        </div>
        <div>
          <br></br>
        </div>
        <div className=" ">
          <div className="nvl-FormContent z-30 !w-[60%] ">
            {/* <div className="grid place-content-around"> */}
            <div className="grid place-content-start">
              <label className="nvl-Def-Label pb-1 ">After Completion</label>
              <div className=" flex gap-8">
                <NVLRadio id={`obform` + id} name="obform" text="Yes" className={"checked:text-gray-400"} register={register} errors={errors} value="Yes" />
                <NVLRadio id={`obform` + id} name="obform" text="No" register={register} errors={errors} className={"checked:text-gray-400"} value="No" />
              </div>
            </div>
            <div className={watch("obform" + id) == "No" ? "Disabled w-3/5 px-3" : " bg-[#F9FAFC] shadow !w-3/5 px-3"}>
              <label className={"pt-4"}><p className="nvl-Def-Label pb-1">Filter By Category </p>
                <NVLMultiSelect id="ddlCategorySubCondition"
                  className="w-96 nvl-non-mandatory"
                  options={MultiSelectListCategory} value={aftercategory}
                  onChange={(event) => {
                    // clearErrors("ddlCategorySubCondition")

                    setAfterCategory(event);

                  }} />

              </label>

              <label className={"pt-4"}><p className="nvl-Def-Label pb-1">Course</p>
                <NVLMultiSelect id={"aftercourse" + id}
                  className="w-96 nvl-non-mandatory" labelText="Course"

                  options={afterCourseCompletion}
                  value={afterCourseData?.["aftercourse" + id]}

                  onChange={(event) => {
                    // setafterCourseData(event);
                    setAfterCourseMultiSelect(event, "aftercourse" + id)

                  }} />

              </label>

            </div>
          </div>
        </div>
      </form>
    </>
  )
}