import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPage from "@components/Controls/NVLModalPage";
import NVLPannelResiziable from "@Controls/NVLPannelResiziable";
import "quill/dist/quill.bubble.css";
import "quill/dist/quill.snow.css";
import { useEffect, useRef, useState } from "react";
import { important } from "tailwind.config";

export default function CertificateDesign(props) {
    const cert = useRef();
    const fileref = useRef(null);
    const [open, setOpen] = useState(false);
    const [text, setText] = useState([]);


    useEffect(() => {
        if (props.cert != "") {
            const regex = /(<div id="parent" ([^>]+)>)/gi;
            let certificate = props.cert.replace(regex, "");
            certificate = certificate.substring(0, certificate.length - 6);
            cert.current.innerHTML = certificate;
            const divs = document.querySelectorAll(".close-icon-pattern");
            divs.forEach((el) =>
                el.addEventListener("click", (event) => {
                    event.target.parentElement.parentElement.remove();
                })
            );
        }
    }, [props.cert]);

    const onImageChange = (e) => {
        if (e.target?.files.length != 0) {
            const [file] = e.target.files;
            new Promise(() => {
                const reader = new FileReader();
                reader?.readAsDataURL(file);
                reader.onload = () => {
                    props.SetFrame(reader.result);
                };
            });
        }
    };

    const onProfileImageChange = (e) => {
        if (e.target?.files.length != 0) {
            const [file] = e.target.files;
            new Promise(() => {
                const reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = () => {
                    const imgRender = (
                        <NVLPannelResiziable key={text.length + 1} width={180} Fileref={fileref} HeaderContent={`<img src=${reader.result} class="w-full h-full"/>`} ></NVLPannelResiziable>
                    );
                    setText([...text, imgRender]);
                };
            });
        }

    };
    return (
        <section className="flex justify-between text-gray-600 body-font gap-3 text-xs font-semibold shadow-xl  py-4 bg-gray-200 rounded-md w-full ">
            <NVLModalPage open={open} setText={setText} text={text} setOpen={setOpen} NotificationData={props?.NotificationData} />
            <div className="overflow-auto max-h-screen max-w-screen-xl">
                <div className={`relative  flex flex-col sm:flex-row sm:items-center shadow-md  border-white`} style={{ width: props?.watch("txtTempWidth") + "mm", height: props?.watch("txtTempHeight") + "mm", marginLeft: props?.watch("txtLeftMargin") + "mm", marginRight: props?.watch("txtRightMargin") + "mm" }} id="CustomeCert" >
                    <div id="parent" ref={cert} style={{ backgroundImage: `url("${props.CertFrame}")`, backgroundSize: "100% 100%" }} className="relative w-full h-full">
                        {text}
                    </div>
                </div>
            </div>
            <div className="mx-auto flex flex-col py-20 px-2 gap-6 relative">
                <div className="grid gap-2">
                    <NVLlabel CustomCss="-translate-x-72 pt-4" text="Certificate Background Template" HelpInfo="Acceptable file formats jpeg,png,jpg" HelpInfoIcon="fa fa-solid fa-circle-question" className="nvl-Def-Label" />
                    <label className="block">
                        <span className="sr-only">Choose File</span>
                        <input type="file" accept="image/jpeg,image/png,image/jpg" onChange={onImageChange}
                            className="block w-full focus:outline-none text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
                    </label>
                </div>
                <div className="grid gap-2">
                    <NVLlabel CustomCss="-translate-x-72 pt-4" text="Image Upload" HelpInfo="Upload Logo image for certificate. Acceptable file formats jpeg,png,jpg" HelpInfoIcon="fa fa-solid fa-circle-question" className="nvl-Def-Label" />
                    <label className="block">
                        <span className="sr-only">Choose File</span>
                        <input id="updFile" type="file" accept="image/jpeg,image/png,image/jpg" onChange={onProfileImageChange}
                            className="block w-full focus:outline-none text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100" />
                    </label>
                </div>
                <div className="grid gap-2 ">
                    <NVLlabel CustomCss="-translate-x-72 pt-4" HelpInfo="Text format" HelpInfoIcon="fa fa-solid fa-circle-question" text="Text Format" className="nvl-Def-Label" help />
                    {/* <div className="cursor-pointer rounded py-2 shadow-lg flex justify-between bg-white" onClick={() => setOpen(!open)} > */}
                    <div onClick={() => setOpen(!open)} className="w-28 justify-center bg-blue-50 rounded-full hover:bg-blue-100 text-blue-700 font-bold py-2 px-4 inline-flex items-center">
                        <span >Add Text</span>
                    </div>
                </div>
            </div>
        </section>
    );
}
