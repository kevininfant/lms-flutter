import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLTextbox from "@components/Controls/NVLTextBox";
import NVLToggle from "@components/Controls/NVLToggle";
import NVLlabel from "@components/Controls/NVLlabel";
import { createXlmsUserOnboardingInfo } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useRouter } from "next/router";
import AddOnboardSet from "pages/SiteConfiguration/AddOnBoardSet";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";
export default function OnBoardingSettings(props) {
  const router = useRouter();
  const [data, getData] = useState(0);
  const [data1, getData1] = useState(0);
  const [submit, setSubmit] = useState([]);
  const [onboardLength, setOnboardLength] = useState(1)
  const initialModalState = {
    ModalType: "Success",
    ModalTopMessage: "Success",
    ModalBottomMessage: "Details have been saved successfully.",
    ModalOnClickEvent: () => {
      router.push(`/SiteConfiguration/SiteConfigSettings`);
    },
  };
  const [modalValues, setModalValues] = useState(initialModalState);
  const pageRoutes = useMemo(() => {
    return [
      { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
      { path: "", breadcrumb: "OnBoardingSettings" }
    ];
  }, []);
  const validationSchema = Yup.object().shape({ 
    EnrollCourseDuration: Yup.string().required("Enroll Course Duration is required").matches(Regex("AllowOnlyNumbers"), "Enroll Course Duration is invalid").test("", "", (e, { createError }) => {
        if (e != "") {
          if (parseInt(e) == 0) return createError({ message: "Enroll Course Duration should be greater than zero" })
        }
        return true
      }).max(3, "Maximum limit exceeds").nullable()})
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
  const { register, handleSubmit, setValue, setError, clearErrors, watch, reset, formState } = useForm(formOptions);
  const { errors } = formState;
  const AddOnboarding = useCallback((PageData) => {
    return (
      <div>
        <>
          <AddOnboardSet
            register={PageData?.register}
            watch={PageData?.watch}
            handleSubmit={PageData?.handleSubmit}
            setValue={PageData?.setValue}
            errors={PageData?.errors}
            props={props}
            onboardLength={PageData?.onboardLength}
            id={PageData?.id}
            onboardjson={PageData?.onboardjson}
            setJsonData={PageData?.setJsonData}
            data={PageData?.data}
            data1={PageData?.data1}
            setSubmit={PageData?.setSubmit}
            submit={PageData?.submit}

          />

        </>
        {
          <div className="pt-2">
            <i className="fa-solid fa-trash text-red-600" onClick={() => {
              setOnboardLength((data) => {
                delete finalOnBoardJson.current.OB["ONB" + (data - 1)];
                return data - 1;
              });
            }}></i>
          </div>
        }
      </div>

    )
  }, [props])

  const OnboardLoop = useCallback((PageData) => {
    const rowGrid = [];
    for (let i = 0; i < PageData?.onboardLength; i++) {
      rowGrid.push(<AddOnboarding
        register={PageData?.register}
        watch={PageData?.watch}
        handleSubmit={PageData?.handleSubmit}
        setValue={PageData?.setValue}
        errors={PageData?.errors}
        onboardLength={PageData?.onboardLength}
        id={i}
        onboardjson={PageData?.finalOnBoardJson.current.OB?.["ONB" + i]}
        setJsonData={PageData?.setJsonData}
        data={PageData?.data}
        data1={PageData?.data1}
        setSubmit={PageData?.setSubmit}
        submit={PageData?.submit}
      />
      )
    }
    return <>

      {rowGrid}
    </>

  }, [])
  const finalResponse = useCallback((finalStatus) => {
    if (finalStatus != "Success") {
      setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Danger", ModalBottomMessage: finalStatus, });
      ModalOpen();
      return;
    } else {
      setValue("submit", "");
      setModalValues({
        ModalInfo: "Success",
        ModalOnClickEvent: () => {
          router.push(`/SiteConfiguration/SiteConfigSettings`);
        },
      });
      ModalOpen();
    }
  }, [router, setValue]);
  const submitHandler = async (data) => {

    getData((temp) => { return temp + 1; });
    getData1((temp) => { return temp + 1; });
    finalOnBoardJson.current = { ...finalOnBoardJson.current, OB: {} };
  


  }

  useEffect(() => {

    async function saveData() {
      let temp = Object.values(submit)
      if (temp.length == onboardLength) {

      let finalResult = [];
      for (let index = 0; index < onboardLength; index++) {

        finalResult.push(watch?.("onBoardrs" + index))
      }

      let finalData = {}
      for (let index = 0; index < onboardLength; index++) {
        finalData = {
          ...finalData,
          ["ON" + index]:
          {
            ...finalResult?.[index], ["CreateUserCourse"]: finalOnBoardJson.current?.["OB"]?.["ONB" + index]?.["values"]?.[0]?.["asnz"]?.["ddlCourse" + index],

            ["AfterCompletion"]: finalOnBoardJson.current?.["OB"]?.["ONB" + index]?.["values"]?.[0]?.["aftercourse"]?.["aftercourse" + index]
            , ["IsAfterCompletion"]: watch("obform")
          }
        }
      }
      // setValue("onBoardData",JSON.stringify(finalData))
      setValue("onBoardData", JSON.stringify(finalData))

      // console.log("useEff", finalData);
      let usersub = { "id": props?.user?.attributes?.["sub"] }
      let userrestriction = JSON.stringify(finalData)

     
          // if(finalResult?.length == onboardLength){
          // setRsvalue (userrestriction)
          const variables = {
            input: {
              PK: "TENANT#" + props?.TenantInfo?.TenantID,
              SK: "ONBOARDINGINFO#USER",
              // AfterCompletionCourseInfo: JSON.stringify(finalAfter),
              CourseConsumeCondition: watch?.("onBoardData"),

              CreatedBy: props?.user?.username,
              CreatedDate: new Date(),
              // DefaultCourseInfo: JSON.stringify(efg),
              EnrolledCourseDuration: watch?.("EnrollCourseDuration"),
              // IsAfterCompletion: watch("obform"),
              IsDeleted: false,
              IsSuspend: false,
              IsUserOnboard: watch("obformm"),
              LastModifiedBy: props?.user?.username,
              LastModifiedDate: new Date(),
              TenantID: props?.TenantInfo?.TenantID,
              UserSub: JSON.stringify(usersub),
              UserType: "NewUser",
            },
          };

          const finalOnboardData = await AppsyncDBconnection(createXlmsUserOnboardingInfo, variables, props.user.signInUserSession.accessToken.jwtToken);
          finalResponse(finalOnboardData.Status);
          // console.log(finalOnboardData, "final Status----->@@@@@");


          // }
        
        

      }
    }
    saveData();
  }, [finalResponse, onboardLength, props, setValue, submit, watch]);

  const finalOnBoardJson = useRef({ OB: {} });
  const setJsonData = useCallback((data, id) => {
    if (id != undefined && onboardLength != undefined) {
      if (id < onboardLength) {
        finalOnBoardJson.current = { ...finalOnBoardJson.current, OB: { ...finalOnBoardJson.current.OB, ["ONB" + (id)]: data }, };
      }
      else {
        if (id != 0) {
          delete finalOnBoardJson.current.OB["ONB" + (id)];
        }
      }
    };

  }, [onboardLength]);
  return (
    <>
      <Container title="OnBoarding" PageRoutes={pageRoutes}></Container>
      <form onSubmit={handleSubmit(submitHandler)} >
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />

        <div className="grid place-content-around" >
          <NVLlabel id="onboarding" text="On Boarding" title="On Boarding" errors={errors} className={"nvl-Def-Label pb-1 pt-2"} register={register} />

        </div>
        <div className="grid place-content-around" >

          <NVLToggle id={"obformm"} defaultChecked={""} name="obformm" onChange={(e) => getIsvisible(e)} />
        </div>
        <div className={watch("obformm") == true ? "pointer-events-none " : " "}>
          <div className=" nvl-FormContent z-50 !w-[60%]  items-center justify-center">

            <NVLTextbox id="userType" labelText="User Type" title="New User" labelClassName="nvl-Def-Label" type={"text"} errors={errors} className={"Disabled nvl-Def-Input nvl-mandatory nvl-Def-Input"} disabled={"New USer"} register={register} />
            <NVLTextbox id="EnrollCourseDuration" labelText="Enroll Course Duration (in Days)" labelClassName="nvl-Def-Label pb-1 " title="Enroll Course Duration" className={`nvl-mandatory nvl-Def-Input ${watch("obformm") == true ? "Disabled " : ""}`} errors={errors} register={register} />

          </div>
        </div>

        <div>
          <OnboardLoop
            register={register}
            watch={watch}
            handleSubmit={handleSubmit}
            setValue={setValue}
            errors={errors}
            props={props}
            onboardLength={onboardLength}
            finalOnBoardJson={finalOnBoardJson}
            setJsonData={setJsonData}
            data={data}
            data1={data1}
            setSubmit={setSubmit}
          />
        </div>
        <NVLButton id="AddOptions" text={"Add onboard Set"} type="button" onClick={() => { setOnboardLength((data) => { return data + 1; }); }} className={"w-32 nvl-button bg-primary text-white "} />

        <div className="nvl-FormContent">
          <div className="flex justify-center gap-2 pt-4">

            <NVLButton
              id="btnSave"
              text={!watch("submit") ? "Save" : ""}
              disabled={watch("submit") ? true : false}
              type="submit"
              // onClick={() => {handleSubmit(submitHandler) }}
              className={"w-32 nvl-button bg-primary text-white "} >
              {
                watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
              }
            </NVLButton>
            <NVLButton id="btnCancel" text={"Cancel"} type="button" className="nvl-button w-28 "
              onClick={() => router.push(`/SiteConfiguration/OnBoardingSettings`)}
            ></NVLButton>
          </div>
        </div>

      </form >
    </>
  )
}