import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import Container from "@Container/Container";
import NVLHeader from "@Controls/NVLHeader";
import NVLRapidModal from "@Controls/NVLRapidModal";
import { deleteXlmsCustomField } from "@graphql/graphql/mutations";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCustomFields, listXlmsTenantInfos } from "src/graphql/queries";
import * as Yup from "yup";

function CustomFieldList(props) {
    const router = useRouter();
    const [isRefreshing, setIsRefreshing] = useState(0);
    const [popupValues, setPopupValues] = useState({});
    const [search, setSearch] = useState("");
    const [tenantList, setTenantList] = useState();
    const tenantId = useRef(props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : "");
    const variable = useRef({ PK: "TENANT#" + props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : "", SK: "CUSTOMFIELD#", });
    const headerColumn = [
        { HeaderName: "Custom Field ", Columnvalue: "CustomFieldType", HeaderCss: "w-6/12", },
        { HeaderName: "Custom Field Name", Columnvalue: "ProfileFieldName", HeaderCss: "w-6/12", },
        { HeaderName: "Action ", Columnvalue: "Action", HeaderCss: "w-0/12" },
    ];
    const validationSchema = Yup.object().shape({
        ddlSearch:
            props.TenantInfo.UserGroup == "SiteAdmin"
                ? Yup.string()
                    .required("Please Select The Field")
                    .test("NOValid", "ChangeHandler", (e) => {
                        if (e != tenantId.current) {
                            variable.current = { PK: "TENANT#" + e, SK: "CUSTOMFIELD#" };
                            tenantId.current = e;
                            setIsRefreshing((count) => {
                                return count + 1;
                            });
                            return true;
                        }
                        return true;

                    })
                : Yup.string().nullable(),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
    const { register, handleSubmit, formState, setValue, watch } = useForm(formOptions);
    const { errors } = formState;

    const searchBoxVal = (e) => {
        setSearch(e);
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    const refreshGrid = async () => {
        setSearch("");
        setIsRefreshing((count) => {
            return count + 1;
        });
    };

    useEffect(() => {
        async function TenantDatafetch() {
            const tenantResponse = await AppsyncDBconnection(listXlmsTenantInfos, { PK: "XLMS#TENANTINFO", SK: "#TENANT#" }, props.user.signInUserSession.accessToken.jwtToken);
            setTenantList(tenantResponse.res?.listXlmsTenantInfos.items);
        }
        TenantDatafetch();
        return (() => {
            setTenantList((temp) => { return { ...temp }; });
        });
    }, [props.user.signInUserSession.accessToken.jwtToken]);


    const actionRestriction = useCallback((getItem) => {
        const actionList = [];
        if (props.RoleData?.EditCustomField && getItem.IsDefault) {
            actionList.push({
                id: 1,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit",
                action: () => router.push(`/SiteConfiguration/CustomFieldSettings?Mode=Edit&TenantID=${getItem.TenantID}&SK=${encodeURIComponent(getItem.SK)}`),
            });
        }

        if (props.RoleData?.EditCustomField && !getItem.IsDefault) {
            actionList.push({
                id: 1,
                Color: "text-green-700",
                Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
                name: "Edit",
                action: () => router.push(`/SiteConfiguration/CustomFieldSettings?Mode=Edit&TenantID=${getItem.TenantID}&SK=${encodeURIComponent(getItem.SK)}`),
            },);
        }
        if (props.RoleData?.DeleteCustomField && !getItem.IsDefault) {
            actionList.push({
                id: 2,
                Color: "text-rose-700",
                Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
                name: "Delete",
                action: () => popup(getItem.PK, getItem.SK, "Are you sure Want to Delete Custom Field?"),
            },);
        }
        return actionList;
    }, [router, props]);

    const dropdownData = useMemo(() => {
        let currentTenant = [];
        const temp = [{ value: "", text: "Select Company" }];
        if (tenantList?.length > 2 && props.TenantInfo.UserGroup == "SiteAdmin") {
            tenantList?.map((getItem) => temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }),);
        } else if (props.TenantInfo.UserGroup != "SiteAdmin" && props.TenantInfo.UserGroup != undefined) {
            variable.current = { PK: "TENANT#" + tenantId.current, SK: "CUSTOMFIELD#" };
            currentTenant = tenantList?.filter(function (Tenant) { return Tenant.TenantID == tenantId.current; });
            currentTenant?.map((getItem) => { temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }); });
            setValue("ddlSearch", tenantId.current, { shouldValidate: true });

        }
        return temp;
    }, [tenantList, props.TenantInfo.UserGroup, setValue]);

    const gridDataBind = useCallback((viewData) => {
        const rowGrid = [];
        viewData && viewData.map((getItem, index) => {
            const text = getItem.CustomFieldType;
            const result = text.replace(/([A-Z])/g, " $1");
            
            rowGrid.push({
                PK: (<NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />),
                SK: (<NVLlabel id={"lblSKID" + (index + 1)} name="PK" text={getItem.SK} />),
                CustomFieldType: (<NVLlabel id={"lblFieldType" + (index + 1)} text={result}></NVLlabel>),
                ProfileFieldName: (<NVLlabel id={"lblFieldName" + (index + 1)} text={getItem.ProfileFieldName}></NVLlabel>),
                Action: getItem.IsDefault ? (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal>) : (<NVLRapidModal id={"RapidModal" + (index + 1)} ActionList={actionRestriction(getItem)}></NVLRapidModal>),
            });
        });
        return rowGrid;
    },
        [actionRestriction]
    );

    const deleteField = async (e) => {
        e.preventDefault();
        const variables = { input: { PK: popupValues.PK, SK: popupValues.SK, }, };
        const finalResult = await AppsyncDBconnection(deleteXlmsCustomField, variables, props.user.signInUserSession.accessToken.jwtToken);
        if (finalResult.Status == "Success") {
            resetPopUp();
        }
    };

    const handleUrl = (data) => {
        if (data.ddlSearch != "") {
            router.push(`CustomFieldSettings?Mode=Create&TenantID=${data.ddlSearch}`);
        } else {
            validationSchema.validate();
        }
    };


    const resetPopUp = useCallback(() => {
        setPopupValues({ PK: "", SK: "", Content: "" });
        refreshGrid();
    }, []);

    function popup(PK, SK, Content) {
        setPopupValues({ PK: PK, SK: SK, Content: Content });
    }
    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Custom Field Settings" }];
    }, []);

    return (
        <>
            <form>
                <Container title="CustomFieldList" loader={tenantList == undefined} PageRoutes={pageRoutes} >
                    <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} href1={watch("ddlSearch") != "" && watch("ddlSearch") != undefined ? `CustomFieldSettings?Mode=Create&TenantID=${watch("ddlSearch")}` : ""} LinkName1="Add Custom Field" IsNestedHeader className1={props.RoleData?.AddCustomField ? (props.TabRouting == true ? "" : "nvl-button-success") : "hidden"} RedirectAction1={handleSubmit((data) => handleUrl(data, "/"))} placeholder={"Search by Company Name/Email"} TableID={"tblCustomField"} SearchonChange={(e) => searchBoxVal(e)} IsDropdown={true} DropdownData={dropdownData} IsDropdownDisable={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} DropdownRequired={true} errors={errors} register={register} />
                  { (watch("ddlSearch") != undefined && watch("ddlSearch") != "") && <NVLGridTable user={props.user} refershPage={isRefreshing} Search={search} id="tblActivityList" className="max-w-full" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsCustomFields} querryName={"listXlmsCustomFields"} variable={variable.current} />}
                    <NVLModalPopup ButtonYestext="Yes" ButtonNotext="No" Content={popupValues.Content} SubmitClick={(e) => deleteField(e)} CancelClick={() => resetPopUp()} CloseIconEvent={() => resetPopUp()} />
                </Container>
            </form>
        </>
    );
}

export default CustomFieldList;


