import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLImageUpload from "@components/Controls/NVLImageUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXLMSCustomLoginTemplate } from "src/graphql/mutations";
import { getXLMSCustomLoginTemplate } from "src/graphql/queries";
import * as Yup from "yup";

function CustomLogin(props) {
 
    const router = useRouter();
    const initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/SiteConfiguration/SiteConfigSettings");
        },
    };
    const [getLogo] = useState({
        Logofile: "/Axle.png",
        ImgHeight: "w-36 h-16",
        lblFile: "",
        uploadImage: "",
        TentImgUrl: "/Axle.png",
    });
    const [modalValues, setModalValues] = useState(initialModalState);
    const [propsInfo, setPropsInfo] = useState();

    useEffect(() => {
        async function FetchData() {
            const url = "https:localhost:3000?company=novac";
            const fetchThemeData = await AppsyncDBconnection(getXLMSCustomLoginTemplate, { PK: "XLMS#CUSTOMLOGINTEMPLATE", SK: "CUSTOMLOGIN#" + url }, props.user.signInUserSession.accessToken.jwtToken);
            setPropsInfo({
                ThemeData: fetchThemeData.res?.getXLMSCustomLoginTemplate,
                mode: fetchThemeData.res?.getXLMSCustomLoginTemplate == null ? "Create" : "Edit"
            });
        }
        FetchData();
        return (() => {
            setPropsInfo((temp) => { return { ...temp }; });
        });
    }, [props.user.signInUserSession.accessToken.jwtToken]);

    const validationSchema = Yup.object().shape({ chkLogoVisible: Yup.bool().default(false).nullable() });
    const finalResponse = (FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
                ModalOnClickEvent: () => {
                    document.getElementById("modepopup").classList.add("hidden");
                },
            });
            ModalOpen();
            return;
        } 
        ModalOpen();
        
    };
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onBlur", nativeValidation: false };
    const { register, handleSubmit, setValue, watch, reset, formState } = useForm(formOptions);
    const { errors } = formState;
    useEffect(() => {
        setValue("txtclrBgColor", propsInfo?.ThemeData?.LoginBackground);
        setValue("chkLogoVisible", propsInfo?.ThemeData?.IsLoginLogoVisible);
        setValue("chkUserVisible", propsInfo?.ThemeData?.IsUserNameLableVisible);
        setValue("chkPwVisible", propsInfo?.ThemeData?.IsPassWordLableVisible);
    }, [propsInfo, setValue]);
    const resetControls = (e) => {
        e.preventDefault();
        reset();
    };

    const nameMode = (chk) => {
        if (chk) {
            document.getElementById("lblUserName").classList.remove("hidden");
        } else {
            document.getElementById("lblUserName").classList.add("hidden");
        }
    };

    const pwdmode = (chk) => {
        if (chk) {
            document.getElementById("lblPassword").classList.remove("hidden");
        } else {
            document.getElementById("lblPassword").classList.add("hidden");
        }
    };

    const submitHandler = async (data) => {
        const url = "https:localhost:3000?company=novac";
        const query = updateXLMSCustomLoginTemplate;

        const loginThemeVariables = {
            input: {
                PK: "XLMS#CUSTOMLOGINTEMPLATE",
                SK: "CUSTOMLOGIN#" + url,
                LoginBackground: document.getElementById("txtclrBgColor").value,
                IsLoginLogoVisible: data.chkLogoVisible,
                LoginlogoPath: "",
                IsUserNameLableVisible: data.chkUserVisible,
                IsPassWordLableVisible: data.chkPwVisible,
            },
        };


        const finalStatus = (await AppsyncDBconnection(query, loginThemeVariables, props.user.signInUserSession.accessToken.jwtToken)).Status;
        finalResponse(finalStatus);


        if (document.getElementById("nvl-TextBox") != null) {
            document.getElementById("nvl-TextBox").classList.remove("nvl-TextBox");
        }
    };

    return (
        <>
            <Container title="Custom Login Theme" loader={propsInfo == undefined} >
                <NVLHeader Header={"Custom Login Theme"} isBackAction={true} RedirectHome={"/SiteConfiguration/SiteConfigSettings"}>

                </NVLHeader>
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />

                <div className="w-1/3 mx-auto">
                    <div id="previewSpan" className={`shadow-md border p-2`} style={{ backgroundColor: watch("txtclrBgColor") }}>
                        <NVLHeader Header={"Preview"} isBackAction={false}>

                        </NVLHeader>
                        <NVLSettingsCard>
                            <div className="px-4">
                                <div className={`${watch("chkLogoVisible") ? "" : "hidden"}`}>
                                    <NVLImageUpload id="imageLogo" text={"Upload Logo"} watch={watch} control={"imageControl"} accept={".jpg,.png,.jpeg"} Logofile={getLogo.Logofile} uploadImage={getLogo.uploadImage} ImgHeight={getLogo.ImgHeight} lblFile={getLogo.lblFile} />
                                </div>
                                <div className="nvl-FormContent flex gap-4">
                                    <NVLlabel id="lblUserName" text="UserName" className={`mt-2 ${watch("chkUserVisible") ? "" : "hidden"}`}></NVLlabel>
                                    <NVLTextbox id="txtUserName" type="text" className="font-medium w-full Disabled" register={register}></NVLTextbox>

                                </div>

                                <div className="nvl-FormContent flex gap-4">
                                    <NVLlabel id="lblPassword" text="Password" className={`mt-2 ${watch("chkPwVisible") ? "" : "hidden"}`}></NVLlabel>
                                    <NVLTextbox id="txtPassword" type="text" className="font-medium w-full Disabled" register={register}></NVLTextbox>
                                </div>
                                <div className=" pl-72"></div>
                            </div>
                        </NVLSettingsCard>
                    </div>
                </div>

                <form onSubmit={handleSubmit(submitHandler)}>
                    <div className="nvl-FormContent grid gap-4">
                        <div className=" grid grid-cols-2">
                            <NVLlabel text="Choose Login Background" className="mt-1 pr-3"></NVLlabel>
                            <NVLTextbox type="color" id="txtclrBgColor" className="ml-11" register={register} errors={errors}></NVLTextbox>
                        </div>
                        <div className=" grid grid-cols-2">
                            <NVLlabel text="Logo Visible" className="pt-2"></NVLlabel>
                            <NVLCheckbox id="chkLogoVisible" className="ml-11" register={register} errors={errors} ></NVLCheckbox>
                        </div>
                        <div className=" grid grid-cols-2">
                            <NVLlabel text="UserName Label Visible"></NVLlabel>
                            <NVLCheckbox id="chkUserVisible" className="ml-11" register={register} errors={errors} onClick={(e) => nameMode(e.target.checked)}></NVLCheckbox>
                        </div>
                        <div className=" grid grid-cols-2">
                            <NVLlabel text="Password Label Visible"></NVLlabel>
                            <NVLCheckbox id="chkPwVisible" className="ml-11" register={register} errors={errors} onClick={(e) => pwdmode(e.target.checked)}></NVLCheckbox>
                        </div>
                        <div className=" grid grid-cols-2 gap-4">
                            <NVLButton id="btnSave" text="Save" type="submit" className="nvl-button bg-primary"></NVLButton>
                            <NVLButton id="btnReset" text="Cancel" type="reset" className="nvl-button" onclick={(e) => resetControls(e)}></NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CustomLogin;

