import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { getXLMSDefaultNotificationTemplate } from "src/graphql/queries";

function ViewNotification(props) {
  const router = useRouter();
  const [Data, setData] = useState([]);
  useEffect(()=>{
  const DataSource= async(i)=>{
  let mode = decodeURIComponent(String(router.query["mode"]));
  let PK = decodeURIComponent(String(router.query["PK"]));
  let SK = decodeURIComponent(String(router.query["SK"]));
  const viewData = await AppsyncDBconnection( getXLMSDefaultNotificationTemplate, { PK: PK, SK: SK}, props.user?.signInUserSession?.accessToken?.jwtToken);
  setData({ viewData: viewData?.res?.getXLMSDefaultNotificationTemplate != undefined ? viewData?.res?.getXLMSDefaultNotificationTemplate : [],})  

}
    DataSource();
    return(()=>{
      setData((temp) => { return { ...temp } });
    })
  },[props.user?.signInUserSession?.accessToken?.jwtToken, router.query])


  useEffect(() => {
    if(Data?.viewData!=undefined){
    document.getElementById("TempateBody").textContent = Data?.viewData?.TemplateBody && (Data?.viewData?.TemplateBody)?.replace(/(<([^>]+)>)/gi, "");
    document.getElementById("Signature").textContent =Data?.viewData?.TemplateBody && (Data?.viewData?.Signature)?.replace(/(<([^>]+)>)/gi, "");
    }
  }, [Data?.viewData?.TemplateBody, Data?.viewData?.Signature, Data?.viewData]);
        // Bread Crumbs
        const PageRoutes = useMemo(()=>{return [
          {path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
          {path: "/SiteConfiguration/NotificationSettingList", breadcrumb: "Notification Setting" },
          {path: "", breadcrumb: "View Notification" }
        ];},[]) 
  return (
    <>
      <Container PageRoutes={PageRoutes} loader={Data?.viewData == undefined} >
          <div className="border-2">
          <div className=" grid grid-cols-1 p-4">
            <div className="grid grid-cols-3 pt-3">
              <div className=" p-3 pl-2">
                <NVLlabel text="Subject" className=" text-sm font-semibold" />
              </div>
              <div>:</div>
              <div className=" p-2 pl-0 ">
                <div className="text-sm">{Data?.viewData?.Subject && (Data?.viewData?.Subject)?.replace(/(<([^>]+)>)/gi, "")}</div>
              </div>

              <div className=" p-2">
                <NVLlabel text="Message" className=" text-sm font-semibold" />
              </div>
              <div>:</div>

              <div className=" text-sm break-all" id="TempateBody"></div>

              <div className=" p-2">
                <NVLlabel text="Signature" className=" text-sm font-semibold" />
              </div>
              <div>:</div>
              <div className=" text-sm p-2" id="Signature"></div>
            </div>
          </div>

          <div className={`grid grid-cols-1 p-4 ${Data?.viewData?.Remainder != true ? "hidden" : ""} `}>
            <div className="grid grid-cols-3 pt-3">
              <div className=" p-2">
                <NVLlabel text="Notification Sequence" className=" text-sm font-semibold" />
              </div>
              <div>:</div>
              <div className=" p-2 pl-0">
                <NVLlabel text={Data?.viewData?.Mail} className=" text-tiny"></NVLlabel>
              </div>
              <div className=" p-2">
                <NVLlabel text="Email resend count" className=" text-sm font-semibold" />
              </div>
              <div>:</div>
              <div className=" p-2 pl-0">
                <NVLlabel text={Data?.viewData?.Mailsendinglimits} className=" text-tiny"></NVLlabel>
              </div>
              <div className=" p-2">
                <NVLlabel text="Email resend day" className=" text-sm font-semibold" />
              </div>
              <div>:</div>
              <div className=" p-2 pl-0">
                <NVLlabel text={Data?.viewData?.MailsendingDays} className=" text-tiny"></NVLlabel>
              </div>
            </div>
          </div>

          <div className="col-start-2 w-6/12 justify-end flex p-2">
            <NVLButton text="Back" ButtonType="primary" onClick={() => router.push("/SiteConfiguration/NotificationSettingList")}></NVLButton>
          </div>
        </div>
      </Container>
    </>
  );
}
export default ViewNotification;
