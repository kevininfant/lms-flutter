import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultiSelect from "@components/Controls/NVLMultiSelect";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLRichTextBox, { getContents, setContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { getXlmsCustomNotification, getXlmsDefaultNotificationFields, listXlmsCustomFields, listXlmsCustomNotification, listXlmsUserGroupListInfos, listXlmsUserListInfos } from "src/graphql/queries";
import * as Yup from "yup";

function Notify(props) {
  const router = useRouter();
  const [Data, setData] = useState({});
  let initialModalState = {};
  useEffect(() => {
    const DataSource = async (i) => {
      var TenantID = props.user.attributes["custom:tenantid"];
      const userData = await AppsyncDBconnection(listXlmsUserListInfos, { PK: "TENANT#" + TenantID, SK: "#USERINFO#", IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
      const GroupData = await AppsyncDBconnection(listXlmsUserGroupListInfos, { PK: "TENANT#" + TenantID, SK: "GROUPINFO#", IsSuspend: false }, props.user.signInUserSession.accessToken.jwtToken);
      const response = await AppsyncDBconnection(listXlmsCustomNotification, { PK: "TENANT#" + TenantID, SK: "CUSTOMNOTIFICATION#" }, props.user.signInUserSession.accessToken.jwtToken);
      const NotificationFields = await AppsyncDBconnection(getXlmsDefaultNotificationFields, { PK: "XLMS#DELIMETERFIELDS", SK: "NOTIFICATIONFIELDS#DELIMETER" }, props.user.signInUserSession.accessToken.jwtToken)
      const CustomFieldData = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + TenantID, SK: "CUSTOMFIELD#" }, props.user.signInUserSession.accessToken.jwtToken);
      setData({
        userData: userData?.res?.listXlmsUserListInfos?.items,
        TenantID: TenantID,
        GroupData: GroupData?.res?.listXlmsUserGroupListInfos?.items,
        TemplateData: response?.res?.listXlmsCustomNotification?.items,
        NotificationData: NotificationFields?.res?.getXlmsDefaultNotificationFields?.DefaultFields,
        CustomFieldData: CustomFieldData?.res?.listXlmsCustomFields?.items,
      })
      let initialModalState = {
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Notification sent successfully.",
        ModalOnClickEvent: () => {
          router.push(`/SiteConfiguration/CustomNotificationList?TenantID=${TenantID}`);
        },
      };

    }
    DataSource();
    return (() => {
      setData((temp) => { return { ...temp } })
    })
  }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router])

  const [Message, setMessage] = useState("");
  const [state, setState] = useState("");
  const [modalValues, setModalValues] = useState(initialModalState);
  const [CurrentDiv, setCurrentDiv] = useState({
    Select: "User",
    Template: "Custom",
  });
  const [Multiselected, setMultiSelected] = useState({ Email: [], User: [] });
  const NotificationFields = useMemo((() => {
    if (Data.NotificationData != undefined) {
      let DelimeterData = JSON.parse(Data.NotificationData);
      let CustomFieldDataList = [];
      Data.CustomFieldData && Data.CustomFieldData?.map((customField) => {
        CustomFieldDataList.push(customField.ProfileFieldName)
      })

      let FinalCustomFieldData = [];
      CustomFieldDataList.map((customField) => {
        FinalCustomFieldData.push({ customField: customField })
      })

      let FinalDelimetersData = { ...DelimeterData?.CompanyDetails, ...DelimeterData?.ActivityDetails, ...DelimeterData?.UserDetails, ...DelimeterData?.CourseDetails, ...CustomFieldDataList };

      return Object.entries(FinalDelimetersData)
    }
  }), [Data.CustomFieldData, Data.NotificationData]);
  const ResetData = (mode) => {
    setHTMLContents("", Message)
    document.getElementById("message_errors")?.classList.add("hidden");
    setMultiSelected({ Email: [], User: [] });
    setValue("rbTemplate", "");
    setState({});
    setValue("ddltemplate", "");
    setValue("txtSubject", "")
    if (mode == "clear") {
      reset();
      setValue("rbUser", "User")
      setValue("rbTemplate", "Custom");
    }

  }

  let MultiSelectList = useMemo(() => [], []);

  const validationSchema = Yup.object().shape({
    rbUser: Yup.string().test("no valid", "novalid", (e) => {
      if (watch("rbUser") == "User") {
        MultiSelectList.splice(0, MultiSelectList.length);
        Data.userData.map((getItem) => {
          if (getItem.EmailID != null) {
            MultiSelectList.push({
              value: getItem.UserSub,
              label: getItem.FirstName + " " + getItem.LastName,
            });
          }
        });
      } else if (watch("rbUser") == "Group") {
        MultiSelectList.splice(0, MultiSelectList.length);
        Data.GroupData.map((getItem) => {
          MultiSelectList.push({ value: getItem.SK, label: getItem.GroupName });
        });
      }
      // ResetData()
      return true;
    }),


    ddlSelectUserGroup: Yup.string()
      .test("MultiSlect_EmptyHandler", "", (e, { createError }) => {
        if ((e == "Empty" || e == undefined)) {
          return createError({ message: `${watch("rbUser") == "User" ? "Users required" : watch("rbUser") == "Group" ? "Group is required" : ""}` });
        }
        if (e == "NoData") {
          return createError({ message: `${watch("rbUser") == "User" ? "There is no User found" : "There is no group found"}` });
        }
        return true;
      }),

    rbTemplate: Yup.string().test("no valid", "novalid", (e) => {
      if (e == "Custom" && e != CurrentDiv.Template) {
        setCurrentDiv({ ...CurrentDiv, Template: e });
        setValue("txtSubject", "");
        setState({});
        setValue("ddltemplate", "");
        document.getElementsByClassName("ql-editor")[0].innerHTML = "";
      } else if (e == "PreDefined" && e != CurrentDiv.Template) {
        setCurrentDiv({ ...CurrentDiv, Template: e });
        setValue("txtSubject", "", { shouldValidate: true });
        setValue("ddltemplate", "", { shouldValidate: true });
      }
      return true;
    }),

    txtSubject:
      Yup.string().required("Subject is required").matches(Regex("AlphaNumWithAllowedSpecialChar"), "Enter Valid Subject").max(250, "Maximum 250 characters exceed").nullable(),

    ddltemplate:
      CurrentDiv.Template != "Custom" &&
      Yup.string().when("rbTemplate", {
        is: "PreDefined",
        then: Yup.string()
          .required("Select a pre-defined Template")
          .test("NOValid", "novalid", async (e) => {
            if (e == "") {
              setState({ txtSubject: "", txtMessage: "" });
            }
            if (CurrentDiv.Template == "PreDefined" && e != "") {
              let tenantID = "TENANT#" + Data?.TenantID;
              let query = getXlmsCustomNotification,
                variables = { PK: tenantID, SK: e };
              let FinalResponse = await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
              setState({
                ...state,
                txtSubject: FinalResponse?.res?.getXlmsCustomNotification?.SubjectName,
                txtMessage: FinalResponse?.res?.getXlmsCustomNotification?.Message,
              });
              document.getElementById("message_errors")?.classList.add("hidden");
            }
            return true;
          }),
      }),

    random: Yup.string()
      .test("", "Message is required", (e,{createError}) => {
        
        if ((e == "Empty" || e == undefined) && CurrentDiv.Template != "PreDefined") {
          return false;
        }
        else if (errors?.random != undefined && CurrentDiv.Template == "PreDefined") {
          clearErrors(["random"])
        }

        if(getContents(Message)?.replaceAll(/(<([^>]+)>)/gi, "").length > 2000) {
          return createError({message:"Maximum characters exceeded"})
        }

        return true;
      }).nullable()
  });

  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };
  const { register, handleSubmit, setValue, watch, reset, formState, clearErrors } = useForm(formOptions);
  const { errors } = formState;


  const MailID = [];
  if (Data.userData && Data.userData.length > 0) {
    Data.userData.map((getItem) => {
      if (getItem.EmailID != null && getItem?.RoleName == "Manager") {
        MailID.push({ value: getItem.UserSub, label: getItem.EmailID });
      }
    });
  }

  const SelectTemplate = [{ value: "", text: "Select Template" }];
  if (Data.TemplateData != undefined) {
    if (Data.TemplateData.length > 0) {
      Data.TemplateData.map((getItem) => {
        SelectTemplate.push({ value: getItem.SK, text: getItem.TemplateName });
      });
    }
  }

  const FinalResponse = (FinalStatus, ModalType) => {
    if (FinalStatus != "Success") {
      setModalValues({
        ModalInfo: "Danger",
        ModalTopMessage: "Error",
        ModalBottomMessage: FinalStatus,
      });
      ModalOpen();
      return;
    } else {
      setValue("submit", "")
      setModalValues({
        ModalInfo: "Success",
        ModalBottomMessage: "Notification sent successfully.",
        ModalOnClickEvent: () => {
          router.push(`/SiteConfiguration/CustomNotificationList?TenantID=${Data?.TenantID}`);
        },
      });
      ModalOpen();
    }
  };

  const onSubmit = async (data) => {
    setValue("submit", true);

    const UserData = [];
    const GroupData = [];
    const MailData = [];
    setValue("submit", true);
    if (watch("rbUser") == "User") {
      for (var i = 0; i < Multiselected.User.length; i++) {
        UserData.push(Multiselected.User[i].value);
      }
      for (var i = 0; i < Multiselected.Email.length; i++) {
        MailData.push(Multiselected.Email[i].label);
      }
    } else if (watch("rbUser") == "Group") {
      for (var i = 0; i < Multiselected.User.length; i++) {
        GroupData.push("GROUPID#" + Multiselected.User[i].value.split("#")[1]);
      }
      for (var i = 0; i < Multiselected.Email.length; i++) {
        MailData.push(Multiselected.Email[i].label);
      }
    }

    if (watch("rbUser") == "User" && UserData.length == 0) {
      setValue("ddlUser", "NoData", { shouldValidate: true });
      setValue("submit", false);

      return;
    } else if (watch("rbUser") == "Group" && GroupData.length == 0) {
      setValue("ddlUser", "NoData", { shouldValidate: true });
      setValue("submit", false);

      return;
    }

    var message = getContents(Message);
    if (message == "") {
      FinalResponse("Warning", "Warning");
      return;
    }
    var IsUser = watch("rbUser") == "User" ? true : false;
    var IsGroup = watch("rbUser") == "User" ? false : true;
    var fetchURL = watch("rbUser") == "User" ? process.env.CUSTOM_SEND_NOTIFICATION_URL : process.env.SENDNOTIFICATIONGROUP
    var JsonSaveData = {
      TenantID: props.TenantInfo.TenantID,
      GroupName: GroupData,
      UserDetails: UserData,
      IsGroup: IsGroup,
      IsUser: IsUser,
      ToCCAddress: watch("rbUser") == "User" ? JSON.stringify(MailData) : MailData,
      Subject: data.txtSubject.replace(/\s{2,}(?!\s)/g, ' ').trim(),
      Message: message,
    };

    let headers = watch("rbUser") == "User" ? { "Content-Type": "application/json", }
      : {
        authorizationtoken: await Auth.currentSession().then((s) =>
          s.getAccessToken().getJwtToken()
        ),
        menuid: "600402",
        defaultrole: props.TenantInfo.UserGroup,
        groupmenuname: "SiteConfiguration",
      }

    let Headers = {
      method: "POST",
      headers: headers,
      body: JSON.stringify(JsonSaveData),
    };


    let FinalStatus = await APIGatewayPostRequest(fetchURL, Headers);
    FinalResponse(FinalStatus.Status);
    setValue("submit", false);
  };

  useEffect(() => {
    setValue("rbUser", "User");
    setValue("rbTemplate", "Custom");
    if (Data.userData != undefined) {
      Data.userData.map((getItem) => {
        if (getItem.EmailID != null) {
          MultiSelectList.push({
            value: getItem.UserSub,
            label: getItem.FirstName + " " + getItem.LastName,
          });
        }
      });
    }
  }, [setValue, props, MultiSelectList, Data.userData]);

  useEffect(() => {
    if (CurrentDiv.Template == "PreDefined") {
      setValue("txtSubject", state.txtSubject);
      if (Message != "") {
        setHTMLContents(state.txtMessage, Message);
        Message?.history?.clear();
      }
    }
    if (Message != "") {
      Message?.on("text-change", (e) => {
        if (getContents(Message) == "" || getContents(Message).replaceAll(/(<([^>]+)>)/gi, "").trim().length == 0) {

          setValue("random", "Empty", { shouldValidate: true });
        } else {

          setValue("random", "NotEmpty", { shouldValidate: true });
        }
      });
    }
    setValue("submit", false);

  }, [setValue, Message, state, CurrentDiv.Template]);

  const PageRoutes = useMemo(() => {
    return [
      { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
      { path: `/SiteConfiguration/NotificationSettingList?TenantID=${Data.TenantID}`, breadcrumb: "Notification Setting" },
      { path: `/SiteConfiguration/CustomNotificationList?TenantID=${Data.TenantID}`, breadcrumb: "Custom Notification" },
      { path: "", breadcrumb: `Send Notification` }
    ];
  }, [Data.TenantID]);

  return (
    <>
      <Container title="Notification" PageRoutes={PageRoutes} loader={Data?.userData == undefined} >
        <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
        <form onSubmit={handleSubmit(onSubmit)} className={`${watch("submit") ? "pointer-events-none" : "px-2"}`}>
          <div className="nvl-FormContent">
            <NVLlabel className="font-bold text-gray-600" text="Select by"></NVLlabel>
            <div className="flex gap-8 flex-wrap">
              <NVLRadio id="rbUser" type="radio" errors={errors} register={register} text="Select User" name="rbUser" onClick={() => { ResetData(); setValue("rbTemplate", "Custom") }} value={"User"} />
              <NVLRadio id="rbUser" type="radio" errors={errors} register={register} text="Select Group" name="rbUser" onClick={() => { ResetData(); setValue("rbTemplate", "Custom") }} value={"Group"} />
            </div>
            <div className="pt-3 ">
              <NVLlabel text="To User" className="font-bold text-gray-600 pt-2">
                <span className="text-red-500 text-lg">*</span>
              </NVLlabel>
              <NVLMultiSelect
                id="ddlSelectUserGroup"
                className="nvl-mandatory nvl-MultiSelect"
                options={MultiSelectList}
                value={Multiselected.User}
                onChange={(event) => {
                  setMultiSelected({ ...Multiselected, User: event });
                  if (event?.length == undefined || event.length == 0) {
                    setValue("ddlSelectUserGroup", "Empty", { shouldValidate: true })
                  }
                  else {
                    setValue("ddlSelectUserGroup", "", { shouldValidate: true })
                  }
                }}
                labelledBy={"Select User"}
              />
              <div className="{invalid-feedback} text-red-500  text-sm ">{errors.ddlSelectUserGroup?.message}
                {/* {`Select ${watch(rbUser)=="User" ? "User" : "Group"}`} */}
              </div>
            </div>
            <div className="pt-3">
              <NVLlabel className="font-bold text-gray-600 pt-2" text="Reporting Manager Email"></NVLlabel>
              <NVLMultiSelect
                id="ddlMailCC"
                className="nvl-non-mandatory nvl-MultiSelect "
                value={Multiselected.Email}
                options={MailID}
                onChange={(event) => {
                  setMultiSelected({ ...Multiselected, Email: event });
                }}
                labelledBy={"Select User"}
              />
            </div>
            <div className="pt-2">
              <NVLlabel className="font-bold pt-2 text-gray-600" text="Template Type"></NVLlabel>
            </div>
            <div className="flex gap-8 flex-wrap">
              <NVLRadio id="rbTemplate" type="radio" errors={errors} register={register} text="Custom Template" name="rbTemplate" value={"Custom"} />
              <NVLRadio id="rbTemplate" type="radio" errors={errors} register={register} text="Pre Defined Template" name="rbTemplate" value={"PreDefined"} />
            </div>
            <div className={`pt-2 ${watch("rbTemplate") == null ? "hidden" : ""} `}>
              <div id="divTemplate" className={` pt-2 ${watch("rbTemplate") == "Custom" || watch("rbTemplate") == null ? "hidden" : ""}  `}>
                <NVLSelectField id="ddltemplate" options={SelectTemplate} errors={errors} title="Select Template" register={register} className="nvl-mandatory nvl-Def-Input" />
              </div>
              <div id="divSubject">
                <NVLTextbox id="txtSubject" labelText="Subject" labelClassName="font-bold pt-2 text-gray-600 " title="Enter Subject" errors={watch("rbTemplate") == "Custom" ? errors : {}} register={register} className={`nvl-mandatory ${watch("rbTemplate") != "Custom" ? "Disabled" : ""}`} />
              </div>
              <div id="divMessage">
                <NVLlabel text="Message" className="font-bold pt-2 text-gray-600">
                  <span className="text-red-500 text-lg">*</span>
                </NVLlabel>
                <NVLRichTextBox id="txtMessage" className={`nvl-mandatory  ${watch("rbTemplate") != "Custom" ? "Disabled" : ""}`} MaxLength={20}  setState={setMessage}></NVLRichTextBox>

                <div id="divrandom" className="{invalid-feedback} text-red-500 text-sm pt-2">
                  {errors?.random?.message}
                </div>

                <div id="divLabel" className={`${watch("rbTemplate") == "PreDefined" ? "hidden" : ""}`} >
                  <NVLlabel
                    showFull
                    text="* Click on the below items to add it in the Message field."></NVLlabel>
                  <div className="pt-2 flex gap-6 font-semibold">
                    <div className="gap-4 flex flex-wrap text-2xl">
                      {NotificationFields && Array.from(NotificationFields)?.map((fieldsData) => {
                        return (
                          <>
                            <NVLlabel
                              id="lblUserName"
                              className="NotifyItems text-lg"
                              text={fieldsData?.[1]}
                              onClick={() => {
                                setContents("{" + fieldsData?.[0] > 0 ? fieldsData?.[0] : "{" + fieldsData?.[1] + "}", Message);
                              }}
                            />
                          </>
                        )
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="justify-center flex gap-4 pt-4">
            <NVLButton id="btnSend" text={!watch("submit") ? "Send" : ""} type="submit" className={"w-28 nvl-button bg-primary text-white "}>
              {
                watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>
              }
            </NVLButton>
            <NVLButton id="btnClear" text={"Clear"} type="button" className="nvl-button w-28" onClick={() => (ResetData("clear"))} />
          </div>
        </form>
      </Container>
    </>
  );
}

export default Notify;

