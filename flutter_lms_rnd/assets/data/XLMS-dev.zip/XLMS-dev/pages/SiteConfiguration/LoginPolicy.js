import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckBox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import { createXlmsLoginPolicy, updateXlmsLoginPolicy } from "src/graphql/mutations";
import { getXlmsLoginPolicy, getXlmsSMSConfig, listXlmsActiveTenantInfo, listXlmsSMTPConfig } from "src/graphql/queries";
import * as Yup from "yup";

function CreateLogin(props) {
    const router = useRouter();
    const [getTenantId, setTenantID] = useState(props.TenantInfo.UserGroup == "SiteAdmin" ? "" : props.TenantInfo.TenantID);
    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.push("/UserManagement/UserList");
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);
    const [tenantDetails, setTenantDetails] = useState();

    const validationSchema = Yup.object().shape({
        ddlSelectCompany: Yup.string()
            .required("Company Name is required")
            .test("Companyhandler", "", (tenantID) => {
                if (getTenantId != tenantID && props.TenantInfo.UserGroup == "SiteAdmin") {
                    setTenantID(tenantID);
                    existingDataHandler("TENANT#" + tenantID, "POLICY#LOGINPOLICY");
                }
                return true;
            }),
        txtPrefixCode: Yup.string()
            .when("rbPrefixCodeRule", {
                is: "PrefixCode",
                then: Yup.string().required("Prefix code is required").nullable().matches(Regex("AllowAlphaNumeric"), " Prefix code is invalid")
                    .max(5, "Maximum 5 characters exceed"),
                otherwise: Yup.string().test("NoValid", "NoValid", () => {
                    setValue("txtPrefixCode", "");
                    return true;
                }).nullable(),
            })
            .nullable(),
         rbPwdExp: Yup.string().nullable(),   
        txtPwExpiry: Yup.string()
        .when("rbPwdExp", {
            is: (e)=> e == "Yes",
            then: Yup.string()
                .required("Password expiry in days is required")
                // .transform((o, c) => (o === "" ? null : c))
                .test("", "", (val, { createError }) => {
                    if (val == "" || val == undefined) {
                        return createError({ message: "Password expiry in days is required" });
                    }
                    if (val < 1) {
                        return createError({ message: "Password expiry in days should be greater than 0" });
                    } else if (val > 180) {
                        return createError({ message: "Password expiry in days should be lesser than 180" });
                    }
                    return true;
                })
                .nullable(),
            otherwise: Yup.string()
                .test("NoValid", "NoValid", () => {
                    setValue("txtPwExpiry", "");
                    setValue("chkMail", "");
                    setValue("chkSMS", "");
                    clearErrors(["txtPwExpiry"])
                    return true;
                })
                .nullable(),
        }),

        txtMinlen: Yup.string()
            .required(" Minimum password length is required")
            .transform((o, c) => (o === "" ? null : c))
            .matches(Regex("AllowOnlyNumbers"), "Enter valid value")
            .test("", "", (val, { createError }) => {
                if (val < 6) {
                    return createError({ message: "Minimum password length should be greater than 5" });
                } else if (val > 99) {
                    return createError({ message: "Minimum password length should be lesser than 99" });
                }
                return true;
            })
            .nullable(),
        chkmfaSMS: Yup.bool().test("e", "novalid", e => {
            if (e && !tenantDetails?.IsSmsConfig && getTenantId != "" && getTenantId != undefined) {
                setModalValues((data) => {
                    return {
                        ...data, Content: "To enable two factor authentication SMS configuration need to be done",
                    };

                });
            }
            return true;
        }),
        chkmfaMail: Yup.bool().test("e", "novalid", e => {
            if (e && !tenantDetails?.IsMailConfig && getTenantId != "" && getTenantId != undefined) {
                setModalValues((data) => {
                    return {
                        ...data, Content: "To enable two factor authentication SMTP configuration  need to be done",
                    };

                });
            }
            return true;
        })

    });


    useEffect(() => {
        async function FetchData() {
            const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
            let tenantDetail;
            if (props.TenantInfo.UserGroup == "SiteAdmin") {
                tenantDetail = getTenantId;
            }
            else {
                tenantDetail = props.user.attributes["custom:tenantid"];
            }
            const smsConfig = await AppsyncDBconnection(getXlmsSMSConfig, { PK: "TENANT#" + tenantDetail, SK: "SMSSETTINGS#" }, props.user.signInUserSession.accessToken.jwtToken);
            const mailconfig = await AppsyncDBconnection(listXlmsSMTPConfig, { PK: "TENANT#" + tenantDetail, SK: "SMTPSETTINGS#" }, props.user.signInUserSession.accessToken.jwtToken);
            setTenantDetails({
                currentTenant: tenantResponse.res?.listXlmsActiveTenantInfo?.items,
                IsSmsConfig: smsConfig?.res?.getXlmsSMSConfig != null ? true : false,
                IsMailConfig: mailconfig?.res?.listXlmsSMTPConfig?.items?.length > 0 ? true : false,
            });
        }
        FetchData();
        return (() => {
            setTenantDetails((temp) => { return { ...temp }; });
        });
    }, [getTenantId, props.TenantInfo.UserGroup, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken]);


    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, reset, formState, watch,clearErrors } = useForm(formOptions);
    const { errors } = formState;


    const selectCompany = useMemo(() => {
        let temp = [{ value: "", text: "Select Company" }];
        if (tenantDetails?.currentTenant?.length > 0 && props.TenantInfo.UserGroup == "SiteAdmin" && temp.length < 2) {
            tenantDetails?.currentTenant?.map((getItem) => temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName }));
        } else if (tenantDetails?.currentTenant?.length > 0 && props.TenantInfo.UserGroup != "SiteAdmin") {
            temp = [];
            const currentTenant = tenantDetails?.currentTenant?.filter(function (Tenant) {
                return Tenant.TenantID == getTenantId;
            });
            currentTenant.map((getItem) => {
                temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName });
            });
            setValue("ddlSelectCompany", getTenantId)
        }
        return temp;
    }, [tenantDetails?.currentTenant, props.TenantInfo.UserGroup, setValue, getTenantId]);

    const existingDataHandler = useCallback(async (PK, SK) => {
        const existingData = await AppsyncDBconnection(getXlmsLoginPolicy, { PK: PK, SK: SK }, props.user.signInUserSession.accessToken.jwtToken);
        const existData = existingData?.res?.getXlmsLoginPolicy;
        reset({ txtPrefixCode: undefined, txtPwExpiry: undefined, txtMinlen: undefined, chkSMS: undefined, chkMail: undefined, rbPrefixCodeRule: "EmailId", rbPwdExp: "No" });

        if (existData != null) {
            setValue("ddlSelectCompany", PK.split("#")[1]);
            setValue("rbPrefixCodeRule", existData?.UserIdRuleType);
            setValue("txtPrefixCode", existData?.PolicyPrefixCode);
            setValue("rbPwdExp", existData?.PasswordExpiry ? "Yes" : "No");
            setValue("txtPwExpiry", existData?.PasswordExpiryInDays == 0 ? "" : existData?.PasswordExpiryInDays.toString());
            setValue("txtMinlen", existData?.PasswordLength?.toString());
            setValue("chkSMS", (existData?.PwdExpiryNotifyType == "Mail,SMS" || existData?.PwdExpiryNotifyType == "SMS") ? "SMS" : "");
            setValue("chkMail", (existData?.PwdExpiryNotifyType == "Mail,SMS" || existData?.PwdExpiryNotifyType == "Mail") ? "Mail" : "");
            setValue("chkmfaSMS", existData?.IsMFASms ? true : false);
            setValue("chkmfaMail", existData?.IsMFAMail ? true : false);
        }
        else {
            setValue("ddlSelectCompany", PK.split("#")[1]);
        }
    }, [props.user.signInUserSession.accessToken.jwtToken, reset, setValue]);

    useEffect(() => {
        if (props.TenantInfo.UserGroup != "SiteAdmin") {
            existingDataHandler("TENANT#" + getTenantId, "POLICY#LOGINPOLICY");
        }
        setValue("rbPrefixCodeRule", "EmailId");
        setValue("rbPwdExp", "No");
    }, [setValue, existingDataHandler, getTenantId, props.TenantInfo.UserGroup]);


    const finalResponse = (FinalStatus, ModalType) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: ModalType,
                ModalTopMessage: ModalType == "Error" ? "Error" : "Warning",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        }
        setModalValues({
            ModalType: "Success",
            ModalTopMessage: "Success",
            ModalBottomMessage: "Details have been saved successfully.",
            ModalOnClickEvent: () => {
                router.query?.["start"] != undefined ?
                    router.push("/UserManagement/UserList") : router.push("SiteConfigSettings");
            },
        });
        ModalOpen();

    };




    const submitHandler = async (data) => {
        setValue("submit", true);
        const setPk = "TENANT#" + document.getElementById("ddlSelectCompany").options[document.getElementById("ddlSelectCompany").selectedIndex].value;
        const setSk = "POLICY#LOGINPOLICY";
        let PwdExpiryNotifyType = data.chkSMS ? "SMS" : "Mail";
        PwdExpiryNotifyType = data.chkSMS && data.chkMail ? "Mail,SMS" : PwdExpiryNotifyType;
        PwdExpiryNotifyType = !data.chkSMS && !data.chkMail ? "" : PwdExpiryNotifyType;
        const tenantName = document.getElementById("ddlSelectCompany").options[document.getElementById("ddlSelectCompany").selectedIndex].text;
        const existVariables = { PK: setPk, SK: setSk };
        const finalStatus = await AppsyncDBconnection(getXlmsLoginPolicy, existVariables, props.user.signInUserSession.accessToken.jwtToken);
        const mode = finalStatus.res.getXlmsLoginPolicy != null ? "Edit" : "Create";
        const query = mode == "Create" ? createXlmsLoginPolicy : updateXlmsLoginPolicy;
        const variables = {
            input: {
                PK: setPk,
                SK: setSk,
                PolicyPrefixCode: data.rbPrefixCodeRule == "PrefixCode" ? data.txtPrefixCode?.toLowerCase() : "",
                PasswordExpiry: data.rbPwdExp == "Yes" ? true : false,
                PasswordExpiryInDays: data.rbPwdExp == "Yes" ? data.txtPwExpiry : 0,
                PasswordLength: data.txtMinlen,
                PwdExpiryNotifyType: data.rbPwdExp == "Yes" ? PwdExpiryNotifyType : "",
                UserIdRuleType: data.rbPrefixCodeRule,
                TenantName: tenantName,
                CreatedBy: props.user.username,
                CreatedDate: new Date(),
                IsMFASms: data.chkmfaSMS,
                IsMFAMail: data.chkmfaMail
            },
        };

        const finalResult = await AppsyncDBconnection(query, variables, props.user.signInUserSession.accessToken.jwtToken);
        finalResponse(finalResult.Status);
        setValue("submit", false);
    };

    const pageRoutes = useMemo(() => {
        return [
            { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
            { path: "", breadcrumb: "Login Policy" }
        ];
    }, []);

    const CancelClick = useCallback(() => {
        setModalValues((data) => {
            return { ...data, Content: "" };
        });
        if (!tenantDetails?.IsSmsConfig) {
            setValue("chkmfaSMS", false);
        }
        if (!tenantDetails?.IsMailConfig) {
            setValue("chkmfaMail", false);
        }
    }, [setValue, tenantDetails?.IsMailConfig, tenantDetails?.IsSmsConfig])

    return (
        <>
            <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalType} />
            <Container title="LoginPolicy" loader={tenantDetails?.currentTenant == undefined} PageRoutes={pageRoutes}>
                <form onSubmit={handleSubmit(submitHandler)} className={`${ watch("submit") ? "pointer-events-none" : "px-2"}`}>
                    <div className="nvl-FormContent">
                        <NVLSelectField id="ddlSelectCompany" errors={errors} labelText="Company Name" labelClassName="nvl-Def-Label" options={selectCompany} className={`${props.TenantInfo.UserGroup != "SiteAdmin" ? "Disabled nvl-Def-Input" : ""} nvl-Def-Input nvl-mandatory`} disabled={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} register={register}></NVLSelectField>
                        <div className="">
                            <NVLlabel text="User ID Generation Rules" className="nvl-Def-Label"></NVLlabel>
                            <div className="flex gap-4 text-xs font-medium pt-1">
                                <NVLRadio id="rbPrefixCodeRule" errors={errors} value={"PrefixCode"} register={register} text="Prefix+Code" name="rbPrefixCodeRule"></NVLRadio>
                                <NVLRadio id="rbPrefixCodeRule" errors={errors} register={register} value={"EmailId"} text="Email ID" name="rbPrefixCodeRule"></NVLRadio>
                                <NVLRadio id="rbPrefixCodeRule" errors={errors} register={register} value={"EmpCode"} text="Employee Code" name="rbPrefixCodeRule"></NVLRadio>
                            </div>
                        </div>
                        <NVLTextbox id="txtPrefixCode" errors={errors} labelText="Prefix Code" labelClassName="nvl-Def-Label" emaxLength="6" title="Prefix Code" className={(watch("rbPrefixCodeRule") == "EmailId" || watch("rbPrefixCodeRule") == "EmpCode") ? "Disabled nvl-Def-Input" : "nvl-mandatory nvl-Def-Input"} disabled={watch("rbPrefixCodeRule") == "EmailId" ? true : false} register={register} />
                        <div className="pb-1">
                            <NVLlabel text="Password Expiry" className="nvl-Def-Label"></NVLlabel>
                            <div className="flex gap-4 text-xs font-medium pt-1">
                                <NVLRadio id="rbPwdExp" errors={errors} register={register} value={"Yes"} text="Yes" name="rbPwdExp"></NVLRadio>
                                <NVLRadio id="rbPwdExp" errors={errors} register={register} value={"No"} text="No" name="rbPwdExp"></NVLRadio>
                            </div>
                        </div>
                        <NVLTextbox id="txtPwExpiry" labelText="Password Expiry in Days" title="Password Expiry in Days" labelClassName="nvl-Def-Label" type={"number"} errors={errors} className={watch("rbPwdExp") == "No" ? "Disabled nvl-Def-Input" : "nvl-mandatory nvl-Def-Input"} disabled={watch("rbPwdExp") == "No" ? true : false} register={register} />
                        <NVLTextbox id="txtMinlen" labelText="Minimum Password Length" title="Minimum Password Length" labelClassName="nvl-Def-Label" type={"number"} errors={errors} className={"nvl-Def-Input nvl-mandatory"} register={register} />
                        <div className="pb-1">
                            <NVLlabel text="Password Expiry" className="nvl-Def-Label"></NVLlabel>
                            <div className="flex gap-2 text-xs font-medium pt-1 pb-1">
                                <NVLCheckBox text="SMS" id="chkSMS" errors={errors} className={watch("rbPwdExp") == "No" ? "pointer-events-none text-gray-300 border-gray-300 checked:bg-gray-400 select-none" : "border-gray-300 checked:bg-blue-600 select-none"} disabled={watch("rbPwdExp") == "No" ? true : false} register={register}></NVLCheckBox>
                                <NVLCheckBox text="Mail" id="chkMail" errors={errors} className={watch("rbPwdExp") == "No" ? "pointer-events-none text-gray-300 border-gray-300 checked:bg-gray-400 select-none" : "border-gray-300 checked:bg-blue-600 select-none"} disabled={watch("rbPwdExp") == "No" ? true : false} register={register}></NVLCheckBox>
                            </div>
                            <div className="pt-2">
                                <NVLlabel text="Two Factor Authentication" className="nvl-Def-Label " HelpInfo={"If enabled verification code will be send to the user on login"} HelpInfoIcon={"fa fa-circle-info"}></NVLlabel>
                                <div className="flex gap-2 text-xs font-medium pt-2 ">
                                    <NVLCheckBox text="SMS" id="chkmfaSMS" errors={errors} className={"border-gray-300 checked:bg-blue-600 select-none"} disabled={false} register={register}></NVLCheckBox>
                                    <NVLCheckBox text="Mail" id="chkmfaMail" errors={errors} className={"border-gray-300 checked:bg-blue-600 select-none"} disabled={false} register={register}></NVLCheckBox>
                                </div>
                            </div>
                            <div className=" flex flex-row gap-1 justify-center nvl-Def-Input mt-4">
                                <NVLButton id="btnSubmit" text={!watch("submit") ? "Submit" : ""} type="submit" disabled={watch("submit") ? true : false} className={"w-32 nvl-button bg-primary text-white "}>{watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i>}</NVLButton>
                                <NVLButton
                                    id="btnCancel"
                                    text={"Cancel"}
                                    type="button"
                                    className="nvl-button w-28"
                                    onClick={(e) => {
                                        e.preventDefault();
                                        router.push("/SiteConfiguration/SiteConfigSettings");
                                    }}
                                ></NVLButton>
                            </div>
                        </div>
                    </div>
                    <NVLModalPopup ButtonYestext="Continue" ButtonNotext="Cancel" ButtonConfirmtext="Cancel" CancelClick={() => { CancelClick(); }} SubmitClick={() => { router.push("/SiteConfiguration/SiteConfigSettings"); }} CloseIconEvent={() => { CancelClick(); }} Content={modalValues.Content} />
                </form>
            </Container>
        </>
    );
}

export default CreateLogin;