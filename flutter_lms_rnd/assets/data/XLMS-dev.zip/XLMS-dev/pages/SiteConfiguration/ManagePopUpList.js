import NVLBreadCrumbs from "@components/Controls/NVLBreadCrumbs";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLRapidModal from "@components/Controls/NVLRapidModal";
import Container from "@Container/Container";
import { updateXlmsPopUpInfo } from "@graphql/graphql/mutations";
import { getXlmsPopUpInfo, listXlmsActiveTenantInfo, listXlmsPopUpInfo } from "@graphql/graphql/queries";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

export default function ManagePopUpList(props) {
  const router = useRouter();
  const [popupValues, setPopupValues] = useState({});
  const [tenantList, setTenantList] = useState();
  const tenantId = useRef(props.TenantInfo.UserGroup != "SiteAdmin" ? props.TenantInfo.TenantID : "");
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [search, setSearch] = useState("")
  const variable = useRef({ PK: props.TenantInfo.UserGroup != "SiteAdmin" ? "TENANT#" + props.TenantInfo.TenantID : "TENANT#", SK: "POPUP#LASTMODIFIEDDATE#", IsDeleted: false });

  const headerColumn = [
    { HeaderName: "Title", Columnvalue: "Title", HeaderCss: "w-3/12", },
    { HeaderName: "File Name", Columnvalue: "FileName", HeaderCss: "w-8/12", },
    { HeaderName: "Start Date", Columnvalue: "StartDate", HeaderCss: "w-0/12 whitespace-nowrap" },
    { HeaderName: "End Date", Columnvalue: "EndDate", HeaderCss: "w-0/12 whitespace-nowrap" },
    { HeaderName: "File Type", Columnvalue: "FileType", HeaderCss: "w-0/12 whitespace-nowrap" },
    { HeaderName: "Status", Columnvalue: "Status", HeaderCss: "w-0/12", },
    { HeaderName: "Action", Columnvalue: "Action", HeaderCss: "w-0/12" },
  ];

  const searchBoxVal = useCallback((e) => {
    setSearch(e);
    setIsRefreshing((count) => {
      return count + 1;
    });
  }, [])
  const validationSchema = Yup.object().shape({
    ddlSearch:
      props.TenantInfo.UserGroup == "SiteAdmin"
        ? Yup.string()
          .required("Please Select The Field")
          .test("NOValid", "ChangeHandler", (e) => {
            if (e != tenantId.current) {
              variable.current = { PK: "TENANT#" + e, SK: "POPUP#LASTMODIFIEDDATE#", IsDeleted: false };
              tenantId.current = e;
              setIsRefreshing((count) => {
                return count + 1;
              });
              return true;
            }
            return true;

          })
        : Yup.string().nullable(),
  });
  const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), };
  const { handleSubmit, register, formState, watch, setValue } = useForm(formOptions);


  useEffect(() => {
    async function TenantDatafetch() {
      const tenantResponse = await AppsyncDBconnection(listXlmsActiveTenantInfo, { PK: "XLMS#TENANTINFO", SK: "#TENANT#", IsSus: false }, props.user.signInUserSession.accessToken.jwtToken);
      setTenantList(tenantResponse?.res?.listXlmsActiveTenantInfo?.items);
    }
    TenantDatafetch();
    return (() => {
      setTenantList((temp) => { return { ...temp }; });
    });
  }, [props.user.signInUserSession.accessToken.jwtToken]);


  const { errors } = formState;
  const refreshData = useCallback(async () => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  }, []);

  const refreshGrid = useCallback(() => {
    setSearch("");
    setIsRefreshing((count) => {
      return count + 1;
    });
  }, []);

  function resetPopUp() {
    setPopupValues({ PK: "", SK: "", Content: "", Type: "" });
    document.getElementById("tableSearch") && document.getElementById("tableSearch").value == "";
  }

  function popup(type, PK, SK, Content) {
    setPopupValues({ PK: PK, SK: SK, Content: Content, Type: type });
  }

  function getDateFormat(CreatedDt) {
    return (new Date(CreatedDt).toDateString().substring(4))
  }

  async function updateField(e) {
    e.preventDefault();
    document.getElementById("tableSearch") ? (document.getElementById("tableSearch").value = "") : ""
    let isDelete = false;
    let EditData;
    if (popupValues.Type == "isDelete") {
      isDelete = true;
      EditData = await AppsyncDBconnection(getXlmsPopUpInfo, { PK: popupValues.PK, SK: popupValues.SK }, props.user.signInUserSession.accessToken.jwtToken);
      EditData = EditData.res?.getXlmsPopUpInfo;
    }
    refreshData();
    let FinalStatus = await AppsyncDBconnection(updateXlmsPopUpInfo, { input: { PK: popupValues.PK, SK: popupValues.SK, IsDeleted: isDelete } }, props.user.signInUserSession.accessToken.jwtToken)
    let Status = await AppsyncDBconnection(updateXlmsPopUpInfo, { input: { PK: popupValues.PK, SK: "POPUPID#" + EditData.PopUpId, IsDeleted: isDelete } }, props.user.signInUserSession.accessToken.jwtToken)
    if (FinalStatus.Status == "Success") {
      refreshData();
    }
    resetPopUp();
  }

  const dropdownData = useMemo(() => {
    let currentTenant = [];
    const temp = [{ value: "", text: "Select Company" }];
    if (tenantList?.length > 2 && props.TenantInfo.UserGroup == "SiteAdmin") {
      tenantList?.map((getItem) => temp.push({ value: getItem.TenantID, text: getItem.TenantDisplayName, }),);
    }
    return temp;
  }, [tenantList, props.TenantInfo.UserGroup]);

  const actionRestriction = useCallback((getItem) => {
    let actionList = []
    if (props.RoleData?.EditPopupInfo || props.TenantInfo.UserGroup == "SiteAdmin") {
      actionList.push(
        {
          id: 4,
          Color: "text-green-700",
          Icon: "fa-solid fa-pencil text-green-700  bg-green-100 w-6",
          name: "Edit",
          action: () =>
            router.push(
              `/SiteConfiguration/AddPopUp?Mode=Edit&PopUpID=${getItem.PopUpId}&TenantID=${props.TenantInfo.UserGroup != "SiteAdmin" ? props?.TenantInfo?.TenantID : watch("ddlSearch")}`
            ),
        }
      )
    }
    if (props.RoleData?.DeletePopupInfo || props.TenantInfo.UserGroup == "SiteAdmin") {
      actionList.push(
        {
          id: 2,
          Color: "text-rose-700",
          Icon: "fa fa-trash-o text-rose-700 bg-rose-100 w-6",
          name: "Delete",
          action: () =>
            popup(
              "isDelete",
              getItem.PK,
              getItem.SK,
              "Are you sure to delete the PopUp?"
            ),
        }
      )
    }
    if (props.RoleData?.PreviewPopupInfo || props.TenantInfo.UserGroup == "SiteAdmin") {
      actionList.push(
        {
          id: 7,
          Color: "text-blue-700",
          Icon: "fa-solid fa-hotel text-blue-700  bg-blue-100 w-6",
          name: "Preview",
          action: () =>
            router.push(
              `/SiteConfiguration/ViewPopUp?Mode=Preview&PopUpID=${getItem.PopUpId}&CreatedDate=${getItem.LastModifiedDate}&TenantID=${props.TenantInfo.UserGroup != "SiteAdmin" ? props?.TenantInfo?.TenantID : watch("ddlSearch")}`
            ),
        },
      )
    }

    return actionList;
  }, [props.RoleData?.DeletePopupInfo, props.RoleData?.EditPopupInfo, props.RoleData?.PreviewPopupInfo, props.TenantInfo?.TenantID, props.TenantInfo.UserGroup, router, watch])

  const gridDataBind = useCallback(
    (viewData) => {
      const rowGrid = [];
      viewData && viewData.map((getItem, index) => {
        let actionList = [];
        actionList = actionRestriction(getItem)
        rowGrid.push({
          PK: (
            <NVLlabel id={"lblPKID" + (index + 1)} name="PK" text={getItem.PK} />
          ),
          SK: (
            <NVLlabel id={"lblSKID" + (index + 1)} name="SK" text={getItem.SK} />
          ),
          PopUpID: (
            <NVLlabel id={"lblPopUpId" + (index + 1)} name="PopUpID" text={getItem.SK} />
          ),
          Title: (
            <>
              <NVLlabel id={"lblPopUpName" + (index + 1)} text={getItem?.PopUpName}></NVLlabel>
            </>
          ),
          StartDate: (
            <NVLlabel id={"lblStartName" + (index + 1)} text={new Date(getItem.StartDate).toDateString().substring(4)}></NVLlabel>
          ),
          EndDate: (
            <NVLlabel id={"lblEndDate" + (index + 1)} text={new Date(getItem.EndDate).toDateString().substring(4)}></NVLlabel>
          ),
          FileType: (
            <NVLlabel id={"lblFileType" + (index + 1)} text={getItem.FileType}></NVLlabel>
          ),
          FileName: (
            <NVLlabel id={"lblFileName" + (index + 1)} text={getItem.FileName}></NVLlabel>
          ),
          Status: (
            <>
              {/* <div className="flex m-auto w-full" title={new Date(getItem.EndDate) < new Date() ? "Inactive" : "Active"}> */}
              <div className="flex m-auto w-full" title={"Active"}>
                <div
                  // className={`rounded-full my-auto h-3 w-3 ${new Date(getItem.EndDate) < new Date() ? "bg-red-500" : "bg-green-600"
                  className={`rounded-full my-auto h-3 w-3 ${"bg-green-600"
                    }	`}
                ></div>
                <NVLlabel
                  // className={`${new Date(getItem.EndDate) < new Date() ? "text-red-500" : "text-green-600"
                  className={`${"text-green-600"
                    } my-auto ml-2	`}
                  // text={new Date(getItem.EndDate) < new Date() ? "Inactive" : "Active"}
                  text={"Active"}
                ></NVLlabel>
              </div>
            </>
          ),
          CreatedDate: (
            <NVLlabel
              id={"txtName" + (index + 1)}
              text={getDateFormat(getItem.CreatedDate)}
            ></NVLlabel>
          ),
          Action: (
            <NVLRapidModal
              id={"RapidModal" + (index + 1)}
              ActionList={actionList}
              index={(index + 1) > 10 ? (index + 1) % 10 : index + 1}
            ></NVLRapidModal>
          ),
        });
      });
      return rowGrid;
    }, [actionRestriction]
  );
  const cancelEvent = (e) => {
    e.preventDefault();
    resetPopUp();
  };
  const handleUrl = (data) => {
    if (data.ddlSearch != "") {
      router.push(`AddPopUp?Mode=Create&TenantID=${props.TenantInfo.UserGroup != "SiteAdmin" ? props?.TenantInfo?.TenantID : watch("ddlSearch")}`);
    } else {
      validationSchema.validate();
    }
  };
  const pageRoutes = useMemo(() => {
    return [
      { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
      { path: "", breadcrumb: "ManagePopUpList" }
    ];
  }, []);

  return (
    <>
      <Container title="ManagePopUp" loader={tenantList == undefined}>
        <NVLBreadCrumbs Routes={pageRoutes}></NVLBreadCrumbs>
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab} DropdownData={dropdownData} IsDropdown={props.TenantInfo.UserGroup != "SiteAdmin" ? false : true} IsDropdownDisable={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false} DropdownRequired={props.TenantInfo.UserGroup != "SiteAdmin" ? true : false}
          IsSearch={props.RoleData?.SeTenathPopupInfo}
          ButtonID5="btnAddNewPopUp" LinkName5="+ Add PopUp" className5={props.RoleData?.CreatePopUpInfo ? (props.TabRouting == true ? "" : "nvl-button-success") : "nvl-button-success"}
          RedirectHome={"/"}
          RedirectAction5={handleSubmit((e) => handleUrl(e, "/"))}
          placeholder={"Search by popup title"}
          SearchonChange={(e) => searchBoxVal(e)} onClick1={refreshGrid}
          errors={errors} register={register}
          RedirectAction4={() => refreshGrid()}
          IsNestedHeader />
        <div className="max-w-full w-full justify-center">
          {((watch("ddlSearch") != undefined && watch("ddlSearch") != "") || props.TenantInfo.UserGroup != "SiteAdmin") &&
            <NVLGridTable
              user={props.user}
              refershPage={isRefreshing}
              id="tblPopUpList" Search={search}
              HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsPopUpInfo}
              querryName={"listXlmsPopUpInfo"} variable={variable.current} />}
        </div>
        <NVLModalPopup ButtonYestext="Yes" SubmitClick={(e) => updateField(e)} CancelClick={(e) => cancelEvent(e)} ButtonNotext="No" CloseIconEvent={() => resetPopUp()} Content={popupValues.Content} />
      </Container>
    </>
  );
}