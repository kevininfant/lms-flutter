import Container from "@components/Container/Container";
import NVLSettingsCard from "@components/Controls/NVLSettingsCard";
import { useRouter } from "next/router";
import { useEffect, useMemo } from "react";


function Card(props) {
  const router = useRouter();

  const CardsList = [
    props.RoleData?.BrandingTheme ? { id: "1", CardName: "Branding", CardIcon: <i className="fa fa-solid fa-pen-ruler text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/Branding") } : "",
    props.RoleData?.NotificationTemplateSetting ? { id: "2", CardName: "Notification setting", CardIcon: <i className="fa fa-solid fa-bell text-5xl"></i>, ActionUrl: () => router.push("/SiteConfiguration/NotificationSettingList") } : "",
    props.RoleData?.CustomFieldSetting ? { id: "3", CardName: "Custom Field Settings", CardIcon: <i className="fa fa-user-circle text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/CustomFieldList") } : "",
    props.RoleData?.LoginPolicy ? { id: "4", CardName: "Login Policy", CardIcon: <i className="fa fa-unlock-alt text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/LoginPolicy") } : "",
    props.RoleData?.PermissionsAndRoleManagement ? { id: "5", CardName: "Permission & Role Management", CardIcon: <i className="fa fa-sitemap text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/Rolelist") } : "",
    props.RoleData?.EmailConfiguration ? { id: "7", CardName: "Email Configuration", CardIcon: <i className="fa-solid fa-envelope-open-text text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/SMTPList") } : "",
    { id: "8", CardName: "SMS Configuration", CardIcon: <i className="fa-solid fas fa-sms text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/SMSConfigInfo") },
    props.RoleData?.CustomDomain ? { id: "9", CardName: "Custom Domain", CardIcon: <i className="fa fa-solid fa-globe text-5xl" /> } : "",
    props.RoleData?.UtilizationReport ? { id: "10", CardName: "Utilization Report", CardIcon: <i className="fa-solid fa-file text-5xl" />, ActionUrl: () => router.push("/") } : "",
    props.RoleData?.CustomCertificate ? { id: "11", CardName: "Custom Certificate", CardIcon: <i className="fa fa-light fa-graduation-cap text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/CustomCertificateList") } : "",
    props.RoleData?.CustomCertificate ? { id: "12", CardName: "LTI", CardIcon: <i className="fa-solid fa-file-text text-5xl " />, ActionUrl: () => router.push("/") } : "",
    props.RoleData?.CustomCertificate ? { id: "14", CardName: "Manage PopUp", CardIcon: <i className="fa-solid fa-laptop-file text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/ManagePopUpList") } : "",
  ];

  if (props.TenantInfo.UserGroup == "CompanyAdmin") {
    const PK = "XLMS#TENANTINFO";
    const SK = props.TenantInfo.TenantID;
    CardsList.push(props.RoleData?.ManageAccountPlanProcessor ? { id: "13", CardName: "Manage Accounts", CardIcon: <i className="fa fa-user-circle text-5xl"></i>, ActionUrl: () => router.push(`/CompanyManagement/CompanyDetails?TenantID=${SK}`) } : "")
    CardsList.push(props.RoleData?.ThirdPartyConfiguration ? { id: "6", CardName: "Third Party Configuration", CardIcon: <i className="fa-solid fa-laptop-file text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/ThirdPartyConfigSettings") } : "")
    CardsList.push(props.RoleData?.ManageAccountPlanProcessor ? { id: "16", CardName: "OnBoarding", CardIcon: <i className="fa fa-user-circle text-5xl"></i>, ActionUrl: () => router.push(`/SiteConfiguration/OnBoardingSettings`) } : "")
  }
  else if(props.TenantInfo.UserGroup == "SiteAdmin"){
    CardsList.push(true ? { id: "15", CardName: "Custom Login", CardIcon: <i className="fa-solid fa-laptop-file text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/CustomLoginList") } : "")
    CardsList.push(true ? { id: "16", CardName: "Site Admin Tool", CardIcon: <i className="fa-solid fa-laptop-file text-5xl" />, ActionUrl: () => router.push("/SiteConfiguration/SiteAdminTool") } : "")
  }
  const PageRoutes = useMemo(() => { return [{ path: "", breadcrumb: "Site Configuration" }]; }, [])
  useEffect(() => {
    if (CardsList.CardIcon != undefined) {
      setload(false);
    }
  }, [CardsList.CardIcon])

  return (
    <>
      <Container title="Settings" PageRoutes={PageRoutes}>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {CardsList &&
            CardsList.map((getItem, index) => {


              return (
                <>
                  {getItem.CardName &&
                    <div key={index}>
                      <NVLSettingsCard CardIcon={getItem.CardIcon} CardName={getItem.CardName} onClick={getItem.ActionUrl} borderclass={getItem.CardIcon != undefined ? "border-b-4 border-th-body-icon-hover-color" : ""} className={getItem.CardIcon != undefined ? "h-36 nvl-card-shadow" : ""} outerclass={getItem.CardIcon != undefined ? "p-3" : ""} />
                    </div>
                  }
                </>
              );

            })}
        </div>
      </Container>
    </>
  );
}

export default Card;
