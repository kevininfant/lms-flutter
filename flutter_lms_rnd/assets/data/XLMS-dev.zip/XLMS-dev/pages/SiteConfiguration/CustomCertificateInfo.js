import Container from "@Container/Container";
import Stepper from "@Controls/NVLStepper";
import StepperControl from "@Controls/NVLStepperControl";
import { UseContextProvider } from "@Dashboard/StepperContext";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { Regex } from "RegularExpression/Regex";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsCustomCertificate, updateXlmsCustomCertificate } from "src/graphql/mutations";
import { getXlmsCustomCertificate, getXlmsDefaultNotificationFields, getXlmsTenantInfo, listXlmsCustomCertificateExistsInfo, listXlmsCustomFields } from "src/graphql/queries";
import * as Yup from "yup";
import CertificateDesign from "./CertificateDesign";
import CertificateInfo from "./CertificateInfo";
import CertificatePreview from "./CertificatePreview";

export default function CustomCertificateInfo(props) {
    const [modalValues, setModalValues] = useState();
    const finalResponse = useCallback((finalStatus) => {
        if (finalStatus != "Success") {
            setModalValues({ModalInfo: "Danger",ModalTopMessage: "Error",ModalBottomMessage: finalStatus,});
            ModalOpen();
            return;
        } 
        setValue("submit", "");

        setModalValues({ ModalInfo: "Success", ModalOnClickEvent: () => {router.push("/SiteConfiguration/CustomCertificateList"); }, });
        ModalOpen();
        
    }, [router, setValue]);
    const router = useRouter();
    const [cert, setCert] = useState("");
    const landscapeValues = useRef({Height: 200, Width: 210, LeftMargin: 11, RightMargin:10})
    const portraitValues = useRef({Height: 210, Width: 200, LeftMargin: 10, RightMargin:11})
    const [currentStep, setCurrentStep] = useState(1);
    const [fetchdata, setFetchdata] = useState();
    const [img, setImg] = useState("https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRZjXcOXtCz17XevHaiQ2XfYQqgpD7hXzdSVQ&usqp=CAU");
    const steps = ["Information", "Certificate Design", "Preview"];
    const previousState = useRef({ txtTempName: {} });
    const tenantId = useMemo(() => {
        return router.query["TenantID"];
    }, [router.query]);

    const notificationFields = useMemo((() => {
        let DelimeterData;
        if (fetchdata?.NotificationData != undefined) {
            DelimeterData = JSON?.parse(fetchdata?.NotificationData);
        }
        const customFieldDataList = [];
        fetchdata?.CustomFieldData && fetchdata?.CustomFieldData?.map((customField) => { customFieldDataList.push(customField.ProfileFieldName); });

        const finalCustomFieldData = [];
        customFieldDataList.map((customField) => { finalCustomFieldData.push({ customField: customField });});

        const finalDelimetersData = { ...DelimeterData?.CompanyDetails, ...DelimeterData?.ActivityDetails, ...DelimeterData?.UserDetails, ...DelimeterData?.CourseDetails, ...customFieldDataList };

        return Object.entries(finalDelimetersData);
    }), [fetchdata?.CustomFieldData, fetchdata?.NotificationData]);
    useEffect(() => {
        async function FetchData() {
            const tenantID = router.query["TenantID"];
            const mode = router.query["Mode"];
            const urlSk = router.query["TemplateID"];
            const contents = "";
            const notificationFields = await AppsyncDBconnection(getXlmsDefaultNotificationFields, { PK: "XLMS#DELIMETERFIELDS", SK: "NOTIFICATIONFIELDS#DELIMETER" }, props.user.signInUserSession.accessToken.jwtToken);

            const customFieldData = await AppsyncDBconnection(listXlmsCustomFields, { PK: "TENANT#" + tenantID, SK: "CUSTOMFIELD#" }, props.user.signInUserSession.accessToken.jwtToken);
            const tenantInfo = await AppsyncDBconnection(getXlmsTenantInfo, {
                PK: "XLMS#TENANTINFO",
                SK: "#TENANT#" + tenantID,
            }, props.user.signInUserSession.accessToken.jwtToken);
            const tenantResponse = await AppsyncDBconnection(getXlmsCustomCertificate, {
                PK: "TENANT#" + tenantID,
                SK: "CUSTOMCERTIFICATE#" + urlSk,
            }, props.user.signInUserSession.accessToken.jwtToken);
            setFetchdata({
                TenantId: tenantID,
                mode: mode,
                EditData: mode == "Edit" && tenantResponse.res.getXlmsCustomCertificate,
                NotificationData: notificationFields.res?.getXlmsDefaultNotificationFields?.DefaultFields,
                CustomFieldData: customFieldData.res?.listXlmsCustomFields?.items,
                CurrentTenantInfo: tenantInfo.res.getXlmsTenantInfo,
                Contents: contents,
            });
        }
        FetchData();
        return (() => {
            setFetchdata((temp) => { return { ...temp }; });
        });
    }, [props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, router.query]);

    useEffect(() => {

        async function GetContents() {
            const contentsPromise = await fetch( process.env.APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE +"?ObjectUrl=" +fetchdata?.EditData?.TemplateUrlPath +"&S3BucketName=" + fetchdata?.CurrentTenantInfo?.BucketName +"&S3KeyName=" + fetchdata?.CurrentTenantInfo?.RootFolder + "/" +fetchdata?.CurrentTenantInfo?.TenantID,
                {
                    method: "GET",
                    headers: {
                        "Content-Type": "application/text",
                        authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                        defaultrole: props.user?.signInUserSession?.accessToken?.payload["cognito:groups"][0],
                        groupmenuname: "SiteConfiguration",
                        menuid: "601302"
                    },
                }
            );
            const contents = await contentsPromise.text();
            setCert(contents);
            const backgroundImg = contents.match(/&quot;(.*?)&quot;/g)?.map(function (x) {
                return x.substring(6, x.length - 6);
            });
            setImg(backgroundImg[0]);
        }
        if (fetchdata?.mode == "Edit") {
            GetContents();
            setValue("txtTempName", fetchdata?.EditData.TemplateName);
            setValue("txtTempDesc", fetchdata?.EditData.TemplateDescription);
            setValue("txtTempWidth", fetchdata?.EditData.TemplateWidth);
            setValue("txtTempHeight", fetchdata?.EditData.TemplateHeight);
            setValue("txtRightMargin", fetchdata?.EditData.TemplateRightMargin);
            setValue("txtLeftMargin", fetchdata?.EditData.TemplateLeftMargin);
            setValue("rbTemplateType", fetchdata?.EditData.TemplateType);
        }
        if (fetchdata?.EditData?.TemplateType == undefined) {
            setValue("rbTemplateType", "Landscape");
        }
        return (() => {
            setCert("");
        });
    }, [setValue, props.user.signInUserSession.accessToken.jwtToken, props.user.signInUserSession.accessToken?.payload, fetchdata?.mode, fetchdata?.EditData?.TemplateType, fetchdata?.EditData?.TemplateUrlPath, fetchdata?.CurrentTenantInfo?.BucketName, fetchdata?.CurrentTenantInfo?.RootFolder, fetchdata?.CurrentTenantInfo?.TenantID, fetchdata?.EditData?.TemplateName, fetchdata?.EditData?.TemplateDescription, fetchdata?.EditData?.TemplateWidth, fetchdata?.EditData?.TemplateHeight, fetchdata?.EditData?.TemplateRightMargin, fetchdata?.EditData?.TemplateLeftMargin]);

    const validationSchema = Yup.object().shape({
        txtTempName:
      currentStep == 1
          ? Yup.string()
              .required("Template name is Required")
              .matches(Regex("AlphaNumWithAllowedSpecialChar"), "Invalid Template Name").max("300","Maximum 300 characters exceed" )
              .test("Exists", "Temp Name Already exists", async (e) => {
                  if (fetchdata?.mode == "Edit" && e?.toLowerCase() == fetchdata?.EditData.TemplateName?.toLowerCase()) {
                      return true;
                  }
                  if (e == "" || !Regex("AlphaNumWithAllowedSpecialChar").exec(e)) {
                      previousState.current = { ...previousState.current, txtTempName: { previousVal: e, previousState: false } };
                      return false;
                  }

                  const existingTempName = await AppsyncDBconnection(listXlmsCustomCertificateExistsInfo, { PK: "TENANT#" + tenantId, SK: "CUSTOMCERTIFICATE#", TemplateNameLower: e?.toLowerCase(), IsDeleted: false }, props.user.signInUserSession.accessToken.jwtToken);
                  if (existingTempName.Status == "Success") {
                      if (existingTempName.res?.listXlmsCustomCertificateExistsInfo?.items?.length == 0) {
                          previousState.current = { ...previousState.current, txtTempName: { previousVal: e, previousState: true } };
                          return true;
                      }
                      previousState.current = { ...previousState.current, txtTempName: { previousVal: e, previousState: false } };
                      return false;
                  }
              })
          : Yup.string(),

        txtTempWidth: Yup.string().matches(Regex("AllowOnlyNumbers"), "Invalid Width").max(4, "Maximum character exceed")
        .test("","",(e,{createError})=>{
            if(e == 0) {
                return createError({message:"Width should be greater than zero"})
             }
            if( watch("rbTemplateType") == "Landscape" && e < landscapeValues.current.Width-1 || watch("rbTemplateType") == "Potrait" && e < portraitValues.current.Width-1 ) {
                return createError({message:"Width should not be lesser than default width"})
            }
             return true
        }).nullable(),

        txtTempHeight: Yup.string().matches(Regex("AllowOnlyNumbers"), "Invalid Height").max(4, "Maximum character exceed").test("","",(e,{createError})=>{
            if(e == 0) {
                return createError({message:"Height should be greater than zero"})
             }
            if( watch("rbTemplateType") == "Landscape" && e < landscapeValues.current.Height-1 || watch("rbTemplateType") == "Potrait" && e < portraitValues.current.Height-1 ) {
                return createError({message:"Height should not be lesser than default height"})
            }
             return true
        }).nullable(),

        txtRightMargin: Yup.string().matches(Regex("AllowOnlyNumbers"), "Invalid Right Margin").max(4, "Maximum character exceed").test("","",(e,{createError})=>{
            if(e == 0) {
                return createError({message:"Right Margin should be greater than zero"})
             }
            if( watch("rbTemplateType") == "Landscape" && e < landscapeValues.current.RightMargin-1 || watch("rbTemplateType") == "Potrait" && e < portraitValues.current.RightMargin-1 ) {
                return createError({message:"Right Margin should not be lesser than default Right Margin"})
            }
             return true
        }).nullable(),

        txtLeftMargin: Yup.string().matches(Regex("AllowOnlyNumbers"), "Invalid Left Margin").max(4, "Maximum character exceed").test("","",(e,{createError})=>{
            if(e == 0) {
                return createError({message:"Left Margin should be greater than zero"})
             }
            if( watch("rbTemplateType") == "Landscape" && e < landscapeValues.current.LeftMargin-1 || watch("rbTemplateType") == "Potrait" && e < portraitValues.current.LeftMargin-1 ) {
                return createError({message:"Left Margin should not be lesser than default Left Margin"})
            }
             return true
        }).nullable(),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, handleSubmit, setValue, watch, formState,clearErrors } = useForm(formOptions);
    const { errors } = formState;
    
    const value = watch("rbTemplateType");
    useEffect(() => {
        if (router.query["Mode"] == "Create") {
            clearErrors(["txtTempWidth"])
            clearErrors(["txtTempHeight"])
            if (value == "Landscape") {
                setValue("txtTempWidth", 210), setValue("txtTempHeight", 200);
            } else {
                setValue("txtTempWidth", 200), setValue("txtTempHeight", 210);
            }
        }
    }, [value, setValue, router.query, clearErrors]);
   

    useEffect(() => {
        if (router.query["Mode"] == "Create") {
            clearErrors(["txtRightMargin"])
            clearErrors(["txtLeftMargin"])
        if (value == "Landscape") {
            setValue("txtRightMargin", 10), setValue("txtLeftMargin", 11);
        } else {
            setValue("txtRightMargin", 10), setValue("txtLeftMargin", 10);
        }
    }
    }, [value, setValue, router.query, clearErrors]);

    const displayStep = (step) => {
        switch (step) {
        case 1:
            return (
                <CertificateInfo
                    watch={watch}
                    register={register}
                    errors={errors}
                    mode={fetchdata?.mode}
                />
            );
        case 2:
            return (
                <CertificateDesign
                    CertFrame={img}
                    watch={watch}
                    SetFrame={setImg}
                    cert={cert}
                    setCert={setCert}
                    NotificationData={notificationFields}
                />
            );
        case 3:
            return <CertificatePreview cert={cert} watch={watch} />;
        default:
        }
    };
    const submitHandler = useCallback(async (data) => {
        const loader = (temp) => {
            setValue("submit", temp);
        };
        if (currentStep === 3) {

            loader(true);
            try {
                let CertificateID;
                if (fetchdata?.mode == "Create") {
                    CertificateID = Math.random().toString(25).substring(2, 12);
                }
                else {
                    CertificateID = fetchdata?.EditData?.TemplateID;
                }
                const setUploadURL = process.env.APIGATEWAY_URL_CUSTOM_CERTIFICATE_UPLOAD_URL + "?TenantId=" + fetchdata?.TenantId + "&CustomCertID=" + CertificateID + "&BucketName=" + fetchdata?.CurrentTenantInfo?.BucketName + "&RootFolder=" + fetchdata?.CurrentTenantInfo?.RootFolder;
                let response = "";
                response = await fetch(setUploadURL + "&S3BucketName=" + fetchdata?.CurrentTenantInfo?.BucketName +   "&S3KeyName=" + fetchdata?.CurrentTenantInfo?.RootFolder + "/" +fetchdata?.CurrentTenantInfo?.TenantID, {
                    method: "POST",
                    headers: {"Content-Type": "application/text",authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,defaultrole: props.TenantInfo.UserGroup,groupmenuname: "SiteConfiguration",menuid: "601300"},
                    body: cert,
                });

                const variables = {
                    input: {
                        PK: "TENANT#" + tenantId,
                        SK: "CUSTOMCERTIFICATE#" + CertificateID,
                        TemplateID: CertificateID,
                        TemplateName: data.txtTempName.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                        TemplateDescription: data.txtTempDesc.replace(/\s{2,}(?!\s)/g, ' ').trim(),
                        TemplateWidth: data.txtTempWidth,
                        TemplateHeight: data.txtTempHeight,
                        TemplateRightMargin: data.txtRightMargin,
                        TemplateLeftMargin: data.txtLeftMargin,
                        TemplateType: data.rbTemplateType,
                        TemplateUrlPath: await response.text(),
                        TemplateNameLower: data.txtTempName.replace(/\s{2,}(?!\s)/g, ' ').trim().toLowerCase(),
                        IsDisabled: false,
                        IsDeleted: false,
                        TenantID: tenantId,
                        BucketName: fetchdata?.CurrentTenantInfo?.BucketName,
                        RootFolder: fetchdata?.CurrentTenantInfo?.RootFolder,
                        LastModifiedDate: new Date()

                    },
                };
                const finalStatus = await AppsyncDBconnection(fetchdata?.mode == "Create" ? createXlmsCustomCertificate : updateXlmsCustomCertificate, variables, props.user.signInUserSession.accessToken.jwtToken);
                finalResponse(finalStatus.Status);
                loader(false);
            }
            catch (e) {
                loader(false);
            }
        } else {
            if (currentStep == 2) {
                const a = document.getElementById("parent");
                setCert(a.outerHTML);
            }
            let newStep = currentStep;
            newStep++;
            setCurrentStep(newStep);

        }
        loader(false);
    }, [finalResponse, tenantId, cert, currentStep, fetchdata?.CurrentTenantInfo?.BucketName, fetchdata?.CurrentTenantInfo?.RootFolder, fetchdata?.CurrentTenantInfo?.TenantID, fetchdata?.EditData?.TemplateID, fetchdata?.TenantId, fetchdata?.mode, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken, setValue]);


    const handleClick = async () => {
        if (currentStep == 2) {
            const a = document.getElementById("parent");
            setCert(a.outerHTML);
        }
        let newStep = currentStep;
        newStep--;
        newStep > 0 && setCurrentStep(newStep);
    };
    const pageRoutes = useMemo(()=>{return [
        { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
        { path: "/SiteConfiguration/CustomCertificateList", breadcrumb: "Custom Certificate" },
        { path: "", breadcrumb: fetchdata?.mode == "Edit" ? "Edit Certificate" : "Add Custom Certificate" }
    ];},[fetchdata?.mode]) 

    return (
        <>
            <Container
                title={fetchdata?.mode == "Edit" ? "Edit Certificate" : "Create Certificate"} PageRoutes={pageRoutes} loader={fetchdata?.mode == undefined} >
                <NVLAlert
                    ButtonYestext={"X"}
                    MessageTop={modalValues?.ModalTopMessage}
                    MessageBottom={modalValues?.ModalBottomMessage}
                    ModalOnClick={modalValues?.ModalOnClickEvent}
                    ModalInfo={modalValues?.ModalInfo}
                />

                <div className="w-full sm:w-full sm:overflow-x-auto sm:overflow-y-auto md:w-full md:overflow lg:w-full lg:overflow-y-hidden xl:w-full xl:overflow-hidden flex-wrap">
                    <div className="mx-auto rounded-2xl bg-white pb-2 shadow-xl md:w-full">
                        <form onSubmit={handleSubmit(submitHandler)} className={`${ watch("submit") ? "pointer-events-none" : ""}`}>
                            <div className="w-full ">
                                <Stepper steps={steps} currentStep={currentStep} />
                                <div className="mt-16">
                                    <UseContextProvider>
                                        {displayStep(currentStep)}
                                    </UseContextProvider>
                                </div>
                            </div>
                            {currentStep > 0 && currentStep <= steps.length && (
                                <StepperControl
                                    handleClick={handleClick}
                                    currentStep={currentStep}
                                    steps={steps}
                                    Flag={watch("submit")}
                                />
                            )}
                        </form>
                    </div>
                </div>
            </Container>
        </>
    );
}