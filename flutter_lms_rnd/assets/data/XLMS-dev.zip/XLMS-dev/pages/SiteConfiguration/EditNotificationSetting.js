import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLRichTextBox, { getContents, setHTMLContents } from "@components/Controls/NVLRichTextBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLTextBox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXLMSDefaultNotificationTemplate } from "src/graphql/mutations";
import { getXLMSDefaultNotificationTemplate } from "src/graphql/queries";
import * as Yup from "yup";

function EditNotification(props) {
    const router = useRouter();
    const routerRef = useRef();
    const [csrFetchedNotificationData, setCsrFetchedNotificationData] = useState([]);
    const [getmessage, setMessage] = useState("");
    const [getSignature, setSignature] = useState("");
    useEffect(() => {
        const dataSource = async () => {
            routerRef.current = {
                Mode: decodeURIComponent(String(router.query["mode"])),
                PK: decodeURIComponent(String(router.query["PK"])),
                SK: decodeURIComponent(String(router.query["SK"])),
            };
            const fetchEditdata = await AppsyncDBconnection(getXLMSDefaultNotificationTemplate, { PK: routerRef.current.PK, SK: routerRef.current.SK }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const editData = fetchEditdata?.res?.getXLMSDefaultNotificationTemplate != undefined ? fetchEditdata?.res?.getXLMSDefaultNotificationTemplate : [];

            setCsrFetchedNotificationData({
                TemplateDetails: editData,
                Mode: routerRef.current.Mode,
                TenantID: "",
                TemplateName: "",
                Dropdown: editData?.Mail
            });
        };
        dataSource();
        return (() => {
            setCsrFetchedNotificationData((temp) => { return { ...temp }; });
        });
    }, [props.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

    const validationSchema = Yup.object().shape({
        ddlMail: Yup.string().nullable().test("", "", (e) => {
            if (e != csrFetchedNotificationData?.Dropdown) {
                setCsrFetchedNotificationData((csrFetchedNotificationData) => { return { ...csrFetchedNotificationData, Dropdown: e }; });
                setValue("txtEmailResendCount", "");
                setValue("ddlEmailResendDay", "");
            }
            return true;
        }),
        txtSubject: Yup.string().required("Subject is required").nullable(),
        txtEmailResendCount: Yup.string()
            .notRequired()
            .max(2, "Email resend count should not exceed more than 2 characters")
            .test("error", "", (val, { createError }) => {
                if (val == undefined || val == "" || val == null) {
                    return true;
                }
                const rejax = new RegExp(/^([1-9][0-9]{0,2})$/);
                if (!rejax.test(val)) {
                    return createError({ message: "Enter valid Email resend count" });
                }
                if (val < 1) {
                    return createError({ message: "Email resend count should not be less than 1" });
                }
                if (val > 10) {
                    return createError({ message: "Email resend count limit is 10" });
                }
                return true;
            })
            .nullable(true),
    });

    const initialModalState = {ModalInfo: "Success",ModalTopMessage: "Success",ModalBottomMessage: "Details have been saved successfully.",ModalOnClickEvent: () => {    router.push("/SiteConfiguration/NotificationSettingList");},};

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const [modalValues, setModalValues] = useState(initialModalState);

    const mail = [
        { value: "", text: "Select" },
        { value: "Daily", text: "Daily" },
        { value: "Week", text: "Week" },
        { value: "Month", text: "Month" },
    ];

    const resendDay = [
        { value: "", text: "Select" },
        { value: "Sunday", text: "Sunday" },
        { value: "Monday", text: "Monday" },
        { value: "Tuesday", text: "Tuesday" },
        { value: "Wednesday", text: "Wednesday" },
        { value: "Thursday", text: "Thursday" },
        { value: "Friday", text: "Friday" },
        { value: "Saturday", text: "Saturday" },
    ];
    const { register, handleSubmit, setValue, formState,watch} = useForm(formOptions);
    const { errors } = formState;

    const finalResponse = (FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        }
        ModalOpen();
        
    };

    useEffect(() => {
        if (csrFetchedNotificationData.Mode == "Edit") {
            if (getmessage != "" && getSignature != "") {
                setValue("txtSubject", csrFetchedNotificationData.TemplateDetails?.Subject);
                setValue("ddlMail", csrFetchedNotificationData.TemplateDetails?.Mail);
                setValue("txtEmailResendCount", csrFetchedNotificationData.TemplateDetails?.Mailsendinglimits);
                setValue("ddlEmailResendDay", csrFetchedNotificationData.TemplateDetails?.MailsendingDays);
                setHTMLContents(csrFetchedNotificationData.TemplateDetails?.TemplateBody, getmessage);
                setHTMLContents(csrFetchedNotificationData.TemplateDetails?.Signature, getSignature);
                getmessage?.history?.clear();
                getSignature?.history?.clear();
                getmessage?.disable();
            }
        }
    }, [getmessage, getSignature, setValue, csrFetchedNotificationData.TemplateDetails?.Subject, csrFetchedNotificationData.TemplateDetails?.Mail, csrFetchedNotificationData.TemplateDetails?.Mailsendinglimits, csrFetchedNotificationData.TemplateDetails?.MailsendingDays, csrFetchedNotificationData.TemplateDetails?.TemplateBody, csrFetchedNotificationData.TemplateDetails?.Signature, csrFetchedNotificationData.Mode]);

    const submitHandler = async (data) => {
        setValue("submit" ,true)
        const setPk = csrFetchedNotificationData.TemplateDetails?.PK;
        const setSk = csrFetchedNotificationData.TemplateDetails?.SK;
        const tenantID=setPk.split("#")[1];
        const variables = {
            input: {
                PK: setPk,
                SK: setSk,
                Subject: data.txtSubject,
                TemplateBody: getContents(getmessage),
                Mail: data.ddlMail,
                Signature: getContents(getSignature),
                Mailsendinglimits: data.txtEmailResendCount,
                MailsendingDays: data.ddlEmailResendDay,
                LastModifiedDate: new Date(),
                LastModifiedBy:props?.user?.username,
                TenantID:tenantID
            },
        };

        const finalStatus = (await AppsyncDBconnection(updateXLMSDefaultNotificationTemplate, variables, props?.user?.signInUserSession.accessToken?.jwtToken));
        finalResponse(finalStatus.Status);
        setValue("submit" ,false)
    };
    // Bread Crumbs
    const pageRoutes = useMemo(()=>{return[
        { path: "/SiteConfiguration/SiteConfigSettings", breadcrumb: "Site Configuration" },
        { path: "/SiteConfiguration/NotificationSettingList", breadcrumb: "Notification Setting" },
        { path: "", breadcrumb: "Edit Notification" }
    ];},[]);
    
    return (
        <>

            <Container loader={csrFetchedNotificationData.Mode == undefined} PageRoutes={pageRoutes} >
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)} className={`${ watch("submit") ? "pointer-events-none" : "px-2"}`}>
                    <div className="nvl-FormContent">
                        <NVLTextBox id="txtSubject" title="Subject Name" register={register} labelText="Subject" labelClassName="nvl-Def-Label" Value="Subject" disabled={true} errors={errors} className="nvl-mandatory nvl-Def-Input Disabled"></NVLTextBox>
                        <NVLlabel text="Message" className="nvl-Def-Label"></NVLlabel>
                        <NVLRichTextBox id="txtMessage" className="pointer-events-none select-none nvl-Def-Input Disabled" setState={setMessage}></NVLRichTextBox>
                        <NVLlabel text="Signature" className="nvl-Def-Label"></NVLlabel>
                        <NVLRichTextBox id="Signature" className="!nvl-Def-Input" setState={setSignature}></NVLRichTextBox>

                        <div className={`${csrFetchedNotificationData.TemplateDetails?.Remainder != true ? "hidden" : ""}`}>
                            <NVLSelectField id="ddlMail" title="Notification Sequence" labelText="Notification Sequence" labelClassName="nvl-Def-Label" className="nvl-non-mandatory nvl-Def-Input" errors={errors} register={register} options={mail} ></NVLSelectField>
                            <NVLTextBox id="txtEmailResendCount" title="Email Resend Count" labelText="Email Resend Count" labelClassName="nvl-Def-Label" register={register} errors={errors} className="nvl-non-mandatory nvl-Def-Input"></NVLTextBox>
                            <NVLSelectField id="ddlEmailResendDay" title="Email Resend Day" labelText="Email Resend Day" labelClassName="nvl-Def-Label" className={`nvl-non-mandatory nvl-Def-Input ${csrFetchedNotificationData?.Dropdown == "Daily" ? "Disabled" : ""}`} errors={errors} register={register} options={resendDay} disabled={csrFetchedNotificationData?.Dropdown == "Daily" ? true : false}></NVLSelectField>
                        </div>
                        <div className=" flex flex-row gap-1 justify-center nvl-Def-Input mt-4">
                            <NVLButton id="btnSave" text={watch("submit") ? "" :"Save"} type="submit" className={"w-32 nvl-button bg-primary text-white "}>
                            { watch("submit") && <i className="fa fa-circle-notch fa-spin mr-2"></i> }
                            </NVLButton>
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default EditNotification;

