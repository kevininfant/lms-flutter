import Container from "@components/Container/Container";
import NVLCard from "@components/Controls/NVLCard";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import { listXlmsGlossaryManagementInfo } from "@graphql/graphql/queries";
import { useRouter } from "next/router";
import { useCallback, useMemo, useState } from "react";

export default function GlossaryList(props) {
  const [searchClick, setSearchClick] = useState({
    id: 0,
    search: false,
    letter: ""
  })
  const [isRefreshing, setIsRefreshing] = useState(true);
  const [search, setSearch] = useState("")

  const router = useRouter();

  const PageRoutes = useMemo(() => {
    return [{ path: "", breadcrumb: "Glossary" }]
  }, [])
  const alphabets = useMemo(() => {
    let letters = ["Special", "All"]
    let a = 1
    for (let i = 65; i <= 90; i++) {
      letters.splice(a, 0, String.fromCharCode(i));
      a++;
    }
    return letters;
  }, []);


  const glossaryList = useCallback(() => {

    return {
      PK: "TENANT#" + props?.TenantInfo.TenantID,
      SK: "GLOSSARY#CONCEPT#PATTERN#",
      IsDeleted: false,
      GlossaryType: searchClick.search == false || (searchClick.search == true && searchClick.letter == "All") ? "" : "Pattern",
      Pattern: searchClick.search == false || (searchClick.search == true && searchClick.letter == "All") ? "" : searchClick.letter
    }
  }, [props?.TenantInfo?.TenantID, searchClick.letter, searchClick.search])

  const searchWithAlphabets = (letter, index) => {
    refreshData()
    if (document.getElementById("tableSearch")) {
      document.getElementById("tableSearch").value = "";
    }
    setSearchClick({ id: index, search: true, letter: letter })
  }
  const headerColumn = useMemo(() => {
    return [{ HeaderName: "", Columnvalue: "Concept" }];
  }, []);
  const searchBoxVal = (e) => {
    setSearch(e);
    setIsRefreshing((count) => {
      return count + 1;
    });
  }
  const refreshData = async () => {
    setSearch("");

    setIsRefreshing((count) => {
      return count + 1;
    });
  };
  const gridDataBind = useCallback(async (glossaryData) => {
    const rowGrid = [];
    glossaryData.map((data, index) => {
      rowGrid.push({
        Concept:<NVLCard data={data} id={'card' + index + 1} role={props?.TenantInfo?.UserGroup}
          token={props?.user?.signInUserSession?.accessToken?.jwtToken} bucketName={props?.TenantInfo.BucketName} />
      })
    })
    return rowGrid;
  }, [props?.TenantInfo.BucketName, props?.TenantInfo?.UserGroup, props?.user?.signInUserSession?.accessToken?.jwtToken])

  return (
    <>
      <Container title="Glossary" PageRoutes={PageRoutes}>
        <NVLHeader TabRouting={props?.GeneralRoleData?.AllowNewTab}
         IsSearch={props.RoleData?.SeTenanthGlossary? true : false}

          placeholder={"Search by Concept or Keyword "}
          SearchonChange={(e) => searchBoxVal(e)} RedirectAction3={() => refreshData()} onClick1={refreshData} IsNestedHeader />
        <h1 className="p-3">Browse the glossary using this index</h1>
        <div className="h-14 border-b-gray-300 border-t-white border-x-white border-2">
          {alphabets.map((letters, index) => {
            return (
              <div key={index} className="inline-block">
                <button className={`text-blue-600 font-semibold ${letters == "All" && searchClick.search == false ? "text-gray-700" : searchClick.search && index == searchClick.id ? "text-gray-700" : ""}`}
                  onClick={() => searchWithAlphabets(letters, index)}>{letters} </button>  |
              </div>
            )
          })}
        </div>
        <div className="px-10 pt-3">
          <NVLGridTable
            user={props.user}
            HeaderColumn={headerColumn}
            GridDataBind={gridDataBind}
            query={listXlmsGlossaryManagementInfo}
            querryName={"listXlmsGlossaryManagementInfo"}
            variable={glossaryList()}
            refershPage={isRefreshing}
            Search={search}
            glossary={true}
            DonotLoad={true}
          />
        </div>
      </Container>
    </>
  )
}
