import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLWebWorker from "@components/Controls/NVLWebWorker";
import ConsumeAssignment from "@Pages/MyLearning/UserConsumerPages/ConsumeAssignment";
import ConsumeDiscussion from "@Pages/MyLearning/UserConsumerPages/ConsumeDiscussion";
import ConsumeFeedback from "@Pages/MyLearning/UserConsumerPages/ConsumeFeedback";
import ConsumeFile from "@Pages/MyLearning/UserConsumerPages/ConsumeFile";
import ConsumePage from "@Pages/MyLearning/UserConsumerPages/ConsumePage";
import ConsumeScrom from "@Pages/MyLearning/UserConsumerPages/ConsumeScrom";
import ConsumeURL from "@Pages/MyLearning/UserConsumerPages/ConsumeURL";
import ConsumeVideo from "@Pages/MyLearning/UserConsumerPages/ConsumeVideo";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import "quill/dist/quill.bubble.css";
import "quill/dist/quill.snow.css";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createXlmsCourseEnrollUser, createXlmsUserCertificateInfo, updateXlmsCourseEnrollUser, updateXlmsEnrollUser } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseManagementInfo } from "src/graphql/queries";
import ConsumeZoom from "./ConsumeZoom";
import ConsumeQuiz from "./UserConsumerPages/ConsumeQuiz";

export default function UserConsumeList({ LanguageName, updateCourseEnrollDataRef, ActivityData, UpdateCourseEnrollData, props, QuesTemplate, CourseEnrollData, EnrollCourseData, ChangeActId, lol }) {
    const EnrollCourseDataRef = useRef(EnrollCourseData);
    useEffect(() => {
        if (props?.ActivityData?.IsActivityCompletion && props?.ActivityData?.IsViewTheActivity && props?.CompletedStatus != "100") {
            appSyncDbConnectionModule();
        }
    }, [appSyncDbConnectionModule, props?.ActivityData?.ActivityType, props?.ActivityData?.IsActivityCompletion, props?.ActivityData?.IsViewTheActivity, props?.CompletedStatus]);
    const ModuleLength = useMemo(() => {
        let temp = EnrollCourseDataRef.current;

        const restriction = Object.values(JSON.parse(temp?.Restriction != undefined ? temp.Restriction : "{}"));
        const groupBy = function (xs, key) {
            return xs.reduce(function (rv, x) {
                (rv[x[key]] = rv[x[key]] || []).push(x);
                return rv;
            }, {});
        };
        const ModuleMust = restriction[0]?.flow?.must != undefined ? restriction[0]?.flow?.must : [];
        const ModuleMustJson = groupBy(ModuleMust, "ModuleID");
        const ModuleLength = ModuleMustJson?.[props?.ActivityData?.ModuleID]?.length != undefined ? ModuleMustJson?.[props?.ActivityData?.ModuleID]?.length : 1;
        return ModuleLength;
    }, [props?.ActivityData?.ModuleID])

    const appSyncDbConnectionModule = useCallback(async (Status = "100", Data) => {
        let temp = EnrollCourseDataRef.current != undefined ? EnrollCourseDataRef.current : {};
        let CompletionsStatus = JSON.parse(temp?.CompletionStatus != undefined ? temp?.CompletionStatus : "{}"), prevProgress = CompletionsStatus?.progress;
        temp = { ...temp, CompletionStatus: CompletionsStatus };
        let CurrentStatus = "0";
        if (CompletionsStatus?.[props?.ActivityData?.ActivityID]?.CompletionStatus != undefined) {
            CurrentStatus = CompletionsStatus?.[props?.ActivityData?.ActivityID]?.CompletionStatus;
        }
        else if ((props?.ActivityData?.CourseID == undefined || props?.ActivityData?.CourseID == null) && props?.EnrollData?.CompletedStatus != undefined) {
            CurrentStatus = props?.EnrollData?.CompletedStatus;
        }
        if (parseInt(Status) < parseInt(CurrentStatus)) {
            Status = CurrentStatus;
        }
        const date = new Date();
        if (props?.ActivityData?.CourseID != undefined) {
            temp = { ...temp, LastModifiedDate: new Date() };
            if (temp?.CompletionStatus != undefined) {
                const tempStatus = temp?.CompletionStatus;
                temp.CompletionStatus = { ...tempStatus, [props?.ActivityData?.ActivityID]: { CompletionStatus: Status } };
            }
            else {
                temp.CompletionStatus = { [props?.ActivityData?.ActivityID]: { CompletionStatus: Status } };
            }
            let progress = 0;
            if ((Status == "100" && CurrentStatus != "100")) {
                const restriction = Object.values(JSON.parse(temp.Restriction != undefined ? temp.Restriction : "{}"));
                const length = restriction[0]?.flow?.must?.length != undefined ? restriction[0]?.flow?.must?.length : 1;
                const CompletedAct = temp?.CompletionStatus?.CompletedActivity != undefined ? temp?.CompletionStatus?.CompletedActivity : 0, CompletedModuleAct = temp?.CompletionStatus?.[props?.ActivityData?.ModuleID]?.CompletedActivity != undefined ? temp?.CompletionStatus?.[props?.ActivityData?.ModuleID]?.CompletedActivity : 0;
                temp.CompletionStatus = { ...temp.CompletionStatus, [props?.ActivityData?.ModuleID]: { progress: parseInt((CompletedModuleAct + 1) * 100 / ModuleLength), CompletionDate: new Date(), CompletedActivity: CompletedModuleAct + 1 }, progress: parseInt((CompletedAct + 1) * 100 / length), CompletedActivity: CompletedAct + 1, [props?.ActivityData?.ActivityID]: { ...temp?.CompletionStatus?.[props?.ActivityData?.ActivityID], CompletionDate: date }, CompletionDate: new Date() }
                progress = ((CompletedAct + 1) * 100 / length);
            }
            temp.CompletionStatus = JSON.stringify(temp?.CompletionStatus != undefined ? temp?.CompletionStatus : "{}");
            temp.LastModifiedDate = new Date();
            if (Data != undefined) {
                temp = { ...temp, ...Data }
            }
            const removeEmpty = (obj) => {
                let tempjson = {};
                Object.keys(obj).forEach((k) => {
                    if (obj?.[k] != undefined&&k!=="__typename") {
                        tempjson = { ...tempjson, [k]: obj?.[k] }
                    }
                });
                return tempjson;
            };
            let tempEnrollRef = removeEmpty(temp);
            EnrollCourseDataRef.current = tempEnrollRef;
                        updateCourseEnrollDataRef(tempEnrollRef);
            AppsyncDBconnection(createXlmsCourseEnrollUser, { input: tempEnrollRef }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            if (progress == 100 && prevProgress != 100) {
                generateCertificate();
            }
        }
        else if (props?.ActivityData?.CourseID == undefined) {
            let activityCompletedStatus = {
                PK: props?.EnrollData?.PK,
                SK: props?.EnrollData?.SK,
                CompletedStatus: Status,
                LastModifiedDate: date
            };
            if (Status == "100") {
                activityCompletedStatus = { ...activityCompletedStatus, CompletionDate: date };
            }
            if (Data != undefined) {
                activityCompletedStatus = { ...activityCompletedStatus, ...Data }
            }
            await AppsyncDBconnection(updateXlmsEnrollUser, { input: activityCompletedStatus }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            if (Status == "100") {
                generateCertificate();
            }
        }
    }, [ModuleLength, generateCertificate, props?.ActivityData?.ActivityID, props?.ActivityData?.CourseID, props?.ActivityData?.ModuleID, props?.EnrollData?.CompletedStatus, props?.EnrollData?.PK, props?.EnrollData?.SK, props?.user?.signInUserSession?.accessToken?.jwtToken, updateCourseEnrollDataRef]);

    const [feedbackLanguage, setFeedbackLanguage] = useState("");
    const description = useRef(null);

    // useEffect(() => {
    //     if (description.current != undefined && props?.ActivityData?.ActivityDescription != "" && props?.ActivityData?.ActivityDescription != undefined)
    //         description.current.innerHTML = "<div class='text-md font-extrabold w-full break-words'>Description:</div>" +
    //             props?.ActivityData?.ActivityDescription;
    // }, [props]);
    const ActivityDescription = useCallback(() => {
        return (
            <>
                <div className="!w-full break-all text-xs p-2 ">
                    <div className='text-md font-extrabold break-words underline text-[#F47A22]'>Description</div>
                    <hr></hr>
                    <div className="mt-4">
                        <div>{props?.ActivityData?.ActivityDescription?.toString()?.replace(/(<([^>]+)>)/ig, '')}</div>
                    </div>
                </div>
            </>
        );
    }, [props?.ActivityData?.ActivityDescription]);

    const generateCertificate = useCallback(async () => {
        if (props?.TenantInfo?.TenantID == undefined) {
            return;
        }
        if (props?.ActivityData?.CourseID != undefined) {
            AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSEBADGE#" + props?.ActivityData?.CourseID }, props?.user.signInUserSession.accessToken.jwtToken).then((data) => {
                if (data?.res?.getXlmsCourseManagementInfo != undefined) {
                    const variables = {
                        input: {
                            PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + props?.user?.attributes?.["sub"],
                            SK: "BADGE#" + props?.ActivityData?.CourseID,
                            CertificateImagePath: data?.res?.getXlmsCourseManagementInfo?.BadgeUploadFile,
                            BadgeName: data?.res?.getXlmsCourseManagementInfo?.BadgeName,
                            IsAvailable: true
                        }
                    };
                    AppsyncDBconnection(createXlmsUserCertificateInfo, variables, props?.user.signInUserSession.accessToken.jwtToken);
                }
            });
            AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSECERTIFICATE#" + props?.ActivityData?.CourseID }, props?.user.signInUserSession.accessToken.jwtToken).then((data) => {
                if (data?.res?.getXlmsCourseManagementInfo != undefined && props?.EnrollData?.CertificatePath == undefined) {
                    const fetchURL = `${process.env.APIGATEWAY_URL_SCORMFILEUPlOAD}?S3BucketName=${props?.TenantInfo?.BucketName}&S3KeyName=${props?.TenantInfo?.RootFolder}`;
                    const statemachinearn = process.env.STEP_FUNCTION_ARN_CERTIFICATE_GENERATION;
                    const json = {
                        "TenantID": props?.TenantInfo?.TenantID,
                        "UserSub": props?.user.attributes["sub"],
                        "CourseID": props?.ActivityData?.CourseID,
                        "BatchID": props?.EnrollCourseData?.BatchID,
                        "ActivityType": "",
                        "ActivityID": ""
                    };
                    const headers = {
                        method: "POST",
                        headers: {
                            authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
                            defaultrole: props?.TenantInfo?.UserGroup,
                            groupmenuname: "ActivityManagement",
                            menuid: "500013",
                            statemachinearn: statemachinearn
                        },
                        body: JSON.stringify(json),
                    };
                    APIGatewayPostRequest(fetchURL, headers);
                }
            });
        }
        else {
            AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#" + props?.ActivityData?.ActivityType + "#ACTIVITYID#" + props?.ActivityData?.ActivityID },
                props?.user.signInUserSession.accessToken.jwtToken).then((data) => {
                                        if (data?.res?.getXlmsActivityManagementInfo?.BadgeUploadFile != undefined) {
                        const variables = {
                            input: {
                                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + props?.user?.attributes?.["sub"],
                                SK: "BADGE#" + props?.ActivityData?.ActivityID,
                                CertificateImagePath: data?.res?.getXlmsActivityManagementInfo?.BadgeUploadFile,
                                BadgeName: data?.res?.getXlmsActivityManagementInfo?.BadgeName,
                                IsAvailable: true
                            }
                        };
                        AppsyncDBconnection(createXlmsUserCertificateInfo, variables, props?.user.signInUserSession.accessToken.jwtToken);
                    }
                    if (data?.res?.getXlmsActivityManagementInfo?.CertificateTemplate != undefined && props?.EnrollData?.CertificatePath == undefined) {
                        const fetchURL = `${process.env.APIGATEWAY_URL_SCORMFILEUPlOAD}?S3BucketName=${props?.TenantInfo?.BucketName}&S3KeyName=${props?.TenantInfo?.RootFolder}`;
                        const statemachinearn = process.env.STEP_FUNCTION_ARN_CERTIFICATE_GENERATION;
                        const json = {
                            "TenantID": props?.TenantInfo?.TenantID,
                            "UserSub": props?.user.attributes["sub"],
                            "CourseID": "",
                            "BatchID": "",
                            "ActivityType": props?.ActivityData?.ActivityType,
                            "ActivityID": props?.ActivityData?.ActivityID
                        };
                        const headers = {
                            method: "POST",
                            headers: {
                                authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
                                defaultrole: props?.TenantInfo?.UserGroup,
                                groupmenuname: "ActivityManagement",
                                menuid: "500013",
                                statemachinearn: statemachinearn
                            },
                            body: JSON.stringify(json),

                        };
                        APIGatewayPostRequest(fetchURL, headers);
                    }
                });   

        }
    }, [props.TenantInfo.TenantID, props.TenantInfo?.BucketName, props.TenantInfo?.RootFolder, props.TenantInfo?.UserGroup, props?.ActivityData?.CourseID, props?.ActivityData?.ActivityType, props?.ActivityData?.ActivityID, props?.user.signInUserSession.accessToken.jwtToken, props?.user.attributes, props?.EnrollData?.CertificatePath, props?.EnrollCourseData?.BatchID]);

    const filterLanguage = useMemo(() => {
        let languageType = [];
        if (Object.keys(JSON.parse(((LanguageName?.items[0]?.LanguageName != undefined) ? LanguageName?.items[0]?.LanguageName : "{}"))) != undefined) {
            Object.entries(JSON.parse((LanguageName?.items[0]?.LanguageName != undefined) ? LanguageName?.items[0]?.LanguageName : "{}")).forEach(([key, value]) => {
                languageType = [...languageType, { value: value, text: key }];
            });
        }
        let ddlLanguageType = [];
        if (ActivityData?.ActivityType == "Feedback") {
            const tempdata = JSON.parse(props?.EnrollCourseData?.QuestionandOptions != undefined ? props?.EnrollCourseData?.QuestionandOptions : "{}");

            if (props?.EnrollCourseData?.QuestionandOptions != undefined && tempdata?.[ActivityData?.ActivityID] != undefined) {

                const tempfeed = (tempdata?.[ActivityData?.ActivityID]);
                Object.values(tempfeed)?.forEach((value) => {
                    const temp = languageType?.filter((x) => x.value == value.Language);
                    if (temp.length > 0) {
                        ddlLanguageType = [...ddlLanguageType, { ...temp[0] }];
                        ddlLanguageType = [...new Map(ddlLanguageType?.map(item => [item["value"], item])).values()];
                    } else {
                        ddlLanguageType = [{ text: "Select", value: "" }];
                    }
                });

                setFeedbackLanguage(ddlLanguageType);

            }
            else if (props.ActivityData?.QuestionandOptions != null) {
                [JSON.parse(props.ActivityData?.QuestionandOptions)]?.forEach((item) => {
                    Object.values(item)?.forEach((value) => {
                        const temp = languageType?.filter((x) => x.value == value.Language);
                        if (temp.length > 0) {
                            ddlLanguageType = [...ddlLanguageType, { ...temp[0] }];
                            ddlLanguageType = [...new Map(ddlLanguageType?.map(item => [item["value"], item])).values()];
                        } else {
                            ddlLanguageType = [{ text: "Select", value: "" }];
                        }
                    });
                });
                setFeedbackLanguage(ddlLanguageType);
            }
        } else {
            if (ActivityData?.AttachFiles != undefined && JSON?.parse(ActivityData?.AttachFiles) != null) {
                JSON?.parse(ActivityData?.AttachFiles).map((e) => {
                    const temp = languageType.filter((x) => x.value == e.Language);
                    if (temp.length > 0) {
                        ddlLanguageType = [...ddlLanguageType, { ...temp[0] }];
                    }
                });
            } else {
                ddlLanguageType = "";
            }
            return ddlLanguageType;
        }
    }, [ActivityData?.ActivityID, ActivityData?.ActivityType, ActivityData?.AttachFiles, LanguageName?.items, props.ActivityData?.QuestionandOptions, props?.EnrollCourseData?.QuestionandOptions]);
    const markAsCompleted = useCallback((formOptions) => {
        let disabled = false;
        if (formOptions?.watch != undefined) {
            disabled = formOptions.watch("markTheActivity");
        }
        return (
            <>
                {(!(props?.EnrollData?.CompletedStatus == "100" || JSON.parse(props?.EnrollCourseData?.CompletionStatus != undefined ? props?.EnrollCourseData?.CompletionStatus : "{}")?.[props?.ActivityData?.ActivityID]?.CompletionStatus == "100")) &&
                    ((props?.ActivityData?.IsActivityCompletion)
                        && !(props?.ActivityData?.IsViewTheActivity)
                        && (props?.ActivityData?.IsMarkTheActivity)) && formOptions?.register != undefined
                    &&
                    <div className=" flex gap-4 m-1 text-xs font-semibold  rounded-md p-2 justify-between">
                        <NVLCheckbox className="!text-slate-700" text="Mark As Completed" disabled={disabled} id="markTheActivity" errors={formOptions.errors} watch={formOptions.watch} register={formOptions.register} showFull></NVLCheckbox>
                    </div>}
            </>);
    }, [props?.EnrollData?.CompletedStatus, props?.EnrollCourseData?.CompletionStatus, props?.ActivityData?.ActivityID, props.ActivityData?.IsActivityCompletion, props.ActivityData?.IsMarkTheActivity, props.ActivityData?.IsViewTheActivity]);

    const UserConsumePage = useCallback(({ props }) => {
        let currentquery = [];
        if (props?.CourseEnrollData != undefined) {
            currentquery = [updateXlmsCourseEnrollUser];
        }
        else {
            currentquery = [updateXlmsEnrollUser];
        }

        switch (ActivityData?.ActivityType) {
            case "File":
                return <ConsumeFile UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "Assignment":
                return <ConsumeAssignment updateCourseEnrollDataRef={updateCourseEnrollDataRef} UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "Video":
                return <ConsumeVideo UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "Url":
                return <ConsumeURL ChangeActId={ChangeActId} UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "Feedback":
                return <ConsumeFeedback UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} props={props} LanguageType={feedbackLanguage} QuesTemplate={QuesTemplate} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} />;
            case "Discussion":
                return <ConsumeDiscussion UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "Page":
                return <ConsumePage UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "ScormPackage":
                return <ConsumeScrom updateCourseEnrollDataRef={updateCourseEnrollDataRef} UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "Quiz":
                return <ConsumeQuiz UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            case "Zoom":
                return <ConsumeZoom UpdateCourseEnrollData={UpdateCourseEnrollData} CourseEnrollData={CourseEnrollData} Updatequery={currentquery} AppSyncDbConnectionModule={appSyncDbConnectionModule} MarkAsCompleted={markAsCompleted} props={props} LanguageType={filterLanguage} />;
            default:
                return <></>;
        }
    }, [ActivityData?.ActivityType, UpdateCourseEnrollData, CourseEnrollData, appSyncDbConnectionModule, markAsCompleted, filterLanguage, updateCourseEnrollDataRef, ChangeActId, feedbackLanguage, QuesTemplate]);
    return (
        <div>
            <NVLWebWorker props={props} />
            <div className="border p-2 my-4">
                <UserConsumePage props={props} />
                <ActivityDescription />
            </div>

        </div>
    );
}