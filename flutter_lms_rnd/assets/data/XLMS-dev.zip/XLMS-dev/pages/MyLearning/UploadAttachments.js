import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLoader from "@components/Controls/NVLLoader";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPutRequest } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function UploadAttachments(props) {
    const uploadedFileize = useRef(0);
    const [fileValues, setFileValues] = useState({
        FileName: "Select File",
        FilePath: null,
        path: null,
        pathchanged: false,
    });

    useEffect(() => {
        if (props.open) {
            clearForm();
        }
    }, [clearForm, props.open]);

    const validationSchema = Yup.object().shape({
        File: Yup.string()
            .test("file_Error", "", (errorName, { createError }) => {
                let message = "";
                if (errorName == "exist") {
                    return true;
                }
                if (errorName == undefined) {
                    return createError({ message: "File is required" });
                }
                if (errorName != undefined) {
                    if (errorName.split("~")[0] == "Empty") {
                        return createError("File is required");
                    }
                    else if (errorName.split("~")[0] == "fileType") {
                        message = "File Format Is Invalid.";
                    } else if (errorName.split("~")[0] == "InvalidSize") {
                        message = "File size exceeds maximum allowed";
                    }
                    if (message != "") {
                        setValue(errorName.split("~").pop(), message);
                        return createError({ message: message });
                    } else {
                        setValue(errorName.split("~").pop(), undefined);
                        return true;
                    }
                }
            })
            .nullable(),

    });

    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };

    const { handleSubmit, reset, setValue, watch, formState } =
    useForm(formOptions);
    const { errors } = formState;

    const clearForm = useCallback(() => {
        reset();
        document.getElementById("getFile").value = null;
        setFileValues({ FileName: "Select File", FilePath: null });
        setValue("submit", false);
    }, [reset, setValue]);

    const getContentType = (Extension) => {
        switch (Extension) {
        case "mkv":
            return "video/x-matroska";
        case "avi":
            return "video/x-ms-video";
        case "mov":
            return "video/quicktime";
        case "wmv":
            return "video/x-ms-wmv";
        case "mp4":
            return "video/mp4";
        case "mpeg4":
            return "video/mpeg4";
        case "txt":
            return "text/html";
        case "xls":
            return "application/vnd.ms-excel";
        case "ppt":
            return "application/vnd.ms-powerpoint";
        case "pptx":
            return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
        case "xlsx":
            return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
        case "tar":
            return "application/x-tar";
        case "rar":
            return "application/vnd.rar";
        case "h5p":
            return "application/octet-stream";
        default:
            return "application/" + Extension;
        }
    };

  

    // useEffect(() => {
    //     const GetUpdatedData = async () => {
    //         const PK = props?.RedirectMode == "Course" ? props.Data?.CourseEnrollData.PK : props?.Data?.UserInfo?.PK;
    //         const SK = props?.RedirectMode == "Course" ? props.Data?.CourseEnrollData.SK : props?.Data?.UserInfo?.SK;
    //         const Query = props?.RedirectMode == "Course" ? getXlmsCourseEnrollUser : getXlmsEnrollUser;
    //         const UserInfo = await AppsyncDBconnection(
    //             Query,
    //             {
    //                 PK: PK,
    //                 SK: SK,
    //             },
    //             props?.props.user.signInUserSession.accessToken.jwtToken
    //         );
    //         const GetQuery = props?.RedirectMode == "Course" ? "getXlmsCourseEnrollUser" : "getXlmsEnrollUser";
    //         const Final = UserInfo?.res?.[GetQuery];
    //     };
    //     GetUpdatedData();
    // }, [props]);

    async function fileValidation(e,) {
        if (e?.target?.files?.[0] == undefined) {
            return false;
        }
        uploadedFileize.current = (e.target.files[0].size);
        const temp = props.forwardedRef.current?.[props.Data.TopicID];
  
        setValue("File", "Uploading");
        const fileInput = document.getElementById(e.target.id);
        const filePath = fileInput.value;
        const filesize = ~~((e.target.files[0].size / (1024*1024)));
        const existingFileSize = (temp?.["Size"]);
        const allowedExtensions =
      /(\.docx|\.doc|\.ppt|\.pptx|\.pdf|\.csv|\.jpg|\.jpeg|\.png|\.avi|\.mov|\.txt|\.xls|\.xlsx|\.mp4|\.mpeg4|\.tar|\.rar|\.zip)$/i;
        if (!allowedExtensions.exec(filePath) || fileInput == null) {
            fileInput.value = "";
            setFileValues({ ...fileValues, FileName: "Select File", FilePath: "" });
            setValue("File", "fileType", { shouldValidate: true });
            return false;
        }
        else if (existingFileSize - filesize <= 0) {
            fileInput.value = "";
            setValue("File", "InvalidSize", { shouldValidate: true, });
            return false;
        }
        else {
            setFileValues({ ...fileValues, FileName: fileInput, FilePath: "" });
            await UploadFile(e);
        }
    }


    const createFile = (bits, name) => {
        try {
            return new File(bits, name, {
                type: "image/" + name.split(".").pop(),
                lastModified: new Date(),
            });
        } catch (e) {
            const myBlob = new Blob(bits);
            myBlob.lastModified = new Date();
            myBlob.name = name;
            return myBlob;
        }
    };

    async function UploadFile(e) {
        if (e.target.files.length == 0) {
            setValue("File", "Empty", { shouldValidate: true });
            return;
        }

        let file = e.target.files[0];
        let Extension = e.target.files[0].name
            .substring(e.target.files[0].name.lastIndexOf(".") + 1)
            .toLowerCase();

        let FileName = e.target.files[0].name;
        if (
            (file.name.split(".").pop() == "jpg" &&
        file.type.split("/").pop() == "jpeg") ||
      (file.name.split(".").pop() == "jpeg" &&
        file.type.split("/").pop() == "jpg")
        ) {
            FileName = FileName.split(".")[0] + "." + file.type.split("/").pop();
            file = createFile([file], FileName);
        }
        setFileValues({
            FileName: "Select File",
            FilePath: null,
            path: null,
            pathchanged: false,
        });

        const filename = encodeURIComponent(file.name);
        Extension = filename
            .substring(filename.lastIndexOf(".") + 1)
            .toLowerCase();
        const groupmenuName = "ActivityManagement";
        const menuId = "500002";
        const headers = {
            method: "GET",
            headers: {
                authorizationToken: await Auth.currentSession().then((s) =>
                    s.getAccessToken().getJwtToken()
                ),
                defaultrole: props.props.TenantInfo.UserGroup,
                groupmenuname: groupmenuName,
                menuid: menuId,
            },
        };
        const contentType = Extension == "csv" ? "text/" + Extension : Extension == "jpeg" || Extension == "jpg" || Extension == "png" ? "image/" + Extension : getContentType(Extension);
        const activitytype = props.RedirectMode == "Course" ? props.Data.ActivityData?.ActivityType : props.Data.UserInfo?.ActivityType;
        const fetchURL = props.RedirectMode == "Course" ? process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${file.name}&TenantID=${props?.props?.TenantInfo?.TenantID}&CourseType=Module&RootFolder=${props?.props?.TenantInfo?.RootFolder}&BucketName=${props?.props?.TenantInfo?.BucketName}&Type=Course&ManagementType=CourseManagement&ActivityType=${props.Data.ActivityData?.ActivityType}` :
            process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY +
      `?FileName=${file.name}&TenantID=${props.props.TenantInfo?.TenantID}&BucketName=${props.props.TenantInfo?.BucketName}&RootFolder=${props.props.TenantInfo?.RootFolder}&ActivityType=${activitytype}&Type=Activity&ActivityID=${props.Data.ActivityID}`;

        const presignedHeader = {
            method: "PUT",
            headers: {
                //"x-amz-acl": "public-read",
                "content-type": contentType,
                defaultrole: props.props.TenantInfo.UserGroup,
                groupmenuname: "ActivityManagement",
                menuid: "500002",
            },
            body: file,
        };
        const finalStatus = await APIGatewayPutRequest(
            fetchURL,
            headers,
            presignedHeader
        );
        if (finalStatus[0] != "Success") {
            setFileValues({ ...fileValues, FileName: "Select File", FilePath: "" });
            setValue("File", "Error", { shouldValidate: true });
            return;
        }
        else {
            setValue("File", "exist", { shouldValidate: true });
            setFileValues({
                ...fileValues,
                FileName: file.name,
                FilePath: finalStatus[1],
            });

        }
    }

    const submithandler = async () => {
        const temp = props.forwardedRef.current?.[props.Data.TopicID];
        setValue("File", "Empty", { shouldValidate: true });
        setValue("submit", false);
        setValue("submitloader", "true");
        const fetchURL = props?.RedirectMode == "Course" ? process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${fileValues.FileName}&ActivityID=${props.Data?.ActivityData?.ActivityID}&Type=Course&TenantID=${props.props.TenantInfo?.TenantID}&RootFolder=${props.props.TenantInfo?.RootFolder}&BucketName=${props.props.TenantInfo?.BucketName}&ActivityType=${props.Data.ActivityData?.ActivityType}&ManagementType=CourseManagement&CourseID=${props.Data.ActivityData?.CourseID}&ModuleID=${props.Data.ActivityData?.ModuleID}&CourseType=Module` : process.env.ACTIVITY_UNSAVED_TO_SAVED + `?FileName=${fileValues.FileName}&ActivityID=${props.Data.UserInfo?.ActivityID}&Type=Activity&TenantID=${props.props.TenantInfo?.TenantID}&RootFolder=${props.props.TenantInfo?.RootFolder}&BucketName=${props.props.TenantInfo?.BucketName}&ActivityType=${props.Data.UserInfo?.ActivityType}`;
        const groupMenuName = props?.RedirectMode == "Course" ? "CourseManagement" : "ActivityManagement";
        const menuId = props?.RedirectMode == "Course" ? "300406" : "500002";
        const headers = {
            method: "GET",
            headers: {
                authorizationToken: await Auth.currentSession().then((s) =>
                    s.getAccessToken().getJwtToken()
                ),
                defaultrole: props.props.TenantInfo.UserGroup,
                groupmenuname: groupMenuName,
                menuid: menuId,
            },
        };
        const finalResult = await APIGatewayGetRequest(fetchURL, headers);
  
        const url = await finalResult?.res?.text();
        let fileType;

        if ((url != undefined) && url != "The specified key does not exist") {
    
            const extension = url?.substring(url.lastIndexOf(".") + 1).toLowerCase();
            const document = ["docx", "doc", "txt", "ppt", "pptx", "pdf", "csv", "xls", "xlsx"], image = ["jpg", "jpeg", "png"], video = ["avi", "mov", "mp4", "mpeg4"], zip = ["tar", "rar", "zip"];
            fileType = document.indexOf(extension) >= 0 ? "Document" : image.indexOf(extension) >= 0 ? "Image" : video.indexOf(extension) >= 0 ? "Video" : zip.indexOf(extension) >= 0 ? "Zip" : "NIL";
            const maximumNumberOfAttachment = temp?.["NoOFAttachement"] - 1;
   
            const fileSizeInBytes = (props.forwardedRef.current?.[props?.Data?.TopicID]?.Size) * 1024 * 1024;
            const diff = Math.abs(fileSizeInBytes - uploadedFileize.current);
            const remainingSizeAvailable = Math.round(diff / 1024 / 1024);
            const finalSize = remainingSizeAvailable;
            const attachment = props.forwardedRef.current?.[props?.Data?.TopicID]?.NoOFAttachement - 1;
            props.forwardedRef.current = {
                ...props.forwardedRef.current, [props?.Data?.TopicID]: {
                    Size: finalSize,
                    NoOFAttachement: attachment
                }
            };
   
            props.Updatesize(finalSize, maximumNumberOfAttachment, props.RedirectMode == "Course" ? "Course" : "Activity");
            props.SendMesage(url, fileType, "Popup");
        } else {
            setValue("File", "Error", { shouldValidate: true });
        }
        props.setOpen(() => {
            return false;
        });
        setValue("submitloader", false);
    };
    const getAttachmentInfo = useCallback(() => {
        const temp = props.forwardedRef.current?.[props.Data.TopicID];
        return (
            <>
                <NVLlabel text={`Max File Size: ${(temp?.["Size"])} MB`}> </NVLlabel>
                <NVLlabel showFull text={`Number of Attachments : ${temp?.["NoOFAttachement"]} `}> </NVLlabel>
            </>
        );
    }, [props.Data.TopicID, props.forwardedRef]);

    return (
        <Container>
            <form id="Formjs" onSubmit={handleSubmit(submithandler)} >
                <div className="flex gap-2 h-50">
                    {" "}
                    <div className="pl-28 pt-6">
                        <NVLlabel text="Upload File" className="font-bold text-gray-600 pt-6" HelpInfo={`File size should be ${(props.forwardedRef.current?.[props.Data.TopicID]?.["Size"])} MB. <br> Acceptable file format: docx, doc, ppt, pptx, pdf, csv, jpg, jpeg, png, avi, mov, xls, xlsx, mp4, zip, tar, rar`} HelpInfoIcon={"fa fa-solid fa-circle-question pt-6"} />
                        <NVLFileUpload id="getFile" text={fileValues.FileName == null ? "Select File" : fileValues.FileName} ButtonType="success" onChange={(e) => fileValidation(e)}></NVLFileUpload>
                        <NVLLoader className={`text-sm ${watch("File") == "Uploading" ? "" : "hidden"}`} id="loader" />
                        <div className={"Center-Aligned-Items {invalid-feedback} text-red-500 text-sm "} >
                            {errors?.File?.message}
                        </div>
                        {getAttachmentInfo()}

                        <div className="flex gap-1 pt-2 pl-24">
                            <NVLButton
                                text={!watch("submitloader")
                                    ? "Upload" : ""}
                                type={"submit"}
                                disabled={
                                    watch("File") == "Uploading" || watch("submitloader") ? true : false
                                }
                                className={
                                    props.ButtonClassName
                                        ? props.ButtonClassName
                                        : `w-24 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""
                                        }`
                                }
                                ButtonType="success"

                            >
                                {watch("submitloader") && (
                                    <i className="fa fa-circle-notch fa-spin mr-2"> </i>
                                )}

                            </NVLButton>
                            <NVLButton
                                id="btnCancel"
                                text={"Clear"}
                                type="button"
                                disabled={
                                    watch("File") == "Uploading" || watch("submitloader") ? true : false
                                }
                                className={
                                    props.ButtonClassName
                                        ? props.ButtonClassName
                                        : `w-24 nvl-button ${watch("File") == "Uploading" || watch("submitloader") ? "nvl-button-light" : ""
                                        }`
                                }
                                onClick={() => clearForm()}
                            ></NVLButton>
                        </div>
                    </div>{" "}
                </div>
            </form>
        </Container>


    );
}

export default UploadAttachments;