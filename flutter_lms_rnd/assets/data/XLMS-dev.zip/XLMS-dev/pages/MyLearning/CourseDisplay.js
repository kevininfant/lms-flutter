import Container from "@components/Container/Container";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useState } from "react";
import { getXlmsCourseEnrollUser, getXlmsCourseManagementInfo, listXlmsCourseModule } from "src/graphql/queries";
function CourseContent(props) {
    const router = useRouter();
    const tenantId = useMemo(() => { return props.TenantInfo.TenantID; }, [props.TenantInfo.TenantID]);
    const courseId = useMemo(() => { return router.query["CourseID"]; }, [router.query]);
    const batchId = useMemo(() => { return router.query["BatchID"]; }, [router.query]);
    const [courseData, setCourseData] = useState({});

    useEffect(() => {
        async function courseDataFetch() {
            const authorizedToken = props.user?.signInUserSession?.accessToken?.jwtToken;
            const activityVariable = {
                PK: "TENANT#" + tenantId,
                SK: "COURSEID#" + courseId,
                IsDeleted: false
            };
            const moduleVariable = {
                PK: "TENANT#" + tenantId + "#COURSEINFO#" + courseId,
                SK: "COURSEMODULE#",
                IsDeleted: false
            };
            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, {
                PK: "TENANT#" + tenantId,
                SK: "COURSEINFO#" + courseId,
            }, authorizedToken);
            const courseEnrollData = await AppsyncDBconnection(getXlmsCourseEnrollUser, {
                PK: "TENANT#" + tenantId + "#COURSE#ENROLLUSER#" + props.user.attributes["sub"],
                SK: "COURSE#" + courseId + "#BATCH#" + batchId,
            }, authorizedToken);
            const actList = (await AppsyncDBconnection(listXlmsCourseModule, activityVariable, authorizedToken));
            const moduleInfo = (await AppsyncDBconnection(listXlmsCourseModule, moduleVariable, authorizedToken));
            const temp = {
                CourseData: courseData.res.getXlmsCourseManagementInfo,
                ActList: actList.res.listXlmsCourseModule?.items,
                moduleInfo: moduleInfo.res.listXlmsCourseModule?.items,
                CourseEnrollData: courseEnrollData.res?.getXlmsCourseEnrollUser,
            };
            setCourseData(temp);
        }
        courseDataFetch();
        return (() => {
            setCourseData((temp) => { return { ...temp }; });
        });
    }, [batchId, courseId, tenantId, props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken]);

    const res = Object.values(JSON.parse(courseData?.CourseEnrollData?.Restriction != undefined ? courseData?.CourseEnrollData?.Restriction : "{}"))?.[0]?.flow;
    const icon = useCallback((item) => {
        let symbol = "";
        switch (item) {
        case "Discussion":
            symbol = "fa fa-comments-o  text-primary pt-2 pr-3";
            break;
        case "Video":
            symbol = "fa fa-video  800 #292524 pt-2 pr-3 ";
            break;
        case "Url":
            symbol = "fa-solid fa-link  text-primary pt-2 pr-3";
            break;
        case "Page":
            symbol = "fa-regular fa-file #e7e5e4 pt-2 pr-3";
            break;
        case "File":
            symbol = "fa-solid fa-file-lines #2563eb pt-2 pr-3";
            break;
        case "Feedback":
            symbol = "fa-solid fa-paper-plane text-sky-900 pt-2 pr-3";
            break;
        case "ScormPackage":
            symbol = "fa-solid fa-photo-film text-sky-900 pt-2 pr-3";
            break;
        case "Quiz":
            symbol = "fa-sharp fa-solid fa-person-chalkboard text-sky-900 pt-2 pr-3";
            break;
        case "Assignment":
            symbol = "fa-solid fa-book-open-reader #0c4a6e pt-2 pr-3";
            break;
        default:
            symbol = "fa fa-tasks pt-2 pr-3";
        }
        return symbol;
    }, []);

    // Bread Crumbs
    const pageRoutes = useMemo(() => { [
        {
            path: "/MyLearning/LearningDashboard",
            breadcrumb: "My Learning"
        },
        { path: "", breadcrumb: courseData?.CourseData?.CourseName }
    ];},[courseData?.CourseData?.CourseName]);
    return (
        <>
            <div className="justify-center w-full">
                <Container title="Coursedisplay" loader={Object?.keys(courseData).length == 0} PageRoutes={pageRoutes}>

                    <div className="m-auto mt-5 w-full">
                        {courseData?.moduleInfo?.map((element, index) => {
                            let tempModule = [];
                            courseData?.ActList?.map((data, ) => {
                                if (element.ModuleID == data.ModuleID) {
                                    res?.Visible?.map((temp) => {
                                        if (temp.actId == data.ActivityID) {
                                            tempModule = [...tempModule, data];
                                        }
                                    });
                                }
                            });
                            if (tempModule.length > 0)
                                return (
                                    <div key={index} className="Course-Trastion mt-2 float-right w-1/4">
                                        <details className="flex shadow-md  m-auto">
                                            <summary className=" bg-white text-xs flex-end font-bold p-4 border border-black rounded-lg	 w-full">{element.ModuleName}</summary>
                                            {tempModule.map((data, index) => {
                                                const temp = JSON.parse(courseData?.CourseEnrollData?.CompletionStatus != undefined ? (courseData?.CourseEnrollData?.CompletionStatus) : "{}");
                                                const tempres = res.Order;
                                                let disabled = false;
                                                if (tempres?.[data.ActivityID]?.before?.length > 0) {
                                                    tempres?.[data.ActivityID].before?.map(tempdata => {
                                                        if (temp?.[tempdata.actId]?.CompletionStatus != "100") {
                                                            disabled = true;
                                                        }
                                                    });
                                                }

                                                if (element.ModuleID == data.ModuleID)
                                                    return (
                                                        <ul key={index} className="p-3 border shadow-sm rounded-md">
                                                            <li className="flex justify-between gap-2 pt-4 hover:transition-all " >
                                                                <div className="flex  w-3/4 border-r-2">
                                                                    {/* {((props.ActList[index].ActivityType) == "Discussion") ?
                                                                symbol = { "pt-2 pr-3 fa-solid fa-check-square text-emerald-700"} : ""
                                                            } */}
                                                                    <i className={`${icon(courseData?.ActList[index]?.ActivityType)}`} />
                                                                    <NVLlabel className="stroke-zinc-900  pt-1 text-xs text-th-primary-dark text-justify place-content-center" text={data.ActivityName}></NVLlabel>
                                                                </div>
                                                                <div className="w-1/4 border-r-2">
                                                                    <NVLButton disabled={disabled} text={JSON.parse(courseData?.CourseEnrollData?.CompletionStatus != undefined ? courseData?.CourseEnrollData?.CompletionStatus : "{}")?.[data.ActivityID]?.CompletionStatus == "100" ? "Learn Again" : JSON.parse(courseData?.CourseEnrollData?.CompletionStatus != undefined ? courseData?.CourseEnrollData?.CompletionStatus : "{}")?.[data.ActivityID]?.CompletionStatus == undefined ? "Start" : "Continue"}
                                                                        onClick={Object?.keys(courseData).length != 0 && router.push(`CourseConsume?CourseID=${element.CourseID}&ActivityID=${data.ActivityID}&ModuleId=${element.ModuleID}&BatchId=${courseData?.CourseEnrollData?.BatchID}&Mode=Dashboard`)} className=" bg-green-500 hover:bg-green-600  text-white font-bold w-full py-1 px-4 rounded-full  place-content-center text-xs">{<i className=" pl-1 content-justify-end fa-solid fa-play"></i>}</NVLButton>
                                                                </div>
                                                                <div > <i className={" pt-2 pr-3 fa-solid fa-check-square text-emerald-700 skew-x-0"} ></i></div>
                                                            </li>
                                                        </ul>
                                                    );
                                            })}
                                        </details>
                                    </div>
                                );
                        })}
                    </div>
                </Container>
            </div >
        </>);

}
export default CourseContent;
