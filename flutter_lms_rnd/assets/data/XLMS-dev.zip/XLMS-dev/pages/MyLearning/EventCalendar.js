import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { Dialog, Transition } from "@headlessui/react";
import { yupResolver } from "@hookform/resolvers/yup";
import AddEventInfo from "@Pages/MyLearning/AddEventInfo";
import dynamic from "next/dynamic";
import React, { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { Regex } from "RegularExpression/Regex";
import * as Yup from "yup";

const TuiCalendar = dynamic(() => import("@components/Controls/NVLCalander"), {
  ssr: false,
});
const CalendarComponent = React.forwardRef((props, ref) => (
  <TuiCalendar
    {...props}
    forwardedRef={ref}
  />
));
CalendarComponent.displayName = "CalendarComponent";

export default function CustomCalendar(props) {
  const [RowGridData, setRowGridData] = useState([]);
  const [ActivityData, setViewData] = useState([]);
  const [PageData, setPageData] = useState(props)

  useEffect(() => {
    async function fetchData() {
      let user = props.user;

      var TenantName = user.attributes["name"];
      var TenantID = user.attributes["custom:tenantid"];
      var UserSub = user.attributes["sub"];

      const response = await AppsyncDBconnection(listXlmsEnrollUser, { PK: "TENANT#" + TenantID + "#ACTIVITY#ENROLLUSER#" + UserSub, SK: "ACTIVITYID#", }, user.signInUserSession.accessToken.jwtToken);
      let json = {
        ActivityData: response.res.listXlmsEnrollUser.items,
        TenantName: TenantName,
        TenantID: TenantID,
      };
      setPageData((data) => {
        return { ...data, ...json }
      })
    }
    fetchData();
    return (() => {
      setPageData((data) => {
        return { ...data }
      })
    })
  })

  const GridDataBind = useCallback(() => {
    const RowGrid = [];
    const start = new Date();
    ActivityData.map((getItem, index) => {
      !getItem.IsDeleted
        ? RowGrid.push({
          calendarId: "1",
          category: "time",
          isVisible: true,
          title: getItem.ActivityType,
          id: getItem.ActivityID,
          body: getItem.ActivityDescription,
          start: getItem.StartDate ? new Date(new Date().setHours(start.getHours() + 2)) : getItem.StartDate,
          end: getItem.EndDate ? new Date(new Date().setHours(start.getHours() + 2)) : getItem.EndDate,
          isReadOnly: true,
        })
        : "";
    });
    setRowGridData({ RowGrid });
  }, [ActivityData]);
  useMemo(() => {
    if (ActivityData.length > 0 && ActivityData != null) {
      GridDataBind();
    }
  }, [ActivityData, GridDataBind]);

  const cal = useRef(null);
  const month = useRef(null);


  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];

  const getCalInstance = useCallback(() => cal.current?.getInstance?.(), []);
  const getMonth = () => {
    month.current.innerHTML =
      monthNames[getCalInstance()?.getDate().getMonth()];
  };
  var templates = {
    popupIsAllDay: function () {
      return "All Day";
    },
    popupStateFree: function () {
      return "Free";
    },
    popupStateBusy: function () {
      return "Busy";
    },
    titlePlaceholder: function () {
      return "Subject";
    },
    locationPlaceholder: function () {
      return "Location";
    },
    startDatePlaceholder: function () {
      return "Start date";
    },
    endDatePlaceholder: function () {
      return "End date";
    },
    popupSave: function () {
      return "Save";
    },
    popupUpdate: function () {
      return "Update";
    },
    popupDetailDate: function (isAllDay, start, end) {
      var isSameDate = moment(start).isSame(end);
      var endFormat = (isSameDate ? "" : "YYYY.MM.DD ") + "hh:mm a";

      if (isAllDay) {
        return (
          moment(start).format("YYYY.MM.DD") +
          (isSameDate ? "" : " - " + moment(end).format("YYYY.MM.DD"))
        );
      }

      return (
        moment(start).format("YYYY.MM.DD hh:mm a") +
        " - " +
        moment(end).format(endFormat)
      );
    },
    popupDetailLocation: function (schedule) {
      return "Location : " + schedule.location;
    },
    popupDetailUser: function (schedule) {
      return "User : " + (schedule.attendees || []).join(", ");
    },
    popupDetailState: function (schedule) {
      return "State : " + schedule.state || "Busy";
    },
    popupDetailRepeat: function (schedule) {
      return "Repeat : " + schedule.recurrenceRule;
    },
    popupDetailBody: function (schedule) {
      return "Body : " + schedule.body;
    },
    popupEdit: function () {
      return "Edit";
    },
    popupDelete: function () {
      return "Delete";
    },
  };
  const onBeforeCreateEvent = (eventData) => {
    const event = {
      calendarId: eventData.calendarId || "",
      id: String(Math.random()),
      title: eventData.txtEventTitle,
      start: eventData.txtstdate,
      end: eventData.txtEnddate,
      category: eventData.isAllday ? "allday" : "time",
      dueDateclassName: "",
      location: eventData.location,
      state: eventData.state,
      isPrivate: eventData.isPrivate,
    };
    getCalInstance().createEvents([event]);

    setOpen(false);
  };
  const onAfterRenderEvent = (event) => {
  };

  const [viewEvent, setEvent] = useState("month");

  getCalInstance()?.on("myCustomEvent", (eventData) => {
    onBeforeCreateEvent(eventData);
  });

  const onClickDayName = (res) => {
  };

  getCalInstance()?.on({
    clickSchedule: function (e) {
    },
    beforeCreateSchedule: function (e) {
    },
    beforeUpdateSchedule: function (e) {
      e.schedule.start = e.start;
      e.schedule.end = e.end;
      cal.updateSchedule(e.schedule.id, e.schedule.calendarId, e.schedule);
    },
  });
  const validationSchema = Yup.object().shape({
    txtEventTitle: Yup.string()
      .required("Event Title")
      .matches(Regex("AlphabetsAndSpaceOnly"), "Invalid Event Title"),
    txtCourse: Yup.string()
      .required("Course Name")
      .matches(Regex("AlphabetsAndSpaceOnly"), "Invalid Course Name"),
    txtTypeOfEvent: Yup.string()
      .required("Type Of Event")
      .matches(Regex("AlphabetsAndSpaceOnly"), "Invalid Type Of Event"),
  });
  const [open, setOpen] = useState(false);
  const formOptions = {
    mode: "onChange",
    resolver: yupResolver(validationSchema),
    reValidateMode: "onChange",
    nativeValidation: false,
  };

  const { register, handleSubmit, setValue, reset, watch, formState } =
    useForm(formOptions);
  const { errors } = formState;

  const DateTime = useCallback(
    (props) => {
      let today = new Date();
      let dateTime =
        today.getFullYear() +
        "-" +
        (today.getMonth() + 1 >= 10
          ? today.getMonth() + 1
          : "0" + (today.getMonth() + 1)) +
        "-" +
        (today.getDate() < 9 ? "0" + today.getDate() : today.getDate()) +
        "T" +
        today.getHours() +
        ":" +
        today.getMinutes();

      return (
        <div className="grid grid-flow-col">
          {props.StartDate == undefined && (
            <div>
              <NVLlabel text="Start Date"></NVLlabel>
              <NVLTextbox
                title="Start Date"
                type="datetime-local"
                className={""}
                min={dateTime}
                id="txtstdate"
                errors={errors}
                register={register}
              ></NVLTextbox>
            </div>
          )}
          {props.EndDate == undefined && (
            <div className="flex">
              <div className="">
                <NVLlabel text="End Date"></NVLlabel>
                <NVLTextbox
                  title="End Date"
                  id="txtEnddate"
                  type="datetime-local"
                  min={dateTime}
                  errors={errors}
                  register={register}
                ></NVLTextbox>
              </div>
            </div>
          )}
        </div>
      );
    },
    [errors, register]
  );

  const submitHandler = async (data) => {
    onBeforeCreateEvent(data);
  };

  const onClickSchedule = useCallback((e) => {
  }, []);
  return (
    <div className="p-4 bg-gray-200">
      <div className="flex justify-between m-4 text-xs">
        <div className="flex gap-4">
          <button
            onClick={() => setEvent("day")}
            type="button"
            className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3"
          >
            <div className="flex flex-row align-middle">
              <span className="mr-2">Day</span>
            </div>
          </button>
          <button
            onClick={() => setEvent("week")}
            type="button"
            className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3"
          >
            <div className="flex flex-row align-middle">
              <span className="mr-2">Week</span>
            </div>
          </button>
          <button
            onClick={() => setEvent("month")}
            type="button"
            className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3"
          >
            <div className="flex flex-row align-middle">
              <span className="mr-2">Month</span>
            </div>
          </button>
        </div>
        <span
          ref={month}
          className="render-range font-semibold shadow-xl  text-gray-600 rounded p-2 border "
        >
          month
        </span>
        <div className="flex gap-4">
          <button
            onClick={() => {
              getCalInstance().today();
              getMonth();
            }}
            type="button"
            className="bg-gray-600 text-white py-2 rounded border-l border-gray-200 hover:bg-red-700 hover:text-white px-3"
          >
            <div className="flex flex-row align-middle">
              <span className="mr-2">Today</span>
            </div>
          </button>
          <button
            onClick={() => {
              getCalInstance().prev();
              getMonth();
            }}
            type="button"
            className="bg-gray-600 text-white rounded-l-md border-r border-gray-100 py-2 hover:bg-red-700 hover:text-white px-3"
          >
            <div className="flex flex-row align-middle gap-2">
              <i className="fa fa-solid fa-arrow-left-long fa-lg cente mt-2.5"></i>
              <p className="">Prev</p>
            </div>
          </button>
          <button
            onClick={() => {
              getCalInstance().next();
              getMonth();
            }}
            type="button"
            className="bg-gray-600 text-white rounded-r-md py-2 border-l border-gray-200 hover:bg-red-700 hover:text-white px-3"
          >
            <div className="flex flex-row align-middle gap">
              <span className="mr-2">Next</span>
              <i className="fa fa-solid fa-arrow-right-long fa-lg cente mt-2.5"></i>
            </div>
          </button>
          <button
            onClick={() => setOpen(true)}
            type="button"
            className="bg-blue-600 text-white rounded py-2  border-gray-200 hover:bg-gray-700 hover:text-white px-3"
          >
            <div className="flex flex-row align-middle gap-2">
              <i className="fa-solid fa-plus mt-1"></i>Add Event
            </div>
          </button>
        </div>
      </div>
      <div className="shadow-xl relative">
        <CalendarComponent
          height="500px"
          ref={cal}
          template={{
            milestone(event) {
              return `<span style="color: #fff; background-color: ${event.backgroundColor};">${event.title}</span>`;
            },
            allday(event) {
              return `[All day] ${event.title}`;
            },
          }}
          view={viewEvent}
          useFormPopup={false}
          useDetailPopup={true}
          events={RowGridData.RowGrid}
          usageStatistics={false}
          taskView={false}
          templates={templates}
          onClickDayname={onClickDayName}
          beforeUpdateEvent={(event) => {
          }}
          onBeforeCreateSchedule={(eventData) =>
            getCalInstance()?.fire("myCustomEvent", eventData)
          }
          onAfterRenderEvent={onAfterRenderEvent}
          onClick={onBeforeCreateEvent}
          onClickEvent={onClickSchedule}
        />
      </div>
      <Transition.Root
        show={open}
        as={Fragment}
      >
        <Dialog
          as="div"
          className="relative z-10"
          onClose={setOpen}
        >
          <Transition.Child
            as={Fragment}
            enter="ease-in-out duration-500"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in-out duration-500"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-opacity-75 transition-opacity" />
          </Transition.Child>

          <div className="pointer-events-none right-7 flex max-w-full absolute bottom-4 ">
            <Transition.Child
              as={Fragment}
              enter="transform transition ease-in-out duration-500 sm:duration-700"
              enterFrom="translate-x-full"
              enterTo="translate-x-0"
              leave="transform transition ease-in-out duration-500 sm:duration-700"
              leaveFrom="translate-x-0"
              leaveTo="translate-x-full"
            >
              <Dialog.Panel className="pointer-events-auto relative w-screen max-w-[350px]">
                <Transition.Child
                  as={Fragment}
                  enter="ease-in-out duration-500"
                  enterFrom="opacity-0"
                  enterTo="opacity-100"
                  leave="ease-in-out duration-500"
                  leaveFrom="opacity-100"
                  leaveTo="opacity-0"
                >
                  <div className="absolute top-0 left-0  flex pt-4 pr-2 sm:-ml-10 sm:pr-4">
                    <button
                      type="button"
                      className="rounded-md text-gray-300 hover:text-white focus:outline-none focus:ring-2 focus:ring-white"
                      onClick={() => setOpen(false)}
                    ></button>
                  </div>
                </Transition.Child>
                <div className="flex h-[500px] flex-col bg-gray-200  gap-5 text-xs p-2 rounded-md">
                  <div className="bg-gray-600 text-white p-2 rounded flex justify-between">
                    Add Event
                    <i
                      onClick={() => setOpen(false)}
                      className="fa-solid fa-angles-right text-blue-600 h-8 w-8 grid place-content-center  cursor-pointer rounded-full bg-blue-100"
                    ></i>
                  </div>

                  <form onSubmit={handleSubmit(submitHandler)}>
                    <AddEventInfo
                      EventDate={<DateTime />}
                      register={register}
                      errors={errors}
                    ></AddEventInfo>
                    <NVLButton
                      id="btnSubmit"
                      text={"Submit"}
                      type="submit"
                      className={"w-32 nvl-button bg-primary text-white mt-4"}
                    ></NVLButton>
                  </form>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>
    </div>
  );
}