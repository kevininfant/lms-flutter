import Container from "@components/Container/Container";
import { useRouter } from "next/router";
import { useMemo, useState } from "react";
import ActivityEnrollList from "./ActivityEnrollList";
import CourseEnrollList from "./CourseEnrollList";

export default function LearningDashboard(props) {
    const router = useRouter();
    const tabId = useMemo(() => { return router.query["parameters"]; }, [router.query]);
    const [openTab, setOpenTab] = useState(((tabId == undefined || tabId == "undefined") ? "1" : tabId));

    // Bread Crumbs
    const pageRoutes = useMemo(() => { return [{ path: "", breadcrumb: "My Learning" }]; }, []);
    return (
        <>
            <Container PageRoutes={!props?.IsComponent ? pageRoutes : undefined}>
                <div className="flex flex-wrap ">
                    <div className="w-full">
                        <ul className="grid sm:flex gap-4 sm:gap-0 justify-items-center justify-between border-b" role="tablist">
                            <div className="flex  sm:gap-4 px-2">
                                <li className=" text-center">
                                    <a className={"text-[#0E4681] font-medium text-xs  sm:px-2 py-1 block leading-normal " + (openTab === "1" ? "text-[#E16C20] font-semibold border-b-2 border-[#E16C20] " : " bg-white ")} onClick={(e) => { e.preventDefault(); setOpenTab("1"); }} data-toggle="tab" href="#link1" role="tablist">
                                        My Course
                                    </a>
                                </li>
                                <li className="hidden text-center">
                                    <a className={"text-[#0E4681] text-xs font-medium px-2 py-1 block leading-normal " + (openTab === "2" ? "text-[#E16C20] font-semibold border-b-2 border-[#E16C20] " : " bg-white ")} onClick={(e) => { e.preventDefault(); setOpenTab("2"); }} data-toggle="tab" href="#link1" role="tablist">
                                        My Training
                                    </a>
                                </li>
                                <li className="hidden text-center ">
                                    <a className={"text-[#0E4681] text-xs font-medium px-2 py-1 block leading-normal " + (openTab === "3" ? "text-[#E16C20] font-semibold border-b-2 border-[#E16C20] " : " bg-white ")} onClick={(e) => { e.preventDefault(); setOpenTab("3"); }} data-toggle="tab" href="#link2" role="tablist">
                                        Learning Plan
                                    </a>
                                </li>
                                <li className="text-center">
                                    <a className={"text-[#0E4681] text-xs px-2 font-medium py-1 block leading-normal " + (openTab === "4" ? "text-[#E16C20] font-semibold border-b-2 border-[#E16C20] " : " bg-white ")} onClick={(e) => { e.preventDefault(); setOpenTab("4"); }} data-toggle="tab" href="#link3" role="tablist">
                                        My Activity
                                    </a>
                                </li>
                            </div>
                        </ul>
                        <div className=" flex-auto text-xs">
                            <div className="tab-content tab-space ">
                                <div className={openTab === "1" ? "block " : "hidden "} id="link1">
                                    <CourseEnrollList row={props?.row} TenantInfo={props?.IsComponent ? props?.props?.TenantInfo : props?.TenantInfo} user={props?.IsComponent ? props?.props?.user : props.user} openTab={openTab} sub={props?.IsComponent ? props?.props?.user?.attributes["sub"] : props?.user?.attributes["sub"]} />
                                </div>
                                <div className={openTab === "2" ? "block " : "hidden "} id="link1"></div>
                                <div className={openTab === "3" ? "block" : "hidden"} id="link2"></div>
                                <div className={openTab === "4" ? "block" : "hidden"} id="link3">
                                    <ActivityEnrollList row={props?.row} TenantInfo={props?.IsComponent ? props?.props?.TenantInfo : props?.TenantInfo} user={props?.IsComponent ? props?.props?.user : props.user} openTab={openTab} sub={props?.IsComponent ? props?.props?.user?.attributes["sub"] : props?.user?.attributes["sub"]} />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Container>
        </>
    );
}
