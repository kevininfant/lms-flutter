import NVLButton from "@components/Controls/NVLButton";
import NVLGridCard from "@components/Controls/NVLGridCard";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLProgressBar from "@components/Controls/NVLProgressBar";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo } from "react";
import { updateXlmsCourseConsumeAtomicCount } from "src/graphql/mutations";
import { getXlmsBatchCourseEnrollUser, listXlmsCourseEnrollUser } from "src/graphql/queries";

export default function CourseEnrollList(props) {
    const router = useRouter();
    const headerColumn = useMemo(() => {
        return [{ HeaderName: "", Columnvalue: "CourseType", HeaderCss: "!w-7/12 " }, { HeaderName: "", Columnvalue: "CourseProgres", HeaderCss: "!w-2/12 ", }, { HeaderName: "", Columnvalue: "CourseAction", HeaderCss: "!w-4/12 " }];
    }, []);

    const activityList = useMemo(() => {
        return {
            Name: "listXlmsCourseEnrollUser",
            query: listXlmsCourseEnrollUser,
            variable: { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSE#ENROLLUSER#" + props?.sub, SK: "COURSE#", IsSuspend: false },
        };
    }, [props?.TenantInfo?.TenantID, props?.sub]);

    const getCourseVisitCount = useCallback(async (TenantID, CourseID) => {
        const query = updateXlmsCourseConsumeAtomicCount, variables = { input: { PK: "TENANT#" + TenantID, SK: "COURSEINFO#" + CourseID, }, };
        const finalStatus = (await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        return finalStatus;
    }, [props?.user?.signInUserSession?.accessToken?.jwtToken]);

    const gridDataBind = useCallback(async (activityData) => {
        const rowGrid = [], variables = [], temp = [];
        for (let i = 0; i < activityData?.length; i++) {
            if (!temp.includes("TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID)) {
                variables = [...variables, { PK: "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard, SK: "COURSEINFO#" + activityData[i].CourseID, }];
                temp = [...temp, "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID];
            }

        }
        const editDatalisttemp = await AppsyncDBconnection(getXlmsBatchCourseEnrollUser, { input: variables }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        let SK = {};
        for (let i = 0; i < editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser?.length; i++) {
            if (editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.SK != undefined && editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.IsSuspend == false) {
                SK = { ...SK, [editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.PK + editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i]?.SK]: { ...editDatalisttemp?.res?.getXlmsBatchCourseEnrollUser[i] } }
            }
        }
        for (let i = 0; (i < activityData?.length) && (props?.row ? props?.row > i : true); i++) {
            const temp = JSON.parse(activityData[i].CompletionStatus != undefined ? activityData[i].CompletionStatus : "{}");
            let tempSK = "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard + "COURSEINFO#" + activityData[i].CourseID, isDisabled;
            if (SK?.[tempSK] != undefined) {
                if (SK?.[tempSK]?.EndDateTime == "" || SK?.[tempSK]?.EndDateTime == undefined || SK?.[tempSK]?.EndDateTime == null || new Date(SK?.[tempSK]?.EndDateTime) >= new Date()) {
                    if (SK?.[tempSK]?.DateTime == "" || SK?.[tempSK]?.DateTime == undefined || new Date(SK?.[tempSK]?.DateTime) == null || new Date(SK?.[tempSK]?.DateTime) <= new Date()) {
                        isDisabled = false;
                    } else { isDisabled = true; }
                } else { isDisabled = true; }
                rowGrid.push({
                    CourseType: <NVLGridCard key={"card" + i} Name={SK?.[tempSK]?.CourseName} ThumbNailPath={SK?.[tempSK]?.CourseThumbNail != undefined ? SK?.[tempSK]?.CourseThumbNail : ""} Icon={SK?.[tempSK]?.CourseThumbNail != undefined ? "" : "fa-solid fa-book-open-reader"} ActivityName={SK?.[tempSK]?.CourseDescription?.replace(/(<([^>]+)>)/gi, "")}></NVLGridCard>,
                    CourseProgres: (
                        <div key={"progress" + i}>
                            <NVLlabel className="text-gray-900  font-medium title-font tracking-wider pb-1">
                                {" "}    Progress &nbsp;{" "}    {`(${temp?.progress > 0 ? Math.round(temp?.progress) : "0"}%)`}
                            </NVLlabel>
                            <div className=""> <NVLProgressBar text="Progress" bgcolor={temp?.progress > "0" ? temp?.progress < 100 ? "#F47623" : temp?.progress ? "#1D74FF" : "#9333ea" : "#AEB9DE"} progress={temp?.progress > 0 ? temp?.progress : "0"} />
                            </div>
                        </div>
                    ),
                    CourseAction: (
                        <div key={"action" + i} className="lg:mb-0 mb-6 ">
                            <div className="h-full flex gap-4 float-right">
                                <NVLButton disabled={isDisabled}
                                    ButtonType={Math.round(temp?.progress) > 0 ? Math.round(temp?.progress) < 100 ? "continue" : Math.round(temp?.progress) ? "completed" : "learnagain" : "start"}
                                    text={Math.round(temp?.progress) > 0 ? Math.round(temp?.progress) < 100 ? "In Progress" : Math.round(temp?.progress) ? "Completed" : "Learn Again" : "Start"}
                                    className={`${isDisabled ? "opacity-40" : ""}  w-44`} onClick={() => {
                                        getCourseVisitCount(activityData[i].TenantID, SK?.[tempSK]?.CourseID);
                                        router.push(`/MyLearning/CourseConsume?CourseID=${SK?.[tempSK]?.CourseID}&BatchId=${activityData[i].BatchID}`);
                                    }} />
                            </div>
                        </div>
                    ),
                });
            }
        }
        return rowGrid;
    }, [getCourseVisitCount, props?.row, props?.user?.signInUserSession?.accessToken?.jwtToken, router]);
    const viewMoreAction = useMemo(() => {
        return { ListOfCount: props?.row, IsNavigation: true, Link: <div onClick={() => router.push(`/MyLearning/LearningDashboard?parameters=1`)} className="nvl-Def-Label whitespace flex justify-end text-[#0E4681]  underline cursor-pointer">All Courses</div> }
    }, [props?.row, router])
    return (
        <>
            <NVLGridTable viewMoreAction={viewMoreAction} DonotLoad={true} setPagezero={props.openTab} refershPage={true} user={props?.user} id="tblCourseList" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsCourseEnrollUser} querryName={"listXlmsCourseEnrollUser"} variable={activityList.variable} />
        </>
    );
}
