import Container from "@components/Container/Container";
import NVLCourseNavbar from "@components/Controls/NVLCourseNavbar";
import NVLImage from "@components/Controls/NVLImage";
import NVLlabel from "@components/Controls/NVLlabel";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { getXlmsCourseEnrollUser, getXlmsCourseManagementInfo, listXlmsCourseEnrollUser, listXlmsCourseModule, listXlmsLanguages } from "src/graphql/queries";
import * as Yup from "yup";
import UserConsumeList from "./UserConsumeList";
function CourseConsume(props) {
    const currentActivityId = useRef({ ActivityID: null, ChangeActId: false });
    const decr = useRef(null);
    const UpdateFunction = useRef(null);
    const router = useRouter();
    const [fetchdata, setFetchdata] = useState({ ...props });
    const courseId = useMemo(() => { return router.query["CourseID"]; }, [router.query]);
    const activityId = useMemo(() => { return router.query["ActivityID"]; }, [router.query]);
    const batchId = useMemo(() => { return router.query["BatchId"]; }, [router.query]);
    const tempEnrollCourseData = useRef();
    const updateCourseEnrollData = useCallback((data) => {
        currentActivityId.current = { ...currentActivityId.current, ChangeActId: false };
        setFetchdata((temp) => {
            return { ...temp, EnrollCourseData: { ...temp.EnrollCourseData, ...data } };
        });
    }, []);
    const FunctionUpdate = (temp) => {
        UpdateFunction.current = temp;
    }

    const updateCourseEnrollDataRef = useCallback((data) => {
        tempEnrollCourseData.current = { ...tempEnrollCourseData.current, ...data };
        UpdateFunction.current && UpdateFunction.current((temp) => {
            return JSON.parse(data?.CompletionStatus != undefined ? data.CompletionStatus : '{}');
        })
    }, []);

    useEffect(() => {
        async function FetchData() {
            const courseData = await AppsyncDBconnection(getXlmsCourseManagementInfo, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID,
                SK: "COURSEINFO#" + courseId,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const enrollCourseData = await AppsyncDBconnection(getXlmsCourseEnrollUser, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSE#ENROLLUSER#" + props?.user.attributes["sub"],
                SK: "COURSE#" + courseId + "#BATCH#" + batchId,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const courseEnrollData = await AppsyncDBconnection(getXlmsCourseEnrollUser, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#" + enrollCourseData?.res?.getXlmsCourseEnrollUser?.Shard,
                SK: "COURSEINFO#" + courseId,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const batchEnrollData = await AppsyncDBconnection(getXlmsCourseEnrollUser, {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + courseId + "#" + enrollCourseData?.res?.getXlmsCourseEnrollUser?.Shard,
                SK: "COURSEBATCH#" + batchId,
            }, props?.user?.signInUserSession?.accessToken?.jwtToken);

            const moduleVariable = {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#COURSEINFO#" + courseId + "#" + enrollCourseData?.res?.getXlmsCourseEnrollUser?.Shard,
                SK: "COURSEMODULE#",
                IsDeleted: false
            };

            const activityVariable = {
                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#" + enrollCourseData?.res?.getXlmsCourseEnrollUser?.Shard,
                SK: "COURSEID#" + courseId,
                IsDeleted: false
            };
            const variable = { PK: `TENANT#${props.TenantInfo.TenantID}`, SK: `COURSEID#${courseId}#MODULEID#`, IsDeleted: false };

            const actList = (await AppsyncDBconnection(listXlmsCourseEnrollUser, activityVariable, props?.user?.signInUserSession?.accessToken?.jwtToken));
            const moduleInfo = (await AppsyncDBconnection(listXlmsCourseEnrollUser, moduleVariable, props?.user?.signInUserSession?.accessToken?.jwtToken));
            const recordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME" }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            const responseModuleData = await AppsyncDBconnection(listXlmsCourseModule, variable, props.user.signInUserSession.accessToken.jwtToken);
            const status = JSON.parse(enrollCourseData?.res?.getXlmsCourseEnrollUser?.CompletionStatus != undefined ? enrollCourseData?.res?.getXlmsCourseEnrollUser?.CompletionStatus : "{}");
            const res = Object.values(JSON.parse(enrollCourseData?.res?.getXlmsCourseEnrollUser?.Restriction != undefined ? enrollCourseData?.res?.getXlmsCourseEnrollUser?.Restriction : "{}"))?.[0]?.flow;
            const tempActivity = Object.keys(status);
            let final = {};
            if (tempActivity.length > 0) {
                let ActData;
                if (router?.query?.["ActivityID"] != undefined) {
                    currentActivityId.current = { ...currentActivityId.current, ActivityID: router?.query?.["ActivityID"], ChangeActId: true };
                    const activityList1 = actList?.res?.listXlmsCourseEnrollUser?.items;
                    if (activityList1 != undefined)
                        ActData = activityList1.filter((item) => item.ActivityID === router?.query?.["ActivityID"])[0];
                    final = {
                        CourseData: courseData?.res?.getXlmsCourseManagementInfo,
                        ActList: actList.res.listXlmsCourseEnrollUser?.items,
                        moduleInfo: moduleInfo.res.listXlmsCourseEnrollUser?.items,
                        LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
                        CourseEnrollData: courseEnrollData?.res?.getXlmsCourseEnrollUser,
                        EnrollCourseData: enrollCourseData?.res?.getXlmsCourseEnrollUser,
                        ActivityData: ActData,
                        responseModuleData: responseModuleData?.res?.listXlmsCourseModule?.items,
                        BatchEnrollData: batchEnrollData?.res?.getXlmsCourseEnrollUser,
                    };
                }
                else {
                    for (let i = 0; i < res?.must.length; i++) {
                        const data = res?.must[i];
                        if (status?.[data?.actId]?.CompletionStatus != "100") {
                            currentActivityId.current = { ...currentActivityId.current, ActivityID: data?.actId, ChangeActId: true };
                            const activityList1 = actList?.res?.listXlmsCourseEnrollUser?.items;
                            ActData = activityList1.filter((item) => item.ActivityID === data?.actId)[0];
                            final = {
                                CourseData: courseData?.res?.getXlmsCourseManagementInfo,
                                ActList: actList.res.listXlmsCourseEnrollUser?.items,
                                moduleInfo: moduleInfo.res.listXlmsCourseEnrollUser?.items,
                                LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
                                CourseEnrollData: courseEnrollData?.res?.getXlmsCourseEnrollUser,
                                EnrollCourseData: enrollCourseData?.res?.getXlmsCourseEnrollUser,
                                responseModuleData: responseModuleData?.res?.listXlmsCourseModule?.items,
                                ActivityData: ActData,
                                BatchEnrollData: batchEnrollData?.res?.getXlmsCourseEnrollUser,
                            };
                            break;
                        }
                    }
                }
                if (ActData == undefined) {
                    final = {
                        CourseData: courseData?.res?.getXlmsCourseManagementInfo,
                        ActList: actList.res.listXlmsCourseEnrollUser?.items,
                        responseModuleData: responseModuleData?.res?.listXlmsCourseModule?.items,
                        moduleInfo: moduleInfo.res.listXlmsCourseEnrollUser?.items,
                        LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
                        EnrollCourseData: enrollCourseData?.res?.getXlmsCourseEnrollUser,
                        CourseEnrollData: courseEnrollData?.res?.getXlmsCourseEnrollUser,
                        BatchEnrollData: batchEnrollData?.res?.getXlmsCourseEnrollUser,
                    };
                }
            }
            else {
                final = {
                    CourseData: courseData?.res?.getXlmsCourseManagementInfo,
                    ActList: actList.res.listXlmsCourseEnrollUser?.items,
                    moduleInfo: moduleInfo.res.listXlmsCourseEnrollUser?.items,
                    LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
                    CourseEnrollData: courseEnrollData?.res?.getXlmsCourseEnrollUser,
                    responseModuleData: responseModuleData?.res?.listXlmsCourseModule?.items,
                    EnrollCourseData: enrollCourseData?.res?.getXlmsCourseEnrollUser,
                    BatchEnrollData: batchEnrollData?.res?.getXlmsCourseEnrollUser,
                };
            }
            tempEnrollCourseData.current = { ...final.EnrollCourseData };
            setFetchdata((data) => {
                return { ...data, ...final };
            });
        }

        if (props?.TenantInfo?.TenantID) {
            FetchData();
        }

        return (() => {
            setFetchdata((temp) => { return { ...temp }; });
        });

    }, [batchId, courseId, activityId, props?.TenantInfo?.TenantID, props?.user.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

    useEffect(() => {
        if (fetchdata?.CourseData != undefined && decr.current != undefined) {
            decr.current.innerHTML = fetchdata?.CourseData?.CourseDescription == undefined ? "No Course Description Found" : fetchdata?.CourseData?.CourseDescription;
        }
    }, [fetchdata, fetchdata?.CourseEnrollData?.CourseDescription]);
    const pageRoutes = useMemo(() => {
        const temp = [{ path: "/MyLearning/LearningDashboard", breadcrumb: "My Learning" },];
        if (currentActivityId.current?.ActivityID == undefined) {
            temp.push({ path: "", breadcrumb: fetchdata?.CourseEnrollData?.CourseName });
        }
        else {
            for (let i = 0; i <= fetchdata?.moduleInfo?.length; i++) {
                if (fetchdata?.ActivityData?.ModuleID == fetchdata?.moduleInfo[i]?.ModuleID)
                    temp.push({
                        path: "", breadcrumb: fetchdata?.CourseEnrollData?.CourseName
                        // + " - " + fetchdata?.moduleInfo[i]?.ModuleName + " - " + fetchdata?.ActivityData?.ActivityName 
                    });
            }
        }
        return temp;
    }, [fetchdata?.ActivityData?.ModuleID, fetchdata?.CourseEnrollData?.CourseName, fetchdata?.moduleInfo]);

    const fetchActData = useCallback((temp) => {
        if (currentActivityId.current?.ActivityID != temp) {
            setFetchdata((data) => {
                let ActData = {};
                if (currentActivityId.current != undefined) {
                    ActData = data.ActList.filter((item) => item.ActivityID === currentActivityId.current?.ActivityID)[0];
                }
                currentActivityId.current = { ...currentActivityId.current, ActivityID: temp, ChangeActId: true };
                let tempData = { ...data };
                tempData = { ...tempData, EnrollCourseData: { ...tempData.EnrollCourseData, ...tempEnrollCourseData.current } };

                ActData = data.ActList.filter((item) => item.ActivityID === temp)[0];
                return { ...tempData, ActivityData: ActData };
            });
        }
    }, []);

    const fetchCourseIntoduction = useCallback(() => {
        currentActivityId.current = { ...currentActivityId.current, ActivityID: undefined, ChangeActId: false };
        setFetchdata((data) => {
            let tempData = { ...data, EnrollCourseData: { ...data.EnrollCourseData, ...tempEnrollCourseData.current, ActivityData: {} } };
            return { ...tempData }
        })
    }, [])

    const validationSchema = Yup.object().shape({})
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    return (
        <>
            <Container loader={fetchdata?.EnrollCourseData == undefined} PageRoutes={pageRoutes}>
                <div>
                    <div className="md:flex gap-4">
                        <div className={`px-3 ease-in-out transition-all duration-300 w-full`}>
                            <div className={`${currentActivityId.current?.ActivityID != undefined ? "Course-Trastion" : "hidden"}`}>
                                <UserConsumeList ChangeActId={currentActivityId.current.ChangeActId} lol={currentActivityId.current} updateCourseEnrollDataRef={updateCourseEnrollDataRef} BatchEnrollData={fetchdata?.BatchEnrollData} UpdateCourseEnrollData={updateCourseEnrollData} CourseEnrollData={fetchdata?.CourseEnrollData} EnrollCourseData={tempEnrollCourseData.current} props={fetchdata} QuesTemplate={fetchdata?.ActivityData?.QuestionandOptions != undefined ? JSON.parse(fetchdata?.ActivityData?.QuestionandOptions) : {}} ActivityData={fetchdata?.ActivityData} LanguageName={fetchdata?.LanguageName} />
                            </div>
                            <div className={`${currentActivityId.current?.ActivityID != undefined ? "hidden" : "border p-2"}`}>
                                <div className="flex justify-between flex-wrap break-all">
                                    {fetchdata?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{fetchdata?.CourseData?.CourseName}</div>}</div>
                                {fetchdata.CourseData?.CourseIntroVideo ? <video controls><source type="video/mp4" src={fetchdata.CourseData?.CourseIntroVideo} /></video> :
                                    <NVLImage className={"h-96 w-full py-4 "} src={"/Learning-course.png"} />}
                                {fetchdata?.CourseData?.CourseDescription && (<div className="p-4 rounded-md mx-auto break-all">
                                    <NVLlabel className={"text-xs nvl-Def-Label !text-[#F47A22]"} text={"Description"}></NVLlabel>
                                    <div ref={decr} className={`${fetchdata?.CourseData?.CourseDescription == undefined ? "text-gray-500 pt-2 text-xs" : "text-th-primary-dark font-medium text-justify flex-wrap text-xs pt-2"}`} />
                                </div>)}
                            </div>
                        </div>
                        <NVLCourseNavbar watch={watch} errors={errors} register={register} activeState={currentActivityId.current?.ActivityID} FunctionUpdate={FunctionUpdate} fetchCourseIntoduction={fetchCourseIntoduction} EnrollCourseData={tempEnrollCourseData.current} FetchActData={fetchActData} fetchdata={fetchdata} />
                    </div>
                </div >
            </Container>
        </>);
}
export default CourseConsume;