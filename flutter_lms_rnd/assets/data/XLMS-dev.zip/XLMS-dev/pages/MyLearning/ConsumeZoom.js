import NVLButton from "@components/Controls/NVLButton";
import { useCallback } from "react";

function ConsumeZoom({ props }) {
    const openInNewTab = useCallback((url) => {
        const newWindow = window.open(url, "_blank", "noopener,noreferrer");
        if (newWindow) newWindow.opener = null;
    }, []);

    const getDateFormat = useCallback((ConvertDate) => {
        const date = new Date(ConvertDate);
        const formattedDate = date.toLocaleString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric", hour: "numeric", minute: "numeric", hour12: true });
        return formattedDate;
    }, []);

    function userGroup() {
        const emails = props?.ActivityData?.AlternativeHosts?.split(",").filter((item) => props?.user?.attributes?.email === item?.trim());
        return emails && emails?.length != 0 ? true : false;
    }
    const getDuration = useCallback(() => {
        const hours = Math.floor(props?.ActivityData?.ActivityDuration / 60);
        const minutes = props?.ActivityData?.ActivityDuration % 60;
        return hours + " hrs " + minutes + " mins ";
    }, [props?.ActivityData?.ActivityDuration]);

    return (
        <div className="min-h-[480px] ">
            <div className="container mx-auto ">
                <div className="flex justify-between flex-wrap break-all">
                    {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                    <div className="grid items-center">
                        <NVLButton text={`${userGroup() === true ? "Start Meeting" : "Join Meeting"}`} ButtonType={`${userGroup() === true ? "success" : "primary"}`}
                            onClick={() => openInNewTab(props.TenantInfo.UserGroup != "Trainer" && userGroup() === false ? props?.ActivityData?.JoinURL : props?.ActivityData?.HostURL)} />
                    </div>
                </div>
                <div className="">
                    <div className="-mx-4 sm:-mx-8 px-4 sm:px-8 overflow-x-auto">
                        <div className="inline-block min-w-full shadow rounded-lg overflow-hidden">
                            <table className="table-fixed w-full justify-center text-center">
                                <tbody>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2">Start Time</td>
                                        <td className="border w-1/2 px-4 py-2">{getDateFormat(props?.ActivityData?.StartDate)}</td>
                                    </tr>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">Duration(minutes)</td>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">{getDuration()}</td>
                                    </tr>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2">Password protected</td>
                                        <td className="border w-1/2 px-4 py-2">{props?.ActivityData?.Password ? "Yes" : "No"}</td>
                                    </tr>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">Join meeting before host</td>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">{props?.ActivityData?.IsEnableBeforeHost ? "Yes" : "No"}</td>
                                    </tr>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2">Start video when host join</td>
                                        <td className="border w-1/2 px-4 py-2">{props?.ActivityData?.IsHostVideo ? "Yes" : "No"}</td>
                                    </tr>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">Start video when participant join</td>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">{props?.ActivityData?.IsParticipantsVideo ? "Yes" : "No"}</td>
                                    </tr>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2">Audio options</td>
                                        <td className="border w-1/2 px-4 py-2">{props?.ActivityData?.AudioOption}</td>
                                    </tr>
                                    <tr>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">Status</td>
                                        <td className="border w-1/2 px-4 py-2 bg-gray-100">{getDateFormat(props?.ActivityData?.StartDate)}</td>
                                    </tr>
                                </tbody>
                            </table>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default ConsumeZoom;