import { yupResolver } from "@hookform/resolvers/yup";
import { useCallback, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function ConsumeURL({ props, MarkAsCompleted, AppSyncDbConnectionModule, ChangeActId }) {
    const fileData = useRef(props?.ActivityData?.AttachFile == undefined ? JSON.parse(props?.ActivityData?.AttachFiles)?.[0]?.FilePath : props?.ActivityData?.AttachFile);

    const [navigation, setNavigation] = useState(false);
    {/*Valiation Mark As Completed*/ }
    const validationSchema = Yup.object().shape({
        markTheActivity: Yup.bool().test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
    });

    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };

    const { register, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    const openInNewTab = useCallback((url, ChangeActId) => {
        if (ChangeActId == true || ChangeActId == undefined) {
            const newWindow = window.open(url, "_blank", "noopener,noreferrer");
            if (newWindow) newWindow.opener = null;
            setNavigation(true);
        }
    }, []);

    return (
        <>
            <div className={` min-h-[480px] mx-auto bg-white`}>
                <div className="flex justify-between flex-wrap break-all">
                    {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                </div>
                {props?.ActivityData?.Appearance == "Embed" ?
                    <iframe src={fileData.current} width="100%" height="485px" />
                    : (!navigation && props?.RedirectMode != "Dashboard") && openInNewTab(fileData.current, ChangeActId)
                }
                <MarkAsCompleted watch={watch} errors={errors} register={register} />
            </div>

        </>
    );
}
export default ConsumeURL;