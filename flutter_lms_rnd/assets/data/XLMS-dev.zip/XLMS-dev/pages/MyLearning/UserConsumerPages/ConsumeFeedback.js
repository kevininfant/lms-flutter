import NVLAlert, { ModalClose, ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLLink from "@components/Controls/NVLLink";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { updateXlmsCourseEnrollUser, updateXlmsCourseFeedbackTemplateAtomicCount, updateXlmsEnrollUser, updateXlmsFeedbackTemplateAtomicCount } from "src/graphql/mutations";
import * as Yup from "yup";


export default function ConsumeFeedback({ props, LanguageType, QuesTemplate, MarkAsCompleted, AppSyncDbConnectionModule, UpdateCourseEnrollData }) {

    const router = useRouter();
    const [feedbackData, setFeedbackData] = useState(QuesTemplate);
    const feedbackDesc = useRef();
    const response = useRef(false)

    useEffect(() => {
        const filterFeedbackData = [];
        let quesTemplate;
        if (QuesTemplate != null) {

            if (props?.EnrollCourseData?.QuestionandOptions != undefined) {
                const temp = JSON.parse(props.EnrollCourseData.QuestionandOptions);
                if (temp?.[props?.ActivityData?.ActivityID] != undefined) {
                    quesTemplate = (temp?.[props?.ActivityData?.ActivityID]);
                }
            } else {
                if (props?.EnrollData?.QuestionandOptions != undefined) {
                    quesTemplate = JSON.parse(props?.EnrollData?.QuestionandOptions)
                }
            }
            quesTemplate != null && Object.values(quesTemplate).map((item) => {
                setValue("ddlUserConsume", item.Language)
                response.current = true;
            })
            Object.values(QuesTemplate)?.forEach((item) => {
                if (item.Language == document.getElementById("ddlUserConsume")?.options[document.getElementById("ddlUserConsume")?.selectedIndex]?.value) {
                    filterFeedbackData.push(item);
                }
                setFeedbackData(filterFeedbackData);
            });
        }
    }, [QuesTemplate, props?.ActivityData?.ActivityID, props?.EnrollCourseData?.QuestionandOptions, props?.EnrollData?.QuestionandOptions, setValue]);

    const initialModalState = {
        ModalType: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: props?.ActivityData?.CompletionMessage != "" ? props?.ActivityData?.CompletionMessage : "Feedback submitted successfully.",
        ModalOnClickEvent: () => {
            if (props.ActivityData.CourseID != undefined) {
                props?.ActivityData?.LinkNextActivity != "" && props?.ActivityData?.LinkNextActivity != undefined ? ModalClose() : router.push("/MyLearning/LearningDashboard");
            }
            else {
                props?.ActivityData?.LinkNextActivity != "" && props?.ActivityData?.LinkNextActivity != undefined ? ModalClose() : router.push("/MyLearning/LearningDashboard");

            }
        },
    };
    const [modalValues, setModalValues] = useState(initialModalState);
    const validationSchema = Yup.object().shape({
        ddlUserConsume: Yup.string()
            .required("Choose a Language")
            .test("", "", () => {
                const filterFeedbackData = [];
                QuesTemplate && Object.values(QuesTemplate)?.forEach((item) => {
                    if (item.Language == document.getElementById("ddlUserConsume")?.options[document.getElementById("ddlUserConsume")?.selectedIndex]?.value) {
                        filterFeedbackData.push(item);
                    }
                });
                setFeedbackData(filterFeedbackData);
                return true;
            }),
        markTheActivity: Yup.bool().nullable(true).test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
    });
    const languageTypeTemp = useMemo(() => {
        let languageType = [];
        if (Object.keys(JSON.parse(props?.LanguageName?.items[0].LanguageName)) != undefined) {
            Object.entries(JSON.parse(props?.LanguageName?.items[0].LanguageName)).forEach(([key, value]) => {
                languageType = [...languageType, { value: value, text: key }];
            });
        }
        return languageType;
    }, [props?.LanguageName?.items]);
    let ddlLanguageType = [];
    if (QuesTemplate != null) {
        [(QuesTemplate)]?.forEach((item) => {
            Object.values(item)?.forEach((value) => {
                const temp = languageTypeTemp?.filter((x) => x.value == value.Language);
                if (temp.length > 0) {
                    ddlLanguageType = [...ddlLanguageType, { ...temp[0] }];
                    ddlLanguageType = [...new Map(ddlLanguageType?.map(item => [item["value"], item])).values()];
                } else {
                    ddlLanguageType = [{ text: "Select", value: "" }];
                }
            });
        });
    }
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: true, };
    const { register, handleSubmit, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;
    const getOptionData = useCallback((Options) => {
        const optionsData = [{ value: "", text: "Select" }];
        if (feedbackData != null) {
            for (let i = 0; i < Options?.length; i++) {
                optionsData?.push({ value: Options[i], text: Options[i] });
            }
        }
        return optionsData;
    }, [feedbackData]
    );
    useEffect(() => {
        // VisitedHandler();
        if (props?.EnrollCourseData?.QuestionandOptions != undefined) {
            const temp = JSON.parse(props.EnrollCourseData.QuestionandOptions);
            if (temp?.[props?.ActivityData?.ActivityID] != undefined) {
                const tempdata = (temp?.[props?.ActivityData?.ActivityID]);
                tempdata != null && Object.values(tempdata).map((item,) => {
                    if (item?.OptionType == "Multiple Answer") {
                        const userFeedbackData = [];
                        item?.UserFeedBack && Object.keys(item?.UserFeedBack).map((qsn,) => {
                            userFeedbackData.push({ "Question": qsn?.replace(/[^\w\s]/gi, ""), "Answer": item?.UserFeedBack?.[qsn] });
                            setValue(qsn?.replace(/[^\w\s]/gi, ""), item?.UserFeedBack?.[qsn?.replace(/[^\w\s]/gi, "")], { shouldValue: true });
                        });
                    } else {
                        setValue(item?.Question?.replace(/[^\w\s]/gi, ""), item?.UserFeedBack);
                    }

                });
            }
        }
        else if (props?.EnrollData?.QuestionandOptions != null) {
            const quesTemplate = JSON.parse(props?.EnrollData?.QuestionandOptions);
            quesTemplate != null && Object.values(quesTemplate).map((item) => {
                if (item?.OptionType == "Multiple Answer") {
                    const userFeedbackData = [];
                    item?.UserFeedBack && Object.keys(item?.UserFeedBack).map((qsn) => {
                        userFeedbackData.push({ "Question": qsn?.replace(/[^\w\s]/gi, ""), "Answer": item?.UserFeedBack?.[qsn] });
                        setValue(qsn?.replace(/[^\w\s]/gi, ""), item?.UserFeedBack?.[qsn?.replace(/[^\w\s]/gi, "")], { shouldValue: true });
                    });
                } else {
                    setValue(item?.Question?.replace(/[^\w\s]/gi, ""), item?.UserFeedBack);
                }

            });
        }
    }, [props, props.CourseID, props?.ActivityData, props?.EnrollData?.CompletedStatus, setValue]);

    useEffect(() => {
        if (props?.ActivityData?.ActivityDescription.replace(/&nbsp;/g, " ") != "undefined" && document.getElementById("lblDescription") != null) {
            feedbackDesc.current = props?.ActivityData?.ActivityDescription?.replace(/&nbsp;/g, " ") != "undefined" ? props?.ActivityData?.ActivityDescription?.replace(/&nbsp;/g, " ") : "";
            document.getElementById("lblDescription").innerHTML = props?.ActivityData?.ActivityDescription.replace(/&nbsp;/g, " ") != "undefined" ? props?.ActivityData?.ActivityDescription.replace(/&nbsp;/g, " ") : "";
        }
    }, [props.ActivityDescription, props?.ActivityData?.ActivityDescription]);
    const finalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalType: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        } else {
            if (props?.ActivityData?.LinkNextActivity != undefined) {
                document.getElementById("divNextLinkActivity")?.classList?.remove("hidden");
                props?.ActivityData?.LinkNextActivity != "" && document.getElementById("divButton")?.classList?.add("hidden");
            }
            ModalOpen();
        }
    }, [props?.ActivityData?.LinkNextActivity]);

    const openInNewTab = useCallback((url) => {
        const newWindow = window.open(url, "_blank", "noopener,noreferrer");
        if (newWindow) newWindow.opener = null;

    }, []);
    const submitHandler = async (data) => {
        let feedbackdatatemp = {}
        const date = new Date();
        feedbackData && feedbackData?.map((item) => {
            const question = item?.Question?.replace(/[^\w\s]/gi, "");
            if (item?.OptionType == "Multiple Answer") {
                let userFeedbackData = {};

                item?.Options.map((CheckBoxItem, index) => {
                    userFeedbackData = { ...userFeedbackData, [question + index]: data?.[question + index] };
                });
                feedbackdatatemp = {
                    ...feedbackdatatemp, [question]: {
                        ...item, ["UserFeedBack"]: userFeedbackData
                    }
                }
            } else if (item?.AddQuestionType == "Label" || item?.AddQuestionType == "Information") {
                feedbackdatatemp = {
                    ...feedbackdatatemp, [question]: {
                        ...item, ["UserFeedBack"]: item?.Question
                    }
                }
            } else {
                feedbackdatatemp = {
                    ...feedbackdatatemp, [question]: {
                        ...item, ["UserFeedBack"]: data?.[question] == undefined ? "" : data?.[question]
                    }
                }
            }
        });
        const attendQuestionData = Object.values(feedbackdatatemp).filter((Qsn) => {
            return Qsn.UserFeedBack != "";
        });
        const totalAttendableQuestion = feedbackData && Object.values(feedbackData).filter((Qsn) => {
            return Qsn?.AddQuestionType != "Label" && Qsn?.AddQuestionType != "Information";
        });


        async function feedbacktemp() {
            let PK = "", SK = "";
            const query = props?.CourseEnrollData?.CourseID != undefined ? updateXlmsCourseFeedbackTemplateAtomicCount : updateXlmsFeedbackTemplateAtomicCount;
            if (props?.CourseEnrollData?.CourseID != undefined) {
                PK = "TENANT#" + props?.TenantInfo?.TenantID;
                SK = props?.ActivityData.SK;
            } else {
                PK = "TENANT#" + props?.TenantInfo?.TenantID;
                SK = "ACTIVITYTYPE#" + props?.ActivityData?.ActivityType + "#ACTIVITYID#" + props?.ActivityData.ActivityID;
            }
            AppsyncDBconnection(query, { input: { PK: PK, SK: SK, } }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        }
        let questionandOptions = JSON.parse(props?.EnrollCourseData?.QuestionandOptions != undefined ? props?.EnrollCourseData?.QuestionandOptions : "{}");
        if (props?.CourseEnrollData?.CourseID != undefined && questionandOptions?.[props.ActivityData.ActivityID] == undefined) {
            feedbacktemp();
        }
        else if (props?.EnrollData?.QuestionandOptions == undefined && props?.CourseEnrollData?.CourseID == undefined) {
            feedbacktemp();
        }
        const doneQuestion = feedbackdatatemp && Object.values(attendQuestionData).length;
        let activityQuestionandOptions;
        const TotalQuestion = feedbackData && Object.values(totalAttendableQuestion).length, currentpk = (props?.CourseEnrollData?.CourseID != null || props?.CourseEnrollData?.CourseID != undefined) ? props?.CourseEnrollData?.PK : props?.EnrollData?.PK, currentsk = (props?.CourseEnrollData?.CourseID != null || props?.CourseEnrollData?.CourseID != undefined) ? props?.CourseEnrollData?.SK : props?.EnrollData?.SK;
        const currentquery = (props?.CourseEnrollData?.CourseID != null || props?.CourseEnrollData?.CourseID != undefined) ? updateXlmsCourseEnrollUser : updateXlmsEnrollUser;
        let activityStatus = "100";
        if (props?.CourseEnrollData?.CourseID != undefined) {
            if (props?.EnrollCourseData?.QuestionandOptions != undefined) {
                questionandOptions = { ...questionandOptions, [props.ActivityData.ActivityID]: (feedbackdatatemp) };
            }
            else {
                questionandOptions = { [props.ActivityData.ActivityID]: feedbackdatatemp };
            }
            if (props.ActivityData.IsViewTheActivity) {
                activityStatus = doneQuestion == TotalQuestion ? "100" : ~~((doneQuestion / TotalQuestion) * 100).toFixed(2);
            }
            if (!props.ActivityData.IsMultipleSubmissions) {
                activityStatus = "100";
            }
            activityQuestionandOptions = {
                PK: props.EnrollCourseData.PK,
                SK: props.EnrollCourseData.SK,
                QuestionandOptions: JSON.stringify(questionandOptions),
                CompletionDate: date,
                LastModifiedDate: date
            };
            UpdateCourseEnrollData(activityQuestionandOptions);
        }
        else {
            activityQuestionandOptions = {
                PK: currentpk,
                SK: currentsk,
                QuestionandOptions: JSON.stringify(feedbackdatatemp),
                LastModifiedDate: date
            };
            if (props.ActivityData.IsViewTheActivity) {
                activityStatus = doneQuestion == TotalQuestion ? "100" : ~~((doneQuestion / TotalQuestion) * 100).toFixed(2);
            }
            if (!props.ActivityData.IsMultipleSubmissions) {
                activityStatus = "100";
            }
        }
        const finalStatus = (await AppsyncDBconnection(currentquery, { input: activityQuestionandOptions }, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        finalResponse(finalStatus);
    };
    const submitted = useMemo(() => {
        if (props?.EnrollCourseData?.CourseID != undefined) {
            if (props?.EnrollCourseData?.QuestionandOptions != undefined) {
                const temp = JSON.parse(props.EnrollCourseData.QuestionandOptions);
                if (temp?.[props.ActivityData.ActivityID] != undefined) {
                    return true;
                }
                else {
                    return false;
                }
            }
            else {
                return false;
            }
        }
        else {
            return props?.EnrollData?.QuestionandOptions != undefined;
        }

    }, [props.EnrollCourseData, props.ActivityData.ActivityID, props?.EnrollData?.QuestionandOptions]);

    return (
        <>
            <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalType} />
            <div className="w-full ">
                <div className="flex justify-between flex-wrap break-all">
                    {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                    <div className="grid items-center">
                        <NVLSelectField id={"ddlUserConsume"} className={`${response.current == true ? "w-48 Disabled" : "w-48"}`} disabled={response.current} options={LanguageType} errors={errors} register={register} />
                    </div>
                </div>
                <form id="Formjs" onSubmit={handleSubmit(submitHandler)} className={`${(!props?.ActivityData?.IsMultipleSubmissions && (props?.ActivityData?.CompletionProgress == "1" && props?.ActivityData?.Position == "Submited")) ?
                    "container pl-4 pt-4 mx-1  border rounded-md pointer-events-none" :
                    " "
                    }  min-h-[470px] p-2`}>

                    {feedbackData != null ?
                        Object.values(feedbackData).map((item, index) => {
                            const Question = item?.Question?.replace(/[^\w\s]/gi, "");
                            return (
                                <>
                                    <div key={index}>
                                        <div className="font-semibold pt-4 !overflow-hidden text-xl w-full pb-3">
                                            <div className="w-1/2 break-all">
                                                <NVLlabel
                                                    showFull
                                                    text={
                                                        index +
                                                        1 +
                                                        "." +
                                                        item.Label?.replace(/(<([^>]+)>)/gi, "") +
                                                        " " +
                                                        item.Question?.replace(/(<([^>]+)>)/gi, "")
                                                    }
                                                />
                                            </div>
                                            <div
                                                className={`my-auto pt-3 ${item.Adjustment == "Horizontal"
                                                    ? "flex gap-2"
                                                    : ""
                                                    } `}
                                                key={index}
                                            >
                                                {item?.OptionType == "Multiple Answer" ? (
                                                    item?.Options.map((CheckBoxItem, index) => {
                                                        return (
                                                            <>
                                                                <div className="gap-3">
                                                                    <NVLCheckbox
                                                                        id={`${Question}${index}`}
                                                                        text={CheckBoxItem}
                                                                        value={true}
                                                                        name={Question}
                                                                        errors={errors}
                                                                        register={register}
                                                                    ></NVLCheckbox>
                                                                </div>
                                                            </>
                                                        );
                                                    })
                                                ) : item?.OptionType == "Single Answer" ? (
                                                    item?.Options.map((radioItem, index) => {
                                                        return (
                                                            <>
                                                                <div className="w-full" key={index}>
                                                                    <NVLRadio
                                                                        id={Question}
                                                                        text={radioItem}
                                                                        name={Question}
                                                                        value={radioItem}
                                                                        errors={errors}
                                                                        register={register}
                                                                    ></NVLRadio>
                                                                </div>
                                                            </>
                                                        );
                                                    })
                                                ) : item?.AddQuestionType == "Multiple Choice" ? (
                                                    <>
                                                        <div className="gap-3" key={index}>
                                                            <NVLSelectField
                                                                id={Question}
                                                                options={getOptionData(item?.Options)}
                                                                className="nvl-Def-Input"
                                                                errors={errors}
                                                                register={register}
                                                            />
                                                        </div>
                                                    </>
                                                ) : item?.AddQuestionType == "Short Answer" ? (
                                                    <>
                                                        <div className="gap-3" key={index}>
                                                            <NVLMultilineTxtbox
                                                                id={Question}
                                                                className="nvl-Def-Input "
                                                                errors={errors}
                                                                register={register}
                                                            />
                                                        </div>
                                                    </>
                                                ) : item?.AddQuestionType == "Information" ? (
                                                    <>
                                                        <div className="gap-3" key={index}>
                                                            <NVLlabel
                                                                id={Question}
                                                                text={item?.InformationType}
                                                                className="font-bold"
                                                            />
                                                        </div>
                                                    </>
                                                ) : (
                                                    <></>
                                                )}
                                            </div>

                                        </div>
                                    </div>
                                </>
                            );
                        })

                        : <> <marquee className="text-red-500"><h1> <i className="fa-solid fa-face-frown-slight"></i> Ouch..! There is no feedback question   created for this user</h1></marquee></>
                    }

                    <div className="pt-5 pb-4" id="divButton">
                        <NVLButton id="btnSubmit" text={"Submit"} type="submit"

                            disabled={(!props?.ActivityData?.IsMultipleSubmissions && submitted) ? true : false}

                            className={`${(!props?.ActivityData?.IsMultipleSubmissions && submitted) ?
                                "w-32 nvl-button bg-gray-200 text-gray-400 pointer-events-none" :
                                "w-32 nvl-button bg-primary text-white"
                                } `}
                        ></NVLButton>
                    </div>
                    {feedbackDesc?.current && (<div className="grid">
                        <NVLlabel
                            text="Description"
                            className=" text-md font-extrabold"
                        ></NVLlabel>
                        <NVLlabel id="lblDescription" className="nvl-Def-Label break-all" text={feedbackDesc.current} showFull></NVLlabel>
                    </div>)}
                    {(props?.ActivityData?.LinkNextActivity != "") && <div className={`hidden`} id="divNextLinkActivity">
                        <div className="flex">
                            <NVLlabel
                                className="pt-3 text-md font-extrabold"
                                text="Link to next activity : "
                            ></NVLlabel>
                            <NVLLink text={props?.ActivityData?.LinkNextActivity == undefined ? "" : props?.ActivityData?.LinkNextActivity} onClick={() => openInNewTab(props?.ActivityData?.LinkNextActivity)} />
                        </div>
                    </div>}

                </form>
                <MarkAsCompleted watch={watch} errors={errors} register={register} />
            </div>
        </>
    );
}