import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { Fragment } from "react";

export const AnswerPreview = ({ getQuestion, index, errors, register, QuestionType, watch, BindFillups, ActivityData }) => {
    let FeedbackDisplay;
    return (<>
        {QuestionType == "MultipleChoice" &&
            <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50 p-4 rounded-md grid gap-2">
                <div className='flex justify-between'>
                    <p className="text-sm font-semibold">
                        {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div>{getQuestion?.YourMark == getQuestion?.TotalMark ?
                        <i className="fa-solid fa-check text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-green-600"></i>
                        :
                        <i className="fa-solid fa-xmark text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-red-600"></i>
                    }</div>
                </div>
                {getQuestion?.ChoiceType == "MultipleAnswer" ? (
                    getQuestion?.Options.map((QestinOption, indexOf) => {
                        return (
                            <Fragment key={crypto.randomUUID()}>
                                <NVLCheckbox id={"chkMultipleAnswer" + (index) + "-" + (indexOf)} name={"chkMultipleAnswer" + (index) + "-" + (indexOf)} text={QestinOption?.Option?.trim()} value={QestinOption.Option} errors={errors} register={register} showFull={true}  ></NVLCheckbox>
                            </Fragment>
                        );
                    })

                )
                    : getQuestion?.ChoiceType == "SingleAnswer" ? (
                        getQuestion?.Options.map((QestinOption) => {
                            return (
                                <Fragment key={crypto.randomUUID()}>
                                    <NVLRadio id={"SingleAnswer" + index} name={"SingleAnswer" + index} value={QestinOption?.Option} type="radio" text={QestinOption?.Option?.trim()} register={register} errors={errors} showFull={true}/>
                                </Fragment>
                            );
                        })) : getQuestion?.ChoiceType == "Dropdown" ? (
                        <>
                            <NVLSelectField options={watch("MultiDropDown" + index)} name={"multiChoiceSelect" + index} id={"multiChoiceSelect" + index} className={"nvl-Def-Input"} register={register} errors={errors}></NVLSelectField>
                        </>
                    ) :
                        (<></>)}
                {ActivityData?.IsShowBothAnswer || ActivityData?.IsShowAnswer ?
                    <div className='flex justify-between flex-wrap p-2'>
                        <div><NVLlabel className="nvl-Def-Label" text="Your Answer"></NVLlabel>
                            {getQuestion?.YourAnswer.map((answer,) => { 
                                getQuestion?.Options.map((feed) => { answer?.Option == feed.Option ? FeedbackDisplay = feed?.Feedback : "" })
                                return  <Fragment key={crypto.randomUUID()}> <div className="grid">
                                    <div className={`relative font-semibold
                                    ${getQuestion?.YourMark == getQuestion?.TotalMark?"bg-green-500":"bg-yellow-500"}
                                      p-2 text-white text-xs 
                                     mr-2 px-2.5 py-0.5 rounded dark:bg-gray-900 `}>
                                        <i className={`fa-solid fa-caret-down absolute -bottom-2 left-0 text-lg
                                         ${getQuestion?.YourMark == getQuestion?.TotalMark?"text-green-500":"text-yellow-500"}`}></i>
                                        {answer?.Feedback}
                                        </div> {answer?.Option}</div></Fragment>;
                            })}
                            
                           {/* <NVLlabel className="nvl-Def-Label" text={FeedbackDisplay}></NVLlabel> */}
                        </div>
                        {ActivityData?.IsShowBothAnswer && (<div>
                            <NVLlabel className="nvl-Def-Label" text="Correct Answer"></NVLlabel>
                            {getQuestion?.ActualAnswer.map((answer,index) => { return answer?.Option +(index == getQuestion?.ActualAnswer?.length -1 ? "": ", ") ; })}
                        </div>)}
                    </div>
                    : ""}
            </div>
        
        }
        {QuestionType == "Ordering" &&

            <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50  p-4 rounded-md grid gap-2">
                <div className='flex justify-between'>
                    <p className="text-sm font-semibold">
                        {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div>{getQuestion?.YourMark == getQuestion?.TotalMark ?
                        <i className="fa-solid fa-check text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-green-600"></i>
                        :
                        <i className="fa-solid fa-xmark text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-red-600"></i>
                    }</div>
                </div>
                <div className="grid gap-4">
                    {watch("OrderingOptions" + index)?.map((e, indexOf) => {
                        return (
                            <Fragment key={crypto.randomUUID()}>
                                <div id={indexOf} className="h-8 bg-white shadow-md rounded flex justify-between p-2 ">
                                    {e}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                </div>
                            </Fragment>
                        );
                    })}
                </div>

                {ActivityData?.IsShowBothAnswer || ActivityData?.IsShowAnswer ?
                    <div className='flex justify-between flex-wrap p-2'>
                        <div><NVLlabel className="nvl-Def-Label" text="Your Answer"></NVLlabel>
                            {getQuestion?.YourAnswer.map((youranswer,index) => { return youranswer + (index == getQuestion?.YourAnswer?.length -1 ? "": ", "); })}
                        </div>
                        {ActivityData?.IsShowBothAnswer && (<div>
                            <NVLlabel className="nvl-Def-Label" text="Correct Answer"></NVLlabel>
                            {getQuestion?.ActualAnswer.map((youranswer,index) => { return youranswer + (index == getQuestion?.YourAnswer?.length -1 ? "": ", "); })}
                        </div>)}
                    </div>
                    : ""}
            </div>


        }
        {QuestionType == "Description" &&
            <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50  p-4 rounded-md grid gap-2">
                <div className='flex justify-between'>
                    <p className="text-sm font-semibold">
                        {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div>{getQuestion?.YourMark > 0 ?
                        <i className="fa-solid fa-check text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-green-600"></i>
                        :
                        <i className="fa-solid fa-xmark text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-red-600"></i>
                    }</div>
                </div>
                <div className="grid gap-4">
                    <NVLMultilineTxtbox id={"txtQuestionForQuiz" + index} title="Add Answer" errors={errors} register={register} className="nvl-non-mandatory nvl-Def-Input" />
                </div>
                {ActivityData?.IsShowBothAnswer || ActivityData?.IsShowAnswer ?
                    <div className='flex justify-between flex-wrap p-2'>
                        <div><NVLlabel className="nvl-Def-Label" text="Your Answer"></NVLlabel>
                            {getQuestion?.YourAnswer}
                        </div>
                        {ActivityData?.IsShowBothAnswer && (<div>
                            <NVLlabel className="nvl-Def-Label" text="Correct Answer"></NVLlabel>
                            {getQuestion?.Options.map((post) => { return post?.Option + "  "; })}
                        </div>)}
                    </div>

                    : ""}

            </div>}
        {QuestionType == "Match" &&

            <div key={index} id={"QuestionForQuiz" + index} className="bg-lime-50 p-4 rounded-md grid gap-2 text-xs">
                <div className='flex justify-between'>
                    <p className="text-sm font-semibold">
                        {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div>{getQuestion?.YourMark == getQuestion?.TotalMark ?
                        <i className="fa-solid fa-check text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-green-600"></i>
                        :
                        <i className="fa-solid fa-xmark text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-red-600"></i>
                    }</div>
                </div>
                <div className="flex gap-4 justify-center">
                    <div className='grid gap-4'>
                        {watch("MatchingA" + index)?.map((e) => {
                            return (
                                <Fragment key={crypto.randomUUID()}>
                                    <div
                                        className="h-8 bg-white shadow-md rounded flex justify-between p-2 "
                                    >
                                        {e}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                    </div>
                                </Fragment>
                            );
                        })}
                    </div>
                    <div className='grid gap-4'>

                        {watch("MatchingB" + index)?.map((e) => {
                            return (
                                <Fragment key={crypto.randomUUID()}>
                                    <div draggable onDragOver={(e) => e.preventDefault()} className="h-8  bg-white shadow-md rounded flex justify-between p-2">
                                        {e}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                    </div>
                                </Fragment>
                            );
                        })}
                    </div>
                </div>
                {ActivityData?.IsShowBothAnswer || ActivityData?.IsShowAnswer ?
                    <div className='flex justify-between flex-wrap p-2'>
                        <div><NVLlabel className="nvl-Def-Label" text="Your Answer"></NVLlabel>
                            {getQuestion?.YourAnswer.map((youranswer,) => { return (<Fragment key={crypto.randomUUID()}>{youranswer?.key + "-" + youranswer?.value} <br /></Fragment>); })}
                        </div>
                        {ActivityData?.IsShowBothAnswer && (<div>
                            <NVLlabel className="nvl-Def-Label" text="Correct Answer"></NVLlabel>
                            {getQuestion?.ActualAnswer.map((youranswer,) => { return (<Fragment key={crypto.randomUUID()}>{youranswer?.key + "-" + youranswer?.value} <br /></Fragment>); })}
                        </div>)}
                    </div>
                    : ""}
            </div>
        }

        {QuestionType == "FillInTheBlank" &&

            <div key={index} id={"FillInTheBlank" + index} className="bg-lime-50  p-4 rounded-md grid gap-2 ">
                <div className='flex justify-between'>
                    <p className="text-sm font-semibold">
                        {(index + 1) + "."} {getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div>{getQuestion?.YourMark == getQuestion?.TotalMark ?
                        <i className="fa-solid fa-check text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-green-600"></i>
                        :
                        <i className="fa-solid fa-xmark text-white h-8 w-8 grid place-content-center cursor-pointer rounded-full bg-red-600"></i>
                    }</div>
                </div>

                <BindFillups SNO={index + 1} getQuestion={getQuestion} id={"FillInTheBlank" + index} FillInTheBlank={getQuestion?.Question.replace(/<[^>]+>/g, "")} ></BindFillups>

                {ActivityData?.IsShowBothAnswer || ActivityData?.IsShowAnswer ?
                    <div className='flex justify-between flex-wrap p-2'>
                        <div><NVLlabel className="nvl-Def-Label" text="Your Answer"></NVLlabel>
                            {getQuestion?.YourAnswer.map((youranswer,) => { return youranswer ; })}
                        </div>
                        {ActivityData?.IsShowBothAnswer && (<div>
                            <NVLlabel className="nvl-Def-Label" text="Correct Answer"></NVLlabel>
                            {getQuestion?.ActualAnswer.map((youranswer,) => { return youranswer ; })}
                        </div>)}
                    </div>
                    : ""}
            </div>
        }
    </>);
};
export default function QuizComponents() {
    return (<></>);
}