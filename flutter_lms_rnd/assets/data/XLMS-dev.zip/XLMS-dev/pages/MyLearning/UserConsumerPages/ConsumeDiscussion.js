import NVLDiscussionBox from "@components/Controls/NVLDiscussionBox";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLHeader from "@components/Controls/NVLHeader";
import { yupResolver } from "@hookform/resolvers/yup";
import { useRouter } from "next/router";
import { useCallback, useMemo, useRef } from "react";
import { useForm } from "react-hook-form";
import { listXlmsCourseDiscussionChat, listXlmsDiscussionChat } from "src/graphql/queries";
import * as Yup from "yup";

function ConsumeDiscussion({ props, MarkAsCompleted, AppSyncDbConnectionModule, }) {
    const router = useRouter();
    const variable = useRef(props?.CourseEnrollData?.CourseID == undefined ?
        { PK: "TENANT#" + props?.TenantId, SK: "ACTIVITY#" + props?.ActivityData?.ActivityID } : { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "COURSEID#" + props.ActivityData.CourseID + "#MODULE#" + props.ActivityData.ModuleID + "#ACTIVITY#" + props.ActivityData.ActivityID + "#TOPIC#" });
    const headerColumn = [{ HeaderName: "", Columnvalue: "TopicName", HeaderCss: "w-12/12 " }];
    const headerHandler = (e, url) => {
        e.preventDefault();
        router.push(url);
    };

    const query = useMemo(() => { return (props?.CourseEnrollData?.CourseID != undefined) ? listXlmsCourseDiscussionChat : listXlmsDiscussionChat; }, [props?.CourseEnrollData?.CourseID]);
    const queryName = useMemo(() => { return (props?.CourseEnrollData?.CourseID != undefined) ? "listXlmsCourseDiscussionChat" : "listXlmsDiscussionChat"; }, [props?.CourseEnrollData?.CourseID]);
    const validationSchema = Yup.object().shape({
        markTheActivity: Yup.bool().test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    const gridDataBind = useCallback((Message) => {
        const rowGrid = [];
        Message?.map((getItem, index) => {
            !getItem.IsDelete ? rowGrid.push({ TopicName: <div key={index}><NVLDiscussionBox DiscussionMessage={getItem} props={props} /></div> }) : "";
        });
        return rowGrid;

    }, [props]);

    return (
        <>
            <div className="flex justify-between flex-wrap break-all">
                {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
            </div>
            <NVLHeader LinkName3="+Create Topic"
                className3={!props.ActivityData?.IsCompleteTheActivity ? "nvl-button-success !w-32" : "hidden"}
                DisableButton3={props.ActivityData?.IsCompleteTheActivity}
                RedirectAction3={(e) => headerHandler(e, `/MyLearning/CreateTopic?Mode=Create&ActivityID=${props?.ActivityData?.ActivityID != undefined ?
                    props?.ActivityData?.ActivityID : ""}&CourseID=${props?.ActivityData?.CourseID != undefined ? props.ActivityData?.CourseID : ""}
                &ModuleID=${props?.ActivityData?.ModuleID != undefined ? props?.ActivityData?.ModuleID : ""}&BatchID=${(props?.EnrollCourseData?.BatchID != null)
                        ? props?.EnrollCourseData.BatchID : ""}&CourseName=${(props?.CourseEnrollData?.CourseName != undefined) ?
                            encodeURIComponent(props?.CourseEnrollData?.CourseName) : ""}`)} IsNestedHeader />
            <div className="min-h-[470px]">
                <NVLGridTable refershPage={false} user={props?.user} id="tblActivityList" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={query} querryName={queryName} variable={variable.current} />
                <MarkAsCompleted watch={watch} errors={errors} register={register} />
            </div>
        </>
    );
}

export default ConsumeDiscussion;