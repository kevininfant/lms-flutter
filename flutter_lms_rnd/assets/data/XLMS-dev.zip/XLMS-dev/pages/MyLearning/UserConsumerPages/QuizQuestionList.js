import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLSelectField from "@components/Controls/NVLSelectField";
import NVLWebWorker from "@components/Controls/NVLWebWorker";
import { yupResolver } from "@hookform/resolvers/yup";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { createXlmsUserCertificateInfo, updateXlmsCourseEnrollUser, updateXlmsEnrollUser } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsBatchCourseQuestionInfo, getXlmsCourseEnrollUser, getXlmsCourseManagementInfo, getXlmsEnrollUser, listXlmsCourseModule, listXlmsLanguages, listXlmsQuizConsumeCourseQuestionlistTemplate, listXlmsQuizConsumeTemplate } from "src/graphql/queries";
import * as Yup from "yup";
import { MultipleAnswerCompoent } from "./QuizQuestionTypeComponent";
import QuizTimer from "./QuizTimerComponent";

export default function QuizQuestionList(props) {
  
    const FillUps = useRef();
    const [popupValues, setPopupValues] = useState();
    const quizStartTime = useRef("") 
    const shuffle = useCallback((array) => {
        const byteArray = new Uint8Array(1);
        function getScaledValue(value, sourceRangeMin, sourceRangeMax, targetRangeMin, targetRangeMax) {
            const targetRange = targetRangeMax - targetRangeMin;
            const sourceRange = sourceRangeMax - sourceRangeMin;
            return (value - sourceRangeMin) * targetRange / sourceRange + targetRangeMin;
        }
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(crypto.getRandomValues(byteArray)[0] * (i + 1));
            const k = Math.floor(getScaledValue(j, 0, 255, 0, i));
            if (k < array.length) {
                const temp = array[i];
                array[i] = array[k];
                array[k] = temp;
            }
        }
        return array;
    }, []);

    const router = useRouter();
    const TenantID = useMemo(() => { return props.TenantInfo.TenantID; }, [props.TenantInfo.TenantID]);
    const Usersub = useMemo(() => { return props.user.attributes["sub"]; }, [props.user.attributes]);
    const activityID = useMemo(() => { return router.query["ActivityID"]; }, [router.query]);
    const LanguageView = useMemo(() => { return router.query["LanguageView"]; }, [router.query]);
    const CourseId = useMemo(() => { return router.query["CourseID"]; }, [router.query]);
    const ModuleId = useMemo(() => { return router.query["ModuleID"]; }, [router.query]);
    const BatchId = useMemo(() => { return router.query["BatchID"]; }, [router.query]);
    const resetCount = useRef(1);
    const VisitedQuestions = useRef({});
    const [QuizData, setQuizData] = useState({});
    const [QuestionList, setQuestionList] = useState({});
    const [attemptRestrict,setAttempt] = useState(false)

    useEffect(() => {
        async function FetchData() {
            quizStartTime.current = new Date()
            let ActList = [], CourseEnrollData = {}, QuestionsResponse, ActivityResponse, activtyResponse;
            if (CourseId != "") {
                const QuestionsRes = await AppsyncDBconnection(listXlmsQuizConsumeCourseQuestionlistTemplate, { PK: "TENANT#" + TenantID, SK: "COURSE#" + CourseId + "#MODULE#" + ModuleId + "#ACTIVITYID#" + activityID + "#LANGUAGE#" + LanguageView, IsConsume: true }, props.user?.signInUserSession?.accessToken?.jwtToken);
                QuestionsResponse = QuestionsRes.res?.listXlmsQuizConsumeCourseQuestionlistTemplate?.items != undefined ? QuestionsRes.res?.listXlmsQuizConsumeCourseQuestionlistTemplate?.items : [];
                const ActivityRes = await AppsyncDBconnection(getXlmsCourseEnrollUser, { PK: "TENANT#" + TenantID + "#COURSE#ENROLLUSER#" + Usersub, SK: "COURSE#" + CourseId + "#BATCH#" + BatchId, }, props.user?.signInUserSession?.accessToken?.jwtToken);
                CourseEnrollData = ActivityRes.res.getXlmsCourseEnrollUser;
                const activityVariable = { PK: "TENANT#" + TenantID, SK: "COURSEID#" + CourseId, IsDeleted: false };
                const ActyList = (await AppsyncDBconnection(listXlmsCourseModule, activityVariable, props.user?.signInUserSession?.accessToken?.jwtToken));
                ActivityResponse = ActyList.res.listXlmsCourseModule?.items.filter((item) => item.ActivityID === activityID)[0];
                ActList = (await AppsyncDBconnection(listXlmsCourseModule, activityVariable, props.user?.signInUserSession?.accessToken?.jwtToken))?.res?.listXlmsCourseModule?.items;
            }
            else {
                const QuestionsRes = await AppsyncDBconnection(listXlmsQuizConsumeTemplate, { PK: "TENANT#" + TenantID, SK: "ACTIVITYID#" + activityID + "#LANGUAGE#" + LanguageView, IsConsume: true }, props.user?.signInUserSession?.accessToken?.jwtToken);
                QuestionsResponse = QuestionsRes.res.listXlmsQuizConsumeTemplate?.items != undefined ? QuestionsRes.res.listXlmsQuizConsumeTemplate?.items : [];
                const ActivityRes = await AppsyncDBconnection(getXlmsEnrollUser, { PK: "TENANT#" + TenantID + "#ACTIVITY#ENROLLUSER#" + Usersub, SK: "ACTIVITYID#" + activityID, }, props.user?.signInUserSession?.accessToken?.jwtToken);
                ActivityResponse = ActivityRes?.res?.getXlmsEnrollUser != undefined ? ActivityRes.res.getXlmsEnrollUser : {};
                activtyResponse = await AppsyncDBconnection(
                    getXlmsEnrollUser,
                    {
                        PK: "TENANT#" + TenantID + "#" + ActivityRes?.res?.getXlmsEnrollUser?.Shard,
                        SK: "ACTIVITYTYPE#" + ActivityRes?.res?.getXlmsEnrollUser?.ActivityType + "#ACTIVITYID#" + activityID,
                    },
                    props.user?.signInUserSession?.accessToken?.jwtToken
                );
            }

            let restrictAttemptWise,restrictStatusWise;

            if (CourseId != "") { 
                if (ActivityResponse && ActivityResponse?.MaximumAttempt != "" && ActivityResponse?.MaximumAttempt <= (CourseEnrollData?.QuestionandOptions && JSON?.parse(CourseEnrollData?.QuestionandOptions)?.[activityID]?.["QuizTakenCount"])){
                    restrictAttemptWise = true
                    setAttempt((attempt)=> {return !attempt})
                }
                if(ActivityResponse?.AllowMaximumAttempts == "if not Passed"  ) {
                    const temp = JSON?.parse(CourseEnrollData?.QuestionandOptions)?.[activityID]?.["QuizStatus"] ? JSON?.parse(CourseEnrollData?.QuestionandOptions)?.[activityID]?.["QuizStatus"] : "";
                    restrictStatusWise = temp == "Fail" || temp == "" ? false : true
                    setAttempt((attempt)=> {return  temp == "Fail" || temp == "" ? attempt : !attempt})
                }
             } else {
                 if (activtyResponse?.res?.getXlmsEnrollUser?.MaximumAttempt != "" && activtyResponse?.res?.getXlmsEnrollUser?.MaximumAttempt <= ActivityResponse?.QuizTakenCount){
                    restrictAttemptWise = true
                    setAttempt((attempt)=> {return !attempt})
                 }
                 if(activtyResponse?.res?.getXlmsEnrollUser?.AllowMaximumAttempts == "if not Passed") {
                    const temp = ActivityResponse?.QuizStatus ? ActivityResponse?.QuizStatus : "" ;
                    restrictStatusWise = temp == "Fail" || temp == ""  ? false : true
                    setAttempt((attempt)=> {return  temp == "Fail" || temp == "" ? attempt : !attempt})
                 }
             } 

             if(restrictAttemptWise || restrictStatusWise){
                window.history.back()
             } else {
            const RecordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME" }, props.user?.signInUserSession?.accessToken?.jwtToken);
            let RandomQuestion = { TotalNoOfQuestion: 0, QuestionBankID: "", Questions: [], QuestionBank: {} };
            if (QuestionsResponse?.length > 0) {
                QuestionsResponse.map((temp, index) => {
                    if (temp?.IsRandomQuestion && temp?.QuestionType == "Random") {
                        RandomQuestion = { ...RandomQuestion, TotalNoOfQuestion: RandomQuestion.TotalNoOfQuestion + 1, QuestionBankID: temp?.QuestionBankID, Questions: [...RandomQuestion?.Questions, index] }
                        if (RandomQuestion?.QuestionBank?.[temp?.QuestionBankID] != undefined) {
                            RandomQuestion = { ...RandomQuestion, QuestionBank: { ...RandomQuestion?.QuestionBank, [temp?.QuestionBankID]: RandomQuestion?.QuestionBank?.[temp?.QuestionBankID] + 1 } }
                        }
                        else {
                            RandomQuestion = { ...RandomQuestion, QuestionBank: { ...RandomQuestion?.QuestionBank, [temp?.QuestionBankID]: 1 } }
                        }
                    }

                })
            }
            if (RandomQuestion?.TotalNoOfQuestion > 0 && RandomQuestion?.QuestionBankID !== undefined) {
                let tempRandom = []
                let QuestionBankIDArray = Object.keys(RandomQuestion?.QuestionBank);
                for (let i = 0; i < QuestionBankIDArray?.length; i++) {
                    let json = `{"TenantID": "${TenantID}", "CategoryID": "", "SubCategoryID": "", "CourseID": "${CourseId}", "ModuleID": "", "LanguageCode": "${LanguageView}", "QuestionBankID": "${QuestionBankIDArray[i]}", "Type": "Course", "NumberOfQuestion": ${RandomQuestion?.QuestionBank?.[QuestionBankIDArray[i]]}}`;

                    const headers = { method: "POST", headers: { "Content-Type": "application/json" }, body: json, };
                    let finalStatus = await APIGatewayPostRequest(process.env.QuizRandom, headers);
                    let temp = await finalStatus.res.text();
                    let SK = [];
                    if (temp != undefined) {
                        try { SK = JSON.parse(temp); }
                        catch (e) { }
                    }
                    if (SK.length > 25) {
                        do {
                            finalStatus = await AppsyncDBconnection(getXlmsBatchCourseQuestionInfo, { PK: "TENANT#" + TenantID, SK: SK.splice(0, 25) }, props.user?.signInUserSession?.accessToken?.jwtToken);
                            if (finalStatus.res?.getXlmsBatchCourseQuestionInfo?.length > 0) {
                                tempRandom = [...tempRandom, ...finalStatus.res?.getXlmsBatchCourseQuestionInfo];
                            }
                        } while (SK.length !== 0);
                    }
                    else if (SK.length > 0) {
                        finalStatus = await AppsyncDBconnection(getXlmsBatchCourseQuestionInfo, { PK: "TENANT#" + TenantID, SK: SK }, props.user?.signInUserSession?.accessToken?.jwtToken);
                        if (finalStatus.res?.getXlmsBatchCourseQuestionInfo?.length > 0) {
                            tempRandom = [...tempRandom, ...finalStatus.res?.getXlmsBatchCourseQuestionInfo];
                        }
                    }
                }
                RandomQuestion?.Questions.map((item, index) => {
                    if (tempRandom?.length > index)
                        QuestionsResponse[item] = tempRandom[index]
                })
            }
                      

            const temp = {
                QuizQuestions: QuestionsResponse,
                ActivityData: ActivityResponse != undefined && ActivityResponse,
                LanguageName: RecordContentDataLanguage?.res?.listXlmsLanguages,
                ActList: ActList,
                CourseEnrollData: CourseEnrollData,
                ShardActivityData: CourseId != "" ? ActivityResponse : activtyResponse?.res?.getXlmsEnrollUser
            };
            setQuizData((data) => {
                return { ...data, ...temp };
            });
            setQuestionList((data) => { return { ...data, current: (activtyResponse?.res?.getXlmsEnrollUser?.IsShuffleWithInQuestion) ? shuffle(QuestionsResponse) : QuestionsResponse }; });
           }
        }
        FetchData();
        return (() => {
            setQuestionList((data) => {
                return { ...data };
            });
            setQuizData((data) => {
                return { ...data };
            });
        });
    }, [BatchId, CourseId, LanguageView, ModuleId, TenantID, Usersub, activityID, props.user?.signInUserSession?.accessToken?.jwtToken, shuffle]);

   
    const BindFillups = useCallback(({ id, FillInTheBlank, errors, register, shuffle, CurrentQuestion }) => {
        const question = FillInTheBlank;
        const OptionsString = question?.match(/\[.+?\]/g);
        const newstr = question?.replace(/\[(.+?)\]/g, "^");
        const replaceDrop = newstr?.split("^");
        return <div className="flex-wrap" >
            {replaceDrop?.map((e, index) => {
                let options;
                let optionsValue = [{ text: "Select Value", value: "" }], tempOptionsfull;
                if (OptionsString?.[index] != undefined)
                    tempOptionsfull = OptionsString[index].substring(1, OptionsString[index].length - 1);
                if (tempOptionsfull != undefined) {
                    options = tempOptionsfull.split("|");
                    FillUps.current = { ...FillUps.current, [id]: { ...FillUps.current?.[id], [index]: options[0] } };
                    let shuffled = shuffle(options);
                    if (VisitedQuestions.current?.["Question" + CurrentQuestion]?.["Option" + index] == undefined) {
                        const tempparse = VisitedQuestions.current?.["Question" + CurrentQuestion] != undefined ? VisitedQuestions.current?.[CurrentQuestion] : {};
                        VisitedQuestions.current = { ...VisitedQuestions.current, ["Question" + CurrentQuestion]: { ...tempparse, ["Option" + index]: shuffled } };
                    }
                    else {
                        shuffled = VisitedQuestions.current?.["Question" + CurrentQuestion]?.["Option" + index];
                    }
                    shuffled.map(e => {
                        optionsValue = [...optionsValue, { text: e, value: e }];
                    });
                }
                return (
                    <div className="px-2 flex gap-2" key={index}><NVLlabel className="text-xs font-semibold pt-2">{e != "" && e}</NVLlabel>
                        {tempOptionsfull != undefined && <NVLSelectField id={id + "-" + index} className="w-48 p-2" options={optionsValue} errors={errors} register={register} />}
                    </div>);
            }
            )
            }
        </div>;
    }, []);

    const [modalValues, setModalValues] = useState({
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            router.back();
        }
    });

    const validationSchema = Yup.object().shape({});
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, handleSubmit, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;
    const dragItem = useRef(null);
    const dragOverItem = useRef(null);

    // data Initializing 
    useEffect(() => {
        for (let i = 0; i < QuestionList?.current?.length; i++) {
            if (QuestionList?.current?.[i]?.QuestionType == "Ordering") {
                setValue("OrderingOptions" + i, shuffle(JSON.parse(QuestionList?.current?.[i]?.Options)));
            }
            else if (QuestionList?.current?.[i]?.QuestionType == "Match") {
                const dataMatch = JSON.parse(QuestionList?.current?.[i]?.Options);
                const matchingA = [], matchingB = [], MatchingC = [];
                for (let i = 0; i < dataMatch?.length; i++) {
                    matchingA.push(dataMatch?.[i]?.[0]);
                    matchingB.push(dataMatch?.[i]?.[1]);
                    MatchingC.push({ key: dataMatch?.[i]?.[0], value: dataMatch?.[i]?.[1] });
                }
                setValue("MatchTheFollowingCorrectAnswer" + i, MatchingC);
                setValue("MatchingA" + i, shuffle(matchingA));
                setValue("MatchingB" + i, shuffle(matchingB));
                const n = [];
                for (let index = 0; index < dataMatch?.length; index++) {
                    n.push({ key: watch("MatchingA" + i)?.[index], value: watch("MatchingB" + i)?.[index] });
                }
                setValue("MatchingC" + i, n);
            }
        }
        setValue("currentIndex", 0);
    }, [QuestionList, QuizData?.ShardActivityData?.IsShuffleWithInChoice, setValue, shuffle, watch]);

    const QuizSubmitData = useCallback(async () => {
        onSubmit(QuizData, QuestionList);
    }, [QuestionList, QuizData, onSubmit]);
    // submit Handling

    const ModuleLength = useMemo(() => {
        let temp = Object.values(JSON.parse(QuizData?.CourseEnrollData?.Restriction != undefined ? QuizData?.CourseEnrollData.Restriction : "{}"));
        const groupBy = function (xs, key) {
            return xs.reduce(function (rv, x) {
                (rv[x[key]] = rv[x[key]] || []).push(x);
                return rv;
            }, {});
        };
        const ModuleMust = temp[0]?.flow?.must != undefined ? temp[0]?.flow?.must : [];
        const ModuleMustJson = groupBy(ModuleMust, "ModuleID");
        const ModuleLength = ModuleMustJson?.[ModuleId]?.length != undefined ? ModuleMustJson?.[ModuleId]?.length : 1;
        return ModuleLength;
    }, [QuizData?.CourseEnrollData?.Restriction, ModuleId])

    
    const onSubmit = useCallback(async (QuizData, QuestionList) => {
        const multiMultipleAns = {};
        const multiSingleAns = {};
        for (let i = 0; i < QuestionList?.current?.length; i++) {
            if (QuestionList?.current?.[i]?.QuestionType == "MultipleChoice") {
                if (QuestionList?.current?.[i]?.ChoiceType == "MultipleAnswer") {
                    if (VisitedQuestions?.current?.["Question" + i] != undefined) {
                        VisitedQuestions?.current?.["Question" + i].Option.map((e, index) => {
                            if (multiMultipleAns?.[VisitedQuestions?.current?.["Question" + i]?.Question] == undefined) {
                                multiMultipleAns = { ...multiMultipleAns, [VisitedQuestions?.current?.["Question" + i]?.Question]: { [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade, index: index } } }
                            }
                            else {
                                multiMultipleAns = { ...multiMultipleAns, [VisitedQuestions?.current?.["Question" + i]?.Question]: { ...multiMultipleAns?.[VisitedQuestions?.current?.["Question" + i]?.Question], [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade, index: index } } }
                            }
                        });
                    }
                    else {
                        JSON.parse(QuestionList?.current?.[i]?.Option != undefined ? QuestionList?.current?.[i]?.Option : "[]").map((e, index) => {
                            if (multiMultipleAns?.[QuestionList?.current?.[i]?.Question] == undefined) {
                                multiMultipleAns = { ...multiMultipleAns, [QuestionList?.current?.[i]?.Question]: { [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade } } }
                            }
                            else {
                                multiMultipleAns = { ...multiMultipleAns, [QuestionList?.current?.[i]?.Question]: { ...multiMultipleAns?.[VisitedQuestions?.current?.["Question" + i]], [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade } } }

                            }
                        });
                    }
                } else if (QuestionList?.current?.[i]?.ChoiceType == "SingleAnswer") {
                    if (VisitedQuestions?.current?.["Question" + i] != undefined) {
                        VisitedQuestions?.current?.["Question" + i]?.Option?.map((e, index) => {
                            if (multiSingleAns?.[VisitedQuestions?.current?.["Question" + i]?.Question] == undefined) {
                                multiSingleAns = { ...multiSingleAns, [VisitedQuestions?.current?.["Question" + i]?.Question]: { [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade, index: index } } }
                            }
                            else {
                                multiSingleAns = { ...multiSingleAns, [VisitedQuestions?.current?.["Question" + i]?.Question]: { ...multiSingleAns?.[VisitedQuestions?.current?.["Question" + i]?.Question], [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade, index: index } } }
                            }
                        });
                    }
                    else {
                        JSON.parse(QuestionList?.current?.[i]?.Option != undefined ? QuestionList?.current?.[i]?.Option : "[]")?.map((e, index) => {
                            if (multiSingleAns?.[QuestionList?.current?.[i]?.Question] == undefined) {
                                multiSingleAns = { ...multiSingleAns, [QuestionList?.current?.[i]?.Question]: { [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade } } }
                            }
                            else {
                                multiSingleAns = { ...multiSingleAns, [QuestionList?.current?.[i]?.Question]: { ...multiSingleAns?.[QuestionList?.current?.[i]?.Question], [e.Option]: { Feedback: e.Feedback, Option: e.Option, Grade: e.Grade } } }
                            }
                        });
                    }

                }
            }
        }
        // attempts count
        // mark collection
        let ScoredMark = 0, TotalMark = 0, SubmitedAll = [];
        for (let i = 0; i < QuestionList?.current?.length; i++) {
            let Options = JSON.parse(QuestionList?.current?.[i]?.Options), Mark = 0;
            if (QuestionList?.current?.[i]?.QuestionType == "MultipleChoice") {
                let inta = 0;
                const currentArray = [];
                const actualAns = [];
                if (QuestionList?.current?.[i]?.ChoiceType == "MultipleAnswer") {
                    Options.map((item, index) => {
                        if (item?.Grade > 0) {
                            actualAns.push({
                                Feedback: item?.Feedback,
                                Option: item?.Option,
                                Grade: item?.Grade
                            });
                        }
                        let temp = multiMultipleAns?.[QuestionList?.current?.[i]?.Question]?.[item?.Option]
                        if (temp?.index != undefined && watch("chkMultipleAnswer" + i + "-" + temp?.index)) {
                            inta += parseInt(temp?.Grade);
                            currentArray = [...currentArray, temp]
                        }
                    })
                    SubmitedAll = [...SubmitedAll, { QuestionId: QuestionList?.current?.[i]?.QuestionID, QuestionType: QuestionList?.current?.[i]?.QuestionType, ChoiceType: QuestionList?.current?.[i]?.ChoiceType, Options: Options, Question: QuestionList?.current?.[i]?.Question, YourAnswer: currentArray, YourMark: ((QuestionList?.current?.[i]?.DefaultMark) * inta) / 100, TotalMark: QuestionList?.current?.[i]?.DefaultMark, ActualAnswer: actualAns, }];
                    Mark = ((QuestionList?.current?.[i]?.DefaultMark) * inta) / 100;

                } else if (QuestionList?.current?.[i]?.ChoiceType == "SingleAnswer") {
                    Options.map((item, index) => {
                        if (item?.Grade > 0) {
                            actualAns.push({
                                Feedback: item?.Feedback,
                                Option: item?.Option,
                                Grade: item?.Grade
                            });
                        }
                        let temp = multiSingleAns?.[QuestionList?.current?.[i]?.Question]?.[item?.Option]
                        if (temp?.index != undefined && watch("SingleAnswer" + i) == item?.Option) {
                            inta += parseInt(temp?.Grade);
                            currentArray = [...currentArray, temp]
                        }
                    })
                    SubmitedAll = [...SubmitedAll, { QuestionId: QuestionList?.current?.[i]?.QuestionID, QuestionType: QuestionList?.current?.[i]?.QuestionType, ChoiceType: QuestionList?.current?.[i]?.ChoiceType, Options: Options, Question: QuestionList?.current?.[i]?.Question, YourAnswer: currentArray, YourMark: ((QuestionList?.current?.[i]?.DefaultMark) * inta) / 100, TotalMark: QuestionList?.current?.[i]?.DefaultMark, ActualAnswer: actualAns }];
                    Mark = ((QuestionList?.current?.[i]?.DefaultMark) * inta) / 100;

                } else if (QuestionList?.current?.[i]?.ChoiceType == "Dropdown") {
                    for (let ib = 0; ib < Options.length; ib++) {
                        if (Options?.[ib]?.Option == watch("multiChoiceSelect" + i)) {
                            inta += parseInt(Options?.[ib]?.Grade);
                            currentArray.push({
                                Feedback: Options?.[ib]?.Feedback,
                                Option: Options?.[ib]?.Option,
                                Grade: Options?.[ib]?.Grade
                            });
                        }
                        if (Options?.[ib]?.Grade > 0) {
                            actualAns.push({
                                Feedback: Options?.[ib]?.Feedback,
                                Option: Options?.[ib]?.Option,
                                Grade: Options?.[ib]?.Grade
                            });
                        }
                    }
                    SubmitedAll = [...SubmitedAll, { QuestionId: QuestionList?.current?.[i]?.QuestionID, QuestionType: QuestionList?.current?.[i]?.QuestionType, ChoiceType: QuestionList?.current?.[i]?.ChoiceType, Options: Options, Question: QuestionList?.current?.[i]?.Question, YourAnswer: currentArray, YourMark: ((QuestionList?.current?.[i]?.DefaultMark) * inta) / 100, TotalMark: QuestionList?.current?.[i]?.DefaultMark, ActualAnswer: actualAns }];
                    Mark = ((QuestionList?.current?.[i]?.DefaultMark) * inta) / 100;

                }

            } else if (QuestionList?.current?.[i]?.QuestionType == "Ordering") {
                let inta = 0;
                for (let ib = 0; ib < Options.length; ib++) {
                    if (Options?.[ib] == watch("OrderingOptions" + i)?.[ib]) {
                        inta = inta + 1;
                    }
                }
                SubmitedAll = [...SubmitedAll, { QuestionId: QuestionList?.current?.[i]?.QuestionID, QuestionType: QuestionList?.current?.[i]?.QuestionType, Question: QuestionList?.current?.[i]?.Question, Options: Options, YourAnswer: watch("OrderingOptions" + i), YourMark: Options.length == inta ? parseInt(QuestionList?.current?.[i]?.DefaultMark) : 0, TotalMark: QuestionList?.current?.[i]?.DefaultMark, ActualAnswer: Options }];
                Mark = Options.length == inta ? parseInt(QuestionList?.current?.[i]?.DefaultMark) : 0;

            } else if (QuestionList?.current?.[i]?.QuestionType == "Match") {
                let inta = 0;

                for (let index = 0; index < watch("MatchTheFollowingCorrectAnswer" + i)?.length; index++) {
                    for (let e = 0; e < watch("MatchingC" + i).length; e++) {
                        if (watch("MatchTheFollowingCorrectAnswer" + i)?.[index]?.key == watch("MatchingC" + i)?.[e]?.key
                            && watch("MatchTheFollowingCorrectAnswer" + i)?.[index]?.value == watch("MatchingC" + i)?.[e]?.value) {
                            inta += 1;
                        }
                    }
                }

                SubmitedAll = [...SubmitedAll, { QuestionId: QuestionList?.current?.[i]?.QuestionID, QuestionType: QuestionList?.current?.[i]?.QuestionType, Question: QuestionList?.current?.[i]?.Question, Options: JSON.parse(QuizData?.QuizQuestions?.[i]?.Options), YourAnswer: watch("MatchingC" + i), YourMark: watch("MatchTheFollowingCorrectAnswer" + i)?.length == inta ? parseInt(QuestionList?.current?.[i]?.DefaultMark) : 0, TotalMark: parseInt(QuestionList?.current?.[i]?.DefaultMark), ActualAnswer: watch("MatchTheFollowingCorrectAnswer" + i) }];
                Mark = watch("MatchTheFollowingCorrectAnswer" + i)?.length == inta ? parseInt(QuestionList?.current?.[i]?.DefaultMark) : 0;

            } else if (QuestionList?.current?.[i]?.QuestionType == "Description") {
                let inta = 0;
                const temp = JSON.parse(QuestionList?.current?.[i]?.Options != undefined ? QuestionList?.current?.[i]?.Options : "[]");
                temp.map((item) => {
                    if ((watch("txtQuestionForQuiz" + i)?.toLowerCase())?.indexOf(item.Option?.toLowerCase()) != -1) {
                        inta += parseInt(item?.Grade) / 100 * parseInt(QuestionList?.current?.[i]?.DefaultMark);
                    }
                })
                SubmitedAll = [...SubmitedAll, { QuestionId: QuestionList?.current?.[i]?.QuestionID, QuestionType: QuestionList?.current?.[i]?.QuestionType, Question: QuestionList?.current?.[i]?.Question, Options: Options, YourAnswer: watch("txtQuestionForQuiz" + i), YourMark: inta, TotalMark: QuestionList?.current?.[i]?.DefaultMark, ActualAnswer: Options }];
                Mark = inta;

            }
            else if (QuestionList?.current?.[i]?.QuestionType == "FillInTheBlank") {
                let inta = 0;
                const correctAns = [];
                const UAnswer = [];
                for (let o = 0; o < (FillUps?.current?.["FillInTheBlank" + i] ? Object.keys(FillUps?.current?.["FillInTheBlank" + i]) : 0).length; o++) {
                    if (FillUps?.current?.["FillInTheBlank" + i]?.[o] == watch("FillInTheBlank" + i + "-" + o)) {
                        inta += 1;
                    }
                    correctAns.push(FillUps?.current?.["FillInTheBlank" + i]?.[o]);
                    UAnswer.push(watch("FillInTheBlank" + i + "-" + o));
                }
                SubmitedAll = [...SubmitedAll, { QuestionId: QuestionList?.current?.[i]?.QuestionID, QuestionType: QuestionList?.current?.[i]?.QuestionType, Question: QuestionList?.current?.[i]?.Question, Options: Options, YourAnswer: UAnswer, YourMark: (FillUps?.current?.["FillInTheBlank" + i] ? Object.keys(FillUps?.current?.["FillInTheBlank" + i]) : 0).length == inta ? parseInt(QuestionList?.current?.[i]?.DefaultMark) : 0, TotalMark: QuestionList?.current?.[i]?.DefaultMark, ActualAnswer: correctAns }];
                Mark = (FillUps?.current?.["FillInTheBlank" + i] ? Object.keys(FillUps?.current?.["FillInTheBlank" + i]) : 0).length == inta ? parseInt(QuestionList?.current?.[i]?.DefaultMark) : 0;
            }
            TotalMark = TotalMark + parseInt(QuestionList?.current?.[i]?.DefaultMark);
            ScoredMark = ScoredMark + Mark;
        }
        let Status;
        let QuizStatus = "";
        let CurrentPercentageScore = ScoredMark * 100 / TotalMark 
        const coursewiseQuiz = QuizData?.ShardActivityData?.CourseID != undefined ? JSON.parse(QuizData?.CourseEnrollData?.QuestionandOptions != undefined ? QuizData?.CourseEnrollData?.QuestionandOptions : "{}"):{};
        const activitywiseQuiz= QuizData?.ShardActivityData?.CourseID != undefined ? {} : JSON.parse( QuizData?.ActivityData?.["QuizCompletion"]);
        const previousData = QuizData?.ShardActivityData?.CourseID != undefined ? coursewiseQuiz?.[activityID]?.["Answer"]?.["PreviousAttempts"] :  activitywiseQuiz?.["PreviousAttempts"]

        let MarkArray = [], AverageScore = 0;
        previousData && previousData.map((data) => {
            MarkArray.push(data?.GradePercentage)
            AverageScore += parseInt(data?.ScoredMark)
        })
        MarkArray.push(CurrentPercentageScore)
        AverageScore += parseInt(ScoredMark)

        let PercentageScoreMark = 0
        if (QuizData?.ShardActivityData?.GradingMethod == "Highest Grade") {
            PercentageScoreMark = Math.max(...MarkArray);
        } else if (QuizData?.ShardActivityData?.GradingMethod == "First Attempt") {
            PercentageScoreMark = MarkArray[0]
        } else if (QuizData?.ShardActivityData?.GradingMethod == "Last Attempt") {
            PercentageScoreMark = MarkArray[MarkArray?.length - 1]
        } else if (QuizData?.ShardActivityData?.GradingMethod == "Average Grade") {
            PercentageScoreMark = (((AverageScore/ MarkArray?.length) / TotalMark) * 100) .toFixed(2)?.replaceAll(".00", "")
        } else {
            PercentageScoreMark = ScoredMark * 100 / TotalMark
        }
    
        if (QuizData?.ShardActivityData?.PassingGrade && PercentageScoreMark >= parseFloat(QuizData?.ShardActivityData?.PassingGrade)) {
            QuizStatus = "Pass";
        }
        else {
            QuizStatus = "Fail";
        }
        if (QuizData?.ShardActivityData?.CourseID != undefined) {
            let temp = QuizData?.CourseEnrollData?.CompletionStatus;
            const QuizTakenCount = JSON.parse(QuizData?.CourseEnrollData?.QuestionandOptions)?.[activityID]?.["QuizTakenCount"] == undefined ? "1" : parseInt(JSON.parse(QuizData?.CourseEnrollData?.QuestionandOptions)?.[activityID]?.["QuizTakenCount"]) + 1;
            if (QuizData?.ShardActivityData?.IsRequirePassingGrade && QuizStatus == "Pass") {
                Status = "100";
            }
            else if (QuizData?.ShardActivityData?.IsRequirePassingGrade && (QuizStatus == "Pass" || parseInt(QuizTakenCount) == parseInt(QuizData?.ShardActivityData.MaximumAttempt))) {
                Status = "100";
            }
            if (QuizData?.ShardActivityData?.IsCompleteTheActivity && QuizStatus == "Pass") {
                  Status = "100";
              }
            const tempStatus = JSON.parse(temp != undefined ? temp : "{}");
            let progress = 0, OldProgress = tempStatus?.progress;
            if (tempStatus?.[activityID]?.CompletedStatus != "100" && Status != undefined) {
                if (temp != undefined) {
                    temp = { ...tempStatus, [activityID]: { CompletionStatus: Status, CompletionDate: new Date() } };
                }
                else {
                    temp = { [activityID]: { CompletionStatus: Status, CompletionDate: new Date() } };
                }
                if (Status == "100") {
                    const restriction = Object.values(JSON.parse(QuizData?.CourseEnrollData?.Restriction != undefined ? QuizData?.CourseEnrollData?.Restriction : "{}"));
                    const length = restriction[0]?.flow?.must?.length != undefined ? restriction[0]?.flow?.must?.length : 1;
                    const CompletedAct = temp?.CompletedActivity != undefined ? temp?.CompletedActivity : 0, CompletedModuleAct = temp?.[ModuleId]?.CompletedActivity != undefined ? temp?.[ModuleId]?.CompletedActivity : 0;
                    temp = { ...temp, [ModuleId]: { progress: Math.min(100, parseInt((CompletedModuleAct + 1) * 100 / ModuleLength)), CompletionDate: new Date(), CompletedActivity: CompletedModuleAct + 1 }, progress: Math.min(100, parseInt((CompletedAct + 1) * 100 / length)), CompletedActivity: CompletedAct + 1, [activityID]: { ...temp?.[activityID], CompletionDate: new Date() }, CompletionDate: new Date() }
                    progress = ((CompletedAct + 1) * 100 / length);
                }
                temp = JSON.stringify(temp);
            }
            const tempQuizData = JSON.parse(QuizData?.CourseEnrollData?.QuestionandOptions != undefined ? QuizData?.CourseEnrollData?.QuestionandOptions : "{}");
            const previousAttemptsScore = tempQuizData?.[activityID]?.["Answer"]?.["PreviousAttempts"] ? tempQuizData?.[activityID]?.["Answer"]?.["PreviousAttempts"] : []
            previousAttemptsScore.push({Attempt:QuizTakenCount.toString(),ScoredMark:ScoredMark,GradePercentage:CurrentPercentageScore.toFixed(2)?.replaceAll(".00", "")})
            
            let answer = { [QuizTakenCount.toString()]: SubmitedAll,
                ["PreviousAttempts"]:previousAttemptsScore,
                ["QuizStartTime"] : new Date(quizStartTime.current),
                ["QuizEndTime"] : new Date()};
           
            // if (tempQuizData?.[activityID] != undefined) {
            //     const tempanswer = tempQuizData?.[activityID]?.["Answer"];
            //     answer = { ...tempanswer, [QuizTakenCount.toString()]: SubmitedAll };
            // }
            const ActivityCompletedStatus = {
                PK: QuizData?.CourseEnrollData?.PK, 
                SK: QuizData?.CourseEnrollData?.SK,
                QuestionandOptions: JSON.stringify({
                    ...JSON.parse(QuizData?.CourseEnrollData?.QuestionandOptions != undefined ? QuizData?.CourseEnrollData?.QuestionandOptions : "{}"), 
                     [activityID]: {
                        ["Answer"]: answer, ["QuizCompletionDate"]: new Date()
                        , ["QuizTakenCount"]: QuizTakenCount,
                        ["ScoredMark"]: ScoredMark,
                        ["QuizStatus"]: QuizStatus,
                        ["GradePercentage"]:CurrentPercentageScore.toFixed(2)?.replaceAll(".00", "")
                    }
                }),
                CompletionStatus: temp
            };

            const FinalStatus = (await AppsyncDBconnection(updateXlmsCourseEnrollUser, { input: ActivityCompletedStatus }, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
          
        

            if (progress == 100 && OldProgress != 100) {
                GenerateCertificate();
            }
            if (FinalStatus != "Success") {
                setModalValues({
                    ModalInfo: "Danger",
                    ModalTopMessage: "Error",
                    ModalBottomMessage: FinalStatus,
                });
                ModalOpen();
                return;
            } else {
                setModalValues({
                    ModalInfo: "Success",
                    ModalOnClickEvent: () => {
                        router.push(`/MyLearning/CourseConsume?CourseID=${QuizData?.CourseEnrollData?.CourseID}&BatchId=${QuizData?.CourseEnrollData?.BatchID}&ActivityID=${activityID}`);
                    },
                });
                ModalOpen();
            }

        }
        else {
            const QuizTakenCount = (QuizData?.ActivityData?.QuizTakenCount == "" || QuizData?.ActivityData?.QuizTakenCount == null || QuizData?.ActivityData?.QuizTakenCount == undefined) ? 1 : parseInt(QuizData?.ActivityData?.QuizTakenCount) + 1;
            let PreviousQuizCompletion;
            try{
                PreviousQuizCompletion=JSON.parse( QuizData?.ActivityData?.["QuizCompletion"]);
            }
            catch(e){
                PreviousQuizCompletion={};
            }
            const previousAttemptsScore = PreviousQuizCompletion?.["PreviousAttempts"] ? PreviousQuizCompletion?.["PreviousAttempts"] : []
            previousAttemptsScore.push({Attempt:QuizTakenCount.toString(),ScoredMark:ScoredMark,GradePercentage:CurrentPercentageScore.toFixed(2)?.replaceAll(".00", "")})
            let QuizCompletion = { [QuizTakenCount.toString()]: SubmitedAll, 
                ["PreviousAttempts"]:previousAttemptsScore,
                ["QuizStartTime"] : new Date(quizStartTime.current),
                ["QuizEndTime"] : new Date() };
            
            // if (QuizData?.ActivityData?.QuizCompletion != undefined) {
            //     const temp = JSON.parse(QuizData?.ActivityData?.QuizCompletion);
            //     QuizCompletion = { ...temp, [QuizTakenCount.toString()]: SubmitedAll };
            // }
           
            let ActivityCompletedStatus = {
                PK: QuizData?.ActivityData?.PK,
                SK: QuizData?.ActivityData?.SK,
                QuizCompletion: JSON.stringify(QuizCompletion),
                QuizCompletionDate: new Date(),
                LastModifiedDate: new Date(),
                QuizTakenCount: QuizTakenCount,
                ScoredMark: ScoredMark,
                QuizStatus: QuizStatus
            };
            if (QuizData?.ShardActivityData?.IsRequirePassingGrade && QuizStatus == "Pass") {
                ActivityCompletedStatus = { ...ActivityCompletedStatus, CompletedStatus: "100" };
            }
            else if (QuizData?.ShardActivityData?.IsRequirePassingGrade && (QuizStatus == "Pass" || parseInt(QuizTakenCount) == parseInt(QuizData?.ShardActivityData?.MaximumAttempt))) {
                ActivityCompletedStatus = { ...ActivityCompletedStatus, CompletedStatus: "100" };
            }
            const FinalStatus = (await AppsyncDBconnection(updateXlmsEnrollUser, { input: ActivityCompletedStatus }, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
            if (ActivityCompletedStatus?.CompletedStatus == "100" && QuizData?.ActivityData?.CompletedStatus != "100") {
                GenerateCertificate();
            }
            if (FinalStatus != "Success") {
                setModalValues({
                    ModalInfo: "Danger",
                    ModalTopMessage: "Error",
                    ModalBottomMessage: FinalStatus,
                });
                ModalOpen();
                return;
            } else {
                setModalValues({
                    ModalInfo: "Success",
                    ModalOnClickEvent: () => {
                        router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${activityID}&ActivityType=Quiz`);
                    },
                });
                ModalOpen();
            }
        }
    }, [activityID, watch, props?.user?.signInUserSession?.accessToken?.jwtToken, ModuleId, ModuleLength, GenerateCertificate, router]);

    const GenerateCertificate = useCallback(async () => {
        if (props?.TenantInfo?.TenantID == undefined) {
            return;
        }
        if (CourseId != "") {
            AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSEBADGE#" + CourseId }, props?.user.signInUserSession.accessToken.jwtToken).then((data) => {
                if (data?.res?.getXlmsCourseManagementInfo != undefined) {
                    const variables = {
                        input: {
                            PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + props?.user?.attributes?.["sub"],
                            SK: "BADGE#" + CourseId,
                            CertificateImagePath: data?.res?.getXlmsCourseManagementInfo?.BadgeUploadFile,
                            BadgeName: data?.res?.getXlmsCourseManagementInfo?.BadgeName,
                            IsAvailable: true
                        }
                    };
                    AppsyncDBconnection(createXlmsUserCertificateInfo, variables, props?.user.signInUserSession.accessToken.jwtToken);
                }
            });
            AppsyncDBconnection(getXlmsCourseManagementInfo, { PK: "TENANT#" + props?.TenantInfo?.TenantID, SK: "COURSECERTIFICATE#" + CourseId }, props?.user.signInUserSession.accessToken.jwtToken).then((data) => {
                if (data?.res?.getXlmsCourseManagementInfo != undefined && props?.CourseEnrollData?.CertificatePath == undefined) {
                    const fetchURL = `${process.env.APIGATEWAY_URL_SCORMFILEUPlOAD}?S3BucketName=${props?.TenantInfo?.BucketName}&S3KeyName=${props?.TenantInfo?.RootFolder}`;
                    const statemachinearn = process.env.STEP_FUNCTION_ARN_CERTIFICATE_GENERATION;
                    const json = {
                        "TenantID": props?.TenantInfo?.TenantID,
                        "UserSub": props?.user.attributes["sub"],
                        "CourseID": CourseId,
                        "BatchID": BatchId,
                        "ActivityType": "",
                        "ActivityID": ""
                    };
                    const headers = {
                        method: "POST",
                        headers: {
                            authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
                            defaultrole: props?.TenantInfo?.UserGroup,
                            groupmenuname: "ActivityManagement",
                            menuid: "500013",
                            statemachinearn: statemachinearn
                        },
                        body: JSON.stringify(json),
                    };
                    APIGatewayPostRequest(fetchURL, headers);
                }
            });
        }
        else {
            AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + props.TenantInfo.TenantID, SK: "ACTIVITYTYPE#Quiz#ACTIVITYID#" + activityID },
                props?.user.signInUserSession.accessToken.jwtToken).then((data) => {
                    if (data?.res?.getXlmsActivityManagementInfo?.BadgeUploadFile != undefined) {
                        const variables = {
                            input: {
                                PK: "TENANT#" + props?.TenantInfo?.TenantID + "#USERSUB#" + props?.user?.attributes?.["sub"],
                                SK: "BADGE#" + activityID,
                                CertificateImagePath: data?.res?.getXlmsActivityManagementInfo?.BadgeUploadFile,
                                BadgeName: data?.res?.getXlmsActivityManagementInfo?.BadgeName,
                                IsAvailable: true
                            }
                        };
                        AppsyncDBconnection(createXlmsUserCertificateInfo, variables, props?.user.signInUserSession.accessToken.jwtToken);
                    }
                    if (data?.res?.getXlmsActivityManagementInfo?.CertificateTemplate != undefined && props?.EnrollData?.CertificatePath == undefined) {
                        const fetchURL = `${process.env.APIGATEWAY_URL_SCORMFILEUPlOAD}?S3BucketName=${props?.TenantInfo?.BucketName}&S3KeyName=${props?.TenantInfo?.RootFolder}`;
                        const statemachinearn = process.env.STEP_FUNCTION_ARN_CERTIFICATE_GENERATION;
                        const json = {
                            "TenantID": props?.TenantInfo?.TenantID,
                            "UserSub": props?.user.attributes["sub"],
                            "CourseID": "",
                            "BatchID": "",
                            "ActivityType": "Quiz",
                            "ActivityID": activityID
                        };
                        const headers = {
                            method: "POST",
                            headers: {
                                authorizationtoken: props?.user.signInUserSession.accessToken.jwtToken,
                                defaultrole: props?.TenantInfo?.UserGroup,
                                groupmenuname: "ActivityManagement",
                                menuid: "500013",
                                statemachinearn: statemachinearn
                            },
                            body: JSON.stringify(json),

                        };
                        APIGatewayPostRequest(fetchURL, headers);
                    }
                });
        }
    }, [props.TenantInfo.TenantID, props.TenantInfo?.BucketName, props.TenantInfo?.RootFolder, props.TenantInfo?.UserGroup, props?.user.signInUserSession.accessToken.jwtToken, props?.user.attributes, props?.CourseEnrollData?.CertificatePath, props?.EnrollData?.CertificatePath, CourseId, BatchId, activityID]);

    // drag and drop functionality
    const handleSort = useCallback(async (QuesAns, oldposition, OrderingOfIndex, Type, MatchType) => {
        if (Type == "Ordering") {
            const Orderdata = watch("OrderingOptions" + OrderingOfIndex);
            const b = [];
            if (dragOverItem.current != oldposition) {
                for (let i = 0; i < Orderdata.length; i++) {
                    if (dragOverItem.current == i) {
                        dragOverItem.current > oldposition ? b.push(Orderdata[i]) : b.push(Orderdata[oldposition]);
                        dragOverItem.current > oldposition ? b.push(Orderdata[oldposition]) : b.push(Orderdata[i]);
                    } else if (oldposition != i) {
                        b.push(Orderdata[i]);
                    }
                }
            } else {
                for (let i = 0; i < Orderdata.length; i++) {
                    b.push(Orderdata[i]);
                }
            }
            setValue("OrderingOptions" + OrderingOfIndex, b);
        } else if (Type == "Match") {
            const Matchdata = watch(MatchType + OrderingOfIndex);
            const c = [];
            if (dragOverItem.current != oldposition) {
                for (let i = 0; i < Matchdata.length; i++) {
                    if (dragOverItem.current == i) {
                        dragOverItem.current > oldposition ? c.push(Matchdata[i]) : c.push(Matchdata[oldposition]);
                        dragOverItem.current > oldposition ? c.push(Matchdata[oldposition]) : c.push(Matchdata[i]);
                    } else if (oldposition != i) {
                        c.push(Matchdata[i]);
                    }
                }
            } else {
                for (let i = 0; i < Matchdata.length; i++) {
                    c.push(Matchdata[i]);
                }
            }
            setValue(MatchType + OrderingOfIndex, c);

            // Match The Following Final Structure

            const n = [];
            for (let i = 0; i < watch("MatchingC" + OrderingOfIndex).length; i++) {
                n.push({ key: watch("MatchingA" + OrderingOfIndex)?.[i], value: watch("MatchingB" + OrderingOfIndex)?.[i] });
            }
            setValue("MatchingC" + OrderingOfIndex, n);
        }
    }, [setValue, watch]);

    const BeforeNextAndPrevAction = useCallback((e) => {
        if (!QuizData?.ShardActivityData?.IsMoveToPreviousAndNextQuestion) {
            let AreYouSure = false;
            if (QuestionList?.current?.[watch("currentIndex")]?.QuestionType == "MultipleChoice") {
                if (QuestionList?.current?.[watch("currentIndex")]?.ChoiceType == "MultipleAnswer") {
                    JSON.parse(QuestionList?.current?.[watch("currentIndex")]?.Options).map((QestinOption, indexOf) => {
                        if (watch("chkMultipleAnswer" + watch("currentIndex") + "-" + indexOf)) {
                            AreYouSure = true;
                        }
                    });
                }
                else if (QuestionList?.current?.[watch("currentIndex")]?.ChoiceType == "SingleAnswer") {
                    JSON.parse(QuestionList?.current?.[watch("currentIndex")]?.Options).map(() => {
                        if (watch("SingleAnswer" + watch("currentIndex"))) {
                            AreYouSure = true;
                        }
                    });
                }
                else if (QuestionList?.current?.[watch("currentIndex")]?.ChoiceType == "Dropdown") {
                    if (watch("multiChoiceSelect" + watch("currentIndex"))) {
                        AreYouSure = true;
                    }
                }
            }
            else if (QuestionList?.current?.[watch("currentIndex")]?.QuestionType == "Description") {
                if (watch("txtQuestionForQuiz" + watch("currentIndex"))) {
                    AreYouSure = true;
                }
            } else {
                AreYouSure = true;
            }
            if (AreYouSure) {
                NextAndPrevAction(e);
            }
            else {
                setPopupValues("Are you sure to move next question without answer?");
            }
        } else {
            NextAndPrevAction(e);
        }
    }, [NextAndPrevAction, QuestionList, QuizData?.ShardActivityData?.IsMoveToPreviousAndNextQuestion, watch]);

    const NextAndPrevAction = useCallback(async (e) => {
        resetCount.current = resetCount.current + 1;
        if (e == "nextQuestion") {
            setValue("currentIndex", watch("currentIndex") + 1);
        } else if (e == "prevQuestion") {
            setValue("currentIndex", watch("currentIndex") - 1);
        } else {
            setValue("currentIndex", e);
        }
    }, [setValue, watch]);
    const QuizTypesOfFiles = useCallback(({ QuestionList, errors, handleSort, register, shuffle, watch }) => {
        const getQuestion = QuestionList?.current?.[watch("currentIndex")];
        const index = watch("currentIndex");
        let options = [];
        if (getQuestion?.QuestionType == "MultipleChoice") {
            if (getQuestion?.ChoiceType != "Dropdown") {
                options = (QuizData?.ShardActivityData?.IsShuffleWithInChoice || getQuestion?.IsShuffleWithInChoice) ? shuffle(JSON.parse(getQuestion.Options)) : JSON.parse(getQuestion.Options);

                // multiplechoice shuffle
                if (VisitedQuestions.current?.["Question" + index]?.["Option"] == undefined) {
                    VisitedQuestions.current = { ...VisitedQuestions.current, ["Question" + index]: { ...getQuestion, ["Option"]: options } };
                }
                else {
                    options = VisitedQuestions.current?.["Question" + index]?.["Option"];
                }
            }

            else if (getQuestion?.ChoiceType == "Dropdown") {
                options.push({ value: "", text: "Select" });
                const v = (QuizData?.ShardActivityData?.IsShuffleWithInChoice || getQuestion?.IsShuffleWithInChoice) ? shuffle(JSON.parse(getQuestion.Options)) : JSON.parse(getQuestion.Options);
                v.map((Items) => {
                    options.push({ value: Items?.Option, text: Items?.Option });
                });

                // dropdown shuffle
                if (VisitedQuestions.current?.["Question" + index]?.["Option"] == undefined) {
                    VisitedQuestions.current = { ...VisitedQuestions.current, ["Question" + index]: { ...getQuestion, ["Option"]: options } };
                }
                else {
                    options = VisitedQuestions.current?.["Question" + index]?.["Option"];
                }
            }
            else {
                VisitedQuestions.current = { ...VisitedQuestions.current, ["Question" + index]: getQuestion };
            }
        }
        else {
            VisitedQuestions.current = { ...VisitedQuestions.current, ["Question" + index]: getQuestion };
        }
        return (<MultipleAnswerCompoent getQuestion={getQuestion} index={index} options={options} errors={errors} register={register} watch={watch} QuestionType={getQuestion?.QuestionType} handleSort={handleSort} dragItem={dragItem} dragOverItem={dragOverItem} BindFillups={BindFillups} shuffle={shuffle} />);
    }, [BindFillups, QuizData?.ShardActivityData?.IsShuffleWithInChoice]);
    return (
        <>
            <Container title="QuestionList" loader={QuizData?.QuizQuestions == undefined}>
                {QuizData?.CourseEnrollData && Object.entries(QuizData?.CourseEnrollData).length == 0 && <NVLWebWorker props={{ ...props, ...QuizData }} />}
                <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
               {QuestionList?.current && QuestionList?.current?.length <= 0 ?  <NVLModalPopup ButtonYestext="Yes" IsConfirmAlert={true} 
                    SubmitClick={() => {CourseId != "" ? router.push(`/MyLearning/CourseConsume?CourseID=${QuizData?.CourseEnrollData?.CourseID}&BatchId=${QuizData?.CourseEnrollData?.BatchID}&ActivityID=${activityID}`) : router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${activityID}&ActivityType=Quiz`); }} 
                   CloseIconEvent={() =>{CourseId != "" ? router.push(`/MyLearning/CourseConsume?CourseID=${QuizData?.CourseEnrollData?.CourseID}&BatchId=${QuizData?.CourseEnrollData?.BatchID}&ActivityID=${activityID}`) : router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${activityID}&ActivityType=Quiz`); }}  
                   Content={"No questions available in this quiz. Kindly contact administrator for further details."} />
                : <NVLModalPopup
                    ButtonYestext="Yes"
                    SubmitClick={() => {
                        NextAndPrevAction("nextQuestion");
                        setPopupValues("");
                    }}
                    CancelClick={() => setPopupValues("")}
                    ButtonNotext="No"
                    CloseIconEvent={() => setPopupValues("")}
                    Content={popupValues}
                />}

         {attemptRestrict && <div className={`break-words h- flex shadow-md gap-6 rounded overflow-hidden divide-x max-w-2xl bg-amber-200 `}>
              <div className="flex flex-1 flex-col p-2 dark:border-violet-400">
                <span className="text-xs dark:text-white flex items-center gap-4 p-2">
                  <i className="fa fa-info-circle" aria-hidden="true"></i>
                  <div>
                     Attempts are not allowed.
                  </div>
                </span>
              </div>
            </div>}
                <form onSubmit={handleSubmit(() => onSubmit(QuizData, QuestionList))}>
                    <div className="grid grid-flow-row-dense grid-cols-12 border rounded">
                        <div className="col-span-8">
                            <div className="grid gap-2 mx-4 my-4 md:order-last text-xs bg-sky-100 p-4">
                                <div className='flex justify-end'>
                                    <QuizTimer QuizData={QuizData} resetCount={resetCount.current} NextAndPrevAction={NextAndPrevAction} watch={watch} QuizSubmitData={QuizSubmitData} router={router} />
                                </div>
                                {QuestionList != undefined && <QuizTypesOfFiles QuestionList={QuestionList} errors={errors} handleSort={handleSort} props={props} register={register} shuffle={shuffle} watch={watch} />}
                            </div>
                        </div>
                        <div className="col-span-4 bg-gray-100">
                            <div className=" grid text-xs p-4">
                                <div className="bg-gray-400 p-1 flex gap-4">
                                    <i className="fa-regular fa-map-pin my-auto text-green-700 font-semibold"></i>{" "}
                                    Quiz Navigation
                                </div>
                                <div className={`bg-gray-200 p-4 gap-4  grid grid-cols-5 shadow `}>
                                    {QuestionList?.current?.map((getQuestion, index) => {
                                        let IS = Object.keys(VisitedQuestions?.current);
                                        return (
                                            <Fragment key={crypto.randomUUID()}>
                                                <div>
                                                    <span className={`${IS.includes("Question" + index) || index == watch("currentIndex") ? "bg-gray-400" : "bg-white"} cursor-pointer h-8 w-6  border border-primary shadow-xl rounded flex justify-center items-center`} onClick={() => {
                                                        !QuizData?.ShardActivityData?.IsSetTime && QuizData?.ShardActivityData?.IsMoveToPreviousAndNextQuestion && setValue("currentIndex", index);
                                                    }}>
                                                        {index + 1}
                                                    </span>
                                                </div>
                                            </Fragment>
                                        );
                                    })}
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="inline-flex mt-2 xs:mt-0 text-xs">
                        {!QuizData?.ShardActivityData?.IsSetTime &&
                            QuizData?.ShardActivityData?.IsMoveToPreviousAndNextQuestion &&
                            (<>
                                <label onClick={() => BeforeNextAndPrevAction("prevQuestion")} className={`${(watch("currentIndex") == 0 ? "hidden" : "")} inline-flex items-center px-4 py-2 text-white bg-gray-800 rounded-l hover:bg-gray-900 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white gap-2`}>
                                    <i className="fa-solid fa-left-long "></i>  Prev
                                </label>
                            </>)}
                        {!QuizData?.ShardActivityData?.IsSetTime && (<>
                            <label onClick={() => BeforeNextAndPrevAction("nextQuestion")} className={`${(watch("currentIndex") + 1 == QuestionList?.current?.length ? "hidden" : "")} inline-flex items-center px-4 py-2  text-white bg-gray-800 border-0 border-l border-gray-700 rounded-r hover:bg-gray-900 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white gap-2`}>
                                Next
                                <i className="fa-solid fa-right-long "></i>
                            </label>
                        </>)}
                        <button className={` ${(watch("currentIndex") + 1 == QuestionList?.current?.length ? "" : "hidden")} inline-flex items-center px-4 py-2  text-white bg-gray-800 border-0 border-l border-gray-700 rounded-r hover:bg-gray-900 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white gap-2`}>
                            Submit
                            <i className="fa-solid fa-right-long "></i>
                        </button>
                    </div>
                </form>
            </Container>
        </>
    );
}

