import Container from "@components/Container/Container";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";

import { useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function ConsumePage({ props, LanguageType, MarkAsCompleted, AppSyncDbConnectionModule }) {
    const [isLoad, setIsLoad] = useState(false);

    const ref = useRef("");
    const validationSchema = Yup.object().shape({
        markTheActivity: Yup.bool().test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
        ddlUserConsume: Yup.string().required("Choose a activity")
            .test("", "", async (e) => {
                setIsLoad(true);
                const temp1 = JSON.parse(props?.ActivityData?.AttachFiles).filter((x) => x.Language == e);
                const contentsPromise = await fetch(
                    process.env.APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE + "?ObjectUrl=" + temp1[0].FilePath + "&S3BucketName=" + props.TenantInfo?.BucketName +
                    "&S3KeyName=" + props.TenantInfo?.RootFolder + "/" +
                    props.TenantInfo?.TenantID,
                    {
                        method: "GET",
                        headers: {
                            "Content-Type": "application/text",
                            authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                            defaultrole: props.TenantInfo.UserGroup,
                            groupmenuname: "SiteConfiguration",
                            menuid: "601302"
                        },
                    }
                );
                const temp = await contentsPromise.text();
                if (temp1.length > 0 && ref.current != null) {
                    ref.current.innerHTML = temp;
                    setIsLoad(false);

                }
            }),
    });
    useEffect(() => {
        const bindfunction = async () => {
            setIsLoad(true);
            try {
                if (props.TenantInfo?.TenantID != undefined) {
                    const temp1 = JSON.parse(props?.ActivityData?.AttachFiles);
                    const contentsPromise = await fetch(
                        process.env.APIGATEWAY_URL_READ_CUSTOM_CERTIFICATE + "?ObjectUrl=" + temp1[0]?.FilePath + "&S3BucketName=" + props.TenantInfo?.BucketName +
                        "&S3KeyName=" + props.TenantInfo?.RootFolder + "/" +
                        props.TenantInfo?.TenantID,
                        {
                            method: "GET",
                            headers: {
                                "Content-Type": "application/text",
                                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                                defaultrole: props.TenantInfo.UserGroup,
                                groupmenuname: "SiteConfiguration",
                                menuid: "601302"
                            },
                        }
                    );
                    const temp = await contentsPromise.text();

                    if (temp1.length > 0 && ref.current != null) {
                        setIsLoad(false);
                        ref.current.innerHTML = temp;
                    }
                }
            } catch (error) {
                return error;
            }
        };
        bindfunction();
    }, [props?.ActivityData?.AttachFiles, props.TenantInfo?.BucketName, props.TenantInfo?.RootFolder, props.TenantInfo?.TenantID, props.TenantInfo.UserGroup, props.user.signInUserSession.accessToken.jwtToken]);
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    return (
        <>
        <Container loader={isLoad}>
            <div className="flex justify-between flex-wrap break-all">
                {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                <div className="grid items-center">
                    <NVLSelectField id={"ddlUserConsume"} className="w-48 py-2" options={LanguageType} errors={errors} register={register} />
                </div>
            </div>            
            </Container>
            <div className="ql-editor min-h-[450px] " ref={ref} />
            <MarkAsCompleted watch={watch} errors={errors} register={register} />
        </>
    );
}
export default ConsumePage;
