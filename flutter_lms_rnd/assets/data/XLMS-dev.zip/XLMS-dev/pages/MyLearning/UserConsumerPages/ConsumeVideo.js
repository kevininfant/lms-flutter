import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { useCallback, useEffect, useMemo, useRef } from "react";
import { useForm } from "react-hook-form";
import ReactPlayer from "react-player";
import * as Yup from "yup";

function ConsumeVideo({ props, LanguageType, MarkAsCompleted, AppSyncDbConnectionModule, }) {
    const progress = useRef({ Duration: 0, CurrentLanguage: "" });
    const playerRef = useRef();

    const getURLValues = useMemo(() => {
        let getURLValues, temp = {};
        if (props?.ActivityData?.InformationType == "File") {
            getURLValues = JSON.parse(props?.ActivityData?.PasteURL != undefined ? props?.ActivityData?.PasteURL : "[]");
            getURLValues.map((item) => {
                temp = { ...temp, [item?.Language]: item?.Device?.["Web/android"] }
            });
        } else if (props?.ActivityData?.InformationType == "URL") {
            getURLValues = JSON.parse(props?.ActivityData?.AttachFiles != undefined ? props?.ActivityData?.AttachFiles : "[]");
            getURLValues.map((item) => {
                temp = { ...temp, [item?.Language]: item?.TextURL }
            });
        }
        return temp;
    }, [props?.ActivityData?.AttachFiles, props?.ActivityData?.InformationType, props?.ActivityData?.PasteURL]);

    const onReady = useCallback(() => {
        let tempProgress = 0;
        if (props?.EnrollCourseData != undefined) {
            let temp = JSON.parse(props.EnrollCourseData?.PasteURL != undefined ? props.EnrollCourseData?.PasteURL : "{}");
            if (temp?.[props.ActivityData?.ActivityID] != undefined) {
                if (temp?.[props.ActivityData?.ActivityID]?.lang == progress?.current?.CurrentLanguage) {
                    tempProgress = temp?.[props.ActivityData?.ActivityID]?.CompletionStatus
                }
                else {
                    tempProgress = 0;
                }
            }
        }
        else if (props?.EnrollData != undefined) {
            let temp = JSON.parse(props?.EnrollData?.PasteURL != undefined ? props?.EnrollData?.PasteURL : "{}");
            if (temp?.[props.ActivityData?.ActivityID] != undefined) {
                if (temp?.[props.ActivityData?.ActivityID]?.lang == progress?.current?.CurrentLanguage) {
                    tempProgress = temp?.[props.ActivityData?.ActivityID]?.CompletionStatus
                }
                else {
                    tempProgress = 0;
                }
            }

        }
        else {
            tempProgress = 0;
        }
        playerRef?.current?.seekTo(tempProgress, "seconds");
    }, [props.ActivityData?.ActivityID, props.EnrollCourseData, props?.EnrollData]);

    const validationSchema = Yup.object().shape({
        ddlUserConsume: Yup.string().test("novalid", "Progress", e => {
            if (e != progress?.current?.CurrentLanguage) {
                progress.current = { ...progress?.current, CurrentLanguage: e };
                playerRef?.current?.seekTo(0, "seconds");
            }
            return true;
        }),
        markTheActivity: Yup.bool().test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false };
    const { register, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        let temp = [], progress = JSON.parse(props?.EnrollCourseData?.PasteURL != undefined ? props?.EnrollCourseData?.PasteURL : "[]")?.[props?.ActivityData?.ActivityID];
        if (props?.EnrollCourseData == undefined && props?.EnrollData != undefined) {
            progress = JSON.parse(props?.EnrollData?.PasteURL != undefined ? props?.EnrollData?.PasteURL : "[]")?.[props?.ActivityData?.ActivityID];
        }
        if (props?.ActivityData?.InformationType == "File") {
            temp = JSON.parse(props?.ActivityData?.PasteURL != undefined ? props?.ActivityData?.PasteURL : "[]");
        } else if (props?.ActivityData?.InformationType == "URL") {
            temp = JSON.parse(props?.ActivityData?.AttachFiles != undefined ? props?.ActivityData?.AttachFiles : "[]");
        }
        const startingData = temp;
        const index = startingData?.findIndex(item => item.Language == "en");
        const findIndex = startingData?.findIndex(item => item.Language == progress?.lang);

        let lang = "";
        if (progress?.lang != undefined && findIndex > -1) {
            lang = progress?.lang;
        }
        else if (index > -1) {
            lang = "en";
        } else {
            lang = startingData?.[0]?.Language;
        }
        setValue("ddlUserConsume", lang, { shouldValidate: true });

    }, [setValue, props?.ActivityData, props?.EnrollCourseData?.PasteURL, props?.EnrollCourseData, props?.EnrollData]);

    const onProgressUpdate = async (OnVideoProgress) => {
        let langs = watch("ddlUserConsume");
        const percentageOfVideo = (OnVideoProgress * 100) / progress.current?.Duration;
        let temp = JSON.parse(props?.EnrollCourseData?.PasteURL != undefined ? props?.EnrollCourseData?.PasteURL : "{}")
        temp = { ...temp, [props?.ActivityData?.ActivityID]: { lang: langs, CompletionStatus: OnVideoProgress } }
        let Final = { PasteURL: JSON.stringify(temp) }
        if (props?.ActivityData?.IsViewTheActivity)
            AppSyncDbConnectionModule(Math.ceil(percentageOfVideo).toString(), Final);
        return;
    };


    return (
        <>
            {LanguageType != "" &&
                <div className="container mx-auto rounded-md">
                    <div className="flex justify-between flex-wrap break-all">
                        {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                        <div className="grid items-center">
                            <NVLSelectField id={"ddlUserConsume"} className="w-48 py-2" options={LanguageType} errors={errors} register={register} />
                        </div>
                    </div>
                    <div className={` min-h-[455px] mx-auto  bg-white`}>
                        <ReactPlayer config={{ file: { attributes: { controlsList: props?.ActivityData?.IsDownload ? "" : "nodownload" } } }} onContextMenu={e => e.preventDefault()} ref={playerRef} onDuration={(e) => { onReady(); progress.current = { ...progress?.current, Duration: e }; }} onProgress={(progress) => { onProgressUpdate(progress.playedSeconds); }} width="100%" height="485px" url={getURLValues?.[watch("ddlUserConsume")]} playing={false} controls={true} />
                        <MarkAsCompleted watch={watch} errors={errors} register={register} />
                    </div>

                </div>
            }
        </>
    );
}
export default ConsumeVideo;