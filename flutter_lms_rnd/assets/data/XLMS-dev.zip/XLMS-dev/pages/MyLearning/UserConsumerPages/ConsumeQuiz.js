import { Image } from "@aws-amplify/ui-react";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { listXlmsQuizConsumeCourseQuestionlistTemplate, listXlmsQuizConsumeTemplate } from "src/graphql/queries";
import * as Yup from "yup";
import QuizPreview from "./QuizPreview";
export default function ConsumeQuiz({ props, MarkAsCompleted, AppSyncDbConnectionModule, }) {
    const modalID = useRef(0);
    const noofQuestion = useRef(0);
    const [counter, setCounter] = useState(-1);
    const router = useRouter();
    const quizTotalMark = useRef(0)
    useEffect(() => {
        if (counter > 0) { modalID.current = setTimeout(() => setCounter(counter - 1), 1000) };
        if (counter == -2) { clearTimeout(modalID.current) }
        if (counter == 0) {
            router.push(`/MyLearning/UserConsumerPages/QuizQuestionList?CourseState=Start&ActivityID=${props?.ActivityData?.ActivityID}&LanguageView=${watch("ddlUserConsume")}&CourseID=${props?.ActivityData?.CourseID != undefined ? props?.ActivityData?.CourseID : ""}&ModuleID=${props?.ActivityData?.ModuleID != undefined ? props?.ActivityData?.ModuleID : ""}&BatchID=${props?.EnrollCourseData?.BatchID != undefined ? props?.EnrollCourseData?.BatchID : ""}`);
        }
        return null;
    }, [counter, props?.ActivityData?.ActivityID, props?.ActivityData?.CourseID, props?.ActivityData?.ModuleID, props?.EnrollCourseData?.BatchID, router, watch]);

    const getYourMark = useRef()
    useEffect(() => {
        // starting report
        const finalCompletion = async () => {
            let completionReport = [];
            if (props?.EnrollCourseData != undefined) {
                completionReport = JSON.parse(props?.EnrollCourseData?.QuestionandOptions != undefined ? props?.EnrollCourseData?.QuestionandOptions : "{}")?.[props.ActivityData.ActivityID]?.Answer;
            }
            else {
                completionReport = JSON?.parse(props?.EnrollData?.QuizCompletion == undefined ? "{}" : props?.EnrollData?.QuizCompletion);
            }
            if ((completionReport != null && completionReport != undefined) && Object.keys(completionReport) != undefined) {

                const tempQuestion = completionReport && Object.values(completionReport)?.[0];
                if (tempQuestion?.length > 0) {
                    let totalMark = 0;
                    let yourMark = 0;
                    for (let i = 0; i < tempQuestion?.length; i++) {
                        totalMark += parseInt(tempQuestion?.[i]?.TotalMark);
                        yourMark += parseInt(tempQuestion?.[i]?.YourMark);
                    }
                    setValue("TotalMark", totalMark);
                    setValue("YourMark", yourMark);
                    getYourMark.current = yourMark;
                    noofQuestion.current = totalMark;
                }

                const scoreOfAllAttempts = completionReport.PreviousAttempts
                let MarkArray = [], AverageScore = 0;
                scoreOfAllAttempts && scoreOfAllAttempts.map((data) => {
                    MarkArray.push(data?.ScoredMark)
                    AverageScore += parseInt(data.ScoredMark)
                })

                if (props?.ActivityData?.GradingMethod == "Highest Grade") {
                    setValue("YourMark", Math.max(...MarkArray));
                    getYourMark.current = Math.max(...MarkArray);
                } else if (props?.ActivityData?.GradingMethod == "First Attempt") {
                    setValue("YourMark", MarkArray[0]);
                    getYourMark.current = MarkArray[0]
                } else if (props?.ActivityData?.GradingMethod == "Last Attempt") {
                    setValue("YourMark", MarkArray[MarkArray?.length - 1]);
                    getYourMark.current = MarkArray[MarkArray?.length - 1]
                } else if (props?.ActivityData?.GradingMethod == "Average Grade") {
                    setValue("YourMark", (AverageScore / MarkArray?.length).toFixed(2)?.replaceAll(".00", ""));
                    getYourMark.current = (AverageScore / MarkArray?.length).toFixed(2)?.replaceAll(".00", "")
                }
            }

            let overAllFeedback = JSON.parse(props?.ActivityData.Options)?.Options?.Options
            const Percentage = (getYourMark.current/noofQuestion.current)*100;

            let closestGradeDifference = Math.abs(Percentage - overAllFeedback?.txtGradeBoundary1);
            let closestFeedback = overAllFeedback?.txtFeedback1;
            
            for (let i = 2; i <= 3; i++) {
                const gradeKey = `txtGradeBoundary${i}`;
                const feedbackKey = `txtFeedback${i}`;
                const gradeDifference = Math.abs(Percentage - overAllFeedback[gradeKey]);
            
                if (gradeDifference < closestGradeDifference) {
                    closestGradeDifference = gradeDifference;
                    closestFeedback = overAllFeedback[feedbackKey];
                }
                setValue("overAllFeedback", closestFeedback)
            }
        };
        
        finalCompletion();
        let languageType = [];
        if (Object.keys(JSON.parse(props?.LanguageName?.items?.[0]?.LanguageName)) != undefined) {
            Object.entries(JSON.parse(props?.LanguageName?.items?.[0]?.LanguageName)).forEach(([key, value]) => {
                languageType = [...languageType, { value: value, text: key }];
            });
        }
        setValue("LanguageType", languageType);

        const getLanguage = async () => {
            let TotalMarkForQuiz = 0;
            if (props?.ActivityData?.CourseID != undefined) {
                const questionsResponse = await AppsyncDBconnection(
                    listXlmsQuizConsumeCourseQuestionlistTemplate,
                    {
                        PK: "TENANT#" + props?.TenantInfo.TenantID,
                        SK: "COURSE#" + props?.ActivityData?.CourseID + "#MODULE#" + props?.ActivityData?.ModuleID + "#ACTIVITYID#" + props?.ActivityData?.ActivityID + "#LANGUAGE#",
                        IsConsume: true
                    },
                    props?.user?.signInUserSession?.accessToken?.jwtToken
                );
                const quizLanguage = questionsResponse.res.listXlmsQuizConsumeCourseQuestionlistTemplate?.items;
                const quizLang = [];
                quizLanguage?.map((getItemQuiz,) => {
                    for (let i = 0; i < languageType.length; i++) {
                        if (getItemQuiz?.Language == languageType?.[i]?.value) {
                            quizLang.push({ text: languageType?.[i]?.text, value: languageType?.[i]?.value });
                            TotalMarkForQuiz = TotalMarkForQuiz + parseInt(getItemQuiz.DefaultMark)
                        }
                    }
                });
                const uniq = {};
                const arrFiltered = quizLang.filter(obj => !uniq[obj.value] && (uniq[obj.value] = true));
                setValue("FilterQuizLanguages", arrFiltered);
                setValue("ddlUserConsume", arrFiltered?.[0]?.value);
            }
            else {
                const questionsResponse = await AppsyncDBconnection(
                    listXlmsQuizConsumeTemplate,
                    {

                        PK: "TENANT#" + props?.TenantInfo.TenantID,
                        SK: "ACTIVITYID#" + props?.ActivityData?.ActivityID,
                        IsConsume: true
                    },
                    props?.user?.signInUserSession?.accessToken?.jwtToken
                );
                const quizLanguage = questionsResponse.res.listXlmsQuizConsumeTemplate?.items;
                const quizLang = [];
                quizLanguage?.map((getItemQuiz,) => {
                    for (let i = 0; i < languageType.length; i++) {
                        if (getItemQuiz?.Language == languageType?.[i]?.value) {
                            quizLang.push({ text: languageType?.[i]?.text, value: languageType?.[i]?.value });
                            TotalMarkForQuiz = TotalMarkForQuiz + parseInt(getItemQuiz.DefaultMark)
                        }
                    }
                });
                const uniq = {};
                const arrFiltered = quizLang.filter(obj => !uniq[obj.value] && (uniq[obj.value] = true));
                setValue("FilterQuizLanguages", arrFiltered);
                setValue("ddlUserConsume", arrFiltered?.[0]?.value);
            }
            quizTotalMark.current = TotalMarkForQuiz
        };
        getLanguage();

    }, [props.ActivityData.ActivityID, props.ActivityData?.CourseID, props.ActivityData?.ModuleID, props?.EnrollData?.QuizCompletion, props?.EnrollCourseData, props?.LanguageName?.items, props.TenantID, props.TenantId, props?.user?.signInUserSession?.accessToken?.jwtToken, router, setValue, watch, props?.TenantInfo.TenantID, props.ActivityData, props?.EnrollData]);

    const validationSchema = Yup.object().shape({
        ddlUserConsume: Yup.string()
            .required("Choose a activity")
            .test("", "", (e) => {
                setValue("SelectedLanguage", e);
            }),
        markTheActivity: Yup.bool().test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
    });
    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    const goToQuizAttemptPage = useCallback(async () => {
        const questionsResponse = await AppsyncDBconnection(listXlmsQuizConsumeTemplate,
            {
                PK: "TENANT#" + props?.TenantId,
                SK: "ACTIVITYID#" + props?.ActivityData?.ActivityID + "#LANGUAGE#" + watch("ddlUserConsume"),
                IsConsume: true
            }, props?.user?.signInUserSession?.accessToken?.jwtToken
        );
        const questionData = questionsResponse.res.listXlmsQuizConsumeTemplate?.items;
        let tMark = 0;
        for (let i = 0; i < questionData?.length; i++) {
            tMark += parseInt(questionData?.[i]?.DefaultMark);
        }
        setValue("TotalMark", tMark);
        setCounter(10);
        modalID.current = 0;
    }, [props?.ActivityData?.ActivityID, props?.TenantId, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue, watch]);

    const diffMinutes = useCallback((date1, date2) => {
        if (date1 != undefined && date2 != undefined) {
            const date1Time = date1.getTime(), date2Time = date2.getTime(), diffSec = Math.abs(date1Time - date2Time) / 1000, diffMin = Math.ceil(diffSec / 60);
            return diffMin;
        }
        return 0;
    }, []);

    const courseOrActivity = useMemo(() => {
        if (props?.EnrollCourseData != undefined) {
            const temp = JSON.parse(props?.EnrollCourseData?.QuestionandOptions)?.[props?.ActivityData?.ActivityID]?.["QuizTakenCount"];

            if ((props?.ActivityData?.MaximumAttempt == undefined || props?.ActivityData?.MaximumAttempt ? temp < props?.ActivityData?.MaximumAttempt : true) && ((props?.ActivityData?.IsDelayBetweenNextAttempt ? ((diffMinutes(new Date(), new Date(JSON.parse(props?.EnrollCourseData?.QuestionandOptions)?.[props?.ActivityData?.ActivityID]?.["QuizCompletionDate"])) > props?.ActivityData?.DelayBetweenNextAttempt)) : true))) {
                return false;
            }
            return true;
        } else {
            if ((props?.ActivityData?.MaximumAttempt == undefined || (props?.ActivityData?.MaximumAttempt ? props?.EnrollData?.QuizTakenCount < props?.ActivityData?.MaximumAttempt : true)) && ((props?.ActivityData?.IsDelayBetweenNextAttempt ? (diffMinutes(new Date(), new Date(props?.EnrollData?.QuizCompletionDate)) > (props?.ActivityData?.DelayBetweenNextAttempt)) : true))) {
                return false;
            }
            return true;
        }
    }, [diffMinutes, props?.ActivityData?.ActivityID, props?.ActivityData?.DelayBetweenNextAttempt, props?.EnrollData?.QuizTakenCount, props?.ActivityData?.IsDelayBetweenNextAttempt, props?.ActivityData?.MaximumAttempt, props?.EnrollData?.QuizCompletionDate, props?.EnrollCourseData]);

    const caAttemptResult = useMemo(() => {
        if (props?.EnrollCourseData != undefined) {
            if (props?.ActivityData?.AllowMaximumAttempts == "if not Passed") {
                const temp = JSON.parse(props?.EnrollCourseData?.QuestionandOptions)?.[props?.ActivityData?.ActivityID]?.["QuizStatus"];
                return (temp == "Fail" || temp == null) ? false : true;
            } else {
                return false;
            }
        }
        else {
            if (props?.ActivityData?.AllowMaximumAttempts == "if not Passed") {
                const temp = props?.EnrollData?.QuizStatus;
                return temp == "Fail" ? false : true;
            } else {
                return false;
            }
        }
    }, [props?.EnrollCourseData, props?.ActivityData?.AllowMaximumAttempts, props?.ActivityData?.ActivityID, props?.EnrollData?.QuizStatus]);

    const timeStart = (props?.ActivityData.StartDate == "" || props?.ActivityData.StartDate == undefined || (new Date(props?.ActivityData.StartDate)) == null || props?.ActivityData.StartDate == "NaN-NaN-NaNTNaN:NaN" || (new Date(props?.ActivityData.StartDate)) <= (new Date())) ? false : true;
    const getTime = new Date(props?.ActivityData.StartDate)?.toDateString() + ", " + new Date(props?.ActivityData.StartDate).getHours() + ":" + new Date(props?.ActivityData.StartDate).getMinutes()  ;

    return (
        <div>
            {
                <>
                    <div className="flex justify-between flex-wrap break-all">
                        {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                        <div className="grid items-center">
                            <NVLSelectField id={"ddlUserConsume"} className="w-48 py-2" options={watch("FilterQuizLanguages")} errors={errors} register={register} />
                        </div>
                    </div>
                    {!(props?.EnrollData?.QuizCompletion || JSON.parse(props?.EnrollCourseData?.QuestionandOptions != undefined ? props?.EnrollCourseData?.QuestionandOptions : "{}")?.[props.ActivityData.ActivityID]) ?
                        <div className="grid gap-4 ">
                            <div className="min-h-[450px]">
                                <div className={` bg-blue-100 relative sm:px-20 w-full rounded-md grid place-items-center`}>
                                    <div className={`text-xs  bg-blue-50 text-gray-800  p-4 m-8 w-[80%] rounded-md grid place-content-center`}>
                                        <div className="z-10  h-full flex-col items-center justify-center space-y-4">
                                            <h1 className="text-blue-800 text-center text-5xl font-bold">Quiz</h1>
                                            <NVLButton
                                                text="Start"
                                                disabled={timeStart}
                                                onClick={() => goToQuizAttemptPage(10)}
                                                className={`
                                            ${!timeStart ? "text-xs bg-transparent w-32  hover:bg-blue-500 text-blue-700 font-semibold hover:text-white py-2 px-4 border border-blue-500 hover:border-transparent rounded" :
                                                        "text-xs bg-transparent w-32 h-8 my-auto bg-blue-200 text-blue-400 font-semibold py-2 px-4 border border-blue-200 hover:border-transparent rounded"}`}>
                                            </NVLButton>
                                            {timeStart && (<><NVLlabel text={`You can start after the time`} className="nvl-Def-Label"></NVLlabel>
                                                <NVLlabel text={getTime} className="nvl-Def-Label"></NVLlabel>
                                            </>)}
                                        </div>
                                        <div className={` -z-1 absolute bottom-3 left-3 h-24 w-24 rounded-full bg-white bg-gradient-to-b from-white to-blue-600 opacity-20`}></div>
                                        <div className={`-z-1 absolute -top-10 left-1/2 h-24 w-24 rounded-full bg-white bg-gradient-to-b from-white to-blue-600 opacity-20`}></div>
                                    </div>
                                    {/* <ActivityDescription /> */}
                                </div>
                            </div>
                        </div>
                        : <div className="grid gap-4 justify-items-center">
                            <div className={`bg-green-100 relative overflow-hidden  sm:px-20 w-full rounded-md grid place-items-center`}>
                                <div className={`text-xs bg-green-50 text-gray-800  p-4 w-[80%] rounded-md grid place-content-center`}>
                                    <ul>
                                        <li className="mb-6 flex items-start text-left gap-4">
                                            <i className="fa-sharp fa-solid fa-repeat h-3 w-4 text-sm"></i>
                                            <NVLlabel text="Status : " className="nvl-Def-Label w-72" ></NVLlabel>
                                            <p>Completed</p>
                                        </li>
                                        {props?.ActivityData?.IsShoeTheScore && (<>
                                            <li className="my-6 flex items-center text-left gap-4">
                                                <i className="fa-solid fa-m h-3 w-4  text-sm "></i>
                                                <NVLlabel text=" Your Marks  / Total Marks : " className="nvl-Def-Label w-72" ></NVLlabel><p>{watch("YourMark") + "  /  " + (watch("TotalMark") == 0 ? noofQuestion.current : watch("TotalMark"))}</p>
                                            </li>
                                            <li className="my-6 flex items-center text-left gap-4">
                                                <i className="fa-solid fa-percent h-3 w-4  text-sm "></i>

                                                <NVLlabel text=" Percentage : " className="nvl-Def-Label w-72" ></NVLlabel><p>{(watch("YourMark") || (watch("TotalMark")) ? `${(watch("YourMark") / (watch("TotalMark") == 0 ? noofQuestion.current : watch("TotalMark")) * 100)?.toFixed(2)?.replaceAll(".00", "")} %` : "0 %")}</p>
                                            </li>
                                        </>
                                        )}
                                     </ul>
                                    
                                    <div className={` -z-1 absolute bottom-3 left-3 h-24 w-24 rounded-full bg-white bg-gradient-to-b from-white to-green-600 opacity-20`}></div>
                                    <div className={`-z-1 absolute -top-10 left-1/2 h-24 w-24 rounded-full bg-white bg-gradient-to-b from-white to-green-600 opacity-20`}></div>
                                </div>
                                <div className="py-2 flex justify-center !w-full">
                                        <NVLlabel text={watch("overAllFeedback")} className={`text-lg  ${watch("YourMark") <= 2 ? "text-red-600" : "text-green-700"} `} ></NVLlabel>
                                    </div>
                                <div className="bg-green-50 rounded-full w-full flex justify-around ">
                                    <NVLButton
                                        disabled={courseOrActivity ? courseOrActivity : caAttemptResult}
                                        onClick={() => goToQuizAttemptPage(10)}
                                        className={`${(courseOrActivity ? courseOrActivity : caAttemptResult) ? "text-xs bg-transparent w-32 h-8 my-auto bg-green-200 text-green-400 font-semibold py-2 px-4 border border-green-200 hover:border-transparent rounded" :
                                            "text-xs bg-transparent w-32 h-8 my-auto  hover:bg-green-500 text-green-700 font-semibold hover:text-white py-2 px-4 border border-green-600 hover:border-transparent rounded"}`}>Re Attempt   <i className="fa-solid fa-repeat"></i>
                                    </NVLButton>
                                </div>
                                {/* <ActivityDescription /> */}
                            </div>
                            <div className="relative  w-full px-5 font-sans text-gray-800 bg-gray-100 p-4 rounded-lg">
                                <ul className="space-y-4">
                                    <li className="text-left">
                                        <label htmlFor="accordion-1" className="relative flex flex-col shadow-md border-green-600">
                                            <input className="peer hidden" type="checkbox" id="accordion-1" />
                                            <i className="fa-solid fa-caret-down absolute right-0 top-4 ml-auto mr-5 h-4 transition peer-checked:rotate-180"></i>
                                            <div className="relative ml-4 cursor-pointer select-none items-center py-4 pr-12">
                                                <h3 className="nvl-Def-Label uppercase">Quiz Submissions</h3>
                                            </div>
                                            <div className="max-h-0 overflow-hidden transition-all duration-500 peer-checked:max-h-full" aria-disabled>
                                                <div className="p-5">
                                                    <div className="bg-white  p-4 rounded-md grid gap-2 text-xs">
                                                        <QuizPreview EnrollCourseData={props.EnrollCourseData} CourseEnrollData={props?.EnrollCourseData} ActivityData={props?.ActivityData} RetainData={props?.EnrollData} register={register} errors={errors} setValue={setValue} watch={watch}></QuizPreview>
                                                    </div>
                                                </div>
                                            </div>
                                        </label>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    }
                    <MarkAsCompleted watch={watch} errors={errors} register={register} />
                    <div className={`relative z-10  ${counter > 0 ? "" : "hidden"}`} aria-labelledby="modal-title" role="dialog" aria-modal="true">
                        <div className="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity"></div>
                        <div className="fixed inset-0 z-10 overflow-y-auto">
                            <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                                <div className="relative transform overflow-hidden rounded-lg bg-white text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-lg">
                                    <div className="bg-white px-4 pt-5 ">
                                        <div className=" grid gap-4 justify-items-center">
                                            <Image alt="Novac Technology logo" className="h-32 w-96 object-contain" src="/Education2.svg" />
                                        </div>
                                        <div className="flex justify-center">
                                            <div className=" rounded-lg  bg-gray-100 p-2 text-center w-full">
                                                <div className=" text-xs   text-gray-800">
                                                    <ul>
                                                        <li className="mb-6 flex items-start text-left gap-4">
                                                            <i className="fa-sharp fa-solid fa-repeat h-3 w-4 text-sm"></i>
                                                            <NVLlabel text=" Attempts Allowed :" className="nvl-Def-Label uppercase w-72 text-xs" ></NVLlabel>
                                                            <p>{props?.ActivityData?.MaximumAttempt ? props?.ActivityData?.MaximumAttempt : "Unlimited"}</p>
                                                        </li>
                                                        {props?.ActivityData?.IsTimeLimit &&
                                                            (<li className="my-6 flex items-center text-left gap-4">
                                                                <i className="fa-solid fa-clock h-3 w-4 text-sm"></i>
                                                                <NVLlabel text=" Time Seconds : " className="nvl-Def-Label uppercase w-72" ></NVLlabel>
                                                                <p>{(props?.ActivityData?.QuizTimeLimit || props?.ActivityData?.QuizTimeLimit != "") ? props?.ActivityData?.QuizTimeLimit : "Unlimited"}</p>
                                                            </li>)}
                                                        {props?.ActivityData?.IsSetTime &&
                                                            (<li className="my-6 flex items-center text-left gap-4">
                                                                <i className="fa-solid fa-clock h-3 w-4 text-sm"></i>
                                                                <NVLlabel text=" Time For Each Question : " className="nvl-Def-Label uppercase w-72" ></NVLlabel>
                                                                <p>{(props?.ActivityData?.TimeForEachQuestion || props?.ActivityData?.TimeForEachQuestion != "") ? props?.ActivityData?.TimeForEachQuestion : "Unlimited"}</p>
                                                            </li>)}
                                                        {props?.ActivityData?.GradingMethod && (<li className="my-6 flex items-center text-left gap-4">
                                                            <i className="fa-solid fa-graduation-cap h-3 w-4  text-sm"></i>
                                                            <NVLlabel text="Grading Method : " className="nvl-Def-Label uppercase w-72" ></NVLlabel>
                                                            <p>{props?.ActivityData?.GradingMethod ? props?.ActivityData?.GradingMethod : "-"}</p>
                                                        </li>)}
                                                        {props?.ActivityData?.MaximumGrade && (<li className="my-6 flex items-center text-left gap-4">
                                                            <i className="fa-solid fa-m h-3 w-4  text-sm"></i>
                                                            <NVLlabel text="Total Mark : " className="nvl-Def-Label uppercase w-72" ></NVLlabel><p>{quizTotalMark.current}</p>
                                                        </li>)}
                                                    </ul>
                                                </div>
                                                <div className=" px-6 border-t border-gray-300 text-yellow-600">
                                                    <p className="text-xs ">
                                                        Your turn for this quiz will start in about
                                                    </p>
                                                    <div className="text-2xl font-semibold">{counter}</div>
                                                    <div className=" uppercase text-xs ">Seconds</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="bg-gray-50 px-4 py-3 sm:flex justify-between sm:flex-row-reverse sm:px-6">
                                        <NVLButton onClick={() => { router.push(`/MyLearning/UserConsumerPages/QuizQuestionList?CourseState=Start&ActivityID=${props?.ActivityData?.ActivityID}&LanguageView=${watch("ddlUserConsume")}&CourseID=${props?.ActivityData?.CourseID != undefined ? props?.ActivityData?.CourseID : ""}&ModuleID=${props?.ActivityData?.ModuleID != undefined ? props?.ActivityData?.ModuleID : ""}&BatchID=${props?.EnrollCourseData?.BatchID != undefined ? props?.EnrollCourseData?.BatchID : ""}`); }}
                                            type="button" className="inline-flex w-full justify-center rounded-md border border-transparent bg-blue-600 px-4 py-2 text-xs font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 sm:ml-3 sm:w-auto sm:text-sm">
                                            Attempt Quiz Now
                                        </NVLButton>
                                        <NVLButton onClick={() => { setCounter(-2) }} type="button" className="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 bg-white px-4 py-2 text-xs font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                                            Back to the course
                                        </NVLButton>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div></>}

        </div>
    );
}