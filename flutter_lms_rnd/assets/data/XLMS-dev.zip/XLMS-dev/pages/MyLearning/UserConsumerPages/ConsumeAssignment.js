import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import Modal from "@components/Controls/NVLDeletePopup";
import NVLFileUpload from "@components/Controls/NVLFileUpload";
import NVLFileViewer from "@components/Controls/NVLFileViewer";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLModalPopup from "@components/Controls/NVLModalPopup";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { Auth } from "aws-amplify";
import { APIGatewayGetRequest, APIGatewayPostRequest, APIGatewayPutRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function ConsumeAssignment({ props, LanguageType, UpdateCourseEnrollData, CourseEnrollData, MarkAsCompleted, AppSyncDbConnectionModule, Updatequery, updateCourseEnrollDataRef }) {
    const router = useRouter();
    const filechange=useRef(false);
    const [submitedData, setSubmiteData] = useState(() => {
        if (props.EnrollCourseData != undefined) {
            if (props.EnrollCourseData?.SubmissionAssignment != undefined) {
                const temparray = JSON.parse(props.EnrollCourseData?.SubmissionAssignment)?.[props.ActivityData.ActivityID];
                if (temparray != undefined) {
                    return JSON.parse(props.EnrollCourseData?.SubmissionAssignment)?.[props.ActivityData.ActivityID];
                } else {
                    return [];
                }
            }
            else {
                return [];
            }
        }
        else {
            return props?.EnrollData?.SubmissionAssignment == undefined ? [] : JSON.parse(props?.EnrollData?.SubmissionAssignment);
        }
    });
    const [comment, setComment] = useState("");
    const [modalValues, setModalValues] = useState({
        ModalInfo: "Success",
        ModalTopMessage: "Success",
        ModalBottomMessage: "Details have been saved successfully.",
        ModalOnClickEvent: () => {
            if (CourseEnrollData == undefined) {
                router.push("/MyLearning/LearningDashboard?parameters=4");
            }
            else {
                router.push("/MyLearning/LearningDashboard?parameters=1");
            }
        },
    });
    const [fileData, setFileData] = useState(() => {

        if (CourseEnrollData != undefined) {
            if (CourseEnrollData?.SubmissionAssignment != undefined) {
                const tempData = JSON.parse(CourseEnrollData?.SubmissionAssignment)?.[props.ActivityData.ActivityID];
                if (tempData != undefined) {
                    return JSON.parse(CourseEnrollData?.SubmissionAssignment)?.[props.ActivityData.ActivityID][0]?.FilePath;
                } else {
                    return "";
                }
            }
            else {
                return "";
            }
        }
        else {
            return props?.ActivityData?.AttachFiles == undefined ? "" : JSON.parse(props?.ActivityData?.AttachFiles)[0]?.FilePath;
        }
    });
    const validationSchema = Yup.object().shape({
        FileLang: Yup.string()
            .test("file_Error", "", (errorName, { createError }) => {
                let message = "";
                if (errorName != undefined) {
                    if (errorName.split("~")[0] == "FILE") {
                        message = "File is required to upload correct format.";
                    } else if (errorName.split("~")[0] == "ERROR") {
                        message = "File not uploaded.";
                    } else if (errorName.split("~")[0] == "INVALIDFILE") {
                        message = "File Format Is Invalid.";
                    }
                    else if (errorName.split("~")[0] == "FILESIZE") {
                        message = `File size has been exceeded than ${props.ActivityData.MaxmumAttachmentSize} MB`;
                    }
                    if (watch(errorName.split("~").pop()) != message && message != "") {
                        setValue(errorName.split("~").pop(), message);
                        return createError({ message: message });
                    } else if (watch(errorName.split("~").pop()) == message && message != "") {
                        return false;
                    }
                    else if (watch(errorName.split("~").pop()) != undefined) {
                        setValue(errorName.split("~").pop(), undefined);
                        return true;
                    }
                }
            })
            .nullable(),
        markTheActivity: Yup.bool().test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
        ddlUserConsume: Yup.string()
            .required("Choose a activity")
            .test("", "", (e) => {
                if (watch("ddlLanguage") != e) {
                    const temp1 = JSON.parse(CourseEnrollData?.AttachFiles != null || CourseEnrollData?.AttachFiles != undefined ? CourseEnrollData?.AttachFiles : props?.ActivityData?.AttachFiles)?.filter(
                        (x) => x.Language == e
                    );
                    if (temp1?.length > 0) {
                        setFileData(temp1[0]?.FilePath);
                        setValue("ddlLanguage", e);
                    }
                }
            }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, setValue, watch, formState } = useForm(formOptions);
    const { errors } = formState;

    useEffect(() => {
        let submissionAssignment = [];
        const temp = () => {
            if (props.EnrollCourseData  != undefined) {
                if (props.EnrollCourseData ?.SubmissionAssignment != undefined) {
                    const temparray = JSON.parse(props.EnrollCourseData ?.SubmissionAssignment)?.[props.ActivityData.ActivityID];
                    if (temparray != undefined) {
                        return JSON.parse(props.EnrollCourseData ?.SubmissionAssignment)?.[props.ActivityData.ActivityID];
                    } else {
                        return [];
                    }
                }
                else {
                    return [];
                }
            }
            else {
                return props?.EnrollData?.SubmissionAssignment == undefined ? [] : JSON.parse(props?.EnrollData?.SubmissionAssignment);
            }
        };

        submissionAssignment = temp();

        submissionAssignment.map((Assignment, index) => {
            setValue("SubmittedComments" + index, Assignment.Comments == undefined ? "" : Assignment.Comments, { shouldValidate: true });
            setValue("SubmittedFile" + index, "Assignment");
            setValue("FileName" + index, Assignment.FileName == undefined ? "Select File" : Assignment.FileName);
        });
        setValue("SubmitedData", submissionAssignment, { shouldValidate: true });
        setSubmiteData(submissionAssignment);
        setValue("FileName-1", "Select File");

        return () => { setSubmiteData([]); };

    }, [setValue, setSubmiteData, props.ActivityData.SubmissionAssignment, CourseEnrollData, props.ActivityData.ActivityID, props.ActivityData.AttachFiles, props?.EnrollData?.SubmissionAssignment, props.EnrollCourseData]);

    const getContentType = (Extension) => {
        switch (Extension) {
            case "mkv":
                return "video/x-matroska";
            case "avi":
                return "video/x-ms-video";
            case "mov":
                return "video/quicktime";
            case "wmv":
                return "video/x-ms-wmv";
            case "mp4":
                return "video/mp4";
            case "mpeg4":
                return "video/mpeg4";
            case "txt":
                return "text/html";
            case "xls":
                return "application/vnd.ms-excel";
            case "ppt":
                return "application/vnd.ms-powerpoint";
            case "pptx":
                return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
            case "xlsx":
                return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            default:
                return "application/" + Extension;
        }
    };

    const fileRename = useCallback((files) => {
        const fileName = files?.name?.split(".")[0];
        const guid = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,
            function (c) {
                var r = (Math.random() * 16) | 0,
                    v = c == "x" ? r : (r & 0x3) | 0x8;
                return v.toString(16);
            }
        );
        const ext = files?.name?.split(".").pop();
        const contentType =
            ext == "csv"
                ? "text/" + ext
                : ext == "jpeg" || ext == "jpg" || ext == "png"
                    ? "image/" + ext
                    : getContentType(ext);

        const filechanges = new File([files], fileName + "-" + guid + "." + ext, {
            type: contentType,
            lastModified: Date.now(),
        });
        return filechanges;
    }, []);

    const fileValidation = useCallback(async (e, index) => {
        if (e.target.files.length == 0) {
            return;
        }
        setValue("FileName" + index, "Select File");
        document.getElementById("loader" + index).classList.remove("hidden");
        const fileInput = document.getElementById(e.target.id);
        const filePath = fileInput.value;
        const getFile = fileRename(e.target.files[0]);

        const allowedExtensions =
            /(\.docx|\.doc|\.ppt|\.pptx|\.pdf|\.csv|\.jpg|\.jpeg|\.png|\.avi|\.mov|\.txt|\.xls|\.xlsx|\.mp4|\.mpeg4)$/i;
        if (!allowedExtensions.exec(filePath) || fileInput == null) {
            fileInput.value = "";
            setValue("FileLang", "INVALIDFILE~FileError" + index, {
                shouldValidate: true,
            });
            document.getElementById("loader" + index) &&
                !document.getElementById("loader" + index).classList.contains("hidden")
                ? document.getElementById("loader" + index).classList.add("hidden")
                : "";
            return false;
        } else if (getFile <= process.env.ACTIVITY_ALLFILE_SIZE) {
            fileInput.value = "";
            setValue("FileLang", "FILESIZE~FileError" + index, {
                shouldValidate: true,
            });
            document.getElementById("loader" + index) &&
                !document.getElementById("loader" + index).classList.contains("hidden")
                ? document.getElementById("loader" + index).classList.add("hidden")
                : "";
            return false;

        } else if (e.target.files[0].size >= (parseInt(props.ActivityData.MaxmumAttachmentSize) * 1024 * 1024)) {
            fileInput.value = "";
            setValue("FileLang", "FILESIZE~FileError" + index, {
                shouldValidate: true,
            });
            document.getElementById("loader" + index) &&
                !document.getElementById("loader" + index).classList.contains("hidden")
                ? document.getElementById("loader" + index).classList.add("hidden")
                : "";
            return false;
        }
        else {
            await uploadFile(getFile, index);
            filechange.current=true;
        }
    }, [uploadFile, fileRename, props?.ActivityData?.MaxmumAttachmentSize, setValue]);

    const uploadFile = useCallback(async (getFile, index) => {
        document.getElementById("divEditActivitySettings")?.classList?.add("pointer-events-none");
        const file = getFile;
        const csvReader = new FileReader();
        csvReader.onload = async function () {
            const isCSVDatacheck = false;
            if (!isCSVDatacheck) {
                const fetchURL = props?.ActivityData?.ModuleID != undefined ? process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${file.name}&TenantID=${props?.TenantInfo?.TenantID}&CourseType=Module&RootFolder=${props?.TenantInfo?.RootFolder}&BucketName=${props?.TenantInfo?.BucketName}&Type=Module&ManagementType=CourseManagement&ActivityType=${props?.ActivityData?.ActivityType}` : process.env.APIGATEWAY_URL_UPLOAD_FILE_ACTIVITY + `?FileName=${file.name}&TenantID=${props?.TenantInfo?.TenantID}&ActivityType=${props?.ActivityData?.ActivityType}&RootFolder=${props?.TenantInfo?.RootFolder}&BucketName=${props?.TenantInfo?.BucketName}&Type=Activity`;
                const headers = {
                    method: "GET",
                    headers: {
                        authorizationtoken:
                            props?.user?.signInUserSession?.accessToken?.jwtToken,
                        defaultrole: props?.TenantInfo?.UserGroup,
                        groupmenuname: "ActivityManagement",
                        menuid: "500002",
                    },
                };
                const extension = file.name.substring(file.name.lastIndexOf(".") + 1).toLowerCase();
                const contentType = extension == "csv" ? "text/" + extension : extension == "jpeg" || extension == "jpg" || extension == "png" ? "image/" + extension : getContentType(extension);
                const presignedHeader = {
                    method: "PUT",
                    headers: {
                        // "x-amz-acl": "public-read",
                        "content-type": contentType,
                        defaultrole: props?.TenantInfo?.UserGroup,
                        groupmenuname: "ActivityManagement",
                        menuid: "500002",
                    },
                    body: file,
                };

                const finalStatus = await APIGatewayPutRequest(
                    fetchURL,
                    headers,
                    presignedHeader
                );
                if (finalStatus[0] != "Success") {
                    setValue("FileLang", "ERROR~FileError" + index);
                    document.getElementById("divEditActivitySettings").classList.remove("pointer-events-none");
                    document.getElementById("loader" + index) && !document.getElementById("loader" + index).classList.contains("hidden") ? document.getElementById("loader" + index).classList.add("hidden") : "";
                    return;
                } else {
                    setValue("FileName" + index, file.name);
                    setValue("FileLang", "sucess~FileError" + index, {
                        shouldValidate: true,
                    });

                    document
                        .getElementById("fileErrorMessage")
                        ?.classList?.add("hidden");
                    document
                        .getElementById("divEditActivitySettings")
                        .classList.remove("pointer-events-none");
                    document.getElementById("loader" + index) &&
                        !document
                            .getElementById("loader" + index)
                            .classList.contains("hidden")
                        ? document
                            .getElementById("loader" + index)
                            .classList.add("hidden")
                        : "";
                }

            }
        };

        csvReader.readAsText(file);
    }, [props?.ActivityData?.ActivityType, props?.ActivityData?.ModuleID, props?.TenantInfo?.BucketName, props?.TenantInfo?.RootFolder, props?.TenantInfo?.TenantID, props?.TenantInfo?.UserGroup, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue]);

    const deleteField = useCallback(async (e, index) => {
        setSubmiteData((temp) => {
            let ActivityCompletedStatus, tempjsonFinal;
            const tempjson = JSON.parse(props.EnrollCourseData?.SubmissionAssignment == undefined ? "{}" : props.EnrollCourseData?.SubmissionAssignment);
            temp.splice(index, 1);
            for (let i = index; i < temp.length; i++) {
                setValue("SubmittedComments" + i, temp[i].Comments);
            }
            setValue("SubmitedData", temp, { shouldValidate: true });
            if (CourseEnrollData != undefined) {
                tempjsonFinal = { [props.ActivityData.ActivityID]: temp };
                if (props.EnrollCourseData?.SubmissionAssignment != undefined) {
                    tempjsonFinal = { ...tempjson, [props.ActivityData.ActivityID]: temp };
                }
            }
            if (CourseEnrollData != undefined) {
                ActivityCompletedStatus = {
                    PK: props.EnrollCourseData?.PK,
                    SK: props.EnrollCourseData?.SK,
                    SubmissionAssignment: JSON.stringify(tempjsonFinal),
                };
                updateCourseEnrollDataRef(ActivityCompletedStatus);
            }
            else {
                ActivityCompletedStatus = {
                    PK: props?.EnrollData?.PK,
                    SK: props?.EnrollData?.SK,
                    SubmissionAssignment: JSON.stringify(temp),
                };
            }
            AppsyncDBconnection(Updatequery[0], { input: ActivityCompletedStatus }, props?.user?.signInUserSession?.accessToken?.jwtToken);
            return temp;
        })

    }, [CourseEnrollData, Updatequery, props.ActivityData.ActivityID, props.EnrollCourseData?.PK, props.EnrollCourseData?.SK, props.EnrollCourseData?.SubmissionAssignment, props?.EnrollData?.PK, props?.EnrollData?.SK, props?.user?.signInUserSession?.accessToken?.jwtToken, setValue, updateCourseEnrollDataRef]);
    const submitUserFile = async () => {
        if (watch("FileName-1") == "Select File") {
            setValue("FileLang", "FILE~FileError-1", { shouldValidate: true });
            setValue("FileName-1", "Select File");
            return;
        }
        const fetchURL = process.env.UNSAVED_TO_SAVED_SUBMITED_ASSIGNMENT_ACTIVITY + `?FileName=${watch("FileName-1")}&ModuleID=${props?.ActivityData?.ModuleID != undefined ? props?.ActivityData?.ModuleID : ""}&ManagementType=${props?.ActivityData?.ModuleID != undefined ? "CourseManagement" : ""}&CourseType=${props?.ActivityData?.ModuleID != undefined ? "Module" : ""}&CourseID=${props?.ActivityData?.CourseID != undefined ? props?.ActivityData?.CourseID : ""}&ActivityID=${props?.ActivityData?.ActivityID}&Type=${props?.ActivityData?.CourseID != undefined ? "Module" : "Activity"}&TenantID=${props?.TenantInfo.TenantID}&RootFolder=${props?.TenantInfo.RootFolder}&BucketName=${props?.TenantInfo.BucketName}&ActivityType=${props?.ActivityData?.ActivityType}&UserSub=${props?.user?.attributes["sub"]}`;
        const headers = {
            method: "GET",
            headers: {
                authorizationtoken: props?.user?.signInUserSession?.accessToken?.jwtToken,
                defaultrole: props?.TenantInfo?.UserGroup,
                groupmenuname: "ActivityManagement",
                menuid: "500002",
            },
        };
        const finalResult = await APIGatewayGetRequest(fetchURL, headers);
        const fileAttached = await finalResult?.res?.text();
        if (fileAttached) {
            const submittedComments = watch("SubmittedComments");
            let setAssignmentValue = submitedData;
            setAssignmentValue = [...submitedData, { Id: "File" + submitedData?.length, FileName: watch("FileName-1"), FilePath: fileAttached, Comments: submittedComments ? submittedComments : "", Date: new Date(), },];
            let temp = setAssignmentValue;
            const tempjson = JSON.parse(props.EnrollCourseData?.SubmissionAssignment == undefined ? "{}" : props.EnrollCourseData?.SubmissionAssignment);
            if (props.EnrollCourseData != undefined) {
                temp = { [props.ActivityData.ActivityID]: setAssignmentValue };
                if (props.EnrollCourseData?.SubmissionAssignment != undefined) {
                    temp = { ...tempjson, ...temp };
                }
            }
            let Status = "0";
            if (props.ActivityData.IsSubmitTheActivity) {
                Status = "100";
            }
            AppSyncDbConnectionModule(Status, { SubmissionAssignment: JSON.stringify(temp), });
            setModalValues({ ModalInfo: "Success", ModalOnClickEvent: () => { CourseEnrollData != undefined ? router.push("LearningDashboard?parameters=1") : router.push("LearningDashboard?parameters=4"); }, });
            ModalOpen();
        }
    };
    const DownloadFiles = useCallback(async (url) => {
        let fetchURL = process.env.APIGATEWAY_INVOKEURL;
        let headers = {
            method: "POST",
            headers: {
                "Content-Type": "text/csv",
                authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                bucketname: props.TenantInfo.BucketName,
            },
            body: url,
        };
        let FinalStatus = await APIGatewayPostRequest(fetchURL, headers);
        var win = window.open(await FinalStatus.res.text(), '_blank');
    }, [props.TenantInfo.BucketName, props.user.signInUserSession.accessToken.jwtToken])

    const saveChangeField = useCallback(async (e, index) => {
        if (watch("FileName" + index) == "Select File") {
            setValue("FileError" + index, "File Is Requried")
            return true;
        }
        const assignmentData = submitedData;
        const assignmentFiles = [], tempjson = JSON.parse(props.EnrollCourseData?.SubmissionAssignment == undefined ? "{}" : props.EnrollCourseData?.SubmissionAssignment);
        const fetchURL = process.env.UNSAVED_TO_SAVED_SUBMITED_ASSIGNMENT_ACTIVITY + `?FileName=${watch("FileName" + index)}&ModuleID=${props?.ActivityData?.ModuleID != undefined ? props?.ActivityData?.ModuleID : ""}&ManagementType=${props?.ActivityData?.ModuleID != undefined ? "CourseManagement" : ""}&CourseType=${props?.ActivityData?.ModuleID != undefined ? "Module" : ""}&CourseID=${props?.ActivityData?.CourseID != undefined ? props?.ActivityData?.CourseID : ""}&ActivityID=${props?.ActivityData?.ActivityID}&Type=${props?.ActivityData?.CourseID != undefined ? "Module" : "Activity"}&TenantID=${props?.TenantInfo.TenantID}&RootFolder=${props?.TenantInfo.RootFolder}&BucketName=${props?.TenantInfo.BucketName}&ActivityType=${props?.ActivityData?.ActivityType}&UserSub=${props?.user?.attributes["sub"]}`;
        const headers = {
            method: "GET",
            headers: {
                authorizationToken: await Auth.currentSession().then((s) => s.getAccessToken().getJwtToken()),
                defaultrole: props?.TenantInfo?.UserGroup,
                groupmenuname: "ActivityManagement",
                menuid: "500002",
            },
        };
        let fileAttached=submitedData[index].FilePath;
        if(filechange.current)
        {
            const finalResult = await APIGatewayGetRequest(fetchURL, headers);
            fileAttached = await finalResult?.res?.text();
        }
        for (let i = 0; i < assignmentData.length; i++) {
            if (i == index) {
                assignmentFiles.push({ Id: assignmentData?.[i].Id, FileName:filechange.current? watch("FileName" + index):submitedData[index].FileName, FilePath: fileAttached, Comments: watch("SubmittedComments" + i), Date: assignmentData?.[i].Date, });
            } else {
                assignmentFiles.push(assignmentData?.[i]);
            }
        }
        setValue("SubmitedData", assignmentFiles);
        setSubmiteData(assignmentFiles);
        let temp = assignmentFiles;
        if (CourseEnrollData != undefined) {
            temp = { [props.ActivityData.ActivityID]: assignmentFiles };
            if (props.EnrollCourseData?.SubmissionAssignment != undefined) {
                temp = { ...tempjson, [props.ActivityData.ActivityID]: assignmentFiles };
            }
        }
        const PK = CourseEnrollData?.PK != undefined ? props.EnrollCourseData?.PK : props?.EnrollData?.PK, SK = CourseEnrollData?.SK != undefined ? props.EnrollCourseData?.SK : props?.EnrollData?.SK;
        const activityCompletedStatus = {
            PK: PK,
            SK: SK,
            SubmissionAssignment: JSON.stringify(temp),
        };
        if (CourseEnrollData?.PK != undefined) {
            UpdateCourseEnrollData(activityCompletedStatus);
        }
        const finalStatus = (
            await AppsyncDBconnection(Updatequery[0], { input: activityCompletedStatus }, props?.user?.signInUserSession?.accessToken?.jwtToken)
        ).Status;

        if (finalStatus != "Success") {
            setModalValues({ ModalInfo: "Danger", ModalTopMessage: "Error", ModalBottomMessage: finalStatus, });
            ModalOpen();
            return;
        } else {
            setModalValues({ ModalInfo: "Success", ModalOnClickEvent: () => { router.push("LearningDashboard"); }, });
            ModalOpen();
        }
    }, [CourseEnrollData, UpdateCourseEnrollData, Updatequery, props.ActivityData.ActivityID, props.ActivityData?.ActivityType, props.ActivityData?.CourseID, props.ActivityData?.ModuleID, props.EnrollCourseData?.PK, props.EnrollCourseData?.SK, props.EnrollCourseData?.SubmissionAssignment, props?.EnrollData?.PK, props?.EnrollData?.SK, props?.TenantInfo.BucketName, props?.TenantInfo.RootFolder, props?.TenantInfo.TenantID, props?.TenantInfo?.UserGroup, props?.user?.attributes, props?.user?.signInUserSession?.accessToken?.jwtToken, router, setValue, submitedData, watch]);

    useEffect(() => {
        submitedData.map((Assignment, index) => {
            setValue("SubmittedComments" + index, Assignment.Comments == undefined ? "" : Assignment.Comments, { shouldValidate: true });
            setValue("SubmittedFile" + index, "Assignment");
            setValue("FileName" + index, Assignment.FileName == undefined ? "Select File" : Assignment.FileName);
        });
        setValue("FileName-1", "Select File");
    }, [setValue, submitedData]);

    return (
        <>
            <NVLAlert ButtonYestext={"X"} MessageTop={modalValues.ModalTopMessage} MessageBottom={modalValues.ModalBottomMessage} ModalOnClick={modalValues.ModalOnClickEvent} ModalInfo={modalValues.ModalInfo} />
            {((props.EnrollData?.UserGradeDetails !== null&& props.EnrollData?.UserGradeDetails !== undefined)||((props.EnrollCourseData!==undefined&&props?.EnrollCourseData?.UserGradeDetails!==undefined&&props.EnrollCourseData.UserGradeDetails!==null)?(JSON.parse(props?.EnrollCourseData?.UserGradeDetails).hasOwnProperty(props.ActivityData?.ModuleID)&&JSON.parse(props?.EnrollCourseData?.UserGradeDetails)[props.ActivityData?.ModuleID].hasOwnProperty(props.ActivityData?.ActivityID))?true:false:false))&& <div className="my-2">
                <div className="text-green-700 p-2 space-y-2 bg-green-100 rounded-md w-full">
                    <NVLlabel text={`Submission Status`} className="font-bold " />
                    <NVLlabel text={`Grade : ${router.query["CourseID"]!==undefined?JSON.parse(props?.EnrollCourseData?.UserGradeDetails)[props.ActivityData?.ModuleID][props.ActivityData?.ActivityID].Grade:JSON.parse(props?.EnrollData?.UserGradeDetails)?.Grade}`} className="font-bold w-full" />
                    <NVLlabel text={`Remarks : ${router.query["CourseID"]!==undefined?JSON.parse(props?.EnrollCourseData?.UserGradeDetails)[props.ActivityData?.ModuleID][props.ActivityData?.ActivityID].Remarks:JSON.parse(props?.EnrollData?.UserGradeDetails)?.Remarks}`} className="font-bold w-full h-fit" showFull />
                    <NVLlabel text={`Graded on : ${router.query["CourseID"]!==undefined?new Date(JSON.parse(props?.EnrollCourseData?.UserGradeDetails)[props.ActivityData?.ModuleID][props.ActivityData.ActivityID].CreatedDate).toDateString().substring(4):new Date(JSON.parse(props?.EnrollData?.UserGradeDetails)?.CreatedDate).toDateString().substring(4)}`} className="font-bold w-full" />
                    <NVLlabel text={`Graded by : ${props?.ActivityData?.CreatedBy}`} className="font-bold w-full h-fit" showFull />
                </div>
                {submitedData.length > 0 && <div className="border border-slate-300 my-2 p-2 space-y-4">
                    <h1 className="font-extrabold">Files submitted</h1>
                    {submitedData.map((assignment, index) => <div key={index}>
                        <section className="flex justify-between my-2">
                            <h3 className="text-sm text-gray-600 flex gap-4 ">
                                {assignment?.FileName}
                            </h3>
                            <ul className="flex justify-between gap-3">
                                {assignment.FileName !== undefined && <li><span onClick={() => DownloadFiles(assignment.FilePath.substring(1))} className="fa-solid fa-download text-xl text-blue-500 cursor-pointer"><i className="fa-downloadtext-xl text-blue-500 cursor-pointer"></i></span></li>}
                                {assignment?.Comments !== undefined && <li><NVLButton type={"button"} text={"Show Comment"} ButtonType={assignment.Comments != "" ? "primary" : "light"} className="w-fit border-none bg-transparent" onClick={() => setComment(assignment.Comments)} /></li>}
                            </ul>
                        </section>
                    </div>)}
                    <NVLModalPopup Content={comment} TextClassName={' text-justify'} IsCloseIcon CloseIconEvent={() => setComment("")} IsConfirmAlert />
                </div>}
            </div>}
            <div id="divEditActivitySettings" className="container rounded-md">
                <div className="flex justify-between flex-wrap break-all">
                    {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                    <div className="grid items-center">
                        <NVLSelectField id={"ddlUserConsume"} className="w-48 py-2" options={LanguageType} errors={errors} register={register} />
                    </div>
                </div>
                <div className="my-2 min-h-[460px]">
                    <NVLFileViewer token={props?.user?.signInUserSession?.accessToken?.jwtToken} src={fileData} BucketName={props?.TenantInfo?.BucketName} IsDownload={props?.ActivityData?.IsDownload}></NVLFileViewer>
                    {/* <ActivityDescription /> */}
                    <br></br><br></br>
                    <div className={`${submitedData.length >= props?.ActivityData?.MaximumNumberOfAttachment||((props.EnrollData?.UserGradeDetails !== null&& props.EnrollData?.UserGradeDetails !== undefined)||((props.EnrollCourseData!==undefined&&props.EnrollCourseData.UserGradeDetails!==null)?(JSON.parse(props?.EnrollCourseData?.UserGradeDetails!==undefined?props?.EnrollCourseData?.UserGradeDetails:"{}").hasOwnProperty(props.ActivityData?.ModuleID)&&JSON.parse(props?.EnrollCourseData?.UserGradeDetails!==undefined?props?.EnrollCourseData?.UserGradeDetails:"{}")[props.ActivityData?.ModuleID]?.hasOwnProperty(props.ActivityData?.ActivityID))?true:false:false))? "hidden" : "p-2"}`}>
                        <div className="my-6">
                        <NVLlabel text="Upload File" className="font-bold text-gray-600" CustomCss={"!bottom-0 !translate-x-1 !translate-y-8 mb-1 pl-5"} HelpInfo={`File size should be ${props.ActivityData.MaxmumAttachmentSize}  MB <br> Acceptable file format: docx, doc, ppt,pptx, pdf, csv, jpg, jpeg, png, avi, mov,xls,xlsx, mp4 `}  HelpInfoIcon={"fa fa-solid fa-circle-question "} /></div>
                        <div className="4-2 flex justify-between sm:flex-row sm:items-center ">
                            {/* File Upload */}
                            <div >
                                <NVLFileUpload className="!w-60 xl:!w-72" isLoader={true} loaderID={"loader-1"} text={watch("FileName-1")} errors={errors} register={register} onChange={(e) => fileValidation(e, "-1")} />
                                <span id="RequireFile" className="text-xs text-red-600 ">
                                    {watch("FileError-1")}
                                </span>
                            </div>
                            <NVLMultilineTxtbox id="SubmittedComments" title="Add Your Comments" errors={errors} register={register} className="nvl-non-mandatory !w-72 nvl-Def-Input h-9" />
                        </div>
                        <div className="flex justify-end">
                            <NVLButton id="btnPreview" onClick={submitUserFile} text={"Submit"} type="submit" className={"nvl-button bg-primary text-white "} />
                        </div>
                    </div>
                    {submitedData?.length > 0&& ((props?.EnrollData!==undefined?props.EnrollData.UserGradeDetails === null?true:false:true)||(props.EnrollCourseData!==undefined&&props?.EnrollCourseData?.UserGradeDetails!==undefined&&props.EnrollCourseData.UserGradeDetails!==null)?(JSON.parse(props?.EnrollCourseData?.UserGradeDetails!==undefined&&props?.EnrollCourseData?.UserGradeDetails!==null?props?.EnrollCourseData?.UserGradeDetails:"{}").hasOwnProperty(props.ActivityData?.ModuleID)&&JSON.parse(props?.EnrollCourseData?.UserGradeDetails!==undefined?props?.EnrollCourseData?.UserGradeDetails:"{}")[props.ActivityData?.ModuleID]?.hasOwnProperty(props.ActivityData?.ActivityID))?false:true:false)&&(<>
                        <NVLlabel text="Your Submission Assignment Details" className="font-bold text-green-700 py-2 bg-green-100 rounded-md" />
                        <div className="relative mx-auto w-full px-5 font-sans text-gray-800 sm:px-20 md:max-w-screen-xl py-4 bg-slate-200 ">
                            <ul className="space-y-4 ">
                                {submitedData.map((Assignment, index) => {
                                    return (
                                            <li className="text-left bg-green-100" key={index}>
                                                <label htmlFor={`accordion-` + index} className="relative flex flex-col rounded-md border border-gray-100 shadow-md">
                                                    <input className="peer hidden" type="checkbox" id={"accordion-" + index} />
                                                    <svg className="absolute right-0 top-4 ml-auto mr-5 h-4 text-gray-500 transition peer-checked:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                                                        <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
                                                    </svg>
                                                    <div className="relative ml-4 cursor-pointer select-none items-center py-4 pr-12">
                                                        <h3 className="text-sm text-gray-600 flex gap-4 ">
                                                            <i className="text-green-600 my-auto fa-sharp fa-solid fa-bookmark"></i>
                                                            {Assignment?.FileName}
                                                        </h3>
                                                    </div>
                                                    <div className="max-h-0 overflow-hidden transition-all duration-500 peer-checked:max-h-96 bg-green-50">
                                                        <div className="p-5">
                                                            <div className="flex justify-between ">
                                                                <div className="my-auto">
                                                                    <NVLFileUpload id={"SubmittedFile" + index} className=" my-auto" isLoader={true} loaderID={"loader" + index}
                                                                        tooltip={watch("FileName" + index) != null ? watch("FileName" + index) : "Select File"
                                                                        }
                                                                        text={watch("FileName" + index)?.substring(0, 12) + "..."} errors={errors} register={register} onChange={(e) => fileValidation(e, index)} />
                                                                    <span id="RequireFile" className="text-xs text-red-600">
                                                                        {watch("FileError" + index)}
                                                                    </span>
                                                                </div>
                                                                <NVLMultilineTxtbox id={"SubmittedComments" + index} title="Add Your Comments" errors={errors} register={register} className="nvl-non-mandatory nvl-Def-Input h-9" />
                                                                <div className="flex items-center gap-6">
                                                                    <NVLButton id="btnPreview" onClick={(e) => saveChangeField(e, index)} text={"Save Change"} type="submit" className={"nvl-button bg-primary text-white "} />
                                                                    <Modal onDelete={(e) => deleteField(e, index)} Icon={<i className="fa-solid fa-trash grid place-content-center h-8 w-8  cursor-pointer rounded-full bg-red-100 text-red-600"></i>}></Modal>
                                                                </div>
                                                            </div>{" "}
                                                        </div>
                                                    </div>
                                                </label>
                                            </li>
                                    );
                                })}

                                {/* </div> */}
                            </ul>
                        </div></>
                    )}

                </div>
                <MarkAsCompleted watch={watch} errors={errors} register={register} />

            </div>

        </>
    );
}
export default ConsumeAssignment;