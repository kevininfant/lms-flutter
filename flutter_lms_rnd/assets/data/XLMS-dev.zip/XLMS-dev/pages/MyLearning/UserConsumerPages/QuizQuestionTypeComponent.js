import NVLCheckbox from "@components/Controls/NVLCheckBox";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLRadio from "@components/Controls/NVLRadio";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { Fragment } from "react";

export const MultipleAnswerCompoent = ({ getQuestion, index, options, errors, register, QuestionType, watch, handleSort, dragItem, dragOverItem, BindFillups, shuffle }) => {
    return (
        <>
            {QuestionType == "MultipleChoice" &&
                <div key={index} id={"QuestionForQuiz" + index} className="space-y-2">
                    <p className="text-xs font-semibold break-all">
                        {"Q"+(index+1)+". "+ getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    {getQuestion?.ChoiceType == "MultipleAnswer" ? (
                        options?.map((QestinOption, indexOf) => {
                            return (
                                <Fragment key={crypto.randomUUID()}>
                                    <NVLCheckbox showFull={true} id={"chkMultipleAnswer" + (index) + "-" + (indexOf)} name={"chkMultipleAnswer" + (index) + "-" + (indexOf)} text={QestinOption.Option?.trim()} value={QestinOption.Option} errors={errors} register={register}  ></NVLCheckbox>
                                </Fragment>);
                        })
                    ) : getQuestion?.ChoiceType == "SingleAnswer" ? (
                        options?.map((QestinOption, ) => {
                            return (
                                <Fragment key={crypto.randomUUID()}>
                                    <NVLRadio showFull={true} id={"SingleAnswer" + index} name={"SingleAnswer" + index} value={QestinOption?.Option} type="radio" text={QestinOption?.Option?.trim()} register={register} errors={errors} />
                                </Fragment>
                            );
                        })) : getQuestion?.ChoiceType == "Dropdown" ? (
                        <>
                            <NVLSelectField options={options} name={"multiChoiceSelect" + index} id={"multiChoiceSelect" + index} className={"nvl-Def-Input"} register={register} errors={errors}></NVLSelectField>
                        </>
                    ) :
                        (<></>)}
                </div>}
            {QuestionType == "Ordering" &&
                <div key={index} id={"QuestionForQuiz" + index} className="space-y-2">
                    <p className="text-xs font-semibold break-all">
                        {"Q"+(index+1)+". "+getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div className="grid gap-4">
                        {watch("OrderingOptions" + index)?.map((e, indexOf) => {
                            return (
                                <Fragment key={crypto.randomUUID()}>
                                    <div draggable onDragStart={() => (dragItem.current = indexOf)} onDragEnter={() => (dragOverItem.current = indexOf)} onDragEnd={() => handleSort(e, indexOf, index, "Ordering")} onDragOver={(e) => e.preventDefault()} id={indexOf} className="h-8 bg-white shadow-md rounded flex justify-between p-2 " >
                                        {e}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                    </div>
                                </Fragment>
                            );
                        })}
                    </div>
                </div>
            }
            {QuestionType == "Description" &&
                <div key={index} id={"QuestionForQuiz" + index} className="space-y-2" >
                    <p className="text-xs font-semibold break-all">
                        {"Q"+(index+1)+". "+getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div className="grid gap-4">
                        <NVLMultilineTxtbox id={"txtQuestionForQuiz" + index} title="Add Answer" errors={errors} register={register} className="nvl-non-mandatory nvl-Def-Input" />
                    </div>
                </div>}
            {QuestionType == "Match" &&
                <div key={index} id={"QuestionForQuiz" + index} className="space-y-2">
                    <p className="text-xs font-semibold break-all">
                        {"Q"+(index+1)+". "+getQuestion?.Question.replace(/<[^>]+>/g, "")}
                    </p>
                    <div className="flex gap-4 justify-center" key={index}>
                        <div className='grid gap-4'>
                            {watch("MatchingA" + index)?.map((e, indexOf) => {
                                return (
                                    <Fragment key={crypto.randomUUID()}>
                                        <div draggable onDragStart={() => (dragItem.current = indexOf)} onDragEnter={() => (dragOverItem.current = indexOf)} onDragEnd={() => handleSort(e, indexOf, index, "Match", "MatchingA")} onDragOver={(e) => e.preventDefault()} className="h-8 bg-white shadow-md rounded flex justify-between p-2 ">
                                            {e}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                        </div>
                                    </Fragment>
                                );
                            })}
                        </div>
                        <div className='grid gap-4 break-all'>
                            {watch("MatchingB" + index)?.map((e, indexOf) => {
                                return (
                                    <Fragment key={crypto.randomUUID()}>
                                        <div draggable onDragStart={() => (dragItem.current = indexOf)} onDragEnter={() => (dragOverItem.current = indexOf)} onDragEnd={() => handleSort(e, indexOf, index, "Match", "MatchingB")} onDragOver={(e) => e.preventDefault()} className="h-8  bg-white shadow-md rounded flex justify-between p-2">
                                            {e}<i className="fa-solid fa-bars cursor-move my-auto pl-2 text-gray-600"></i>
                                        </div>
                                    </Fragment>
                                );
                            })}
                        </div>
                    </div>

                </div>}
            {QuestionType == "FillInTheBlank" &&
                <div key={index} id={"FillInTheBlank" + index} className="space-y-2  break-all">
                    <BindFillups CurrentQuestion={watch("currentIndex")} id={"FillInTheBlank" + index} FillInTheBlank={"Q"+(index+1)+". "+ getQuestion?.Question.replace(/<[^>]+>/g, "")} errors={errors} register={register} shuffle={shuffle}></BindFillups>
                </div>}
        </>
    );
};

export default function QuizCompoenets() { return( <></>);}
