import { useCallback, useEffect, useRef, useState } from "react";

export default function QuizTimer({ QuizData, NextAndPrevAction, QuizSubmitData, router, watch, resetCount }) {
    const timer = useRef();
    const [counter1, setCounter1] = useState(() => {""; });
    useEffect(() => {
        clearTimeout(timer.current);
        setCounter1((data) => {
            if (QuizData?.ShardActivityData?.IsSetTime && data == undefined) {
                return ((parseInt(QuizData?.ShardActivityData?.TimeForEachQuestion) * 60));
            } else if (QuizData?.ShardActivityData?.QuizTimeLimit != undefined && QuizData?.ShardActivityData?.QuizTimeLimit != "0" && data == undefined) {
                return ((parseInt(QuizData?.ShardActivityData?.QuizTimeLimit) * 60));
            }
        });
    }, [QuizData]);
    const [counter2, setCounter2] = useState();
    useEffect(() => {
        if (resetCount > 0 && QuizData?.ShardActivityData?.IsSetTime) {
            clearTimeout(timer.current);
            setCounter1(() => {
                return ((parseInt(QuizData?.ShardActivityData?.TimeForEachQuestion) * 60));
            });
        }
    }, [QuizData?.ShardActivityData?.IsSetTime, QuizData?.ShardActivityData?.TimeForEachQuestion, resetCount]);
    const toHoursAndMinutes = useCallback((e) => {
        setCounter1(() => {
            return e;
        });
        setCounter2(() => {
            const totalMinutes = Math.floor(e / 60);
            let seconds = e % 60;
            let hours = Math.floor(totalMinutes / 60);
            let minutes = totalMinutes % 60;
            if (minutes < 10 && minutes.length != 2) {
                minutes = "0" + minutes;
            }
            if (hours < 10 && hours.length != 2) {
                hours = "0" + hours;
            }
            if (seconds < 10 && seconds.length != 2) {
                seconds = "0" + seconds;
            }
            const temp = { h: hours, m: minutes, s: seconds };
            return temp;
        });
    }, []);

    useEffect(() => {
        if (QuizData?.ShardActivityData?.IsSetTime) {
            if (counter1 > 0) {
                timer.current = setTimeout(() => toHoursAndMinutes(counter1 - 1), 1000);
            }
            if (counter1 == 0 && watch("currentIndex") < QuizData?.QuizQuestions?.length - 1) {
                NextAndPrevAction("nextQuestion");
                setCounter1((parseInt(QuizData?.ShardActivityData?.TimeForEachQuestion) * 60));
            }
            else if (counter1 == 0) {
                if (QuizData?.ShardActivityData?.IsSubmissionAutomatically) {
                    QuizSubmitData();
                } else {
                    //router.push(`/MyLearning/UserConsume?CourseState=Start&ActivityID=${QuizData?.ShardActivityData?.ActivityID}&ActivityType=${QuizData?.ShardActivityData?.ActivityType}`);
                    router.back();
                }
            }
            return null;
        }
        else if (QuizData?.ShardActivityData?.QuizTimeLimit != undefined && QuizData?.ShardActivityData?.QuizTimeLimit != "0") {
            if (counter1 > 0) {
                timer.current = setTimeout(() => toHoursAndMinutes(counter1 - 1), 1000);
            }
            if (counter1 == 0) {
                if (QuizData?.ShardActivityData?.IsSubmissionAutomatically) {
                    QuizSubmitData();
                } else {
                    //router.push(`/MyLearning/UserConsume?CourseState=Start&ActivityID=${QuizData?.ShardActivityData?.ActivityID}&ActivityType=${QuizData?.ActivityData?.ActivityType}`);
                    router.back();
                }
            }
        }
    }, [NextAndPrevAction, QuizData, QuizSubmitData, counter1, router, toHoursAndMinutes, watch]);


    return (
        <>
            {counter2 && <div className="bg-yellow-600 p-2 rounded-full font-semibold w-24 flex gap-2"  ><i className="fa-solid fa-clock my-auto text-sm"></i>{counter2?.h + ":" + counter2?.m + ":" + counter2?.s}</div>}
        </>
    );
}

