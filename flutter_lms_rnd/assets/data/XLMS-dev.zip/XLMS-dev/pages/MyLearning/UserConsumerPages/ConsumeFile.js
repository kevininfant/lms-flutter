import NVLFileViewer from "@components/Controls/NVLFileViewer";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { yupResolver } from "@hookform/resolvers/yup";
import { useState } from "react";
import { useForm } from "react-hook-form";
import * as Yup from "yup";

function ConsumeFile({ props, LanguageType, MarkAsCompleted, AppSyncDbConnectionModule, }) {

    const [fileData, setFileData] = useState(props?.ActivityData?.AttachFiles == undefined ? [] : JSON.parse(props?.ActivityData?.AttachFiles)[0]?.FilePath);

    {/*Valiation Mark As Completed*/ }
    const validationSchema = Yup.object().shape({
        markTheActivity: Yup.bool().test("", "", (e) => {
            if (e) {
                AppSyncDbConnectionModule("100");
            }
            return true;
        }),
        ddlUserConsume: Yup.string()
            .required("Choose a Language")
            .test("", "", (e) => {
                const temp1 = JSON.parse(props?.ActivityData?.AttachFiles).filter((x) => x.Language == e);
                if (temp1.length > 0) {
                    setFileData(() => {
                        return temp1[0]?.FilePath;
                    });
                }
            }),
    });

    const formOptions = { mode: "onChange", resolver: yupResolver(validationSchema), reValidateMode: "onChange", nativeValidation: false, };
    const { register, formState, watch } = useForm(formOptions);
    const { errors } = formState;
    return (
        <>
            <div className="flex justify-between flex-wrap break-all">
                    {props?.CourseData?.CourseName && <div className="text-base font-semibold my-auto text-[#0E4681]">{props?.CourseData?.CourseName}</div>}
                    <div className="grid items-center">
                    <NVLSelectField id={"ddlUserConsume"} className="w-48 py-2 grid" options={LanguageType} errors={errors} register={register} />
                    </div>
                </div>
            <div className="min-h-[470px]">
                <NVLFileViewer token={props?.user?.signInUserSession?.accessToken?.jwtToken} src={fileData} BucketName={props?.TenantInfo?.BucketName} IsDownload={props?.ActivityData?.IsDownload}></NVLFileViewer>
                <MarkAsCompleted watch={watch} errors={errors} register={register} />
            </div>

        </>
    );
}
export default ConsumeFile;
