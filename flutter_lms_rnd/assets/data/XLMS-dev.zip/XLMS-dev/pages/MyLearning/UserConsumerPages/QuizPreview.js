import NVLlabel from "@components/Controls/NVLlabel";
import NVLSelectField from "@components/Controls/NVLSelectField";
import { Fragment, useCallback, useEffect, useRef } from "react";
import { AnswerPreview } from "./QuizAnswerPreviewComponent";

export default function QuizPreview({ ActivityData, RetainData, errors, register, setValue, watch,  CourseEnrollData }) {
    useEffect(() => {
        let temp,prevData;
        setValue("multiChoiceSelect" + 2, "checked");
        if (CourseEnrollData != undefined) {
            prevData=JSON.parse(CourseEnrollData?.QuestionandOptions != undefined ? CourseEnrollData?.QuestionandOptions : "{}")?.[ActivityData.ActivityID]?.["Answer"]
            delete prevData["PreviousAttempts"];
            delete prevData["QuizStartTime"]
            delete prevData["QuizEndTime"]
            temp = prevData;
        }
        else {
            prevData = JSON.parse(RetainData?.QuizCompletion)
            delete prevData["PreviousAttempts"];
            delete prevData["QuizStartTime"]
            delete prevData["QuizEndTime"]
            temp = prevData;
        }
      
        let questionlength = temp ? Object.values(temp)[0].length : 0
        let previewquestionData = temp ? Object.values(temp)[0] : []
        for (let i = 0; i < questionlength; i++) {
            if ((previewquestionData)?.[i]?.QuestionType == "Ordering") {
                setValue("OrderingOptions" + i, (previewquestionData)?.[i]?.Options);
            }
            else if ((previewquestionData)?.[i]?.QuestionType == "MultipleChoice") {
                if ((previewquestionData)?.[i]?.ChoiceType == "Dropdown") {
                    const multiDropDown = [{value:"",text:"Select Value"}];
                    (previewquestionData)?.[i]?.Options.map((Items,) => {
                        multiDropDown.push({ value: Items?.Option, text: Items?.Option });
                    });
                    setValue("MultiDropDown" + i, multiDropDown);
                }
            }
        }
    }, [ActivityData.ActivityID, CourseEnrollData, RetainData?.QuizCompletion, setValue]);
    const fillUps = useRef();
    const bindFillups = useCallback(({ id, FillInTheBlank,  }) => {
        const question = FillInTheBlank;
        var byteArray = new Uint8Array(1);
        function getScaledValue(value, sourceRangeMin, sourceRangeMax, targetRangeMin, targetRangeMax) {
            var targetRange = targetRangeMax - targetRangeMin;
            var sourceRange = sourceRangeMax - sourceRangeMin;
            return (value - sourceRangeMin) * targetRange / sourceRange + targetRangeMin;
        }
        function shuffle(array) {
            for (let i = array.length - 1; i > 0; i--) {
                let j = Math.floor(crypto.getRandomValues(byteArray)[0] * (i + 1));
                j = Math.floor(getScaledValue(j, Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER, 0, i));
                const temp = array[i];
                array[i] = array[j];
                array[j] = temp;
            }
            return array;
        }
        const optionsString = question?.match(/\[.+?\]/g);
        const newStr = question?.replace(/\[(.+?)\]/g, "^");
        const replaceDrop = newStr?.split("^");
        return <div className="flex">
            {replaceDrop?.map((e, index) => {
                let options;
                let optionsValue = [{ text: "Select Value", value: "" }], tempOptionsfull;
                if (optionsString?.[index] != undefined)
                    tempOptionsfull = optionsString?.[index].substring(1, optionsString?.[index].length - 1);
                if (tempOptionsfull != undefined) {
                    options = tempOptionsfull.split("|");
                    fillUps.current = { ...fillUps.current, [id]: { ...fillUps.current?.[id], [index]: options[0] } };

                    const shuffled = shuffle(options);
                    shuffled.map(e => {
                        optionsValue = [...optionsValue, { text: e, value: e }];
                    });
                }

                return (
                    <div className="px-2 flex" key={index}><NVLlabel className="nvl-Def-Label">{e != "" && e}</NVLlabel>
                        {tempOptionsfull != undefined && <NVLSelectField id={id + "-" + index} className="w-48 p-2" options={optionsValue} errors={errors} register={register} />}
                    </div>);
            }
            )
            }
        </div>;
    }, [errors, register]);
    
    const QuizTypesOfFiles = useCallback(() => {

        let tempjson,previewJson
        if (CourseEnrollData != undefined) {
            previewJson = JSON.parse(CourseEnrollData?.QuestionandOptions != undefined ? CourseEnrollData?.QuestionandOptions : "{}")?.[ActivityData.ActivityID]?.Answer
             delete previewJson["PreviousAttempts"];
             delete previewJson["QuizStartTime"]
             delete previewJson["QuizEndTime"]
             tempjson = previewJson
        }
        else {
           previewJson = JSON.parse(RetainData?.QuizCompletion)
           delete previewJson["PreviousAttempts"];
           delete previewJson["QuizStartTime"]
           delete previewJson["QuizEndTime"]
           tempjson = previewJson
        }
        if (Object.keys(tempjson).length > 0) {
            const attempts = Object.keys(tempjson);
            return (
                <>{
                    attempts.map((attemptsNumber,index) => {
                        const temp = tempjson?.[attemptsNumber];
                        return (
                            <Fragment key={crypto.randomUUID()}>
                                <div key={index}>
                                {(ActivityData?.IsShowAnswer || ActivityData?.IsShowBothAnswer || ActivityData?.IsHideTheQuestions)
                                 && <div> Attempt Number: {attemptsNumber} </div>}
                                    {temp?.length > 0 && temp?.map((getQuestion, index) => {
                                        if (ActivityData?.IsShowAnswer || ActivityData?.IsShowBothAnswer || ActivityData?.IsHideTheQuestions) {
                                            if ((ActivityData?.IsHideTheQuestions) && (getQuestion?.YourMark == getQuestion?.TotalMark)) {
                                                return "";
                                            } else {
                                                return (
                                                    <Fragment key={crypto.randomUUID()}>
                                                        <AnswerPreview ActivityData={ActivityData} getQuestion={getQuestion} index={index} errors={errors} register={register} watch={watch} QuestionType={getQuestion?.QuestionType} BindFillups={bindFillups} />
                                                    </Fragment>);
                                            }
                                        }
                                    })}
                                </div>
                            </Fragment>);
                    })}
                </>
            );
        }
        else {
            return <></>;
        }
    }, [ActivityData, bindFillups, CourseEnrollData, RetainData?.QuizCompletion, errors, register, watch]);

    return (
        <div className='pointer-events-none'>
            <QuizTypesOfFiles />

        </div>
    );
}