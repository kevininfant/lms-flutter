import Container from "@components/Container/Container";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useCallback, useEffect, useMemo, useState } from "react";
import { getXlmsEnrollUser, listXlmsLanguages } from "src/graphql/queries";

import NVLProgressBar from "@components/Controls/NVLProgressBar";
import NVLlabel from "@components/Controls/NVLlabel";
import { useRouter } from "next/router";
import UserConsumeList from "./UserConsumeList";

function UserConsume(props) {

    const router = useRouter();
    const [csrFetchedData, setCsrFetchedData] = useState({ ...props });
    useEffect(() => {
        const dataSource = async () => {
            const tenantId = props.user.attributes["custom:tenantid"];
            const sub = props.user.attributes["sub"];
            const activityId = decodeURIComponent(String(router.query["ActivityID"]));
            const activityType = decodeURIComponent(String(router.query["ActivityType"]));
            const tenantResponse = await AppsyncDBconnection(
                getXlmsEnrollUser,
                {
                    PK: "TENANT#" + tenantId + "#ACTIVITY#ENROLLUSER#" + sub,
                    SK: "ACTIVITYID#" + activityId,
                },
                props.user?.signInUserSession?.accessToken?.jwtToken
            );
            const recordContentDataLanguage = await AppsyncDBconnection(listXlmsLanguages, { PK: "XLMS#LANGUAGE", SK: "LANGUAGE#LANGUAGENAME" }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const activityResponse = await AppsyncDBconnection(
                getXlmsEnrollUser,
                {
                    PK: "TENANT#" + tenantId + "#" + tenantResponse?.res?.getXlmsEnrollUser?.Shard,
                    SK: "ACTIVITYTYPE#" + activityType + "#ACTIVITYID#" + activityId,
                },
                props.user?.signInUserSession?.accessToken?.jwtToken
            );
            setCsrFetchedData((temp) => {
                return ({
                    ...temp,
                    TenantId: tenantId,
                    LanguageName: recordContentDataLanguage?.res?.listXlmsLanguages,
                    EnrollData: tenantResponse?.res?.getXlmsEnrollUser,
                    ActivityData: activityResponse?.res?.getXlmsEnrollUser
                });
            });
        };
        dataSource();
        return (() => {
            setCsrFetchedData((Data) => { return { ...Data }; });
        });

    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query]);

    const [open, setOpen] = useState(true);
    const completed =useMemo(()=>{return (csrFetchedData?.EnrollData?.CompletedStatus != undefined) ? csrFetchedData?.EnrollData?.CompletedStatus : "0";},[csrFetchedData?.EnrollData?.CompletedStatus]);


    const sortUsingPostion = useCallback((QuesAns) => {
        if (Object.values(QuesAns).length > 0) {
            var sorted = Object.values(QuesAns).sort(function (a, b) {
                return a.Position - b.Position;
            });
            return sorted;
        }
        return [];
    }, []);
    // Bread Crumbs
    const pageRoutes = useMemo(() => {
        return [
            { path: "/MyLearning/LearningDashboard?parameters=4", breadcrumb: "My Learning" },
            { path: "", breadcrumb: `My Activity${csrFetchedData?.ActivityData?.ActivityName && " - " + csrFetchedData?.ActivityData?.ActivityName}` }
        ];},[csrFetchedData?.ActivityData?.ActivityName]);

    return (
        <Container PageRoutes={pageRoutes} loader={csrFetchedData?.TenantId == undefined} >
            <div className="flex">
                <div className="container mx-auto">
                    <section className="text-gray-600 grid body-font gap-2 ">
                        <UserConsumeList props={csrFetchedData} LanguageName={csrFetchedData.LanguageName} EnrollData={csrFetchedData.EnrollData} ActivityData={csrFetchedData.ActivityData} sortusingpostion={sortUsingPostion} QuesTemplate={csrFetchedData?.ActivityData?.QuestionandOptions != undefined && JSON.parse(csrFetchedData?.ActivityData?.QuestionandOptions)} />
                    </section>
                </div>
            </div>
        </Container>
    );
}

export default UserConsume;
