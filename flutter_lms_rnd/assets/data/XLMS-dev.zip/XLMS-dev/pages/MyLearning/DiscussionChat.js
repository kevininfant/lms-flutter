import Container from "@components/Container/Container";

import NVLButton from "@components/Controls/NVLButton";
import NVLImage from "@components/Controls/NVLImage";
import NVLLink from "@components/Controls/NVLLink";
import NVLPageModalPopup from "@components/Controls/NVLPageModalPopup";
import UploadAttachments from "@Pages/MyLearning/UploadAttachments";
import { API } from "aws-amplify";
import { APIGatewayPostRequest, AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createXlmsCourseDiscussionChatMessage, createXlmsCourseDiscussionChatUserView, createXlmsDiscussionChatMessage, createXlmsDiscussionChatUserView, updateXlmsCourseDiscussionChatMessage, updateXlmsCourseDiscusssionChatAtomicCount, updateXlmsCourseEnrollUser, updateXlmsDiscussionChatAtomicCount, updateXlmsDiscussionChatMessage, updateXlmsEnrollUser } from "src/graphql/mutations";
import { getXlmsCourseDiscussionChatInfo, getXlmsCourseEnrollUser, getXlmsDiscussionChatInfo, getXlmsEnrollUser, listXlmsCourseDiscussionChatMessage, listXlmsCourseModule, listXlmsDiscussionChatMessage } from "src/graphql/queries";
import { onCreateXlmsCourseDiscussionChatMessage, onCreateXlmsDiscussionChatMessage } from "src/graphql/subscriptions";

const UploadAttachmentsComponent = React.forwardRef((props, ref) => (

    <UploadAttachments
        {...props}
        forwardedRef={ref}
    />
));
UploadAttachmentsComponent.displayName = "UploadAttachmentsComponent";

function DiscussionChat(props) {
    const router = useRouter();
    const routerRef = useRef({});
    const setSubscription = useRef(true);
    const messagesEnd = useRef();
    const [csrFetchedData, setCsrFetchedData] = useState({ ...props });
    const [chatMessage, setChatMessage] = useState();
    const textValue = useRef();
    const [open, setOpen] = useState(false);
    const [popupName, setPopupName] = useState("");
    useEffect(() => {
        const dataSource = async () => {
            routerRef.current = {
                TenantID: props.user.attributes["custom:tenantid"],
                UserSub: props.user.attributes["sub"],
                ActivityID: decodeURIComponent(String(router.query["ActivityID"])),
                TopicID: decodeURIComponent(String(router.query["TopicID"])),
                TopicName: decodeURIComponent(String(router.query["TopicName"])),
                CourseID: decodeURIComponent(String(router.query["CourseID"])),
                BatchID: decodeURIComponent(String(router.query["BatchID"])),
                ModuleID: decodeURIComponent(String(router.query["ModuleID"])),
            };
            let topicData = {};
            const discussionchatlist = await AppsyncDBconnection(listXlmsDiscussionChatMessage, { PK: "TENANT#" + routerRef.current.TenantID + "#ACTIVITY#" + routerRef.current.ActivityID, SK: "TOPIC#" + routerRef.current.TopicID + "#MESSAGETIME#", }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const currentQueryName = (routerRef.current.CourseID != "") ? getXlmsCourseDiscussionChatInfo : getXlmsDiscussionChatInfo;
            const getDiscussionSortKey = (routerRef.current.CourseID != "") ? "COURSEID#" + routerRef.current.CourseID + "#MODULE#" + routerRef.current.ModuleID + "#ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#" + routerRef.current.TopicID : "ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#" + routerRef.current.TopicID;
            const editTopicData = await AppsyncDBconnection(currentQueryName, { PK: "TENANT#" + routerRef.current.TenantID, SK: getDiscussionSortKey, }, props.user?.signInUserSession?.accessToken?.jwtToken);
            if (routerRef.current.CourseID != "") {
                topicData = editTopicData?.res?.getXlmsCourseDiscussionChatInfo;
            }
            else {
                topicData = editTopicData?.res?.getXlmsDiscussionChatInfo;
            }
            const userInfo = await AppsyncDBconnection(getXlmsEnrollUser, { PK: "TENANT#" + routerRef.current.TenantID + "#ACTIVITY#ENROLLUSER#" + routerRef.current.UserSub, SK: "ACTIVITYID#" + routerRef.current.ActivityID, }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const activityInfo = await AppsyncDBconnection(getXlmsEnrollUser, {
                PK: "TENANT#" + routerRef.current.TenantID + "#" + userInfo?.res?.getXlmsEnrollUser?.Shard,
                SK: "ACTIVITYTYPE#Discussion#ACTIVITYID#" + routerRef.current.ActivityID,
            }, props.user?.signInUserSession?.accessToken?.jwtToken);

            const courseEnrollData = await AppsyncDBconnection(getXlmsCourseEnrollUser, { PK: "TENANT#" + routerRef.current.TenantID + "#COURSE#ENROLLUSER#" + routerRef.current.UserSub, SK: "COURSE#" + routerRef.current.CourseID + "#BATCH#" + routerRef.current.BatchID, }, props.user?.signInUserSession?.accessToken?.jwtToken);
            const courseInfo = await AppsyncDBconnection(getXlmsCourseEnrollUser, {
                PK: "TENANT#" + routerRef.current.TenantID + "#" + courseEnrollData?.res?.getXlmsCourseEnrollUser?.Shard,
                SK: "COURSEID#" + routerRef.current.CourseID + "#MODULEID#" + routerRef.current.ModuleID + "#ACTIVITYTYPE#Discussion#ACTIVITYID#" + routerRef.current.ActivityID
            }, props.user?.signInUserSession?.accessToken?.jwtToken);
            let actData;
            if (routerRef.current.CourseID != "") {
                const activityVariable = { PK: "TENANT#" + routerRef.current.TenantID, SK: "COURSEID#" + routerRef.current.CourseID, IsDeleted: false };
                const actList = (await AppsyncDBconnection(listXlmsCourseModule, activityVariable, props.user?.signInUserSession?.accessToken?.jwtToken));
                actData = actList?.res?.listXlmsCourseModule?.items.filter((item) => item.ActivityID === routerRef.current.ActivityID)[0];
            }
            setCsrFetchedData({
                ActivityInfo: activityInfo?.res?.getXlmsEnrollUser,
                UserInfo: userInfo?.res?.getXlmsEnrollUser,
                CourseInfo: courseInfo?.res?.getXlmsCourseEnrollUser,
                CourseEnrollData: courseEnrollData?.res?.getXlmsCourseEnrollUser,
                TenantID: routerRef.current.TenantID,
                ActivityID: routerRef.current.ActivityID,
                TopicID: routerRef.current.TopicID,
                UserSub: routerRef.current.UserSub,
                MessageList: discussionchatlist.res.listXlmsDiscussionChatMessage?.items,
                Discussionchat: discussionchatlist.res.listXlmsDiscussionChatMessage?.items,
                CourseID: routerRef.current.CourseID,
                BatchID: routerRef.current.BatchID,
                ModuleID: routerRef.current.ModuleID,
                TopicName: routerRef.current.TopicName,
                ActivityData: routerRef.current.CourseID != "" && actData,
                TopicData: topicData,
            });


        };
        dataSource();
        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });

        });
    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, router.query]);


    const currentQuery = useMemo(() => {
        let currentquery = [];
        (csrFetchedData?.CourseEnrollData?.CourseId != null || csrFetchedData?.CourseEnrollData?.CourseId != undefined) ? (currentquery = [createXlmsCourseDiscussionChatMessage, onCreateXlmsCourseDiscussionChatMessage, updateXlmsCourseDiscussionChatMessage, listXlmsCourseDiscussionChatMessage]) : currentquery = [createXlmsDiscussionChatMessage, onCreateXlmsDiscussionChatMessage, updateXlmsDiscussionChatMessage, listXlmsDiscussionChatMessage];
        return currentquery;
    }, [csrFetchedData?.CourseEnrollData?.CourseId]);

    const queryName = useMemo(() => {
        let currentquery = [];
        (csrFetchedData?.CourseEnrollData?.CourseId != null || csrFetchedData?.CourseEnrollData?.CourseId != undefined) ? (
            currentquery = ["createXlmsCourseDiscussionChatMessage", "onCreateXlmsCourseDiscussionChatMessage", "updateXlmsCourseDiscussionChatMessage", "listXlmsCourseDiscussionChatMessage"]) :
            currentquery = ["createXlmsDiscussionChatMessage", "onCreateXlmsDiscussionChatMessage", "updateXlmsDiscussionChatMessage", "listXlmsDiscussionChatMessage"];
        return currentquery;
    }, [csrFetchedData?.CourseEnrollData?.CourseId]);

    const currentAttachmentStatus = useRef({});
    useMemo(() => {

        if (Object.keys(currentAttachmentStatus.current).length == 0 || csrFetchedData?.TopicID != undefined) {
            let temp = {};
            if (csrFetchedData?.CourseID != "") {
                temp = JSON.parse(csrFetchedData?.CourseEnrollData?.RemainingAttachmentBytes != undefined || csrFetchedData?.CourseEnrollData?.RemainingAttachmentBytes != null ? csrFetchedData?.CourseEnrollData.RemainingAttachmentBytes : "{}");
            }
            else {
                temp = JSON.parse(csrFetchedData?.UserInfo?.RemainingAttachmentBytes != undefined || csrFetchedData?.CourseEnrollData?.RemainingAttachmentBytes != null ? csrFetchedData?.UserInfo?.RemainingAttachmentBytes : "{}");

            }

            if (!(Object.keys(temp).includes(csrFetchedData?.TopicID))) {
                temp = {
                    ...temp, [csrFetchedData?.TopicID]: {
                        "Size": (csrFetchedData?.CourseID != "") ? csrFetchedData?.ActivityData?.MaxmumAttachmentSize : csrFetchedData?.ActivityInfo?.MaxmumAttachmentSize,
                        "NoOFAttachement": (csrFetchedData?.CourseID != "") ? csrFetchedData?.ActivityData?.MaximumNumberOfAttachment : csrFetchedData?.ActivityInfo?.MaximumNumberOfAttachment
                    }
                };

            }
            currentAttachmentStatus.current = temp;

        }
    }, [csrFetchedData?.ActivityData?.MaximumNumberOfAttachment, csrFetchedData?.ActivityData?.MaxmumAttachmentSize, csrFetchedData?.ActivityInfo?.MaximumNumberOfAttachment, csrFetchedData?.ActivityInfo?.MaxmumAttachmentSize, csrFetchedData?.CourseEnrollData?.RemainingAttachmentBytes, csrFetchedData?.CourseID, csrFetchedData?.TopicID, csrFetchedData?.UserInfo]);



    const updateSize = useCallback(async () => {
        const query = routerRef.current.CourseID != "" ? updateXlmsCourseEnrollUser : updateXlmsEnrollUser;
        const pkValue = routerRef.current.CourseID != "" ? csrFetchedData?.CourseEnrollData?.PK : csrFetchedData?.UserInfo?.PK;
        const skvalue = routerRef.current.CourseID != "" ? csrFetchedData?.CourseEnrollData?.SK : csrFetchedData?.UserInfo?.SK;
        let remainingAttachmentData = {};
        const temp = currentAttachmentStatus.current;
        remainingAttachmentData = { ...temp };
        const variables = { input: { PK: pkValue, SK: skvalue, RemainingAttachmentBytes: JSON.stringify(remainingAttachmentData) } };
        await AppsyncDBconnection(query, variables, props?.user?.signInUserSession?.accessToken?.jwtToken);

    }, [csrFetchedData?.CourseEnrollData?.PK, csrFetchedData?.CourseEnrollData?.SK, csrFetchedData?.UserInfo?.PK, csrFetchedData?.UserInfo?.SK, props?.user?.signInUserSession?.accessToken?.jwtToken]);

    const ref = useRef(1);
    useEffect(() => {
        async function temp() {
            if (props.TenantInfo.TenantID != undefined) {
                const query = routerRef.current.CourseID != "" ? createXlmsCourseDiscussionChatUserView : createXlmsDiscussionChatUserView;
                const userSubId = props.user.attributes["sub"];
                const topicId = csrFetchedData?.TopicID;
                const pk = ("TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#" + csrFetchedData?.ActivityID);
                const sk = ("TOPIC#" + csrFetchedData?.TopicID + "#USERSUB#" + userSubId);

                const discussionViewVariables = {
                    input: {
                        PK: pk,
                        SK: sk,
                        Date: "" + (new Date().toString() + ref.current),
                    }
                };
                ref.current = ref.current + 1;
                const finalStatus = await AppsyncDBconnection(query, discussionViewVariables, props.user.signInUserSession.accessToken.jwtToken);

                if (finalStatus.Status == "Success") {
                    const query1 = routerRef.current.CourseID != "" ? updateXlmsCourseDiscusssionChatAtomicCount : updateXlmsDiscussionChatAtomicCount;
                    const pkValue = ("TENANT#" + props.TenantInfo.TenantID);
                    const skvalue = (csrFetchedData?.CourseID != "" ? ("COURSEID#" + csrFetchedData?.CourseID + "#MODULE#" + csrFetchedData?.ModuleID + "#ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + topicId) : ("ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + topicId)),
                        discussionCountVariables = {
                            input: {
                                PK: pkValue,
                                SK: skvalue,

                            }
                        };
                    AppsyncDBconnection(query1, discussionCountVariables, props.user.signInUserSession.accessToken.jwtToken);
                }
            }
        }


        if (csrFetchedData?.TopicData?.UserSub != undefined && csrFetchedData?.TopicData?.UserSub != props.user.attributes["sub"]) {

            temp();
        }


    }, [csrFetchedData?.ActivityID, csrFetchedData?.CourseID, props.TenantInfo.TenantID, csrFetchedData?.TopicData?.UserSub, csrFetchedData?.TopicID, csrFetchedData.UserSub, props.UserSubID, props.mode, props.user.attributes, props.user.signInUserSession.accessToken.jwtToken, csrFetchedData?.ModuleID]);

    {/* Update View Count */ }
    useEffect(() => {
        var mytky = [];
        if (csrFetchedData?.MessageList != undefined) {
            mytky = DistinctRecords(csrFetchedData?.MessageList, "UserSub");
            function DistinctRecords(MYJSON, prop) {
                return MYJSON.filter((obj, pos, arr) => {
                    return arr.map(mapObj => mapObj[prop]).indexOf(obj[prop]) === pos;
                });
            }
            const discussionVariables = {
                input: {
                    PK: ("TENANT#" + props.TenantInfo.TenantID),
                    SK: ("ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + csrFetchedData?.TopicID),
                    View: mytky.length
                }
            };
            AppsyncDBconnection(currentQuery[2], discussionVariables, props.user.signInUserSession.accessToken.jwtToken);
        }
    }, [currentQuery, csrFetchedData?.ActivityID, csrFetchedData?.MessageList, props.TenantInfo.TenantID, csrFetchedData?.TopicID, props.user.signInUserSession.accessToken.jwtToken]);

    useEffect(() => {
        if (csrFetchedData?.ActivityID != undefined) {
            messageDataBind();
            const messagebody = document.getElementById("Parentdiv");
            messagebody.scrollTop = messagebody?.scrollHeight;
        }
    }, [csrFetchedData?.ActivityID, messageDataBind]);

    const subscribedcall = useCallback(async () => {
        if (csrFetchedData?.TopicID != undefined && props.TenantInfo.TenantID != undefined && setSubscription.current) {
            const pkValue = "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + csrFetchedData?.TopicID;

            API.graphql({
                variables: { PK: pkValue },
                query: currentQuery[1],
                authMode: "AWS_LAMBDA",
                authToken: props.user.signInUserSession.accessToken.jwtToken
            },
                { "Authorization": props.user.signInUserSession.accessToken.jwtToken }).subscribe(
                    {
                        next: (result) => {
                            if (result?.value?.data?.[queryName[1]] != undefined) {
                                const temp = result?.value?.data?.[queryName[1]];
                                setChatMessage((data) => {
                                    return [...data, temp]
                                });
                                messagesEnd.current?.scrollIntoView({ behavior: "smooth" });
                            }
                        }
                    });
            setSubscription.current = false;
        }
    }, [csrFetchedData?.ActivityID, csrFetchedData?.TopicID, currentQuery, props.TenantInfo.TenantID, props.user.signInUserSession.accessToken.jwtToken, queryName]);

    useEffect(() => {
        subscribedcall();
    }, [subscribedcall]);

    const messageDataBind = useCallback(async () => {
        if (csrFetchedData?.ActivityID != undefined) {
            const response = await AppsyncDBconnection(currentQuery[3], {
                PK: "TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#" + csrFetchedData?.ActivityID+"#TOPIC#" + csrFetchedData?.TopicID,
                SK: "TOPIC#" + csrFetchedData?.TopicID + "#MESSAGETIME#",
            }, props.user.signInUserSession.accessToken.jwtToken
            );
            const element = response?.res?.[queryName[3]]?.items;
            if (element?.length != undefined) {
                setChatMessage(element);
                messagesEnd.current?.scrollIntoView({ behavior: "smooth" });
            }
        }
    }, [currentQuery, queryName, csrFetchedData?.ActivityID, props.TenantInfo.TenantID, csrFetchedData?.TopicID, props.user.signInUserSession.accessToken.jwtToken]);
    {/*Sender Message and Save Message Content */ }

    const sendMesage = useCallback(async (FileUrl, FileType, Mode,) => {
        if (textValue.current.value.trim() == "" && Mode != "Popup") {
            return;
        }
        const query = currentQuery[0];
        const messageId = crypto.randomUUID();
        const skValue = ("TOPIC#" + csrFetchedData?.TopicID + "#MESSAGETIME#" + new Date() + "#MESSAGE#" + messageId);
        const pkValue = ("TENANT#" + props.TenantInfo.TenantID + "#ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + csrFetchedData?.TopicID);

        const discussionVariables = {
            input: {
                PK: pkValue,
                SK: skValue,
                Message: textValue.current.value,
                UserSub: props.user?.attributes["sub"],
                UserName: props.user.username,
                DateTime: (new Date()),
                File: FileUrl != "NIL" ? FileUrl : null,
                IsDelete: false,
                TopicID: csrFetchedData?.TopicID,
                TenantID: props.TenantInfo.TenantID,
                ActivityID: csrFetchedData?.ActivityID,
                FileType: FileType == undefined ? "Text" : FileType,
            }
        };
        AppsyncDBconnection(query, discussionVariables, props?.user?.signInUserSession?.accessToken?.jwtToken).then((res) => {
            if (res?.Status == "Success") {
                textValue.current.value = "";
            }
        });
    }, [currentQuery, csrFetchedData?.ActivityID, props.TenantInfo.TenantID, csrFetchedData?.TopicID, props.user?.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, props.user.username]);


    const SenderReceiver = useCallback(({ chatMessageBind }) => {
        const rowGrid = [];
        for (let i = 0; i < chatMessageBind?.length; i++) {
            const message = chatMessageBind[i]?.UserSub == props?.user?.attributes["sub"];
            rowGrid.push(<div><SenderReceiverConversation
                Sender={(message && chatMessageBind[i]?.FileType == "Text") ? chatMessageBind[i].Message : (message && chatMessageBind[i]?.FileType != "Text") ? "NotText" : undefined}
                Receiver={(!message && chatMessageBind[i]?.FileType == "Text") ? chatMessageBind[i].Message : (!message && chatMessageBind[i]?.FileType != "Text") ? "NotText" : undefined}
                chatMessage={chatMessageBind[i]}
                FileType={chatMessageBind[i]?.FileType}
                File={chatMessageBind[i]?.File}
            />
            </div>);
        }
        return <>{rowGrid}</>;

    }, [props?.user?.attributes]);

    const upload = () => {
        setPopupName("Upload");
        setOpen((open) => {
            return open + 1;
        });
    };
    const getComponent = useCallback(
        (PopupName) => {
            const componentData = {
                Upload: (
                    <UploadAttachmentsComponent
                        setOpen={setOpen}
                        open={open}
                        props={props}
                        Data={csrFetchedData}
                        ref={currentAttachmentStatus}
                        Mode="Popup"
                        SendMesage={sendMesage}
                        Updatesize={updateSize}
                        RedirectMode={csrFetchedData?.CourseID == "" ? "Activity" : "Course"}
                        TopicID={csrFetchedData?.TopicID}
                    />
                ),
            };
            return componentData[PopupName];
        },
        [csrFetchedData, sendMesage, updateSize, open, props]
    );

    const SenderReceiverConversation = useCallback(({ Receiver, Sender, FileType, File }) => {
        const getContentType = (Extension) => {
            switch (Extension) {
                case "mkv":
                    return "video/x-matroska";
                case "avi":
                    return "video/x-ms-video";
                case "mov":
                    return "video/quicktime";
                case "wmv":
                    return "video/x-ms-wmv";
                case "mp4":
                    return "video/mp4";
                case "mpeg4":
                    return "video/mpeg4";
                case "txt":
                    return "text/plain";
                case "xls":
                    return "application/vnd.ms-excel";
                case "ppt":
                    return "application/vnd.ms-powerpoint";
                case "pptx":
                    return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                case "xlsx":
                    return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                case "tar":
                    return "application/x-tar";
                case "rar":
                    return "application/vnd.rar";
                case "h5p":
                    return "application/octet-stream";
                default:
                    return "application/" + Extension;
            }
        };
        async function DownloadFiles(url) {
            const downloadUrl = url.slice(1);
            const ext = File.substring(File.lastIndexOf(".") + 1).toLowerCase();
            const contentType = ext == "csv" ? "text/" + ext : ext == "jpeg" || ext == "jpg" || ext == "png" ? "image/" + ext
                : getContentType(ext);
            const fetchURL = process.env.APIGATEWAY_INVOKEURL;
            const headers = {
                method: "POST",
                headers: {
                    "Content-Type": contentType,
                    authorizationtoken: props.user.signInUserSession.accessToken.jwtToken,
                    bucketName: props.TenantInfo.BucketName,
                },
                body: downloadUrl,
            };


            if (ext != "txt") {
                const finalStatus = await APIGatewayPostRequest(fetchURL, headers);
                const finalResponse = await finalStatus.res.text();
                window.open(finalResponse, "_blank");
            } else {
                var file_path = url;
                var a = document.createElement("A");
                a.href = file_path;
                a.download = file_path.substr(file_path.lastIndexOf("/") + 1);
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);

            }
        }
        let extension;
        if (File?.includes(".")) {
            extension = File.substring(File.lastIndexOf(".") + 1).toLowerCase();
        }
        return (
            <>
                {Receiver && <div id="Reciever" className="flex flex-col space-y-4 p-3 overflow-y-auto scrollbar-thumb-blue scrollbar-thumb-rounded scrollbar-track-blue-lighter scrollbar-w-2 scrolling-touch">
                    <div className="flex items-start justify-start">
                        <div className="flex flex-col space-y-2 text-xs max-w-xs mx-2 order-1 items-end">
                            <div>

                                {FileType == "Text" && <div className="break-all">
                                    <span className={`p-3 py-2 rounded-lg inline-block rounded-br-none bg-blue-600 text-white`}>{Receiver}</span>
                                </div>}
                                {FileType == "Image" &&
                                    <div>
                                        <NVLImage className="cursor-pointer" src={File} alt="Image" onClick={() => DownloadFiles(File)} title="Image" height={100} width={100} tabIndex={8} />
                                    </div>
                                }

                                <div className="flex items-center">
                                    <i className={`${FileType == "Video" ? "fa fa-video-camera text-blue-500" :
                                        (extension == "xls" || extension == "xlsx" || extension == "csv") ? "fa fa-file-excel-o text-green-400" :
                                            (extension == "ppt" || extension == "pdf" || extension == "pptx") ? "fa fa-file-powerpoint-o text-red-500" :
                                                (extension == "doc" || extension == "docx") ? "fa fa-file-word-o text-blue-400" :
                                                    (extension == "zip" || extension == "rar" || extension == "tar") ? "fa fa-file-archive-o text-gray-500" :
                                                        extension == "txt" ? "fa fa-file-text-o text-gray-400" :
                                                            ""} text-xl cursor-pointer`} aria-hidden="true"></i>
                                    {(File && FileType != "Image") && File?.substring(File?.lastIndexOf("/") + 1) != "The specified key does not exist." && <div>
                                        <NVLLink className={`font-normal cursor-pointer "text-red-500" : "text-blue-500"`} onClick={() => DownloadFiles(File)} text={File && File?.substring(File?.lastIndexOf("/") + 1)}></NVLLink>
                                    </div>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>}
                {Sender && <div id="sender" className="flex flex-col space-y-4 p-3 overflow-y-auto scrollbar-thumb-blue scrollbar-thumb-rounded scrollbar-track-blue-lighter scrollbar-w-2 scrolling-touch">
                    <div className="flex items-end justify-end">
                        <div className="flex flex-col space-y-2 text-xs max-w-xs mx-2 order-1 items-end">
                            <div>
                                {FileType == "Text" && <div className="break-all">
                                    <span className={`p-3 py-2 rounded-lg inline-block rounded-br-none bg-green-600 text-white`}>{Sender}</span>
                                </div>}
                                {FileType == "Image" &&
                                    <div>
                                        <NVLImage className="cursor-pointer" src={File} alt="Image" onClick={() => DownloadFiles(File)} title="Image" height={100} width={100} tabIndex={8} />
                                    </div>
                                }

                                <div className=" flex items-center">
                                    <i className={`${FileType == "Video" ? "fa fa-video-camera text-blue-500" :
                                        (extension == "xls" || extension == "xlsx" || extension == "csv") ? "fa fa-file-excel-o text-green-400" :
                                            (extension == "ppt" || extension == "pdf" || extension == "pptx") ? "fa fa-file-powerpoint-o text-red-500" :
                                                (extension == "doc" || extension == "docx") ? "fa fa-file-word-o text-blue-400" :
                                                    (extension == "zip" || extension == "rar" || extension == "tar") ? "fa fa-file-archive-o text-gray-500" :
                                                        extension == "txt" ? "fa fa-file-text-o text-gray-400" :
                                                            ""} text-xl cursor-pointer`} aria-hidden="true"></i>
                                    {(File && FileType != "Image") && File?.substring(File?.lastIndexOf("/") + 1) != "The specified key does not exist." && <div>
                                        <NVLLink className={`font-normal cursor-pointer "text-red-500" : "text-blue-500"`} onClick={() => DownloadFiles(File)} text={File && File?.substring(File?.lastIndexOf("/") + 1)}></NVLLink>
                                    </div>}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>}
            </>
        );
    }, [props.TenantInfo.BucketName, props.user.signInUserSession.accessToken.jwtToken]);
    let pageRoutes = [];
    if (csrFetchedData?.CourseID == "" || csrFetchedData?.CourseID == undefined) {
        pageRoutes = [
            { path: "/MyLearning/LearningDashboard?parameters=4", breadcrumb: "My Learning" },
            { path: `/MyLearning/UserConsume?Mode=Start&ActivityID=${csrFetchedData?.ActivityID}&ActivityType=Discussion`, breadcrumb: `My Activity - ${csrFetchedData?.ActivityInfo?.ActivityName}` },
            { path: "", breadcrumb: csrFetchedData?.TopicName }
        ];
    } else {
        pageRoutes = [
            { path: "/MyLearning/LearningDashboard?parameters=1", breadcrumb: "My Learning" },
            { path: `/MyLearning/CourseConsume?CourseID=${csrFetchedData?.CourseID}&ActivityID=${csrFetchedData?.ActivityData?.ActivityID}&BatchId=${csrFetchedData?.BatchID}`, breadcrumb: `${decodeURIComponent(String(router.query["CourseName"]))} - ${csrFetchedData?.ActivityData?.ModuleName} - ${csrFetchedData?.ActivityData?.ActivityName}` },
            { path: "", breadcrumb: csrFetchedData?.TopicName }
        ];
    }

    const AttachmentHandler = useCallback(() => {
        return (
            <>
                <i className={`fa fa-paperclip text-xl text-blue-500 ${((currentAttachmentStatus.current?.[csrFetchedData?.TopicID]?.Size <= "0" || currentAttachmentStatus.current?.[csrFetchedData?.TopicID]?.NoOFAttachement == "0")) && "Disabled text-gray-400"}`} aria-hidden="true" onClick={() => upload()}></i>
            </>
        );
    }, [csrFetchedData?.TopicID]);

    return (
        <>
            <NVLPageModalPopup
                ModalType="Page"
                ScreenName={`Upload`}
                PageComponent={getComponent(popupName)}
                open={open}
                setOpen={setOpen}
            />
            <Container PageRoutes={pageRoutes} loader={csrFetchedData?.TenantID == undefined}>

                <div className="relative bg-slate-100 rounded">
                    {
                        props.DiscussionMessage?.Subject && <>
                            <div className=" flex justify-end gap-4 obsolute bottom-2">
                            </div>
                            <div>
                                <NVLLink text={(props?.DiscussionMessage?.Subject)} onClick={() =>
                                    router.push(`/ MyLearning / DiscussionChat ? TopicID = ${props?.TopicID}`)} className="font-Montserrat text-sm font-bold uppercase">
                                </NVLLink>
                                <i className="fa fa-eye text-lg  flex justify-end gap-4 obsolute bottom-2  "></i>
                            </div>
                        </>
                    }
                    <div className="text-xs font-normal bg-blue-100 p-3 rounded-md flex gap-4 pl-4 items-center"  >
                        <div className=" text-sm font-semibold">About Us Description  :</div>
                        <div>{(router.query["Description"])}</div>

                    </div>
                    <div id="Parentdiv" className={`p-2 rounded-xl border-gray-200 min-h-[350px] max-h-[350px] mx-auto bg-slate-50 overflow-auto `}>
                        <SenderReceiver chatMessageBind={chatMessage} />
                        <div className={`p-2`} ref={messagesEnd}></div>
                    </div>

                    <div className="border-t-2 border-gray-200 px-4 pt-4 mb-2 sm:mb-0 rounded-md p-4 text-xs">
                        <div className="relative flex">
                            <input onKeyUp={(e) => {
                                if (e.key === "Enter") {
                                    sendMesage();
                                }
                            }} type="text" placeholder="Write your Message " ref={textValue}
                                className="w-full focus:outline-none focus:placeholder-gray-400 text-gray-600 placeholder-gray-600 pl-6 bg-gray-200 rounded-md py-2 pr-32" />
                            <div className="absolute right-0 items-center inset-y-0 hidden sm:flex">
                                {AttachmentHandler()}
                                <NVLButton type="submit" id="sendbtn" onClick={() => sendMesage()} className="inline-flex items-center justify-center rounded-md px-2 py-1 m-4 transition duration-500 ease-in-out text-white bg-blue-500 hover:bg-blue-400 focus:outline-none ">
                                    <span className="font-light ">Send <i className="fa fa-paper-plane"></i> </span>
                                </NVLButton>
                            </div>
                        </div>
                    </div>

                </div >
            </Container>
        </>
    );
}

export default DiscussionChat;

