import NVLButton from "@components/Controls/NVLButton";
import NVLGridCard from "@components/Controls/NVLGridCard";
import NVLGridTable from "@components/Controls/NVLGridTable";
import NVLProgressBar from "@components/Controls/NVLProgressBar";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useMemo } from "react";
import { getXlmsBatchEnrollUser, listXlmsEnrollUser } from "src/graphql/queries";
import NVLlabel from "../../components/Controls/NVLlabel";

export default function ActivityEnrollList(props) {
    const router = useRouter();
    const headerColumn = useMemo(() => {
        return [{ HeaderName: "", Columnvalue: "ActivityType", HeaderCss: "w-6/12 " }, { HeaderName: "", Columnvalue: "ActivityProgress", HeaderCss: "w-3/12 ", }, { HeaderName: "", Columnvalue: "ActivityAction", HeaderCss: "w-3/12 ", }];
    }, []);

    const activityList = useMemo(() => {
        return {
            Name: "listXlmsEnrollUser",
            query: listXlmsEnrollUser,
            variable: { PK: "TENANT#" + props?.TenantInfo?.TenantID + "#ACTIVITY#ENROLLUSER#" + props?.sub, SK: "ACTIVITYID#", IsSuspend: false },
        };
    }, [props?.TenantInfo?.TenantID, props?.sub]);

    const gridDataBind = useCallback(async (activityData) => {
        const icon = (item) => {
            let symbol = "";
            switch (item) {
                case "Discussion":
                    symbol = "fa fa-comments-o"
                    break;
                case "Video":
                    symbol = "fa fa-video"
                    break;
                case "Url":
                    symbol = "fa-solid fa-link"
                    break;
                case "Page":
                    symbol = "fa-regular fa-file"
                    break;
                case "File":
                    symbol = "fa-solid fa-file-lines"
                    break;
                case "Feedback":
                    symbol = "fa-solid fa-paper-plane"
                    break;
                case "ScormPackage":
                    symbol = "fa-solid fa-photo-film"
                    break;
                case "Quiz":
                    symbol = "fa-sharp fa-solid fa-person-chalkboard"
                    break;
                case "Assignment":
                    symbol = "fa-solid fa-book-open-reader"
                    break;
                default:
                    symbol = "fa fa-tasks"
            }
            return symbol;
        }, rowGrid = [], variables = [];

        for (let i = 0; i < activityData?.length; i++) {
            variables = [...variables, { PK: "TENANT#" + activityData[i].TenantID + "#" + activityData[i].Shard, SK: "ACTIVITYTYPE#" + activityData[i].ActivityType + "#ACTIVITYID#" + activityData[i].ActivityID }]
        }
        const editDatalisttemp = await AppsyncDBconnection(getXlmsBatchEnrollUser, { input: variables }, props?.user?.signInUserSession?.accessToken?.jwtToken);
        
        let SK = {};
        for (let i = 0; i < editDatalisttemp?.res?.getXlmsBatchEnrollUser?.length; i++) {
            if (editDatalisttemp?.res?.getXlmsBatchEnrollUser[i].SK != undefined && editDatalisttemp?.res?.getXlmsBatchEnrollUser[i].IsSuspend == false) {
                SK = { ...SK, [editDatalisttemp?.res?.getXlmsBatchEnrollUser[i].SK]: { ...editDatalisttemp?.res?.getXlmsBatchEnrollUser[i] } }
            }
        }
        for (let i = 0; (i < activityData?.length)&&(props?.row?props?.row>i:true); i++) {
            let tempSK = "ACTIVITYTYPE#" + activityData[i].ActivityType + "#ACTIVITYID#" + activityData[i].ActivityID, isDisabled;
            if (SK?.[tempSK] != undefined) {
                if (SK?.[tempSK]?.EndDate == "" || SK?.[tempSK]?.EndDate == undefined || SK?.[tempSK]?.EndDate == null || new Date(SK?.[tempSK]?.EndDate) >= new Date()) {
                    if (SK?.[tempSK]?.StartDate == "" || SK?.[tempSK]?.StartDate == undefined || new Date(SK?.[tempSK]?.StartDate) == null || new Date(SK?.[tempSK]?.StartDate) <= new Date()) {
                        isDisabled = false;
                    } else { isDisabled = true; }
                } else { isDisabled = true; }
                rowGrid.push({
                    ActivityType: (
                        <NVLGridCard key={"card" + i} Name={SK?.[tempSK]?.ActivityType == "ScormPackage" ? "SCORM Package" : SK?.[tempSK]?.ActivityType} ThumbNailPath={SK?.[tempSK]?.ThumbNailPath != undefined ? SK?.[tempSK]?.ThumbNailPath : ""} Icon={SK?.[tempSK]?.ThumbNailPath != undefined ? "" : icon(SK?.[tempSK]?.ActivityType)} ActivityName={SK?.[tempSK]?.ActivityName}></NVLGridCard>
                    ),
                    ActivityProgress: (
                        <div key={"progress" + i}>
                            <NVLlabel className="text-gray-900  font-medium title-font tracking-wider pb-1">
                                {" "}    Progress &nbsp;{" "}    {`(${activityData[i].CompletedStatus > 0 ? Math.round(activityData[i].CompletedStatus) : "0"}%)`}
                            </NVLlabel>
                            <div className="">
                                
                                <NVLProgressBar text="Progress" 
                                bgcolor={activityData[i].CompletedStatus > "0" ? activityData[i].CompletedStatus < 100 ? "#F47623" : SK?.[tempSK]?.IsActivityCompletion ? "#1D74FF" : "#9333ea " : "#AEB9DE"} progress={activityData[i].CompletedStatus > 0 ? activityData[i].CompletedStatus : "0"} />
                            </div>
                        </div>
                    ),
                    ActivityAction: (
                        <div key={"action" + i} className="lg:mb-0 mb-6 ">
                            <div className="h-full flex gap-4 float-right">
                                <NVLButton disabled={isDisabled} ButtonType={activityData[i].CompletedStatus > "0" ? activityData[i].CompletedStatus < 100 ? "continue" : SK?.[tempSK]?.IsActivityCompletion ? "completed" : "learnagain" : "start"} text={activityData[i].CompletedStatus > "0" ? activityData[i].CompletedStatus < 100 ? "In Progress" : SK?.[tempSK]?.IsActivityCompletion ? "Completed" : "Learn Again" : "Start"} className={`${isDisabled ? "opacity-40" : ""}  w-44`} onClick={() => { router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${SK?.[tempSK]?.ActivityID}&ActivityType=${SK?.[tempSK]?.ActivityType}`); }} />
                            </div>
                        </div>
                    ),
                })
            }
        }
        return rowGrid;
    }, [props?.row, props?.user?.signInUserSession?.accessToken?.jwtToken, router]);
    const viewMoreAction = useMemo(() => {
        return { ListOfCount: props?.row, IsNavigation: true, Link: <div onClick={() => router.push(`/MyLearning/LearningDashboard?parameters=4`)} className="nvl-Def-Label whitespace flex justify-end text-[#0E4681] underline cursor-pointer">All Activities</div> }
    }, [props?.row, router])
    return (
        <>
            <NVLGridTable viewMoreAction={viewMoreAction} DonotLoad={true} setPagezero={props.openTab} refershPage={true} user={props?.user} id="tblCourseList" HeaderColumn={headerColumn} GridDataBind={gridDataBind} query={listXlmsEnrollUser} querryName={"listXlmsEnrollUser"} variable={activityList.variable} />         
        </>
    );
}