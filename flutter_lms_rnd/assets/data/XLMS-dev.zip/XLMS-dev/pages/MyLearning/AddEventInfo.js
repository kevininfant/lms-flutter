import NVLTextbox from "@components/Controls/NVLTextBox";
export default function AddEventInfo(props) {
    return (
        <>
            <div className='grid gap-5'>
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="Event Title" id="txtEventTitle" placeholder={"Template Name"} className="nvl-mandatory w-full" register={props.register} errors={props.errors} />
                {props.EventDate}
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="Course" id="txtCourse" placeholder={"Course"} className="nvl-mandatory w-full" register={props.register} errors={props.errors} />
                <NVLTextbox labelClassName="nvl-Def-Label" labelText="Types of Event" id="txtTypeOfEvent" placeholder={"Height"} className="nvl-mandatory w-full" register={props.register} errors={props.errors} />
            </div>
        </>
    );
}