import Container from "@components/Container/Container";
import NVLAlert, { ModalOpen } from "@components/Controls/NVLAlert";
import NVLButton from "@components/Controls/NVLButton";
import NVLlabel from "@components/Controls/NVLlabel";
import NVLMultilineTxtbox from "@components/Controls/NVLMultilineTxtBox";
import NVLTextbox from "@components/Controls/NVLTextBox";
import { yupResolver } from "@hookform/resolvers/yup";
import { AppsyncDBconnection } from "DBConnection/ErrorResponse";
import { useRouter } from "next/router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useForm } from "react-hook-form";
import { WithContext as ReactTags } from "react-tag-input";
import { Regex } from "RegularExpression/Regex";
import { createXlmsCourseDiscussionChat, createXlmsDiscussionChat, updateXlmsCourseDiscussionChat, updateXlmsDiscussionChat } from "src/graphql/mutations";
import { getXlmsActivityManagementInfo, getXlmsCourseDiscussionChatInfo, getXlmsDiscussionChatInfo, listXlmsCourseDiscussionChat, listXlmsCourseDiscussionChatNameExits, listXlmsCourseModule, listXlmsDiscussionChat, listXlmsDiscussionChatNameExits } from "src/graphql/queries";
import * as Yup from "yup";

function CreateTopic(props) {
    const router = useRouter();
    const routerRef = useRef();
    const [csrFetchedData, setCsrFetchedData] = useState({});
    let initialModalState;
    useEffect(() => {
        const dataSource = async () => {
            routerRef.current = {
                ActivityID: decodeURIComponent(String(router.query["ActivityID"])),
                TopicSub: decodeURIComponent(String(router.query["TopicSub"])),
                CourseID: decodeURIComponent(String(router.query["CourseID"])),
                ModuleID: decodeURIComponent(String(router.query["ModuleID"])),
                BatchID: decodeURIComponent(String(router.query["BatchID"])),
                CourseName: decodeURIComponent(String(router.query["CourseName"])),
                TenantID: props.user.attributes["custom:tenantid"],
                UserSub: props.user.attributes["sub"]

            };
            const query = (routerRef.current.CourseID != "") ? getXlmsCourseDiscussionChatInfo : getXlmsDiscussionChatInfo;
            const queryName = (routerRef.current.CourseID != "") ? "getXlmsCourseDiscussionChatInfo" : "getXlmsDiscussionChatInfo";

            const listQuery = (routerRef.current.CourseID != "") ? listXlmsCourseDiscussionChat : listXlmsDiscussionChat;
            const getDiscussionSortKey = (routerRef.current.CourseID != "") ? "COURSEID#" + routerRef.current.CourseID + "#MODULE#" + routerRef.current.ModuleID + "#ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#" + routerRef.current.TopicSub : "ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#" + routerRef.current.TopicSub;
            const listDiscussionSortKey = (routerRef.current.CourseID == "") ? "ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#" : "COURSEID" + routerRef.current.CourseID + "MODULE#" + routerRef.current.ModuleID + "ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#";
            const editTopicData = await AppsyncDBconnection(
                query,
                {
                    PK: "TENANT#" + routerRef.current.TenantID,
                    SK: getDiscussionSortKey,
                }, props.user?.signInUserSession?.accessToken?.jwtToken
            );
            const mode = editTopicData.res?.[queryName] != null || editTopicData.res?.[queryName] != undefined ? "Edit" : "Create";

            const activityEnrollData = await AppsyncDBconnection(getXlmsActivityManagementInfo, { PK: "TENANT#" + routerRef.current.TenantID, SK: "ACTIVITYTYPE#Discussion#ACTIVITYID#" + routerRef.current.ActivityID, }, props.user.signInUserSession.accessToken.jwtToken);

            // const CourseEnrollData = await AppsyncDBconnection(getXlmsCourseEnrollUser, {
            //     PK: "TENANT#" + routerRef.current.TenantID + "#COURSE#ENROLLUSER#" + routerRef.current.UserSub,
            //     SK: "COURSE#" + routerRef.current.CourseID + "#BATCH#" + routerRef.current.BatchID,
            // }, props.user?.signInUserSession?.accessToken?.jwtToken);

            const discussionData = await AppsyncDBconnection(listQuery, {
                PK: "TENANT#" + routerRef.current.TenantID,
                SK: listDiscussionSortKey,
            }, props.user?.signInUserSession?.accessToken?.jwtToken);

            let actData;
            if (routerRef.current.CourseID != "") {
                const activityVariable = {
                    PK: "TENANT#" + routerRef.current.TenantID,
                    SK: "COURSEID#" + routerRef.current.CourseID,
                    IsDeleted: false
                };
                const actList = (await AppsyncDBconnection(listXlmsCourseModule, activityVariable, props.user?.signInUserSession?.accessToken?.jwtToken));
                actData = actList?.res?.listXlmsCourseModule?.items.filter((item) => item.ActivityID === routerRef.current.ActivityID)[0];
            }



            setCsrFetchedData({
                TenantID: routerRef.current.TenantID,
                ActivityID: routerRef.current.ActivityID,
                TopicSub: routerRef.current.TopicSub,
                DiscussionData: discussionData.res?.ListQuery?.items != undefined ? discussionData.res?.ListQuery?.items : [],
                Mode: mode,
                CourseID: routerRef.current.CourseID,
                ModuleID: routerRef.current.ModuleID,
                BatchID: routerRef.current.BatchID,
                EditTopicData: editTopicData.res?.[queryName] == undefined ? {} : editTopicData.res?.[queryName],
                ActivityEnrollData: activityEnrollData.res?.getXlmsActivityManagementInfo != undefined && activityEnrollData.res?.getXlmsActivityManagementInfo,
                ActivityData: routerRef.current.CourseID != "" && actData,
                CourseName: routerRef.current.CourseName,
            });


            const initialModalState = {
                ModalInfo: "Success",
                ModalTopMessage: "Success",
                ModalBottomMessage: "Discussion started successfully.",
                ModalOnClickEvent: () => {
                    if (routerRef.current.CourseID != "")
                        router.push(`/MyLearning/CourseConsume?CourseID=${routerRef.current.CourseID}&ActivityID=${routerRef.current.ActivityID}&ModuleId=${routerRef.current.ModuleID}&BatchId=${routerRef.current.BatchID}`);
                    else
                        router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${routerRef.current.ActivityID}&ActivityName=Discussion`);
                },
            };

        };
        dataSource();
        return (() => {
            setCsrFetchedData((temp) => { return { ...temp }; });
        });
    }, [props.user.attributes, props.user?.signInUserSession?.accessToken?.jwtToken, queryName, router, router.query]);

    const [tags, setTags] = useState(csrFetchedData?.EditTopicData?.Keywords != undefined ? JSON?.parse(csrFetchedData?.EditTopicData?.Keywords) : []);
    const previousState = useRef({ txtTopicName: {} });
    const query = useMemo(() => {
        let currentquery = [];
        (csrFetchedData?.CourseID == "") ?
            currentquery = [createXlmsDiscussionChat, getXlmsDiscussionChatInfo, updateXlmsDiscussionChat, listXlmsDiscussionChat, listXlmsDiscussionChatNameExits]
            : currentquery = [createXlmsCourseDiscussionChat, getXlmsCourseDiscussionChatInfo, updateXlmsCourseDiscussionChat, listXlmsCourseDiscussionChat, listXlmsCourseDiscussionChatNameExits];
        return currentquery;
    }, [csrFetchedData?.CourseID]);
    const queryName = useMemo(() => {
        let currentquery = [];
        (csrFetchedData?.CourseID == "") ?
            currentquery = ["createXlmsDiscussionChat", "getXlmsDiscussionChatInfo", "updateXlmsDiscussionChat", "listXlmsDiscussionChat", "listXlmsDiscussionChatNameExits"]
            : currentquery = ["createXlmsCourseDiscussionChat", "getXlmsCourseDiscussionChatInfo", "updateXlmsCourseDiscussionChat", "listXlmsCourseDiscussionChat", "listXlmsCourseDiscussionChatNameExits"];
        return currentquery;
    }, [csrFetchedData?.CourseID]);


    const [modalValues, setModalValues] = useState(initialModalState);
    const validationSchema = Yup.object().shape({
        txtTopicName: Yup.string().required("Topic name is required").matches(Regex("AlphaNumForTopicName"), "Invalid Topic Name").min(3, "Topic Name should me minimum of 3 characters").max(250, ("Maximum 250 characters Reached"))
            .test("name", ("Topic Name Already Exists"), async (e) => {
                if (csrFetchedData?.Mode?.toLowerCase() == "edit" && e.toLowerCase() == csrFetchedData?.EditTopicData?.TopicName.toLowerCase()) {
                    return true;
                }
                if (e == "" || !Regex("AlphaNumForTopicName").exec(e)) {
                    previousState.current = { ...previousState.current, txtTopicName: { previousVal: e, previousState: false } };
                    return false;
                }
       
                if (e.length >= 3) {
                    const variables = { PK: ("TENANT#" + props.TenantInfo.TenantID), SK: (routerRef.current.CourseID != "" ? ("COURSEID#" + routerRef.current.CourseID + "#MODULE#" + routerRef.current.ModuleID + "#ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#") : ("ACTIVITY#" + routerRef.current.ActivityID + "#TOPIC#")), TopicNameLowerCase: e.toLowerCase() };
                    const finalResponse = (await AppsyncDBconnection(query[4], variables, props?.user?.signInUserSession?.accessToken.jwtToken));
                    if (finalResponse.Status == "Success") {
                        if (finalResponse?.res?.[queryName[4]].items.length > 0) {
                            previousState.current = { ...previousState.current, txtTopicName: { previousVal: e, previousState: false } };
                            return false;
                        } else {
                            previousState.current = { ...previousState.current, txtTopicName: { previousVal: e, previousState: true } };
                            return true;
                        }
                    }
                }
                if (previousState.current?.txtTopicName?.previousVal != undefined && e == previousState.current.txtTopicName?.previousVal) {
                    return true;
                }
                return false;
            }),
    });

    const formOptions = {
        mode: "onChange",
        resolver: yupResolver(validationSchema),
        reValidateMode: "onChange",
        nativeValidation: false,
    };

    useMemo(() => {
        if (csrFetchedData?.EditTopicData?.Keywords) {
            setTags(JSON.parse(csrFetchedData?.EditTopicData?.Keywords));
        }
    }, [csrFetchedData?.EditTopicData?.Keywords]);

    const { register, handleSubmit, formState, watch, setValue,  } = useForm(formOptions);
    const { errors } = formState;
    const keyCodes = {
        comma: 188,
        enter: 13,
        tab: 9,
    };

    const delimiters = useMemo(() => {
        return [keyCodes.comma, keyCodes.enter, keyCodes.tab];
    }, [keyCodes.comma, keyCodes.enter, keyCodes.tab]);

    const finalResponse = useCallback((FinalStatus) => {
        if (FinalStatus != "Success") {
            setModalValues({
                ModalInfo: "Danger",
                ModalTopMessage: "Error",
                ModalBottomMessage: FinalStatus,
            });
            ModalOpen();
            return;
        } else {
            setValue("submit", "");
            setModalValues({
                ModalInfo: "Success",
                ModalOnClickEvent: () => {
                    if (csrFetchedData?.CourseID != "")
                        router.push(`/MyLearning/CourseConsume?CourseID=${csrFetchedData?.CourseID}&ActivityID=${csrFetchedData?.ActivityID}&ModuleId=${csrFetchedData?.ModuleID}&BatchId=${csrFetchedData?.BatchID}`);
                    else
                        router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${csrFetchedData?.ActivityID}&ActivityType=Discussion`);
                },
            });
            ModalOpen();
        }
    }, [csrFetchedData?.ActivityID, csrFetchedData?.BatchID, csrFetchedData?.CourseID, csrFetchedData?.ModuleID, router, setValue]);


    useEffect(() => {
        if (csrFetchedData?.Mode == "Edit") {
            setValue("txtTopicName", csrFetchedData?.EditTopicData?.TopicName);
            setValue("txtDiscussionmsg", csrFetchedData?.EditTopicData?.Description);
        }
        if (watch("isClean")) {
            setValue("txtTopicName", "");
            setTags([]);
            setValue("txtDiscussionmsg", "");
            setValue("isClean", false);
        }
    }, [csrFetchedData?.EditTopicData, csrFetchedData?.Mode, setValue, watch]);

    const handleDelete = useCallback(
        (i) => {
            setTags(tags.filter((tag, index) => index !== i));
            setValue("ReactTags", "Delete", { shouldValidate: true });
        },
        [setValue, tags]
    );
    const handleAddition = useCallback(
        (tag) => {
            setTags([...tags, tag]);
            setValue("ReactTags", "Add", { shouldValidate: true });
        },
        [setValue, tags]
    );

    const handleDrag = useCallback(
        (tag, currPos, newPos) => {
            const newTags = tags.slice();
            newTags.splice(currPos, 1);
            newTags.splice(newPos, 0, tag);
            setTags(newTags);
        },
        [tags]
    );



    const ReactTagsButton = ({ tags, ButtonClassName, ButtonText, errors, watch, delimiters, handleAddition, handleDelete, handleDrag, handleSubmit, router, submitHandler, Flag }) => {
        const count = Object.keys(errors);
        let focus = false;
        if (count.length == 1 && count[0] == "ReactTags") {
            focus = true;
        }



        return (
            <>
                <div className="">
                    <ReactTags className="" id="rcttags" autofocus={focus} inline allowUnique tags={tags} placeholder="Type and Press Enter to add new keywords" delimiters={delimiters} handleDelete={handleDelete} handleAddition={handleAddition} handleDrag={handleDrag} inputFieldPosition="top" />
                    <div className="{invalid-feedback} text-red-500 text-sm">
                        {errors?.ReactTags?.message}
                    </div>
                </div>
                <div className="flex justify-between gap-1 nvl-Def-Input pt-6">
                    <NVLButton id="btnSave" Flag={Flag} text={ButtonText ? ButtonText : "Submit"} disabled={watch("File") == "Uploading" ? true : false} type={"submit"} className={ButtonClassName ? ButtonClassName : `w-32 nvl-button bg-primary text-white ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`} onClick={handleSubmit((data) => submitHandler(data, "Page"))} />
                    <NVLButton id="btnCancel" text={"Cancel"} disabled={watch("File") == "Uploading" ? true : false}
                        type="button" className={`nvl-button w-28 ${watch("File") == "Uploading" ? "nvl-button-light" : ""}`}
                        onClick={() => csrFetchedData?.CourseID == "" ? router.push(`/MyLearning/UserConsume?Mode=Start&ActivityID=${csrFetchedData?.ActivityID}&ActivityType=Discussion`) : router.push(`/MyLearning/CourseConsume?CourseID=${csrFetchedData?.CourseID}&ActivityID=${csrFetchedData?.ActivityData?.ActivityID}&ModuleId=${csrFetchedData?.ActivityData?.ModuleID}&BatchId=${csrFetchedData?.BatchID}`)}></NVLButton>
                </div>
            </>
        );
    };

    const submitHandler = async (data) => {
        const dateTime = new Date().toLocaleString();
        const currentquery = (csrFetchedData?.Mode == "Edit" ? query[2] : query[0]);
        const userSub = props.user.attributes["sub"];
        const topicId = (csrFetchedData?.Mode == "Edit" ? csrFetchedData?.TopicSub : crypto.randomUUID());
        const sk = (csrFetchedData?.CourseID != "") ? "COURSEID#" + csrFetchedData?.CourseID + "#MODULE#" + csrFetchedData?.ModuleID + "#ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + topicId : "ACTIVITY#" + csrFetchedData?.ActivityID + "#TOPIC#" + topicId;
        let variables = {
            input: {
                PK: "TENANT#" + props.TenantInfo.TenantID,
                SK: sk,
                ActivityID: csrFetchedData?.ActivityID,
                Description: data.txtDiscussionmsg,
                TopicName: data.txtTopicName,
                TopicNameLowerCase: data.txtTopicName.toLowerCase(),
                Keywords: JSON.stringify(tags),
                CreatedDate: dateTime,
                TopicID: topicId,
                UserSub: userSub,
                TenantID: props.TenantInfo.TenantID,
                IsDelete: false,        
            },
        };
        if (csrFetchedData?.Mode != "Edit") {
            variables = {
                ...variables, input: {
                    ...variables.input,
                    UserSub: userSub
                }
            };
        }
        const finalStatus = (await AppsyncDBconnection(currentquery, variables, props?.user?.signInUserSession?.accessToken?.jwtToken)).Status;
        finalResponse(finalStatus);
    };
  
    const pageRoutes = useMemo(() => {
        let temp = [];
        if (csrFetchedData?.CourseID == "") {
            temp = [
                { path: `/MyLearning/LearningDashboard?parameters=4`, breadcrumb: `My Learning` },
                { path: `/MyLearning/UserConsume?Mode=Start&ActivityID=${csrFetchedData?.ActivityID}&ActivityType=Discussion`, breadcrumb: `My Activity - ${csrFetchedData?.ActivityEnrollData?.ActivityName}` },
                { path: "", breadcrumb: csrFetchedData?.Mode == "Edit" ? "Edit Topic" : "Create Topic" }
            ];
        } else {
            temp = [
                { path: "/MyLearning/LearningDashboard?parameters=1", breadcrumb: "My Learning" },
                { path: `/MyLearning/CourseConsume?CourseID=${csrFetchedData?.CourseID}&ActivityID=${csrFetchedData?.ActivityData?.ActivityID}&ModuleId=${csrFetchedData?.ActivityData?.ModuleID}&BatchId=${csrFetchedData?.BatchID}`, breadcrumb: 
        
        `${csrFetchedData?.CourseName} - ${csrFetchedData?.ActivityData?.ModuleName} - ${csrFetchedData?.ActivityData?.ActivityName}` },
        
                { path: "", breadcrumb: csrFetchedData?.Mode == "Edit" ? "Edit Topic" : "Create Topic" }
            ];
        }
        return temp;
    }, [csrFetchedData?.ActivityData?.ActivityID, csrFetchedData?.ActivityData?.ActivityName, csrFetchedData?.ActivityData?.ModuleID, csrFetchedData?.ActivityData?.ModuleName, csrFetchedData?.ActivityEnrollData?.ActivityName, csrFetchedData?.ActivityID, csrFetchedData?.BatchID, csrFetchedData?.CourseID, csrFetchedData?.CourseName, csrFetchedData?.Mode]);
    return (
        <>
            <Container PageRoutes={pageRoutes} loader={csrFetchedData.TenantID == undefined}>
                <NVLAlert ButtonYesstext={"X"} MessageTop={modalValues?.ModalTopMessage} MessageBottom={modalValues?.ModalBottomMessage} ModalOnClick={modalValues?.ModalOnClickEvent} ModalInfo={modalValues?.ModalInfo} />
                <form onSubmit={handleSubmit(submitHandler)}>
                    <div className="nvl-FormContent !overflow-y-visible	">
                        <NVLTextbox labelClassName="nvl-Def-Label"
                            labelText="Topic" id="txtTopicName" placeholder={"Topic Name"}
                            className={("nvl-mandatory nvl-Def-Input")}
                            register={register} errors={errors} />
                        <NVLMultilineTxtbox labelClassName="nvl-Def-Label" id="txtDiscussionmsg" title="Type your Message" labelText="Description" placeholder="Discussion" className=".nvl-non-mandatory nvl-Def-Input" register={register} errors={errors} />
                        <div className="Center-Aligned-Items flex items-center">
                            <div className="pt-1">
                                <div className="Center-Aligned-Items {invalid-feedback} text-red-500  text-sm">{errors.File?.message}</div>
                            </div>
                        </div>
                        <NVLlabel text="Tags/Keywords" className="nvl-Def-Label w-52"></NVLlabel>
                        <div>
                            <ReactTagsButton register={register} handleDelete={handleDelete} handleDrag={handleDrag} handleSubmit={handleSubmit} submitHandler={submitHandler} router={router} tags={tags} props={props} delimiters={delimiters} errors={errors} watch={watch} handleAddition={handleAddition} />
                        </div>
                    </div>
                </form>
            </Container>
        </>
    );
}

export default CreateTopic;
